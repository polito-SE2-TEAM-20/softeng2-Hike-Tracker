--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country) FROM stdin;
1	2	0.00	0	0.00	2	Airline Trail - Detour		/static/gpx/001_Airline_Trail___Detour.gpx	0.00				USA
2	2	0.00	0	0.00	2	Airline Trail		/static/gpx/002_Airline_Trail.gpx	0.00				USA
3	2	0.00	0	0.00	0	Colchester Railroad		/static/gpx/003_Colchester_Railroad.gpx	0.00				USA
4	2	0.00	0	0.00	1	Willimantic Flower Bridge		/static/gpx/004_Willimantic_Flower_Bridge.gpx	0.00				USA
5	2	0.00	0	0.00	1	Willimantic Pedestrian Bridge		/static/gpx/005_Willimantic_Pedestrian_Bridge.gpx	0.00				USA
6	2	0.00	0	0.00	2	Two Sister'S Preserve Loop Trail		/static/gpx/006_Two_Sister_S_Preserve_Loop_Trail.gpx	0.00				USA
7	2	0.00	0	0.00	1	Putnam River Trail		/static/gpx/007_Putnam_River_Trail.gpx	0.00				USA
8	2	0.00	0	0.00	2	Airline Trail Bypass		/static/gpx/008_Airline_Trail_Bypass.gpx	0.00				USA
9	2	0.00	0	0.00	2	Indian Neck		/static/gpx/009_Indian_Neck.gpx	0.00				USA
10	2	0.00	0	0.00	0	Stony Creek		/static/gpx/010_Stony_Creek.gpx	0.00				USA
11	2	0.00	0	0.00	1	Quarry-Westwoods		/static/gpx/011_Quarry_Westwoods.gpx	0.00				USA
12	2	0.00	0	0.00	0	Short Beach		/static/gpx/012_Short_Beach.gpx	0.00				USA
13	2	0.00	0	0.00	2	Charter Oak Greenway		/static/gpx/013_Charter_Oak_Greenway.gpx	0.00				USA
14	2	0.00	0	0.00	0	Bissell Greenway		/static/gpx/014_Bissell_Greenway.gpx	0.00				USA
15	2	0.00	0	0.00	2	Riverfront Trail System		/static/gpx/015_Riverfront_Trail_System.gpx	0.00				USA
16	2	0.00	0	0.00	2	Millers Pond Park Trail		/static/gpx/016_Millers_Pond_Park_Trail.gpx	0.00				USA
17	2	0.00	0	0.00	2	Mattabesett Trail		/static/gpx/017_Mattabesett_Trail.gpx	0.00				USA
18	2	0.00	0	0.00	2	Jefferson Park Trail		/static/gpx/018_Jefferson_Park_Trail.gpx	0.00				USA
19	2	0.00	0	0.00	2	Cockaponset Trail		/static/gpx/019_Cockaponset_Trail.gpx	0.00				USA
20	2	0.00	0	0.00	2	Mt. Nebo Park		/static/gpx/020_Mt__Nebo_Park.gpx	0.00				USA
21	2	0.00	0	0.00	2	 		/static/gpx/021__.gpx	0.00				USA
22	2	0.00	0	0.00	2	Proposed Trail		/static/gpx/022_Proposed_Trail.gpx	0.00				USA
23	2	0.00	0	0.00	2	Blinnshed Ridge Trail		/static/gpx/023_Blinnshed_Ridge_Trail.gpx	0.00				USA
24	2	0.00	0	0.00	2	Neck River Trail		/static/gpx/024_Neck_River_Trail.gpx	0.00				USA
25	2	0.00	0	0.00	2	Unnamed Trail		/static/gpx/025_Unnamed_Trail.gpx	0.00				USA
26	2	0.00	0	0.00	2	Oil Mill Brook Trail		/static/gpx/026_Oil_Mill_Brook_Trail.gpx	0.00				USA
27	2	0.00	0	0.00	2	Chatfield Trail		/static/gpx/027_Chatfield_Trail.gpx	0.00				USA
28	2	0.00	0	0.00	2	Unamed Trail		/static/gpx/028_Unamed_Trail.gpx	0.00				USA
29	2	0.00	0	0.00	2	Lost Pond Trail		/static/gpx/029_Lost_Pond_Trail.gpx	0.00				USA
30	2	0.00	0	0.00	2	Ccc Camp Hadley Trail		/static/gpx/030_Ccc_Camp_Hadley_Trail.gpx	0.00				USA
31	2	0.00	0	0.00	2	Double Loop Trail		/static/gpx/031_Double_Loop_Trail.gpx	0.00				USA
32	2	0.00	0	0.00	2	Over Brook Trail		/static/gpx/032_Over_Brook_Trail.gpx	0.00				USA
33	2	0.00	0	0.00	2	Cockaponset Forest Trail		/static/gpx/033_Cockaponset_Forest_Trail.gpx	0.00				USA
34	2	0.00	0	0.00	2	Pattaconk Trail		/static/gpx/034_Pattaconk_Trail.gpx	0.00				USA
35	2	0.00	0	0.00	2	Westwoods Forest Trail		/static/gpx/035_Westwoods_Forest_Trail.gpx	0.00				USA
36	2	0.00	0	0.00	2	Blinnshed Loop Trail		/static/gpx/036_Blinnshed_Loop_Trail.gpx	0.00				USA
37	2	0.00	0	0.00	2	Unnamed Tsail		/static/gpx/037_Unnamed_Tsail.gpx	0.00				USA
38	2	0.00	0	0.00	1	Messerschmidt Wma Trail		/static/gpx/038_Messerschmidt_Wma_Trail.gpx	0.00				USA
39	2	0.00	0	0.00	2	Westwoods Nature Trail		/static/gpx/039_Westwoods_Nature_Trail.gpx	0.00				USA
40	2	0.00	0	0.00	2	Enduro		/static/gpx/040_Enduro.gpx	0.00				USA
41	2	0.00	0	0.00	2	Land Trust Trail		/static/gpx/041_Land_Trust_Trail.gpx	0.00				USA
42	2	0.00	0	0.00	0	Beaver Brook Park Trail		/static/gpx/042_Beaver_Brook_Park_Trail.gpx	0.00				USA
43	2	0.00	0	0.00	2	Housatonic Forest Trail		/static/gpx/043_Housatonic_Forest_Trail.gpx	0.00				USA
44	2	0.00	0	0.00	1	Farmington Canal Trail		/static/gpx/044_Farmington_Canal_Trail.gpx	0.00				USA
45	2	0.00	0	0.00	2	Beckley Furnace Park Path		/static/gpx/045_Beckley_Furnace_Park_Path.gpx	0.00				USA
46	2	0.00	0	0.00	0	Farmington River Trail		/static/gpx/046_Farmington_River_Trail.gpx	0.00				USA
47	2	0.00	0	0.00	0	Farminton Canal Trail		/static/gpx/047_Farminton_Canal_Trail.gpx	0.00				USA
48	2	0.00	0	0.00	2	Farminton River Trail		/static/gpx/048_Farminton_River_Trail.gpx	0.00				USA
49	2	0.00	0	0.00	2	Hop River Trail		/static/gpx/049_Hop_River_Trail.gpx	0.00				USA
50	2	0.00	0	0.00	2	Hoprivertrail - Detouraround316		/static/gpx/050_Hoprivertrail___Detouraround316.gpx	0.00				USA
51	2	0.00	0	0.00	1	Hop River Trail - Long Hill Rd.		/static/gpx/051_Hop_River_Trail___Long_Hill_Rd_.gpx	0.00				USA
52	2	0.00	0	0.00	2	Hop River Trail - Rockville Spur		/static/gpx/052_Hop_River_Trail___Rockville_Spur.gpx	0.00				USA
53	2	0.00	0	0.00	2	Housatonic Rail Trail		/static/gpx/053_Housatonic_Rail_Trail.gpx	0.00				USA
54	2	0.00	0	0.00	1	Middletown Bikeway		/static/gpx/054_Middletown_Bikeway.gpx	0.00				USA
55	2	0.00	0	0.00	2	Mattabesett Trolley Trail		/static/gpx/055_Mattabesett_Trolley_Trail.gpx	0.00				USA
56	2	0.00	0	0.00	1	Moosup Valley State Park Trail		/static/gpx/056_Moosup_Valley_State_Park_Trail.gpx	0.00				USA
57	2	0.00	0	0.00	2	Quinnebaug River Trail		/static/gpx/057_Quinnebaug_River_Trail.gpx	0.00				USA
58	2	0.00	0	0.00	2	Tracey Road Trail		/static/gpx/058_Tracey_Road_Trail.gpx	0.00				USA
59	2	0.00	0	0.00	0	Trolley Trail		/static/gpx/059_Trolley_Trail.gpx	0.00				USA
60	2	0.00	0	0.00	2	Quinnebaug Hatchery Trail		/static/gpx/060_Quinnebaug_Hatchery_Trail.gpx	0.00				USA
61	2	0.00	0	0.00	2	Hopeville Park Trail		/static/gpx/061_Hopeville_Park_Trail.gpx	0.00				USA
62	2	0.00	0	0.00	1	Hopeville Park Path		/static/gpx/062_Hopeville_Park_Path.gpx	0.00				USA
63	2	0.00	0	0.00	2	Nehantic Trail		/static/gpx/063_Nehantic_Trail.gpx	0.00				USA
64	2	0.00	0	0.00	1	Camp Columbia Trail		/static/gpx/064_Camp_Columbia_Trail.gpx	0.00				USA
65	2	0.00	0	0.00	1	Shelton Land Trust Trail		/static/gpx/065_Shelton_Land_Trust_Trail.gpx	0.00				USA
66	2	0.00	0	0.00	1	Dinosaur Park Sidewalk		/static/gpx/066_Dinosaur_Park_Sidewalk.gpx	0.00				USA
67	2	0.00	0	0.00	0	Dinosaur Park Trail		/static/gpx/067_Dinosaur_Park_Trail.gpx	0.00				USA
68	2	0.00	0	0.00	1	Access Road		/static/gpx/068_Access_Road.gpx	0.00				USA
69	2	0.00	0	0.00	1	Day Pond Park Path		/static/gpx/069_Day_Pond_Park_Path.gpx	0.00				USA
70	2	0.00	0	0.00	2	Day Pond Park Trail		/static/gpx/070_Day_Pond_Park_Trail.gpx	0.00				USA
71	2	0.00	0	0.00	2	Salmon River Trail		/static/gpx/071_Salmon_River_Trail.gpx	0.00				USA
72	2	0.00	0	0.00	2	Salmon River Trial		/static/gpx/072_Salmon_River_Trial.gpx	0.00				USA
73	2	0.00	0	0.00	2	Dennis Hill Park Trail		/static/gpx/073_Dennis_Hill_Park_Trail.gpx	0.00				USA
74	2	0.00	0	0.00	1	Railroad Trail		/static/gpx/074_Railroad_Trail.gpx	0.00				USA
75	2	0.00	0	0.00	2	Gillette Castle Trail		/static/gpx/075_Gillette_Castle_Trail.gpx	0.00				USA
76	2	0.00	0	0.00	1	Kent Falls Park Path		/static/gpx/076_Kent_Falls_Park_Path.gpx	0.00				USA
77	2	0.00	0	0.00	0	Kent Falls Park Trail		/static/gpx/077_Kent_Falls_Park_Trail.gpx	0.00				USA
78	2	0.00	0	0.00	2	Lovers Leap Park Trail		/static/gpx/078_Lovers_Leap_Park_Trail.gpx	0.00				USA
79	2	0.00	0	0.00	2	Enders Forest Trail		/static/gpx/079_Enders_Forest_Trail.gpx	0.00				USA
80	2	0.00	0	0.00	0	Gay City Park Path		/static/gpx/080_Gay_City_Park_Path.gpx	0.00				USA
81	2	0.00	0	0.00	1	Gay City Park Trail		/static/gpx/081_Gay_City_Park_Trail.gpx	0.00				USA
82	2	0.00	0	0.00	1	Split Rock Trail		/static/gpx/082_Split_Rock_Trail.gpx	0.00				USA
83	2	0.00	0	0.00	0	Gillette Castle Path		/static/gpx/083_Gillette_Castle_Path.gpx	0.00				USA
84	2	0.00	0	0.00	0	Great Pond Forest Trail		/static/gpx/084_Great_Pond_Forest_Trail.gpx	0.00				USA
85	2	0.00	0	0.00	2	Haddam Meadows Park Trail		/static/gpx/085_Haddam_Meadows_Park_Trail.gpx	0.00				USA
86	2	0.00	0	0.00	2	Haley Farm Park Trail		/static/gpx/086_Haley_Farm_Park_Trail.gpx	0.00				USA
87	2	0.00	0	0.00	1	Hammonasset Park Path		/static/gpx/087_Hammonasset_Park_Path.gpx	0.00				USA
88	2	0.00	0	0.00	2	Nature Trail		/static/gpx/088_Nature_Trail.gpx	0.00				USA
89	2	0.00	0	0.00	0	Hammonasset Bike Path		/static/gpx/089_Hammonasset_Bike_Path.gpx	0.00				USA
90	2	0.00	0	0.00	0	Hammonasset Park Boardwalk		/static/gpx/090_Hammonasset_Park_Boardwalk.gpx	0.00				USA
91	2	0.00	0	0.00	0	Meigs Point Jetty		/static/gpx/091_Meigs_Point_Jetty.gpx	0.00				USA
92	2	0.00	0	0.00	2	Willard Island Nature Trail		/static/gpx/092_Willard_Island_Nature_Trail.gpx	0.00				USA
93	2	0.00	0	0.00	2	Moraine Nature Trail		/static/gpx/093_Moraine_Nature_Trail.gpx	0.00				USA
94	2	0.00	0	0.00	2	Haystack Park Trail		/static/gpx/094_Haystack_Park_Trail.gpx	0.00				USA
95	2	0.00	0	0.00	2	Higganum Reservoir Park Trail		/static/gpx/095_Higganum_Reservoir_Park_Trail.gpx	0.00				USA
96	2	0.00	0	0.00	2	Appalachian Trail		/static/gpx/096_Appalachian_Trail.gpx	0.00				USA
97	2	0.00	0	0.00	1	Mohawk Trail		/static/gpx/097_Mohawk_Trail.gpx	0.00				USA
98	2	0.00	0	0.00	1	Pine Knob Loop		/static/gpx/098_Pine_Knob_Loop.gpx	0.00				USA
99	2	0.00	0	0.00	2	Appalachian/Pine Knob Loop		/static/gpx/099_Appalachian_Pine_Knob_Loop.gpx	0.00				USA
100	2	0.00	0	0.00	2	White Mountain Trail		/static/gpx/100_White_Mountain_Trail.gpx	0.00				USA
101	2	0.00	0	0.00	2	River Trail		/static/gpx/101_River_Trail.gpx	0.00				USA
102	2	0.00	0	0.00	0	Hurd Park Trail		/static/gpx/102_Hurd_Park_Trail.gpx	0.00				USA
103	2	0.00	0	0.00	2	Hurd Park Path		/static/gpx/103_Hurd_Park_Path.gpx	0.00				USA
104	2	0.00	0	0.00	2	Paugussett Trail		/static/gpx/104_Paugussett_Trail.gpx	0.00				USA
105	2	0.00	0	0.00	0	Waterfall Trail		/static/gpx/105_Waterfall_Trail.gpx	0.00				USA
106	2	0.00	0	0.00	1	Paugussett Trail Connector		/static/gpx/106_Paugussett_Trail_Connector.gpx	0.00				USA
107	2	0.00	0	0.00	2	Minetto Park Trail		/static/gpx/107_Minetto_Park_Trail.gpx	0.00				USA
108	2	0.00	0	0.00	1	Coincident Macedonia Brook Rd		/static/gpx/108_Coincident_Macedonia_Brook_Rd.gpx	0.00				USA
109	2	0.00	0	0.00	1	Coincident Weber Road		/static/gpx/109_Coincident_Weber_Road.gpx	0.00				USA
110	2	0.00	0	0.00	1	Macedonia Ridge Trail		/static/gpx/110_Macedonia_Ridge_Trail.gpx	0.00				USA
111	2	0.00	0	0.00	1	Cobble Mountain Trail		/static/gpx/111_Cobble_Mountain_Trail.gpx	0.00				USA
112	2	0.00	0	0.00	1	Shenipsit Trail		/static/gpx/112_Shenipsit_Trail.gpx	0.00				USA
113	2	0.00	0	0.00	2	Meshomasic Forest Trail		/static/gpx/113_Meshomasic_Forest_Trail.gpx	0.00				USA
114	2	0.00	0	0.00	1	Crest Trail		/static/gpx/114_Crest_Trail.gpx	0.00				USA
115	2	0.00	0	0.00	2	Campground Trail		/static/gpx/115_Campground_Trail.gpx	0.00				USA
116	2	0.00	0	0.00	1	Brook Trail		/static/gpx/116_Brook_Trail.gpx	0.00				USA
117	2	0.00	0	0.00	2	Kettletown Park Trail		/static/gpx/117_Kettletown_Park_Trail.gpx	0.00				USA
118	2	0.00	0	0.00	0	North Ridge Trail		/static/gpx/118_North_Ridge_Trail.gpx	0.00				USA
119	2	0.00	0	0.00	1	North Ridge Loop Trail		/static/gpx/119_North_Ridge_Loop_Trail.gpx	0.00				USA
120	2	0.00	0	0.00	2	Miller Brook Connector Trail		/static/gpx/120_Miller_Brook_Connector_Trail.gpx	0.00				USA
121	2	0.00	0	0.00	0	Miller Trail		/static/gpx/121_Miller_Trail.gpx	0.00				USA
122	2	0.00	0	0.00	2	Miller Trail Spur		/static/gpx/122_Miller_Trail_Spur.gpx	0.00				USA
123	2	0.00	0	0.00	0	Pomperaug Trail		/static/gpx/123_Pomperaug_Trail.gpx	0.00				USA
124	2	0.00	0	0.00	2	Brook Trail Access		/static/gpx/124_Brook_Trail_Access.gpx	0.00				USA
125	2	0.00	0	0.00	2	Waramaug Lake Park Trail		/static/gpx/125_Waramaug_Lake_Park_Trail.gpx	0.00				USA
126	2	0.00	0	0.00	2	Well Groomed Trail		/static/gpx/126_Well_Groomed_Trail.gpx	0.00				USA
127	2	0.00	0	0.00	0	Mashamoquet Brook Park Trail		/static/gpx/127_Mashamoquet_Brook_Park_Trail.gpx	0.00				USA
128	2	0.00	0	0.00	0	Shenipsit Trail Spur		/static/gpx/128_Shenipsit_Trail_Spur.gpx	0.00				USA
129	2	0.00	0	0.00	0	Shenipsit		/static/gpx/129_Shenipsit.gpx	0.00				USA
130	2	0.00	0	0.00	1	Nassahegon Forest Trail		/static/gpx/130_Nassahegon_Forest_Trail.gpx	0.00				USA
131	2	0.00	0	0.00	0	Tunxis Trail		/static/gpx/131_Tunxis_Trail.gpx	0.00				USA
132	2	0.00	0	0.00	2	Black Spruce Bog Trail		/static/gpx/132_Black_Spruce_Bog_Trail.gpx	0.00				USA
133	2	0.00	0	0.00	0	Mohawk Forest Trail		/static/gpx/133_Mohawk_Forest_Trail.gpx	0.00				USA
134	2	0.00	0	0.00	1	Ethan Allen Youth Trail		/static/gpx/134_Ethan_Allen_Youth_Trail.gpx	0.00				USA
135	2	0.00	0	0.00	0	Punch Brook Trail		/static/gpx/135_Punch_Brook_Trail.gpx	0.00				USA
136	2	0.00	0	0.00	0	Red Cedar Lake Trail		/static/gpx/136_Red_Cedar_Lake_Trail.gpx	0.00				USA
137	2	0.00	0	0.00	1	Under Mountain Trail		/static/gpx/137_Under_Mountain_Trail.gpx	0.00				USA
138	2	0.00	0	0.00	1	Mount Tom Trail		/static/gpx/138_Mount_Tom_Trail.gpx	0.00				USA
139	2	0.00	0	0.00	1	Naugatuck Trail		/static/gpx/139_Naugatuck_Trail.gpx	0.00				USA
140	2	0.00	0	0.00	2	Nehantic Forest Trail		/static/gpx/140_Nehantic_Forest_Trail.gpx	0.00				USA
141	2	0.00	0	0.00	2	Naugatuck Forest Trail		/static/gpx/141_Naugatuck_Forest_Trail.gpx	0.00				USA
142	2	0.00	0	0.00	0	Naugatuck Spur		/static/gpx/142_Naugatuck_Spur.gpx	0.00				USA
143	2	0.00	0	0.00	0	Whitemore Trail		/static/gpx/143_Whitemore_Trail.gpx	0.00				USA
144	2	0.00	0	0.00	2	Quinnipiac Trail		/static/gpx/144_Quinnipiac_Trail.gpx	0.00				USA
145	2	0.00	0	0.00	2	Nehantic Forest Trai		/static/gpx/145_Nehantic_Forest_Trai.gpx	0.00				USA
146	2	0.00	0	0.00	2	Nepaug Forest Trail		/static/gpx/146_Nepaug_Forest_Trail.gpx	0.00				USA
147	2	0.00	0	0.00	0	Naugatuck		/static/gpx/147_Naugatuck.gpx	0.00				USA
148	2	0.00	0	0.00	2	Nyantaquit Trail		/static/gpx/148_Nyantaquit_Trail.gpx	0.00				USA
149	2	0.00	0	0.00	2	Tipping Rock Loop Trail		/static/gpx/149_Tipping_Rock_Loop_Trail.gpx	0.00				USA
150	2	0.00	0	0.00	1	Valley Outlook Trail		/static/gpx/150_Valley_Outlook_Trail.gpx	0.00				USA
151	2	0.00	0	0.00	1	Shelter 4 Loop Trail		/static/gpx/151_Shelter_4_Loop_Trail.gpx	0.00				USA
152	2	0.00	0	0.00	2	Osbornedale Park Trail		/static/gpx/152_Osbornedale_Park_Trail.gpx	0.00				USA
153	2	0.00	0	0.00	2	Unnamed		/static/gpx/153_Unnamed.gpx	0.00				USA
154	2	0.00	0	0.00	0	Paugnut Forest Trail		/static/gpx/154_Paugnut_Forest_Trail.gpx	0.00				USA
155	2	0.00	0	0.00	2	Charles L Pack Trail		/static/gpx/155_Charles_L_Pack_Trail.gpx	0.00				USA
156	2	0.00	0	0.00	1	Peoples Forest Trail		/static/gpx/156_Peoples_Forest_Trail.gpx	0.00				USA
157	2	0.00	0	0.00	0	Putnam Memorial Trail		/static/gpx/157_Putnam_Memorial_Trail.gpx	0.00				USA
158	2	0.00	0	0.00	1	Platt Hill Park Trail		/static/gpx/158_Platt_Hill_Park_Trail.gpx	0.00				USA
159	2	0.00	0	0.00	2	Metacomet Trail		/static/gpx/159_Metacomet_Trail.gpx	0.00				USA
160	2	0.00	0	0.00	0	Metacomet Trail Bypass		/static/gpx/160_Metacomet_Trail_Bypass.gpx	0.00				USA
161	2	0.00	0	0.00	1	Penwood Park Trail		/static/gpx/161_Penwood_Park_Trail.gpx	0.00				USA
162	2	0.00	0	0.00	2	Quadick Park Path		/static/gpx/162_Quadick_Park_Path.gpx	0.00				USA
163	2	0.00	0	0.00	1	Quadick Red Trail		/static/gpx/163_Quadick_Red_Trail.gpx	0.00				USA
164	2	0.00	0	0.00	1	Pootatuck Forest Trail		/static/gpx/164_Pootatuck_Forest_Trail.gpx	0.00				USA
165	2	0.00	0	0.00	1	River Highland Park Trail		/static/gpx/165_River_Highland_Park_Trail.gpx	0.00				USA
166	2	0.00	0	0.00	2	Tunxis		/static/gpx/166_Tunxis.gpx	0.00				USA
167	2	0.00	0	0.00	1	Old Furnace Trail		/static/gpx/167_Old_Furnace_Trail.gpx	0.00				USA
168	2	0.00	0	0.00	2	Old Furnace Park Trail		/static/gpx/168_Old_Furnace_Park_Trail.gpx	0.00				USA
169	2	0.00	0	0.00	2	Kestral Trail		/static/gpx/169_Kestral_Trail.gpx	0.00				USA
170	2	0.00	0	0.00	1	Warbler Trail		/static/gpx/170_Warbler_Trail.gpx	0.00				USA
171	2	0.00	0	0.00	2	Muir Trail		/static/gpx/171_Muir_Trail.gpx	0.00				USA
172	2	0.00	0	0.00	2	Shadow Pond Nature Trail		/static/gpx/172_Shadow_Pond_Nature_Trail.gpx	0.00				USA
173	2	0.00	0	0.00	2	Jesse Gerard Trail		/static/gpx/173_Jesse_Gerard_Trail.gpx	0.00				USA
174	2	0.00	0	0.00	1	Robert Ross Trail		/static/gpx/174_Robert_Ross_Trail.gpx	0.00				USA
175	2	0.00	0	0.00	1	Agnes Bowen Trail		/static/gpx/175_Agnes_Bowen_Trail.gpx	0.00				USA
176	2	0.00	0	0.00	0	Elliot Bronson Trail		/static/gpx/176_Elliot_Bronson_Trail.gpx	0.00				USA
177	2	0.00	0	0.00	2	Walt Landgraf Trail		/static/gpx/177_Walt_Landgraf_Trail.gpx	0.00				USA
178	2	0.00	0	0.00	0	Squantz Pond Park Trail		/static/gpx/178_Squantz_Pond_Park_Trail.gpx	0.00				USA
179	2	0.00	0	0.00	1	Putnam Memorial Museum Trail		/static/gpx/179_Putnam_Memorial_Museum_Trail.gpx	0.00				USA
180	2	0.00	0	0.00	0	Quinnipiac Park Trail		/static/gpx/180_Quinnipiac_Park_Trail.gpx	0.00				USA
181	2	0.00	0	0.00	0	Boardwalk		/static/gpx/181_Boardwalk.gpx	0.00				USA
182	2	0.00	0	0.00	0	Rocky Neck Park Sidewalk		/static/gpx/182_Rocky_Neck_Park_Sidewalk.gpx	0.00				USA
183	2	0.00	0	0.00	0	Rocky Neck Park Path		/static/gpx/183_Rocky_Neck_Park_Path.gpx	0.00				USA
184	2	0.00	0	0.00	1	Rocky Neck Park Trail		/static/gpx/184_Rocky_Neck_Park_Trail.gpx	0.00				USA
185	2	0.00	0	0.00	2	Rope Swing		/static/gpx/185_Rope_Swing.gpx	0.00				USA
186	2	0.00	0	0.00	2	Sherwood Island Park Path		/static/gpx/186_Sherwood_Island_Park_Path.gpx	0.00				USA
187	2	0.00	0	0.00	0	Sleeping Giant Park Trail		/static/gpx/187_Sleeping_Giant_Park_Trail.gpx	0.00				USA
188	2	0.00	0	0.00	1	Sherwood Island Nature Trail		/static/gpx/188_Sherwood_Island_Nature_Trail.gpx	0.00				USA
189	2	0.00	0	0.00	1	Sleeping Giant Park Path		/static/gpx/189_Sleeping_Giant_Park_Path.gpx	0.00				USA
190	2	0.00	0	0.00	2	Tower Trail		/static/gpx/190_Tower_Trail.gpx	0.00				USA
191	2	0.00	0	0.00	2	Quinnipiac Trail Spur		/static/gpx/191_Quinnipiac_Trail_Spur.gpx	0.00				USA
192	2	0.00	0	0.00	1	Southford Falls Park Trail		/static/gpx/192_Southford_Falls_Park_Trail.gpx	0.00				USA
193	2	0.00	0	0.00	1	Tunxis Forest Trail		/static/gpx/193_Tunxis_Forest_Trail.gpx	0.00				USA
194	2	0.00	0	0.00	2	Sleeping Giant Trail		/static/gpx/194_Sleeping_Giant_Trail.gpx	0.00				USA
195	2	0.00	0	0.00	1	Stratton Brook Park Path		/static/gpx/195_Stratton_Brook_Park_Path.gpx	0.00				USA
196	2	0.00	0	0.00	2	Bike Trail		/static/gpx/196_Bike_Trail.gpx	0.00				USA
197	2	0.00	0	0.00	0	Stratton Brook Park Trail		/static/gpx/197_Stratton_Brook_Park_Trail.gpx	0.00				USA
198	2	0.00	0	0.00	1	Simsbury Park Trail		/static/gpx/198_Simsbury_Park_Trail.gpx	0.00				USA
199	2	0.00	0	0.00	1	Wolcott Trail		/static/gpx/199_Wolcott_Trail.gpx	0.00				USA
200	2	0.00	0	0.00	1	Madden Fyler Pond Trail		/static/gpx/200_Madden_Fyler_Pond_Trail.gpx	0.00				USA
201	2	0.00	0	0.00	1	Sunny Brook Park Trail		/static/gpx/201_Sunny_Brook_Park_Trail.gpx	0.00				USA
202	2	0.00	0	0.00	1	Fadoir Spring Trail		/static/gpx/202_Fadoir_Spring_Trail.gpx	0.00				USA
203	2	0.00	0	0.00	2	Fadoir Trail		/static/gpx/203_Fadoir_Trail.gpx	0.00				USA
204	2	0.00	0	0.00	1	Walnut Mountain Trail		/static/gpx/204_Walnut_Mountain_Trail.gpx	0.00				USA
205	2	0.00	0	0.00	1	Wolcott		/static/gpx/205_Wolcott.gpx	0.00				USA
206	2	0.00	0	0.00	1	Old Metacomet Trail		/static/gpx/206_Old_Metacomet_Trail.gpx	0.00				USA
207	2	0.00	0	0.00	0	Talcott Mountain Park Trail		/static/gpx/207_Talcott_Mountain_Park_Trail.gpx	0.00				USA
208	2	0.00	0	0.00	1	Falls Brook Trail		/static/gpx/208_Falls_Brook_Trail.gpx	0.00				USA
209	2	0.00	0	0.00	2	Whittemore Glen Trail		/static/gpx/209_Whittemore_Glen_Trail.gpx	0.00				USA
210	2	0.00	0	0.00	1	Wharton Brook Park Trail		/static/gpx/210_Wharton_Brook_Park_Trail.gpx	0.00				USA
211	2	0.00	0	0.00	2	Larkin Bridle Trail		/static/gpx/211_Larkin_Bridle_Trail.gpx	0.00				USA
212	2	0.00	0	0.00	0	Bluff Point Bike Path		/static/gpx/212_Bluff_Point_Bike_Path.gpx	0.00				USA
213	2	0.00	0	0.00	0	Bluff Point Trail		/static/gpx/213_Bluff_Point_Trail.gpx	0.00				USA
214	2	0.00	0	0.00	2	Hrt - Main Street Spur		/static/gpx/214_Hrt___Main_Street_Spur.gpx	0.00				USA
215	2	0.00	0	0.00	2	Laurel Brook Trail		/static/gpx/215_Laurel_Brook_Trail.gpx	0.00				USA
216	2	0.00	0	0.00	2	Wadsworth Falls Park Trail		/static/gpx/216_Wadsworth_Falls_Park_Trail.gpx	0.00				USA
217	2	0.00	0	0.00	2	White Birch Trail		/static/gpx/217_White_Birch_Trail.gpx	0.00				USA
218	2	0.00	0	0.00	2	Red Cedar Trail		/static/gpx/218_Red_Cedar_Trail.gpx	0.00				USA
219	2	0.00	0	0.00	2	Little Falls Trail		/static/gpx/219_Little_Falls_Trail.gpx	0.00				USA
220	2	0.00	0	0.00	2	Deer Trail		/static/gpx/220_Deer_Trail.gpx	0.00				USA
221	2	0.00	0	0.00	2	Rockfall Land Trust Trail		/static/gpx/221_Rockfall_Land_Trust_Trail.gpx	0.00				USA
222	2	0.00	0	0.00	2	Bridge Trail		/static/gpx/222_Bridge_Trail.gpx	0.00				USA
223	2	0.00	0	0.00	2	Main Trail		/static/gpx/223_Main_Trail.gpx	0.00				USA
224	2	0.00	0	0.00	2	American Legion Forest Trail		/static/gpx/224_American_Legion_Forest_Trail.gpx	0.00				USA
225	2	0.00	0	0.00	2	Turkey Vultures Ledges Trail		/static/gpx/225_Turkey_Vultures_Ledges_Trail.gpx	0.00				USA
226	2	0.00	0	0.00	2	Henry R Buck Trail		/static/gpx/226_Henry_R_Buck_Trail.gpx	0.00				USA
227	2	0.00	0	0.00	2	Mashapaug Pond View Trail		/static/gpx/227_Mashapaug_Pond_View_Trail.gpx	0.00				USA
228	2	0.00	0	0.00	2	Bigelow Hollow Park Trail		/static/gpx/228_Bigelow_Hollow_Park_Trail.gpx	0.00				USA
229	2	0.00	0	0.00	2	Breakneck Pond View Trail		/static/gpx/229_Breakneck_Pond_View_Trail.gpx	0.00				USA
230	2	0.00	0	0.00	2	East Ridge Trail		/static/gpx/230_East_Ridge_Trail.gpx	0.00				USA
231	2	0.00	0	0.00	2	Bigelow Pond Loop Trail		/static/gpx/231_Bigelow_Pond_Loop_Trail.gpx	0.00				USA
232	2	0.00	0	0.00	2	Ridge Trail		/static/gpx/232_Ridge_Trail.gpx	0.00				USA
233	2	0.00	0	0.00	2	Nipmuck Trail		/static/gpx/233_Nipmuck_Trail.gpx	0.00				USA
234	2	0.00	0	0.00	2	Mattatuck Trail		/static/gpx/234_Mattatuck_Trail.gpx	0.00				USA
235	2	0.00	0	0.00	2	Black Rock Park Trail		/static/gpx/235_Black_Rock_Park_Trail.gpx	0.00				USA
236	2	0.00	0	0.00	1	Poquonnock River Walk		/static/gpx/236_Poquonnock_River_Walk.gpx	0.00				USA
237	2	0.00	0	0.00	1	Kempf & Shenipsit Trail		/static/gpx/237_Kempf___Shenipsit_Trail.gpx	0.00				USA
238	2	0.00	0	0.00	1	Kempf Trail		/static/gpx/238_Kempf_Trail.gpx	0.00				USA
239	2	0.00	0	0.00	2	Railroad Bed		/static/gpx/239_Railroad_Bed.gpx	0.00				USA
240	2	0.00	0	0.00	2	Mohegan Trail		/static/gpx/240_Mohegan_Trail.gpx	0.00				USA
241	2	0.00	0	0.00	0	Burr Pond Park Trail		/static/gpx/241_Burr_Pond_Park_Trail.gpx	0.00				USA
242	2	0.00	0	0.00	2	Burr Pond Park Path		/static/gpx/242_Burr_Pond_Park_Path.gpx	0.00				USA
243	2	0.00	0	0.00	1	Campbell Falls Trail		/static/gpx/243_Campbell_Falls_Trail.gpx	0.00				USA
244	2	0.00	0	0.00	2	Deep Woods Trail		/static/gpx/244_Deep_Woods_Trail.gpx	0.00				USA
245	2	0.00	0	0.00	2	Chimney Trail		/static/gpx/245_Chimney_Trail.gpx	0.00				USA
246	2	0.00	0	0.00	2	Chimney Connector Trail		/static/gpx/246_Chimney_Connector_Trail.gpx	0.00				USA
247	2	0.00	0	0.00	2	East Woods Trail		/static/gpx/247_East_Woods_Trail.gpx	0.00				USA
248	2	0.00	0	0.00	2	East Woods Connector Trail		/static/gpx/248_East_Woods_Connector_Trail.gpx	0.00				USA
249	2	0.00	0	0.00	2	Covered Bridge Connector Trail		/static/gpx/249_Covered_Bridge_Connector_Trail.gpx	0.00				USA
250	2	0.00	0	0.00	2	Covered Bridge Trail		/static/gpx/250_Covered_Bridge_Trail.gpx	0.00				USA
251	2	0.00	0	0.00	2	Lookout Trail		/static/gpx/251_Lookout_Trail.gpx	0.00				USA
252	2	0.00	0	0.00	2	Chatfield Hollow Park Trail		/static/gpx/252_Chatfield_Hollow_Park_Trail.gpx	0.00				USA
253	2	0.00	0	0.00	2	Lookout Spur Trail		/static/gpx/253_Lookout_Spur_Trail.gpx	0.00				USA
254	2	0.00	0	0.00	2	Chimney Spur Trail		/static/gpx/254_Chimney_Spur_Trail.gpx	0.00				USA
255	2	0.00	0	0.00	2	Deep Woods Access Trail		/static/gpx/255_Deep_Woods_Access_Trail.gpx	0.00				USA
256	2	0.00	0	0.00	2	West Crest Trail		/static/gpx/256_West_Crest_Trail.gpx	0.00				USA
257	2	0.00	0	0.00	2	Chatfield Park Path		/static/gpx/257_Chatfield_Park_Path.gpx	0.00				USA
258	2	0.00	0	0.00	2	Pond Trail		/static/gpx/258_Pond_Trail.gpx	0.00				USA
259	2	0.00	0	0.00	0	Paul F Wildermann		/static/gpx/259_Paul_F_Wildermann.gpx	0.00				USA
260	2	0.00	0	0.00	2	Cockaponset Forest Path		/static/gpx/260_Cockaponset_Forest_Path.gpx	0.00				USA
261	2	0.00	0	0.00	2	Kay Fullerton Trail		/static/gpx/261_Kay_Fullerton_Trail.gpx	0.00				USA
262	2	0.00	0	0.00	2	Quinimay Trail		/static/gpx/262_Quinimay_Trail.gpx	0.00				USA
263	2	0.00	0	0.00	2	Cowboy Way Trail		/static/gpx/263_Cowboy_Way_Trail.gpx	0.00				USA
264	2	0.00	0	0.00	2	Muck Rock Road Trail		/static/gpx/264_Muck_Rock_Road_Trail.gpx	0.00				USA
265	2	0.00	0	0.00	2	Weber Road Trail		/static/gpx/265_Weber_Road_Trail.gpx	0.00				USA
266	2	0.00	0	0.00	2	Beechnut Bog Trail		/static/gpx/266_Beechnut_Bog_Trail.gpx	0.00				USA
267	2	0.00	0	0.00	2	Wood Road Trail		/static/gpx/267_Wood_Road_Trail.gpx	0.00				USA
268	2	0.00	0	0.00	2	Bumpy Hill Road Trail		/static/gpx/268_Bumpy_Hill_Road_Trail.gpx	0.00				USA
269	2	0.00	0	0.00	2	Kristens Way Trail		/static/gpx/269_Kristens_Way_Trail.gpx	0.00				USA
270	2	0.00	0	0.00	2	Messerschmidt Lane Trail		/static/gpx/270_Messerschmidt_Lane_Trail.gpx	0.00				USA
271	2	0.00	0	0.00	2	Tower Hill Connector Trail		/static/gpx/271_Tower_Hill_Connector_Trail.gpx	0.00				USA
272	2	0.00	0	0.00	2	Mattabesset Trail		/static/gpx/272_Mattabesset_Trail.gpx	0.00				USA
273	2	0.00	0	0.00	2	Mattabasset Trail		/static/gpx/273_Mattabasset_Trail.gpx	0.00				USA
274	2	0.00	0	0.00	2	Old Mattebesset Trail		/static/gpx/274_Old_Mattebesset_Trail.gpx	0.00				USA
275	2	0.00	0	0.00	2	Huntington Park Trail		/static/gpx/275_Huntington_Park_Trail.gpx	0.00				USA
276	2	0.00	0	0.00	2	Huntington Ridge Trail		/static/gpx/276_Huntington_Ridge_Trail.gpx	0.00				USA
277	2	0.00	0	0.00	2	Aspetuck Valley Trail		/static/gpx/277_Aspetuck_Valley_Trail.gpx	0.00				USA
278	2	0.00	0	0.00	2	Vista Trail		/static/gpx/278_Vista_Trail.gpx	0.00				USA
279	2	0.00	0	0.00	2	Devils Hopyard Park Trail		/static/gpx/279_Devils_Hopyard_Park_Trail.gpx	0.00				USA
280	2	0.00	0	0.00	2	Witch Hazel/Millington Trail		/static/gpx/280_Witch_Hazel_Millington_Trail.gpx	0.00				USA
281	2	0.00	0	0.00	2	Millington Trail		/static/gpx/281_Millington_Trail.gpx	0.00				USA
282	2	0.00	0	0.00	2	Loop Trail		/static/gpx/282_Loop_Trail.gpx	0.00				USA
283	2	0.00	0	0.00	2	Witch Hazel Trail		/static/gpx/283_Witch_Hazel_Trail.gpx	0.00				USA
284	2	0.00	0	0.00	2	Woodcutters Trail		/static/gpx/284_Woodcutters_Trail.gpx	0.00				USA
285	2	0.00	0	0.00	2	Chapman Falls Trail		/static/gpx/285_Chapman_Falls_Trail.gpx	0.00				USA
286	2	0.00	0	0.00	2	Devils Oven Spur Trail		/static/gpx/286_Devils_Oven_Spur_Trail.gpx	0.00				USA
287	2	0.00	0	0.00	2	Maxs Trail		/static/gpx/287_Maxs_Trail.gpx	0.00				USA
288	2	0.00	0	0.00	1	Machimoodus Park Trail		/static/gpx/288_Machimoodus_Park_Trail.gpx	0.00				USA
289	2	0.00	0	0.00	1	Fishermans Trail		/static/gpx/289_Fishermans_Trail.gpx	0.00				USA
290	2	0.00	0	0.00	2	Ccc Trail		/static/gpx/290_Ccc_Trail.gpx	0.00				USA
291	2	0.00	0	0.00	2	Natchaug Trail		/static/gpx/291_Natchaug_Trail.gpx	0.00				USA
292	2	0.00	0	0.00	2	Natchaug Forest Trail		/static/gpx/292_Natchaug_Forest_Trail.gpx	0.00				USA
293	2	0.00	0	0.00	2	Goodwin Forest Trail		/static/gpx/293_Goodwin_Forest_Trail.gpx	0.00				USA
294	2	0.00	0	0.00	2	Pine Acres Pond Trail		/static/gpx/294_Pine_Acres_Pond_Trail.gpx	0.00				USA
295	2	0.00	0	0.00	2	Brown Hill Pond Trail		/static/gpx/295_Brown_Hill_Pond_Trail.gpx	0.00				USA
296	2	0.00	0	0.00	2	Yellow White Loop Trail		/static/gpx/296_Yellow_White_Loop_Trail.gpx	0.00				USA
297	2	0.00	0	0.00	2	Red Yellow Connector Trail		/static/gpx/297_Red_Yellow_Connector_Trail.gpx	0.00				USA
298	2	0.00	0	0.00	2	Governor'S Island Trail		/static/gpx/298_Governor_S_Island_Trail.gpx	0.00				USA
299	2	0.00	0	0.00	2	Goodwin Foresttrail		/static/gpx/299_Goodwin_Foresttrail.gpx	0.00				USA
300	2	0.00	0	0.00	2	Forest Discovery Trail		/static/gpx/300_Forest_Discovery_Trail.gpx	0.00				USA
301	2	0.00	0	0.00	2	Goodwin Heritage Trail		/static/gpx/301_Goodwin_Heritage_Trail.gpx	0.00				USA
302	2	0.00	0	0.00	2	Crest		/static/gpx/302_Crest.gpx	0.00				USA
303	2	0.00	0	0.00	1	Mansfield Hollow Park Trail		/static/gpx/303_Mansfield_Hollow_Park_Trail.gpx	0.00				USA
304	2	0.00	0	0.00	0	Nipmuck Trail - East Branch		/static/gpx/304_Nipmuck_Trail___East_Branch.gpx	0.00				USA
305	2	0.00	0	0.00	1	Nipmuck Alternate		/static/gpx/305_Nipmuck_Alternate.gpx	0.00				USA
306	2	0.00	0	0.00	2	Mashamoquet Brook Nature Trail		/static/gpx/306_Mashamoquet_Brook_Nature_Trail.gpx	0.00				USA
307	2	0.00	0	0.00	2	Nipmuck Forest Trail		/static/gpx/307_Nipmuck_Forest_Trail.gpx	0.00				USA
308	2	0.00	0	0.00	2	Morey Pond Trail		/static/gpx/308_Morey_Pond_Trail.gpx	0.00				USA
309	2	0.00	0	0.00	2	Nipmuck Foreat Trail		/static/gpx/309_Nipmuck_Foreat_Trail.gpx	0.00				USA
310	2	0.00	0	0.00	2	Pharisee Rock Trail		/static/gpx/310_Pharisee_Rock_Trail.gpx	0.00				USA
311	2	0.00	0	0.00	2	Pachaug Forest Trail		/static/gpx/311_Pachaug_Forest_Trail.gpx	0.00				USA
312	2	0.00	0	0.00	2	Pachaug Trail		/static/gpx/312_Pachaug_Trail.gpx	0.00				USA
313	2	0.00	0	0.00	2	Canonicus Trail		/static/gpx/313_Canonicus_Trail.gpx	0.00				USA
314	2	0.00	0	0.00	2	Pachaug		/static/gpx/314_Pachaug.gpx	0.00				USA
315	2	0.00	0	0.00	2	Laurel Loop Trail		/static/gpx/315_Laurel_Loop_Trail.gpx	0.00				USA
316	2	0.00	0	0.00	2	Pachaug/Nehantic Connector		/static/gpx/316_Pachaug_Nehantic_Connector.gpx	0.00				USA
317	2	0.00	0	0.00	2	Pachaug/Tippecansett Connector		/static/gpx/317_Pachaug_Tippecansett_Connector.gpx	0.00				USA
318	2	0.00	0	0.00	2	Nehantic/Pachaug Connector		/static/gpx/318_Nehantic_Pachaug_Connector.gpx	0.00				USA
319	2	0.00	0	0.00	2	Quinebaug/Pachaug Connector		/static/gpx/319_Quinebaug_Pachaug_Connector.gpx	0.00				USA
320	2	0.00	0	0.00	2	Quinebaug Trail		/static/gpx/320_Quinebaug_Trail.gpx	0.00				USA
321	2	0.00	0	0.00	2	Pachaug/Narragansett Connector		/static/gpx/321_Pachaug_Narragansett_Connector.gpx	0.00				USA
322	2	0.00	0	0.00	2	Narragansett Trail		/static/gpx/322_Narragansett_Trail.gpx	0.00				USA
323	2	0.00	0	0.00	2	Green Falls Loop Trail		/static/gpx/323_Green_Falls_Loop_Trail.gpx	0.00				USA
324	2	0.00	0	0.00	2	Green Falls Water Access Trail		/static/gpx/324_Green_Falls_Water_Access_Trail.gpx	0.00				USA
325	2	0.00	0	0.00	2	Freeman Trail		/static/gpx/325_Freeman_Trail.gpx	0.00				USA
326	2	0.00	0	0.00	2	Tippecansett Trail		/static/gpx/326_Tippecansett_Trail.gpx	0.00				USA
327	2	0.00	0	0.00	2	Tippecansett/Freeman Trail		/static/gpx/327_Tippecansett_Freeman_Trail.gpx	0.00				USA
328	2	0.00	0	0.00	1	Green Falls Pond Trail		/static/gpx/328_Green_Falls_Pond_Trail.gpx	0.00				USA
329	2	0.00	0	0.00	2	Nehantic/Pachaug Trail		/static/gpx/329_Nehantic_Pachaug_Trail.gpx	0.00				USA
330	2	0.00	0	0.00	2	Phillips Pond Spur Trail		/static/gpx/330_Phillips_Pond_Spur_Trail.gpx	0.00				USA
331	2	0.00	0	0.00	2	Quinebaug/Nehantic Connector		/static/gpx/331_Quinebaug_Nehantic_Connector.gpx	0.00				USA
332	2	0.00	0	0.00	0	Nehantic/Quinebaug Connector		/static/gpx/332_Nehantic_Quinebaug_Connector.gpx	0.00				USA
333	2	0.00	0	0.00	1	Patagansett Trail		/static/gpx/333_Patagansett_Trail.gpx	0.00				USA
334	2	0.00	0	0.00	2	Paugussett Forest Trail		/static/gpx/334_Paugussett_Forest_Trail.gpx	0.00				USA
335	2	0.00	0	0.00	2	Zoar Trail		/static/gpx/335_Zoar_Trail.gpx	0.00				USA
336	2	0.00	0	0.00	2	Lillinonah Trail		/static/gpx/336_Lillinonah_Trail.gpx	0.00				USA
337	2	0.00	0	0.00	2	Zoar Trail (Old)		/static/gpx/337_Zoar_Trail__Old_.gpx	0.00				USA
338	2	0.00	0	0.00	2	Upper Gussy Trail		/static/gpx/338_Upper_Gussy_Trail.gpx	0.00				USA
339	2	0.00	0	0.00	2	Pierrepont Park Trail		/static/gpx/339_Pierrepont_Park_Trail.gpx	0.00				USA
340	2	0.00	0	0.00	2	Shenipsit Forest Trail		/static/gpx/340_Shenipsit_Forest_Trail.gpx	0.00				USA
341	2	0.00	0	0.00	2	Quary Trail		/static/gpx/341_Quary_Trail.gpx	0.00				USA
342	2	0.00	0	0.00	2	Shenipsit Forest Road		/static/gpx/342_Shenipsit_Forest_Road.gpx	0.00				USA
343	2	0.00	0	0.00	2	Topsmead Forest Trail		/static/gpx/343_Topsmead_Forest_Trail.gpx	0.00				USA
344	2	0.00	0	0.00	2	Edith M Chase Ecology Trail		/static/gpx/344_Edith_M_Chase_Ecology_Trail.gpx	0.00				USA
345	2	0.00	0	0.00	2	Bernard H Stairs Trail		/static/gpx/345_Bernard_H_Stairs_Trail.gpx	0.00				USA
346	2	0.00	0	0.00	2	West Rock Park Trail		/static/gpx/346_West_Rock_Park_Trail.gpx	0.00				USA
347	2	0.00	0	0.00	2	West Rock Summit Trail		/static/gpx/347_West_Rock_Summit_Trail.gpx	0.00				USA
348	2	0.00	0	0.00	2	Regicides Trail		/static/gpx/348_Regicides_Trail.gpx	0.00				USA
349	2	0.00	0	0.00	1	Sanford Feeder Trail		/static/gpx/349_Sanford_Feeder_Trail.gpx	0.00				USA
350	2	0.00	0	0.00	2	North Summit Trail		/static/gpx/350_North_Summit_Trail.gpx	0.00				USA
351	2	0.00	0	0.00	2	Westville Feeder Trail		/static/gpx/351_Westville_Feeder_Trail.gpx	0.00				USA
352	2	0.00	0	0.00	2	West Rock Park Road		/static/gpx/352_West_Rock_Park_Road.gpx	0.00				USA
353	2	0.00	0	0.00	1	Bennetts Pond Trail		/static/gpx/353_Bennetts_Pond_Trail.gpx	0.00				USA
354	2	0.00	0	0.00	2	Ives Trail		/static/gpx/354_Ives_Trail.gpx	0.00				USA
355	2	0.00	0	0.00	1	Ridgefield Open Space Trail		/static/gpx/355_Ridgefield_Open_Space_Trail.gpx	0.00				USA
356	2	0.00	0	0.00	2	George Dudley Seymour Park Trail		/static/gpx/356_George_Dudley_Seymour_Park_Trail.gpx	0.00				USA
357	2	0.00	0	0.00	0	Grta		/static/gpx/357_Grta.gpx	0.00				USA
358	2	0.00	0	0.00	0	Mohegan Forest Trail		/static/gpx/358_Mohegan_Forest_Trail.gpx	0.00				USA
359	2	0.00	0	0.00	1	Mount Bushnell Trail		/static/gpx/359_Mount_Bushnell_Trail.gpx	0.00				USA
360	2	0.00	0	0.00	2	Nye Holman Trail		/static/gpx/360_Nye_Holman_Trail.gpx	0.00				USA
361	2	0.00	0	0.00	2	Al'S Trail		/static/gpx/361_Al_S_Trail.gpx	0.00				USA
362	2	0.00	0	0.00	2	Salt Rock State Park Trail		/static/gpx/362_Salt_Rock_State_Park_Trail.gpx	0.00				USA
363	2	0.00	0	0.00	2	Scantic River Trail		/static/gpx/363_Scantic_River_Trail.gpx	0.00				USA
364	2	0.00	0	0.00	1	Scantic River Park Trail		/static/gpx/364_Scantic_River_Park_Trail.gpx	0.00				USA
365	2	0.00	0	0.00	2	Scantic Park Access		/static/gpx/365_Scantic_Park_Access.gpx	0.00				USA
366	2	0.00	0	0.00	1	Sunrise Park Trail		/static/gpx/366_Sunrise_Park_Trail.gpx	0.00				USA
367	2	0.00	0	0.00	0	Kitchel Trail		/static/gpx/367_Kitchel_Trail.gpx	0.00				USA
368	2	0.00	0	0.00	2	Old Driveway		/static/gpx/368_Old_Driveway.gpx	0.00				USA
369	2	0.00	0	0.00	0	Kitchel		/static/gpx/369_Kitchel.gpx	0.00				USA
370	2	0.00	0	0.00	0	Driveway		/static/gpx/370_Driveway.gpx	0.00				USA
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website) FROM stdin;
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address) FROM stdin;
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash") FROM stdin;
2	$2b$10$DNYgQBhCA575pr2loREhZu3lecCnzRY2vjzR0G7jnuk6CYiK7YEbm	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N
4	$2b$10$Sy8KVDMEkcOLT7q2qCpwqeEY7AAu/ZEwppv3Qq.GX64f.BNqktJtO	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N
5	$2b$10$j.SKkEm5WdUIa3ZbiOi7NusXoy1iU.iXTqKzzzMCgcorUY.ZoPHY6	Laura	Zurru	5	laura@emergency.it	\N	t	\N
1	$2b$10$YVAjvFGgbuLftIcH3V2jIeKBj1aCXSCYfIgg0bCrx/PF3QkaQ4C7q	German	Gorodnev	0	german@hiker.it	\N	t	\N
3	$2b$10$m6zoRs9i4vmfLGxCD5fSvuVBFQdxqoaNIFL/vmo9kqHpXfad5MbFy	vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 370, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 1, false);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 1, false);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: hike_points PK_7fc686c35c52228d8494a7c4947; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_7fc686c35c52228d8494a7c4947" PRIMARY KEY ("hikeId", "pointId");


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

