--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: insert_hike(integer, character varying, integer, character varying, character varying, character varying, character varying, character varying, numeric, numeric, integer, character varying, jsonb, jsonb, jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hike(user_id integer, title character varying, difficulty integer, gpx_path character varying, country character varying, region character varying, province character varying, city character varying, length numeric, ascent numeric, expected_time integer, description character varying, pictures jsonb, start_point jsonb, end_point jsonb, reference_points jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $$;


--
-- Name: insert_hut(integer, double precision, double precision, integer, numeric, character varying, character varying, character varying, character varying, numeric, time without time zone, time without time zone, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut(user_id integer, lat double precision, lon double precision, number_of_beds integer, price numeric, title character varying, address character varying, owner_name character varying, website character varying, elevation numeric, working_time_start time without time zone, working_time_end time without time zone, email character varying, phone_number character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number
    );
    END
    $$;


--
-- Name: insert_parking_lot(integer, double precision, double precision, character varying, integer, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_parking_lot(user_id integer, lat double precision, lon double precision, name character varying, max_cars integer, address character varying, city character varying, country character varying, region character varying, province character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: code-hike; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."code-hike" (code, "userHikeId") FROM stdin;
\.


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
1	1	0	5
1	2	100000	6
1	3	1	3
1	4	2	3
2	5	0	5
2	6	100000	6
3	7	0	5
3	8	100000	6
3	9	1	3
3	10	2	3
4	11	0	5
4	12	100000	6
4	13	1	3
4	14	2	3
5	15	0	5
5	16	100000	6
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country, condition, cause, pictures, "weatherStatus", "weatherDescription") FROM stdin;
1	2	1.20	80	7.70	2	Amprimo	Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.	/static/gpx/Amprimo.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/3.jpg"]	0	
2	2	8.00	200	28.40	1	Anello Chateau Beaulard - Cotolivier - Vazon	Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.	/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx	0.00	Piemonte	Torino	Beaulard	Italia	0		["/static/images/2.jpg"]	0	
3	2	8.00	210	17.40	2	Lago Bianco	Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.\n\nLa diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.\n\nLa Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.\n\nSi può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.	/static/gpx/Lago Bianco.gpx	0.00	Auvergne-Rhone-Alpes	Savoia	Val-Cenis	Francia	0		["/static/images/1.jpg"]	0	
4	2	1.30	200	17.40	2	Alte Langhe Settentrionali - Cossano Belbo	Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.\nSi svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.\nSi imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.\nInizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.\nPercorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. \nSeguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. \nSi procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante	/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx	0.00	Piemonte	Cuneo	Cossano Belbo	Italia	0		["/static/images/4.jpg"]	0	
5	2	16.50	225	9.90	2	La pieve romanica di Piesenzana e la valle delle tartufaie	Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. \nCirca 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. \nIn regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. \nA Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). \nContemporaneamente i ristoranti della zona propongono piatti a base di tartufi	/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx	0.00	Piemonte	Asti	Montechiaro d'Asti	Italia	0		["/static/images/5.jpg"]	0	
\.


--
-- Data for Name: hut-worker; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."hut-worker" ("userId", "hutId") FROM stdin;
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website, elevation, pictures, description, "workingTimeStart", "workingTimeEnd", "phoneNumber", email) FROM stdin;
1	17	8	64.00	Edmund-Graf-Hütte	2	Diego Lana	http://acrobatic-rate.org	279.16	[]		05:00:00	12:00:00	+396706422381	Peleo_Zanon94@libero.it
2	18	10	109.00	Dr.Hernaus-Stöckl	2	Olimpia Caterino	http://loyal-tintype.it	331.53	[]		08:00:00	16:00:00	+395357659733	Astrid82@hotmail.com
3	19	7	45.00	Amstettner Hütte	2	Olindo Mercurio	http://square-bump.org	307.70	[]		07:00:00	18:00:00	+395517710359	Elvia9@hotmail.com
4	20	2	137.00	Hochleckenhaus	2	Annagrazia Zollo	http://revolving-river.it	297.71	[]		08:00:00	15:00:00	+398448275156	Serafino.DiMichele@yahoo.it
5	21	7	129.00	Kampthalerhütte	2	Telica Signorini	http://near-paragraph.org	324.92	[]		07:00:00	20:00:00	+391152596788	Domenica28@yahoo.it
6	22	3	56.00	Lambacher Hütte	2	Ing. Odetta Argenio	https://victorious-heartache.net	274.33	[]		04:00:00	10:00:00	+397320968042	Esa_Soldati@yahoo.it
7	23	4	74.00	Lustenauer Hütte	2	Dr. Cantidio Olla	https://palatable-intentionality.com	260.05	[]		06:00:00	12:00:00	+393183169577	Gillo65@email.it
8	24	5	36.00	Gablonzer Hütte	2	Achille Cenni	https://spherical-genie.it	319.30	[]		01:00:00	18:00:00	+391572891880	Ivone_Miceli@yahoo.com
9	25	3	79.00	Katafygio «Flampouri»	2	Ing. Surano Repetto	http://stingy-standing.org	315.41	[]		02:00:00	13:00:00	+396114084256	Muziano51@libero.it
10	26	1	105.00	Simonyhütte	2	Sostrato Berti	https://definite-likelihood.org	267.97	[]		01:00:00	16:00:00	+396196552666	Aurelia_Mariani16@gmail.com
11	27	10	71.00	Vinzenz-Tollinger-Hütte	2	Colomba Pellegrino	https://illegal-departure.it	305.44	[]		02:00:00	17:00:00	+394073393483	Colmazio_Sepe@yahoo.it
12	28	8	85.00	Ottokar-Kernstock-Haus	2	Viliana Senatore	http://sour-gelatin.net	328.10	[]		07:00:00	19:00:00	+394189024194	Zenobia_Biagi@email.it
13	29	9	99.00	Reisseckhütte	2	Mirella Miotto	https://lone-liner.it	281.84	[]		01:00:00	12:00:00	+396315156184	Albano.Canova@libero.it
14	30	3	92.00	Vernagthütte	2	Acacio Farina	http://first-number.it	339.15	[]		07:00:00	19:00:00	+398086596421	Orazio_Sacco@yahoo.com
15	31	7	81.00	Wormser Hütte	2	Bibiana Leggio	http://scented-admin.it	324.22	[]		03:00:00	21:00:00	+399155604256	Erasmo_Tortorici@gmail.com
16	32	2	137.00	Biberacher Hütte	2	Sig. Melezio Biagi	https://carefree-nick.net	286.73	[]		01:00:00	14:00:00	+396926803134	Silvio.Falbo@hotmail.com
17	33	3	124.00	Katafygio «1777»	2	Aldobrando Guastone	http://disastrous-vacuum.it	330.24	[]		05:00:00	11:00:00	+398351759180	Pollione_Procopio1@yahoo.it
18	34	9	140.00	Hochwaldhütte	2	Berardo Manetti	http://sane-litmus.com	281.80	[]		07:00:00	14:00:00	+398028393299	Brigitta.Carboni@yahoo.it
19	35	1	89.00	Kölner Eifelhütte	2	Dr. Minervina Carbone	http://truthful-lesbian.com	313.89	[]		04:00:00	19:00:00	+390199041666	Socrate33@yahoo.it
20	36	5	83.00	Madrisahütte	2	Cino Romeo	https://playful-mussel.it	326.94	[]		07:00:00	16:00:00	+392968216390	Abbondio_Biancheri@yahoo.com
21	37	3	114.00	Dresdner Hütte	2	Loriana Albanese	http://wilted-clover.com	323.81	[]		04:00:00	10:00:00	+394955858711	Speranza16@libero.it
22	38	3	54.00	Fiderepasshütte	2	Dr. Guendalina Rigoni	https://infatuated-timber.net	305.08	[]		03:00:00	20:00:00	+395207035595	Edvige82@gmail.com
23	39	4	37.00	Göppinger Hütte	2	Liberio Crisafulli	https://dismal-sac.com	261.88	[]		01:00:00	10:00:00	+391626212867	Bianca4@yahoo.com
24	40	3	120.00	Oberzalimhütte	2	Abbondanzio Caccamo	http://virtual-necklace.net	312.01	[]		08:00:00	22:00:00	+390716824054	Celinia.Bonanno@gmail.com
25	41	3	87.00	Rastkogelhütte	2	Rutilo Malatesta	https://upright-diver.net	314.09	[]		02:00:00	16:00:00	+395541693038	Roberta_Messana@email.it
26	42	10	87.00	Ansbacher Skihütte im Allgäu	2	Guenda Marras	http://fatal-badge.net	300.45	[]		03:00:00	22:00:00	+395907724543	Gianluigi.DiMatteo@yahoo.it
27	43	6	55.00	Kaltenberghütte	2	Mariano Morra	https://inconsequential-goodness.com	337.94	[]		08:00:00	23:00:00	+393124947992	Selene.Manzi@yahoo.it
28	44	4	150.00	Schweinfurter Hütte	2	Valerio Santilli	https://authorized-cod.org	272.17	[]		01:00:00	12:00:00	+398944131422	Ezechiele.Luise93@hotmail.com
29	45	8	65.00	Katafygio «Vardousion»	2	Telica Mulas	https://competent-pomelo.it	309.83	[]		08:00:00	22:00:00	+394096787440	Erberto_Comito@email.it
30	46	9	112.00	Kocbekov dom na Korošici	2	Verena Panetta	https://prize-step-aunt.it	317.47	[]		09:00:00	18:00:00	+396678287545	Atanasia_Biondi8@libero.it
31	47	9	87.00	Planinski dom Rašiške cete na Rašici	2	Rosanna Bergamini	http://tinted-clerk.org	264.72	[]		01:00:00	11:00:00	+392660983061	Agapito_DAlessio@yahoo.com
32	48	4	38.00	Prešernova koca na Stolu	2	Dott. Alcina Giardini	https://well-made-handicap.com	326.36	[]		09:00:00	22:00:00	+396133919335	Martina_Lotito28@email.it
33	49	5	45.00	Planinski dom na Mrzlici	2	Amanzio Lo Presti	https://hilarious-grandmother.org	327.72	[]		01:00:00	19:00:00	+396507344074	Rosanna_Carboni@hotmail.com
34	50	10	61.00	Koca na Planini nad Vrhniko	2	Rolando Salvadori	https://splendid-ocean.net	309.58	[]		07:00:00	19:00:00	+394850267875	Enrico.Raffa@yahoo.com
35	51	9	50.00	Zavetišce gorske straže na Jelencih	2	Gallicano Biggi	https://soupy-ex-wife.net	301.56	[]		08:00:00	14:00:00	+396870955315	Secondo56@yahoo.com
36	52	2	92.00	Planinski dom na Gori	2	Azzurra De Angelis	https://which-collapse.it	276.90	[]		05:00:00	18:00:00	+394602576108	Federica.Manno63@gmail.com
37	53	8	145.00	Bregarjevo zavetišce na planini Viševnik	2	Nives Ambrosino	http://great-lieu.com	336.28	[]		03:00:00	21:00:00	+393609185022	Aladino16@yahoo.it
38	54	7	72.00	Koca pod Bogatinom	2	Pupolo Giacalone	http://spicy-vanity.it	332.61	[]		01:00:00	16:00:00	+397702981526	Regolo2@yahoo.com
39	55	9	130.00	Pogacnikov dom na Kriških podih	2	Cloe Napoletano	http://definite-yoke.org	317.28	[]		02:00:00	16:00:00	+394153809289	Alceste.Solinas77@gmail.com
40	56	6	107.00	Dom na Smrekovcu	2	Igino Recchia	https://torn-doe.net	273.94	[]		03:00:00	10:00:00	+395199395252	Tabita33@gmail.com
41	57	4	137.00	Refuge Du Chatelleret	2	Cosma Corti	http://slim-notice.net	322.86	[]		07:00:00	17:00:00	+393512968890	Donata.Micillo97@email.it
42	58	4	55.00	Refuge De Chalance	2	Alma Buonomo	https://primary-shaw.org	261.25	[]		05:00:00	20:00:00	+396186150482	Loreno_Pecoraro84@libero.it
43	59	10	84.00	Refuge Des Bans	2	Bibiana Contu	http://key-biscuit.it	260.91	[]		01:00:00	07:00:00	+399437870906	Simonetta_Militello77@gmail.com
44	60	8	142.00	Refuge De Pombie	2	Eliodoro Aiello	https://authorized-mist.com	283.21	[]		02:00:00	21:00:00	+394290542416	Isabella_Cecchi@gmail.com
45	61	10	102.00	Refuge De Larribet	2	Sig. Deodato Bertaccini	http://fragrant-crowd.org	273.19	[]		05:00:00	14:00:00	+396832119432	Fedro70@libero.it
46	62	4	74.00	Refuge Du Mont Pourri	2	Giorgia Sorrentino	http://same-profile.net	291.60	[]		06:00:00	15:00:00	+390909356692	Grato.Giovannelli7@gmail.com
47	63	10	120.00	Refuge De La Dent D?Oche	2	Publio Medici	http://quintessential-champagne.it	280.88	[]		03:00:00	14:00:00	+394401001227	Liborio.Marian@libero.it
48	64	1	74.00	Bergseehütte SAC	2	Zaccaria Bisconti	http://insistent-grey.com	331.31	[]		06:00:00	21:00:00	+394369924357	Emmerico_Brignone95@hotmail.com
49	65	4	53.00	Bivouac au Col de la Dent Blanche CAS	2	Gigliola Di Mauro	https://thirsty-sensitivity.org	304.13	[]		06:00:00	19:00:00	+399666169296	Tancredi39@libero.it
50	66	1	56.00	Salbitschijenbiwak SAC	2	Plinio Pacifico	https://fair-blessing.org	320.80	[]		08:00:00	22:00:00	+394317741274	Serafina43@yahoo.it
51	67	2	82.00	Spannorthütte SAC	2	Maddalena Sannino	https://grimy-management.com	295.70	[]		05:00:00	22:00:00	+399871867126	Ornella_Scardino90@libero.it
52	68	10	133.00	Cabane Arpitettaz CAS	2	Lea Monaci	https://colossal-financing.org	310.71	[]		01:00:00	16:00:00	+395261305712	Camelia.Macchi@yahoo.it
53	69	8	127.00	Refugio De Lizara	2	Luigi Ferrari	https://soggy-lark.org	319.77	[]		05:00:00	20:00:00	+399466476181	Cherubino5@gmail.com
54	70	10	118.00	Albergue De Montfalcó	2	Igor Kofler	https://sorrowful-square.com	329.63	[]		08:00:00	18:00:00	+394953096935	Antioco44@libero.it
55	71	9	149.00	El Molonillo/Peña Partida	2	Dr. Massima Donato	https://tubby-shin.com	271.46	[]		07:00:00	16:00:00	+395465870873	Moira12@yahoo.com
56	72	2	56.00	La Campiñuela	2	Marco Rosset	https://distinct-lunch.com	291.62	[]		09:00:00	15:00:00	+393602790172	Filippo_Caiazza64@yahoo.it
57	73	7	68.00	Titov Vrv	2	Michela Fusco	http://miserable-comfort.org	306.97	[]		09:00:00	16:00:00	+394874616212	Nestore94@hotmail.com
58	74	9	63.00	Rifugio Franchetti	2	Dr. Bruto De Lorenzo	http://upbeat-niche.com	266.10	[]		09:00:00	23:00:00	+397209467557	Oscar.Cosentino@gmail.com
59	75	6	60.00	Rifugio Semenza	2	Catena Padula	https://oblong-king.org	267.51	[]		05:00:00	16:00:00	+396151620958	Vittore96@email.it
60	76	4	61.00	Rifugio Città di Mortara 	2	Dr. Valente Gangemi	http://rundown-tenant.org	261.74	[]		03:00:00	23:00:00	+396143867627	Ursicio_Traini@libero.it
61	77	10	108.00	Rifugio Andolla	2	Ubaldo Micheletti	http://yearly-hydraulics.com	294.05	[]		03:00:00	13:00:00	+398952211722	Evidio80@yahoo.com
62	78	4	71.00	Rifugio Forte dei Marmi	2	Sig. Angela Laezza	https://impassioned-speedboat.org	290.65	[]		08:00:00	21:00:00	+390927094554	Tesifonte_DeCicco46@yahoo.it
63	79	6	71.00	Rifugio Berti	2	Giobbe Nucci	http://offensive-fiberglass.org	320.67	[]		05:00:00	21:00:00	+391604466841	Gandolfo74@yahoo.it
64	80	5	142.00	Rifugio Premuda	2	Valente Damiani	https://illustrious-critic.it	270.95	[]		04:00:00	21:00:00	+391446722568	Fiorenzo90@yahoo.com
65	81	3	60.00	Rifugio Elisa	2	Gemma Agresta	http://profitable-interconnection.it	269.54	[]		03:00:00	23:00:00	+399735196178	Mafalda.Vianello35@yahoo.it
66	82	1	99.00	Rifugio CAI Saronno	2	Sabazio Ciavarella	http://scarce-vinyl.it	267.70	[]		05:00:00	19:00:00	+398555862882	Greta.Mori0@yahoo.com
67	83	8	57.00	Rifugio Picco Ivigna	2	Antonella Moretti	https://dirty-patience.net	268.33	[]		04:00:00	10:00:00	+393086835173	Tarquinia63@yahoo.it
68	84	7	79.00	Rifugio Toesca	2	Gioacchina Lucarini	http://functional-casserole.com	272.39	[]		05:00:00	17:00:00	+390813493558	Sofia.Brunetti@email.it
69	85	4	95.00	Rifugio Al Cedo	2	Dr. Melissa Granato	http://kindly-planet.org	338.79	[]		03:00:00	18:00:00	+398384362478	Settimo86@libero.it
70	86	2	42.00	Capanna Gnifetti	2	Dr. Bindo Visconti	http://buttery-cheque.com	328.28	[]		05:00:00	20:00:00	+395490091257	Enimia.LaMonica19@yahoo.com
71	87	7	124.00	Rifugio Aosta	2	Dott. Venerando Sodano	https://dry-relief.com	305.70	[]		01:00:00	14:00:00	+393113530782	Priscilla.Palombi@hotmail.com
72	88	9	53.00	Rifugio Cevedale	2	Prudenzia Parrino	http://open-blind.it	317.00	[]		03:00:00	23:00:00	+395752936355	Ulrico_Raimondi@libero.it
73	89	8	83.00	Rifugio Ponti	2	Macaria Martino	https://amusing-affiliate.com	261.20	[]		01:00:00	09:00:00	+390959427633	Bibiano.Nesti39@yahoo.it
74	90	5	53.00	Rifugio XII Apostoli	2	Primo Di Pasquale	http://pure-care.org	311.96	[]		09:00:00	23:00:00	+395879620039	Nazzaro.DiFranco@yahoo.com
75	91	2	129.00	Rifugio Elisabetta Soldini	2	Priamo Di Giuseppe	http://far-off-hobby.it	262.83	[]		03:00:00	11:00:00	+395502663311	Adalfredo.Schillaci@gmail.com
76	92	6	43.00	Rifugio Denza	2	Marita Tomaselli	http://concerned-blackbird.com	321.70	[]		06:00:00	16:00:00	+392529538804	Siricio12@yahoo.it
77	93	6	51.00	Rifugio Fonte Tavoloni 	2	Zanita Cruciata	http://even-phenotype.com	316.34	[]		05:00:00	19:00:00	+394547353549	Eustorgio.Pession@email.it
78	94	4	58.00	Rifugio Carducci	2	Mario Galluzzo	http://burdensome-cabana.com	269.67	[]		07:00:00	20:00:00	+390663124290	Regolo_Ramella61@libero.it
79	95	4	78.00	Rifugio Bindesi	2	Guendalina Tralli	http://jubilant-output.net	300.55	[]		02:00:00	18:00:00	+399579042320	Eligio_Cardini@libero.it
80	96	10	64.00	Mountain hut Miroslav Hirtz	2	Amelia Campanella	https://svelte-pineapple.it	335.21	[]		02:00:00	19:00:00	+398306154616	Reginaldo44@hotmail.com
81	97	7	109.00	Koca na Blegošu	2	Lorella Bartolucci	http://low-shorts.it	279.11	[]		04:00:00	17:00:00	+392023504667	Viscardo33@gmail.com
82	98	3	130.00	Wittener Hütte	2	Gionata D'Argenio	http://easy-signup.com	288.19	[]		03:00:00	10:00:00	+396412493309	Rosmunda36@yahoo.it
83	99	3	45.00	Hochjoch-Hospiz	2	Elda Perri	https://handy-search.net	320.42	[]		07:00:00	18:00:00	+395009026296	Geminiano.Porcari51@hotmail.com
84	100	5	56.00	Meilerhütte	2	Senofonte Fiorini	http://long-dynamite.it	305.84	[]		03:00:00	16:00:00	+391779602805	Ciriaco57@gmail.com
85	101	6	128.00	Gaudeamushütte	2	Donatella Liotta	http://outlying-ring.org	278.55	[]		05:00:00	22:00:00	+393301767454	Marino25@email.it
86	102	5	69.00	Rheydter Hütte	2	Liborio Valsecchi	https://grandiose-adviser.com	308.45	[]		08:00:00	17:00:00	+399555444071	Narseo.Rambaldi@gmail.com
87	103	5	134.00	Sektionshütte Krippen	2	Taddeo Pagliuca	https://playful-fountain.it	287.48	[]		04:00:00	20:00:00	+390391460446	Bonifacio_Bove10@hotmail.com
88	104	3	46.00	Neunkirchner Hütte	2	Benvenuto Liccardo	https://empty-gain.net	329.89	[]		06:00:00	14:00:00	+395367669003	Remondo.Perrotta@yahoo.it
89	105	8	93.00	Refugio De Riglos	2	Antero Colombo	https://powerless-gear.com	268.45	[]		03:00:00	15:00:00	+393679949269	Agesilao.Pandolfi25@libero.it
90	106	5	65.00	Salbithütte SAC	2	Polissena Tassone	http://infantile-lack.org	283.61	[]		09:00:00	21:00:00	+391269127711	Evidio_Santarelli@email.it
91	107	2	127.00	Finsteraarhornhütte SAC	2	Donna Mangione	http://another-sorrel.org	261.41	[]		08:00:00	20:00:00	+393031012630	Eliano66@email.it
92	108	3	112.00	Cabane des Vignettes CAS	2	Uriele Mazzocchi	http://accurate-fulfillment.com	275.28	[]		05:00:00	12:00:00	+392081485002	Eva55@libero.it
93	109	3	125.00	Glecksteinhütte SAC	2	Porziano Carletti	http://thick-juice.org	287.98	[]		03:00:00	22:00:00	+391603648413	No.Bressan41@gmail.com
94	110	1	47.00	Länta-Hütte SAC	2	Valeria Paganelli	https://lone-shift.net	286.91	[]		02:00:00	13:00:00	+392786355672	Ianira.Piccolo@libero.it
95	111	2	101.00	Monte-Leone-Hütte SAC	2	Gabriele Minelli	https://famous-magazine.com	289.16	[]		09:00:00	16:00:00	+391769922619	Clemenzia.Falcioni87@hotmail.com
96	112	5	75.00	Ringelspitzhütte SAC	2	Antonia Miglio	http://solid-climb.org	308.78	[]		06:00:00	12:00:00	+391786356557	Cantidio13@yahoo.com
97	113	4	143.00	Na poljanama Maljen	2	Teresa Ferracuti	https://ordinary-linen.com	289.99	[]		08:00:00	21:00:00	+392466521092	Vincenzo_Renzi@email.it
98	114	9	44.00	Dobra voda	2	Ludovica Quinto	https://profitable-neighbour.org	317.34	[]		04:00:00	22:00:00	+392119410746	Catullo_Mascolo@yahoo.com
99	115	1	122.00	Ivanova hiža	2	Marzia Gaudiano	https://false-suck.com	333.88	[]		06:00:00	18:00:00	+396371208124	Vilfredo40@yahoo.com
100	116	7	113.00	Glavica	2	Antonella Cesaretti	http://flowery-tenor.com	302.00	[]		01:00:00	16:00:00	+390131173477	Narciso_Baldo@hotmail.com
101	117	6	70.00	Trpošnjik	2	Ulfa Ramella	http://sleepy-enigma.org	290.35	[]		07:00:00	22:00:00	+394213280518	Aladino76@libero.it
102	118	1	82.00	Bitorajka	2	Elisabetta Carella	http://wonderful-centurion.com	298.14	[]		07:00:00	16:00:00	+395629882897	Alessandro_DiDonato89@libero.it
103	119	4	70.00	Zlatko Prgin	2	Pollione Papapietro	http://regal-silence.net	290.25	[]		05:00:00	14:00:00	+397373834090	Arcibaldo70@hotmail.com
104	120	5	38.00	Prpa	2	Olimpia Borgia	https://busy-wrist.org	279.15	[]		04:00:00	15:00:00	+395987766692	Averardo.Aprile47@libero.it
105	121	3	113.00	Ždrilo	2	Massimo Trombetta	http://proud-noise.com	294.87	[]		05:00:00	17:00:00	+396156890017	Altea.Stella32@yahoo.it
106	122	7	130.00	Miroslav Hirtz	2	Carla Toscano	https://utilized-pillar.org	260.56	[]		09:00:00	22:00:00	+391394568788	Amauri72@email.it
107	123	9	69.00	Jezerce	2	Raimondo Cerutti	http://open-pathway.net	335.57	[]		04:00:00	18:00:00	+397005973605	Settimo.Talarico50@gmail.com
108	124	2	106.00	Ivica Sudnik	2	Desiderata Baldacci	http://serious-accordance.net	301.14	[]		01:00:00	13:00:00	+392799267394	Uberto_Ancona42@hotmail.com
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
1	125	72	2	Italy	L'Aquila		Sesto Abibo laziale
2	126	55	2	Italy	Frosinone		Giuliana sardo
3	127	37	2	Italy	Rieti		Sesto Remo umbro
4	128	211	2	Italy	Padova		Borgo Doriano
5	129	161	2	Italy	Biella		Quarto Efrem
6	130	216	2	Italy	Treviso		Basilia nell'emilia
7	131	257	2	Italy	Caltanissetta		Settimo Ataleo
8	132	98	2	Italy	Cremona		Borgo Samuele ligure
9	133	236	2	Italy	Avellino		Cleo sardo
10	134	64	2	Italy	Matera		Selene lido
11	135	293	2	Italy	Napoli		Settimo Amadeo ligure
12	136	117	2	Italy	Bergamo		Rubino sardo
13	137	87	2	Italy	Enna		Quarto Terenzio veneto
14	138	243	2	Italy	Prato		Vichi lido
15	139	259	2	Italy	Genova		Ferrero lido
16	140	287	2	Italy	Agrigento		Borgo Natale
17	141	102	2	Italy	Gorizia		Sesto Giulio
18	142	44	2	Italy	Cagliari		Settimo Gaudenzia sardo
19	143	253	2	Italy	Pavia		Bacci a mare
20	144	90	2	Italy	Teramo		Demostene calabro
21	145	31	2	Italy	Catanzaro		Demontis del friuli
22	146	202	2	Italy	Ascoli Piceno		Artemisa umbro
23	147	6	2	Italy	Siena		San Onesta
24	148	70	2	Italy	Reggio Emilia		Settimo Teodoro
25	149	289	2	Italy	Caltanissetta		Settimo Magno
26	150	184	2	Italy	Varese		Fleano calabro
27	151	47	2	Italy	Olbia-Tempio		Sesto Cuniberto
28	152	184	2	Italy	Ravenna		Ruggero lido
29	153	51	2	Italy	Olbia-Tempio		Borgo Ausilia
30	154	298	2	Italy	Bergamo		Gregori a mare
31	155	76	2	Italy	Pistoia		Colantuono salentino
32	156	126	2	Italy	Verona		Borgo Ionne
33	157	277	2	Italy	Carbonia-Iglesias		Accardi lido
34	158	5	2	Italy	Latina		Troisi veneto
35	159	284	2	Italy	Trapani		Settimo Acrisio
36	160	63	2	Italy	Gorizia		Lazzari lido
37	161	212	2	Italy	Torino		Quarto Sapiente nell'emilia
38	162	257	2	Italy	Napoli		Gaudenzio sardo
39	163	288	2	Italy	Livorno		Isidoro sardo
40	164	28	2	Italy	Rimini		Giacalone veneto
41	165	20	2	Italy	Ferrara		Borgo Uriele nell'emilia
42	166	179	2	Italy	Nuoro		Quarto Cassandra veneto
43	167	291	2	Italy	Pesaro e Urbino		Quarto Norberto
44	168	162	2	Italy	Cosenza		Gatto calabro
45	169	85	2	Italy	Siena		Quarto Urdino
46	170	201	2	Italy	Isernia		Quarto Adelasia
47	171	295	2	Italy	Teramo		Salemi a mare
48	172	55	2	Italy	Messina		Ferrando ligure
49	173	149	2	Italy	Rieti		Sesto Reginaldo
50	174	279	2	Italy	Lecco		Borgo Agabio
51	175	209	2	Italy	Macerata		De Lorenzo umbro
52	176	11	2	Italy	Pordenone		Quarto Tristano
53	177	180	2	Italy	Matera		Calogero veneto
54	178	8	2	Italy	Taranto		Riccardo calabro
55	179	135	2	Italy	Trento		San Ilia
56	180	185	2	Italy	Siena		Quarto Bertoldo umbro
57	181	178	2	Italy	Napoli		San Rino salentino
58	182	101	2	Italy	Vercelli		Borgo Ezio
59	183	138	2	Italy	Lecco		Sesto Corrado calabro
60	184	133	2	Italy	Taranto		Quarto Canziano
61	185	274	2	Italy	Sondrio		San Lorenzo ligure
62	186	236	2	Italy	Cosenza		Bentivoglio laziale
63	187	187	2	Italy	Catania		Quarto Lucrezia
64	188	242	2	Italy	Venezia		Settimo Roberta sardo
65	189	183	2	Italy	Pescara		Sesto Aleandro laziale
66	190	49	2	Italy	Como		Borgo Vincenzo
67	191	193	2	Italy	Carbonia-Iglesias		San Ido
68	192	180	2	Italy	Cuneo		Quarto Elpidio nell'emilia
69	193	76	2	Italy	Cuneo		Godeberta salentino
70	194	15	2	Italy	Lodi		Giglio ligure
71	195	268	2	Italy	Palermo		Di Bella lido
72	196	236	2	Italy	Rovigo		Lelli laziale
73	197	230	2	Italy	Savona		Martelli laziale
74	198	290	2	Italy	Barletta-Andria-Trani		Luchetti sardo
75	199	290	2	Italy	Lodi		San Desiderata
76	200	263	2	Italy	Caltanissetta		Clodomiro nell'emilia
77	201	81	2	Italy	Como		Ulisse umbro
78	202	154	2	Italy	Trieste		San Apollo
79	203	115	2	Italy	Brindisi		Quarto Abele
80	204	95	2	Italy	Isernia		Sesto Paterniano
81	205	161	2	Italy	Trieste		Romana ligure
82	206	239	2	Italy	L'Aquila		Settimo Ivan
83	207	175	2	Italy	Grosseto		Costantin a mare
84	208	162	2	Italy	Reggio Calabria		Eliana veneto
85	209	236	2	Italy	Isernia		Gherardo umbro
86	210	186	2	Italy	La Spezia		Tabita laziale
87	211	170	2	Italy	Forlì-Cesena		Fioravanti umbro
88	212	192	2	Italy	Avellino		Di Tommaso calabro
89	213	215	2	Italy	Imperia		Sesto Paciano
90	214	225	2	Italy	Siena		Bindi terme
91	215	237	2	Italy	Siracusa		Borgo Giovanni
92	216	251	2	Italy	Olbia-Tempio		Guido nell'emilia
93	217	142	2	Italy	Genova		Licia nell'emilia
94	218	204	2	Italy	Teramo		Sesto Urbano nell'emilia
95	219	73	2	Italy	Brindisi		Palmisani nell'emilia
96	220	233	2	Italy	Barletta-Andria-Trani		San Lorena
97	221	112	2	Italy	Oristano		Taziano laziale
98	222	135	2	Italy	Carbonia-Iglesias		Vivaldo a mare
99	223	151	2	Italy	Trento		Sesto Tulliano
100	224	70	2	Italy	Isernia		Settimo Urbano
101	225	121	2	Italy	Lecce		Roma
102	226	130	2	Italy	Cagliari		Ricciardi nell'emilia
103	227	127	2	Italy	Foggia		Rapisarda umbro
104	228	291	2	Italy	Latina		Nerea terme
105	229	279	2	Italy	Sassari		Tarso veneto
106	230	57	2	Italy	Alessandria		Sanfilippo salentino
107	231	291	2	Italy	Ogliastra		Settimo Apollinare terme
108	232	154	2	Italy	Fermo		San Decimo
109	233	100	2	Italy	Siena		Bresciani salentino
110	234	93	2	Italy	Enna		Cerri laziale
111	235	109	2	Italy	Cosenza		Borgo Raffaele umbro
112	236	299	2	Italy	Foggia		Quarto Arduino
113	237	42	2	Italy	Venezia		Borgo Abelardo a mare
114	238	110	2	Italy	Mantova		Borgo Verulo
115	239	292	2	Italy	Teramo		Settimo Demostene salentino
116	240	80	2	Italy	Monza e della Brianza		Settimo Selvaggia
117	241	64	2	Italy	Brescia		Borgo Lodovica
118	242	126	2	Italy	Carbonia-Iglesias		Giacinto calabro
119	243	258	2	Italy	Ancona		San Zama
120	244	163	2	Italy	Brescia		Quarto Calogera
121	245	148	2	Italy	Foggia		Sesto Gennaro lido
122	246	275	2	Italy	Brindisi		San Giovanni salentino
123	247	84	2	Italy	Carbonia-Iglesias		Eginardo terme
124	248	81	2	Italy	Reggio Calabria		Cuzzocrea del friuli
125	249	289	2	Italy	Cagliari		Sesto Alma
126	250	224	2	Italy	Avellino		Siri ligure
127	251	1	2	Italy	Bolzano		Pecorella ligure
128	252	119	2	Italy	Nuoro		Quarto Pierangelo
129	253	278	2	Italy	Enna		Settimo Gaetano terme
130	254	1	2	Italy	Belluno		San Gherardo
131	255	1	2	Italy	Caserta		Gianfranco sardo
132	256	254	2	Italy	Como		Amato laziale
133	257	34	2	Italy	Perugia		Placido laziale
134	258	58	2	Italy	Medio Campidano		San Folco del friuli
135	259	286	2	Italy	Monza e della Brianza		Rosset terme
136	260	172	2	Italy	Chieti		Quarto Enrico
137	261	1	2	Italy	Venezia		Quarto Gaglioffo
138	262	1	2	Italy	Livorno		Salvatore umbro
139	263	161	2	Italy	Taranto		Deodata calabro
140	264	1	2	Italy	Caltanissetta		De Bonis del friuli
141	265	128	2	Italy	Grosseto		Petronilla sardo
142	266	257	2	Italy	Vicenza		Borgo Elogio umbro
143	267	89	2	Italy	Padova		Settimo Eustorgio
144	268	279	2	Italy	Asti		Di Bella salentino
145	269	300	2	Italy	Piacenza		Raffaele salentino
146	270	261	2	Italy	Potenza		Frau umbro
147	271	295	2	Italy	Prato		Ciccarelli ligure
148	272	278	2	Italy	Alessandria		Bernabei sardo
149	273	200	2	Italy	Ragusa		Sesto Abele
150	274	181	2	Italy	Nuoro		Mautone laziale
151	275	144	2	Italy	Siracusa		Borgo Adamo calabro
152	276	66	2	Italy	Alessandria		Adele umbro
153	277	136	2	Italy	Chieti		Saturniano veneto
154	278	135	2	Italy	Novara		Camilli ligure
155	279	123	2	Italy	Perugia		Settimo Palmira
156	280	193	2	Italy	Isernia		Valentino terme
157	281	289	2	Italy	Massa-Carrara		Borgo Egeo terme
158	282	128	2	Italy	Parma		Luongo del friuli
159	283	211	2	Italy	Barletta-Andria-Trani		Bianco salentino
160	284	214	2	Italy	Imperia		San Amaranto
161	285	249	2	Italy	Siracusa		Cruciata terme
162	286	77	2	Italy	Ragusa		Amabile ligure
163	287	162	2	Italy	Genova		Settimo Bassilla
164	288	118	2	Italy	Ragusa		Bonazzi sardo
165	289	188	2	Italy	Arezzo		Sesto Ignazio del friuli
166	290	30	2	Italy	Padova		Borgo Aronne
167	291	74	2	Italy	Varese		Di Michele del friuli
168	292	233	2	Italy	Lecco		Graziano calabro
169	293	246	2	Italy	Potenza		D'Anna del friuli
170	294	130	2	Italy	Vibo Valentia		Settimo Sinesio terme
171	295	284	2	Italy	Frosinone		Di Marino sardo
172	296	278	2	Italy	Pistoia		Francesco del friuli
173	297	96	2	Italy	Enna		Quarto Verecondo
174	298	144	2	Italy	Reggio Emilia		Lo Giudice sardo
175	299	114	2	Italy	Teramo		Quarto Veneranda
176	300	133	2	Italy	Pescara		Fabbro terme
177	301	174	2	Italy	Firenze		Quarto Aristofane calabro
178	302	234	2	Italy	Ferrara		Borgo Carla calabro
179	303	74	2	Italy	Monza e della Brianza		Borgo Gottardo
180	304	185	2	Italy	Caserta		Michela laziale
181	305	25	2	Italy	Belluno		Ermelinda a mare
182	306	157	2	Italy	Bologna		Franzè laziale
183	307	6	2	Italy	Novara		Quarto Altea nell'emilia
184	308	67	2	Italy	Chieti		Lendinara
185	309	242	2	Italy	Udine		San Mauro
186	310	237	2	Italy	Ancona		Napoli
187	311	115	2	Italy	Verona		Settimo Delfina
188	312	214	2	Italy	Vercelli		Quarto Nicodemo laziale
189	313	45	2	Italy	Teramo		Leonida del friuli
190	314	209	2	Italy	Pavia		Quarto Fiammetta
191	315	232	2	Italy	Bergamo		Sesto Carmela
192	316	124	2	Italy	Brindisi		Sesto Dacio salentino
193	317	289	2	Italy	Siracusa		Rosanna calabro
194	318	79	2	Italy	Nuoro		Borgo Ranolfo salentino
195	319	125	2	Italy	Livorno		Quarto Franco laziale
196	320	227	2	Italy	Lodi		Volpi a mare
197	321	227	2	Italy	Forlì-Cesena		Fucci lido
198	322	217	2	Italy	Gorizia		Ippolito nell'emilia
199	323	146	2	Italy	Ragusa		Borgo Bartolomeo
200	324	282	2	Italy	Parma		Di Giovanni lido
201	325	215	2	Italy	Sondrio		Quarto Lisandro
202	326	259	2	Italy	Cagliari		Lauriano veneto
203	327	410	2	Italy	Salerno		Quarto Vladimiro a mare
204	328	101	2	Italy	Lecce		Borgo Filomeno
205	329	78	2	Italy	Vibo Valentia		Da Rold umbro
206	330	176	2	Italy	Pordenone		Settimo Icilio
207	331	67	2	Italy	Varese		Sanfilippo ligure
208	332	199	2	Italy	Isernia		Boris terme
209	333	191	2	Italy	Verbano-Cusio-Ossola		Quarto Riccardo
210	334	97	2	Italy	Vibo Valentia		Quarto Gerasimo
211	335	201	2	Italy	Cosenza		Quarto Marcello
212	336	43	2	Italy	Oristano		Quarto Loretta sardo
213	337	9	2	Italy	Pordenone		Sesto Democrito
214	338	55	2	Italy	La Spezia		San Anatolia
215	339	26	2	Italy	Perugia		Emilia terme
216	340	63	2	Italy	Vercelli		Adalgiso lido
217	341	76	2	Italy	Ascoli Piceno		Monaco veneto
218	342	239	2	Italy	Trento		Iona ligure
219	343	209	2	Italy	Caltanissetta		Ninfa lido
220	344	127	2	Italy	Roma		Sesto Menardo calabro
221	345	34	2	Italy	Milano		Quarto Iorio calabro
222	346	3	2	Italy	Brindisi		Zanella calabro
223	347	117	2	Italy	Brescia		Manno laziale
224	348	254	2	Italy	Sassari		San Adina sardo
225	349	154	2	Italy	Alessandria		De Giorgio calabro
226	350	46	2	Italy	Como		Catanzaro sardo
227	351	263	2	Italy	Taranto		Patrone lido
228	352	299	2	Italy	Carbonia-Iglesias		Devota del friuli
229	353	31	2	Italy	Napoli		Quarto Amabile
230	354	152	2	Italy	Roma		Impellizzeri terme
231	355	194	2	Italy	Ancona		Quarto Leo
232	356	168	2	Italy	Salerno		Borgo Vinicio terme
233	357	166	2	Italy	Palermo		Ferro calabro
234	358	221	2	Italy	Varese		San Onorino
235	359	300	2	Italy	Ravenna		Elvia del friuli
236	360	150	2	Italy	Alessandria		Settimo Tesauro
237	361	42	2	Italy	Ascoli Piceno		Nunziata terme
238	362	253	2	Italy	Palermo		Valentini calabro
239	363	112	2	Italy	Ragusa		Sesto Adriano a mare
240	364	150	2	Italy	Trapani		Loddo terme
241	365	165	2	Italy	Reggio Calabria		Demontis del friuli
242	366	273	2	Italy	Enna		Marchetti lido
243	367	275	2	Italy	Brescia		San Stiliano
244	368	96	2	Italy	Arezzo		Sesto Piersilvio del friuli
245	369	225	2	Italy	Cosenza		Bergamasco veneto
246	370	45	2	Italy	Pistoia		Pession veneto
247	371	109	2	Italy	Catanzaro		Borgo Archippo del friuli
248	372	146	2	Italy	Mantova		Astrid lido
249	373	292	2	Italy	Savona		Rosamunda salentino
250	374	9	2	Italy	Vicenza		Visintin umbro
251	375	199	2	Italy	Terni		Quarto Nicol� nell'emilia
252	376	251	2	Italy	L'Aquila		Settimo Camilla lido
253	377	247	2	Italy	Forlì-Cesena		San Diego
254	378	197	2	Italy	Cagliari		Borgo Antonia
255	379	49	2	Italy	Agrigento		Cusumano laziale
256	380	266	2	Italy	Matera		Bartoli veneto
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address, altitude) FROM stdin;
1	0	0101000020E610000043D95E8288A91C40720950EB278D4640	Start Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
2	0	0101000020E610000051A7B8816D921C408D966B20C98C4640	End Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
3	0	0101000020E6100000C668CC0D4EA81C40DA8DB03B2C8D4640		Ref Point 1	1256.85
4	0	0101000020E6100000116FE90D01A21C4022DFF1622B8D4640		Ref Point 2	1283.61
5	0	0101000020E61000004337FB03E5161B401CEBE2361A844640	Start Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
6	0	0101000020E61000001092054CE0161B401FD8F15F20844640	End Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
7	0	0101000020E610000058CB9D9960C81B408731E9EFA59C4640	Start Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
8	0	0101000020E61000003BE0BA6246C81B401E34BBEEAD9C4640	End Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
9	0	0101000020E61000007EE4D6A4DBC21B40147AFD497C9C4640		fountain	2027.00
10	0	0101000020E6100000B7B8C667B2BF1B4090A4A487A19B4640		Peak	2131.00
11	0	0101000020E61000005F9A22C0E96520406C76A4FACE554640	Start Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
12	0	0101000020E61000002368CC24EA652040CC7EDDE9CE554640	End Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
13	0	0101000020E61000006B662D05A46D20401557957D57564640		Ref Point 1	482.53
14	0	0101000020E610000024D236FE44652040813D26529A554640		Ref Point 2	242.59
15	0	0101000020E61000009F3E027FF83920409E245D33F9804640	Start Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
16	0	0101000020E610000099F56228273A20408DEDB5A0F7804640	End Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
17	0	0101000020E61000002D64979723B62440C66F2527958D4740	Edmund-Graf-Hütte	6574 Pettneu am Arlberg, Tyrol, Austria	\N
18	0	0101000020E6100000455BF9D0380E2A4056DBD4F478794740	Dr.Hernaus-Stöckl	9020 Klagenfurt, Kärnten, Austria	\N
19	0	0101000020E61000003AD4CD22968A2D406DAF4FF575F14740	Amstettner Hütte	3340 Waidhofen an der Ybbs, Niederösterreich, Austria	\N
20	0	0101000020E61000003470C88518362B404F23C0A11DEA4740	Hochleckenhaus	4853 Steinbach am Attersee, Oberösterreich, Austria	\N
21	0	0101000020E6100000745CA7EA5C3230400E95C9F10B114840	Kampthalerhütte	2384 Breitenfurt bei Wien, Niederösterreich, Austria	\N
22	0	0101000020E610000059E5350827672B402FB2862AC2D34740	Lambacher Hütte	4822 Bad Goisern, Oberösterreich, Austria	\N
23	0	0101000020E610000019FDD2643FA62340662869A087B24740	Lustenauer Hütte	6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria	\N
24	0	0101000020E610000036849931B0F52A4014BD78F039C44740	Gablonzer Hütte	4825 Gosau-Hintertal, Oberösterreich, Austria	\N
25	0	0101000020E6100000202F5A3629BF3740D489BAC5B2144340	Katafygio «Flampouri»	136 72 Acharnes, Attica region, Greece	\N
26	0	0101000020E6100000103E4BA24D3F2B40F731169C1AC04740	Simonyhütte	4830 Hallstatt, Oberösterreich, Austria	\N
27	0	0101000020E610000033190145D5182740BF9048EBDFA04740	Vinzenz-Tollinger-Hütte	6060 Hall in Tirol, Tyrol, Austria	\N
28	0	0101000020E61000001F1E0B5901B82E4091BFCBF1EAB34740	Ottokar-Kernstock-Haus	8600 Bruck an der Mur, Steiermark, Austria	\N
29	0	0101000020E610000018E4FB977DBF2A40D6A3B4422D754740	Reisseckhütte	9814 Mühldorf, Mölltal, Kärnten, Austria	\N
30	0	0101000020E61000007B116DC7D4A52540C0401020436D4740	Vernagthütte	Austria	\N
31	0	0101000020E6100000286211C30EF323407EC9C6832D884740	Wormser Hütte	Austria	\N
32	0	0101000020E6100000999CDA19A60E24406CD097DEFEA04740	Biberacher Hütte	Austria	\N
33	0	0101000020E610000007BC276AC4133740DDF934DDA1A84440	Katafygio «1777»	620 55 Kerkini, Central Macedonia region, Greece	\N
34	0	0101000020E6100000D5AF743E3C0B2A40E6E786A6EC704840	Hochwaldhütte	Germany	\N
35	0	0101000020E6100000C2FBAA5CA8EC19408FC536A968544940	Kölner Eifelhütte	Germany	\N
36	0	0101000020E6100000323CF6B358D223401763601DC7794740	Madrisahütte	Austria	\N
37	0	0101000020E6100000313F373465472640CDC98B4CC07F4740	Dresdner Hütte	Austria	\N
38	0	0101000020E6100000CDCCCCCCCC6C24403E07962364A84740	Fiderepasshütte	Germany	\N
39	0	0101000020E6100000B727486C77172440A9DDAF027C9B4740	Göppinger Hütte	Austria	\N
40	0	0101000020E6100000A379008BFC622340C7629B54348A4740	Oberzalimhütte	Austria	\N
41	0	0101000020E610000013B70A62A0932740B3B45373B99D4740	Rastkogelhütte	Austria	\N
42	0	0101000020E61000009D2D20B41E0E2440D54F49E70DC24740	Ansbacher Skihütte im Allgäu	Germany	\N
43	0	0101000020E610000009E066F16249244097E13FDD408F4740	Kaltenberghütte	Austria	\N
44	0	0101000020E61000000AD7A3703D0A2640E277D32D3B944740	Schweinfurter Hütte	Austria	\N
45	0	0101000020E61000006DC438245A213640DA172BC5E9574340	Katafygio «Vardousion»	330 53 Delphi, Central Greece region, Greece	\N
46	0	0101000020E6100000630F270F8F472D40336D62F5852D4740	Kocbekov dom na Korošici	3334 Luče, Mozirje, Slovenia	\N
47	0	0101000020E6100000D1F5D08072062D40D25C9F20CE114740	Planinski dom Rašiške cete na Rašici	1211 Ljubljana, Šmartno, Slovenia	\N
48	0	0101000020E6100000F70F966F85592C40971550C935374740	Prešernova koca na Stolu	4274 Žirovnica, Slovenia	\N
49	0	0101000020E6100000AA5C8F5FCB372E408E6CD71919184740	Planinski dom na Mrzlici	3302 Griže, Slovenia	\N
50	0	0101000020E6100000651A4D2EC6802C40577A6D3656FC4640	Koca na Planini nad Vrhniko	1360 Vrhnika, Slovenia	\N
51	0	0101000020E6100000245DF94DDD322C4077DAB7E6D0144740	Zavetišce gorske straže na Jelencih	0, -, Slovenia	\N
52	0	0101000020E6100000313F3734656F2E406F7F2E1A32264740	Planinski dom na Gori	Šentjungert, 3310 Žalec, Slovenia	\N
53	0	0101000020E610000098F2E7FC90A22B40C7CBA2C928274740	Bregarjevo zavetišce na planini Viševnik	4265 Bohinjsko jezero, Slovenia	\N
54	0	0101000020E610000091860959CC862B401635F33FD4244740	Koca pod Bogatinom	4265 Bohinjsko jezero, Slovenia	\N
55	0	0101000020E6100000678B3942E5992B40007F639573334740	Pogacnikov dom na Kriških podih	5232 Soca, Slovenia	\N
56	0	0101000020E610000008F580BBE4CC2D402A9C0F95E7344740	Dom na Smrekovcu	3325 Šoštanj, Slovenia	\N
57	0	0101000020E610000073F6CE68AB32194060E811A3E77C4640	Refuge Du Chatelleret	38520 Saint Christophe En Oisans, Isère, France	\N
58	0	0101000020E610000084622B685AF218408177F2E9B16B4640	Refuge De Chalance	5800 La Chapelle En Valgaudemar, Hautes-Alpes, France	\N
59	0	0101000020E6100000963D096CCE711940AE7FD767CE6A4640	Refuge Des Bans	5290 Vallouise, Hautes-Alpes, France	\N
60	0	0101000020E6100000DEAB5626FC52DBBFAED689CBF16A4540	Refuge De Pombie	65400 Laruns, Pyrénées-Atlantiques, France	\N
61	0	0101000020E6100000A69C2FF65E7CD2BFA9F92AF9D86D4540	Refuge De Larribet	65400 Arrens, Marsous, Hautes-Pyrénées, France	\N
62	0	0101000020E61000009CA6CF0EB84E1B401232906797C34640	Refuge Du Mont Pourri	73210 Peisey Nancroix, Savoie, France	\N
63	0	0101000020E6100000C712D6C6D8E91A40BF81C98D222D4740	Refuge De La Dent D?Oche	74500 Bernex, Haute-Savoie, France	\N
64	0	0101000020E6100000BEBDCA2243F820405620D41E27544740	Bergseehütte SAC	Uri, Switzerland	\N
65	0	0101000020E6100000CDD5732CA96D1E40F591820D5C054740	Bivouac au Col de la Dent Blanche CAS	Wallis, Switzerland	\N
66	0	0101000020E610000060F1FE571F0C2140D6BA5B328C564740	Salbitschijenbiwak SAC	Uri, Switzerland	\N
67	0	0101000020E610000084EAC5BE53052140F224048A5C664740	Spannorthütte SAC	Uri, Switzerland	\N
68	0	0101000020E6100000827FB24EBCB71E406113E452EB0C4740	Cabane Arpitettaz CAS	Wallis, Switzerland	\N
69	0	0101000020E61000008A75AA7CCF48E4BF588BF447BD614540	Refugio De Lizara	22730, Aragón, Spain	\N
70	0	0101000020E6100000AE56C01909F8E43F58DB5E1CA6064540	Albergue De Montfalcó	22585 Tolva, Aragón, Spain	\N
71	0	0101000020E61000000A4CFFBF1E610AC08B780953B6904240	El Molonillo/Peña Partida	18160 Güejar Sierra, Andalucía, Spain	\N
72	0	0101000020E610000029110100A92D0AC0F39F054F27844240	La Campiñuela	18417 Trévelez, Andalucía, Spain	\N
73	0	0101000020E61000008E79782A3BCC3440BEAE152301FF4440	Titov Vrv	Tetovo, Municipality of Tetovo, North Macedonia	\N
74	0	0101000020E6100000A2EC2DE57C212B40C7F143A5113D4540	Rifugio Franchetti	Pietracamela, Abruzzo, Italy	\N
75	0	0101000020E610000052E2299ABDFA2840518B1C7D27114740	Rifugio Semenza	Tambre, Veneto, Italy	\N
76	0	0101000020E6100000A197F67244A31F40313D06D094EE4640	Rifugio Città di Mortara 	Alagna Valsesia, Piemonte, Italy	\N
77	0	0101000020E61000006E39F29B1D242040AB1ED555260C4740	Rifugio Andolla	Antrona Schieranico, Piemonte, Italy	\N
78	0	0101000020E61000000AD80E46ECAB2440B70BCD751AFF4540	Rifugio Forte dei Marmi	Stazzema, Toscana, Italy	\N
79	0	0101000020E6100000A88B14CAC2CF284038D66AB4C1504740	Rifugio Berti	Comelico Superiore, Veneto, Italy	\N
80	0	0101000020E610000071B43E4052BB2B406FE70CD649CF4640	Rifugio Premuda	San Dorligo della Valle, Friuli Venezia Giulia, Italy	\N
81	0	0101000020E61000006CCF2C0950C32240191BBAD91FF84640	Rifugio Elisa	Mandello del Lario, Lombardia, Italy	\N
82	0	0101000020E6100000A5BDC11726B31F40F90FE9B7AFFB4640	Rifugio CAI Saronno	Macugnaga, Piemonte, Italy	\N
83	0	0101000020E610000098DD9387857A2640A930B610E4584740	Rifugio Picco Ivigna	Scena, Trentino Alto Adige, Italy	\N
84	0	0101000020E61000003AE97DE36B8F1C404AEF1B5F7B8A4640	Rifugio Toesca	Bussoleno, Piemonte, Italy	\N
85	0	0101000020E6100000A913D044D8E02040382D78D1570C4740	Rifugio Al Cedo	Santa Maria Maggiore, Piemonte, Italy	\N
86	0	0101000020E6100000449D5ECE11661F4009ED8B3A29F34640	Capanna Gnifetti	Gressoney La Trinitè, Valle d?Aosta, Italy	\N
87	0	0101000020E6100000B8AE9811DE3E1E403A048E041AFC4640	Rifugio Aosta	Bionaz, Valle d?Aosta, Italy	\N
88	0	0101000020E6100000BBB31B22135525408EA8F523EA374740	Rifugio Cevedale	Pejo, Trentino Alto Adige, Italy	\N
89	0	0101000020E61000000D33349E08722340F0A485CB2A204740	Rifugio Ponti	Val Masino, Lombardia, Italy	\N
90	0	0101000020E6100000C46D7E0DD2B125405364085B47134740	Rifugio XII Apostoli	Stenico, Trentino Alto Adige, Italy	\N
91	0	0101000020E61000009F1C058882591B40DDD1FF722DE24640	Rifugio Elisabetta Soldini	Courmayeur, Valle d?Aosta, Italy	\N
92	0	0101000020E610000061D57994804F25409903A4C1291F4740	Rifugio Denza	Vermiglio, Trentino Alto Adige, Italy	\N
93	0	0101000020E61000000C1F115322F92A40338AE596560F4540	Rifugio Fonte Tavoloni 	Ovindoli, Abruzzo, Italy	\N
94	0	0101000020E610000037C2A2224EBF2840F2ED5D83BE4E4740	Rifugio Carducci	Auronzo di Cadore, Veneto, Italy	\N
95	0	0101000020E61000006FA53220D64E26400DE02D90A0044740	Rifugio Bindesi	Trento, Trentino Alto Adige, Italy	\N
96	0	0101000020E610000001C11C3D7ECB2D40C670D0B9365A4640	Mountain hut Miroslav Hirtz	53287 Jablanac, Ličko-senjska županija, Croatia	\N
97	0	0101000020E6100000398485EEED352C4098331D324C154740	Koca na Blegošu	4224 Gorenja vas, Slovenia	\N
98	0	0101000020E610000040F850A225BF1F400F441669E2594940	Wittener Hütte	Germany	\N
99	0	0101000020E610000000FDBE7FF3AA25409A99999999694740	Hochjoch-Hospiz	Austria	\N
100	0	0101000020E6100000D7A02FBDFD412640CDCCCCCCCCB44740	Meilerhütte	Germany	\N
101	0	0101000020E610000050C422861DA628406E85B01A4BC64740	Gaudeamushütte	Austria	\N
102	0	0101000020E6100000179CC1DF2F961940D5EB1681B15C4940	Rheydter Hütte	Germany	\N
103	0	0101000020E6100000FB66518EB8562C4057E883656C744940	Sektionshütte Krippen	Germany	\N
104	0	0101000020E61000001F7A839D234C2C40B45EF68814A34740	Neunkirchner Hütte	2620 Neunkirchen, Steiermark, Austria	\N
105	0	0101000020E61000009CE379FC2043E7BF8FC536A9682C4540	Refugio De Riglos	22808, Aragón, Spain	\N
106	0	0101000020E6100000563D4FC4941A2140EBB308E997564740	Salbithütte SAC	Uri, Switzerland	\N
107	0	0101000020E61000001D55C855B23A2040B8EB64DCCE424740	Finsteraarhornhütte SAC	Wallis, Switzerland	\N
108	0	0101000020E6100000DEFD765E1AE71D4038777A52B2FE4640	Cabane des Vignettes CAS	Wallis, Switzerland	\N
109	0	0101000020E6100000E769EE0B84312040FBE19FAF02504740	Glecksteinhütte SAC	Bern, Switzerland	\N
110	0	0101000020E6100000752B5D3C5F152240D9971BDB51454740	Länta-Hütte SAC	Graubünden, Switzerland	\N
111	0	0101000020E610000055ADDEFA26292040BAB9F14860214740	Monte-Leone-Hütte SAC	Wallis, Switzerland	\N
112	0	0101000020E6100000557F0CE8F9C222408F373B25D26E4740	Ringelspitzhütte SAC	Graubünden, Switzerland	\N
113	0	0101000020E6100000A4AA09A2EE0334408E23D6E253104640	Na poljanama Maljen	Maljen, Serbia	\N
114	0	0101000020E6100000A9DE1AD82A313440C5E6E3DA50114640	Dobra voda	Suvobor, Serbia	\N
115	0	0101000020E61000007250C24CDBFF2E402D095053CBC64640	Ivanova hiža	Karlovac town environment, Karlovačka, Croatia	\N
116	0	0101000020E6100000C6DCB5847CC02F40C746205ED7EB4640	Glavica	Medvednica, City of Zagreb, Croatia	\N
117	0	0101000020E6100000FFEC478AC8B83040D3F6AFAC34BD4540	Trpošnjik	Mosor, Splitsko-dalmatinska, Croatia	\N
118	0	0101000020E6100000C217265305932D40C4CE143AAFA54640	Bitorajka	Bitoraj, Primorsko-goranska, Croatia	\N
119	0	0101000020E6100000AB09A2EE0360304006D847A7AE084640	Zlatko Prgin	Dinara, Šibensko-kninska, Croatia	\N
120	0	0101000020E6100000D3872EA86F492E405C8FC2F528444640	Prpa	Velebit, Ličko-senjska, Croatia	\N
121	0	0101000020E6100000787FBC57AD5C2E408BFD65F7E43D4640	Ždrilo	Velebit, Ličko-senjska, Croatia	\N
122	0	0101000020E610000086032159C0F42D40B21188D7F59B4640	Miroslav Hirtz	Velika Kapela, Primorsko-goranska, Croatia	\N
123	0	0101000020E6100000A31EA2D11DAC3140462575029AC04640	Jezerce	Papuk, Požeško-slavonska, Croatia	\N
124	0	0101000020E61000003EE8D9ACFA4C2F405F0CE544BBE24640	Ivica Sudnik	Samoborska gora, Zagrebačka, Croatia	\N
125	0	0101000020E6100000AD3BCC4D8A7D2840CBDF185D39124640		8 Piazza Orsino, Sesto Abibo laziale, Italy	\N
126	0	0101000020E6100000AF5E454607602340EDF2AD0FEB6B4440		2 Via Merola, Giuliana sardo, Italy	\N
127	0	0101000020E610000050BA3EBD63AA2840D5DBB0B7DE294640		59 Rotonda Vincenza, Sesto Remo umbro, Italy	\N
128	0	0101000020E6100000E7204322C8042640F6AEE6A507F54540		59 Contrada Pizzitola, Borgo Doriano, Italy	\N
129	0	0101000020E61000009F11B6E919B02140ABAC12D154364640		04 Contrada Perego, Quarto Efrem, Italy	\N
130	0	0101000020E61000009EBFBFF7ED2224402DAAEA8ABEE84640		0 Incrocio Lipari, Basilia nell'emilia, Italy	\N
131	0	0101000020E6100000FF209221C76E274017844DF8002D4640		4 Piazza Boccia, Settimo Ataleo, Italy	\N
132	0	0101000020E6100000C2B28817FA8E2340D5809C8B1AB04640		70 Contrada Elide, Borgo Samuele ligure, Italy	\N
133	0	0101000020E6100000107BFC3960762540600A6A53D0274740		75 Strada Grande, Cleo sardo, Italy	\N
134	0	0101000020E6100000CF5AC0BAE0462B40B9ED314745E34640		63 Contrada Guido, Selene lido, Italy	\N
135	0	0101000020E610000048B42E7FCFC525403379B93E620B4740		6 Strada Ferroni, Settimo Amadeo ligure, Italy	\N
136	0	0101000020E6100000E066F16261B42A4084E85AC52CF04640		57 Via Aniceto, Rubino sardo, Italy	\N
137	0	0101000020E610000021263CFC90E62840C604EBEEF0074640		0 Borgo Ottonello, Quarto Terenzio veneto, Italy	\N
138	0	0101000020E6100000CFB81567B161274070CFF3A78DA74640		593 Incrocio Bertani, Vichi lido, Italy	\N
139	0	0101000020E6100000C1F979F8D76F224054F0CAE48AB04640		8 Via Angela, Ferrero lido, Italy	\N
140	0	0101000020E61000008248D0A975782B40741200D2EDC94640		552 Borgo Scalia, Borgo Natale, Italy	\N
141	0	0101000020E6100000918B208436172940630E828E564E4540		03 Piazza Gangemi, Sesto Giulio, Italy	\N
142	0	0101000020E610000023484A1F5F572240D37CDF09072C4640		340 Strada Carta, Settimo Gaudenzia sardo, Italy	\N
143	0	0101000020E6100000A09339F130542140F7DBE8ADCB384740		6 Incrocio Barillà, Bacci a mare, Italy	\N
144	0	0101000020E6100000068A0E37967A2540DB1FDE29D3664540		19 Rotonda Stefano, Demostene calabro, Italy	\N
145	0	0101000020E6100000CF59B09EA4CE2640F18288D4B4434740		059 Via Zoe, Demontis del friuli, Italy	\N
146	0	0101000020E6100000C153C8957A5A26407541D8840FE14640		8 Incrocio Timoteo, Artemisa umbro, Italy	\N
147	0	0101000020E61000008577B988EF302140BAD3426E2B3D4740		04 Rotonda Gherardo, San Onesta, Italy	\N
148	0	0101000020E6100000589643E6259E2540B49487E013DD4540		7 Borgo Papini, Settimo Teodoro, Italy	\N
149	0	0101000020E6100000249E4720B9702840B1F84D61A5124640		013 Incrocio Speranza, Settimo Magno, Italy	\N
150	0	0101000020E61000008B89CDC7B55926407EB4EED57D084740		29 Via Marianna, Fleano calabro, Italy	\N
151	0	0101000020E6100000D8B969334EEB27402CF8C84164804540		563 Strada Sorbello, Sesto Cuniberto, Italy	\N
152	0	0101000020E610000061D394AEAAD4204012A6835039FC4640		52 Borgo Aurelio, Ruggero lido, Italy	\N
153	0	0101000020E6100000B53C6AA741AC27408F0134A550B84640		89 Via Nilde, Borgo Ausilia, Italy	\N
154	0	0101000020E6100000F78CE9AE91D52240ED48F59D5FE54640		978 Borgo Clemente, Gregori a mare, Italy	\N
155	0	0101000020E6100000626DE75663902B4097FA1E9A1ED44640		7 Contrada Mia, Colantuono salentino, Italy	\N
156	0	0101000020E6100000FFF9C78C011B2640DD706946501E4740		613 Rotonda Napoletano, Borgo Ionne, Italy	\N
157	0	0101000020E61000009C363EEEB67E2740BC2363B5F9BA4640		04 Incrocio Gundelinda, Accardi lido, Italy	\N
158	0	0101000020E61000008A9466F3387C1E402B31CF4A5AE74640		154 Incrocio Cordelia, Troisi veneto, Italy	\N
159	0	0101000020E6100000F22895F084D22A404082870E26ED4440		535 Via Marcello, Settimo Acrisio, Italy	\N
160	0	0101000020E61000007E1D386744712240C878399105CC4640		46 Via Silvia, Lazzari lido, Italy	\N
161	0	0101000020E610000020D84C1993812240A475AFEEB30D4740		9 Rotonda Fernanda, Quarto Sapiente nell'emilia, Italy	\N
162	0	0101000020E6100000242136FD7E2E26406E2AF7A7F91A4740		55 Borgo Alarico, Gaudenzio sardo, Italy	\N
163	0	0101000020E6100000485E8C37E8B927408860C1A2C7CA4640		61 Borgo Alfredo, Isidoro sardo, Italy	\N
164	0	0101000020E61000005E961BB1BB751E407379BD4571EF4640		687 Via Birino, Giacalone veneto, Italy	\N
165	0	0101000020E6100000BE2ABC708CED2340366964A1E7DD4640		70 Borgo Cecchini, Borgo Uriele nell'emilia, Italy	\N
166	0	0101000020E610000053B4722F302B2540E4DC26DC2B4D4740		20 Piazza Ventura, Quarto Cassandra veneto, Italy	\N
167	0	0101000020E61000009A97C3EE3B32254052B241CB5F574640		0 Borgo Remondo, Quarto Norberto, Italy	\N
168	0	0101000020E6100000622D3E05C0782840F70BD17C29DE4640		1 Borgo Carrozzo, Gatto calabro, Italy	\N
169	0	0101000020E6100000B05758703F782440773A4668BAB84640		1 Incrocio Campo, Quarto Urdino, Italy	\N
170	0	0101000020E610000011D20957F63B2640E6B8AEF3CA084740		58 Contrada Cascone, Quarto Adelasia, Italy	\N
171	0	0101000020E61000004704E3E0D2692C408514F2F741A74640		7 Contrada Lino, Salemi a mare, Italy	\N
172	0	0101000020E61000002F0ACC54D2C8264038FE9F1E36CA4640		3 Strada Tedde, Ferrando ligure, Italy	\N
173	0	0101000020E610000046E80C31035E29405A46EA3D95E54640		82 Contrada Chiara, Sesto Reginaldo, Italy	\N
174	0	0101000020E6100000E4F90CA8376B2340ABA3F496BC5E4440		96 Incrocio Poggio, Borgo Agabio, Italy	\N
175	0	0101000020E6100000967DB2BD71ED26406F7319EDA7C14640		13 Piazza Pisu, De Lorenzo umbro, Italy	\N
176	0	0101000020E6100000FC68DDABFB5427401073EE1B04334740		420 Rotonda Geremia, Quarto Tristano, Italy	\N
177	0	0101000020E610000069965F611C5B2540B52792F991CA4540		4 Rotonda Dulina, Calogero veneto, Italy	\N
178	0	0101000020E6100000B4C6455ACF692740D8C523A765B04640		8 Contrada Casali, Riccardo calabro, Italy	\N
179	0	0101000020E61000003B843B61D3CC1E40935742D202D44640		081 Strada Benedetto, San Ilia, Italy	\N
180	0	0101000020E6100000C03FA54A9455284094347F4C6BE54640		7 Rotonda Abbondanzio, Quarto Bertoldo umbro, Italy	\N
181	0	0101000020E610000003FBF900EEEB1E40FA6184F068EE4640		2 Rotonda Ross, San Rino salentino, Italy	\N
182	0	0101000020E610000007681140209E2640B177352F3D9D4640		7 Piazza Gennaro, Borgo Ezio, Italy	\N
183	0	0101000020E6100000525F96766AFE23402A7C6C81F3EE4640		4 Rotonda Ferrarotti, Sesto Corrado calabro, Italy	\N
184	0	0101000020E61000007319EDA7B5EF1E400B1060EC18EC4640		39 Strada Toti, Quarto Canziano, Italy	\N
185	0	0101000020E6100000F86B578DCA1A284015E06014A9B14640		9 Strada Gualberto, San Lorenzo ligure, Italy	\N
186	0	0101000020E6100000D634947FD2A12740811A081390584540		190 Strada Ausilia, Bentivoglio laziale, Italy	\N
187	0	0101000020E61000009D63E53C08EA2640B7FB0BF3D4DC4540		90 Borgo Pillitteri, Quarto Lucrezia, Italy	\N
188	0	0101000020E6100000EA0E18DAEF9B2B40948444DAC6764640		33 Piazza Tavani, Settimo Roberta sardo, Italy	\N
189	0	0101000020E610000014BCD7FFEFC62640BA66F2CD36DE4640		9 Borgo Pirrone, Sesto Aleandro laziale, Italy	\N
190	0	0101000020E610000009168733BFBE27405D4E098849354540		97 Via Palmazio, Borgo Vincenzo, Italy	\N
191	0	0101000020E6100000462AE7E6763A2940ABB8CC446CE14440		2 Incrocio Bardomiano, San Ido, Italy	\N
192	0	0101000020E610000075EED176A7F62640A7F97486F3B24640		3 Strada Prisco, Quarto Elpidio nell'emilia, Italy	\N
193	0	0101000020E6100000F9A23D5E48F727405789C3E3ECE04640		485 Borgo Brigida, Godeberta salentino, Italy	\N
194	0	0101000020E6100000731A587D64FD294065FED13769E64540		0 Incrocio Gaudenzio, Giglio ligure, Italy	\N
195	0	0101000020E6100000ABC5F18D322421407D1FB3582FFA4640		5 Via Cristoforo, Di Bella lido, Italy	\N
196	0	0101000020E610000035D252793B0228403A79ECC26AEA4640		267 Contrada Ansovino, Lelli laziale, Italy	\N
197	0	0101000020E6100000DD730580CFD02640F16261889CD44640		55 Strada Elita, Martelli laziale, Italy	\N
198	0	0101000020E61000006531564046E12040530E1C8645E74640		693 Borgo Polifemo, Luchetti sardo, Italy	\N
199	0	0101000020E610000026B8A2DE9D5E2740311A434AFDDC4640		5 Borgo Gianpietro, San Desiderata, Italy	\N
200	0	0101000020E61000000A5BFD22B27524407121EA99B95B4640		549 Rotonda Melanio, Clodomiro nell'emilia, Italy	\N
201	0	0101000020E6100000C132DBBA40CE2240D0EFFB372F274740		488 Via Caputo, Ulisse umbro, Italy	\N
202	0	0101000020E6100000CA558737C6B91F40EB79ED88F9BD4640		4 Incrocio Palmazio, San Apollo, Italy	\N
203	0	0101000020E61000006AEE320DD4F324401D098F9147B14640		43 Contrada Righi, Quarto Abele, Italy	\N
204	0	0101000020E610000044053D8A291B2140F0FACC599F5A4440		3 Incrocio Carmela, Sesto Paterniano, Italy	\N
205	0	0101000020E61000002B1D07B9E6212040F08C11E4FBF04640		1 Piazza Venerio, Romana ligure, Italy	\N
206	0	0101000020E61000007BEDE3B21BB727403464E190B2DD4640		524 Contrada Forte, Settimo Ivan, Italy	\N
207	0	0101000020E6100000D8E9ACBB1EE91F40A0A932E774D04640		031 Strada Alvaro, Costantin a mare, Italy	\N
208	0	0101000020E61000009C8136DEC21B294063731FCA61894540		7 Borgo Anna, Eliana veneto, Italy	\N
209	0	0101000020E6100000E3B08FA91680204076A0F3BF01E94640		10 Via Tesi, Gherardo umbro, Italy	\N
210	0	0101000020E6100000EE6EAF16E9832340C6F0225D7DCC4640		247 Piazza Ferranti, Tabita laziale, Italy	\N
211	0	0101000020E6100000D81D41E037B02140C2F1214D61C54440		076 Rotonda Liberato, Fioravanti umbro, Italy	\N
212	0	0101000020E6100000A807BB174E80284061BC8B9C2AD94640		849 Strada Bove, Di Tommaso calabro, Italy	\N
213	0	0101000020E6100000FD18CE9085A322406C9CA80073DB4640		4 Strada Maggio, Sesto Paciano, Italy	\N
214	0	0101000020E6100000E39F635122672540E113A1C7DEDE4640		68 Incrocio Sebastiano, Bindi terme, Italy	\N
215	0	0101000020E610000098231A93B47928409916500361674640		347 Strada Ferretti, Borgo Giovanni, Italy	\N
216	0	0101000020E6100000ABBCD3539A032740A544B7031AEF4640		59 Contrada Niceforo, Guido nell'emilia, Italy	\N
217	0	0101000020E61000001E424B0D239B2440D8D1DD1A7DA04640		92 Contrada Spizzirri, Licia nell'emilia, Italy	\N
218	0	0101000020E6100000CF2CAE96E0891F405EB642FDD3234640		00 Strada Malizia, Sesto Urbano nell'emilia, Italy	\N
219	0	0101000020E6100000D7BDBACF96BC254007205AD020C34640		981 Incrocio Gruber, Palmisani nell'emilia, Italy	\N
220	0	0101000020E6100000C96BCABA24832740A97E4A3A6FE54640		82 Piazza Donda, San Lorena, Italy	\N
221	0	0101000020E6100000A8DAB80F8AC32940DF67017F9D1A4540		403 Piazza Gilda, Taziano laziale, Italy	\N
222	0	0101000020E6100000C272DFC556972640A4271BC528D24640		840 Borgo Gabriele, Vivaldo a mare, Italy	\N
223	0	0101000020E61000005F306E5974411E40EC3F21F1E13A4740		27 Incrocio Sarti, Sesto Tulliano, Italy	\N
224	0	0101000020E61000006C109CE9142628401760C4E347124740		2 Via Fadda, Settimo Urbano, Italy	\N
225	0	0101000020E610000044EC0214D9FD284012AC600AC5EE4440		120 Via Cristoforo Colombo, Roma, Italy	\N
226	0	0101000020E6100000B0FECF61BEF827406DFD99E6C2F24640		323 Strada Artemisa, Ricciardi nell'emilia, Italy	\N
227	0	0101000020E6100000EBB76576CCAF26407B8FE9BFBD424640		0 Via Fidenzio, Rapisarda umbro, Italy	\N
228	0	0101000020E6100000D6479682247220407379BD4571084740		89 Strada Cuomo, Nerea terme, Italy	\N
229	0	0101000020E610000097900F7A36872040AB251DE560074740		7 Borgo Ondina, Tarso veneto, Italy	\N
230	0	0101000020E61000000DABD3DC65C22740D32F116F9DE34640		95 Incrocio Ancona, Sanfilippo salentino, Italy	\N
231	0	0101000020E61000009FEE97AA0FCF27402834FF9E0E024740		74 Rotonda Rigoni, Settimo Apollinare terme, Italy	\N
232	0	0101000020E6100000E417B90265622C40EFC0A50815E24440		4 Incrocio Corradi, San Decimo, Italy	\N
233	0	0101000020E6100000B2463D44A37B2540F3C011EEDF764540		9 Rotonda Re, Bresciani salentino, Italy	\N
234	0	0101000020E6100000B6B0B84956A326409DC2A5BE87334740		20 Strada Abbondanzio, Cerri laziale, Italy	\N
235	0	0101000020E6100000D56C2FB319AD2840823C16365EC04640		9 Piazza Milani, Borgo Raffaele umbro, Italy	\N
236	0	0101000020E610000076583C5002EE1E40E0CCF9731BE14640		63 Via Belli, Quarto Arduino, Italy	\N
237	0	0101000020E6100000470EC7A98CC52840B6A73F564BE04640		0 Strada Bacci, Borgo Abelardo a mare, Italy	\N
238	0	0101000020E61000004DC00A4B97B91F4005C1E3DBBBF84540		5 Piazza Fanara, Borgo Verulo, Italy	\N
239	0	0101000020E610000059EB7A585E182740106D1162780E4640		7 Incrocio Fernanda, Settimo Demostene salentino, Italy	\N
240	0	0101000020E610000051D9B0A6B2581F4089B7CEBF5DE14640		85 Borgo Fedro, Settimo Selvaggia, Italy	\N
241	0	0101000020E6100000AD7603BB504F27406049A8CFC4374640		88 Borgo Mancino, Borgo Lodovica, Italy	\N
242	0	0101000020E61000004692C5A28EF72640D32934B511794640		45 Rotonda Alcina, Giacinto calabro, Italy	\N
243	0	0101000020E6100000068B790C45182740C3CB1D47BD774640		7 Strada Ventura, San Zama, Italy	\N
244	0	0101000020E61000005CC0159A35C620401880A1A245F44640		904 Strada Dante, Quarto Calogera, Italy	\N
245	0	0101000020E6100000FA2D9512DD7227409453967C47234640		9 Via Adalfredo, Sesto Gennaro lido, Italy	\N
246	0	0101000020E61000008ECD8E54DFA12B403562C1583A2D4540		4 Incrocio Alessandrini, San Giovanni salentino, Italy	\N
247	0	0101000020E610000020651FBF127F254034C06092257F4640		435 Borgo Casimira, Eginardo terme, Italy	\N
248	0	0101000020E610000064BB31F3D36E22404F401361C3C24640		41 Strada Abbondanzio, Cuzzocrea del friuli, Italy	\N
249	0	0101000020E6100000D160AEA0C47E2240E41824D813C04640		2 Piazza Cruciata, Sesto Alma, Italy	\N
250	0	0101000020E61000006FD8B628B3B91E40086465EA64D64640		5 Piazza Iginia, Siri ligure, Italy	\N
251	0	0101000020E610000016CDB9CAC93E2140BC0E8B074A744640		09 Incrocio Celi, Pecorella ligure, Italy	\N
252	0	0101000020E6100000B4064A65E54A274026DAFA8E86E14640		122 Incrocio Parrinello, Quarto Pierangelo, Italy	\N
253	0	0101000020E61000000736F80CF26822405273034F6B9C4640		142 Piazza Polidori, Settimo Gaetano terme, Italy	\N
254	0	0101000020E6100000DF6124C511412140D11CFE3FF3744640		3 Contrada Gioia, San Gherardo, Italy	\N
255	0	0101000020E610000077ED77CD50412140CB243493B9744640		843 Piazza Costantini, Gianfranco sardo, Italy	\N
256	0	0101000020E61000002E008DD2A5032D406B5CA4F55C204540		7 Incrocio Fedro, Amato laziale, Italy	\N
257	0	0101000020E61000004ED367075C6F1F403A57941282D64640		01 Piazza Ermini, Placido laziale, Italy	\N
258	0	0101000020E61000006405BF0D316E1F409F07D22060D24640		5 Borgo Tassi, San Folco del friuli, Italy	\N
259	0	0101000020E61000006F4BE482334C2740A928A8F287304640		583 Contrada De Vito, Rosset terme, Italy	\N
260	0	0101000020E61000005BC52CC59F522B40DB68A5B50EFA4640		7 Strada Gregori, Quarto Enrico, Italy	\N
261	0	0101000020E61000000D5F155E383A21402BCC310F4F724640		62 Piazza Lieto, Quarto Gaglioffo, Italy	\N
262	0	0101000020E6100000E04158326C5D2140821C9430D3704640		151 Incrocio Fidenzio, Salvatore umbro, Italy	\N
263	0	0101000020E6100000C1F979F8D7071F404EFA319C21CD4640		184 Via Serviliano, Deodata calabro, Italy	\N
264	0	0101000020E61000000C97B0917F3921404C9C267D6B734640		924 Borgo Divo, De Bonis del friuli, Italy	\N
265	0	0101000020E6100000EFA18ED838742840FA10AF46D1764640		45 Borgo Gianpaolo, Petronilla sardo, Italy	\N
266	0	0101000020E6100000B032BF3F4AC11E4019CD25B094D54640		9 Incrocio Elena, Borgo Elogio umbro, Italy	\N
267	0	0101000020E610000039FBB9579CA829401D9C3EF152FC4440		3 Strada Maltese, Settimo Eustorgio, Italy	\N
268	0	0101000020E6100000440E5BC4C1F71E4071033E3F8C7E4640		84 Incrocio Franzè, Di Bella salentino, Italy	\N
269	0	0101000020E6100000C69EE2DD36D82B400B8AD5D5D3E84640		0 Piazza Venerio, Raffaele salentino, Italy	\N
270	0	0101000020E6100000888961E2EA131F4040E7244A31CD4640		28 Borgo Acquistapace, Frau umbro, Italy	\N
271	0	0101000020E6100000E8F86871C6D81E40E7EBE86E8DD84640		04 Via Frontiniano, Ciccarelli ligure, Italy	\N
272	0	0101000020E610000024BF34FBF2301F405FCE6C57E8CB4640		6 Borgo Cremona, Bernabei sardo, Italy	\N
273	0	0101000020E61000000242902859C7254075988AE832F64540		40 Contrada Ludovico, Sesto Abele, Italy	\N
274	0	0101000020E61000005CEC5113D8AF1E405650ACAE9ED84640		33 Strada Maffeo, Mautone laziale, Italy	\N
275	0	0101000020E6100000A6A84423E9E41E40BF20336145E14640		8 Incrocio Griselda, Borgo Adamo calabro, Italy	\N
276	0	0101000020E6100000F07A7AB6582B2740B1ADFAB726234640		48 Strada Bedini, Adele umbro, Italy	\N
277	0	0101000020E61000002252D32EA6C91E404392B47636E94640		49 Rotonda Monteleone, Saturniano veneto, Italy	\N
278	0	0101000020E61000000BC336983C2C27405262D7F676234640		3 Borgo Amico, Camilli ligure, Italy	\N
279	0	0101000020E61000004F722C94F1E8264075F2D885D5064740		404 Piazza Fabiano, Settimo Palmira, Italy	\N
280	0	0101000020E61000005C8BBBE6FA8F26407A4F8AFB343B4740		346 Incrocio Gordiano, Valentino terme, Italy	\N
281	0	0101000020E61000007B9054956C0B28407BB5487FD4974640		80 Piazza Migliaccio, Borgo Egeo terme, Italy	\N
282	0	0101000020E6100000BE52F1DA00B72B40D21D1F8887274540		0 Rotonda De Maio, Luongo del friuli, Italy	\N
283	0	0101000020E6100000A732D6485C052740FDD8243FE2394640		43 Piazza Giuseppe, Bianco salentino, Italy	\N
284	0	0101000020E6100000AD94545C0B4D2240EE885462E8B94640		98 Piazza Debora, San Amaranto, Italy	\N
285	0	0101000020E6100000333097F9B3641F40983BE93356DF4640		2 Rotonda Sveva, Cruciata terme, Italy	\N
286	0	0101000020E61000002B8AB2124E762740C1EA234B41314640		05 Via Misaele, Amabile ligure, Italy	\N
287	0	0101000020E6100000905F8951219022403E5695229E864640		21 Borgo Tullia, Settimo Bassilla, Italy	\N
288	0	0101000020E610000096C1621E43E92640E580B80611044740		1 Contrada Lori, Bonazzi sardo, Italy	\N
289	0	0101000020E61000007090B52B99842B40E461461DC27E4640		5 Contrada Pomponio, Sesto Ignazio del friuli, Italy	\N
290	0	0101000020E610000084B1CFAD219A26406BDECC43010E4740		99 Contrada D'Onofrio, Borgo Aronne, Italy	\N
291	0	0101000020E6100000CC1D47BDF13F2240A5A31CCC26824640		82 Incrocio Zama, Di Michele del friuli, Italy	\N
292	0	0101000020E610000048E58123DCFF26407F7E294D94084740		30 Piazza Sabino, Graziano calabro, Italy	\N
293	0	0101000020E61000006B5A73918C1625409D7C1FB358204740		9 Strada Trombetta, D'Anna del friuli, Italy	\N
294	0	0101000020E6100000204F818241C01E40068B1E53D2D34640		97 Via Pezzella, Settimo Sinesio terme, Italy	\N
295	0	0101000020E6100000C0CBB161F2931E40B859BC5818D34640		0 Borgo Abramo, Di Marino sardo, Italy	\N
296	0	0101000020E610000070DA4246F68B2C40A79C8AAFD1364740		28 Incrocio Rigoni, Francesco del friuli, Italy	\N
297	0	0101000020E6100000A9D5FC9D92882C4058FBE02131384740		687 Piazza Cappello, Quarto Verecondo, Italy	\N
298	0	0101000020E6100000F74A0FF91DD1274067DC8AB3D8024740		600 Strada Gaudenzio, Lo Giudice sardo, Italy	\N
299	0	0101000020E61000004221A7542EE52C40A39BB3F457164740		949 Via Franzè, Quarto Veneranda, Italy	\N
300	0	0101000020E6100000D3D7987C586422408E7CB9AA47A84640		85 Rotonda Fedele, Fabbro terme, Italy	\N
301	0	0101000020E610000008CDAE7B2B8A2440E646EC6EF9664540		85 Incrocio Loreno, Quarto Aristofane calabro, Italy	\N
302	0	0101000020E610000081EB8A19E1CD26408A4457D8C2194640		902 Rotonda Camillo, Borgo Carla calabro, Italy	\N
303	0	0101000020E6100000B4CA4C69FD5122404A95CDC1D8134540		710 Borgo Silvestrini, Borgo Gottardo, Italy	\N
304	0	0101000020E6100000E4BD6A65C267264033260EEA6CBC4640		63 Contrada Ulpiano, Michela laziale, Italy	\N
305	0	0101000020E610000071C0536DDCD325406C312E0BDCB14640		22 Borgo Santori, Ermelinda a mare, Italy	\N
306	0	0101000020E6100000B368F0ADFEEA2540D42AFA4333B54640		90 Contrada Michela, Franzè laziale, Italy	\N
307	0	0101000020E61000005B2CA0AB08EA2740DE454E15422C4740		263 Via Auberto, Quarto Altea nell'emilia, Italy	\N
308	0	0101000020E61000009703988D2933274052EC0D63778A4640		77 Via Monte Grappa, Lendinara, Italy	\N
309	0	0101000020E61000005389FC44AF582940E7D2AEF83CCA4640		6 Piazza Ancona, San Mauro, Italy	\N
310	0	0101000020E61000000236D6B441802C4025D5D237C46B4440		44 Via dei Greci, Napoli, Italy	\N
311	0	0101000020E610000073220BE24DBC2740A1E4C40DAE2D4740		69 Contrada De Maio, Settimo Delfina, Italy	\N
312	0	0101000020E610000046B1DCD26AB02540072E45A808074740		3 Incrocio Massa, Quarto Nicodemo laziale, Italy	\N
313	0	0101000020E6100000B17E7DBE77992240C0F858B043504440		45 Strada Gennaro, Leonida del friuli, Italy	\N
314	0	0101000020E6100000EC3026FDBD2C27403B6AF1CE46024740		1 Piazza Matteo, Quarto Fiammetta, Italy	\N
315	0	0101000020E6100000996EC8F5A5712B40C576F700DD3C4740		7 Incrocio Leo, Sesto Carmela, Italy	\N
316	0	0101000020E6100000AA5DB818A8F922406B0DA5F622154440		49 Piazza Monterosso, Sesto Dacio salentino, Italy	\N
317	0	0101000020E610000034B10AE58E682040CFC941BFA57A4440		73 Strada Apollina, Rosanna calabro, Italy	\N
318	0	0101000020E610000008D04AB5AABC2140800F5EBBB4374640		8 Contrada Simone, Borgo Ranolfo salentino, Italy	\N
319	0	0101000020E6100000B35DA10F967D2D408F49905BDD324740		08 Contrada Valentina, Quarto Franco laziale, Italy	\N
320	0	0101000020E6100000852348A5D8C12840842458C114E24540		07 Via Luana, Volpi a mare, Italy	\N
321	0	0101000020E6100000BF5076E915252B40EA398EC4703B4740		7 Via Vanda, Fucci lido, Italy	\N
322	0	0101000020E6100000B956D6917EDA2B40DF707A72A8054540		6 Via Annamaria, Ippolito nell'emilia, Italy	\N
323	0	0101000020E61000007889A02067742340DE2A3EF493CE4640		60 Contrada Ilenia, Borgo Bartolomeo, Italy	\N
324	0	0101000020E6100000235399BDC70C254059CFFF6101ED4540		3 Borgo Liberati, Di Giovanni lido, Italy	\N
325	0	0101000020E610000027F33405D7392640E75E16C90D2C4740		37 Contrada Sini, Quarto Lisandro, Italy	\N
326	0	0101000020E61000001C15EE4BECAC2A40DD11A9C4D02E4540		86 Rotonda Manicone, Lauriano veneto, Italy	\N
327	0	0101000020E6100000C1D4850E70E722408E6D63FDB0594540		3 Via Sirio, Quarto Vladimiro a mare, Italy	\N
328	0	0101000020E6100000E5BA849E28A826407E7D63BE723F4640		9 Piazza Bonazzi, Borgo Filomeno, Italy	\N
329	0	0101000020E610000055B1E72109D11F4018CFA0A17FB14640		142 Contrada Ponzio, Da Rold umbro, Italy	\N
330	0	0101000020E61000007DEFCA89D18E2640DB0B16985F354540		11 Piazza Calcedonio, Settimo Icilio, Italy	\N
331	0	0101000020E6100000BB6D9516E41D244002678412C1A94640		244 Via Placido, Sanfilippo ligure, Italy	\N
332	0	0101000020E6100000F67AF7C77BB52740FA449E245D4F4740		7 Incrocio Del Bianco, Boris terme, Italy	\N
333	0	0101000020E6100000DE68119BD960294098E8E225EEFB4440		359 Rotonda Ancilla, Quarto Riccardo, Italy	\N
334	0	0101000020E61000007ED3AA4CE7E52340C9CC052E8F254640		9 Strada Perrotta, Quarto Gerasimo, Italy	\N
335	0	0101000020E61000004EDF217B732E2240D3F4D901D7214540		6 Strada Artemisa, Quarto Marcello, Italy	\N
336	0	0101000020E61000004377A45588CA264008951348E43C4640		4 Via Fabbricatore, Quarto Loretta sardo, Italy	\N
337	0	0101000020E610000072593B40E6692840252D4B2A09EC4440		1 Incrocio Adone, Sesto Democrito, Italy	\N
338	0	0101000020E610000023E7B3F281D7214072C8618B38C84640		4 Piazza Carvelli, San Anatolia, Italy	\N
339	0	0101000020E61000000C84AE8E2D752740A4897780272E4640		75 Via Munaro, Emilia terme, Italy	\N
340	0	0101000020E6100000A63C5F58A33326408C811A63CCED4540		643 Contrada Marras, Adalgiso lido, Italy	\N
341	0	0101000020E6100000CC0C1B65FD922840A42C8DA905C14640		6 Borgo Eraclide, Monaco veneto, Italy	\N
342	0	0101000020E61000007332CC64933F2740FEDDF1DC31254640		1 Rotonda Vindonio, Iona ligure, Italy	\N
343	0	0101000020E610000032D758784D462240743F4C67CC0B4740		20 Borgo Filippo, Ninfa lido, Italy	\N
344	0	0101000020E61000002B16BF29ACC825401AB6775787864540		63 Incrocio Bortoluzzi, Sesto Menardo calabro, Italy	\N
345	0	0101000020E6100000FE00B562C9B62A4032CFA51364D94440		70 Rotonda Marani, Quarto Iorio calabro, Italy	\N
346	0	0101000020E61000002AD890C9F3362640A3C629DFD80F4640		69 Rotonda Ultimo, Zanella calabro, Italy	\N
347	0	0101000020E610000098F0958AD7422540F3DD52735E994640		1 Borgo Imelda, Manno laziale, Italy	\N
348	0	0101000020E6100000451B36806D772640B99BF1C7FE074740		95 Borgo Ragone, San Adina sardo, Italy	\N
349	0	0101000020E61000008948A8740B9027402B7D321015F14540		00 Rotonda Icaro, De Giorgio calabro, Italy	\N
350	0	0101000020E6100000484B8A3496612B40F1F44A5986DF4640		24 Incrocio Aidano, Catanzaro sardo, Italy	\N
351	0	0101000020E610000006240626DCE0264059631A97BBDC4640		916 Via Emilia, Patrone lido, Italy	\N
352	0	0101000020E61000001A62067470422640EF6BC94F4FBD4540		799 Piazza Schiavi, Devota del friuli, Italy	\N
353	0	0101000020E6100000F0F1536694F425402F5D77A9C7134640		3 Via Liberio, Quarto Amabile, Italy	\N
354	0	0101000020E6100000A5DAA7E3317F2240E75E16C90DEF4640		45 Piazza Bianchetti, Impellizzeri terme, Italy	\N
355	0	0101000020E6100000D12E956D967D2C40126C5CFFAE6D4440		846 Strada Iona, Quarto Leo, Italy	\N
356	0	0101000020E6100000DD6CBDF0941F27409F515F3BBDDA4640		894 Via Vailati, Borgo Vinicio terme, Italy	\N
357	0	0101000020E610000096EA025E66002640FA4E82ED16F44540		78 Via Migliaccio, Ferro calabro, Italy	\N
358	0	0101000020E61000009DDE20B5E43C25407F83F6EAE39D4540		65 Incrocio Mastrogiacomo, San Onorino, Italy	\N
359	0	0101000020E6100000016E162F168E2340861BF0F9614A4440		924 Incrocio Marita, Elvia del friuli, Italy	\N
360	0	0101000020E61000009F32480BE1EA20405C8A50114CDA4640		4 Rotonda Mirabella, Settimo Tesauro, Italy	\N
361	0	0101000020E6100000618841052C422B400938DFE3A78E4640		899 Incrocio Ambrogio, Nunziata terme, Italy	\N
362	0	0101000020E6100000160F94803D132140276BD44334E04640		08 Rotonda Arminio, Valentini calabro, Italy	\N
363	0	0101000020E610000097A13BD22A4C25401A80B2CE9DD44540		06 Piazza Libero, Sesto Adriano a mare, Italy	\N
364	0	0101000020E6100000AD904D4DDD3827405B632BC313B14540		7 Rotonda Indro, Loddo terme, Italy	\N
365	0	0101000020E610000071E82D1EDEEB2C405F93DA30AF824440		6 Rotonda Tomei, Demontis del friuli, Italy	\N
366	0	0101000020E6100000DA48C8F6109B1F40EE2AFFB5176E4640		29 Rotonda Aloisio, Marchetti lido, Italy	\N
367	0	0101000020E61000004D028A4798F02740C38366D7BD264640		618 Contrada Ambrosino, San Stiliano, Italy	\N
368	0	0101000020E6100000BCB77DEAB38A2C404EF04DD3676E4440		201 Incrocio Palombo, Sesto Piersilvio del friuli, Italy	\N
369	0	0101000020E6100000CBC80F4BB93126404793E6EA22FD4640		77 Borgo De Bonis, Bergamasco veneto, Italy	\N
370	0	0101000020E6100000A68E9FD7E925284065677682A2C64640		387 Borgo Ida, Pession veneto, Italy	\N
371	0	0101000020E6100000407562C55F5D294091FC773359C24640		073 Contrada Pedrazzini, Borgo Archippo del friuli, Italy	\N
372	0	0101000020E6100000CF328B506C4D244070D63B37C8184640		3 Via Gagliano, Astrid lido, Italy	\N
373	0	0101000020E61000007E6E0D11DC1122409453967C47EB4640		189 Contrada Capponi, Rosamunda salentino, Italy	\N
374	0	0101000020E610000043A44BA4D989204072A8DF85ADD34640		8 Via Flore, Visintin umbro, Italy	\N
375	0	0101000020E61000004371C79BFC022C404AF5F81807254540		00 Incrocio Vulpiano, Quarto Nicol� nell'emilia, Italy	\N
376	0	0101000020E61000009EA74B10BFA422400292FAFC41944440		59 Rotonda Menozzi, Settimo Camilla lido, Italy	\N
377	0	0101000020E61000000D88B59D5B012C40CF70B9B024144540		88 Borgo Ansaldo, San Diego, Italy	\N
378	0	0101000020E610000059935D1F8CFE26407E6DA23B2D3B4640		606 Via Glauco, Borgo Antonia, Italy	\N
379	0	0101000020E6100000D50451F7010829403B736AC2510D4640		4 Rotonda Fatima, Cusumano laziale, Italy	\N
380	0	0101000020E6100000CD6152D735012740D65F6523C6394640		0 Rotonda Ester, Bartoli veneto, Italy	\N
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hike_track_points ("userHikeId", index, "pointId", datetime) FROM stdin;
\.


--
-- Data for Name: user_hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes (id, "userId", "hikeId", "startedAt", "updatedAt", "finishedAt", "psTotalKms", "psHighestAltitude", "psAltitudeRange", "psTotalTimeMinutes", "psAverageSpeed", "psAverageVerticalAscentSpeed", "maxElapsedTime", "weatherNotified", "unfinishedNotified") FROM stdin;
\.


--
-- Data for Name: user_hikes_track_points_user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes_track_points_user_hike_track_points ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash", approved, preferences, "plannedHikes") FROM stdin;
2	$2b$10$L8sxX0iW3XOeZ98amx9y4u6k5L6wZ7/gWJTjvZuTjFGkvG08YhDUu	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N	f	\N	\N
4	$2b$10$0bDYKHxgP6RafoD6nDs69.lyJ5UX3OWHJZeTbEPL6X/OnDbYTwsKe	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N	f	\N	\N
5	$2b$10$EkArUU3WnaAF2mOsUAgLQOsKIs9Jgtl9KoFPsVScQUap3mqtRTGZe	Laura	Zurru	5	laura@emergency.it	\N	t	\N	f	\N	\N
1	$2b$10$n.At0qJ8b.kkN25Nog03KOlrMOUFZiUwtxFHbawkHIExTAKnTi7OW	German	Gorodnev	0	german@hiker.it	\N	t	\N	f	\N	\N
3	$2b$10$a.Ifept8JrHDZYPpwb5.1e.NYGdWbVOBGSntq3Wbp4VgSTPELqAWW	vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N	f	\N	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 5, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 108, true);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 256, true);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 380, true);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_hikes_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

