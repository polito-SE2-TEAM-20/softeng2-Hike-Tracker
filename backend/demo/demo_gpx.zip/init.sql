--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: hike_points PK_7fc686c35c52228d8494a7c4947; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_7fc686c35c52228d8494a7c4947" PRIMARY KEY ("hikeId", "pointId");


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$fe0etjWRCC4aiCAHl3na1O6MUjanWL6SpDDujYi2F1blvzNHBb2iC',
    'Antonio',
    'Battipaglia',
    2,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$cc.I9g0eb/Ghank/TQn2huvv9Q5eg3wUhkJFRKH71f.hfSANdPaK2',
    'Erfan',
    'Gholami',
    4,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$sU9tsTaqBDlkyKpFc3PPrOATO0hWtribrKYd.6WhM1g5KrpZFAKBW',
    'Laura',
    'Zurru',
    5,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$XhGVBCoI7RigTIlCH5Q/seGXAfjNZsABpG/4gocC0kAEux3aNqbTi',
    'German',
    'Gorodnev',
    0,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$uxIXWvdWmgxG6XoKAqywtOvasZS8rDylTsnO7ylcTIt29sybmZNm6',
    'vincenzo',
    'Sagristano',
    3,
    true
  );
  

      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Airline Trail - Detour',
        0,
        '/static/gpx/001_Airline_Trail___Detour.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Airline Trail',
        2,
        '/static/gpx/002_Airline_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Colchester Railroad',
        0,
        '/static/gpx/003_Colchester_Railroad.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Willimantic Flower Bridge',
        0,
        '/static/gpx/004_Willimantic_Flower_Bridge.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Willimantic Pedestrian Bridge',
        2,
        '/static/gpx/005_Willimantic_Pedestrian_Bridge.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Two Sister''S Preserve Loop Trail',
        2,
        '/static/gpx/006_Two_Sister_S_Preserve_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Putnam River Trail',
        0,
        '/static/gpx/007_Putnam_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Airline Trail Bypass',
        2,
        '/static/gpx/008_Airline_Trail_Bypass.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Indian Neck',
        0,
        '/static/gpx/009_Indian_Neck.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Stony Creek',
        2,
        '/static/gpx/010_Stony_Creek.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quarry-Westwoods',
        0,
        '/static/gpx/011_Quarry_Westwoods.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Short Beach',
        2,
        '/static/gpx/012_Short_Beach.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Charter Oak Greenway',
        2,
        '/static/gpx/013_Charter_Oak_Greenway.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bissell Greenway',
        1,
        '/static/gpx/014_Bissell_Greenway.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Riverfront Trail System',
        1,
        '/static/gpx/015_Riverfront_Trail_System.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Millers Pond Park Trail',
        2,
        '/static/gpx/016_Millers_Pond_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mattabesett Trail',
        2,
        '/static/gpx/017_Mattabesett_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Jefferson Park Trail',
        2,
        '/static/gpx/018_Jefferson_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Cockaponset Trail',
        2,
        '/static/gpx/019_Cockaponset_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mt. Nebo Park',
        2,
        '/static/gpx/020_Mt__Nebo_Park.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        ' ',
        2,
        '/static/gpx/021__.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Proposed Trail',
        2,
        '/static/gpx/022_Proposed_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Blinnshed Ridge Trail',
        2,
        '/static/gpx/023_Blinnshed_Ridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Neck River Trail',
        2,
        '/static/gpx/024_Neck_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Unnamed Trail',
        2,
        '/static/gpx/025_Unnamed_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Oil Mill Brook Trail',
        2,
        '/static/gpx/026_Oil_Mill_Brook_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Chatfield Trail',
        2,
        '/static/gpx/027_Chatfield_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Unamed Trail',
        2,
        '/static/gpx/028_Unamed_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Lost Pond Trail',
        2,
        '/static/gpx/029_Lost_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Ccc Camp Hadley Trail',
        2,
        '/static/gpx/030_Ccc_Camp_Hadley_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Double Loop Trail',
        2,
        '/static/gpx/031_Double_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Over Brook Trail',
        2,
        '/static/gpx/032_Over_Brook_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Cockaponset Forest Trail',
        2,
        '/static/gpx/033_Cockaponset_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pattaconk Trail',
        2,
        '/static/gpx/034_Pattaconk_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Westwoods Forest Trail',
        2,
        '/static/gpx/035_Westwoods_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Blinnshed Loop Trail',
        2,
        '/static/gpx/036_Blinnshed_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Unnamed Tsail',
        2,
        '/static/gpx/037_Unnamed_Tsail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Messerschmidt Wma Trail',
        1,
        '/static/gpx/038_Messerschmidt_Wma_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Westwoods Nature Trail',
        2,
        '/static/gpx/039_Westwoods_Nature_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Enduro',
        2,
        '/static/gpx/040_Enduro.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Land Trust Trail',
        2,
        '/static/gpx/041_Land_Trust_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Beaver Brook Park Trail',
        1,
        '/static/gpx/042_Beaver_Brook_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Housatonic Forest Trail',
        0,
        '/static/gpx/043_Housatonic_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Farmington Canal Trail',
        2,
        '/static/gpx/044_Farmington_Canal_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Beckley Furnace Park Path',
        1,
        '/static/gpx/045_Beckley_Furnace_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Farmington River Trail',
        0,
        '/static/gpx/046_Farmington_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Farminton Canal Trail',
        2,
        '/static/gpx/047_Farminton_Canal_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Farminton River Trail',
        2,
        '/static/gpx/048_Farminton_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hop River Trail',
        1,
        '/static/gpx/049_Hop_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hoprivertrail - Detouraround316',
        2,
        '/static/gpx/050_Hoprivertrail___Detouraround316.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hop River Trail - Long Hill Rd.',
        2,
        '/static/gpx/051_Hop_River_Trail___Long_Hill_Rd_.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hop River Trail - Rockville Spur',
        0,
        '/static/gpx/052_Hop_River_Trail___Rockville_Spur.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Housatonic Rail Trail',
        0,
        '/static/gpx/053_Housatonic_Rail_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Middletown Bikeway',
        2,
        '/static/gpx/054_Middletown_Bikeway.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mattabesett Trolley Trail',
        2,
        '/static/gpx/055_Mattabesett_Trolley_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Moosup Valley State Park Trail',
        0,
        '/static/gpx/056_Moosup_Valley_State_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinnebaug River Trail',
        1,
        '/static/gpx/057_Quinnebaug_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tracey Road Trail',
        2,
        '/static/gpx/058_Tracey_Road_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Trolley Trail',
        2,
        '/static/gpx/059_Trolley_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinnebaug Hatchery Trail',
        2,
        '/static/gpx/060_Quinnebaug_Hatchery_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hopeville Park Trail',
        2,
        '/static/gpx/061_Hopeville_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hopeville Park Path',
        0,
        '/static/gpx/062_Hopeville_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nehantic Trail',
        2,
        '/static/gpx/063_Nehantic_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Camp Columbia Trail',
        1,
        '/static/gpx/064_Camp_Columbia_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shelton Land Trust Trail',
        1,
        '/static/gpx/065_Shelton_Land_Trust_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Dinosaur Park Sidewalk',
        0,
        '/static/gpx/066_Dinosaur_Park_Sidewalk.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Dinosaur Park Trail',
        1,
        '/static/gpx/067_Dinosaur_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Access Road',
        1,
        '/static/gpx/068_Access_Road.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Day Pond Park Path',
        2,
        '/static/gpx/069_Day_Pond_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Day Pond Park Trail',
        1,
        '/static/gpx/070_Day_Pond_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Salmon River Trail',
        1,
        '/static/gpx/071_Salmon_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Salmon River Trial',
        2,
        '/static/gpx/072_Salmon_River_Trial.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Dennis Hill Park Trail',
        2,
        '/static/gpx/073_Dennis_Hill_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Railroad Trail',
        1,
        '/static/gpx/074_Railroad_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Gillette Castle Trail',
        0,
        '/static/gpx/075_Gillette_Castle_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kent Falls Park Path',
        0,
        '/static/gpx/076_Kent_Falls_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kent Falls Park Trail',
        1,
        '/static/gpx/077_Kent_Falls_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Lovers Leap Park Trail',
        1,
        '/static/gpx/078_Lovers_Leap_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Enders Forest Trail',
        0,
        '/static/gpx/079_Enders_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Gay City Park Path',
        0,
        '/static/gpx/080_Gay_City_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Gay City Park Trail',
        2,
        '/static/gpx/081_Gay_City_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Split Rock Trail',
        0,
        '/static/gpx/082_Split_Rock_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Gillette Castle Path',
        2,
        '/static/gpx/083_Gillette_Castle_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Great Pond Forest Trail',
        0,
        '/static/gpx/084_Great_Pond_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Haddam Meadows Park Trail',
        0,
        '/static/gpx/085_Haddam_Meadows_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Haley Farm Park Trail',
        1,
        '/static/gpx/086_Haley_Farm_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hammonasset Park Path',
        2,
        '/static/gpx/087_Hammonasset_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nature Trail',
        1,
        '/static/gpx/088_Nature_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hammonasset Bike Path',
        0,
        '/static/gpx/089_Hammonasset_Bike_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hammonasset Park Boardwalk',
        0,
        '/static/gpx/090_Hammonasset_Park_Boardwalk.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Meigs Point Jetty',
        1,
        '/static/gpx/091_Meigs_Point_Jetty.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Willard Island Nature Trail',
        2,
        '/static/gpx/092_Willard_Island_Nature_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Moraine Nature Trail',
        0,
        '/static/gpx/093_Moraine_Nature_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Haystack Park Trail',
        0,
        '/static/gpx/094_Haystack_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Higganum Reservoir Park Trail',
        0,
        '/static/gpx/095_Higganum_Reservoir_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Appalachian Trail',
        1,
        '/static/gpx/096_Appalachian_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mohawk Trail',
        0,
        '/static/gpx/097_Mohawk_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pine Knob Loop',
        0,
        '/static/gpx/098_Pine_Knob_Loop.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Appalachian/Pine Knob Loop',
        2,
        '/static/gpx/099_Appalachian_Pine_Knob_Loop.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'White Mountain Trail',
        1,
        '/static/gpx/100_White_Mountain_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'River Trail',
        0,
        '/static/gpx/101_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hurd Park Trail',
        0,
        '/static/gpx/102_Hurd_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hurd Park Path',
        2,
        '/static/gpx/103_Hurd_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Paugussett Trail',
        2,
        '/static/gpx/104_Paugussett_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Waterfall Trail',
        2,
        '/static/gpx/105_Waterfall_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Paugussett Trail Connector',
        1,
        '/static/gpx/106_Paugussett_Trail_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Minetto Park Trail',
        2,
        '/static/gpx/107_Minetto_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Coincident Macedonia Brook Rd',
        2,
        '/static/gpx/108_Coincident_Macedonia_Brook_Rd.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Coincident Weber Road',
        0,
        '/static/gpx/109_Coincident_Weber_Road.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Macedonia Ridge Trail',
        0,
        '/static/gpx/110_Macedonia_Ridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Cobble Mountain Trail',
        2,
        '/static/gpx/111_Cobble_Mountain_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shenipsit Trail',
        2,
        '/static/gpx/112_Shenipsit_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Meshomasic Forest Trail',
        1,
        '/static/gpx/113_Meshomasic_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Crest Trail',
        1,
        '/static/gpx/114_Crest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Campground Trail',
        2,
        '/static/gpx/115_Campground_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Brook Trail',
        2,
        '/static/gpx/116_Brook_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kettletown Park Trail',
        0,
        '/static/gpx/117_Kettletown_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'North Ridge Trail',
        2,
        '/static/gpx/118_North_Ridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'North Ridge Loop Trail',
        0,
        '/static/gpx/119_North_Ridge_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Miller Brook Connector Trail',
        2,
        '/static/gpx/120_Miller_Brook_Connector_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Miller Trail',
        2,
        '/static/gpx/121_Miller_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Miller Trail Spur',
        1,
        '/static/gpx/122_Miller_Trail_Spur.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pomperaug Trail',
        0,
        '/static/gpx/123_Pomperaug_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Brook Trail Access',
        1,
        '/static/gpx/124_Brook_Trail_Access.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Waramaug Lake Park Trail',
        1,
        '/static/gpx/125_Waramaug_Lake_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Well Groomed Trail',
        0,
        '/static/gpx/126_Well_Groomed_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mashamoquet Brook Park Trail',
        2,
        '/static/gpx/127_Mashamoquet_Brook_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shenipsit Trail Spur',
        0,
        '/static/gpx/128_Shenipsit_Trail_Spur.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shenipsit',
        0,
        '/static/gpx/129_Shenipsit.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nassahegon Forest Trail',
        0,
        '/static/gpx/130_Nassahegon_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tunxis Trail',
        1,
        '/static/gpx/131_Tunxis_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Black Spruce Bog Trail',
        1,
        '/static/gpx/132_Black_Spruce_Bog_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mohawk Forest Trail',
        1,
        '/static/gpx/133_Mohawk_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Ethan Allen Youth Trail',
        2,
        '/static/gpx/134_Ethan_Allen_Youth_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Punch Brook Trail',
        0,
        '/static/gpx/135_Punch_Brook_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Red Cedar Lake Trail',
        1,
        '/static/gpx/136_Red_Cedar_Lake_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Under Mountain Trail',
        1,
        '/static/gpx/137_Under_Mountain_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mount Tom Trail',
        0,
        '/static/gpx/138_Mount_Tom_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Naugatuck Trail',
        1,
        '/static/gpx/139_Naugatuck_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nehantic Forest Trail',
        2,
        '/static/gpx/140_Nehantic_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Naugatuck Forest Trail',
        0,
        '/static/gpx/141_Naugatuck_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Naugatuck Spur',
        1,
        '/static/gpx/142_Naugatuck_Spur.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Whitemore Trail',
        0,
        '/static/gpx/143_Whitemore_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinnipiac Trail',
        0,
        '/static/gpx/144_Quinnipiac_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nehantic Forest Trai',
        2,
        '/static/gpx/145_Nehantic_Forest_Trai.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nepaug Forest Trail',
        0,
        '/static/gpx/146_Nepaug_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Naugatuck',
        0,
        '/static/gpx/147_Naugatuck.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nyantaquit Trail',
        1,
        '/static/gpx/148_Nyantaquit_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tipping Rock Loop Trail',
        1,
        '/static/gpx/149_Tipping_Rock_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Valley Outlook Trail',
        2,
        '/static/gpx/150_Valley_Outlook_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shelter 4 Loop Trail',
        1,
        '/static/gpx/151_Shelter_4_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Osbornedale Park Trail',
        2,
        '/static/gpx/152_Osbornedale_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Unnamed',
        0,
        '/static/gpx/153_Unnamed.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Paugnut Forest Trail',
        0,
        '/static/gpx/154_Paugnut_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Charles L Pack Trail',
        1,
        '/static/gpx/155_Charles_L_Pack_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Peoples Forest Trail',
        2,
        '/static/gpx/156_Peoples_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Putnam Memorial Trail',
        1,
        '/static/gpx/157_Putnam_Memorial_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Platt Hill Park Trail',
        2,
        '/static/gpx/158_Platt_Hill_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Metacomet Trail',
        0,
        '/static/gpx/159_Metacomet_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Metacomet Trail Bypass',
        0,
        '/static/gpx/160_Metacomet_Trail_Bypass.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Penwood Park Trail',
        0,
        '/static/gpx/161_Penwood_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quadick Park Path',
        1,
        '/static/gpx/162_Quadick_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quadick Red Trail',
        2,
        '/static/gpx/163_Quadick_Red_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pootatuck Forest Trail',
        0,
        '/static/gpx/164_Pootatuck_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'River Highland Park Trail',
        1,
        '/static/gpx/165_River_Highland_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tunxis',
        1,
        '/static/gpx/166_Tunxis.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Old Furnace Trail',
        1,
        '/static/gpx/167_Old_Furnace_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Old Furnace Park Trail',
        1,
        '/static/gpx/168_Old_Furnace_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kestral Trail',
        1,
        '/static/gpx/169_Kestral_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Warbler Trail',
        1,
        '/static/gpx/170_Warbler_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Muir Trail',
        0,
        '/static/gpx/171_Muir_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shadow Pond Nature Trail',
        2,
        '/static/gpx/172_Shadow_Pond_Nature_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Jesse Gerard Trail',
        1,
        '/static/gpx/173_Jesse_Gerard_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Robert Ross Trail',
        1,
        '/static/gpx/174_Robert_Ross_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Agnes Bowen Trail',
        0,
        '/static/gpx/175_Agnes_Bowen_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Elliot Bronson Trail',
        0,
        '/static/gpx/176_Elliot_Bronson_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Walt Landgraf Trail',
        2,
        '/static/gpx/177_Walt_Landgraf_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Squantz Pond Park Trail',
        2,
        '/static/gpx/178_Squantz_Pond_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Putnam Memorial Museum Trail',
        2,
        '/static/gpx/179_Putnam_Memorial_Museum_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinnipiac Park Trail',
        0,
        '/static/gpx/180_Quinnipiac_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Boardwalk',
        0,
        '/static/gpx/181_Boardwalk.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Rocky Neck Park Sidewalk',
        1,
        '/static/gpx/182_Rocky_Neck_Park_Sidewalk.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Rocky Neck Park Path',
        0,
        '/static/gpx/183_Rocky_Neck_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Rocky Neck Park Trail',
        2,
        '/static/gpx/184_Rocky_Neck_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Rope Swing',
        0,
        '/static/gpx/185_Rope_Swing.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sherwood Island Park Path',
        1,
        '/static/gpx/186_Sherwood_Island_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sleeping Giant Park Trail',
        0,
        '/static/gpx/187_Sleeping_Giant_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sherwood Island Nature Trail',
        1,
        '/static/gpx/188_Sherwood_Island_Nature_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sleeping Giant Park Path',
        0,
        '/static/gpx/189_Sleeping_Giant_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tower Trail',
        2,
        '/static/gpx/190_Tower_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinnipiac Trail Spur',
        1,
        '/static/gpx/191_Quinnipiac_Trail_Spur.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Southford Falls Park Trail',
        0,
        '/static/gpx/192_Southford_Falls_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tunxis Forest Trail',
        2,
        '/static/gpx/193_Tunxis_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sleeping Giant Trail',
        0,
        '/static/gpx/194_Sleeping_Giant_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Stratton Brook Park Path',
        1,
        '/static/gpx/195_Stratton_Brook_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bike Trail',
        2,
        '/static/gpx/196_Bike_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Stratton Brook Park Trail',
        2,
        '/static/gpx/197_Stratton_Brook_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Simsbury Park Trail',
        1,
        '/static/gpx/198_Simsbury_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Wolcott Trail',
        1,
        '/static/gpx/199_Wolcott_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Madden Fyler Pond Trail',
        0,
        '/static/gpx/200_Madden_Fyler_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sunny Brook Park Trail',
        1,
        '/static/gpx/201_Sunny_Brook_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Fadoir Spring Trail',
        0,
        '/static/gpx/202_Fadoir_Spring_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Fadoir Trail',
        2,
        '/static/gpx/203_Fadoir_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Walnut Mountain Trail',
        1,
        '/static/gpx/204_Walnut_Mountain_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Wolcott',
        1,
        '/static/gpx/205_Wolcott.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Old Metacomet Trail',
        2,
        '/static/gpx/206_Old_Metacomet_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Talcott Mountain Park Trail',
        1,
        '/static/gpx/207_Talcott_Mountain_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Falls Brook Trail',
        2,
        '/static/gpx/208_Falls_Brook_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Whittemore Glen Trail',
        2,
        '/static/gpx/209_Whittemore_Glen_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Wharton Brook Park Trail',
        0,
        '/static/gpx/210_Wharton_Brook_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Larkin Bridle Trail',
        0,
        '/static/gpx/211_Larkin_Bridle_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bluff Point Bike Path',
        0,
        '/static/gpx/212_Bluff_Point_Bike_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bluff Point Trail',
        0,
        '/static/gpx/213_Bluff_Point_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hrt - Main Street Spur',
        0,
        '/static/gpx/214_Hrt___Main_Street_Spur.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Laurel Brook Trail',
        2,
        '/static/gpx/215_Laurel_Brook_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Wadsworth Falls Park Trail',
        2,
        '/static/gpx/216_Wadsworth_Falls_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'White Birch Trail',
        2,
        '/static/gpx/217_White_Birch_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Red Cedar Trail',
        2,
        '/static/gpx/218_Red_Cedar_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Little Falls Trail',
        2,
        '/static/gpx/219_Little_Falls_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Deer Trail',
        2,
        '/static/gpx/220_Deer_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Rockfall Land Trust Trail',
        2,
        '/static/gpx/221_Rockfall_Land_Trust_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bridge Trail',
        2,
        '/static/gpx/222_Bridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Main Trail',
        2,
        '/static/gpx/223_Main_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'American Legion Forest Trail',
        2,
        '/static/gpx/224_American_Legion_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Turkey Vultures Ledges Trail',
        2,
        '/static/gpx/225_Turkey_Vultures_Ledges_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Henry R Buck Trail',
        2,
        '/static/gpx/226_Henry_R_Buck_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mashapaug Pond View Trail',
        2,
        '/static/gpx/227_Mashapaug_Pond_View_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bigelow Hollow Park Trail',
        2,
        '/static/gpx/228_Bigelow_Hollow_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Breakneck Pond View Trail',
        2,
        '/static/gpx/229_Breakneck_Pond_View_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'East Ridge Trail',
        2,
        '/static/gpx/230_East_Ridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bigelow Pond Loop Trail',
        2,
        '/static/gpx/231_Bigelow_Pond_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Ridge Trail',
        2,
        '/static/gpx/232_Ridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nipmuck Trail',
        2,
        '/static/gpx/233_Nipmuck_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mattatuck Trail',
        2,
        '/static/gpx/234_Mattatuck_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Black Rock Park Trail',
        2,
        '/static/gpx/235_Black_Rock_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Poquonnock River Walk',
        0,
        '/static/gpx/236_Poquonnock_River_Walk.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kempf & Shenipsit Trail',
        0,
        '/static/gpx/237_Kempf___Shenipsit_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kempf Trail',
        0,
        '/static/gpx/238_Kempf_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Railroad Bed',
        1,
        '/static/gpx/239_Railroad_Bed.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mohegan Trail',
        2,
        '/static/gpx/240_Mohegan_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Burr Pond Park Trail',
        0,
        '/static/gpx/241_Burr_Pond_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Burr Pond Park Path',
        2,
        '/static/gpx/242_Burr_Pond_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Campbell Falls Trail',
        1,
        '/static/gpx/243_Campbell_Falls_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Deep Woods Trail',
        2,
        '/static/gpx/244_Deep_Woods_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Chimney Trail',
        2,
        '/static/gpx/245_Chimney_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Chimney Connector Trail',
        2,
        '/static/gpx/246_Chimney_Connector_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'East Woods Trail',
        2,
        '/static/gpx/247_East_Woods_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'East Woods Connector Trail',
        2,
        '/static/gpx/248_East_Woods_Connector_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Covered Bridge Connector Trail',
        2,
        '/static/gpx/249_Covered_Bridge_Connector_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Covered Bridge Trail',
        2,
        '/static/gpx/250_Covered_Bridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Lookout Trail',
        2,
        '/static/gpx/251_Lookout_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Chatfield Hollow Park Trail',
        2,
        '/static/gpx/252_Chatfield_Hollow_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Lookout Spur Trail',
        2,
        '/static/gpx/253_Lookout_Spur_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Chimney Spur Trail',
        2,
        '/static/gpx/254_Chimney_Spur_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Deep Woods Access Trail',
        2,
        '/static/gpx/255_Deep_Woods_Access_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'West Crest Trail',
        2,
        '/static/gpx/256_West_Crest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Chatfield Park Path',
        2,
        '/static/gpx/257_Chatfield_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pond Trail',
        2,
        '/static/gpx/258_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Paul F Wildermann',
        0,
        '/static/gpx/259_Paul_F_Wildermann.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Cockaponset Forest Path',
        2,
        '/static/gpx/260_Cockaponset_Forest_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kay Fullerton Trail',
        2,
        '/static/gpx/261_Kay_Fullerton_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinimay Trail',
        2,
        '/static/gpx/262_Quinimay_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Cowboy Way Trail',
        2,
        '/static/gpx/263_Cowboy_Way_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Muck Rock Road Trail',
        2,
        '/static/gpx/264_Muck_Rock_Road_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Weber Road Trail',
        2,
        '/static/gpx/265_Weber_Road_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Beechnut Bog Trail',
        2,
        '/static/gpx/266_Beechnut_Bog_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Wood Road Trail',
        2,
        '/static/gpx/267_Wood_Road_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bumpy Hill Road Trail',
        2,
        '/static/gpx/268_Bumpy_Hill_Road_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kristens Way Trail',
        2,
        '/static/gpx/269_Kristens_Way_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Messerschmidt Lane Trail',
        2,
        '/static/gpx/270_Messerschmidt_Lane_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tower Hill Connector Trail',
        2,
        '/static/gpx/271_Tower_Hill_Connector_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mattabesset Trail',
        2,
        '/static/gpx/272_Mattabesset_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mattabasset Trail',
        2,
        '/static/gpx/273_Mattabasset_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Old Mattebesset Trail',
        2,
        '/static/gpx/274_Old_Mattebesset_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Huntington Park Trail',
        2,
        '/static/gpx/275_Huntington_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Huntington Ridge Trail',
        2,
        '/static/gpx/276_Huntington_Ridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Aspetuck Valley Trail',
        2,
        '/static/gpx/277_Aspetuck_Valley_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Vista Trail',
        2,
        '/static/gpx/278_Vista_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Devils Hopyard Park Trail',
        2,
        '/static/gpx/279_Devils_Hopyard_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Witch Hazel/Millington Trail',
        2,
        '/static/gpx/280_Witch_Hazel_Millington_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Millington Trail',
        2,
        '/static/gpx/281_Millington_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Loop Trail',
        2,
        '/static/gpx/282_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Witch Hazel Trail',
        2,
        '/static/gpx/283_Witch_Hazel_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Woodcutters Trail',
        2,
        '/static/gpx/284_Woodcutters_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Chapman Falls Trail',
        2,
        '/static/gpx/285_Chapman_Falls_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Devils Oven Spur Trail',
        2,
        '/static/gpx/286_Devils_Oven_Spur_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Maxs Trail',
        2,
        '/static/gpx/287_Maxs_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Machimoodus Park Trail',
        2,
        '/static/gpx/288_Machimoodus_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Fishermans Trail',
        1,
        '/static/gpx/289_Fishermans_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Ccc Trail',
        2,
        '/static/gpx/290_Ccc_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Natchaug Trail',
        2,
        '/static/gpx/291_Natchaug_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Natchaug Forest Trail',
        2,
        '/static/gpx/292_Natchaug_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Goodwin Forest Trail',
        2,
        '/static/gpx/293_Goodwin_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pine Acres Pond Trail',
        2,
        '/static/gpx/294_Pine_Acres_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Brown Hill Pond Trail',
        2,
        '/static/gpx/295_Brown_Hill_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Yellow White Loop Trail',
        2,
        '/static/gpx/296_Yellow_White_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Red Yellow Connector Trail',
        2,
        '/static/gpx/297_Red_Yellow_Connector_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Governor''S Island Trail',
        2,
        '/static/gpx/298_Governor_S_Island_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Goodwin Foresttrail',
        2,
        '/static/gpx/299_Goodwin_Foresttrail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Forest Discovery Trail',
        2,
        '/static/gpx/300_Forest_Discovery_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Goodwin Heritage Trail',
        2,
        '/static/gpx/301_Goodwin_Heritage_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Crest',
        2,
        '/static/gpx/302_Crest.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mansfield Hollow Park Trail',
        0,
        '/static/gpx/303_Mansfield_Hollow_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nipmuck Trail - East Branch',
        2,
        '/static/gpx/304_Nipmuck_Trail___East_Branch.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nipmuck Alternate',
        1,
        '/static/gpx/305_Nipmuck_Alternate.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mashamoquet Brook Nature Trail',
        0,
        '/static/gpx/306_Mashamoquet_Brook_Nature_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nipmuck Forest Trail',
        2,
        '/static/gpx/307_Nipmuck_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Morey Pond Trail',
        2,
        '/static/gpx/308_Morey_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nipmuck Foreat Trail',
        2,
        '/static/gpx/309_Nipmuck_Foreat_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pharisee Rock Trail',
        2,
        '/static/gpx/310_Pharisee_Rock_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pachaug Forest Trail',
        2,
        '/static/gpx/311_Pachaug_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pachaug Trail',
        2,
        '/static/gpx/312_Pachaug_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Canonicus Trail',
        2,
        '/static/gpx/313_Canonicus_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pachaug',
        2,
        '/static/gpx/314_Pachaug.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Laurel Loop Trail',
        2,
        '/static/gpx/315_Laurel_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pachaug/Nehantic Connector',
        2,
        '/static/gpx/316_Pachaug_Nehantic_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pachaug/Tippecansett Connector',
        2,
        '/static/gpx/317_Pachaug_Tippecansett_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nehantic/Pachaug Connector',
        2,
        '/static/gpx/318_Nehantic_Pachaug_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinebaug/Pachaug Connector',
        2,
        '/static/gpx/319_Quinebaug_Pachaug_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinebaug Trail',
        2,
        '/static/gpx/320_Quinebaug_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pachaug/Narragansett Connector',
        2,
        '/static/gpx/321_Pachaug_Narragansett_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Narragansett Trail',
        2,
        '/static/gpx/322_Narragansett_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Green Falls Loop Trail',
        2,
        '/static/gpx/323_Green_Falls_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Green Falls Water Access Trail',
        2,
        '/static/gpx/324_Green_Falls_Water_Access_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Freeman Trail',
        2,
        '/static/gpx/325_Freeman_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tippecansett Trail',
        2,
        '/static/gpx/326_Tippecansett_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tippecansett/Freeman Trail',
        2,
        '/static/gpx/327_Tippecansett_Freeman_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Green Falls Pond Trail',
        1,
        '/static/gpx/328_Green_Falls_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nehantic/Pachaug Trail',
        2,
        '/static/gpx/329_Nehantic_Pachaug_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Phillips Pond Spur Trail',
        2,
        '/static/gpx/330_Phillips_Pond_Spur_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinebaug/Nehantic Connector',
        2,
        '/static/gpx/331_Quinebaug_Nehantic_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nehantic/Quinebaug Connector',
        0,
        '/static/gpx/332_Nehantic_Quinebaug_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Patagansett Trail',
        0,
        '/static/gpx/333_Patagansett_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Paugussett Forest Trail',
        2,
        '/static/gpx/334_Paugussett_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Zoar Trail',
        2,
        '/static/gpx/335_Zoar_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Lillinonah Trail',
        2,
        '/static/gpx/336_Lillinonah_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Zoar Trail (Old)',
        2,
        '/static/gpx/337_Zoar_Trail__Old_.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Upper Gussy Trail',
        1,
        '/static/gpx/338_Upper_Gussy_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pierrepont Park Trail',
        2,
        '/static/gpx/339_Pierrepont_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shenipsit Forest Trail',
        2,
        '/static/gpx/340_Shenipsit_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quary Trail',
        2,
        '/static/gpx/341_Quary_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shenipsit Forest Road',
        2,
        '/static/gpx/342_Shenipsit_Forest_Road.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Topsmead Forest Trail',
        2,
        '/static/gpx/343_Topsmead_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Edith M Chase Ecology Trail',
        2,
        '/static/gpx/344_Edith_M_Chase_Ecology_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bernard H Stairs Trail',
        2,
        '/static/gpx/345_Bernard_H_Stairs_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'West Rock Park Trail',
        2,
        '/static/gpx/346_West_Rock_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'West Rock Summit Trail',
        2,
        '/static/gpx/347_West_Rock_Summit_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Regicides Trail',
        2,
        '/static/gpx/348_Regicides_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sanford Feeder Trail',
        2,
        '/static/gpx/349_Sanford_Feeder_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'North Summit Trail',
        2,
        '/static/gpx/350_North_Summit_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Westville Feeder Trail',
        2,
        '/static/gpx/351_Westville_Feeder_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'West Rock Park Road',
        2,
        '/static/gpx/352_West_Rock_Park_Road.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bennetts Pond Trail',
        1,
        '/static/gpx/353_Bennetts_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Ives Trail',
        2,
        '/static/gpx/354_Ives_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Ridgefield Open Space Trail',
        0,
        '/static/gpx/355_Ridgefield_Open_Space_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'George Dudley Seymour Park Trail',
        2,
        '/static/gpx/356_George_Dudley_Seymour_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Grta',
        1,
        '/static/gpx/357_Grta.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mohegan Forest Trail',
        0,
        '/static/gpx/358_Mohegan_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mount Bushnell Trail',
        2,
        '/static/gpx/359_Mount_Bushnell_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nye Holman Trail',
        2,
        '/static/gpx/360_Nye_Holman_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Al''S Trail',
        2,
        '/static/gpx/361_Al_S_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Salt Rock State Park Trail',
        2,
        '/static/gpx/362_Salt_Rock_State_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Scantic River Trail',
        1,
        '/static/gpx/363_Scantic_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Scantic River Park Trail',
        0,
        '/static/gpx/364_Scantic_River_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Scantic Park Access',
        2,
        '/static/gpx/365_Scantic_Park_Access.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sunrise Park Trail',
        0,
        '/static/gpx/366_Sunrise_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kitchel Trail',
        0,
        '/static/gpx/367_Kitchel_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Old Driveway',
        0,
        '/static/gpx/368_Old_Driveway.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kitchel',
        2,
        '/static/gpx/369_Kitchel.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Driveway',
        1,
        '/static/gpx/370_Driveway.gpx',
        'USA'
      );
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        1,
        120,
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Julie Konopelski',
        'http://welcome-antiquity.biz'
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        5,
        116,
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Dr. Brandi Schowalter',
        'https://bad-joint.name'
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        5,
        53,
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Cesar Rolfson',
        'https://marvelous-aglet.com'
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        5,
        73,
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Dr. Delbert Becker',
        'https://scholarly-dynamite.com'
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        10,
        50,
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Phillip Boyer',
        'http://classic-armpit.biz'
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        8,
        82,
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Billy Konopelski',
        'http://monstrous-leveret.biz'
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        3,
        130,
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Cassandra Moore',
        'http://overlooked-monastery.com'
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        5,
        84,
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Craig Trantow',
        'https://crisp-hello.org'
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        2,
        137,
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Doreen Hilll III',
        'https://impressionable-microlending.net'
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        7,
        92,
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Ginger Gutkowski',
        'http://reckless-pint.info'
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        6,
        120,
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Dana O''Conner',
        'http://pleased-mouton.info'
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        7,
        66,
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Andrew Bashirian Sr.',
        'https://exemplary-flatboat.net'
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        1,
        97,
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Israel Williamson',
        'http://happy-homeland.net'
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        5,
        79,
        'Vernagthütte',
        'Austria',
        'Karla Wolff',
        'https://loving-parade.name'
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        5,
        52,
        'Wormser Hütte',
        'Austria',
        'Ernest Mann',
        'http://left-cloister.info'
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        2,
        84,
        'Biberacher Hütte',
        'Austria',
        'Bernice Gibson',
        'http://fast-diarist.info'
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        9,
        99,
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Bernard Denesik',
        'http://rundown-centurion.name'
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        6,
        96,
        'Hochwaldhütte',
        'Germany',
        'Ruth Kertzmann',
        'https://shameless-slope.org'
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        1,
        77,
        'Kölner Eifelhütte',
        'Germany',
        'Edgar Marquardt',
        'https://sudden-god.net'
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        2,
        65,
        'Madrisahütte',
        'Austria',
        'Cora Schimmel',
        'http://monumental-vermicelli.biz'
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        10,
        61,
        'Dresdner Hütte',
        'Austria',
        'Mindy Borer',
        'https://aged-periodical.com'
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        10,
        137,
        'Fiderepasshütte',
        'Germany',
        'Miss Luther Kertzmann',
        'http://primary-pond.org'
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        6,
        95,
        'Göppinger Hütte',
        'Austria',
        'Dr. Bryan Doyle',
        'http://far-off-chicken.net'
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        4,
        87,
        'Oberzalimhütte',
        'Austria',
        'Mr. Edith Koelpin',
        'http://pristine-crewmember.org'
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        4,
        144,
        'Rastkogelhütte',
        'Austria',
        'Colin Halvorson',
        'http://occasional-father-in-law.net'
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        2,
        43,
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Archie Jacobson',
        'http://torn-timetable.info'
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        3,
        68,
        'Kaltenberghütte',
        'Austria',
        'Heidi Muller',
        'http://impartial-blend.name'
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        5,
        97,
        'Schweinfurter Hütte',
        'Austria',
        'Brandy Kreiger',
        'https://possible-jealousy.net'
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        4,
        137,
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Christie Dooley',
        'http://peaceful-clan.biz'
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        1,
        50,
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Elbert Boehm',
        'https://aware-aquifer.biz'
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        1,
        113,
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Dr. Bryan Corkery',
        'http://knotty-due.org'
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        1,
        48,
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Amy Oberbrunner',
        'https://skeletal-charm.info'
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        10,
        90,
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Faye Tromp',
        'https://calm-tourism.net'
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        10,
        64,
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Raymond Fadel',
        'https://lovable-expense.info'
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        2,
        111,
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Jane Kassulke',
        'http://creamy-stupidity.net'
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        1,
        113,
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Elena Pollich',
        'https://lonely-stamina.info'
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        9,
        36,
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Carroll Lockman',
        'http://shameless-mythology.net'
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        5,
        86,
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Clay McClure Jr.',
        'http://brown-grape.biz'
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        6,
        131,
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Lillie Sanford',
        'http://which-meaning.com'
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        6,
        140,
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Ms. Elvira Waters',
        'https://foolhardy-pan.com'
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        9,
        36,
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Russell Stehr',
        'http://extraneous-riding.org'
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        4,
        57,
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Marcella Schmitt Sr.',
        'http://bare-tragedy.org'
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        1,
        72,
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Dawn Kshlerin',
        'http://velvety-triad.name'
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        6,
        96,
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Brett Conn',
        'http://unripe-circle.info'
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        6,
        105,
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Dr. Jessica O''Conner',
        'http://buzzing-impress.com'
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        3,
        101,
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Mrs. Thelma Feeney',
        'http://sour-linkage.info'
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        3,
        124,
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Hattie Hoeger',
        'http://any-pressure.biz'
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        10,
        129,
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Maryann Satterfield',
        'http://popular-consumption.biz'
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        6,
        70,
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Sherman Yost',
        'https://concerned-singer.biz'
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        4,
        90,
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Rolando Bosco',
        'https://joyful-stable.com'
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        2,
        127,
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Mike Hayes',
        'https://clear-baggie.info'
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        7,
        92,
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Flora Zulauf',
        'http://superb-collector.org'
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        1,
        103,
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Nancy Schumm',
        'https://puzzling-prelude.com'
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        4,
        105,
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Dr. Marjorie Emmerich',
        'https://decent-chin.net'
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        8,
        118,
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Randal Carroll',
        'http://aged-snarl.name'
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        5,
        40,
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Kim Koelpin',
        'https://severe-gig.biz'
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        9,
        109,
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Dr. Christy Pacocha II',
        'http://daring-blanket.info'
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        1,
        147,
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Marcia Boyle III',
        'https://frightened-infant.net'
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        3,
        122,
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Cameron Zulauf MD',
        'https://jubilant-zoot-suit.info'
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        7,
        47,
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Leigh Ferry',
        'http://antique-timetable.info'
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        9,
        36,
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Edwin Klocko',
        'http://clear-cut-query.com'
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        1,
        92,
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Terrance Mayert',
        'https://cool-conscience.name'
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        2,
        37,
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Meghan Dach DVM',
        'http://compassionate-museum.net'
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        7,
        80,
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Mrs. Jake Ankunding',
        'http://scented-clarinet.biz'
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        8,
        117,
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Cassandra Schowalter',
        'http://simplistic-naming.org'
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        5,
        93,
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Elaine Roob',
        'http://elated-bear.net'
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        6,
        36,
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Jody Herzog',
        'http://cultivated-gratitude.org'
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        5,
        40,
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Miss Mable Von Jr.',
        'http://dishonest-state.biz'
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        4,
        107,
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Barbara Mann PhD',
        'http://mountainous-input.net'
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        8,
        129,
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Dan Jenkins',
        'http://jittery-diaphragm.org'
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        2,
        122,
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Ana Rice PhD',
        'http://unwelcome-doorbell.com'
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        10,
        97,
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Blake Rau',
        'http://shiny-cage.com'
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        1,
        48,
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Guy Glover',
        'https://unselfish-pyridine.com'
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        9,
        131,
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Derek Conn',
        'http://unripe-lining.biz'
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        8,
        148,
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Russell Hane',
        'http://cooperative-forest.net'
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        4,
        82,
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Rufus Funk',
        'https://disastrous-dealer.info'
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        1,
        46,
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Randolph Reynolds',
        'http://unequaled-good.com'
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        4,
        107,
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Bessie King',
        'https://vicious-medium.net'
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        7,
        119,
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Noel Wiegand',
        'http://shady-portfolio.org'
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        10,
        113,
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Loretta McGlynn',
        'https://forthright-hectare.net'
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        4,
        88,
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Edmond Sipes',
        'https://forked-internet.com'
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        9,
        38,
        'Wittener Hütte',
        'Germany',
        'Ignacio Bahringer',
        'http://frosty-storm.biz'
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        4,
        37,
        'Hochjoch-Hospiz',
        'Austria',
        'Don Raynor',
        'https://imperturbable-postfix.com'
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        10,
        72,
        'Meilerhütte',
        'Germany',
        'Tracey Thompson',
        'http://inferior-strobe.com'
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        6,
        54,
        'Gaudeamushütte',
        'Austria',
        'Donnie Wilderman',
        'https://burdensome-monsoon.net'
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        6,
        57,
        'Rheydter Hütte',
        'Germany',
        'Delores Schinner',
        'http://free-honeydew.com'
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        4,
        114,
        'Sektionshütte Krippen',
        'Germany',
        'Mrs. Barry Renner',
        'http://spry-stranger.org'
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        5,
        63,
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Sheila Trantow',
        'http://obedient-basketball.com'
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        7,
        98,
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Lee Pfannerstill',
        'https://frosty-quote.biz'
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        8,
        102,
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Sergio Herzog',
        'https://clear-cut-beer.name'
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        3,
        81,
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Spencer Wolff V',
        'https://high-level-toenail.name'
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        2,
        45,
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Trevor Rohan',
        'https://elliptical-company.net'
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        6,
        36,
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Dr. Alicia Quitzon',
        'https://trusting-download.info'
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        4,
        112,
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Jerald Veum',
        'https://practical-element.name'
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        4,
        37,
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Cory Zboncak',
        'https://sophisticated-trace.org'
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        2,
        59,
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Salvatore Sipes',
        'http://likely-idea.com'
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        3,
        120,
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Loretta McGlynn',
        'https://distorted-hearth.org'
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        7,
        74,
        'Dobra voda',
        'Suvobor, Serbia',
        'Inez Schmitt',
        'http://obese-portfolio.info'
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        7,
        134,
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Melvin Bauch DVM',
        'https://deep-backup.com'
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        2,
        136,
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Elias Cummings',
        'https://foolhardy-trade.name'
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        5,
        83,
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Harvey Lebsack IV',
        'http://weighty-sphere.com'
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        6,
        66,
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Janet Schmitt',
        'http://nautical-rib.info'
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        9,
        41,
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Benjamin Bednar',
        'http://studious-cardboard.com'
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        9,
        128,
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Henry Witting',
        'http://same-outside.org'
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        7,
        117,
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Malcolm Haag',
        'https://limping-barbecue.com'
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        8,
        97,
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Orlando Murray',
        'http://substantial-fishbone.org'
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        9,
        49,
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Mrs. Bill Hettinger',
        'https://fruitful-provider.com'
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        6,
        42,
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Nelson Daniel',
        'http://sparse-signify.net'
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '8223 Evie Mount, Fort Barrettfort, Italy',
        'Fort Barrettfort',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        157,
        '012 Boyer Stream, McLean, Italy',
        'McLean',
        'Italy',
        'New Hampshire',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        92,
        '136 Hilario Radial, University, Italy',
        'University',
        'Italy',
        'Maine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        26,
        '21000 Wuckert Drive, South Darrylchester, Italy',
        'South Darrylchester',
        'Italy',
        'Alaska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        182,
        '4703 Bria Circles, Sharonchester, Italy',
        'Sharonchester',
        'Italy',
        'New Jersey',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        179,
        '419 Casper Inlet, Littelstead, Italy',
        'Littelstead',
        'Italy',
        'Utah',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        38,
        '75398 Thiel Prairie, University, Italy',
        'University',
        'Italy',
        'Idaho',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        279,
        '013 Presley Throughway, West Bethanycester, Italy',
        'West Bethanycester',
        'Italy',
        'North Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        160,
        '415 Leif Gardens, West Lelia, Italy',
        'West Lelia',
        'Italy',
        'Nebraska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        278,
        '7005 Lexi Burgs, Port Gerardo, Italy',
        'Port Gerardo',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        266,
        '687 Karelle Loaf, St. Paul, Italy',
        'St. Paul',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        258,
        '5225 Luigi Circle, Reynoldsville, Italy',
        'Reynoldsville',
        'Italy',
        'Kansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        216,
        '3843 Frami Fords, Fort Darencester, Italy',
        'Fort Darencester',
        'Italy',
        'Wisconsin',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        43,
        '9448 Anderson Lights, Lake Jasperstead, Italy',
        'Lake Jasperstead',
        'Italy',
        'Nevada',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        170,
        '05903 Crist Burg, New Obieton, Italy',
        'New Obieton',
        'Italy',
        'Idaho',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        73,
        '45440 Stehr Streets, Thadville, Italy',
        'Thadville',
        'Italy',
        'Florida',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        286,
        '3044 Reyes Harbors, North Edwina, Italy',
        'North Edwina',
        'Italy',
        'New York',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        227,
        '249 McCullough Crossroad, Fort Julianneberg, Italy',
        'Fort Julianneberg',
        'Italy',
        'Connecticut',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        295,
        '592 Kristoffer Manors, Jaskolskitown, Italy',
        'Jaskolskitown',
        'Italy',
        'Alabama',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        217,
        '1555 Carlotta Keys, Bradtkefurt, Italy',
        'Bradtkefurt',
        'Italy',
        'Mississippi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        76,
        '419 Terry Passage, Lehnerhaven, Italy',
        'Lehnerhaven',
        'Italy',
        'Florida',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        160,
        '3757 Greenholt Pass, New Koby, Italy',
        'New Koby',
        'Italy',
        'Vermont',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '21961 Jo Route, North Richland Hills, Italy',
        'North Richland Hills',
        'Italy',
        'North Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        163,
        '36567 Patsy Gateway, Gerholdbury, Italy',
        'Gerholdbury',
        'Italy',
        'Florida',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        152,
        '38109 Bernier Bypass, Lake Dewittmouth, Italy',
        'Lake Dewittmouth',
        'Italy',
        'Kansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        115,
        '774 Newton Ridge, Arnoldoport, Italy',
        'Arnoldoport',
        'Italy',
        'Delaware',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        125,
        '8180 Crist Parkways, Port Tryciaport, Italy',
        'Port Tryciaport',
        'Italy',
        'Nevada',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        26,
        '474 Haley Trace, South Lilly, Italy',
        'South Lilly',
        'Italy',
        'West Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        182,
        '04933 Olen Highway, Dibbertburgh, Italy',
        'Dibbertburgh',
        'Italy',
        'Nebraska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        111,
        '57008 Maggio Mountains, East Annie, Italy',
        'East Annie',
        'Italy',
        'Massachusetts',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        79,
        '32521 Schmitt Mount, South Janelle, Italy',
        'South Janelle',
        'Italy',
        'Wyoming',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        287,
        '4362 Paul Rue, Akron, Italy',
        'Akron',
        'Italy',
        'North Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        157,
        '55331 Hauck Vista, North Alanfort, Italy',
        'North Alanfort',
        'Italy',
        'New Mexico',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '8253 Kihn Extension, Port Torreyhaven, Italy',
        'Port Torreyhaven',
        'Italy',
        'New Mexico',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        129,
        '787 Hirthe Lakes, Fountain Valley, Italy',
        'Fountain Valley',
        'Italy',
        'Wisconsin',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        202,
        '529 Friesen Flats, North Walker, Italy',
        'North Walker',
        'Italy',
        'Kansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        297,
        '289 Deckow Station, Port Mariela, Italy',
        'Port Mariela',
        'Italy',
        'Alaska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        98,
        '0443 Ryan Streets, Allanstad, Italy',
        'Allanstad',
        'Italy',
        'New York',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        293,
        '56834 Zelda Mews, North Braxtonstad, Italy',
        'North Braxtonstad',
        'Italy',
        'Oregon',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        214,
        '827 Tony Lock, North Felipestead, Italy',
        'North Felipestead',
        'Italy',
        'Hawaii',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '14410 Weber Fall, Kihnstead, Italy',
        'Kihnstead',
        'Italy',
        'Florida',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        169,
        '011 Jillian Hills, Caroleworth, Italy',
        'Caroleworth',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        235,
        '260 Jena Glens, Lehnerborough, Italy',
        'Lehnerborough',
        'Italy',
        'New York',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        227,
        '932 Dibbert Fall, Elkhart, Italy',
        'Elkhart',
        'Italy',
        'West Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        279,
        '8603 Everardo Keys, South Davin, Italy',
        'South Davin',
        'Italy',
        'Maine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        284,
        '1308 Kovacek Trail, East Doyle, Italy',
        'East Doyle',
        'Italy',
        'New Hampshire',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        248,
        '28086 Landen Drives, Port Yazminland, Italy',
        'Port Yazminland',
        'Italy',
        'Idaho',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        248,
        '1798 Pablo Well, Casas Adobes, Italy',
        'Casas Adobes',
        'Italy',
        'Florida',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        289,
        '189 Stephanie Stream, East Hailieberg, Italy',
        'East Hailieberg',
        'Italy',
        'Ohio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        101,
        '459 Hermiston Trace, Alishacester, Italy',
        'Alishacester',
        'Italy',
        'Idaho',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        234,
        '8638 Hills Green, North Salmamouth, Italy',
        'North Salmamouth',
        'Italy',
        'Utah',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '3270 Ernesto Route, Alanisstead, Italy',
        'Alanisstead',
        'Italy',
        'Utah',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        80,
        '3176 Claire Summit, Eunafurt, Italy',
        'Eunafurt',
        'Italy',
        'Tennessee',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '503 Muller Course, Beatricechester, Italy',
        'Beatricechester',
        'Italy',
        'Tennessee',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        141,
        '60723 Runolfsson Glens, Port Lexiboro, Italy',
        'Port Lexiboro',
        'Italy',
        'Kentucky',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        148,
        '015 Chasity Plaza, Port Jacinthestead, Italy',
        'Port Jacinthestead',
        'Italy',
        'Massachusetts',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        32,
        '079 Erna Brook, Dayton, Italy',
        'Dayton',
        'Italy',
        'New Jersey',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        31,
        '190 Marlin Mission, Wisokyborough, Italy',
        'Wisokyborough',
        'Italy',
        'Washington',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        152,
        '689 Marisol Passage, El Paso, Italy',
        'El Paso',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        296,
        '499 Nikolaus Locks, Joplin, Italy',
        'Joplin',
        'Italy',
        'South Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        66,
        '19681 Schumm Unions, Lorenastead, Italy',
        'Lorenastead',
        'Italy',
        'Mississippi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        172,
        '009 Crist Harbor, Handcester, Italy',
        'Handcester',
        'Italy',
        'Utah',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        65,
        '096 Zena Brook, Lake Hilton, Italy',
        'Lake Hilton',
        'Italy',
        'Indiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        75,
        '476 Lowe Crest, Merced, Italy',
        'Merced',
        'Italy',
        'New Jersey',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        158,
        '1754 Rowland Groves, Euless, Italy',
        'Euless',
        'Italy',
        'Delaware',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        232,
        '7251 Billie Ferry, Romanfurt, Italy',
        'Romanfurt',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        168,
        '516 O''Keefe Crest, New Osborne, Italy',
        'New Osborne',
        'Italy',
        'Missouri',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        29,
        '719 O''Keefe Hills, New Kristinside, Italy',
        'New Kristinside',
        'Italy',
        'Idaho',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        141,
        '580 Bartell Ports, Brookhaven, Italy',
        'Brookhaven',
        'Italy',
        'Washington',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '435 Stroman Way, Bethesda, Italy',
        'Bethesda',
        'Italy',
        'Vermont',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        297,
        '978 Bogisich Viaduct, West Brennan, Italy',
        'West Brennan',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        210,
        '0779 Haylee Viaduct, Billings, Italy',
        'Billings',
        'Italy',
        'Wisconsin',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        220,
        '51871 Stanton Wall, Moseboro, Italy',
        'Moseboro',
        'Italy',
        'Mississippi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        245,
        '473 Ole Mall, Madelinehaven, Italy',
        'Madelinehaven',
        'Italy',
        'Tennessee',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        148,
        '79927 Demetrius Wells, Vandervortview, Italy',
        'Vandervortview',
        'Italy',
        'Wyoming',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        45,
        '795 Adrianna Park, Lake Marlinbury, Italy',
        'Lake Marlinbury',
        'Italy',
        'New Jersey',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        210,
        '2014 Erdman Lakes, McClureside, Italy',
        'McClureside',
        'Italy',
        'Mississippi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        180,
        '941 Trever Corner, Fort Marilieport, Italy',
        'Fort Marilieport',
        'Italy',
        'Ohio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        244,
        '1051 Catherine Prairie, South Hattie, Italy',
        'South Hattie',
        'Italy',
        'Rhode Island',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        143,
        '47865 Cooper Club, Harrischester, Italy',
        'Harrischester',
        'Italy',
        'Rhode Island',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        144,
        '01275 Treutel Pass, West Mariliestead, Italy',
        'West Mariliestead',
        'Italy',
        'Iowa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        87,
        '281 Erdman Trace, East Trent, Italy',
        'East Trent',
        'Italy',
        'South Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        243,
        '41640 Durgan Park, Octaviastead, Italy',
        'Octaviastead',
        'Italy',
        'Massachusetts',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        113,
        '07857 Marvin Estates, North Clinton, Italy',
        'North Clinton',
        'Italy',
        'Minnesota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        200,
        '238 Estel Squares, Mabelshire, Italy',
        'Mabelshire',
        'Italy',
        'Oklahoma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        250,
        '96486 Bergnaum Pass, Fort Shyann, Italy',
        'Fort Shyann',
        'Italy',
        'Rhode Island',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        277,
        '5514 Kianna Courts, Somerville, Italy',
        'Somerville',
        'Italy',
        'Delaware',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        251,
        '93394 Lacey Canyon, Denesikshire, Italy',
        'Denesikshire',
        'Italy',
        'Louisiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        60,
        '171 Cade Divide, Marinaborough, Italy',
        'Marinaborough',
        'Italy',
        'Indiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        78,
        '82974 Eliane Ramp, South Aurelie, Italy',
        'South Aurelie',
        'Italy',
        'New Jersey',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        55,
        '2978 Yundt Tunnel, New Siennahaven, Italy',
        'New Siennahaven',
        'Italy',
        'Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        213,
        '7103 Zoie Junctions, Olgachester, Italy',
        'Olgachester',
        'Italy',
        'Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        96,
        '279 Nico Ways, Westfield, Italy',
        'Westfield',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        148,
        '6098 Kuvalis Courts, Modesto, Italy',
        'Modesto',
        'Italy',
        'New York',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        91,
        '6081 Tyrese Bridge, Barnstable Town, Italy',
        'Barnstable Town',
        'Italy',
        'California',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        141,
        '7182 Josie Circle, Andreville, Italy',
        'Andreville',
        'Italy',
        'Utah',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        106,
        '172 Jakubowski Road, Lake Lornastead, Italy',
        'Lake Lornastead',
        'Italy',
        'Maryland',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        173,
        '0069 Rutherford Point, Fort Dessie, Italy',
        'Fort Dessie',
        'Italy',
        'Kentucky',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        80,
        '23063 Emil Corners, Kerlukeside, Italy',
        'Kerlukeside',
        'Italy',
        'Arkansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        134,
        '2326 Dalton Loop, San Luis Obispo, Italy',
        'San Luis Obispo',
        'Italy',
        'Iowa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        272,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Vermont',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        197,
        '2525 Schumm Isle, Ahmedport, Italy',
        'Ahmedport',
        'Italy',
        'Maryland',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        29,
        '368 Sauer Landing, Chapel Hill, Italy',
        'Chapel Hill',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        163,
        '49093 Elta Key, Nevaside, Italy',
        'Nevaside',
        'Italy',
        'Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        250,
        '4728 Johathan Ramp, Bashirianview, Italy',
        'Bashirianview',
        'Italy',
        'Minnesota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        243,
        '03773 Kris Roads, Hageneston, Italy',
        'Hageneston',
        'Italy',
        'Nebraska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        121,
        '214 German Springs, West Shanna, Italy',
        'West Shanna',
        'Italy',
        'Rhode Island',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        119,
        '065 Ulices Skyway, West Junior, Italy',
        'West Junior',
        'Italy',
        'Ohio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        28,
        '027 Gloria Row, Gloverhaven, Italy',
        'Gloverhaven',
        'Italy',
        'Connecticut',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        102,
        '24439 Elody Forges, Blandaboro, Italy',
        'Blandaboro',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        265,
        '422 Sanford Lake, North Las Vegas, Italy',
        'North Las Vegas',
        'Italy',
        'Nevada',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        53,
        '82247 Kevon Canyon, South Johnson, Italy',
        'South Johnson',
        'Italy',
        'Maine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        229,
        '01869 Napoleon Ranch, West Ethan, Italy',
        'West Ethan',
        'Italy',
        'Mississippi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        146,
        '9351 Gerhard Brooks, Kettering, Italy',
        'Kettering',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        102,
        '7357 Stehr Heights, Lake Destiniboro, Italy',
        'Lake Destiniboro',
        'Italy',
        'Connecticut',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        130,
        '095 Sanford Ranch, New Josephinechester, Italy',
        'New Josephinechester',
        'Italy',
        'Mississippi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        52,
        '3653 Lubowitz Garden, Bayamon, Italy',
        'Bayamon',
        'Italy',
        'Illinois',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        224,
        '2985 Pete Lake, South Diana, Italy',
        'South Diana',
        'Italy',
        'Colorado',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        185,
        '3083 Keeling Dale, Stehrbury, Italy',
        'Stehrbury',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        243,
        '399 Bahringer Manor, Racine, Italy',
        'Racine',
        'Italy',
        'Louisiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        125,
        '5442 Mosciski Neck, New Camillaburgh, Italy',
        'New Camillaburgh',
        'Italy',
        'Florida',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        191,
        '1923 Curt Forks, North Kaylamouth, Italy',
        'North Kaylamouth',
        'Italy',
        'Minnesota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        77,
        '8978 Halvorson Gateway, Susanaton, Italy',
        'Susanaton',
        'Italy',
        'South Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        91,
        '315 Rossie Club, Walnut Creek, Italy',
        'Walnut Creek',
        'Italy',
        'North Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        216,
        '479 Mueller Port, Port Robynboro, Italy',
        'Port Robynboro',
        'Italy',
        'Michigan',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        56,
        '02274 Wisozk Cliffs, Mathildechester, Italy',
        'Mathildechester',
        'Italy',
        'Maine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '143 Kacie Orchard, Lednerburgh, Italy',
        'Lednerburgh',
        'Italy',
        'Illinois',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        58,
        '016 Kiehn Spring, New Evanview, Italy',
        'New Evanview',
        'Italy',
        'New Mexico',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        246,
        '609 Nadia Greens, South Meghan, Italy',
        'South Meghan',
        'Italy',
        'Arizona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '09030 Sheila Hollow, New Henriettefield, Italy',
        'New Henriettefield',
        'Italy',
        'Connecticut',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '280 Stiedemann Heights, Cartwrightborough, Italy',
        'Cartwrightborough',
        'Italy',
        'Rhode Island',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        93,
        '30431 Muller Causeway, Coral Springs, Italy',
        'Coral Springs',
        'Italy',
        'Kentucky',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        56,
        '2186 Willy Junctions, Joaquinborough, Italy',
        'Joaquinborough',
        'Italy',
        'Indiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        215,
        '491 Jaskolski Court, North Chelsey, Italy',
        'North Chelsey',
        'Italy',
        'Pennsylvania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        284,
        '02644 Pete Ford, Morissettehaven, Italy',
        'Morissettehaven',
        'Italy',
        'Massachusetts',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        226,
        '053 Dibbert Land, Fort Margaretteland, Italy',
        'Fort Margaretteland',
        'Italy',
        'Arkansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '829 Alvah Station, East Jessikatown, Italy',
        'East Jessikatown',
        'Italy',
        'North Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '8528 Block Brook, Thielchester, Italy',
        'Thielchester',
        'Italy',
        'North Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        205,
        '2392 Elaina Street, Altenwerthboro, Italy',
        'Altenwerthboro',
        'Italy',
        'South Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '0798 Barton Way, Ernserland, Italy',
        'Ernserland',
        'Italy',
        'South Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        45,
        '5689 Gerhold Freeway, Feestboro, Italy',
        'Feestboro',
        'Italy',
        'Ohio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        89,
        '1187 Heaney Rapid, Fort Nathanaelside, Italy',
        'Fort Nathanaelside',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        156,
        '442 Ferry Forks, Gislasonland, Italy',
        'Gislasonland',
        'Italy',
        'Louisiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        105,
        '56620 Ashlee Mall, Euless, Italy',
        'Euless',
        'Italy',
        'South Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        86,
        '2574 Madie Heights, Jerryburgh, Italy',
        'Jerryburgh',
        'Italy',
        'Nebraska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        254,
        '5337 Aufderhar Avenue, East Ayana, Italy',
        'East Ayana',
        'Italy',
        'Kentucky',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        136,
        '39525 Schoen Pike, North Triston, Italy',
        'North Triston',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        286,
        '3098 Carroll Common, Fort Collins, Italy',
        'Fort Collins',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        250,
        '98787 Wolf Keys, Fort Bernice, Italy',
        'Fort Bernice',
        'Italy',
        'Minnesota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        164,
        '7243 Shanahan Stravenue, Lake Reanna, Italy',
        'Lake Reanna',
        'Italy',
        'South Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        65,
        '47429 Desmond Island, Cronaton, Italy',
        'Cronaton',
        'Italy',
        'Arizona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        218,
        '8061 Fahey Landing, North Madisynborough, Italy',
        'North Madisynborough',
        'Italy',
        'North Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        232,
        '6682 Iliana Trafficway, Frederickchester, Italy',
        'Frederickchester',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        51,
        '342 Murphy Place, Aiyanaboro, Italy',
        'Aiyanaboro',
        'Italy',
        'Delaware',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        80,
        '535 Jett Mills, Erdmanton, Italy',
        'Erdmanton',
        'Italy',
        'Wisconsin',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        156,
        '374 Rebekah Station, Pittsfield, Italy',
        'Pittsfield',
        'Italy',
        'Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        168,
        '101 Abbott Lakes, South Nathaniel, Italy',
        'South Nathaniel',
        'Italy',
        'Alabama',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        30,
        '039 O''Reilly Falls, Joplin, Italy',
        'Joplin',
        'Italy',
        'Arizona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        170,
        '1173 Seth Ranch, West Willa, Italy',
        'West Willa',
        'Italy',
        'Arkansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        229,
        '98666 Greyson Keys, Wilberworth, Italy',
        'Wilberworth',
        'Italy',
        'New Hampshire',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        179,
        '94055 Demarcus Burg, West Lamontbury, Italy',
        'West Lamontbury',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        222,
        '7985 Reichel Mountains, Port Shemar, Italy',
        'Port Shemar',
        'Italy',
        'Nevada',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        76,
        '992 Delbert Rapids, Poinciana, Italy',
        'Poinciana',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        212,
        '75224 Giuseppe Springs, Pacochafurt, Italy',
        'Pacochafurt',
        'Italy',
        'Alabama',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        134,
        '035 Jermaine Port, Cristfield, Italy',
        'Cristfield',
        'Italy',
        'Oregon',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '12722 Myrtis Lock, West Brett, Italy',
        'West Brett',
        'Italy',
        'West Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        208,
        '82874 Jenkins Vista, Port Irving, Italy',
        'Port Irving',
        'Italy',
        'Ohio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        269,
        '843 Lazaro Common, East Breanna, Italy',
        'East Breanna',
        'Italy',
        'Vermont',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        238,
        '363 Camron Harbors, Fort Kendrickport, Italy',
        'Fort Kendrickport',
        'Italy',
        'Vermont',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        29,
        '792 Zander Mount, Oceanside, Italy',
        'Oceanside',
        'Italy',
        'Oregon',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        277,
        '51626 Bednar Trafficway, Herberttown, Italy',
        'Herberttown',
        'Italy',
        'Minnesota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        174,
        '84640 Herzog Overpass, South Murphy, Italy',
        'South Murphy',
        'Italy',
        'Nebraska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        124,
        '3713 Toy Pike, North Piperhaven, Italy',
        'North Piperhaven',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        236,
        '5978 Robel Freeway, Hesperia, Italy',
        'Hesperia',
        'Italy',
        'Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        197,
        '32301 Maida Square, Tyraport, Italy',
        'Tyraport',
        'Italy',
        'Washington',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        157,
        '23894 Elyssa Loop, Christview, Italy',
        'Christview',
        'Italy',
        'Tennessee',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        76,
        '90662 Ansley Neck, Elenastad, Italy',
        'Elenastad',
        'Italy',
        'Utah',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        52,
        '75625 Baumbach Ways, East Toyfield, Italy',
        'East Toyfield',
        'Italy',
        'Connecticut',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        255,
        '7232 Howe Rest, Bauchfort, Italy',
        'Bauchfort',
        'Italy',
        'Kansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        64,
        '653 Rogahn Throughway, Carlsbad, Italy',
        'Carlsbad',
        'Italy',
        'Indiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        79,
        '4902 Reilly Circle, Hutchinson, Italy',
        'Hutchinson',
        'Italy',
        'Nebraska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        266,
        '1087 Stark Green, Port Madgeview, Italy',
        'Port Madgeview',
        'Italy',
        'Wisconsin',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '355 Kihn Grove, Lake Bernadine, Italy',
        'Lake Bernadine',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        NaN,
        '0818 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Michigan',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        257,
        '07164 Haley Burgs, Fort Allenefort, Italy',
        'Fort Allenefort',
        'Italy',
        'Illinois',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        289,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'California',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        211,
        '862 D''angelo Fort, Halvorsonfort, Italy',
        'Halvorsonfort',
        'Italy',
        'Arkansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        299,
        '9167 Maeve Rest, Jannieside, Italy',
        'Jannieside',
        'Italy',
        'Tennessee',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        152,
        '29374 Sipes Forest, Bowie, Italy',
        'Bowie',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        115,
        '2943 Hegmann Trail, Rodrigoview, Italy',
        'Rodrigoview',
        'Italy',
        'Utah',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        212,
        '134 Jarrod Rapids, Port Maida, Italy',
        'Port Maida',
        'Italy',
        'Hawaii',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        273,
        '2643 Davis Plaza, Hyattfurt, Italy',
        'Hyattfurt',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        273,
        '9617 Delbert Extension, Sacramento, Italy',
        'Sacramento',
        'Italy',
        'Minnesota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        215,
        '42958 Jean Motorway, Lake Oletamouth, Italy',
        'Lake Oletamouth',
        'Italy',
        'South Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        233,
        '016 Zemlak Pass, Zboncakside, Italy',
        'Zboncakside',
        'Italy',
        'Alaska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        253,
        '48215 Ulices Greens, North Hilbert, Italy',
        'North Hilbert',
        'Italy',
        'Idaho',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        295,
        '206 Millie Walks, Tierrafurt, Italy',
        'Tierrafurt',
        'Italy',
        'New Jersey',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        270,
        '60646 Karson Lock, North Madge, Italy',
        'North Madge',
        'Italy',
        'Colorado',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        217,
        '3187 Lesch Manor, Ottiston, Italy',
        'Ottiston',
        'Italy',
        'Arkansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        181,
        '578 Berge Bridge, Haagview, Italy',
        'Haagview',
        'Italy',
        'Oklahoma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        141,
        '30998 Alexanne Circles, South Glen, Italy',
        'South Glen',
        'Italy',
        'Wisconsin',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        30,
        '33622 Rosamond Mall, Theresiaboro, Italy',
        'Theresiaboro',
        'Italy',
        'Oklahoma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '717 Verdie Causeway, South Calliefurt, Italy',
        'South Calliefurt',
        'Italy',
        'Tennessee',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        147,
        '3380 Willis Hills, South Triston, Italy',
        'South Triston',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        260,
        '038 Hudson Ranch, Hackettside, Italy',
        'Hackettside',
        'Italy',
        'Massachusetts',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        60,
        '45325 Cartwright Grove, Alyssonshire, Italy',
        'Alyssonshire',
        'Italy',
        'Alaska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        93,
        '264 Klein Drive, West Ramoncester, Italy',
        'West Ramoncester',
        'Italy',
        'Minnesota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        192,
        '8493 Susana Path, Magdalenacester, Italy',
        'Magdalenacester',
        'Italy',
        'Indiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        279,
        '0578 Jamey Divide, Potomac, Italy',
        'Potomac',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        85,
        '34763 Rosalind Drive, New Arno, Italy',
        'New Arno',
        'Italy',
        'California',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        172,
        '5677 Eulah Crossing, Willardton, Italy',
        'Willardton',
        'Italy',
        'Colorado',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        76,
        '8983 Luigi Rapid, Hamillchester, Italy',
        'Hamillchester',
        'Italy',
        'Vermont',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '7957 Joana Vista, Rock Hill, Italy',
        'Rock Hill',
        'Italy',
        'Idaho',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        221,
        '1768 Cremin Forest, Padbergland, Italy',
        'Padbergland',
        'Italy',
        'Colorado',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        74,
        '48910 Lambert Mills, East Cleveland, Italy',
        'East Cleveland',
        'Italy',
        'West Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        126,
        '224 Green Forks, West Rosalia, Italy',
        'West Rosalia',
        'Italy',
        'Hawaii',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        32,
        '61634 Larson Isle, East Destineeworth, Italy',
        'East Destineeworth',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        175,
        '3739 Lauren Freeway, Ezequielfurt, Italy',
        'Ezequielfurt',
        'Italy',
        'Delaware',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        169,
        '5862 Schneider Row, Kunzetown, Italy',
        'Kunzetown',
        'Italy',
        'Oregon',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        67,
        '2352 Rohan Junctions, North Hiramport, Italy',
        'North Hiramport',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        274,
        '0555 Alene Roads, Lake Ivamouth, Italy',
        'Lake Ivamouth',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '6714 Jerrold Pike, New Cydney, Italy',
        'New Cydney',
        'Italy',
        'Utah',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        224,
        '8323 Delmer Square, West Joyburgh, Italy',
        'West Joyburgh',
        'Italy',
        'Florida',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        118,
        '8618 Taya Forks, West Des Moines, Italy',
        'West Des Moines',
        'Italy',
        'Kentucky',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        220,
        '404 Runolfsdottir Estate, Hegmannborough, Italy',
        'Hegmannborough',
        'Italy',
        'Oklahoma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        37,
        '5564 Dave Track, New Jacquelyn, Italy',
        'New Jacquelyn',
        'Italy',
        'South Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        177,
        '67688 Germaine Cape, Fort Rowenacester, Italy',
        'Fort Rowenacester',
        'Italy',
        'Nevada',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        43,
        '3987 Savanna Mill, Waelchihaven, Italy',
        'Waelchihaven',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        64,
        '748 Ora Track, Harrisonburg, Italy',
        'Harrisonburg',
        'Italy',
        'Massachusetts',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        67,
        '551 Kshlerin Ports, Cummingsport, Italy',
        'Cummingsport',
        'Italy',
        'Michigan',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        211,
        '136 Lucile Freeway, Hoover, Italy',
        'Hoover',
        'Italy',
        'Maine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        111,
        '0205 Roosevelt Tunnel, Borerside, Italy',
        'Borerside',
        'Italy',
        'Maryland',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        101,
        '875 Kozey Club, Frederick, Italy',
        'Frederick',
        'Italy',
        'Maine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        138,
        '998 Della Ports, Nolanberg, Italy',
        'Nolanberg',
        'Italy',
        'Pennsylvania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        109,
        '0891 O''Connell Path, Port Mossiemouth, Italy',
        'Port Mossiemouth',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        260,
        '11320 Torrey Union, Gleichnertown, Italy',
        'Gleichnertown',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        259,
        '4014 Parker Spur, Vallejo, Italy',
        'Vallejo',
        'Italy',
        'Connecticut',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        215,
        '895 Velda Drive, Orland Park, Italy',
        'Orland Park',
        'Italy',
        'Nebraska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        212,
        '1123 Verdie Lakes, Inglewood, Italy',
        'Inglewood',
        'Italy',
        'West Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        153,
        '6173 Rosella Ford, Rowlandmouth, Italy',
        'Rowlandmouth',
        'Italy',
        'Connecticut',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        132,
        '23338 Keeling Squares, Runolfsdottirport, Italy',
        'Runolfsdottirport',
        'Italy',
        'Rhode Island',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        268,
        '590 Santina Land, Hilpertfield, Italy',
        'Hilpertfield',
        'Italy',
        'Illinois',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        292,
        '392 Hickle Manor, Bransonburgh, Italy',
        'Bransonburgh',
        'Italy',
        'Alabama',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        210,
        '362 Tremaine Squares, New Garett, Italy',
        'New Garett',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        74,
        '57865 Sincere Course, Gertrudeside, Italy',
        'Gertrudeside',
        'Italy',
        'Ohio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        27,
        '12077 Hauck Fort, Framiton, Italy',
        'Framiton',
        'Italy',
        'Louisiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        222,
        '716 Mitchell Brook, Mitchellfield, Italy',
        'Mitchellfield',
        'Italy',
        'Pennsylvania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        95,
        '489 Williamson Oval, Lake Hadleyview, Italy',
        'Lake Hadleyview',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        300,
        '4249 Jaunita Ranch, Detroit, Italy',
        'Detroit',
        'Italy',
        'West Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '27007 Gerhold Highway, Lake Winstonstad, Italy',
        'Lake Winstonstad',
        'Italy',
        'Louisiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        128,
        '2665 Dickinson Radial, Toreyburgh, Italy',
        'Toreyburgh',
        'Italy',
        'Iowa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        76,
        '816 Kihn River, Morarshire, Italy',
        'Morarshire',
        'Italy',
        'Louisiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        164,
        '8616 Declan Corner, Hailieville, Italy',
        'Hailieville',
        'Italy',
        'Minnesota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        79,
        '3991 Sally Fall, La Crosse, Italy',
        'La Crosse',
        'Italy',
        'Maryland',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        54,
        '3872 Imani Meadow, Huntington, Italy',
        'Huntington',
        'Italy',
        'Illinois',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        226,
        '5590 Daisy Skyway, Pagacport, Italy',
        'Pagacport',
        'Italy',
        'Minnesota',
        ''
      );
    
  