--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: insert_hut(integer, double precision, double precision, integer, numeric, character varying, character varying, character varying, character varying, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut(user_id integer, lat double precision, lon double precision, number_of_beds integer, price numeric, title character varying, address character varying, owner_name character varying, website character varying, elevation numeric) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation
    );
    END
    $$;


--
-- Name: insert_parking_lot(integer, double precision, double precision, character varying, integer, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_parking_lot(user_id integer, lat double precision, lon double precision, name character varying, max_cars integer, address character varying, city character varying, country character varying, region character varying, province character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country) FROM stdin;
1	2	0.90	13	16.20	0	Airline Trail - Detour		/static/gpx/001_Airline_Trail___Detour.gpx	0.00	La Spezia		Pariggiano ligure	USA
2	2	0.60	8	14.80	2	Airline Trail		/static/gpx/002_Airline_Trail.gpx	0.00	Como		Borgo Ilda	USA
3	2	1.90	26	11.00	1	Colchester Railroad		/static/gpx/003_Colchester_Railroad.gpx	0.00	Milano		Chilà laziale	USA
4	2	1.50	19	7.70	1	Willimantic Flower Bridge		/static/gpx/004_Willimantic_Flower_Bridge.gpx	0.00	Imperia		Settimo Luana	USA
5	2	0.80	11	29.90	1	Willimantic Pedestrian Bridge		/static/gpx/005_Willimantic_Pedestrian_Bridge.gpx	0.00	Padova		San Valerio	USA
6	2	0.60	7	29.80	2	Two Sister'S Preserve Loop Trail		/static/gpx/006_Two_Sister_S_Preserve_Loop_Trail.gpx	0.00	Modena		Betti terme	USA
7	2	0.90	14	12.80	1	Putnam River Trail		/static/gpx/007_Putnam_River_Trail.gpx	0.00	Como		Giannetti ligure	USA
8	2	1.40	20	19.60	2	Airline Trail Bypass		/static/gpx/008_Airline_Trail_Bypass.gpx	0.00	Taranto		Sesto Massimiliano a mare	USA
9	2	14.60	248	9.00	1	Indian Neck		/static/gpx/009_Indian_Neck.gpx	0.00	Reggio Calabria		Settimo Ulfa	USA
10	2	6.70	86	5.70	0	Stony Creek		/static/gpx/010_Stony_Creek.gpx	0.00	Lucca		Quarto Edilberto	USA
11	2	8.70	108	10.20	2	Quarry-Westwoods		/static/gpx/011_Quarry_Westwoods.gpx	0.00	Oristano		Quarto Marilena	USA
12	2	17.30	241	7.80	0	Short Beach		/static/gpx/012_Short_Beach.gpx	0.00	Siracusa		Casolaro terme	USA
13	2	1.30	18	20.60	2	Charter Oak Greenway		/static/gpx/013_Charter_Oak_Greenway.gpx	0.00	Taranto		Riggi lido	USA
14	2	1.70	21	19.90	1	Bissell Greenway		/static/gpx/014_Bissell_Greenway.gpx	0.00	Roma		Sesto Romeo ligure	USA
15	2	0.60	9	25.30	0	Riverfront Trail System		/static/gpx/015_Riverfront_Trail_System.gpx	0.00	Prato		Borgo Paride	USA
16	2	1.40	20	7.20	2	Millers Pond Park Trail		/static/gpx/016_Millers_Pond_Park_Trail.gpx	0.00	Chieti		Ilenia calabro	USA
17	2	0.60	7	8.70	2	Mattabesett Trail		/static/gpx/017_Mattabesett_Trail.gpx	0.00	Pesaro e Urbino		Assunto nell'emilia	USA
18	2	1.20	20	22.90	2	Jefferson Park Trail		/static/gpx/018_Jefferson_Park_Trail.gpx	0.00	Siracusa		Druina calabro	USA
19	2	1.20	15	19.00	2	Cockaponset Trail		/static/gpx/019_Cockaponset_Trail.gpx	0.00	Agrigento		San Proserpina	USA
20	2	1.00	13	18.70	1	Mt. Nebo Park		/static/gpx/020_Mt__Nebo_Park.gpx	0.00	Isernia		Borgo Nina a mare	USA
21	2	1.20	17	26.40	2	 		/static/gpx/021__.gpx	0.00	Trento		Lo Piccolo veneto	USA
22	2	0.80	12	15.90	2	Proposed Trail		/static/gpx/022_Proposed_Trail.gpx	0.00	Verbano-Cusio-Ossola		Settimo Perla nell'emilia	USA
23	2	1.00	14	16.90	2	Blinnshed Ridge Trail		/static/gpx/023_Blinnshed_Ridge_Trail.gpx	0.00	Messina		Quarto Cordelia lido	USA
24	2	1.40	20	21.40	2	Neck River Trail		/static/gpx/024_Neck_River_Trail.gpx	0.00	Carbonia-Iglesias		Alberico veneto	USA
25	2	1.50	25	25.60	2	Unnamed Trail		/static/gpx/025_Unnamed_Trail.gpx	0.00	Pavia		Settimo Carlotta umbro	USA
26	2	0.60	9	9.00	2	Oil Mill Brook Trail		/static/gpx/026_Oil_Mill_Brook_Trail.gpx	0.00	Matera		Settimo Lisa	USA
27	2	1.10	16	18.00	2	Chatfield Trail		/static/gpx/027_Chatfield_Trail.gpx	0.00	Parma		Perna ligure	USA
28	2	0.80	13	22.40	2	Unamed Trail		/static/gpx/028_Unamed_Trail.gpx	0.00	Oristano		San Asella	USA
29	2	0.90	12	29.80	2	Lost Pond Trail		/static/gpx/029_Lost_Pond_Trail.gpx	0.00	Bolzano		Settimo Ottone	USA
30	2	1.10	19	25.90	2	Ccc Camp Hadley Trail		/static/gpx/030_Ccc_Camp_Hadley_Trail.gpx	0.00	Ragusa		Borgo Prudenzia	USA
31	2	0.50	8	24.00	2	Double Loop Trail		/static/gpx/031_Double_Loop_Trail.gpx	0.00	Lucca		Borgo Rodrigo	USA
32	2	0.70	10	17.30	2	Over Brook Trail		/static/gpx/032_Over_Brook_Trail.gpx	0.00	Lucca		San Alcina del friuli	USA
33	2	1.40	23	18.20	2	Cockaponset Forest Trail		/static/gpx/033_Cockaponset_Forest_Trail.gpx	0.00	Rieti		Leo sardo	USA
34	2	0.80	11	23.50	2	Pattaconk Trail		/static/gpx/034_Pattaconk_Trail.gpx	0.00	Forlì-Cesena		Quarto Gaia a mare	USA
35	2	0.90	14	19.30	2	Westwoods Forest Trail		/static/gpx/035_Westwoods_Forest_Trail.gpx	0.00	Vibo Valentia		Borgo Alice nell'emilia	USA
36	2	1.40	19	28.50	2	Blinnshed Loop Trail		/static/gpx/036_Blinnshed_Loop_Trail.gpx	0.00	Rieti		Quarto Aldobrando del friuli	USA
37	2	1.00	13	26.20	2	Unnamed Tsail		/static/gpx/037_Unnamed_Tsail.gpx	0.00	Pistoia		San Proserpina laziale	USA
38	2	1.30	22	16.80	2	Messerschmidt Wma Trail		/static/gpx/038_Messerschmidt_Wma_Trail.gpx	0.00	Chieti		Quarto Leonio terme	USA
39	2	1.20	19	18.40	2	Westwoods Nature Trail		/static/gpx/039_Westwoods_Nature_Trail.gpx	0.00	Nuoro		Sesto Bardomiano calabro	USA
40	2	0.80	12	18.10	2	Enduro		/static/gpx/040_Enduro.gpx	0.00	Terni		Quarto Scolastica lido	USA
41	2	0.90	14	8.80	2	Land Trust Trail		/static/gpx/041_Land_Trust_Trail.gpx	0.00	Alessandria		Otilia sardo	USA
42	2	0.50	8	6.90	0	Beaver Brook Park Trail		/static/gpx/042_Beaver_Brook_Park_Trail.gpx	0.00	Fermo		Quarto Taziano	USA
43	2	0.60	8	20.10	1	Housatonic Forest Trail		/static/gpx/043_Housatonic_Forest_Trail.gpx	0.00	Barletta-Andria-Trani		Sesto Liberto	USA
44	2	0.80	10	16.10	2	Farmington Canal Trail		/static/gpx/044_Farmington_Canal_Trail.gpx	0.00	Terni		Sesto Ella	USA
45	2	0.70	9	12.20	1	Beckley Furnace Park Path		/static/gpx/045_Beckley_Furnace_Park_Path.gpx	0.00	Agrigento		San Casto terme	USA
46	2	1.30	16	15.30	0	Farmington River Trail		/static/gpx/046_Farmington_River_Trail.gpx	0.00	Trento		Borgo Graziana veneto	USA
47	2	0.80	12	14.40	0	Farminton Canal Trail		/static/gpx/047_Farminton_Canal_Trail.gpx	0.00	Pavia		Pavan del friuli	USA
48	2	1.40	21	6.30	2	Farminton River Trail		/static/gpx/048_Farminton_River_Trail.gpx	0.00	La Spezia		Lo Pinto veneto	USA
49	2	4.70	70	12.80	1	Hop River Trail		/static/gpx/049_Hop_River_Trail.gpx	0.00	Barletta-Andria-Trani		Sesto Enea nell'emilia	USA
50	2	0.60	10	9.60	1	Hoprivertrail - Detouraround316		/static/gpx/050_Hoprivertrail___Detouraround316.gpx	0.00	Terni		Zamboni laziale	USA
51	2	0.80	11	5.00	2	Hop River Trail - Long Hill Rd.		/static/gpx/051_Hop_River_Trail___Long_Hill_Rd_.gpx	0.00	Parma		Notaro sardo	USA
52	2	0.90	15	22.40	0	Hop River Trail - Rockville Spur		/static/gpx/052_Hop_River_Trail___Rockville_Spur.gpx	0.00	Pistoia		Giacinto ligure	USA
53	2	0.60	7	16.70	0	Housatonic Rail Trail		/static/gpx/053_Housatonic_Rail_Trail.gpx	0.00	Pistoia		Leoncini ligure	USA
54	2	2.00	27	19.80	1	Middletown Bikeway		/static/gpx/054_Middletown_Bikeway.gpx	0.00	Avellino		Adelmo veneto	USA
55	2	1.50	23	18.80	2	Mattabesett Trolley Trail		/static/gpx/055_Mattabesett_Trolley_Trail.gpx	0.00	Medio Campidano		Bisconti umbro	USA
56	2	1.50	23	18.00	2	Moosup Valley State Park Trail		/static/gpx/056_Moosup_Valley_State_Park_Trail.gpx	0.00	Enna		Borgo Alice salentino	USA
57	2	0.70	9	20.10	0	Quinnebaug River Trail		/static/gpx/057_Quinnebaug_River_Trail.gpx	0.00	Trapani		Agrippa ligure	USA
58	2	0.70	11	10.50	2	Tracey Road Trail		/static/gpx/058_Tracey_Road_Trail.gpx	0.00	Benevento		Settimo Vodingo ligure	USA
59	2	1.50	20	13.00	2	Trolley Trail		/static/gpx/059_Trolley_Trail.gpx	0.00	Prato		Sesto Donata	USA
60	2	1.20	15	21.10	2	Quinnebaug Hatchery Trail		/static/gpx/060_Quinnebaug_Hatchery_Trail.gpx	0.00	Bari		Quarto Biagio	USA
61	2	1.50	21	23.30	2	Hopeville Park Trail		/static/gpx/061_Hopeville_Park_Trail.gpx	0.00	Lecce		Elena calabro	USA
62	2	0.50	8	18.00	1	Hopeville Park Path		/static/gpx/062_Hopeville_Park_Path.gpx	0.00	Catanzaro		Nicarete terme	USA
63	2	0.50	7	11.00	2	Nehantic Trail		/static/gpx/063_Nehantic_Trail.gpx	0.00	Vercelli		Rosi veneto	USA
64	2	1.20	20	26.40	2	Camp Columbia Trail		/static/gpx/064_Camp_Columbia_Trail.gpx	0.00	Fermo		Sesto Rosmunda del friuli	USA
65	2	0.80	11	23.50	0	Shelton Land Trust Trail		/static/gpx/065_Shelton_Land_Trust_Trail.gpx	0.00	Gorizia		Sesto Desiderato	USA
66	2	1.40	18	9.60	2	Dinosaur Park Sidewalk		/static/gpx/066_Dinosaur_Park_Sidewalk.gpx	0.00	Catanzaro		Tarquini umbro	USA
67	2	0.80	11	8.60	0	Dinosaur Park Trail		/static/gpx/067_Dinosaur_Park_Trail.gpx	0.00	Genova		Crevatin veneto	USA
68	2	1.40	19	22.20	1	Access Road		/static/gpx/068_Access_Road.gpx	0.00	Bari		Quarto Severa	USA
69	2	0.80	11	28.30	2	Day Pond Park Path		/static/gpx/069_Day_Pond_Park_Path.gpx	0.00	Rimini		Bartoli terme	USA
70	2	0.70	9	30.00	1	Day Pond Park Trail		/static/gpx/070_Day_Pond_Park_Trail.gpx	0.00	Torino		Daniele laziale	USA
71	2	2.60	42	24.30	0	Salmon River Trail		/static/gpx/071_Salmon_River_Trail.gpx	0.00	Padova		Settimo Ubaldo	USA
72	2	1.10	16	19.50	2	Salmon River Trial		/static/gpx/072_Salmon_River_Trial.gpx	0.00	Messina		Amabile veneto	USA
73	2	0.80	11	8.40	0	Dennis Hill Park Trail		/static/gpx/073_Dennis_Hill_Park_Trail.gpx	0.00	Savona		Sesto Dalida salentino	USA
74	2	1.00	16	9.80	1	Railroad Trail		/static/gpx/074_Railroad_Trail.gpx	0.00	Livorno		Sesto Vezio calabro	USA
75	2	0.90	12	25.00	2	Gillette Castle Trail		/static/gpx/075_Gillette_Castle_Trail.gpx	0.00	Nuoro		Sesto Alceste sardo	USA
76	2	1.40	19	5.10	1	Kent Falls Park Path		/static/gpx/076_Kent_Falls_Park_Path.gpx	0.00	Isernia		Settimo Cointa	USA
77	2	1.10	14	19.60	1	Kent Falls Park Trail		/static/gpx/077_Kent_Falls_Park_Trail.gpx	0.00	Como		Borgo Isotta sardo	USA
78	2	0.60	8	17.60	2	Lovers Leap Park Trail		/static/gpx/078_Lovers_Leap_Park_Trail.gpx	0.00	Vercelli		La Monaca veneto	USA
79	2	0.50	8	24.40	1	Enders Forest Trail		/static/gpx/079_Enders_Forest_Trail.gpx	0.00	Teramo		Settimo Ofelia lido	USA
80	2	0.70	10	11.10	1	Gay City Park Path		/static/gpx/080_Gay_City_Park_Path.gpx	0.00	Viterbo		Settimo Sabato	USA
81	2	0.90	13	18.70	0	Gay City Park Trail		/static/gpx/081_Gay_City_Park_Trail.gpx	0.00	Vercelli		Alfio a mare	USA
82	2	1.50	21	5.00	1	Split Rock Trail		/static/gpx/082_Split_Rock_Trail.gpx	0.00	Firenze		Quarto Fiorenza veneto	USA
83	2	1.10	15	27.60	2	Gillette Castle Path		/static/gpx/083_Gillette_Castle_Path.gpx	0.00	Cuneo		Sesto Ulfa lido	USA
84	2	1.20	18	27.10	1	Great Pond Forest Trail		/static/gpx/084_Great_Pond_Forest_Trail.gpx	0.00	Massa-Carrara		Babila sardo	USA
85	2	1.20	19	19.50	0	Haddam Meadows Park Trail		/static/gpx/085_Haddam_Meadows_Park_Trail.gpx	0.00	Agrigento		Aciscolo lido	USA
86	2	0.70	8	14.10	2	Haley Farm Park Trail		/static/gpx/086_Haley_Farm_Park_Trail.gpx	0.00	Sondrio		Quarto Aidano	USA
87	2	1.50	18	27.70	2	Hammonasset Park Path		/static/gpx/087_Hammonasset_Park_Path.gpx	0.00	La Spezia		San Ausilia veneto	USA
88	2	0.90	13	5.90	2	Nature Trail		/static/gpx/088_Nature_Trail.gpx	0.00	Lecce		Borgo Riccarda umbro	USA
89	2	1.30	19	5.40	0	Hammonasset Bike Path		/static/gpx/089_Hammonasset_Bike_Path.gpx	0.00	Chieti		Magno calabro	USA
90	2	1.10	15	12.40	2	Hammonasset Park Boardwalk		/static/gpx/090_Hammonasset_Park_Boardwalk.gpx	0.00	Cosenza		San Ezechiele	USA
91	2	1.10	13	7.10	2	Meigs Point Jetty		/static/gpx/091_Meigs_Point_Jetty.gpx	0.00	Lecco		Silvana ligure	USA
92	2	1.40	24	13.00	2	Willard Island Nature Trail		/static/gpx/092_Willard_Island_Nature_Trail.gpx	0.00	L'Aquila		Mastroianni veneto	USA
93	2	1.10	14	14.40	2	Moraine Nature Trail		/static/gpx/093_Moraine_Nature_Trail.gpx	0.00	Ferrara		Borgo Estella	USA
94	2	1.30	17	14.90	0	Haystack Park Trail		/static/gpx/094_Haystack_Park_Trail.gpx	0.00	Viterbo		Ettore lido	USA
95	2	0.70	9	25.40	2	Higganum Reservoir Park Trail		/static/gpx/095_Higganum_Reservoir_Park_Trail.gpx	0.00	Como		Matilde calabro	USA
96	2	0.70	9	26.40	2	Appalachian Trail		/static/gpx/096_Appalachian_Trail.gpx	0.00	Fermo		Erenia ligure	USA
97	2	1.10	15	27.30	1	Mohawk Trail		/static/gpx/097_Mohawk_Trail.gpx	0.00	Fermo		Sesto Umberto salentino	USA
98	2	1.30	21	7.20	2	Pine Knob Loop		/static/gpx/098_Pine_Knob_Loop.gpx	0.00	Lodi		Doro nell'emilia	USA
99	2	1.00	17	13.10	2	Appalachian/Pine Knob Loop		/static/gpx/099_Appalachian_Pine_Knob_Loop.gpx	0.00	Nuoro		San Leonia	USA
100	2	0.90	11	19.90	2	White Mountain Trail		/static/gpx/100_White_Mountain_Trail.gpx	0.00	Aosta		Falzone terme	USA
101	2	1.20	15	10.40	1	River Trail		/static/gpx/101_River_Trail.gpx	0.00	Pescara		Abbate a mare	USA
102	2	0.70	11	14.60	1	Hurd Park Trail		/static/gpx/102_Hurd_Park_Trail.gpx	0.00	Catania		Settimo Tea del friuli	USA
103	2	0.80	11	24.30	1	Hurd Park Path		/static/gpx/103_Hurd_Park_Path.gpx	0.00	Ragusa		Medugno ligure	USA
104	2	0.90	12	9.20	2	Paugussett Trail		/static/gpx/104_Paugussett_Trail.gpx	0.00	Medio Campidano		Settimo Federico terme	USA
105	2	0.80	11	11.20	1	Waterfall Trail		/static/gpx/105_Waterfall_Trail.gpx	0.00	Modena		Angeli calabro	USA
106	2	0.90	12	19.80	1	Paugussett Trail Connector		/static/gpx/106_Paugussett_Trail_Connector.gpx	0.00	Pordenone		Borgo Adina a mare	USA
107	2	1.30	16	6.90	2	Minetto Park Trail		/static/gpx/107_Minetto_Park_Trail.gpx	0.00	Avellino		Settimo Galdino	USA
108	2	1.10	15	10.20	2	Coincident Macedonia Brook Rd		/static/gpx/108_Coincident_Macedonia_Brook_Rd.gpx	0.00	Caltanissetta		Cosimo nell'emilia	USA
109	2	0.90	12	18.40	0	Coincident Weber Road		/static/gpx/109_Coincident_Weber_Road.gpx	0.00	Ragusa		Alamanno salentino	USA
110	2	3.40	43	18.60	0	Macedonia Ridge Trail		/static/gpx/110_Macedonia_Ridge_Trail.gpx	0.00	Palermo		Quarto Ultimo laziale	USA
111	2	1.30	16	5.00	2	Cobble Mountain Trail		/static/gpx/111_Cobble_Mountain_Trail.gpx	0.00	Modena		Montesano terme	USA
112	2	1.40	19	29.50	0	Shenipsit Trail		/static/gpx/112_Shenipsit_Trail.gpx	0.00	Rovigo		Fabbri terme	USA
113	2	0.60	9	23.30	2	Meshomasic Forest Trail		/static/gpx/113_Meshomasic_Forest_Trail.gpx	0.00	Fermo		Lelli nell'emilia	USA
114	2	1.40	21	21.80	2	Crest Trail		/static/gpx/114_Crest_Trail.gpx	0.00	Bologna		Sesto Calpurnia	USA
115	2	1.30	19	27.70	1	Campground Trail		/static/gpx/115_Campground_Trail.gpx	0.00	Biella		Alfredo sardo	USA
116	2	0.70	10	13.90	2	Brook Trail		/static/gpx/116_Brook_Trail.gpx	0.00	Novara		Borgo Luigia sardo	USA
117	2	1.00	15	24.70	0	Kettletown Park Trail		/static/gpx/117_Kettletown_Park_Trail.gpx	0.00	Enna		Quarto Manuele sardo	USA
118	2	0.90	12	16.90	0	North Ridge Trail		/static/gpx/118_North_Ridge_Trail.gpx	0.00	Trento		Quarto Eugenio	USA
119	2	0.60	9	6.30	1	North Ridge Loop Trail		/static/gpx/119_North_Ridge_Loop_Trail.gpx	0.00	Ogliastra		Borgo Osanna	USA
120	2	0.80	11	8.10	1	Miller Brook Connector Trail		/static/gpx/120_Miller_Brook_Connector_Trail.gpx	0.00	Cagliari		Settimo Irene lido	USA
121	2	0.60	8	8.30	2	Miller Trail		/static/gpx/121_Miller_Trail.gpx	0.00	Vibo Valentia		Borgo Cosma	USA
122	2	1.50	25	25.20	2	Miller Trail Spur		/static/gpx/122_Miller_Trail_Spur.gpx	0.00	Torino		Ermilo a mare	USA
123	2	1.20	19	26.10	1	Pomperaug Trail		/static/gpx/123_Pomperaug_Trail.gpx	0.00	Vicenza		Cannone nell'emilia	USA
124	2	1.10	16	16.40	1	Brook Trail Access		/static/gpx/124_Brook_Trail_Access.gpx	0.00	Catania		Sesto Eusebio sardo	USA
125	2	0.90	12	5.30	2	Waramaug Lake Park Trail		/static/gpx/125_Waramaug_Lake_Park_Trail.gpx	0.00	Prato		San Taziana laziale	USA
126	2	1.50	19	21.20	2	Well Groomed Trail		/static/gpx/126_Well_Groomed_Trail.gpx	0.00	Lecco		Pantaleo umbro	USA
127	2	1.30	16	26.70	1	Mashamoquet Brook Park Trail		/static/gpx/127_Mashamoquet_Brook_Park_Trail.gpx	0.00	Parma		Sesto Egeo	USA
128	2	0.60	8	10.00	2	Shenipsit Trail Spur		/static/gpx/128_Shenipsit_Trail_Spur.gpx	0.00	Roma		Azelio sardo	USA
129	2	0.70	9	14.40	0	Shenipsit		/static/gpx/129_Shenipsit.gpx	0.00	Trento		Pantaleone del friuli	USA
130	2	0.60	9	28.90	0	Nassahegon Forest Trail		/static/gpx/130_Nassahegon_Forest_Trail.gpx	0.00	Verona		Simeoni ligure	USA
131	2	1.40	17	16.30	1	Tunxis Trail		/static/gpx/131_Tunxis_Trail.gpx	0.00	Vercelli		Settimo Loredana sardo	USA
132	2	0.50	8	26.30	1	Black Spruce Bog Trail		/static/gpx/132_Black_Spruce_Bog_Trail.gpx	0.00	Vicenza		Simona ligure	USA
133	2	1.40	23	11.90	1	Mohawk Forest Trail		/static/gpx/133_Mohawk_Forest_Trail.gpx	0.00	Bari		Raniero sardo	USA
134	2	0.80	11	29.90	0	Ethan Allen Youth Trail		/static/gpx/134_Ethan_Allen_Youth_Trail.gpx	0.00	Ascoli Piceno		San Semiramide	USA
135	2	0.90	12	6.10	1	Punch Brook Trail		/static/gpx/135_Punch_Brook_Trail.gpx	0.00	Monza e della Brianza		Magno a mare	USA
136	2	1.40	22	12.90	0	Red Cedar Lake Trail		/static/gpx/136_Red_Cedar_Lake_Trail.gpx	0.00	Ogliastra		Quarto Balderico umbro	USA
137	2	0.50	8	15.10	1	Under Mountain Trail		/static/gpx/137_Under_Mountain_Trail.gpx	0.00	Padova		Flore calabro	USA
138	2	0.80	11	8.00	2	Mount Tom Trail		/static/gpx/138_Mount_Tom_Trail.gpx	0.00	Ravenna		Giardina ligure	USA
139	2	0.60	8	19.70	1	Naugatuck Trail		/static/gpx/139_Naugatuck_Trail.gpx	0.00	Brescia		Salvi ligure	USA
140	2	0.50	8	24.00	1	Nehantic Forest Trail		/static/gpx/140_Nehantic_Forest_Trail.gpx	0.00	Novara		Beniamino sardo	USA
141	2	0.90	14	22.40	0	Naugatuck Forest Trail		/static/gpx/141_Naugatuck_Forest_Trail.gpx	0.00	Perugia		Urdino lido	USA
142	2	0.60	8	27.80	1	Naugatuck Spur		/static/gpx/142_Naugatuck_Spur.gpx	0.00	Avellino		San Gerino	USA
143	2	1.30	19	19.50	0	Whitemore Trail		/static/gpx/143_Whitemore_Trail.gpx	0.00	Barletta-Andria-Trani		Settimo Marzia calabro	USA
144	2	1.60	27	8.80	0	Quinnipiac Trail		/static/gpx/144_Quinnipiac_Trail.gpx	0.00	Monza e della Brianza		Alessia calabro	USA
145	2	1.10	15	5.20	2	Nehantic Forest Trai		/static/gpx/145_Nehantic_Forest_Trai.gpx	0.00	Firenze		Borgo Sabino	USA
146	2	0.50	7	7.70	2	Nepaug Forest Trail		/static/gpx/146_Nepaug_Forest_Trail.gpx	0.00	Carbonia-Iglesias		Quarto Giovanni terme	USA
147	2	1.50	22	15.00	2	Naugatuck		/static/gpx/147_Naugatuck.gpx	0.00	Vibo Valentia		Sesto Paola	USA
148	2	1.50	25	12.80	0	Nyantaquit Trail		/static/gpx/148_Nyantaquit_Trail.gpx	0.00	Lucca		Lazzaro sardo	USA
149	2	0.60	10	16.80	1	Tipping Rock Loop Trail		/static/gpx/149_Tipping_Rock_Loop_Trail.gpx	0.00	Caltanissetta		Calogera ligure	USA
150	2	1.10	15	26.20	0	Valley Outlook Trail		/static/gpx/150_Valley_Outlook_Trail.gpx	0.00	Alessandria		San Enimia nell'emilia	USA
151	2	0.50	8	7.30	2	Shelter 4 Loop Trail		/static/gpx/151_Shelter_4_Loop_Trail.gpx	0.00	Prato		Borgo Celinia calabro	USA
152	2	1.20	15	24.40	2	Osbornedale Park Trail		/static/gpx/152_Osbornedale_Park_Trail.gpx	0.00	Enna		Borgo Raffaella	USA
153	2	0.90	12	10.90	0	Unnamed		/static/gpx/153_Unnamed.gpx	0.00	Foggia		Albina terme	USA
154	2	1.20	20	23.40	1	Paugnut Forest Trail		/static/gpx/154_Paugnut_Forest_Trail.gpx	0.00	Ogliastra		Oddone sardo	USA
155	2	1.50	18	29.50	1	Charles L Pack Trail		/static/gpx/155_Charles_L_Pack_Trail.gpx	0.00	Firenze		Nocerino lido	USA
156	2	0.50	8	9.80	0	Peoples Forest Trail		/static/gpx/156_Peoples_Forest_Trail.gpx	0.00	Foggia		Tobia del friuli	USA
157	2	1.40	17	26.30	0	Putnam Memorial Trail		/static/gpx/157_Putnam_Memorial_Trail.gpx	0.00	Ancona		Bellino laziale	USA
158	2	0.60	10	11.30	2	Platt Hill Park Trail		/static/gpx/158_Platt_Hill_Park_Trail.gpx	0.00	Caltanissetta		Pastorino nell'emilia	USA
159	2	1.40	17	9.30	2	Metacomet Trail		/static/gpx/159_Metacomet_Trail.gpx	0.00	Vibo Valentia		Borgo Giambattista nell'emilia	USA
160	2	0.50	7	13.90	0	Metacomet Trail Bypass		/static/gpx/160_Metacomet_Trail_Bypass.gpx	0.00	Taranto		Quarto Zosima	USA
161	2	1.50	23	10.60	0	Penwood Park Trail		/static/gpx/161_Penwood_Park_Trail.gpx	0.00	Prato		Leandro salentino	USA
162	2	1.00	13	11.50	2	Quadick Park Path		/static/gpx/162_Quadick_Park_Path.gpx	0.00	Verbano-Cusio-Ossola		Aquilino veneto	USA
163	2	0.70	10	9.90	2	Quadick Red Trail		/static/gpx/163_Quadick_Red_Trail.gpx	0.00	Imperia		San Ciro	USA
164	2	0.50	8	28.50	0	Pootatuck Forest Trail		/static/gpx/164_Pootatuck_Forest_Trail.gpx	0.00	Pordenone		Settimo Cunegonda	USA
165	2	0.70	11	13.10	2	River Highland Park Trail		/static/gpx/165_River_Highland_Park_Trail.gpx	0.00	Pordenone		Sesto Vittore	USA
166	2	1.30	19	6.20	1	Tunxis		/static/gpx/166_Tunxis.gpx	0.00	Bologna		Castaldo lido	USA
167	2	0.90	15	16.00	2	Old Furnace Trail		/static/gpx/167_Old_Furnace_Trail.gpx	0.00	Benevento		Alberto sardo	USA
168	2	1.10	15	9.10	2	Old Furnace Park Trail		/static/gpx/168_Old_Furnace_Park_Trail.gpx	0.00	Cagliari		Luzi salentino	USA
169	2	0.50	8	8.80	0	Kestral Trail		/static/gpx/169_Kestral_Trail.gpx	0.00	Caltanissetta		Atanasia del friuli	USA
170	2	0.60	8	12.40	2	Warbler Trail		/static/gpx/170_Warbler_Trail.gpx	0.00	Grosseto		San Dionigi veneto	USA
171	2	1.00	14	13.80	0	Muir Trail		/static/gpx/171_Muir_Trail.gpx	0.00	Brescia		Pelagia ligure	USA
172	2	1.30	21	27.70	2	Shadow Pond Nature Trail		/static/gpx/172_Shadow_Pond_Nature_Trail.gpx	0.00	Fermo		Diletta nell'emilia	USA
173	2	0.80	10	17.00	2	Jesse Gerard Trail		/static/gpx/173_Jesse_Gerard_Trail.gpx	0.00	Barletta-Andria-Trani		San Trasea umbro	USA
174	2	0.80	10	29.00	1	Robert Ross Trail		/static/gpx/174_Robert_Ross_Trail.gpx	0.00	Asti		Quarto Muziano	USA
175	2	0.80	10	26.00	0	Agnes Bowen Trail		/static/gpx/175_Agnes_Bowen_Trail.gpx	0.00	Benevento		Menozzi nell'emilia	USA
176	2	1.10	16	18.70	0	Elliot Bronson Trail		/static/gpx/176_Elliot_Bronson_Trail.gpx	0.00	Terni		Quarto Verena	USA
177	2	0.60	9	19.40	0	Walt Landgraf Trail		/static/gpx/177_Walt_Landgraf_Trail.gpx	0.00	Livorno		Festo laziale	USA
178	2	0.60	7	15.00	1	Squantz Pond Park Trail		/static/gpx/178_Squantz_Pond_Park_Trail.gpx	0.00	Pesaro e Urbino		Sesto Fiorenzo	USA
179	2	1.10	17	27.80	2	Putnam Memorial Museum Trail		/static/gpx/179_Putnam_Memorial_Museum_Trail.gpx	0.00	Matera		Alamanno umbro	USA
180	2	1.00	14	26.20	1	Quinnipiac Park Trail		/static/gpx/180_Quinnipiac_Park_Trail.gpx	0.00	Ravenna		Mercurio salentino	USA
181	2	1.40	20	5.10	0	Boardwalk		/static/gpx/181_Boardwalk.gpx	0.00	Catania		Borgo Eginardo sardo	USA
182	2	1.40	18	18.40	1	Rocky Neck Park Sidewalk		/static/gpx/182_Rocky_Neck_Park_Sidewalk.gpx	0.00	Medio Campidano		Genziano veneto	USA
183	2	1.10	16	6.90	0	Rocky Neck Park Path		/static/gpx/183_Rocky_Neck_Park_Path.gpx	0.00	Foggia		Magliocco calabro	USA
184	2	1.50	22	14.60	0	Rocky Neck Park Trail		/static/gpx/184_Rocky_Neck_Park_Trail.gpx	0.00	Agrigento		Quarto Viviano	USA
185	2	1.00	15	23.80	1	Rope Swing		/static/gpx/185_Rope_Swing.gpx	0.00	Imperia		Rocchi del friuli	USA
186	2	0.60	9	11.00	1	Sherwood Island Park Path		/static/gpx/186_Sherwood_Island_Park_Path.gpx	0.00	Pavia		Prospera a mare	USA
187	2	1.20	19	25.40	0	Sleeping Giant Park Trail		/static/gpx/187_Sleeping_Giant_Park_Trail.gpx	0.00	Lodi		Settimo Morgana	USA
188	2	0.70	8	21.50	0	Sherwood Island Nature Trail		/static/gpx/188_Sherwood_Island_Nature_Trail.gpx	0.00	Verona		Iovino veneto	USA
189	2	0.60	10	6.40	0	Sleeping Giant Park Path		/static/gpx/189_Sleeping_Giant_Park_Path.gpx	0.00	Parma		Alcamo del friuli	USA
190	2	0.70	10	17.30	1	Tower Trail		/static/gpx/190_Tower_Trail.gpx	0.00	Ascoli Piceno		San Plutarco a mare	USA
191	2	1.30	19	26.00	0	Quinnipiac Trail Spur		/static/gpx/191_Quinnipiac_Trail_Spur.gpx	0.00	Modena		San Amone	USA
192	2	0.60	10	23.10	1	Southford Falls Park Trail		/static/gpx/192_Southford_Falls_Park_Trail.gpx	0.00	Gorizia		Tina veneto	USA
193	2	1.00	15	29.10	1	Tunxis Forest Trail		/static/gpx/193_Tunxis_Forest_Trail.gpx	0.00	Salerno		Schettino ligure	USA
194	2	1.20	17	25.70	0	Sleeping Giant Trail		/static/gpx/194_Sleeping_Giant_Trail.gpx	0.00	Grosseto		Quarto Rosmunda laziale	USA
195	2	0.60	9	18.30	2	Stratton Brook Park Path		/static/gpx/195_Stratton_Brook_Park_Path.gpx	0.00	Sondrio		San Gerino ligure	USA
196	2	1.40	19	23.00	1	Bike Trail		/static/gpx/196_Bike_Trail.gpx	0.00	Terni		Mura nell'emilia	USA
197	2	1.00	13	17.60	1	Stratton Brook Park Trail		/static/gpx/197_Stratton_Brook_Park_Trail.gpx	0.00	Reggio Calabria		San Saffiro	USA
198	2	1.20	16	6.90	2	Simsbury Park Trail		/static/gpx/198_Simsbury_Park_Trail.gpx	0.00	Enna		Sesto Emiliana lido	USA
199	2	0.90	11	6.10	0	Wolcott Trail		/static/gpx/199_Wolcott_Trail.gpx	0.00	Bolzano		Errichiello calabro	USA
200	2	1.20	16	23.60	0	Madden Fyler Pond Trail		/static/gpx/200_Madden_Fyler_Pond_Trail.gpx	0.00	Torino		Quarto Margherita veneto	USA
201	2	1.00	16	5.30	0	Sunny Brook Park Trail		/static/gpx/201_Sunny_Brook_Park_Trail.gpx	0.00	Taranto		Ermes sardo	USA
202	2	0.50	6	5.40	0	Fadoir Spring Trail		/static/gpx/202_Fadoir_Spring_Trail.gpx	0.00	Pescara		Piscitelli ligure	USA
203	2	1.10	16	20.90	2	Fadoir Trail		/static/gpx/203_Fadoir_Trail.gpx	0.00	Grosseto		Settimo Sigfrido	USA
204	2	1.10	14	24.30	2	Walnut Mountain Trail		/static/gpx/204_Walnut_Mountain_Trail.gpx	0.00	Arezzo		Zeno veneto	USA
205	2	0.50	7	5.70	0	Wolcott		/static/gpx/205_Wolcott.gpx	0.00	Treviso		Pastorino lido	USA
206	2	0.90	13	13.80	1	Old Metacomet Trail		/static/gpx/206_Old_Metacomet_Trail.gpx	0.00	Benevento		Caiazzo terme	USA
207	2	0.80	12	21.80	0	Talcott Mountain Park Trail		/static/gpx/207_Talcott_Mountain_Park_Trail.gpx	0.00	Genova		La Rocca laziale	USA
208	2	1.40	22	26.90	0	Falls Brook Trail		/static/gpx/208_Falls_Brook_Trail.gpx	0.00	Modena		Sesto Attila ligure	USA
209	2	1.50	25	27.40	2	Whittemore Glen Trail		/static/gpx/209_Whittemore_Glen_Trail.gpx	0.00	Salerno		Sapiente veneto	USA
210	2	0.90	14	7.50	0	Wharton Brook Park Trail		/static/gpx/210_Wharton_Brook_Park_Trail.gpx	0.00	Trento		Borgo Adone	USA
211	2	5.40	67	22.10	2	Larkin Bridle Trail		/static/gpx/211_Larkin_Bridle_Trail.gpx	0.00	Cuneo		Fosco umbro	USA
212	2	1.00	14	27.20	0	Bluff Point Bike Path		/static/gpx/212_Bluff_Point_Bike_Path.gpx	0.00	Forlì-Cesena		Boris del friuli	USA
213	2	1.30	17	15.70	2	Bluff Point Trail		/static/gpx/213_Bluff_Point_Trail.gpx	0.00	Lecce		Settimo Alvaro	USA
214	2	1.40	17	22.70	1	Hrt - Main Street Spur		/static/gpx/214_Hrt___Main_Street_Spur.gpx	0.00	Ragusa		Blanc sardo	USA
215	2	1.50	21	9.00	2	Laurel Brook Trail		/static/gpx/215_Laurel_Brook_Trail.gpx	0.00	Padova		Settimo Vladimiro	USA
216	2	1.10	18	27.90	2	Wadsworth Falls Park Trail		/static/gpx/216_Wadsworth_Falls_Park_Trail.gpx	0.00	Arezzo		Borgo Gioberto	USA
217	2	1.20	15	16.30	2	White Birch Trail		/static/gpx/217_White_Birch_Trail.gpx	0.00	Carbonia-Iglesias		Borgo Graciliano laziale	USA
218	2	1.40	17	11.80	2	Red Cedar Trail		/static/gpx/218_Red_Cedar_Trail.gpx	0.00	Forlì-Cesena		Amanda a mare	USA
219	2	1.50	24	11.70	2	Little Falls Trail		/static/gpx/219_Little_Falls_Trail.gpx	0.00	Reggio Emilia		San Querano	USA
220	2	0.70	10	24.30	2	Deer Trail		/static/gpx/220_Deer_Trail.gpx	0.00	Salerno		Rallo laziale	USA
221	2	1.50	20	20.10	2	Rockfall Land Trust Trail		/static/gpx/221_Rockfall_Land_Trust_Trail.gpx	0.00	Messina		Nocentini terme	USA
222	2	0.80	10	24.70	2	Bridge Trail		/static/gpx/222_Bridge_Trail.gpx	0.00	Isernia		Borgo Rodiano	USA
223	2	0.70	11	19.90	2	Main Trail		/static/gpx/223_Main_Trail.gpx	0.00	Isernia		Mastrogiacomo salentino	USA
224	2	0.80	12	22.50	2	American Legion Forest Trail		/static/gpx/224_American_Legion_Forest_Trail.gpx	0.00	Cremona		Evangelista sardo	USA
225	2	1.20	16	9.80	2	Turkey Vultures Ledges Trail		/static/gpx/225_Turkey_Vultures_Ledges_Trail.gpx	0.00	Pordenone		Quarto Antonella	USA
226	2	5.20	86	18.70	2	Henry R Buck Trail		/static/gpx/226_Henry_R_Buck_Trail.gpx	0.00	Avellino		Leonida laziale	USA
227	2	1.10	16	24.10	2	Mashapaug Pond View Trail		/static/gpx/227_Mashapaug_Pond_View_Trail.gpx	0.00	Brescia		Perilli nell'emilia	USA
228	2	1.10	14	7.40	2	Bigelow Hollow Park Trail		/static/gpx/228_Bigelow_Hollow_Park_Trail.gpx	0.00	Ogliastra		Trovato ligure	USA
229	2	1.20	19	10.50	2	Breakneck Pond View Trail		/static/gpx/229_Breakneck_Pond_View_Trail.gpx	0.00	Enna		Sesto Norina	USA
230	2	1.40	19	30.00	2	East Ridge Trail		/static/gpx/230_East_Ridge_Trail.gpx	0.00	Udine		Liberati veneto	USA
231	2	1.20	18	15.90	2	Bigelow Pond Loop Trail		/static/gpx/231_Bigelow_Pond_Loop_Trail.gpx	0.00	Potenza		Gianluigi del friuli	USA
232	2	1.10	15	29.50	2	Ridge Trail		/static/gpx/232_Ridge_Trail.gpx	0.00	Cremona		Quarto Melchiade sardo	USA
233	2	1.10	16	16.30	2	Nipmuck Trail		/static/gpx/233_Nipmuck_Trail.gpx	0.00	Padova		Mercuri calabro	USA
234	2	0.50	8	10.10	2	Mattatuck Trail		/static/gpx/234_Mattatuck_Trail.gpx	0.00	Prato		Vidiano a mare	USA
235	2	1.00	12	20.40	2	Black Rock Park Trail		/static/gpx/235_Black_Rock_Park_Trail.gpx	0.00	Nuoro		Lolli lido	USA
236	2	0.50	9	21.10	1	Poquonnock River Walk		/static/gpx/236_Poquonnock_River_Walk.gpx	0.00	Ravenna		Sesto Iacopone umbro	USA
237	2	1.40	20	13.50	2	Kempf & Shenipsit Trail		/static/gpx/237_Kempf___Shenipsit_Trail.gpx	0.00	Parma		Borgo Siro sardo	USA
238	2	0.80	10	10.50	1	Kempf Trail		/static/gpx/238_Kempf_Trail.gpx	0.00	Vercelli		Borgo Adelfo	USA
239	2	0.80	12	22.50	0	Railroad Bed		/static/gpx/239_Railroad_Bed.gpx	0.00	Pavia		Generosa calabro	USA
240	2	0.70	12	16.20	0	Mohegan Trail		/static/gpx/240_Mohegan_Trail.gpx	0.00	Rimini		Romilda laziale	USA
241	2	1.50	20	9.10	1	Burr Pond Park Trail		/static/gpx/241_Burr_Pond_Park_Trail.gpx	0.00	Udine		Sesto Aloisio calabro	USA
242	2	1.00	14	12.10	1	Burr Pond Park Path		/static/gpx/242_Burr_Pond_Park_Path.gpx	0.00	Ancona		Borgo Elvia	USA
243	2	1.50	19	16.70	0	Campbell Falls Trail		/static/gpx/243_Campbell_Falls_Trail.gpx	0.00	Catania		Quarto Liberatore sardo	USA
244	2	0.70	11	6.20	2	Deep Woods Trail		/static/gpx/244_Deep_Woods_Trail.gpx	0.00	Catanzaro		Neri a mare	USA
245	2	1.80	22	10.30	2	Chimney Trail		/static/gpx/245_Chimney_Trail.gpx	0.00	Asti		Settimo Sonia laziale	USA
246	2	0.90	13	23.50	2	Chimney Connector Trail		/static/gpx/246_Chimney_Connector_Trail.gpx	0.00	Ogliastra		Melissa del friuli	USA
247	2	1.40	24	9.20	2	East Woods Trail		/static/gpx/247_East_Woods_Trail.gpx	0.00	Barletta-Andria-Trani		Antonella a mare	USA
248	2	0.80	12	28.20	2	East Woods Connector Trail		/static/gpx/248_East_Woods_Connector_Trail.gpx	0.00	Pistoia		Carla calabro	USA
249	2	0.80	10	23.80	2	Covered Bridge Connector Trail		/static/gpx/249_Covered_Bridge_Connector_Trail.gpx	0.00	Rieti		Quarto Fernando calabro	USA
250	2	1.30	20	28.00	2	Covered Bridge Trail		/static/gpx/250_Covered_Bridge_Trail.gpx	0.00	Mantova		San Cremenzio sardo	USA
251	2	1.30	19	29.00	2	Lookout Trail		/static/gpx/251_Lookout_Trail.gpx	0.00	Livorno		Zullo del friuli	USA
252	2	1.10	16	16.70	2	Chatfield Hollow Park Trail		/static/gpx/252_Chatfield_Hollow_Park_Trail.gpx	0.00	Bologna		Settimo Attila	USA
253	2	1.40	18	13.30	2	Lookout Spur Trail		/static/gpx/253_Lookout_Spur_Trail.gpx	0.00	Lecce		Quarto Bertoldo	USA
254	2	0.80	10	13.70	2	Chimney Spur Trail		/static/gpx/254_Chimney_Spur_Trail.gpx	0.00	Ragusa		Fernanda terme	USA
255	2	1.10	14	17.70	2	Deep Woods Access Trail		/static/gpx/255_Deep_Woods_Access_Trail.gpx	0.00	Alessandria		Renda del friuli	USA
256	2	0.90	12	21.40	2	West Crest Trail		/static/gpx/256_West_Crest_Trail.gpx	0.00	Reggio Emilia		San Carla laziale	USA
257	2	0.90	13	27.20	2	Chatfield Park Path		/static/gpx/257_Chatfield_Park_Path.gpx	0.00	Forlì-Cesena		Narseo nell'emilia	USA
258	2	0.90	13	8.70	2	Pond Trail		/static/gpx/258_Pond_Trail.gpx	0.00	Reggio Emilia		Sesto Doroteo	USA
259	2	1.20	15	10.20	1	Paul F Wildermann		/static/gpx/259_Paul_F_Wildermann.gpx	0.00	Prato		Settimo Azelia	USA
260	2	0.90	12	29.20	2	Cockaponset Forest Path		/static/gpx/260_Cockaponset_Forest_Path.gpx	0.00	Savona		Sesto Lapo	USA
261	2	0.60	10	19.10	2	Kay Fullerton Trail		/static/gpx/261_Kay_Fullerton_Trail.gpx	0.00	Torino		San Dodato terme	USA
262	2	1.00	12	25.90	2	Quinimay Trail		/static/gpx/262_Quinimay_Trail.gpx	0.00	Cremona		Quarto Agapito lido	USA
263	2	1.00	14	11.10	2	Cowboy Way Trail		/static/gpx/263_Cowboy_Way_Trail.gpx	0.00	Trento		Settimo Annibale	USA
264	2	1.10	13	14.10	2	Muck Rock Road Trail		/static/gpx/264_Muck_Rock_Road_Trail.gpx	0.00	Vibo Valentia		Quarto Sabino	USA
265	2	0.90	11	23.60	2	Weber Road Trail		/static/gpx/265_Weber_Road_Trail.gpx	0.00	Como		Sesto Gaudino calabro	USA
266	2	0.80	12	7.00	2	Beechnut Bog Trail		/static/gpx/266_Beechnut_Bog_Trail.gpx	0.00	Massa-Carrara		Liberto terme	USA
267	2	0.60	9	6.30	2	Wood Road Trail		/static/gpx/267_Wood_Road_Trail.gpx	0.00	Padova		San Calogero sardo	USA
268	2	0.70	11	9.60	2	Bumpy Hill Road Trail		/static/gpx/268_Bumpy_Hill_Road_Trail.gpx	0.00	Firenze		Bertolini umbro	USA
269	2	1.30	21	17.10	2	Kristens Way Trail		/static/gpx/269_Kristens_Way_Trail.gpx	0.00	Enna		Borgo Dulina	USA
270	2	1.50	19	6.00	2	Messerschmidt Lane Trail		/static/gpx/270_Messerschmidt_Lane_Trail.gpx	0.00	Isernia		Monica laziale	USA
271	2	1.30	21	25.20	2	Tower Hill Connector Trail		/static/gpx/271_Tower_Hill_Connector_Trail.gpx	0.00	Benevento		Angela veneto	USA
272	2	1.60	26	5.60	2	Mattabesset Trail		/static/gpx/272_Mattabesset_Trail.gpx	0.00	Bolzano		Guastella calabro	USA
273	2	0.80	11	22.50	2	Mattabasset Trail		/static/gpx/273_Mattabasset_Trail.gpx	0.00	Ferrara		San Graziano	USA
274	2	1.20	20	17.30	2	Old Mattebesset Trail		/static/gpx/274_Old_Mattebesset_Trail.gpx	0.00	Torino		Leonzio sardo	USA
275	2	0.70	10	14.50	2	Huntington Park Trail		/static/gpx/275_Huntington_Park_Trail.gpx	0.00	Sondrio		Quarto Norina	USA
276	2	1.50	24	16.10	2	Huntington Ridge Trail		/static/gpx/276_Huntington_Ridge_Trail.gpx	0.00	Verona		Quarto Asella	USA
277	2	0.60	9	21.40	2	Aspetuck Valley Trail		/static/gpx/277_Aspetuck_Valley_Trail.gpx	0.00	Pisa		Settimo Rosalinda umbro	USA
278	2	1.50	23	11.30	2	Vista Trail		/static/gpx/278_Vista_Trail.gpx	0.00	Fermo		Sesto Abibo sardo	USA
279	2	1.20	16	16.90	2	Devils Hopyard Park Trail		/static/gpx/279_Devils_Hopyard_Park_Trail.gpx	0.00	Medio Campidano		Settimo Marinetta laziale	USA
280	2	1.00	14	25.40	2	Witch Hazel/Millington Trail		/static/gpx/280_Witch_Hazel_Millington_Trail.gpx	0.00	Viterbo		Settimo Santina nell'emilia	USA
281	2	1.50	20	22.40	2	Millington Trail		/static/gpx/281_Millington_Trail.gpx	0.00	Carbonia-Iglesias		Sesto Egeo	USA
282	2	1.40	23	9.20	2	Loop Trail		/static/gpx/282_Loop_Trail.gpx	0.00	Sassari		San Wanda	USA
283	2	2.00	28	5.00	2	Witch Hazel Trail		/static/gpx/283_Witch_Hazel_Trail.gpx	0.00	Reggio Emilia		Di Palma calabro	USA
284	2	1.60	27	17.50	2	Woodcutters Trail		/static/gpx/284_Woodcutters_Trail.gpx	0.00	Livorno		Quarto Miriam	USA
285	2	0.90	15	16.00	2	Chapman Falls Trail		/static/gpx/285_Chapman_Falls_Trail.gpx	0.00	Crotone		San Apollonia terme	USA
286	2	1.40	24	9.20	2	Devils Oven Spur Trail		/static/gpx/286_Devils_Oven_Spur_Trail.gpx	0.00	Pistoia		De Biase veneto	USA
287	2	3.10	39	27.60	2	Maxs Trail		/static/gpx/287_Maxs_Trail.gpx	0.00	Trento		Mansueto umbro	USA
288	2	0.60	10	27.90	1	Machimoodus Park Trail		/static/gpx/288_Machimoodus_Park_Trail.gpx	0.00	Fermo		Zenaide salentino	USA
289	2	1.50	19	11.40	2	Fishermans Trail		/static/gpx/289_Fishermans_Trail.gpx	0.00	Pisa		Sesto Porfirio veneto	USA
290	2	2.20	29	7.20	2	Ccc Trail		/static/gpx/290_Ccc_Trail.gpx	0.00	Ragusa		Sesto Virginio calabro	USA
291	2	0.80	13	24.20	2	Natchaug Trail		/static/gpx/291_Natchaug_Trail.gpx	0.00	L'Aquila		Aniello sardo	USA
292	2	1.40	17	25.60	2	Natchaug Forest Trail		/static/gpx/292_Natchaug_Forest_Trail.gpx	0.00	Novara		Settimo Manlio	USA
293	2	1.10	14	26.40	2	Goodwin Forest Trail		/static/gpx/293_Goodwin_Forest_Trail.gpx	0.00	Trapani		Sesto Gaglioffo salentino	USA
294	2	0.90	12	23.70	2	Pine Acres Pond Trail		/static/gpx/294_Pine_Acres_Pond_Trail.gpx	0.00	Sassari		Borgo Claudio veneto	USA
295	2	0.50	8	11.80	2	Brown Hill Pond Trail		/static/gpx/295_Brown_Hill_Pond_Trail.gpx	0.00	Grosseto		Illidio laziale	USA
296	2	1.50	19	16.90	2	Yellow White Loop Trail		/static/gpx/296_Yellow_White_Loop_Trail.gpx	0.00	Benevento		Isidora a mare	USA
297	2	0.70	10	19.40	2	Red Yellow Connector Trail		/static/gpx/297_Red_Yellow_Connector_Trail.gpx	0.00	Novara		Mario veneto	USA
298	2	1.00	16	6.80	2	Governor'S Island Trail		/static/gpx/298_Governor_S_Island_Trail.gpx	0.00	Varese		Lombardo calabro	USA
299	2	0.50	7	26.60	2	Goodwin Foresttrail		/static/gpx/299_Goodwin_Foresttrail.gpx	0.00	Lodi		Taormina calabro	USA
300	2	1.40	20	14.50	2	Forest Discovery Trail		/static/gpx/300_Forest_Discovery_Trail.gpx	0.00	Milano		Ciotti lido	USA
301	2	0.70	9	13.40	2	Goodwin Heritage Trail		/static/gpx/301_Goodwin_Heritage_Trail.gpx	0.00	Trieste		San Simone	USA
302	2	1.00	16	11.60	2	Crest		/static/gpx/302_Crest.gpx	0.00	Biella		Quarto Erardo	USA
303	2	1.60	27	9.60	2	Mansfield Hollow Park Trail		/static/gpx/303_Mansfield_Hollow_Park_Trail.gpx	0.00	Belluno		Quarto Gertrude	USA
304	2	0.70	10	17.90	0	Nipmuck Trail - East Branch		/static/gpx/304_Nipmuck_Trail___East_Branch.gpx	0.00	Vibo Valentia		Gustavo sardo	USA
305	2	2.40	38	13.50	0	Nipmuck Alternate		/static/gpx/305_Nipmuck_Alternate.gpx	0.00	Avellino		Borgo Fleano	USA
306	2	1.40	20	19.20	0	Mashamoquet Brook Nature Trail		/static/gpx/306_Mashamoquet_Brook_Nature_Trail.gpx	0.00	Trapani		Settimo Alcibiade	USA
307	2	0.90	13	6.10	2	Nipmuck Forest Trail		/static/gpx/307_Nipmuck_Forest_Trail.gpx	0.00	Grosseto		Venerio ligure	USA
308	2	1.10	18	27.60	2	Morey Pond Trail		/static/gpx/308_Morey_Pond_Trail.gpx	0.00	Bolzano		Cerri nell'emilia	USA
309	2	1.20	16	13.90	2	Nipmuck Foreat Trail		/static/gpx/309_Nipmuck_Foreat_Trail.gpx	0.00	Ragusa		Porfirio nell'emilia	USA
310	2	1.50	20	6.90	2	Pharisee Rock Trail		/static/gpx/310_Pharisee_Rock_Trail.gpx	0.00	Genova		San Ezechiele	USA
311	2	1.00	13	7.60	2	Pachaug Forest Trail		/static/gpx/311_Pachaug_Forest_Trail.gpx	0.00	Foggia		Sesto Arabella umbro	USA
312	2	0.70	9	20.00	2	Pachaug Trail		/static/gpx/312_Pachaug_Trail.gpx	0.00	Matera		Piero del friuli	USA
313	2	1.10	14	19.10	2	Canonicus Trail		/static/gpx/313_Canonicus_Trail.gpx	0.00	Ascoli Piceno		Di Iorio terme	USA
314	2	1.40	23	23.50	2	Pachaug		/static/gpx/314_Pachaug.gpx	0.00	Pavia		Gaio lido	USA
315	2	0.50	7	22.50	2	Laurel Loop Trail		/static/gpx/315_Laurel_Loop_Trail.gpx	0.00	Nuoro		Arduino nell'emilia	USA
316	2	1.30	22	14.50	2	Pachaug/Nehantic Connector		/static/gpx/316_Pachaug_Nehantic_Connector.gpx	0.00	Monza e della Brianza		Sesto Ireneo	USA
317	2	0.70	11	8.70	2	Pachaug/Tippecansett Connector		/static/gpx/317_Pachaug_Tippecansett_Connector.gpx	0.00	Caserta		Quarto Candida	USA
318	2	1.50	22	28.20	2	Nehantic/Pachaug Connector		/static/gpx/318_Nehantic_Pachaug_Connector.gpx	0.00	Campobasso		Settimo Donato umbro	USA
319	2	1.30	19	20.00	2	Quinebaug/Pachaug Connector		/static/gpx/319_Quinebaug_Pachaug_Connector.gpx	0.00	Bolzano		San Tammaro	USA
320	2	0.90	13	29.90	2	Quinebaug Trail		/static/gpx/320_Quinebaug_Trail.gpx	0.00	Barletta-Andria-Trani		Landolfo laziale	USA
321	2	1.10	16	28.40	2	Pachaug/Narragansett Connector		/static/gpx/321_Pachaug_Narragansett_Connector.gpx	0.00	Perugia		Sesto Beata nell'emilia	USA
322	2	0.60	9	19.90	2	Narragansett Trail		/static/gpx/322_Narragansett_Trail.gpx	0.00	Savona		Cacciapuoti laziale	USA
323	2	0.70	10	18.20	2	Green Falls Loop Trail		/static/gpx/323_Green_Falls_Loop_Trail.gpx	0.00	Avellino		Orso terme	USA
324	2	0.70	9	25.50	2	Green Falls Water Access Trail		/static/gpx/324_Green_Falls_Water_Access_Trail.gpx	0.00	Ascoli Piceno		Quarto Saturniano	USA
325	2	1.20	20	14.60	2	Freeman Trail		/static/gpx/325_Freeman_Trail.gpx	0.00	Perugia		Quarto Felice a mare	USA
326	2	0.80	10	24.90	2	Tippecansett Trail		/static/gpx/326_Tippecansett_Trail.gpx	0.00	Piacenza		Settimo Agnese del friuli	USA
327	2	1.10	14	22.90	2	Tippecansett/Freeman Trail		/static/gpx/327_Tippecansett_Freeman_Trail.gpx	0.00	Varese		Iolanda a mare	USA
328	2	1.20	15	8.50	1	Green Falls Pond Trail		/static/gpx/328_Green_Falls_Pond_Trail.gpx	0.00	Isernia		Repetto a mare	USA
329	2	0.70	10	5.60	2	Nehantic/Pachaug Trail		/static/gpx/329_Nehantic_Pachaug_Trail.gpx	0.00	Ogliastra		Speranza ligure	USA
330	2	1.50	22	29.50	2	Phillips Pond Spur Trail		/static/gpx/330_Phillips_Pond_Spur_Trail.gpx	0.00	Campobasso		Sesto Gertrude nell'emilia	USA
331	2	0.80	13	27.50	2	Quinebaug/Nehantic Connector		/static/gpx/331_Quinebaug_Nehantic_Connector.gpx	0.00	Cremona		San Bruna umbro	USA
332	2	0.70	10	26.80	1	Nehantic/Quinebaug Connector		/static/gpx/332_Nehantic_Quinebaug_Connector.gpx	0.00	Forlì-Cesena		Giancarlo sardo	USA
333	2	1.40	24	7.40	0	Patagansett Trail		/static/gpx/333_Patagansett_Trail.gpx	0.00	Perugia		San Elvira a mare	USA
334	2	1.30	19	22.20	2	Paugussett Forest Trail		/static/gpx/334_Paugussett_Forest_Trail.gpx	0.00	Perugia		Sesto Giovenzio nell'emilia	USA
335	2	1.00	16	11.60	2	Zoar Trail		/static/gpx/335_Zoar_Trail.gpx	0.00	Lucca		Veneranda lido	USA
336	2	1.20	15	5.20	2	Lillinonah Trail		/static/gpx/336_Lillinonah_Trail.gpx	0.00	Bari		Aristarco a mare	USA
337	2	0.70	10	8.50	2	Zoar Trail (Old)		/static/gpx/337_Zoar_Trail__Old_.gpx	0.00	Grosseto		Borgo Michele sardo	USA
338	2	1.00	13	10.00	1	Upper Gussy Trail		/static/gpx/338_Upper_Gussy_Trail.gpx	0.00	Latina		Sesto Platone	USA
339	2	1.00	16	21.70	2	Pierrepont Park Trail		/static/gpx/339_Pierrepont_Park_Trail.gpx	0.00	Vicenza		Cipolla del friuli	USA
340	2	0.80	12	14.20	2	Shenipsit Forest Trail		/static/gpx/340_Shenipsit_Forest_Trail.gpx	0.00	Agrigento		Giuda laziale	USA
341	2	1.10	17	20.40	2	Quary Trail		/static/gpx/341_Quary_Trail.gpx	0.00	Trento		Cacciatore sardo	USA
342	2	1.00	15	11.40	2	Shenipsit Forest Road		/static/gpx/342_Shenipsit_Forest_Road.gpx	0.00	Benevento		San Ambrosiano sardo	USA
343	2	1.20	20	26.80	2	Topsmead Forest Trail		/static/gpx/343_Topsmead_Forest_Trail.gpx	0.00	Caserta		Edgardo lido	USA
344	2	2.30	29	15.90	2	Edith M Chase Ecology Trail		/static/gpx/344_Edith_M_Chase_Ecology_Trail.gpx	0.00	Latina		Renato lido	USA
345	2	0.80	11	16.80	2	Bernard H Stairs Trail		/static/gpx/345_Bernard_H_Stairs_Trail.gpx	0.00	Crotone		Restivo lido	USA
346	2	1.50	20	7.30	2	West Rock Park Trail		/static/gpx/346_West_Rock_Park_Trail.gpx	0.00	Matera		Settimo Evaristo	USA
347	2	0.60	7	14.60	2	West Rock Summit Trail		/static/gpx/347_West_Rock_Summit_Trail.gpx	0.00	Avellino		Valenza nell'emilia	USA
348	2	0.60	8	22.90	2	Regicides Trail		/static/gpx/348_Regicides_Trail.gpx	0.00	Latina		Settimo Maddalena	USA
349	2	1.10	13	19.90	0	Sanford Feeder Trail		/static/gpx/349_Sanford_Feeder_Trail.gpx	0.00	Biella		Margherita terme	USA
350	2	3.30	40	27.00	2	North Summit Trail		/static/gpx/350_North_Summit_Trail.gpx	0.00	Milano		Borgo Ramiro	USA
351	2	1.20	20	17.80	2	Westville Feeder Trail		/static/gpx/351_Westville_Feeder_Trail.gpx	0.00	Pistoia		Pizzimenti terme	USA
352	2	0.70	8	27.00	1	West Rock Park Road		/static/gpx/352_West_Rock_Park_Road.gpx	0.00	Udine		Rapuano umbro	USA
353	2	1.10	19	14.80	1	Bennetts Pond Trail		/static/gpx/353_Bennetts_Pond_Trail.gpx	0.00	Pisa		Sesto Iride	USA
354	2	1.50	25	19.40	0	Ives Trail		/static/gpx/354_Ives_Trail.gpx	0.00	Siena		San Gosto a mare	USA
355	2	1.00	13	14.00	2	Ridgefield Open Space Trail		/static/gpx/355_Ridgefield_Open_Space_Trail.gpx	0.00	Massa-Carrara		Quarto Sicuro laziale	USA
356	2	1.10	15	11.30	1	George Dudley Seymour Park Trail		/static/gpx/356_George_Dudley_Seymour_Park_Trail.gpx	0.00	Salerno		Serafini terme	USA
357	2	1.10	14	23.10	0	Grta		/static/gpx/357_Grta.gpx	0.00	Rovigo		Dina veneto	USA
358	2	1.10	14	9.90	0	Mohegan Forest Trail		/static/gpx/358_Mohegan_Forest_Trail.gpx	0.00	Massa-Carrara		Sesto Gianpietro	USA
359	2	2.10	30	12.90	1	Mount Bushnell Trail		/static/gpx/359_Mount_Bushnell_Trail.gpx	0.00	Barletta-Andria-Trani		Sesto Aquilino	USA
360	2	1.20	14	13.60	2	Nye Holman Trail		/static/gpx/360_Nye_Holman_Trail.gpx	0.00	Gorizia		Demontis a mare	USA
361	2	1.50	19	20.50	2	Al'S Trail		/static/gpx/361_Al_S_Trail.gpx	0.00	Rimini		Taziano sardo	USA
362	2	1.00	13	26.00	2	Salt Rock State Park Trail		/static/gpx/362_Salt_Rock_State_Park_Trail.gpx	0.00	Grosseto		Settimo Ezio lido	USA
363	2	0.80	12	23.70	2	Scantic River Trail		/static/gpx/363_Scantic_River_Trail.gpx	0.00	Belluno		Sesto Riccardo	USA
364	2	1.30	18	23.80	0	Scantic River Park Trail		/static/gpx/364_Scantic_River_Park_Trail.gpx	0.00	Pavia		Settimo Varo	USA
365	2	0.60	8	19.70	2	Scantic Park Access		/static/gpx/365_Scantic_Park_Access.gpx	0.00	Udine		Sesto Carlo	USA
366	2	0.80	12	11.80	0	Sunrise Park Trail		/static/gpx/366_Sunrise_Park_Trail.gpx	0.00	Cosenza		Viscardo laziale	USA
367	2	2.20	27	12.70	1	Kitchel Trail		/static/gpx/367_Kitchel_Trail.gpx	0.00	Pordenone		Settimo Bonagiunta lido	USA
368	2	0.60	9	27.80	0	Old Driveway		/static/gpx/368_Old_Driveway.gpx	0.00	Trapani		Sesto Rinaldo ligure	USA
369	2	0.60	8	23.40	0	Kitchel		/static/gpx/369_Kitchel.gpx	0.00	Pisa		Capponi calabro	USA
370	2	1.10	15	29.10	2	Driveway		/static/gpx/370_Driveway.gpx	0.00	Asti		Belli veneto	USA
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website, elevation) FROM stdin;
1	1	8	55.00	Edmund-Graf-Hütte	2	Fortunata Guerriero	https://steep-vibe.it	\N
2	2	5	94.00	Dr.Hernaus-Stöckl	2	Osvaldo Valle	https://acclaimed-equinox.it	\N
3	3	8	78.00	Amstettner Hütte	2	Enea Pollina	http://exotic-mukluk.net	\N
4	4	10	138.00	Hochleckenhaus	2	Misaele Piras	https://honorable-permit.com	\N
5	5	8	53.00	Kampthalerhütte	2	Sig. Paola Buzzi	http://noteworthy-tabernacle.net	\N
6	6	7	103.00	Lambacher Hütte	2	Lamberto De Meo	https://ill-variable.org	\N
7	7	4	126.00	Lustenauer Hütte	2	Gaudino Blasi	http://cultured-metro.com	\N
8	8	7	42.00	Gablonzer Hütte	2	Armando Spada	https://made-up-botany.org	\N
9	9	5	93.00	Katafygio «Flampouri»	2	Lisa Salierno	http://inferior-polyester.com	\N
10	10	6	80.00	Simonyhütte	2	Taziana Politi	https://burdensome-grouper.org	\N
11	11	6	107.00	Vinzenz-Tollinger-Hütte	2	Otilia Fiorenza	http://puny-gnu.org	\N
12	12	8	135.00	Ottokar-Kernstock-Haus	2	Pancrazio Cavallo	http://fussy-cashier.org	\N
13	13	9	99.00	Reisseckhütte	2	Marina Oggiano	https://detailed-clogs.it	\N
14	14	8	55.00	Vernagthütte	2	Alfio Di Pietro	https://untrue-shelf.it	\N
15	15	6	92.00	Wormser Hütte	2	Sefora Iodice	https://dutiful-oboe.org	\N
16	16	6	133.00	Biberacher Hütte	2	Caio Bini	https://faint-tulip.net	\N
17	17	4	122.00	Katafygio «1777»	2	Dr. Doda Doro	http://triangular-glasses.com	\N
18	18	5	117.00	Hochwaldhütte	2	Dr. Nicea Martini	http://prestigious-warfare.com	\N
19	19	8	104.00	Kölner Eifelhütte	2	Giuliano Ceccarelli	https://quarterly-nationality.com	\N
20	20	1	73.00	Madrisahütte	2	Demostene Guidi	https://direct-cirrus.net	\N
21	21	8	77.00	Dresdner Hütte	2	Alice Colonna	https://avaricious-gobbler.it	\N
22	22	9	107.00	Fiderepasshütte	2	Maria Vicinanza	http://essential-fellow.com	\N
23	23	8	85.00	Göppinger Hütte	2	Gesualdo Pugliesi	http://gloomy-angel.it	\N
24	24	4	138.00	Oberzalimhütte	2	Feliciano Di Marco	http://troubled-refectory.it	\N
25	25	5	45.00	Rastkogelhütte	2	Liviana Repetto	https://untimely-singer.it	\N
26	26	7	140.00	Ansbacher Skihütte im Allgäu	2	Dante Leoncini	https://affectionate-pickaxe.net	\N
27	27	1	146.00	Kaltenberghütte	2	Dott. Giosuele Motisi	https://inferior-hospice.com	\N
28	28	1	120.00	Schweinfurter Hütte	2	Demetrio Di Lecce	http://scientific-post.it	\N
29	29	6	82.00	Katafygio «Vardousion»	2	Leo Sapienza	http://fabulous-mrna.org	\N
30	30	4	131.00	Kocbekov dom na Korošici	2	Filomena Campoli	https://sore-alligator.org	\N
31	31	2	48.00	Planinski dom Rašiške cete na Rašici	2	Alba Paolillo	https://confused-primate.com	\N
32	32	7	130.00	Prešernova koca na Stolu	2	Alina Cozzani	https://broken-termite.org	\N
33	33	4	71.00	Planinski dom na Mrzlici	2	Dott. Pamela Del Monte	https://powerless-prestige.com	\N
34	34	8	76.00	Koca na Planini nad Vrhniko	2	Arminio Lazzaro	https://glass-goggles.com	\N
35	35	1	76.00	Zavetišce gorske straže na Jelencih	2	Eva De Feo	https://snappy-viola.com	\N
36	36	2	55.00	Planinski dom na Gori	2	Desiderio Palmisani	http://sparkling-piccolo.it	\N
37	37	7	36.00	Bregarjevo zavetišce na planini Viševnik	2	Demetrio Fantini	http://celebrated-mayonnaise.org	\N
38	38	3	51.00	Koca pod Bogatinom	2	Pellegrino Montesano	https://spirited-sadness.it	\N
39	39	1	48.00	Pogacnikov dom na Kriških podih	2	Marinella Schiavone	http://posh-canoe.net	\N
40	40	3	128.00	Dom na Smrekovcu	2	Penelope Bonazzi	https://likely-tavern.it	\N
41	41	8	95.00	Refuge Du Chatelleret	2	Alda Giannetti	https://short-wing.org	\N
42	42	5	102.00	Refuge De Chalance	2	Innocente Cavaliere	https://vengeful-gray.com	\N
43	43	5	144.00	Refuge Des Bans	2	Duilio Guarnieri	http://punctual-ziggurat.org	\N
44	44	9	148.00	Refuge De Pombie	2	Ivo Grieco	https://large-width.net	\N
45	45	2	149.00	Refuge De Larribet	2	Valente Barbarulo	http://pretty-hake.org	\N
46	46	9	114.00	Refuge Du Mont Pourri	2	Dr. Manuela Pellegrino	https://sandy-boxer.org	\N
47	47	1	70.00	Refuge De La Dent D?Oche	2	Degna Perra	https://granular-angora.it	\N
48	48	6	109.00	Bergseehütte SAC	2	Sig. Franco Antenucci	http://optimistic-comportment.net	\N
49	49	3	113.00	Bivouac au Col de la Dent Blanche CAS	2	Adelmo Totaro	http://imperfect-song.org	\N
50	50	4	54.00	Salbitschijenbiwak SAC	2	Venerando Polizzi	http://sad-stop.com	\N
51	51	4	107.00	Spannorthütte SAC	2	Catena Coletta	https://striped-aid.com	\N
52	52	7	149.00	Cabane Arpitettaz CAS	2	Ing. Ines Alessandrini	https://easy-going-revenant.org	\N
53	53	2	84.00	Refugio De Lizara	2	Gianluigi Perin	https://large-edger.net	\N
54	54	4	111.00	Albergue De Montfalcó	2	Apollina Pacifici	http://internal-secretion.it	\N
55	55	8	117.00	El Molonillo/Peña Partida	2	Elio Lelli	http://aggressive-chug.it	\N
56	56	9	122.00	La Campiñuela	2	Saverio Quaranta	http://wry-evaporation.net	\N
57	57	5	149.00	Titov Vrv	2	Bacco Iannello	https://suburban-linguist.com	\N
58	58	8	80.00	Rifugio Franchetti	2	Alcino Tammaro	http://pointed-military.net	\N
59	59	5	142.00	Rifugio Semenza	2	Ing. Pupolo Capasso	https://pricey-deduce.it	\N
60	60	5	93.00	Rifugio Città di Mortara 	2	Salvatore Santo	https://electric-fairy.it	\N
61	61	7	46.00	Rifugio Andolla	2	Rossana Fumarola	http://luxurious-kendo.net	\N
62	62	4	86.00	Rifugio Forte dei Marmi	2	Ilenia Piazzolla	https://tight-peony.org	\N
63	63	5	38.00	Rifugio Berti	2	Lucia Modica	http://illiterate-shaker.net	\N
64	64	6	86.00	Rifugio Premuda	2	Vidone Cozzani	http://wise-diver.com	\N
65	65	6	95.00	Rifugio Elisa	2	Innocenzo Praticò	http://inferior-model.org	\N
66	66	7	60.00	Rifugio CAI Saronno	2	Ing. Amalia Di Costanzo	https://severe-bangle.it	\N
67	67	1	148.00	Rifugio Picco Ivigna	2	Osvaldo Perugini	http://slimy-reasoning.it	\N
68	68	6	127.00	Rifugio Toesca	2	Patrizio Caiazzo	http://spanish-spokeswoman.org	\N
69	69	2	135.00	Rifugio Al Cedo	2	Leonio Soldati	http://lavish-smile.it	\N
70	70	1	88.00	Capanna Gnifetti	2	Ildefonso Latorre	https://dutiful-dip.com	\N
71	71	4	76.00	Rifugio Aosta	2	Cinzia Pani	http://grave-background.net	\N
72	72	6	107.00	Rifugio Cevedale	2	Addo D'Alessio	https://organic-attempt.org	\N
73	73	4	107.00	Rifugio Ponti	2	Otello Pavani	http://ringed-incidence.it	\N
74	74	8	135.00	Rifugio XII Apostoli	2	Ing. Antonia Bucci	https://exhausted-threshold.net	\N
75	75	7	133.00	Rifugio Elisabetta Soldini	2	Demetria Barsotti	http://noted-bronze.net	\N
76	76	9	83.00	Rifugio Denza	2	Irma Ciccarelli	https://favorite-goat.com	\N
77	77	2	83.00	Rifugio Fonte Tavoloni 	2	Petronilla Silvestro	https://shadowy-bloomer.com	\N
78	78	9	102.00	Rifugio Carducci	2	Greta Gori	http://frequent-laboratory.net	\N
79	79	8	125.00	Rifugio Bindesi	2	Vilma Campus	http://odd-chairlift.it	\N
80	80	8	130.00	Mountain hut Miroslav Hirtz	2	Grazia Florio	https://judicious-waitress.net	\N
81	81	5	148.00	Koca na Blegošu	2	Ninfa Di Maria	https://fatal-activity.com	\N
82	82	3	61.00	Wittener Hütte	2	Coreno Alessi	http://moist-vineyard.com	\N
83	83	1	66.00	Hochjoch-Hospiz	2	Ludovico Ippolito	http://prudent-archeology.org	\N
84	84	4	83.00	Meilerhütte	2	Brando Simeoli	http://sinful-pressurization.com	\N
85	85	10	59.00	Gaudeamushütte	2	Sig. Amerigo Lelli	http://cuddly-confidentiality.com	\N
86	86	3	81.00	Rheydter Hütte	2	Daniele Brandi	http://hidden-dryer.org	\N
87	87	6	123.00	Sektionshütte Krippen	2	Amina Maragno	https://barren-ninja.com	\N
88	88	1	69.00	Neunkirchner Hütte	2	Nicarete Tornatore	https://messy-confirmation.net	\N
89	89	10	52.00	Refugio De Riglos	2	Davide Cavriani	https://surprised-antler.org	\N
90	90	6	149.00	Salbithütte SAC	2	Teodosio Sini	http://uncommon-plant.com	\N
91	91	2	76.00	Finsteraarhornhütte SAC	2	Fedele Luppino	https://smart-tile.com	\N
92	92	7	80.00	Cabane des Vignettes CAS	2	Melitina De Martino	https://babyish-forelimb.com	\N
93	93	9	147.00	Glecksteinhütte SAC	2	Altea Bartoli	https://responsible-jiffy.org	\N
94	94	5	125.00	Länta-Hütte SAC	2	Lisandro Santarelli	https://weary-tackle.com	\N
95	95	4	91.00	Monte-Leone-Hütte SAC	2	Diamante Carlucci	http://digital-slope.it	\N
96	96	8	136.00	Ringelspitzhütte SAC	2	Dr. Rufina Avola	http://humongous-cinder.it	\N
97	97	3	140.00	Na poljanama Maljen	2	Concetta Zanella	http://rubbery-zither.com	\N
98	98	9	138.00	Dobra voda	2	Servidio Tallone	https://mysterious-creative.com	\N
99	99	4	131.00	Ivanova hiža	2	Adalrico Di Franco	http://suburban-pig.org	\N
100	100	5	144.00	Glavica	2	Lena Fuoco	http://yearly-tempo.it	\N
101	101	9	93.00	Trpošnjik	2	Ester Carriero	http://similar-observation.net	\N
102	102	3	90.00	Bitorajka	2	Celeste Torchio	http://excitable-sunflower.com	\N
103	103	6	94.00	Zlatko Prgin	2	Prudenzia Biondi	http://official-evening-wear.com	\N
104	104	8	133.00	Prpa	2	Lea Matarazzo	https://past-custard.it	\N
105	105	9	128.00	Ždrilo	2	Isidoro Maiello	https://weird-tart.org	\N
106	106	2	85.00	Miroslav Hirtz	2	Gioacchino Fratello	http://weird-crow.com	\N
107	107	7	141.00	Jezerce	2	Giuseppe Gamper	http://yearly-agent.it	\N
108	108	5	42.00	Ivica Sudnik	2	Niceforo Pariggiano	http://polished-cracker.com	\N
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
1	109	72	2	Italy	Biella		Quarto Liberatore calabro
2	110	190	2	Italy	Verona		Settimo Enimia
3	111	292	2	Italy	Sondrio		Azara lido
4	112	140	2	Italy	Varese		Adriana nell'emilia
5	113	33	2	Italy	Lodi		Geltrude terme
6	114	73	2	Italy	L'Aquila		Borgo Aristofane
7	115	137	2	Italy	Olbia-Tempio		Ausilio ligure
8	116	236	2	Italy	Cosenza		San Erberto
9	117	168	2	Italy	Catania		Elvino ligure
10	118	248	2	Italy	Avellino		San Manuela veneto
11	119	273	2	Italy	Olbia-Tempio		Borgo Agazio
12	120	94	2	Italy	Savona		Borgo Endrigo terme
13	121	35	2	Italy	Trapani		Settimo Melissa salentino
14	122	128	2	Italy	Crotone		Quarto Cristaldo
15	123	127	2	Italy	Vibo Valentia		Dodaro lido
16	124	179	2	Italy	Vibo Valentia		San Zena
17	125	297	2	Italy	Isernia		Ecclesio calabro
18	126	56	2	Italy	Avellino		Sesto Filippa
19	127	41	2	Italy	Macerata		Fiore laziale
20	128	153	2	Italy	Macerata		Candida salentino
21	129	120	2	Italy	Barletta-Andria-Trani		Sesto Pelagia umbro
22	130	201	2	Italy	Asti		Quarto Natalina
23	131	6	2	Italy	Brindisi		Quarto Duilio
24	132	197	2	Italy	Rovigo		Zefiro del friuli
25	133	66	2	Italy	Ogliastra		Sesto Climaco
26	134	56	2	Italy	Reggio Calabria		Ferraro lido
27	135	158	2	Italy	Reggio Emilia		Settimo Sonia
28	136	148	2	Italy	Nuoro		Martinelli laziale
29	137	270	2	Italy	Lecce		San Turibio veneto
30	138	257	2	Italy	Prato		Quarto Donato
31	139	201	2	Italy	Lodi		Amatore a mare
32	140	177	2	Italy	Lecce		Ave del friuli
33	141	56	2	Italy	Brescia		Camelia nell'emilia
34	142	5	2	Italy	Carbonia-Iglesias		San Fulvia
35	143	219	2	Italy	Agrigento		San Prudenzio terme
36	144	133	2	Italy	Ancona		Settimo Ulberto sardo
37	145	233	2	Italy	Ancona		Serafino del friuli
38	146	153	2	Italy	Ancona		Quarto Egizia
39	147	35	2	Italy	Bari		Piccinini terme
40	148	67	2	Italy	Ogliastra		San Martina
41	149	20	2	Italy	Napoli		Gaio a mare
42	150	289	2	Italy	Frosinone		Borgo Tiberio a mare
43	151	101	2	Italy	Salerno		Iride del friuli
44	152	186	2	Italy	Monza e della Brianza		Settimo Fleano
45	153	274	2	Italy	Napoli		Caporaso sardo
46	154	197	2	Italy	Barletta-Andria-Trani		Sesto Landolfo
47	155	153	2	Italy	Parma		Sesto Gilda calabro
48	156	285	2	Italy	Asti		Sesto Annibale
49	157	261	2	Italy	Savona		Borgo Silvestro calabro
50	158	28	2	Italy	Brindisi		Cherchi salentino
51	159	235	2	Italy	Bari		Mazzanti calabro
52	160	11	2	Italy	Varese		Pennestrì salentino
53	161	289	2	Italy	Como		Sesto Panfilo del friuli
54	162	8	2	Italy	Verbano-Cusio-Ossola		Borgo Acacio a mare
55	163	254	2	Italy	Sondrio		Gruber umbro
56	164	80	2	Italy	Agrigento		Sesto Richelmo a mare
57	165	112	2	Italy	Avellino		San Adalgisa
58	166	226	2	Italy	Livorno		Lucchesi a mare
59	167	146	2	Italy	Como		Soldati calabro
60	168	260	2	Italy	Mantova		Borgo Bino
61	169	119	2	Italy	Catania		San Marica
62	170	162	2	Italy	Udine		Sesto Elena del friuli
63	171	129	2	Italy	Mantova		Sesto Ermenegildo calabro
64	172	140	2	Italy	Prato		Federici del friuli
65	173	179	2	Italy	Teramo		Bastiano nell'emilia
66	174	50	2	Italy	Siracusa		Del Prete terme
67	175	56	2	Italy	Pisa		Luzi lido
68	176	181	2	Italy	Udine		Settimo Patrizia umbro
69	177	169	2	Italy	Taranto		Chiara lido
70	178	15	2	Italy	Crotone		Celi a mare
71	179	60	2	Italy	Piacenza		Zamboni a mare
72	180	259	2	Italy	Lodi		Borgo Attilio lido
73	181	171	2	Italy	Parma		Sesto Fidenzio
74	182	63	2	Italy	Verona		Sesto Rosanna a mare
75	183	152	2	Italy	Lecce		Cacciatore sardo
76	184	25	2	Italy	Bolzano		Alcamo del friuli
77	185	47	2	Italy	Campobasso		Borgo Amanzio terme
78	186	59	2	Italy	Pisa		Quarto Prudenzio nell'emilia
79	187	58	2	Italy	Potenza		Samona del friuli
80	188	200	2	Italy	Terni		Cavallari veneto
81	189	294	2	Italy	Brindisi		Settimo Eleuterio
82	190	179	2	Italy	Vicenza		Amleto calabro
83	191	287	2	Italy	Catania		Gaglioffo umbro
84	192	290	2	Italy	Reggio Emilia		Bellucci terme
85	193	94	2	Italy	Campobasso		Settimo Graziano
86	194	125	2	Italy	Taranto		Gennaro terme
87	195	259	2	Italy	Siracusa		Pascucci salentino
88	196	286	2	Italy	Carbonia-Iglesias		Sesto Neri
89	197	251	2	Italy	Ragusa		Addo ligure
90	198	174	2	Italy	Napoli		Quarto Gustavo veneto
91	199	72	2	Italy	Brindisi		Liverani calabro
92	200	149	2	Italy	Fermo		Salvatori a mare
93	201	140	2	Italy	Enna		Aldobrando laziale
94	202	54	2	Italy	L'Aquila		San Flora salentino
95	203	192	2	Italy	Napoli		Betta a mare
96	204	38	2	Italy	L'Aquila		Settimo Rosa salentino
97	205	206	2	Italy	Pistoia		Settimo Leo a mare
98	206	286	2	Italy	Taranto		Cleofe ligure
99	207	77	2	Italy	Ragusa		Bonavita umbro
100	208	116	2	Italy	Teramo		Sesto Saverio a mare
101	209	143	2	Italy	Enna		Roma
102	210	98	2	Italy	Olbia-Tempio		Girardi ligure
103	211	156	2	Italy	Ancona		Settimo Aristarco calabro
104	212	52	2	Italy	Padova		Petito sardo
105	213	114	2	Italy	Pistoia		Settimo Ermete
106	214	73	2	Italy	Monza e della Brianza		Guidi terme
107	215	228	2	Italy	Caltanissetta		Scardino ligure
108	216	174	2	Italy	Agrigento		Borgo Luigi ligure
109	217	290	2	Italy	Campobasso		Quarto Lorenzo nell'emilia
110	218	261	2	Italy	Pavia		Sesto Stanislao
111	219	243	2	Italy	Massa-Carrara		Guelfo del friuli
112	220	113	2	Italy	Campobasso		Quarto Cunegonda
113	221	26	2	Italy	Viterbo		Graziano lido
114	222	119	2	Italy	Sassari		Simeoni lido
115	223	270	2	Italy	Reggio Emilia		Borgo Davino
116	224	90	2	Italy	Napoli		Borgo Gonzaga laziale
117	225	106	2	Italy	Arezzo		Spano terme
118	226	154	2	Italy	Novara		Quarto Anacleto a mare
119	227	167	2	Italy	Brescia		San Ugo
120	228	121	2	Italy	Barletta-Andria-Trani		Nocera del friuli
121	229	31	2	Italy	Agrigento		Franceschi lido
122	230	139	2	Italy	Rieti		Ada calabro
123	231	258	2	Italy	Monza e della Brianza		Pastorelli umbro
124	232	180	2	Italy	Cremona		Quarto Nilde
125	233	37	2	Italy	Ascoli Piceno		Violante laziale
126	234	179	2	Italy	Venezia		Ermenegildo salentino
127	235	1	2	Italy	Frosinone		Dionisi calabro
128	236	120	2	Italy	Oristano		Settimo Prudenzia
129	237	173	2	Italy	Forlì-Cesena		Izzo veneto
130	238	1	2	Italy	Vicenza		Tarcisio del friuli
131	239	1	2	Italy	Campobasso		Arianna nell'emilia
132	240	77	2	Italy	Vicenza		Fabiano sardo
133	241	239	2	Italy	Piacenza		Speranza del friuli
134	242	202	2	Italy	Pisa		Massimo del friuli
135	243	259	2	Italy	Perugia		Pedrotti terme
136	244	147	2	Italy	Potenza		Festo veneto
137	245	1	2	Italy	Massa-Carrara		Lo Cascio nell'emilia
138	246	1	2	Italy	Rieti		Borgo Bianca veneto
139	247	32	2	Italy	Udine		Masia calabro
140	248	1	2	Italy	Matera		Petrone lido
141	249	198	2	Italy	Ascoli Piceno		Pesce nell'emilia
142	250	209	2	Italy	Siracusa		Fiorenza salentino
143	251	250	2	Italy	Sassari		San Perseo
144	252	281	2	Italy	Verona		Settimo Addo veneto
145	253	268	2	Italy	Ancona		Siria nell'emilia
146	254	172	2	Italy	Roma		Quarto Leonio
147	255	261	2	Italy	Rimini		Sviturno calabro
148	256	288	2	Italy	La Spezia		San Costanza ligure
149	257	88	2	Italy	Belluno		Quarto Panfilo ligure
150	258	211	2	Italy	Asti		Dalmasso nell'emilia
151	259	142	2	Italy	Padova		Valente terme
152	260	223	2	Italy	Isernia		Quarto Carina salentino
153	261	226	2	Italy	Foggia		San Mirocleto
154	262	283	2	Italy	Treviso		Cataldo del friuli
155	263	150	2	Italy	Brindisi		Chessari a mare
156	264	264	2	Italy	Forlì-Cesena		Borgo Romana laziale
157	265	249	2	Italy	Torino		Piazza a mare
158	266	268	2	Italy	Piacenza		San Onesto del friuli
159	267	166	2	Italy	Catanzaro		Sesto Tabita
160	268	65	2	Italy	Avellino		Ciavarella ligure
161	269	26	2	Italy	Fermo		Quarto Auberto terme
162	270	146	2	Italy	Novara		Cointa del friuli
163	271	43	2	Italy	Rimini		Sesto Ubertino a mare
164	272	274	2	Italy	Alessandria		Quarto Nicarete
165	273	258	2	Italy	Pordenone		San Giosu� salentino
166	274	30	2	Italy	Crotone		Guarino laziale
167	275	115	2	Italy	Vibo Valentia		Settimo Maruta
168	276	255	2	Italy	Reggio Emilia		Borgo Lelia nell'emilia
169	277	289	2	Italy	Catanzaro		Sviturno terme
170	278	299	2	Italy	Pavia		Bentivoglio lido
171	279	131	2	Italy	Padova		Settimo Patrizia
172	280	260	2	Italy	Ascoli Piceno		San Agabio umbro
173	281	147	2	Italy	Trento		Ione laziale
174	282	179	2	Italy	Agrigento		Settimo Concordio ligure
175	283	77	2	Italy	Gorizia		Grazia a mare
176	284	159	2	Italy	Potenza		Ilario del friuli
177	285	250	2	Italy	Udine		Settimo Altea
178	286	137	2	Italy	Reggio Emilia		Eleonora del friuli
179	287	207	2	Italy	Bologna		Eliana calabro
180	288	98	2	Italy	Forlì-Cesena		Sempronio salentino
181	289	216	2	Italy	Matera		Nicola veneto
182	290	156	2	Italy	Genova		Borgo Nilde nell'emilia
183	291	6	2	Italy	Trento		Giambattista umbro
184	292	295	2	Italy	Roma		Lendinara
185	293	256	2	Italy	Ancona		San Paola veneto
186	294	146	2	Italy	Trapani		Napoli
187	295	113	2	Italy	Treviso		Settimo Dianora ligure
188	296	162	2	Italy	Biella		Borgo Aronne terme
189	297	87	2	Italy	Napoli		Dianora ligure
190	298	211	2	Italy	Palermo		Sesto Valentina
191	299	196	2	Italy	Forlì-Cesena		Bisio del friuli
192	300	198	2	Italy	Vercelli		Quarto Beltramo
193	301	83	2	Italy	Ogliastra		Ave umbro
194	302	30	2	Italy	Nuoro		Vinfrido nell'emilia
195	303	208	2	Italy	Terni		Borgo Adalgiso nell'emilia
196	304	150	2	Italy	La Spezia		Settimo Linda
197	305	143	2	Italy	Brindisi		Castaldi ligure
198	306	81	2	Italy	Trento		Ennio ligure
199	307	220	2	Italy	Aosta		Nicol� a mare
200	308	260	2	Italy	Latina		Piergiorgio ligure
201	309	296	2	Italy	Napoli		Giorgia del friuli
202	310	88	2	Italy	Matera		Borgo Ottaviano terme
203	311	410	2	Italy	Ogliastra		Filomena lido
204	312	196	2	Italy	Piacenza		Bonomo nell'emilia
205	313	45	2	Italy	Medio Campidano		Noemi salentino
206	314	283	2	Italy	Novara		San Porzia
207	315	181	2	Italy	Aosta		Quarto Soccorso
208	316	172	2	Italy	Vicenza		Settimo Zanita del friuli
209	317	59	2	Italy	Bolzano		Guiscardo veneto
210	318	65	2	Italy	Sondrio		Settimo Laura salentino
211	319	163	2	Italy	Cuneo		Agnello del friuli
212	320	157	2	Italy	Fermo		Zingaretti lido
213	321	9	2	Italy	Bolzano		Sesto Ulfa
214	322	284	2	Italy	Potenza		Luconi sardo
215	323	66	2	Italy	Pesaro e Urbino		Metrofane lido
216	324	70	2	Italy	Latina		San Desiderato salentino
217	325	181	2	Italy	L'Aquila		Amabile sardo
218	326	258	2	Italy	Brescia		Sesto Adelardo
219	327	107	2	Italy	Livorno		Sesto Sebastiano sardo
220	328	108	2	Italy	Catania		Settimo Fedele
221	329	42	2	Italy	Enna		Settimo Crescenzia umbro
222	330	3	2	Italy	Roma		Ines umbro
223	331	209	2	Italy	Cagliari		Gianpaolo lido
224	332	107	2	Italy	Campobasso		Sicuro terme
225	333	249	2	Italy	Torino		Borgo Regolo
226	334	199	2	Italy	Gorizia		Quarto Apollonia
227	335	209	2	Italy	Lecce		Settimo Ester calabro
228	336	205	2	Italy	Udine		Quarto Annunziata
229	337	176	2	Italy	Brescia		Sesto Santo lido
230	338	66	2	Italy	Torino		Bassilla calabro
231	339	55	2	Italy	Cremona		Pierangelo veneto
232	340	62	2	Italy	Pistoia		Borrelli del friuli
233	341	231	2	Italy	Udine		Settimo Alfio
234	342	174	2	Italy	Udine		Borgo Aristione veneto
235	343	163	2	Italy	Brescia		Quarto Mauro
236	344	81	2	Italy	Sondrio		Marica umbro
237	345	150	2	Italy	Perugia		Andromeda laziale
238	346	70	2	Italy	Benevento		Paladini ligure
239	347	144	2	Italy	Biella		Plinio ligure
240	348	79	2	Italy	Genova		Di Martino sardo
241	349	61	2	Italy	Roma		Dolci veneto
242	350	238	2	Italy	La Spezia		San Amerigo
243	351	81	2	Italy	Foggia		Sparacino calabro
244	352	250	2	Italy	Fermo		Acilia lido
245	353	298	2	Italy	Savona		Settimo Ardito laziale
246	354	118	2	Italy	Cremona		Salomone laziale
247	355	149	2	Italy	Teramo		San Odidone
248	356	233	2	Italy	Verbano-Cusio-Ossola		Quarto Adelasia
249	357	255	2	Italy	Sondrio		Canova terme
250	358	9	2	Italy	Vercelli		Quaranta umbro
251	359	129	2	Italy	Padova		San Sveva calabro
252	360	160	2	Italy	Belluno		Quarto Odorico laziale
253	361	260	2	Italy	Reggio Emilia		Borgo Cora terme
254	362	208	2	Italy	Vicenza		Borgo Verecondo
255	363	173	2	Italy	Pavia		Antenucci sardo
256	364	238	2	Italy	Barletta-Andria-Trani		Borgo Donna terme
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address) FROM stdin;
1	0	0101000020E61000002D64979723B62440C66F2527958D4740	Edmund-Graf-Hütte	6574 Pettneu am Arlberg, Tyrol, Austria
2	0	0101000020E6100000455BF9D0380E2A4056DBD4F478794740	Dr.Hernaus-Stöckl	9020 Klagenfurt, Kärnten, Austria
3	0	0101000020E61000003AD4CD22968A2D406DAF4FF575F14740	Amstettner Hütte	3340 Waidhofen an der Ybbs, Niederösterreich, Austria
4	0	0101000020E61000003470C88518362B404F23C0A11DEA4740	Hochleckenhaus	4853 Steinbach am Attersee, Oberösterreich, Austria
5	0	0101000020E6100000745CA7EA5C3230400E95C9F10B114840	Kampthalerhütte	2384 Breitenfurt bei Wien, Niederösterreich, Austria
6	0	0101000020E610000059E5350827672B402FB2862AC2D34740	Lambacher Hütte	4822 Bad Goisern, Oberösterreich, Austria
7	0	0101000020E610000019FDD2643FA62340662869A087B24740	Lustenauer Hütte	6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria
8	0	0101000020E610000036849931B0F52A4014BD78F039C44740	Gablonzer Hütte	4825 Gosau-Hintertal, Oberösterreich, Austria
9	0	0101000020E6100000202F5A3629BF3740D489BAC5B2144340	Katafygio «Flampouri»	136 72 Acharnes, Attica region, Greece
10	0	0101000020E6100000103E4BA24D3F2B40F731169C1AC04740	Simonyhütte	4830 Hallstatt, Oberösterreich, Austria
11	0	0101000020E610000033190145D5182740BF9048EBDFA04740	Vinzenz-Tollinger-Hütte	6060 Hall in Tirol, Tyrol, Austria
12	0	0101000020E61000001F1E0B5901B82E4091BFCBF1EAB34740	Ottokar-Kernstock-Haus	8600 Bruck an der Mur, Steiermark, Austria
13	0	0101000020E610000018E4FB977DBF2A40D6A3B4422D754740	Reisseckhütte	9814 Mühldorf, Mölltal, Kärnten, Austria
14	0	0101000020E61000007B116DC7D4A52540C0401020436D4740	Vernagthütte	Austria
15	0	0101000020E6100000286211C30EF323407EC9C6832D884740	Wormser Hütte	Austria
16	0	0101000020E6100000999CDA19A60E24406CD097DEFEA04740	Biberacher Hütte	Austria
17	0	0101000020E610000007BC276AC4133740DDF934DDA1A84440	Katafygio «1777»	620 55 Kerkini, Central Macedonia region, Greece
18	0	0101000020E6100000D5AF743E3C0B2A40E6E786A6EC704840	Hochwaldhütte	Germany
19	0	0101000020E6100000C2FBAA5CA8EC19408FC536A968544940	Kölner Eifelhütte	Germany
20	0	0101000020E6100000323CF6B358D223401763601DC7794740	Madrisahütte	Austria
21	0	0101000020E6100000313F373465472640CDC98B4CC07F4740	Dresdner Hütte	Austria
22	0	0101000020E6100000CDCCCCCCCC6C24403E07962364A84740	Fiderepasshütte	Germany
23	0	0101000020E6100000B727486C77172440A9DDAF027C9B4740	Göppinger Hütte	Austria
24	0	0101000020E6100000A379008BFC622340C7629B54348A4740	Oberzalimhütte	Austria
25	0	0101000020E610000013B70A62A0932740B3B45373B99D4740	Rastkogelhütte	Austria
26	0	0101000020E61000009D2D20B41E0E2440D54F49E70DC24740	Ansbacher Skihütte im Allgäu	Germany
27	0	0101000020E610000009E066F16249244097E13FDD408F4740	Kaltenberghütte	Austria
28	0	0101000020E61000000AD7A3703D0A2640E277D32D3B944740	Schweinfurter Hütte	Austria
29	0	0101000020E61000006DC438245A213640DA172BC5E9574340	Katafygio «Vardousion»	330 53 Delphi, Central Greece region, Greece
30	0	0101000020E6100000630F270F8F472D40336D62F5852D4740	Kocbekov dom na Korošici	3334 Luče, Mozirje, Slovenia
31	0	0101000020E6100000D1F5D08072062D40D25C9F20CE114740	Planinski dom Rašiške cete na Rašici	1211 Ljubljana, Šmartno, Slovenia
32	0	0101000020E6100000F70F966F85592C40971550C935374740	Prešernova koca na Stolu	4274 Žirovnica, Slovenia
33	0	0101000020E6100000AA5C8F5FCB372E408E6CD71919184740	Planinski dom na Mrzlici	3302 Griže, Slovenia
34	0	0101000020E6100000651A4D2EC6802C40577A6D3656FC4640	Koca na Planini nad Vrhniko	1360 Vrhnika, Slovenia
35	0	0101000020E6100000245DF94DDD322C4077DAB7E6D0144740	Zavetišce gorske straže na Jelencih	0, -, Slovenia
36	0	0101000020E6100000313F3734656F2E406F7F2E1A32264740	Planinski dom na Gori	Šentjungert, 3310 Žalec, Slovenia
37	0	0101000020E610000098F2E7FC90A22B40C7CBA2C928274740	Bregarjevo zavetišce na planini Viševnik	4265 Bohinjsko jezero, Slovenia
38	0	0101000020E610000091860959CC862B401635F33FD4244740	Koca pod Bogatinom	4265 Bohinjsko jezero, Slovenia
39	0	0101000020E6100000678B3942E5992B40007F639573334740	Pogacnikov dom na Kriških podih	5232 Soca, Slovenia
40	0	0101000020E610000008F580BBE4CC2D402A9C0F95E7344740	Dom na Smrekovcu	3325 Šoštanj, Slovenia
41	0	0101000020E610000073F6CE68AB32194060E811A3E77C4640	Refuge Du Chatelleret	38520 Saint Christophe En Oisans, Isère, France
42	0	0101000020E610000084622B685AF218408177F2E9B16B4640	Refuge De Chalance	5800 La Chapelle En Valgaudemar, Hautes-Alpes, France
43	0	0101000020E6100000963D096CCE711940AE7FD767CE6A4640	Refuge Des Bans	5290 Vallouise, Hautes-Alpes, France
44	0	0101000020E6100000DEAB5626FC52DBBFAED689CBF16A4540	Refuge De Pombie	65400 Laruns, Pyrénées-Atlantiques, France
45	0	0101000020E6100000A69C2FF65E7CD2BFA9F92AF9D86D4540	Refuge De Larribet	65400 Arrens, Marsous, Hautes-Pyrénées, France
46	0	0101000020E61000009CA6CF0EB84E1B401232906797C34640	Refuge Du Mont Pourri	73210 Peisey Nancroix, Savoie, France
47	0	0101000020E6100000C712D6C6D8E91A40BF81C98D222D4740	Refuge De La Dent D?Oche	74500 Bernex, Haute-Savoie, France
48	0	0101000020E6100000BEBDCA2243F820405620D41E27544740	Bergseehütte SAC	Uri, Switzerland
49	0	0101000020E6100000CDD5732CA96D1E40F591820D5C054740	Bivouac au Col de la Dent Blanche CAS	Wallis, Switzerland
50	0	0101000020E610000060F1FE571F0C2140D6BA5B328C564740	Salbitschijenbiwak SAC	Uri, Switzerland
51	0	0101000020E610000084EAC5BE53052140F224048A5C664740	Spannorthütte SAC	Uri, Switzerland
52	0	0101000020E6100000827FB24EBCB71E406113E452EB0C4740	Cabane Arpitettaz CAS	Wallis, Switzerland
53	0	0101000020E61000008A75AA7CCF48E4BF588BF447BD614540	Refugio De Lizara	22730, Aragón, Spain
54	0	0101000020E6100000AE56C01909F8E43F58DB5E1CA6064540	Albergue De Montfalcó	22585 Tolva, Aragón, Spain
55	0	0101000020E61000000A4CFFBF1E610AC08B780953B6904240	El Molonillo/Peña Partida	18160 Güejar Sierra, Andalucía, Spain
56	0	0101000020E610000029110100A92D0AC0F39F054F27844240	La Campiñuela	18417 Trévelez, Andalucía, Spain
57	0	0101000020E61000008E79782A3BCC3440BEAE152301FF4440	Titov Vrv	Tetovo, Municipality of Tetovo, North Macedonia
58	0	0101000020E6100000A2EC2DE57C212B40C7F143A5113D4540	Rifugio Franchetti	Pietracamela, Abruzzo, Italy
59	0	0101000020E610000052E2299ABDFA2840518B1C7D27114740	Rifugio Semenza	Tambre, Veneto, Italy
60	0	0101000020E6100000A197F67244A31F40313D06D094EE4640	Rifugio Città di Mortara 	Alagna Valsesia, Piemonte, Italy
61	0	0101000020E61000006E39F29B1D242040AB1ED555260C4740	Rifugio Andolla	Antrona Schieranico, Piemonte, Italy
62	0	0101000020E61000000AD80E46ECAB2440B70BCD751AFF4540	Rifugio Forte dei Marmi	Stazzema, Toscana, Italy
63	0	0101000020E6100000A88B14CAC2CF284038D66AB4C1504740	Rifugio Berti	Comelico Superiore, Veneto, Italy
64	0	0101000020E610000071B43E4052BB2B406FE70CD649CF4640	Rifugio Premuda	San Dorligo della Valle, Friuli Venezia Giulia, Italy
65	0	0101000020E61000006CCF2C0950C32240191BBAD91FF84640	Rifugio Elisa	Mandello del Lario, Lombardia, Italy
66	0	0101000020E6100000A5BDC11726B31F40F90FE9B7AFFB4640	Rifugio CAI Saronno	Macugnaga, Piemonte, Italy
67	0	0101000020E610000098DD9387857A2640A930B610E4584740	Rifugio Picco Ivigna	Scena, Trentino Alto Adige, Italy
68	0	0101000020E61000003AE97DE36B8F1C404AEF1B5F7B8A4640	Rifugio Toesca	Bussoleno, Piemonte, Italy
69	0	0101000020E6100000A913D044D8E02040382D78D1570C4740	Rifugio Al Cedo	Santa Maria Maggiore, Piemonte, Italy
70	0	0101000020E6100000449D5ECE11661F4009ED8B3A29F34640	Capanna Gnifetti	Gressoney La Trinitè, Valle d?Aosta, Italy
71	0	0101000020E6100000B8AE9811DE3E1E403A048E041AFC4640	Rifugio Aosta	Bionaz, Valle d?Aosta, Italy
72	0	0101000020E6100000BBB31B22135525408EA8F523EA374740	Rifugio Cevedale	Pejo, Trentino Alto Adige, Italy
73	0	0101000020E61000000D33349E08722340F0A485CB2A204740	Rifugio Ponti	Val Masino, Lombardia, Italy
74	0	0101000020E6100000C46D7E0DD2B125405364085B47134740	Rifugio XII Apostoli	Stenico, Trentino Alto Adige, Italy
75	0	0101000020E61000009F1C058882591B40DDD1FF722DE24640	Rifugio Elisabetta Soldini	Courmayeur, Valle d?Aosta, Italy
76	0	0101000020E610000061D57994804F25409903A4C1291F4740	Rifugio Denza	Vermiglio, Trentino Alto Adige, Italy
77	0	0101000020E61000000C1F115322F92A40338AE596560F4540	Rifugio Fonte Tavoloni 	Ovindoli, Abruzzo, Italy
78	0	0101000020E610000037C2A2224EBF2840F2ED5D83BE4E4740	Rifugio Carducci	Auronzo di Cadore, Veneto, Italy
79	0	0101000020E61000006FA53220D64E26400DE02D90A0044740	Rifugio Bindesi	Trento, Trentino Alto Adige, Italy
80	0	0101000020E610000001C11C3D7ECB2D40C670D0B9365A4640	Mountain hut Miroslav Hirtz	53287 Jablanac, Ličko-senjska županija, Croatia
81	0	0101000020E6100000398485EEED352C4098331D324C154740	Koca na Blegošu	4224 Gorenja vas, Slovenia
82	0	0101000020E610000040F850A225BF1F400F441669E2594940	Wittener Hütte	Germany
83	0	0101000020E610000000FDBE7FF3AA25409A99999999694740	Hochjoch-Hospiz	Austria
84	0	0101000020E6100000D7A02FBDFD412640CDCCCCCCCCB44740	Meilerhütte	Germany
85	0	0101000020E610000050C422861DA628406E85B01A4BC64740	Gaudeamushütte	Austria
86	0	0101000020E6100000179CC1DF2F961940D5EB1681B15C4940	Rheydter Hütte	Germany
87	0	0101000020E6100000FB66518EB8562C4057E883656C744940	Sektionshütte Krippen	Germany
88	0	0101000020E61000001F7A839D234C2C40B45EF68814A34740	Neunkirchner Hütte	2620 Neunkirchen, Steiermark, Austria
89	0	0101000020E61000009CE379FC2043E7BF8FC536A9682C4540	Refugio De Riglos	22808, Aragón, Spain
90	0	0101000020E6100000563D4FC4941A2140EBB308E997564740	Salbithütte SAC	Uri, Switzerland
91	0	0101000020E61000001D55C855B23A2040B8EB64DCCE424740	Finsteraarhornhütte SAC	Wallis, Switzerland
92	0	0101000020E6100000DEFD765E1AE71D4038777A52B2FE4640	Cabane des Vignettes CAS	Wallis, Switzerland
93	0	0101000020E6100000E769EE0B84312040FBE19FAF02504740	Glecksteinhütte SAC	Bern, Switzerland
94	0	0101000020E6100000752B5D3C5F152240D9971BDB51454740	Länta-Hütte SAC	Graubünden, Switzerland
95	0	0101000020E610000055ADDEFA26292040BAB9F14860214740	Monte-Leone-Hütte SAC	Wallis, Switzerland
96	0	0101000020E6100000557F0CE8F9C222408F373B25D26E4740	Ringelspitzhütte SAC	Graubünden, Switzerland
97	0	0101000020E6100000A4AA09A2EE0334408E23D6E253104640	Na poljanama Maljen	Maljen, Serbia
98	0	0101000020E6100000A9DE1AD82A313440C5E6E3DA50114640	Dobra voda	Suvobor, Serbia
99	0	0101000020E61000007250C24CDBFF2E402D095053CBC64640	Ivanova hiža	Karlovac town environment, Karlovačka, Croatia
100	0	0101000020E6100000C6DCB5847CC02F40C746205ED7EB4640	Glavica	Medvednica, City of Zagreb, Croatia
101	0	0101000020E6100000FFEC478AC8B83040D3F6AFAC34BD4540	Trpošnjik	Mosor, Splitsko-dalmatinska, Croatia
102	0	0101000020E6100000C217265305932D40C4CE143AAFA54640	Bitorajka	Bitoraj, Primorsko-goranska, Croatia
103	0	0101000020E6100000AB09A2EE0360304006D847A7AE084640	Zlatko Prgin	Dinara, Šibensko-kninska, Croatia
104	0	0101000020E6100000D3872EA86F492E405C8FC2F528444640	Prpa	Velebit, Ličko-senjska, Croatia
105	0	0101000020E6100000787FBC57AD5C2E408BFD65F7E43D4640	Ždrilo	Velebit, Ličko-senjska, Croatia
106	0	0101000020E610000086032159C0F42D40B21188D7F59B4640	Miroslav Hirtz	Velika Kapela, Primorsko-goranska, Croatia
107	0	0101000020E6100000A31EA2D11DAC3140462575029AC04640	Jezerce	Papuk, Požeško-slavonska, Croatia
108	0	0101000020E61000003EE8D9ACFA4C2F405F0CE544BBE24640	Ivica Sudnik	Samoborska gora, Zagrebačka, Croatia
109	0	0101000020E6100000AD3BCC4D8A7D2840CBDF185D39124640		040 Borgo Armando, Quarto Liberatore calabro, Italy
110	0	0101000020E6100000AF5E454607602340EDF2AD0FEB6B4440		44 Strada Pierangelo, Settimo Enimia, Italy
111	0	0101000020E610000050BA3EBD63AA2840D5DBB0B7DE294640		256 Strada Pili, Azara lido, Italy
112	0	0101000020E6100000E7204322C8042640F6AEE6A507F54540		69 Rotonda Gennaro, Adriana nell'emilia, Italy
113	0	0101000020E61000009F11B6E919B02140ABAC12D154364640		783 Rotonda D'Aleo, Geltrude terme, Italy
114	0	0101000020E61000009EBFBFF7ED2224402DAAEA8ABEE84640		154 Incrocio Reale, Borgo Aristofane, Italy
115	0	0101000020E6100000FF209221C76E274017844DF8002D4640		0 Borgo Solinas, Ausilio ligure, Italy
116	0	0101000020E6100000C2B28817FA8E2340D5809C8B1AB04640		7 Via Melchiade, San Erberto, Italy
117	0	0101000020E6100000107BFC3960762540600A6A53D0274740		5 Strada Diletta, Elvino ligure, Italy
118	0	0101000020E6100000CF5AC0BAE0462B40B9ED314745E34640		7 Borgo Valenti, San Manuela veneto, Italy
119	0	0101000020E610000048B42E7FCFC525403379B93E620B4740		2 Rotonda Caio, Borgo Agazio, Italy
120	0	0101000020E6100000E066F16261B42A4084E85AC52CF04640		120 Borgo Margiotta, Borgo Endrigo terme, Italy
121	0	0101000020E610000021263CFC90E62840C604EBEEF0074640		727 Incrocio Govoni, Settimo Melissa salentino, Italy
122	0	0101000020E6100000CFB81567B161274070CFF3A78DA74640		33 Via Fabiano, Quarto Cristaldo, Italy
123	0	0101000020E6100000C1F979F8D76F224054F0CAE48AB04640		8 Via Elmo, Dodaro lido, Italy
124	0	0101000020E61000008248D0A975782B40741200D2EDC94640		420 Incrocio Fois, San Zena, Italy
125	0	0101000020E6100000918B208436172940630E828E564E4540		0 Via Giuliano, Ecclesio calabro, Italy
126	0	0101000020E610000023484A1F5F572240D37CDF09072C4640		50 Strada Alma, Sesto Filippa, Italy
127	0	0101000020E6100000A09339F130542140F7DBE8ADCB384740		0 Rotonda Lavinia, Fiore laziale, Italy
128	0	0101000020E6100000068A0E37967A2540DB1FDE29D3664540		40 Borgo Valenza, Candida salentino, Italy
129	0	0101000020E6100000CF59B09EA4CE2640F18288D4B4434740		0 Rotonda Rucco, Sesto Pelagia umbro, Italy
130	0	0101000020E6100000C153C8957A5A26407541D8840FE14640		911 Rotonda Lo Iacono, Quarto Natalina, Italy
131	0	0101000020E61000008577B988EF302140BAD3426E2B3D4740		287 Piazza Mastropietro, Quarto Duilio, Italy
132	0	0101000020E6100000589643E6259E2540B49487E013DD4540		96 Borgo Lucia, Zefiro del friuli, Italy
133	0	0101000020E6100000249E4720B9702840B1F84D61A5124640		443 Strada Enrico, Sesto Climaco, Italy
134	0	0101000020E61000008B89CDC7B55926407EB4EED57D084740		16 Strada Marsella, Ferraro lido, Italy
135	0	0101000020E6100000D8B969334EEB27402CF8C84164804540		0 Contrada Agresta, Settimo Sonia, Italy
136	0	0101000020E610000061D394AEAAD4204012A6835039FC4640		52 Incrocio Pacifico, Martinelli laziale, Italy
137	0	0101000020E6100000B53C6AA741AC27408F0134A550B84640		6 Piazza Marisa, San Turibio veneto, Italy
138	0	0101000020E6100000F78CE9AE91D52240ED48F59D5FE54640		741 Strada Ortensio, Quarto Donato, Italy
139	0	0101000020E6100000626DE75663902B4097FA1E9A1ED44640		3 Incrocio Rogolino, Amatore a mare, Italy
140	0	0101000020E6100000FFF9C78C011B2640DD706946501E4740		5 Contrada Narcisi, Ave del friuli, Italy
141	0	0101000020E61000009C363EEEB67E2740BC2363B5F9BA4640		27 Incrocio Canale, Camelia nell'emilia, Italy
142	0	0101000020E61000008A9466F3387C1E402B31CF4A5AE74640		2 Borgo Leonardi, San Fulvia, Italy
143	0	0101000020E6100000F22895F084D22A404082870E26ED4440		042 Piazza Bandini, San Prudenzio terme, Italy
144	0	0101000020E61000007E1D386744712240C878399105CC4640		4 Strada Beltramo, Settimo Ulberto sardo, Italy
145	0	0101000020E610000020D84C1993812240A475AFEEB30D4740		392 Borgo No�, Serafino del friuli, Italy
146	0	0101000020E6100000242136FD7E2E26406E2AF7A7F91A4740		79 Via Quinzio, Quarto Egizia, Italy
147	0	0101000020E6100000485E8C37E8B927408860C1A2C7CA4640		4 Incrocio Aronne, Piccinini terme, Italy
148	0	0101000020E61000005E961BB1BB751E407379BD4571EF4640		2 Strada Barile, San Martina, Italy
149	0	0101000020E6100000BE2ABC708CED2340366964A1E7DD4640		74 Borgo Ireneo, Gaio a mare, Italy
150	0	0101000020E610000053B4722F302B2540E4DC26DC2B4D4740		22 Rotonda Fausta, Borgo Tiberio a mare, Italy
151	0	0101000020E61000009A97C3EE3B32254052B241CB5F574640		33 Incrocio Ulfa, Iride del friuli, Italy
152	0	0101000020E6100000622D3E05C0782840F70BD17C29DE4640		54 Piazza Panico, Settimo Fleano, Italy
153	0	0101000020E6100000B05758703F782440773A4668BAB84640		091 Via Pozzi, Caporaso sardo, Italy
154	0	0101000020E610000011D20957F63B2640E6B8AEF3CA084740		1 Contrada Pozzi, Sesto Landolfo, Italy
155	0	0101000020E61000004704E3E0D2692C408514F2F741A74640		40 Strada Pisu, Sesto Gilda calabro, Italy
156	0	0101000020E61000002F0ACC54D2C8264038FE9F1E36CA4640		39 Contrada Sabino, Sesto Annibale, Italy
157	0	0101000020E610000046E80C31035E29405A46EA3D95E54640		59 Incrocio Rogolino, Borgo Silvestro calabro, Italy
158	0	0101000020E6100000E4F90CA8376B2340ABA3F496BC5E4440		9 Incrocio Donati, Cherchi salentino, Italy
159	0	0101000020E6100000967DB2BD71ED26406F7319EDA7C14640		86 Contrada Fabiana, Mazzanti calabro, Italy
160	0	0101000020E6100000FC68DDABFB5427401073EE1B04334740		17 Via Beronico, Pennestrì salentino, Italy
161	0	0101000020E610000069965F611C5B2540B52792F991CA4540		794 Piazza Pizzuti, Sesto Panfilo del friuli, Italy
162	0	0101000020E6100000B4C6455ACF692740D8C523A765B04640		332 Contrada Abele, Borgo Acacio a mare, Italy
163	0	0101000020E61000003B843B61D3CC1E40935742D202D44640		7 Piazza Sante, Gruber umbro, Italy
164	0	0101000020E6100000C03FA54A9455284094347F4C6BE54640		5 Rotonda Ugolini, Sesto Richelmo a mare, Italy
165	0	0101000020E610000003FBF900EEEB1E40FA6184F068EE4640		386 Via Bruni, San Adalgisa, Italy
166	0	0101000020E610000007681140209E2640B177352F3D9D4640		3 Strada Labate, Lucchesi a mare, Italy
167	0	0101000020E6100000525F96766AFE23402A7C6C81F3EE4640		0 Contrada Caserta, Soldati calabro, Italy
168	0	0101000020E61000007319EDA7B5EF1E400B1060EC18EC4640		7 Borgo Bonetti, Borgo Bino, Italy
169	0	0101000020E6100000F86B578DCA1A284015E06014A9B14640		33 Contrada Fior, San Marica, Italy
170	0	0101000020E6100000D634947FD2A12740811A081390584540		44 Borgo Bonito, Sesto Elena del friuli, Italy
171	0	0101000020E61000009D63E53C08EA2640B7FB0BF3D4DC4540		51 Strada Crocefisso, Sesto Ermenegildo calabro, Italy
172	0	0101000020E6100000EA0E18DAEF9B2B40948444DAC6764640		776 Borgo Spiga, Federici del friuli, Italy
173	0	0101000020E610000014BCD7FFEFC62640BA66F2CD36DE4640		66 Contrada Mara, Bastiano nell'emilia, Italy
174	0	0101000020E610000009168733BFBE27405D4E098849354540		4 Contrada Lamberto, Del Prete terme, Italy
175	0	0101000020E6100000462AE7E6763A2940ABB8CC446CE14440		4 Contrada Pignatelli, Luzi lido, Italy
176	0	0101000020E610000075EED176A7F62640A7F97486F3B24640		17 Incrocio Taziana, Settimo Patrizia umbro, Italy
177	0	0101000020E6100000F9A23D5E48F727405789C3E3ECE04640		35 Piazza Marianna, Chiara lido, Italy
178	0	0101000020E6100000731A587D64FD294065FED13769E64540		1 Contrada Meneo, Celi a mare, Italy
179	0	0101000020E6100000ABC5F18D322421407D1FB3582FFA4640		41 Via Amando, Zamboni a mare, Italy
180	0	0101000020E610000035D252793B0228403A79ECC26AEA4640		081 Via Clodomiro, Borgo Attilio lido, Italy
181	0	0101000020E6100000DD730580CFD02640F16261889CD44640		42 Contrada Chiodi, Sesto Fidenzio, Italy
182	0	0101000020E61000006531564046E12040530E1C8645E74640		0 Strada Cronida, Sesto Rosanna a mare, Italy
183	0	0101000020E610000026B8A2DE9D5E2740311A434AFDDC4640		4 Strada Celeste, Cacciatore sardo, Italy
184	0	0101000020E61000000A5BFD22B27524407121EA99B95B4640		0 Borgo Cremenzio, Alcamo del friuli, Italy
185	0	0101000020E6100000C132DBBA40CE2240D0EFFB372F274740		115 Incrocio Tarso, Borgo Amanzio terme, Italy
186	0	0101000020E6100000CA558737C6B91F40EB79ED88F9BD4640		354 Piazza Acrisio, Quarto Prudenzio nell'emilia, Italy
187	0	0101000020E61000006AEE320DD4F324401D098F9147B14640		9 Strada Giusti, Samona del friuli, Italy
188	0	0101000020E610000044053D8A291B2140F0FACC599F5A4440		131 Borgo Tarcisio, Cavallari veneto, Italy
189	0	0101000020E61000002B1D07B9E6212040F08C11E4FBF04640		8 Strada Giancarlo, Settimo Eleuterio, Italy
190	0	0101000020E61000007BEDE3B21BB727403464E190B2DD4640		5 Borgo Pagliuca, Amleto calabro, Italy
191	0	0101000020E6100000D8E9ACBB1EE91F40A0A932E774D04640		55 Rotonda Petronilla, Gaglioffo umbro, Italy
192	0	0101000020E61000009C8136DEC21B294063731FCA61894540		041 Strada Auro, Bellucci terme, Italy
193	0	0101000020E6100000E3B08FA91680204076A0F3BF01E94640		20 Piazza Severino, Settimo Graziano, Italy
194	0	0101000020E6100000EE6EAF16E9832340C6F0225D7DCC4640		17 Strada Marino, Gennaro terme, Italy
195	0	0101000020E6100000D81D41E037B02140C2F1214D61C54440		5 Strada Mancinelli, Pascucci salentino, Italy
196	0	0101000020E6100000A807BB174E80284061BC8B9C2AD94640		0 Borgo Galatea, Sesto Neri, Italy
197	0	0101000020E6100000FD18CE9085A322406C9CA80073DB4640		850 Contrada Giovenzio, Addo ligure, Italy
198	0	0101000020E6100000E39F635122672540E113A1C7DEDE4640		5 Rotonda Evaristo, Quarto Gustavo veneto, Italy
199	0	0101000020E610000098231A93B47928409916500361674640		3 Contrada Climaco, Liverani calabro, Italy
200	0	0101000020E6100000ABBCD3539A032740A544B7031AEF4640		1 Via Storti, Salvatori a mare, Italy
201	0	0101000020E61000001E424B0D239B2440D8D1DD1A7DA04640		43 Contrada Brignone, Aldobrando laziale, Italy
202	0	0101000020E6100000CF2CAE96E0891F405EB642FDD3234640		264 Strada Marchi, San Flora salentino, Italy
203	0	0101000020E6100000D7BDBACF96BC254007205AD020C34640		265 Strada Pierangelo, Betta a mare, Italy
204	0	0101000020E6100000C96BCABA24832740A97E4A3A6FE54640		58 Via Speranza, Settimo Rosa salentino, Italy
205	0	0101000020E6100000A8DAB80F8AC32940DF67017F9D1A4540		421 Borgo Romualdo, Settimo Leo a mare, Italy
206	0	0101000020E6100000C272DFC556972640A4271BC528D24640		5 Incrocio Gavino, Cleofe ligure, Italy
207	0	0101000020E61000005F306E5974411E40EC3F21F1E13A4740		7 Borgo Ciriaco, Bonavita umbro, Italy
208	0	0101000020E61000006C109CE9142628401760C4E347124740		9 Rotonda Osvaldo, Sesto Saverio a mare, Italy
209	0	0101000020E610000044EC0214D9FD284012AC600AC5EE4440		120 Via Cristoforo Colombo, Roma, Italy
210	0	0101000020E6100000B0FECF61BEF827406DFD99E6C2F24640		7 Strada Catullo, Girardi ligure, Italy
211	0	0101000020E6100000EBB76576CCAF26407B8FE9BFBD424640		9 Piazza Pippo, Settimo Aristarco calabro, Italy
212	0	0101000020E6100000D6479682247220407379BD4571084740		2 Rotonda Nucci, Petito sardo, Italy
213	0	0101000020E610000097900F7A36872040AB251DE560074740		18 Strada Donda, Settimo Ermete, Italy
214	0	0101000020E61000000DABD3DC65C22740D32F116F9DE34640		6 Strada Puleo, Guidi terme, Italy
215	0	0101000020E61000009FEE97AA0FCF27402834FF9E0E024740		0 Rotonda Eliana, Scardino ligure, Italy
216	0	0101000020E6100000E417B90265622C40EFC0A50815E24440		6 Rotonda Maruta, Borgo Luigi ligure, Italy
217	0	0101000020E6100000B2463D44A37B2540F3C011EEDF764540		16 Strada Lo Pinto, Quarto Lorenzo nell'emilia, Italy
218	0	0101000020E6100000B6B0B84956A326409DC2A5BE87334740		3 Strada Aniello, Sesto Stanislao, Italy
219	0	0101000020E6100000D56C2FB319AD2840823C16365EC04640		947 Incrocio Masiero, Guelfo del friuli, Italy
220	0	0101000020E610000076583C5002EE1E40E0CCF9731BE14640		24 Via Marone, Quarto Cunegonda, Italy
221	0	0101000020E6100000470EC7A98CC52840B6A73F564BE04640		39 Rotonda Lari, Graziano lido, Italy
222	0	0101000020E61000004DC00A4B97B91F4005C1E3DBBBF84540		88 Strada Rigoni, Simeoni lido, Italy
223	0	0101000020E610000059EB7A585E182740106D1162780E4640		91 Borgo Lecca, Borgo Davino, Italy
224	0	0101000020E610000051D9B0A6B2581F4089B7CEBF5DE14640		461 Strada Valenza, Borgo Gonzaga laziale, Italy
225	0	0101000020E6100000AD7603BB504F27406049A8CFC4374640		249 Piazza Pili, Spano terme, Italy
226	0	0101000020E61000004692C5A28EF72640D32934B511794640		8 Strada Clodoveo, Quarto Anacleto a mare, Italy
227	0	0101000020E6100000068B790C45182740C3CB1D47BD774640		340 Contrada Minervina, San Ugo, Italy
228	0	0101000020E61000005CC0159A35C620401880A1A245F44640		89 Piazza Feliziani, Nocera del friuli, Italy
229	0	0101000020E6100000FA2D9512DD7227409453967C47234640		7 Piazza Martina, Franceschi lido, Italy
230	0	0101000020E61000008ECD8E54DFA12B403562C1583A2D4540		47 Rotonda Piva, Ada calabro, Italy
231	0	0101000020E610000020651FBF127F254034C06092257F4640		924 Contrada Ferilli, Pastorelli umbro, Italy
232	0	0101000020E610000064BB31F3D36E22404F401361C3C24640		8 Via Caporaso, Quarto Nilde, Italy
233	0	0101000020E6100000D160AEA0C47E2240E41824D813C04640		40 Piazza Mancio, Violante laziale, Italy
234	0	0101000020E61000006FD8B628B3B91E40086465EA64D64640		8 Piazza Benvenuta, Ermenegildo salentino, Italy
235	0	0101000020E610000016CDB9CAC93E2140BC0E8B074A744640		02 Incrocio Ferrando, Dionisi calabro, Italy
236	0	0101000020E6100000B4064A65E54A274026DAFA8E86E14640		07 Borgo Grande, Settimo Prudenzia, Italy
237	0	0101000020E61000000736F80CF26822405273034F6B9C4640		937 Incrocio Lori, Izzo veneto, Italy
238	0	0101000020E6100000DF6124C511412140D11CFE3FF3744640		20 Borgo Giuseppe, Tarcisio del friuli, Italy
239	0	0101000020E610000077ED77CD50412140CB243493B9744640		16 Borgo Marchesini, Arianna nell'emilia, Italy
240	0	0101000020E61000002E008DD2A5032D406B5CA4F55C204540		503 Strada Sabele, Fabiano sardo, Italy
241	0	0101000020E61000004ED367075C6F1F403A57941282D64640		66 Piazza Pavone, Speranza del friuli, Italy
242	0	0101000020E61000006405BF0D316E1F409F07D22060D24640		6 Rotonda Capannolo, Massimo del friuli, Italy
243	0	0101000020E61000006F4BE482334C2740A928A8F287304640		818 Strada Veneranda, Pedrotti terme, Italy
244	0	0101000020E61000005BC52CC59F522B40DB68A5B50EFA4640		636 Contrada Lezzi, Festo veneto, Italy
245	0	0101000020E61000000D5F155E383A21402BCC310F4F724640		766 Piazza Alessandra, Lo Cascio nell'emilia, Italy
246	0	0101000020E6100000E04158326C5D2140821C9430D3704640		57 Rotonda Salomone, Borgo Bianca veneto, Italy
247	0	0101000020E6100000C1F979F8D7071F404EFA319C21CD4640		154 Incrocio Alida, Masia calabro, Italy
248	0	0101000020E61000000C97B0917F3921404C9C267D6B734640		0 Via Elvira, Petrone lido, Italy
249	0	0101000020E6100000EFA18ED838742840FA10AF46D1764640		80 Strada Restivo, Pesce nell'emilia, Italy
250	0	0101000020E6100000B032BF3F4AC11E4019CD25B094D54640		121 Via Cataldo, Fiorenza salentino, Italy
251	0	0101000020E610000039FBB9579CA829401D9C3EF152FC4440		34 Contrada Panetta, San Perseo, Italy
252	0	0101000020E6100000440E5BC4C1F71E4071033E3F8C7E4640		82 Piazza Gravina, Settimo Addo veneto, Italy
253	0	0101000020E6100000C69EE2DD36D82B400B8AD5D5D3E84640		66 Strada Sassi, Siria nell'emilia, Italy
254	0	0101000020E6100000888961E2EA131F4040E7244A31CD4640		099 Rotonda Tiziano, Quarto Leonio, Italy
255	0	0101000020E6100000E8F86871C6D81E40E7EBE86E8DD84640		8 Via Privato, Sviturno calabro, Italy
256	0	0101000020E610000024BF34FBF2301F405FCE6C57E8CB4640		6 Incrocio Greppi, San Costanza ligure, Italy
257	0	0101000020E61000000242902859C7254075988AE832F64540		751 Strada Pierluigi, Quarto Panfilo ligure, Italy
258	0	0101000020E61000005CEC5113D8AF1E405650ACAE9ED84640		2 Strada Osanna, Dalmasso nell'emilia, Italy
259	0	0101000020E6100000A6A84423E9E41E40BF20336145E14640		2 Borgo Martini, Valente terme, Italy
260	0	0101000020E6100000F07A7AB6582B2740B1ADFAB726234640		389 Contrada Musso, Quarto Carina salentino, Italy
261	0	0101000020E61000002252D32EA6C91E404392B47636E94640		2 Incrocio Igino, San Mirocleto, Italy
262	0	0101000020E61000000BC336983C2C27405262D7F676234640		70 Borgo Enrico, Cataldo del friuli, Italy
263	0	0101000020E61000004F722C94F1E8264075F2D885D5064740		08 Via Napolitano, Chessari a mare, Italy
264	0	0101000020E61000005C8BBBE6FA8F26407A4F8AFB343B4740		3 Incrocio Brando, Borgo Romana laziale, Italy
265	0	0101000020E61000007B9054956C0B28407BB5487FD4974640		814 Incrocio Salomone, Piazza a mare, Italy
266	0	0101000020E6100000BE52F1DA00B72B40D21D1F8887274540		6 Strada Apollina, San Onesto del friuli, Italy
267	0	0101000020E6100000A732D6485C052740FDD8243FE2394640		296 Piazza Barresi, Sesto Tabita, Italy
268	0	0101000020E6100000AD94545C0B4D2240EE885462E8B94640		3 Rotonda Priamo, Ciavarella ligure, Italy
269	0	0101000020E6100000333097F9B3641F40983BE93356DF4640		776 Incrocio Palano, Quarto Auberto terme, Italy
270	0	0101000020E61000002B8AB2124E762740C1EA234B41314640		9 Borgo Biagio, Cointa del friuli, Italy
271	0	0101000020E6100000905F8951219022403E5695229E864640		98 Borgo Emiliana, Sesto Ubertino a mare, Italy
272	0	0101000020E610000096C1621E43E92640E580B80611044740		18 Via Giorgia, Quarto Nicarete, Italy
273	0	0101000020E61000007090B52B99842B40E461461DC27E4640		58 Strada Casano, San Giosu� salentino, Italy
274	0	0101000020E610000084B1CFAD219A26406BDECC43010E4740		40 Piazza Mauro, Guarino laziale, Italy
275	0	0101000020E6100000CC1D47BDF13F2240A5A31CCC26824640		077 Rotonda Semplicio, Settimo Maruta, Italy
276	0	0101000020E610000048E58123DCFF26407F7E294D94084740		16 Via Decimo, Borgo Lelia nell'emilia, Italy
277	0	0101000020E61000006B5A73918C1625409D7C1FB358204740		5 Borgo Maugeri, Sviturno terme, Italy
278	0	0101000020E6100000204F818241C01E40068B1E53D2D34640		096 Contrada Antonio, Bentivoglio lido, Italy
279	0	0101000020E6100000C0CBB161F2931E40B859BC5818D34640		061 Incrocio De Biase, Settimo Patrizia, Italy
280	0	0101000020E610000070DA4246F68B2C40A79C8AAFD1364740		45 Piazza Doro, San Agabio umbro, Italy
281	0	0101000020E6100000A9D5FC9D92882C4058FBE02131384740		2 Contrada Galeazzo, Ione laziale, Italy
282	0	0101000020E6100000F74A0FF91DD1274067DC8AB3D8024740		706 Strada Innocenti, Settimo Concordio ligure, Italy
283	0	0101000020E61000004221A7542EE52C40A39BB3F457164740		77 Contrada Acrisio, Grazia a mare, Italy
284	0	0101000020E6100000D3D7987C586422408E7CB9AA47A84640		568 Borgo Esterina, Ilario del friuli, Italy
285	0	0101000020E610000008CDAE7B2B8A2440E646EC6EF9664540		301 Incrocio Lepore, Settimo Altea, Italy
286	0	0101000020E610000081EB8A19E1CD26408A4457D8C2194640		51 Piazza Olimpia, Eleonora del friuli, Italy
287	0	0101000020E6100000B4CA4C69FD5122404A95CDC1D8134540		8 Contrada Maione, Eliana calabro, Italy
288	0	0101000020E6100000E4BD6A65C267264033260EEA6CBC4640		611 Piazza Panza, Sempronio salentino, Italy
289	0	0101000020E610000071C0536DDCD325406C312E0BDCB14640		36 Contrada Ivanoe, Nicola veneto, Italy
290	0	0101000020E6100000B368F0ADFEEA2540D42AFA4333B54640		013 Incrocio Matteucci, Borgo Nilde nell'emilia, Italy
291	0	0101000020E61000005B2CA0AB08EA2740DE454E15422C4740		46 Contrada Capizzi, Giambattista umbro, Italy
292	0	0101000020E61000009703988D2933274052EC0D63778A4640		2 Via Monte Grappa, Lendinara, Italy
293	0	0101000020E61000005389FC44AF582940E7D2AEF83CCA4640		14 Rotonda Crespignano, San Paola veneto, Italy
294	0	0101000020E61000000236D6B441802C4025D5D237C46B4440		44 Via dei Greci, Napoli, Italy
295	0	0101000020E610000073220BE24DBC2740A1E4C40DAE2D4740		734 Rotonda Dodaro, Settimo Dianora ligure, Italy
296	0	0101000020E610000046B1DCD26AB02540072E45A808074740		6 Via Orsolina, Borgo Aronne terme, Italy
297	0	0101000020E6100000B17E7DBE77992240C0F858B043504440		525 Piazza Giulio, Dianora ligure, Italy
298	0	0101000020E6100000EC3026FDBD2C27403B6AF1CE46024740		535 Contrada Rusciano, Sesto Valentina, Italy
299	0	0101000020E6100000996EC8F5A5712B40C576F700DD3C4740		135 Rotonda Climaco, Bisio del friuli, Italy
300	0	0101000020E6100000AA5DB818A8F922406B0DA5F622154440		7 Incrocio Valentini, Quarto Beltramo, Italy
301	0	0101000020E610000034B10AE58E682040CFC941BFA57A4440		894 Incrocio Sarbello, Ave umbro, Italy
302	0	0101000020E610000008D04AB5AABC2140800F5EBBB4374640		617 Contrada Cleopatra, Vinfrido nell'emilia, Italy
303	0	0101000020E6100000B35DA10F967D2D408F49905BDD324740		19 Via Ferrara, Borgo Adalgiso nell'emilia, Italy
304	0	0101000020E6100000852348A5D8C12840842458C114E24540		347 Incrocio Berto, Settimo Linda, Italy
305	0	0101000020E6100000BF5076E915252B40EA398EC4703B4740		394 Incrocio Cleopatra, Castaldi ligure, Italy
306	0	0101000020E6100000B956D6917EDA2B40DF707A72A8054540		5 Rotonda Rosario, Ennio ligure, Italy
307	0	0101000020E61000007889A02067742340DE2A3EF493CE4640		630 Strada Sabazio, Nicol� a mare, Italy
308	0	0101000020E6100000235399BDC70C254059CFFF6101ED4540		6 Piazza Evaldo, Piergiorgio ligure, Italy
309	0	0101000020E610000027F33405D7392640E75E16C90D2C4740		722 Via Zampieri, Giorgia del friuli, Italy
310	0	0101000020E61000001C15EE4BECAC2A40DD11A9C4D02E4540		444 Rotonda Vera, Borgo Ottaviano terme, Italy
311	0	0101000020E6100000C1D4850E70E722408E6D63FDB0594540		66 Contrada Giuseppa, Filomena lido, Italy
312	0	0101000020E6100000E5BA849E28A826407E7D63BE723F4640		860 Piazza Di Caccamo, Bonomo nell'emilia, Italy
313	0	0101000020E610000055B1E72109D11F4018CFA0A17FB14640		234 Strada Cirillo, Noemi salentino, Italy
314	0	0101000020E61000007DEFCA89D18E2640DB0B16985F354540		61 Strada Benedetti, San Porzia, Italy
315	0	0101000020E6100000BB6D9516E41D244002678412C1A94640		495 Borgo Masi, Quarto Soccorso, Italy
316	0	0101000020E6100000F67AF7C77BB52740FA449E245D4F4740		362 Strada Colmazio, Settimo Zanita del friuli, Italy
317	0	0101000020E6100000DE68119BD960294098E8E225EEFB4440		9 Piazza Ildefonso, Guiscardo veneto, Italy
318	0	0101000020E61000007ED3AA4CE7E52340C9CC052E8F254640		402 Borgo Giona, Settimo Laura salentino, Italy
319	0	0101000020E61000004EDF217B732E2240D3F4D901D7214540		43 Contrada Scotti, Agnello del friuli, Italy
320	0	0101000020E61000004377A45588CA264008951348E43C4640		0 Incrocio Sabato, Zingaretti lido, Italy
321	0	0101000020E610000072593B40E6692840252D4B2A09EC4440		2 Incrocio Alcamo, Sesto Ulfa, Italy
322	0	0101000020E610000023E7B3F281D7214072C8618B38C84640		9 Borgo Cardinale, Luconi sardo, Italy
323	0	0101000020E61000000C84AE8E2D752740A4897780272E4640		0 Strada Pesaresi, Metrofane lido, Italy
324	0	0101000020E6100000A63C5F58A33326408C811A63CCED4540		593 Via Remo, San Desiderato salentino, Italy
325	0	0101000020E6100000CC0C1B65FD922840A42C8DA905C14640		946 Rotonda Siricio, Amabile sardo, Italy
326	0	0101000020E61000007332CC64933F2740FEDDF1DC31254640		48 Strada Bosco, Sesto Adelardo, Italy
327	0	0101000020E610000032D758784D462240743F4C67CC0B4740		7 Contrada Iorio, Sesto Sebastiano sardo, Italy
328	0	0101000020E61000002B16BF29ACC825401AB6775787864540		4 Rotonda Ercoli, Settimo Fedele, Italy
329	0	0101000020E6100000FE00B562C9B62A4032CFA51364D94440		736 Piazza Rollo, Settimo Crescenzia umbro, Italy
330	0	0101000020E61000002AD890C9F3362640A3C629DFD80F4640		9 Rotonda Colmanno, Ines umbro, Italy
331	0	0101000020E610000098F0958AD7422540F3DD52735E994640		90 Contrada Galluzzo, Gianpaolo lido, Italy
332	0	0101000020E6100000451B36806D772640B99BF1C7FE074740		444 Incrocio Serafino, Sicuro terme, Italy
333	0	0101000020E61000008948A8740B9027402B7D321015F14540		22 Rotonda Ragone, Borgo Regolo, Italy
334	0	0101000020E6100000484B8A3496612B40F1F44A5986DF4640		777 Piazza Remondo, Quarto Apollonia, Italy
335	0	0101000020E610000006240626DCE0264059631A97BBDC4640		59 Via Cottone, Settimo Ester calabro, Italy
336	0	0101000020E61000001A62067470422640EF6BC94F4FBD4540		98 Incrocio Elena, Quarto Annunziata, Italy
337	0	0101000020E6100000F0F1536694F425402F5D77A9C7134640		026 Contrada Isabella, Sesto Santo lido, Italy
338	0	0101000020E6100000A5DAA7E3317F2240E75E16C90DEF4640		757 Contrada Asterio, Bassilla calabro, Italy
339	0	0101000020E6100000D12E956D967D2C40126C5CFFAE6D4440		40 Strada Gianbattista, Pierangelo veneto, Italy
340	0	0101000020E6100000DD6CBDF0941F27409F515F3BBDDA4640		06 Incrocio Pacifico, Borrelli del friuli, Italy
341	0	0101000020E610000096EA025E66002640FA4E82ED16F44540		428 Incrocio Marini, Settimo Alfio, Italy
342	0	0101000020E61000009DDE20B5E43C25407F83F6EAE39D4540		5 Rotonda Salis, Borgo Aristione veneto, Italy
343	0	0101000020E6100000016E162F168E2340861BF0F9614A4440		094 Incrocio Michelangelo, Quarto Mauro, Italy
344	0	0101000020E61000009F32480BE1EA20405C8A50114CDA4640		30 Incrocio Efisio, Marica umbro, Italy
345	0	0101000020E6100000618841052C422B400938DFE3A78E4640		08 Rotonda Dal Farra, Andromeda laziale, Italy
346	0	0101000020E6100000160F94803D132140276BD44334E04640		8 Rotonda Lorenzo, Paladini ligure, Italy
347	0	0101000020E610000097A13BD22A4C25401A80B2CE9DD44540		5 Piazza Asimodeo, Plinio ligure, Italy
348	0	0101000020E6100000AD904D4DDD3827405B632BC313B14540		9 Strada Casimiro, Di Martino sardo, Italy
349	0	0101000020E610000071E82D1EDEEB2C405F93DA30AF824440		507 Contrada Correale, Dolci veneto, Italy
350	0	0101000020E6100000DA48C8F6109B1F40EE2AFFB5176E4640		190 Piazza Masi, San Amerigo, Italy
351	0	0101000020E61000004D028A4798F02740C38366D7BD264640		55 Rotonda Donata, Sparacino calabro, Italy
352	0	0101000020E6100000BCB77DEAB38A2C404EF04DD3676E4440		4 Piazza Verme, Acilia lido, Italy
353	0	0101000020E6100000CBC80F4BB93126404793E6EA22FD4640		5 Via Cleo, Settimo Ardito laziale, Italy
354	0	0101000020E6100000A68E9FD7E925284065677682A2C64640		150 Strada Barbarigo, Salomone laziale, Italy
355	0	0101000020E6100000407562C55F5D294091FC773359C24640		931 Rotonda Concetta, San Odidone, Italy
356	0	0101000020E6100000CF328B506C4D244070D63B37C8184640		653 Borgo Servidio, Quarto Adelasia, Italy
357	0	0101000020E61000007E6E0D11DC1122409453967C47EB4640		545 Incrocio Verulo, Canova terme, Italy
358	0	0101000020E610000043A44BA4D989204072A8DF85ADD34640		66 Piazza Poggi, Quaranta umbro, Italy
359	0	0101000020E61000004371C79BFC022C404AF5F81807254540		911 Rotonda Castaldo, San Sveva calabro, Italy
360	0	0101000020E61000009EA74B10BFA422400292FAFC41944440		744 Via Pallotta, Quarto Odorico laziale, Italy
361	0	0101000020E61000000D88B59D5B012C40CF70B9B024144540		13 Strada Pugliesi, Borgo Cora terme, Italy
362	0	0101000020E610000059935D1F8CFE26407E6DA23B2D3B4640		2 Strada Palladio, Borgo Verecondo, Italy
363	0	0101000020E6100000D50451F7010829403B736AC2510D4640		97 Rotonda Antenucci, Antenucci sardo, Italy
364	0	0101000020E6100000CD6152D735012740D65F6523C6394640		3 Strada Tullia, Borgo Donna terme, Italy
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash") FROM stdin;
2	$2b$10$naA/tW.4ikzm1USaTlj2jOyZtMBB6jqw8YyAH.xPFD2.5Kvn8zWh2	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N
4	$2b$10$qgOoNG.PxbOuF1Nx.xA3FOCKgbNpCb0sCJOm.4aqpxXkPzxELp61.	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N
5	$2b$10$U8gacZslEdgin1f1fg7lu..vfXCad4r25CFSazTMv/zycX.hNG90.	Laura	Zurru	5	laura@emergency.it	\N	t	\N
1	$2b$10$QduckJgx1IsmfuYjoQ3LUOZM4riP9cQPaHWtKujii4g6yXWbQwvDe	German	Gorodnev	0	german@hiker.it	\N	t	\N
3	$2b$10$qCMIdvLj1lt7cmqxOUq97.tiEjWnBI2ZHEosU7oD/MEm9wXjjACF.	vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 370, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 108, true);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 256, true);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 364, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: hike_points PK_7fc686c35c52228d8494a7c4947; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_7fc686c35c52228d8494a7c4947" PRIMARY KEY ("hikeId", "pointId");


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

