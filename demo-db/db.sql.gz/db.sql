--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: insert_hike(integer, character varying, integer, character varying, character varying, character varying, character varying, character varying, numeric, numeric, integer, character varying, jsonb, jsonb, jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hike(user_id integer, title character varying, difficulty integer, gpx_path character varying, country character varying, region character varying, province character varying, city character varying, length numeric, ascent numeric, expected_time integer, description character varying, pictures jsonb, start_point jsonb, end_point jsonb, reference_points jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $$;


--
-- Name: insert_hut(integer, double precision, double precision, integer, numeric, character varying, character varying, character varying, character varying, numeric, time without time zone, time without time zone, character varying, character varying, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut(user_id integer, lat double precision, lon double precision, number_of_beds integer, price numeric, title character varying, address character varying, owner_name character varying, website character varying, elevation numeric, working_time_start time without time zone, working_time_end time without time zone, email character varying, phone_number character varying, pictures jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber",
      "pictures"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number,
      pictures
    );
    END
    $$;


--
-- Name: insert_parking_lot(integer, double precision, double precision, character varying, integer, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_parking_lot(user_id integer, lat double precision, lon double precision, name character varying, max_cars integer, address character varying, city character varying, country character varying, region character varying, province character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: code-hike; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."code-hike" (code, "userHikeId") FROM stdin;
\.


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
1	1	0	5
1	2	100000	6
1	3	1	3
1	4	2	3
2	5	0	5
2	6	100000	6
3	7	0	5
3	8	100000	6
3	9	1	3
3	10	2	3
4	11	0	5
4	12	100000	6
4	13	1	3
4	14	2	3
5	15	0	5
5	16	100000	6
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country, condition, cause, pictures, "weatherStatus", "weatherDescription") FROM stdin;
1	2	0.90	80	18.10	2	Amprimo	Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.	/static/gpx/Amprimo.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/3.jpg"]	0	
2	2	3.20	200	19.80	1	Anello Chateau Beaulard - Cotolivier - Vazon	Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.	/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx	0.00	Piemonte	Torino	Beaulard	Italia	0		["/static/images/2.jpg"]	0	
3	2	4.10	210	16.40	2	Lago Bianco	Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.\n\nLa diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.\n\nLa Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.\n\nSi può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.	/static/gpx/Lago Bianco.gpx	0.00	Auvergne-Rhone-Alpes	Savoia	Val-Cenis	Francia	0		["/static/images/1.jpg"]	0	
4	2	4.90	200	19.30	2	Alte Langhe Settentrionali - Cossano Belbo	Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.\nSi svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.\nSi imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.\nInizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.\nPercorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. \nSeguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. \nSi procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante	/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx	0.00	Piemonte	Cuneo	Cossano Belbo	Italia	0		["/static/images/4.jpg"]	0	
5	2	3.80	225	8.80	2	La pieve romanica di Piesenzana e la valle delle tartufaie	Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. \nCirca 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. \nIn regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. \nA Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). \nContemporaneamente i ristoranti della zona propongono piatti a base di tartufi	/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx	0.00	Piemonte	Asti	Montechiaro d'Asti	Italia	0		["/static/images/5.jpg"]	0	
\.


--
-- Data for Name: hut-worker; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."hut-worker" ("userId", "hutId") FROM stdin;
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website, elevation, pictures, description, "workingTimeStart", "workingTimeEnd", "phoneNumber", email) FROM stdin;
1	17	2	128.00	Edmund-Graf-Hütte	2	Pauside Cara	http://pretty-dusk.com	316.57	["/static/images/80fb26b5-ade4-4113-9748-53a4749e1411.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg"]		08:00:00	21:00:00	+394798486632	Albina.Vuillermoz@yahoo.it
2	18	1	143.00	Dr.Hernaus-Stöckl	2	Dott. Fulvio Marra	https://constant-edition.com	313.38	["/static/images/43900d12-7f53-4110-a6b7-772e716dbc60.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg"]		06:00:00	23:00:00	+390285090373	Sansone.Vanni1@libero.it
3	19	5	92.00	Amstettner Hütte	2	Dott. Stefania Ratti	http://silver-generator.org	309.67	["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]		05:00:00	20:00:00	+394185980230	Maiorico.Sabbatini89@libero.it
4	20	5	64.00	Hochleckenhaus	2	Dott. Giovanna Falchi	https://oval-agenda.net	313.91	["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg"]		04:00:00	22:00:00	+392250090821	Bartolomea.Volpe47@gmail.com
5	21	3	140.00	Kampthalerhütte	2	Davino Tavani	http://impressive-immigration.it	284.72	["/static/images/425e8ee2-72c0-4156-b550-6e1d904663a2.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]		03:00:00	21:00:00	+390501878239	Pacifico_Graziano16@gmail.com
6	22	10	35.00	Lambacher Hütte	2	Sig. Acrisio Cipolla	https://sure-footed-hellcat.com	334.36	["/static/images/8a8c2365-2d64-43f8-a221-b05bf5ffaa47.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]		05:00:00	23:00:00	+391125661678	Zaccheo_Nobili54@email.it
7	23	8	139.00	Lustenauer Hütte	2	Davide Cascio	https://embellished-tunnel.org	270.02	["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg"]		09:00:00	20:00:00	+390142739596	Vedasto_Greco93@yahoo.com
8	24	6	143.00	Gablonzer Hütte	2	Tolomeo Rondinone	https://new-maize.org	283.21	["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]		01:00:00	19:00:00	+396388964781	Elaide_Ceccarini10@gmail.com
9	25	10	61.00	Katafygio «Flampouri»	2	Rinaldo Barresi	http://delirious-endorsement.com	267.67	["/static/images/c2613970-2a27-4a40-9cc5-fd2312ca4e60.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg"]		08:00:00	20:00:00	+398763362180	Dionigi_Lorenzini@libero.it
10	26	4	93.00	Simonyhütte	2	Sante Vicari	https://pleasing-yellowjacket.com	317.93	["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]		04:00:00	23:00:00	+399305063084	Ciriaco53@hotmail.com
11	27	8	146.00	Vinzenz-Tollinger-Hütte	2	Isaia Quinto	https://idolized-report.it	334.05	["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]		02:00:00	19:00:00	+393040962718	Taide_Palazzo37@hotmail.com
12	28	10	90.00	Ottokar-Kernstock-Haus	2	Ing. Vulmaro Rosset	https://dismal-moat.net	319.26	["/static/images/87ce0c23-8549-46fc-8538-103433b20a3c.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg"]		09:00:00	20:00:00	+397749487530	Giasone_Parrinello23@yahoo.it
13	29	7	131.00	Reisseckhütte	2	Daniela Vecchi	https://gleeful-ounce.com	267.35	["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]		06:00:00	23:00:00	+399777302009	Climaco.Verme11@hotmail.com
14	30	7	87.00	Vernagthütte	2	Sig. Aidano Di Palma	http://monstrous-lunchmeat.it	291.26	["/static/images/78948680-d691-4336-a553-7c89e39fe780.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]		07:00:00	20:00:00	+393822712112	Zaccheo_DiCesare72@libero.it
15	31	7	38.00	Wormser Hütte	2	Virgilio Zanatta	https://memorable-prince.com	326.69	["/static/images/c983162f-6637-43d8-8c74-044279d45f87.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]		09:00:00	23:00:00	+393920267921	Fulberto.Marziali13@yahoo.com
16	32	9	126.00	Biberacher Hütte	2	Ione Battisti	http://decisive-subsidy.it	278.97	["/static/images/425e8ee2-72c0-4156-b550-6e1d904663a2.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg"]		05:00:00	23:00:00	+399842921608	Massimiliano.Torrisi@yahoo.com
17	33	6	120.00	Katafygio «1777»	2	Ciro Palombi	http://which-nucleotide.it	264.72	["/static/images/8b792b0e-5416-45af-abbc-286a77a5d644.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]		08:00:00	19:00:00	+397844400219	Tizio.Cappai68@hotmail.com
18	34	5	150.00	Hochwaldhütte	2	Verdiana Spadafora	http://silky-candidate.it	312.47	["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]		03:00:00	21:00:00	+396134112829	Quartilla.Orlando71@yahoo.it
19	35	4	78.00	Kölner Eifelhütte	2	Sig. Olimpia Fabbricatore	http://frugal-listening.it	266.33	["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg"]		06:00:00	21:00:00	+396803473301	Rosanna.Marangon@email.it
20	36	10	133.00	Madrisahütte	2	Evandro Castelli	https://solid-playwright.it	331.77	["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg"]		08:00:00	20:00:00	+398611512559	Antonia.Scocco13@yahoo.it
21	37	5	101.00	Dresdner Hütte	2	Damiana Macchi	http://hurtful-luxury.org	305.25	["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]		05:00:00	18:00:00	+390676150687	Crocefisso.Baldassarre5@email.it
22	38	10	84.00	Fiderepasshütte	2	Damiano Riccardi	https://lumbering-stove.it	308.37	["/static/images/425e8ee2-72c0-4156-b550-6e1d904663a2.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg"]		08:00:00	20:00:00	+393794340860	Everardo77@yahoo.it
23	39	3	89.00	Göppinger Hütte	2	Ildegarda Marzano	https://hefty-tankful.org	321.94	["/static/images/e9b41d5b-2e1b-4dbd-ac79-d0f63cb2ddc7.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg"]		01:00:00	19:00:00	+390619141860	Cordelia.Gabrielli@hotmail.com
24	40	6	108.00	Oberzalimhütte	2	Fidenzio Antenucci	https://tart-pig.com	261.62	["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]		08:00:00	22:00:00	+392958166004	Gerardo_Cristiano@yahoo.it
25	41	6	108.00	Rastkogelhütte	2	Sig. Evidio Bortot	https://ready-workhorse.it	273.27	["/static/images/43900d12-7f53-4110-a6b7-772e716dbc60.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg"]		01:00:00	18:00:00	+396899934149	Zosima_Marciano54@hotmail.com
26	42	7	64.00	Ansbacher Skihütte im Allgäu	2	Severiano Tolu	http://wealthy-dog.org	292.15	["/static/images/8a8c2365-2d64-43f8-a221-b05bf5ffaa47.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg"]		06:00:00	22:00:00	+399511494409	Oliviera1@email.it
27	43	4	91.00	Kaltenberghütte	2	Marana Vallone	http://decent-keyboard.com	298.26	["/static/images/36bdeba2-0744-4db0-85d3-4ce367c3faf8.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg"]		04:00:00	21:00:00	+396383997357	Liberio.Baroni@libero.it
28	44	10	102.00	Schweinfurter Hütte	2	Abele Vecchi	http://expert-laugh.org	295.22	["/static/images/c983162f-6637-43d8-8c74-044279d45f87.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg"]		08:00:00	22:00:00	+390910410494	Cora_Zanon@yahoo.it
29	45	1	41.00	Katafygio «Vardousion»	2	Amilcare Capocotta	http://square-tub.net	276.19	["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg"]		02:00:00	23:00:00	+396281741714	Clemenzia30@yahoo.it
30	46	4	71.00	Kocbekov dom na Korošici	2	Amanzio Pianigiani	http://healthy-stud.org	270.59	["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]		02:00:00	23:00:00	+397259085438	Valente.Morri26@libero.it
31	47	1	61.00	Planinski dom Rašiške cete na Rašici	2	Ilaria Iannone	https://outstanding-deviance.com	268.06	["/static/images/78948680-d691-4336-a553-7c89e39fe780.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]		06:00:00	20:00:00	+399332654392	Edoardo_Mignogna6@email.it
32	48	9	135.00	Prešernova koca na Stolu	2	Dott. Zenone Righi	https://amusing-hospice.it	339.13	["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg"]		09:00:00	18:00:00	+397678378747	Gioacchino_Biagini47@hotmail.com
33	49	4	120.00	Planinski dom na Mrzlici	2	Unna Bennardo	https://serious-behalf.org	330.47	["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg"]		01:00:00	23:00:00	+397714538986	Callisto93@email.it
34	50	9	134.00	Koca na Planini nad Vrhniko	2	Cristiana Carbon	http://warm-refuge.org	307.26	["/static/images/425e8ee2-72c0-4156-b550-6e1d904663a2.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg"]		05:00:00	18:00:00	+398051050275	Quarto.Sucameli@hotmail.com
35	51	9	49.00	Zavetišce gorske straže na Jelencih	2	Delinda Santarsiero	http://dapper-wisteria.com	282.29	["/static/images/c983162f-6637-43d8-8c74-044279d45f87.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg"]		07:00:00	18:00:00	+398125087845	Guenda81@yahoo.it
36	52	5	61.00	Planinski dom na Gori	2	Viscardo Vitiello	http://definite-dashboard.net	310.88	["/static/images/4d67edf5-5712-4e90-814c-c784442057c5.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg"]		02:00:00	19:00:00	+391177203173	Ermes.Favara51@email.it
37	53	6	103.00	Bregarjevo zavetišce na planini Viševnik	2	Evidio Milano	https://possible-link.org	288.34	["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg"]		06:00:00	19:00:00	+397197700525	Olivia_Marchini@yahoo.com
38	54	4	81.00	Koca pod Bogatinom	2	Rina Trovato	http://cooked-vol.org	331.58	["/static/images/87ce0c23-8549-46fc-8538-103433b20a3c.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg"]		03:00:00	18:00:00	+391647772702	Graciliano.Pirone@gmail.com
39	55	10	81.00	Pogacnikov dom na Kriških podih	2	Rodolfo Ianni	http://envious-collectivization.org	296.09	["/static/images/c2613970-2a27-4a40-9cc5-fd2312ca4e60.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg"]		04:00:00	23:00:00	+395212394675	Baldomero.Cont@libero.it
40	56	1	110.00	Dom na Smrekovcu	2	Rosa Ruggeri	https://capital-clearing.org	293.35	["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]		08:00:00	18:00:00	+399771638040	Tirone_Trapani52@hotmail.com
41	57	4	49.00	Refuge Du Chatelleret	2	Colmanno Sergi	https://faraway-inversion.it	266.16	["/static/images/e9b41d5b-2e1b-4dbd-ac79-d0f63cb2ddc7.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg"]		01:00:00	23:00:00	+391677758433	Carolina_Orr@gmail.com
42	58	4	101.00	Refuge De Chalance	2	Romualdo Marangoni	http://reasonable-uncle.com	289.45	["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]		01:00:00	20:00:00	+392750937604	Virone.Concas14@yahoo.com
43	59	7	78.00	Refuge Des Bans	2	Margherita Gori	http://bright-lathe.net	268.94	["/static/images/c983162f-6637-43d8-8c74-044279d45f87.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg"]		07:00:00	22:00:00	+393399091734	Abibo.Saccone@email.it
44	60	8	120.00	Refuge De Pombie	2	Cherubino Guarnieri	http://digital-restructuring.org	307.00	["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg"]		05:00:00	20:00:00	+392979468585	Telemaco.Murgia@gmail.com
45	61	4	103.00	Refuge De Larribet	2	Alceste Pece	http://misguided-precedent.net	304.83	["/static/images/425e8ee2-72c0-4156-b550-6e1d904663a2.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg"]		05:00:00	18:00:00	+396843693379	Ondina.Abbate@yahoo.it
46	62	7	147.00	Refuge Du Mont Pourri	2	Gaio Di Luca	https://concrete-mixture.it	297.79	["/static/images/87ce0c23-8549-46fc-8538-103433b20a3c.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg"]		02:00:00	21:00:00	+398484684724	Aimone42@email.it
47	63	5	35.00	Refuge De La Dent D?Oche	2	Marisa Mannino	https://complex-athletics.net	262.55	["/static/images/425e8ee2-72c0-4156-b550-6e1d904663a2.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg"]		04:00:00	19:00:00	+398937328231	Aidano.Gori43@hotmail.com
48	64	2	64.00	Bergseehütte SAC	2	Isabella Serafini	https://gargantuan-encirclement.com	260.25	["/static/images/78948680-d691-4336-a553-7c89e39fe780.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg"]		03:00:00	23:00:00	+397015722903	Mercede3@hotmail.com
49	65	6	103.00	Bivouac au Col de la Dent Blanche CAS	2	Antonia Bertolini	https://irritating-equinox.it	274.14	["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg"]		03:00:00	22:00:00	+390587835177	Ciriaco.Francesconi22@yahoo.com
50	66	7	58.00	Salbitschijenbiwak SAC	2	Antioco Germani	http://blank-rating.org	320.27	["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg"]		08:00:00	19:00:00	+391902047061	Famiano.Caputo@hotmail.com
51	67	2	142.00	Spannorthütte SAC	2	Sinfronio Paganelli	https://roasted-boycott.net	278.19	["/static/images/87ce0c23-8549-46fc-8538-103433b20a3c.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]		01:00:00	18:00:00	+394474083781	Benito25@libero.it
52	68	3	124.00	Cabane Arpitettaz CAS	2	Ing. Smeralda Manfredi	http://sparse-switchboard.it	321.15	["/static/images/e9b41d5b-2e1b-4dbd-ac79-d0f63cb2ddc7.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg"]		05:00:00	19:00:00	+393921737473	Vincenzo_Bonifazi@gmail.com
53	69	3	105.00	Refugio De Lizara	2	Asimodeo Martina	http://lavish-cartoon.net	296.34	["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg"]		01:00:00	22:00:00	+393160498201	Aurelia55@hotmail.com
54	70	5	102.00	Albergue De Montfalcó	2	Rubiano Pierini	http://trustworthy-baker.it	339.94	["/static/images/e9b41d5b-2e1b-4dbd-ac79-d0f63cb2ddc7.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg"]		04:00:00	19:00:00	+397869763203	Robaldo_Fusco@gmail.com
55	71	7	135.00	El Molonillo/Peña Partida	2	Marana Cammisa	http://fluid-charlatan.it	292.14	["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg"]		02:00:00	22:00:00	+397235284633	Uberto.Maniscalco95@yahoo.com
56	72	10	82.00	La Campiñuela	2	Ing. Saffo Terzo	http://monstrous-estate.org	274.86	["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg"]		08:00:00	22:00:00	+395064004260	Smeralda_Dolce@yahoo.it
57	73	9	94.00	Titov Vrv	2	Quinziano Baldi	https://outlying-gap.it	319.18	["/static/images/b16ffd6b-749a-41fe-a316-2dbe73e0b56e.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg"]		01:00:00	20:00:00	+394790265704	Isidoro88@email.it
58	74	10	128.00	Rifugio Franchetti	2	Alda Grossi	https://intelligent-tick.net	300.43	["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg"]		01:00:00	19:00:00	+390267273562	Lucio84@gmail.com
59	75	9	54.00	Rifugio Semenza	2	Paola Canova	https://strong-ancestor.org	328.62	["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]		07:00:00	20:00:00	+399321110933	Gaudino29@libero.it
60	76	7	84.00	Rifugio Città di Mortara 	2	Cointa Malagoli	https://relieved-dynamo.org	261.86	["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]		05:00:00	21:00:00	+397781626769	Elvezio.Leone@libero.it
61	77	5	106.00	Rifugio Andolla	2	Concetto Gambino	http://closed-activist.it	336.24	["/static/images/87ce0c23-8549-46fc-8538-103433b20a3c.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg"]		01:00:00	23:00:00	+396808934063	Gionata88@gmail.com
62	78	1	97.00	Rifugio Forte dei Marmi	2	Annibale Mazzotti	http://overdue-clerk.it	291.49	["/static/images/36bdeba2-0744-4db0-85d3-4ce367c3faf8.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]		06:00:00	23:00:00	+393630233034	Leonilda89@yahoo.com
63	79	2	37.00	Rifugio Berti	2	Davino Pellegrino	https://clear-cut-anterior.net	293.88	["/static/images/87ce0c23-8549-46fc-8538-103433b20a3c.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]		03:00:00	19:00:00	+392648542125	Marina_DAnna50@gmail.com
64	80	4	122.00	Rifugio Premuda	2	Dr. Durante Cosentino	http://unconscious-sage.net	324.36	["/static/images/36bdeba2-0744-4db0-85d3-4ce367c3faf8.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]		01:00:00	22:00:00	+399415732972	Lucia82@hotmail.com
65	81	1	40.00	Rifugio Elisa	2	Barbara Andrisani	https://awesome-arithmetic.com	283.31	["/static/images/36bdeba2-0744-4db0-85d3-4ce367c3faf8.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]		07:00:00	19:00:00	+392920747407	Berengario54@gmail.com
66	82	4	144.00	Rifugio CAI Saronno	2	Cassiano Huber	https://aching-monument.com	314.96	["/static/images/4d67edf5-5712-4e90-814c-c784442057c5.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]		06:00:00	22:00:00	+390565533721	Marisa_Todaro@hotmail.com
67	83	3	82.00	Rifugio Picco Ivigna	2	Cosima D'Andrea	https://unacceptable-classic.com	295.47	["/static/images/8b792b0e-5416-45af-abbc-286a77a5d644.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]		02:00:00	20:00:00	+399012868960	Gaglioffo.Spada0@libero.it
68	84	6	78.00	Rifugio Toesca	2	Saturniano Romani	https://black-and-white-memory.org	288.89	["/static/images/c2613970-2a27-4a40-9cc5-fd2312ca4e60.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg"]		08:00:00	22:00:00	+395965544468	Annibale39@libero.it
69	85	1	73.00	Rifugio Al Cedo	2	Rebecca Gulino	http://giddy-flute.com	262.85	["/static/images/c983162f-6637-43d8-8c74-044279d45f87.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]		03:00:00	20:00:00	+394685652340	Romola65@yahoo.it
70	86	5	142.00	Capanna Gnifetti	2	Veriana Ottaviano	http://heavy-fanlight.net	322.83	["/static/images/8a8c2365-2d64-43f8-a221-b05bf5ffaa47.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg"]		08:00:00	21:00:00	+395217204810	Teodata.Raimondi@hotmail.com
71	87	2	78.00	Rifugio Aosta	2	Gaio Pecoraro	https://yellow-surgery.it	318.27	["/static/images/8b792b0e-5416-45af-abbc-286a77a5d644.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg"]		01:00:00	22:00:00	+398235781968	Diodata.Bonomo32@yahoo.it
72	88	2	82.00	Rifugio Cevedale	2	Chiaffredo Pani	https://giddy-ballot.com	320.46	["/static/images/8b792b0e-5416-45af-abbc-286a77a5d644.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]		04:00:00	19:00:00	+395613685293	Marinetta13@yahoo.it
73	89	8	66.00	Rifugio Ponti	2	Liliana Simone	https://concrete-trustee.net	318.65	["/static/images/425e8ee2-72c0-4156-b550-6e1d904663a2.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg"]		02:00:00	20:00:00	+398203444966	Fausta_Ierardi95@yahoo.com
74	90	7	146.00	Rifugio XII Apostoli	2	Alba Bini	https://multicolored-anesthesiology.net	285.25	["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg"]		04:00:00	22:00:00	+395205103623	Dione_Massaro25@yahoo.it
75	91	6	39.00	Rifugio Elisabetta Soldini	2	Vivaldo Cabras	https://lost-riding.org	301.70	["/static/images/b16ffd6b-749a-41fe-a316-2dbe73e0b56e.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]		06:00:00	18:00:00	+391127113241	Gemma.Pala15@email.it
76	92	2	114.00	Rifugio Denza	2	Fiorenziano Petronio	http://yearly-harvester.com	290.50	["/static/images/d50d1121-5179-442a-adb4-c157bd9f3aba.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]		08:00:00	23:00:00	+399178896612	Efrem_Cesaretti@hotmail.com
77	93	7	36.00	Rifugio Fonte Tavoloni 	2	Afro Delle Monache	http://sparse-ocean.net	334.39	["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg"]		06:00:00	21:00:00	+393840935093	Salomone93@gmail.com
78	94	5	92.00	Rifugio Carducci	2	Porziano Cavallini	http://grumpy-diesel.com	318.50	["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]		09:00:00	19:00:00	+392863993462	Ivo_Paolicelli44@hotmail.com
79	95	7	89.00	Rifugio Bindesi	2	Dr. Gumesindo Peroni	https://thorny-avenue.com	290.23	["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]		02:00:00	23:00:00	+392087605258	Dante_Alessandrini48@yahoo.com
80	96	7	97.00	Mountain hut Miroslav Hirtz	2	Famiano Moroni	http://failing-coordination.org	293.66	["/static/images/80fb26b5-ade4-4113-9748-53a4749e1411.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg"]		01:00:00	22:00:00	+391794949698	Colombo_Ippolito49@hotmail.com
81	97	5	87.00	Koca na Blegošu	2	Eloisa Palla	https://noisy-temper.it	327.21	["/static/images/e9b41d5b-2e1b-4dbd-ac79-d0f63cb2ddc7.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]		05:00:00	20:00:00	+393923788695	Adrione.DeGiorgi@yahoo.com
82	98	5	144.00	Wittener Hütte	2	Emma Ferraiuolo	http://nippy-cucumber.net	271.01	["/static/images/80fb26b5-ade4-4113-9748-53a4749e1411.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg"]		03:00:00	21:00:00	+397601663159	Cristiana_Macchia61@hotmail.com
83	99	5	139.00	Hochjoch-Hospiz	2	Alda Carlino	http://hard-muscat.com	328.47	["/static/images/80fb26b5-ade4-4113-9748-53a4749e1411.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]		09:00:00	18:00:00	+398190608312	Alceo_Soro@email.it
84	100	8	40.00	Meilerhütte	2	Diamante Perin	https://careless-glider.it	267.73	["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg"]		07:00:00	22:00:00	+392491764281	Ismaele_Burgio@gmail.com
85	101	7	50.00	Gaudeamushütte	2	Nicodemo Liverani	https://tremendous-broccoli.it	331.03	["/static/images/01ca1313-f573-4144-a2dd-b4be8426d956.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]		04:00:00	18:00:00	+396387594870	Franco91@gmail.com
86	102	9	58.00	Rheydter Hütte	2	Apollina Pintus	http://gross-earth.it	332.78	["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]		05:00:00	23:00:00	+394705549761	Giacinta.Salvadori9@email.it
87	103	8	86.00	Sektionshütte Krippen	2	Carmen Di Domenico	http://clear-forte.org	291.95	["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg"]		05:00:00	20:00:00	+397923666661	Fabio.Moscato65@email.it
88	104	10	56.00	Neunkirchner Hütte	2	Orlando Pellicano	http://dual-fix.org	284.06	["/static/images/80fb26b5-ade4-4113-9748-53a4749e1411.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg"]		07:00:00	22:00:00	+397794883585	Rainaldo_Maltese@libero.it
89	105	3	57.00	Refugio De Riglos	2	Postumio De Giorgio	http://incompatible-lighting.com	277.38	["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg"]		03:00:00	19:00:00	+398304420353	Lamberto77@gmail.com
90	106	3	42.00	Salbithütte SAC	2	Aniello Cantagallo	https://outgoing-screenwriting.com	316.96	["/static/images/43900d12-7f53-4110-a6b7-772e716dbc60.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg"]		03:00:00	23:00:00	+396386535079	Rosalinda_DArgenio@libero.it
91	107	5	39.00	Finsteraarhornhütte SAC	2	Dr. Betta Andreoli	http://majestic-sushi.it	286.67	["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg"]		02:00:00	20:00:00	+392022060190	Gallicano.Cipolla@gmail.com
92	108	2	144.00	Cabane des Vignettes CAS	2	Rainelda Gervasi	http://cautious-redhead.org	300.79	["/static/images/78948680-d691-4336-a553-7c89e39fe780.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]		09:00:00	19:00:00	+391779586979	Serviliano_Cottone@email.it
93	109	1	42.00	Glecksteinhütte SAC	2	Dagoberto Baldassarre	https://inferior-gunpowder.org	288.16	["/static/images/78948680-d691-4336-a553-7c89e39fe780.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg"]		06:00:00	19:00:00	+394994010481	Silvana.Porcari80@email.it
94	110	3	96.00	Länta-Hütte SAC	2	Ave Pezzella	http://shocking-waveform.net	282.47	["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg"]		08:00:00	20:00:00	+393359457670	Fernando.Paola@email.it
95	111	3	108.00	Monte-Leone-Hütte SAC	2	Natalina Borghi	https://jaded-bongo.org	304.95	["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]		07:00:00	18:00:00	+397905947710	Cassiopea.Riccio@email.it
96	112	10	72.00	Ringelspitzhütte SAC	2	Cora Gagliardi	https://great-academics.net	324.47	["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg"]		07:00:00	20:00:00	+397369451902	Isidora98@yahoo.com
97	113	5	66.00	Na poljanama Maljen	2	Arduino Capone	http://distant-pot.org	268.83	["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]		05:00:00	21:00:00	+397514685049	Brunilde18@gmail.com
98	114	6	53.00	Dobra voda	2	Vito Franzoni	https://fresh-crotch.it	330.16	["/static/images/36bdeba2-0744-4db0-85d3-4ce367c3faf8.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg"]		05:00:00	21:00:00	+398415238989	Marta.Gigliotti@yahoo.com
99	115	1	106.00	Ivanova hiža	2	Onesto Silvestrini	http://stupid-dragster.com	331.78	["/static/images/d50d1121-5179-442a-adb4-c157bd9f3aba.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]		02:00:00	18:00:00	+399674225289	Anatolia_Carrozzo15@hotmail.com
100	116	4	107.00	Glavica	2	Carmela Canova	http://lanky-growth.com	319.27	["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg", "/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg"]		03:00:00	18:00:00	+399802717702	Romualdo.Passarelli@gmail.com
101	117	5	76.00	Trpošnjik	2	Fiordaliso Cappiello	https://past-use.com	315.78	["/static/images/4d67edf5-5712-4e90-814c-c784442057c5.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]		02:00:00	23:00:00	+397731577088	Bino_Petronio11@hotmail.com
102	118	3	101.00	Bitorajka	2	Zanita Graziani	https://rash-vineyard.com	308.04	["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg", "/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]		05:00:00	22:00:00	+395983003331	Fidenzio79@libero.it
103	119	9	47.00	Zlatko Prgin	2	Natalina Zanatta	https://merry-testing.net	279.03	["/static/images/8a8c2365-2d64-43f8-a221-b05bf5ffaa47.jpg", "/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg", "/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg"]		07:00:00	23:00:00	+397502462015	Vasco.Pirrone32@yahoo.com
104	120	10	110.00	Prpa	2	Aiace Barbarulo	http://insistent-lookout.com	333.52	["/static/images/b16ffd6b-749a-41fe-a316-2dbe73e0b56e.jpg", "/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg"]		04:00:00	23:00:00	+393267029969	Demetria_Dionisi70@hotmail.com
105	121	3	140.00	Ždrilo	2	Gioia Tasso	https://astonishing-midline.net	278.16	["/static/images/c2613970-2a27-4a40-9cc5-fd2312ca4e60.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg", "/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]		03:00:00	22:00:00	+394279268223	Eustorgio_Ferroni45@email.it
106	122	8	141.00	Miroslav Hirtz	2	Violante Zappalà	https://alive-revitalisation.it	338.16	["/static/images/78948680-d691-4336-a553-7c89e39fe780.jpg", "/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg", "/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg", "/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg", "/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg"]		07:00:00	20:00:00	+393007705372	Lorena_Pintus84@gmail.com
107	123	3	106.00	Jezerce	2	Dott. Marciano Ledda	http://klutzy-rainy.net	305.84	["/static/images/87ce0c23-8549-46fc-8538-103433b20a3c.jpg", "/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg", "/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]		06:00:00	20:00:00	+396409572071	Mercede_Valenza@libero.it
108	124	8	114.00	Ivica Sudnik	2	Elda Carlucci	http://legal-backburn.com	338.00	["/static/images/b16ffd6b-749a-41fe-a316-2dbe73e0b56e.jpg", "/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg", "/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg", "/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg", "/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]		03:00:00	18:00:00	+395220368758	Riccarda.Cipollaro50@yahoo.com
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
1	125	72	2	Italy	Salerno		Benedetti terme
2	126	73	2	Italy	Teramo		Quarto Fabiana a mare
3	127	292	2	Italy	Piacenza		Polese lido
4	128	79	2	Italy	Cosenza		Lorusso ligure
5	129	260	2	Italy	Caserta		Quarto Serafina
6	130	275	2	Italy	Perugia		Settimo Euridice ligure
7	131	293	2	Italy	Pescara		Settimo Venera umbro
8	132	227	2	Italy	Treviso		Crespignano lido
9	133	173	2	Italy	Oristano		San Annamaria lido
10	134	248	2	Italy	Barletta-Andria-Trani		Bruschi calabro
11	135	255	2	Italy	Nuoro		San Amando
12	136	283	2	Italy	Ascoli Piceno		Borgo Ginevra
13	137	207	2	Italy	Lecco		Borgo Antimo del friuli
14	138	99	2	Italy	Milano		Giovanni umbro
15	139	153	2	Italy	Brindisi		Quarto Callisto salentino
16	140	147	2	Italy	Pesaro e Urbino		Settimo Amone
17	141	118	2	Italy	Vibo Valentia		Nicolini salentino
18	142	51	2	Italy	Ragusa		San Leonzio del friuli
19	143	121	2	Italy	Viterbo		Di Marino lido
20	144	235	2	Italy	Piacenza		Gatto laziale
21	145	107	2	Italy	Gorizia		San Ermenegarda calabro
22	146	228	2	Italy	Siracusa		Fichera sardo
23	147	6	2	Italy	Salerno		San Ombretta umbro
24	148	111	2	Italy	Vercelli		Miceli nell'emilia
25	149	64	2	Italy	Torino		Malagoli veneto
26	150	41	2	Italy	Benevento		Settimo Grazia
27	151	56	2	Italy	Firenze		Quarto Aleandro a mare
28	152	273	2	Italy	Carbonia-Iglesias		San Flora
29	153	28	2	Italy	Bergamo		Luzzi salentino
30	154	168	2	Italy	La Spezia		Carlotti terme
31	155	236	2	Italy	Aosta		Venturelli calabro
32	156	27	2	Italy	Nuoro		Quarto Ascanio
33	157	39	2	Italy	Bari		Quarto Anita
34	158	5	2	Italy	Trieste		Ranucci veneto
35	159	192	2	Italy	Ancona		San Emmerico terme
36	160	217	2	Italy	Genova		Erardo umbro
37	161	34	2	Italy	Agrigento		Priscilla umbro
38	162	291	2	Italy	Pesaro e Urbino		Borgo Ventura
39	163	217	2	Italy	Alessandria		Niceto a mare
40	164	265	2	Italy	Matera		Rocca sardo
41	165	20	2	Italy	Lecce		Colombano terme
42	166	176	2	Italy	Monza e della Brianza		Borgo Emilia laziale
43	167	278	2	Italy	Monza e della Brianza		Filice sardo
44	168	40	2	Italy	Rieti		Bonomi lido
45	169	211	2	Italy	Latina		Cozzolino terme
46	170	207	2	Italy	Caltanissetta		Catena lido
47	171	282	2	Italy	Ogliastra		Fabio nell'emilia
48	172	98	2	Italy	Bologna		Borgo Mennone
49	173	65	2	Italy	Siena		Belotti del friuli
50	174	118	2	Italy	Olbia-Tempio		Teodoto ligure
51	175	232	2	Italy	Cosenza		Morabito lido
52	176	11	2	Italy	Belluno		Settimo Adria
53	177	76	2	Italy	Rieti		Castellani nell'emilia
54	178	8	2	Italy	Pavia		Quarto Emiliano terme
55	179	214	2	Italy	Venezia		Cozzolino ligure
56	180	26	2	Italy	Sondrio		Borgo Basileo sardo
57	181	300	2	Italy	Mantova		San Gerino terme
58	182	90	2	Italy	L'Aquila		Gustavo sardo
59	183	297	2	Italy	Ravenna		Loretta veneto
60	184	234	2	Italy	Isernia		San Leopoldo ligure
61	185	90	2	Italy	Firenze		Delfina lido
62	186	207	2	Italy	Reggio Emilia		Clara del friuli
63	187	36	2	Italy	Olbia-Tempio		Settimo Gallicano
64	188	109	2	Italy	Crotone		Borgo Lieto
65	189	161	2	Italy	Siracusa		Quarto Vinebaldo lido
66	190	152	2	Italy	Chieti		Quarto Severino salentino
67	191	152	2	Italy	Padova		San Bino
68	192	180	2	Italy	Cuneo		Baldovino salentino
69	193	223	2	Italy	Terni		Ulfo laziale
70	194	15	2	Italy	Como		Sesto Gerolamo
71	195	96	2	Italy	Cremona		Ulfo calabro
72	196	239	2	Italy	Siracusa		Sesto Siro
73	197	209	2	Italy	Enna		Valentino nell'emilia
74	198	59	2	Italy	Forlì-Cesena		Sesto Noemi terme
75	199	239	2	Italy	Siracusa		Settimo Sabele
76	200	47	2	Italy	Belluno		Ilaria a mare
77	201	258	2	Italy	Venezia		Settimo Teodosio calabro
78	202	140	2	Italy	Sondrio		Tufano sardo
79	203	82	2	Italy	Trento		Settimo Ladislao
80	204	123	2	Italy	Ancona		Neopolo a mare
81	205	89	2	Italy	Modena		Quarto Apuleio a mare
82	206	73	2	Italy	Teramo		Scrofani ligure
83	207	229	2	Italy	Frosinone		Borgo Albina sardo
84	208	211	2	Italy	Verona		Criscenti terme
85	209	60	2	Italy	Alessandria		Borrelli a mare
86	210	208	2	Italy	Modena		Borgo Noemi
87	211	256	2	Italy	Latina		Quarto Giliola
88	212	205	2	Italy	Vicenza		Borgo Gedeone sardo
89	213	48	2	Italy	Cosenza		Settimo Sarbello calabro
90	214	35	2	Italy	Medio Campidano		Carola salentino
91	215	268	2	Italy	Bergamo		Settimo Tibaldo
92	216	101	2	Italy	Latina		Settimo Rosario veneto
93	217	61	2	Italy	Parma		Grieco a mare
94	218	62	2	Italy	Prato		Borgo Galdino laziale
95	219	262	2	Italy	Sondrio		Ubertino sardo
96	220	242	2	Italy	Campobasso		Settimo Degna
97	221	291	2	Italy	Livorno		Elpidio umbro
98	222	195	2	Italy	Rieti		Algiso sardo
99	223	62	2	Italy	Rovigo		Settimo Ascanio veneto
100	224	226	2	Italy	Sondrio		Archimede salentino
101	225	241	2	Italy	Lecce		Roma
102	226	93	2	Italy	La Spezia		Valerio umbro
103	227	224	2	Italy	Varese		Mancino del friuli
104	228	300	2	Italy	Matera		Aiello a mare
105	229	201	2	Italy	Nuoro		Ramella salentino
106	230	87	2	Italy	Forlì-Cesena		Sesto Averardo sardo
107	231	254	2	Italy	Pavia		Borgo Aida
108	232	270	2	Italy	Carbonia-Iglesias		Scala calabro
109	233	106	2	Italy	Cremona		Sandra ligure
110	234	160	2	Italy	Bergamo		Girardi sardo
111	235	293	2	Italy	Massa-Carrara		San Ponziano
112	236	200	2	Italy	Cuneo		Quarto Orlando umbro
113	237	273	2	Italy	Piacenza		Carlini nell'emilia
114	238	72	2	Italy	Imperia		San Leonia veneto
115	239	242	2	Italy	Pavia		San Godiva
116	240	225	2	Italy	Olbia-Tempio		Carminati terme
117	241	103	2	Italy	Arezzo		Omar laziale
118	242	31	2	Italy	Savona		Sesto Luisa
119	243	39	2	Italy	Catania		Settimo Eligio
120	244	128	2	Italy	Pavia		Quarto Liberto laziale
121	245	290	2	Italy	Enna		San Abdone lido
122	246	137	2	Italy	Bergamo		Carlini ligure
123	247	225	2	Italy	Rimini		Settimo Urbano terme
124	248	33	2	Italy	Barletta-Andria-Trani		Lecca calabro
125	249	113	2	Italy	Ascoli Piceno		San Athos
126	250	294	2	Italy	Padova		Ermenegarda ligure
127	251	1	2	Italy	Caserta		Sechi laziale
128	252	169	2	Italy	Pesaro e Urbino		Damiana ligure
129	253	47	2	Italy	Verona		Letizia del friuli
130	254	1	2	Italy	Ferrara		Settimo Gondulfo lido
131	255	1	2	Italy	Siena		Sanfilippo nell'emilia
132	256	292	2	Italy	Reggio Emilia		Settimo Licia
133	257	129	2	Italy	Livorno		Settimo Sisto
134	258	104	2	Italy	Ascoli Piceno		Carlini terme
135	259	189	2	Italy	Catanzaro		Borgo Pierangelo terme
136	260	79	2	Italy	Brindisi		Loriana sardo
137	261	1	2	Italy	Arezzo		Settimo Lea lido
138	262	1	2	Italy	Terni		Vidone laziale
139	263	273	2	Italy	Verona		Sesto Ponziano
140	264	1	2	Italy	Catanzaro		Bardomiano ligure
141	265	197	2	Italy	Pisa		Libero salentino
142	266	263	2	Italy	Vibo Valentia		Quarto Loretta salentino
143	267	156	2	Italy	Salerno		Borgo Telica
144	268	235	2	Italy	Piacenza		Amalia veneto
145	269	275	2	Italy	Venezia		Settimo Rossana a mare
146	270	101	2	Italy	Taranto		Sesto Benvenuto
147	271	284	2	Italy	Monza e della Brianza		Sesto Luna veneto
148	272	199	2	Italy	Pordenone		Colombo a mare
149	273	67	2	Italy	Frosinone		Nicezio umbro
150	274	251	2	Italy	Cagliari		Ione calabro
151	275	125	2	Italy	Reggio Calabria		Ghita salentino
152	276	297	2	Italy	Siracusa		Parmenio nell'emilia
153	277	83	2	Italy	Macerata		Settimo Orsolina
154	278	281	2	Italy	Siracusa		Catalano nell'emilia
155	279	182	2	Italy	Enna		San Elsa
156	280	269	2	Italy	Foggia		Borgo Esterina umbro
157	281	279	2	Italy	Bergamo		Quarto Diamante terme
158	282	177	2	Italy	Bolzano		Sosteneo del friuli
159	283	266	2	Italy	Brindisi		Sesto Galileo umbro
160	284	213	2	Italy	Catania		Settimo Augusto
161	285	263	2	Italy	Ravenna		Gaudenzia nell'emilia
162	286	111	2	Italy	Bologna		Salvatori a mare
163	287	177	2	Italy	Perugia		Pellegrino a mare
164	288	71	2	Italy	Ravenna		Indelicato terme
165	289	167	2	Italy	Macerata		Silvano salentino
166	290	30	2	Italy	Trento		Venera ligure
167	291	93	2	Italy	Chieti		Gabriella veneto
168	292	118	2	Italy	Viterbo		San Coriolano
169	293	77	2	Italy	Monza e della Brianza		Marta terme
170	294	204	2	Italy	Firenze		Borgo Arabella
171	295	59	2	Italy	Bolzano		Quarto Astrid
172	296	284	2	Italy	Venezia		Quarto Vulmaro
173	297	222	2	Italy	Savona		Lucia veneto
174	298	181	2	Italy	Perugia		Borgo Vittorio
175	299	78	2	Italy	Arezzo		Borgo Priamo
176	300	58	2	Italy	Campobasso		Bacco a mare
177	301	239	2	Italy	Pavia		Flaviano nell'emilia
178	302	71	2	Italy	Varese		Piera laziale
179	303	215	2	Italy	Roma		San Attilio
180	304	222	2	Italy	Oristano		Sesto Fulberto calabro
181	305	37	2	Italy	Trento		Caggiano calabro
182	306	85	2	Italy	Massa-Carrara		Quarto Alfonso lido
183	307	6	2	Italy	Frosinone		Loffredo lido
184	308	263	2	Italy	Arezzo		Lendinara
185	309	62	2	Italy	Ogliastra		Ludovico terme
186	310	79	2	Italy	Trieste		Napoli
187	311	78	2	Italy	Bergamo		Liberatore veneto
188	312	98	2	Italy	Mantova		Settimo Federica
189	313	60	2	Italy	Avellino		Arcadio umbro
190	314	236	2	Italy	Olbia-Tempio		Zenone veneto
191	315	71	2	Italy	Ancona		Settimo Vincenza nell'emilia
192	316	103	2	Italy	Cosenza		Fulvia laziale
193	317	148	2	Italy	Cremona		Sesto Euseo
194	318	254	2	Italy	Forlì-Cesena		Davino lido
195	319	285	2	Italy	Biella		Sesto Donatello
196	320	289	2	Italy	Fermo		Cara laziale
197	321	277	2	Italy	Ferrara		Borgo Atanasio laziale
198	322	187	2	Italy	Asti		Silvana ligure
199	323	227	2	Italy	Bari		Distefano ligure
200	324	155	2	Italy	Arezzo		Raide veneto
201	325	272	2	Italy	Novara		Sesto Amelia veneto
202	326	294	2	Italy	Frosinone		Betta veneto
203	327	410	2	Italy	Parma		Alessio nell'emilia
204	328	38	2	Italy	Reggio Calabria		Lidia salentino
205	329	177	2	Italy	Potenza		Settimo Eufemia terme
206	330	263	2	Italy	Barletta-Andria-Trani		Beniamina nell'emilia
207	331	269	2	Italy	Belluno		San Nadia umbro
208	332	277	2	Italy	Ferrara		San Lapo salentino
209	333	265	2	Italy	L'Aquila		Settimo Leda sardo
210	334	51	2	Italy	Medio Campidano		Settimo Lauriano
211	335	221	2	Italy	Siracusa		Sesto Natalina salentino
212	336	123	2	Italy	Novara		Settimo Venceslao
213	337	9	2	Italy	Frosinone		Viviano laziale
214	338	294	2	Italy	Carbonia-Iglesias		Babini del friuli
215	339	41	2	Italy	Forlì-Cesena		Quarto Baldassarre ligure
216	340	102	2	Italy	Cagliari		Settimo Sidonia
217	341	180	2	Italy	Aosta		Settimo Galdino
218	342	131	2	Italy	Rimini		Del Vecchio a mare
219	343	157	2	Italy	Perugia		Fiorenza ligure
220	344	141	2	Italy	Grosseto		San Raimondo nell'emilia
221	345	140	2	Italy	Massa-Carrara		San Apollinare del friuli
222	346	3	2	Italy	Brescia		Molinari nell'emilia
223	347	219	2	Italy	Lucca		Silenzi ligure
224	348	165	2	Italy	Milano		Settimo Severa ligure
225	349	170	2	Italy	Novara		Iorio a mare
226	350	213	2	Italy	Reggio Calabria		Giadero salentino
227	351	67	2	Italy	Rieti		Settimo Altea
228	352	60	2	Italy	Ancona		Quarto Silverio
229	353	100	2	Italy	Firenze		Clarenzio sardo
230	354	187	2	Italy	Verona		Quarto Cleo a mare
231	355	204	2	Italy	Catania		Quarto Marilena laziale
232	356	228	2	Italy	Vercelli		Sesto Augusto ligure
233	357	286	2	Italy	Messina		Sesto Calcedonio sardo
234	358	121	2	Italy	Cuneo		Loreto umbro
235	359	41	2	Italy	Bolzano		Ciotola ligure
236	360	41	2	Italy	Parma		Quarto Semiramide calabro
237	361	274	2	Italy	Brindisi		Bozzi a mare
238	362	166	2	Italy	Napoli		Sesto Galeazzo nell'emilia
239	363	82	2	Italy	Palermo		Letizia terme
240	364	88	2	Italy	Trento		Maida del friuli
241	365	147	2	Italy	Agrigento		Sesto Nostriano nell'emilia
242	366	217	2	Italy	Pisa		Sesto Ermes
243	367	107	2	Italy	Lecce		Settimo Rosalinda calabro
244	368	222	2	Italy	Matera		Pozzi nell'emilia
245	369	74	2	Italy	Olbia-Tempio		Settimo Napoleone
246	370	186	2	Italy	Caserta		Narseo sardo
247	371	140	2	Italy	Vicenza		Ventimiglia salentino
248	372	287	2	Italy	Brindisi		Borgo Doda
249	373	275	2	Italy	Bari		Borgo Nicarete
250	374	9	2	Italy	Biella		San Ottone
251	375	121	2	Italy	Siena		San Goffredo
252	376	69	2	Italy	Isernia		Modesto umbro
253	377	238	2	Italy	Salerno		Borgo Lea
254	378	28	2	Italy	Fermo		Massa laziale
255	379	162	2	Italy	Teramo		Sesto Euseo
256	380	244	2	Italy	Brindisi		Testa lido
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address, altitude) FROM stdin;
1	0	0101000020E610000043D95E8288A91C40720950EB278D4640	Start Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
2	0	0101000020E610000051A7B8816D921C408D966B20C98C4640	End Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
3	0	0101000020E6100000C668CC0D4EA81C40DA8DB03B2C8D4640		Ref Point 1	1256.85
4	0	0101000020E6100000116FE90D01A21C4022DFF1622B8D4640		Ref Point 2	1283.61
5	0	0101000020E61000004337FB03E5161B401CEBE2361A844640	Start Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
6	0	0101000020E61000001092054CE0161B401FD8F15F20844640	End Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
7	0	0101000020E610000058CB9D9960C81B408731E9EFA59C4640	Start Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
8	0	0101000020E61000003BE0BA6246C81B401E34BBEEAD9C4640	End Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
9	0	0101000020E61000007EE4D6A4DBC21B40147AFD497C9C4640		fountain	2027.00
10	0	0101000020E6100000B7B8C667B2BF1B4090A4A487A19B4640		Peak	2131.00
11	0	0101000020E61000005F9A22C0E96520406C76A4FACE554640	Start Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
12	0	0101000020E61000002368CC24EA652040CC7EDDE9CE554640	End Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
13	0	0101000020E61000006B662D05A46D20401557957D57564640		Ref Point 1	482.53
14	0	0101000020E610000024D236FE44652040813D26529A554640		Ref Point 2	242.59
15	0	0101000020E61000009F3E027FF83920409E245D33F9804640	Start Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
16	0	0101000020E610000099F56228273A20408DEDB5A0F7804640	End Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
17	0	0101000020E61000002D64979723B62440C66F2527958D4740	Edmund-Graf-Hütte	6574 Pettneu am Arlberg, Tyrol, Austria	\N
18	0	0101000020E6100000455BF9D0380E2A4056DBD4F478794740	Dr.Hernaus-Stöckl	9020 Klagenfurt, Kärnten, Austria	\N
19	0	0101000020E61000003AD4CD22968A2D406DAF4FF575F14740	Amstettner Hütte	3340 Waidhofen an der Ybbs, Niederösterreich, Austria	\N
20	0	0101000020E61000003470C88518362B404F23C0A11DEA4740	Hochleckenhaus	4853 Steinbach am Attersee, Oberösterreich, Austria	\N
21	0	0101000020E6100000745CA7EA5C3230400E95C9F10B114840	Kampthalerhütte	2384 Breitenfurt bei Wien, Niederösterreich, Austria	\N
22	0	0101000020E610000059E5350827672B402FB2862AC2D34740	Lambacher Hütte	4822 Bad Goisern, Oberösterreich, Austria	\N
23	0	0101000020E610000019FDD2643FA62340662869A087B24740	Lustenauer Hütte	6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria	\N
24	0	0101000020E610000036849931B0F52A4014BD78F039C44740	Gablonzer Hütte	4825 Gosau-Hintertal, Oberösterreich, Austria	\N
25	0	0101000020E6100000202F5A3629BF3740D489BAC5B2144340	Katafygio «Flampouri»	136 72 Acharnes, Attica region, Greece	\N
26	0	0101000020E6100000103E4BA24D3F2B40F731169C1AC04740	Simonyhütte	4830 Hallstatt, Oberösterreich, Austria	\N
27	0	0101000020E610000033190145D5182740BF9048EBDFA04740	Vinzenz-Tollinger-Hütte	6060 Hall in Tirol, Tyrol, Austria	\N
28	0	0101000020E61000001F1E0B5901B82E4091BFCBF1EAB34740	Ottokar-Kernstock-Haus	8600 Bruck an der Mur, Steiermark, Austria	\N
29	0	0101000020E610000018E4FB977DBF2A40D6A3B4422D754740	Reisseckhütte	9814 Mühldorf, Mölltal, Kärnten, Austria	\N
30	0	0101000020E61000007B116DC7D4A52540C0401020436D4740	Vernagthütte	Austria	\N
31	0	0101000020E6100000286211C30EF323407EC9C6832D884740	Wormser Hütte	Austria	\N
32	0	0101000020E6100000999CDA19A60E24406CD097DEFEA04740	Biberacher Hütte	Austria	\N
33	0	0101000020E610000007BC276AC4133740DDF934DDA1A84440	Katafygio «1777»	620 55 Kerkini, Central Macedonia region, Greece	\N
34	0	0101000020E6100000D5AF743E3C0B2A40E6E786A6EC704840	Hochwaldhütte	Germany	\N
35	0	0101000020E6100000C2FBAA5CA8EC19408FC536A968544940	Kölner Eifelhütte	Germany	\N
36	0	0101000020E6100000323CF6B358D223401763601DC7794740	Madrisahütte	Austria	\N
37	0	0101000020E6100000313F373465472640CDC98B4CC07F4740	Dresdner Hütte	Austria	\N
38	0	0101000020E6100000CDCCCCCCCC6C24403E07962364A84740	Fiderepasshütte	Germany	\N
39	0	0101000020E6100000B727486C77172440A9DDAF027C9B4740	Göppinger Hütte	Austria	\N
40	0	0101000020E6100000A379008BFC622340C7629B54348A4740	Oberzalimhütte	Austria	\N
41	0	0101000020E610000013B70A62A0932740B3B45373B99D4740	Rastkogelhütte	Austria	\N
42	0	0101000020E61000009D2D20B41E0E2440D54F49E70DC24740	Ansbacher Skihütte im Allgäu	Germany	\N
43	0	0101000020E610000009E066F16249244097E13FDD408F4740	Kaltenberghütte	Austria	\N
44	0	0101000020E61000000AD7A3703D0A2640E277D32D3B944740	Schweinfurter Hütte	Austria	\N
45	0	0101000020E61000006DC438245A213640DA172BC5E9574340	Katafygio «Vardousion»	330 53 Delphi, Central Greece region, Greece	\N
46	0	0101000020E6100000630F270F8F472D40336D62F5852D4740	Kocbekov dom na Korošici	3334 Luče, Mozirje, Slovenia	\N
47	0	0101000020E6100000D1F5D08072062D40D25C9F20CE114740	Planinski dom Rašiške cete na Rašici	1211 Ljubljana, Šmartno, Slovenia	\N
48	0	0101000020E6100000F70F966F85592C40971550C935374740	Prešernova koca na Stolu	4274 Žirovnica, Slovenia	\N
49	0	0101000020E6100000AA5C8F5FCB372E408E6CD71919184740	Planinski dom na Mrzlici	3302 Griže, Slovenia	\N
50	0	0101000020E6100000651A4D2EC6802C40577A6D3656FC4640	Koca na Planini nad Vrhniko	1360 Vrhnika, Slovenia	\N
51	0	0101000020E6100000245DF94DDD322C4077DAB7E6D0144740	Zavetišce gorske straže na Jelencih	0, -, Slovenia	\N
52	0	0101000020E6100000313F3734656F2E406F7F2E1A32264740	Planinski dom na Gori	Šentjungert, 3310 Žalec, Slovenia	\N
53	0	0101000020E610000098F2E7FC90A22B40C7CBA2C928274740	Bregarjevo zavetišce na planini Viševnik	4265 Bohinjsko jezero, Slovenia	\N
54	0	0101000020E610000091860959CC862B401635F33FD4244740	Koca pod Bogatinom	4265 Bohinjsko jezero, Slovenia	\N
55	0	0101000020E6100000678B3942E5992B40007F639573334740	Pogacnikov dom na Kriških podih	5232 Soca, Slovenia	\N
56	0	0101000020E610000008F580BBE4CC2D402A9C0F95E7344740	Dom na Smrekovcu	3325 Šoštanj, Slovenia	\N
57	0	0101000020E610000073F6CE68AB32194060E811A3E77C4640	Refuge Du Chatelleret	38520 Saint Christophe En Oisans, Isère, France	\N
58	0	0101000020E610000084622B685AF218408177F2E9B16B4640	Refuge De Chalance	5800 La Chapelle En Valgaudemar, Hautes-Alpes, France	\N
59	0	0101000020E6100000963D096CCE711940AE7FD767CE6A4640	Refuge Des Bans	5290 Vallouise, Hautes-Alpes, France	\N
60	0	0101000020E6100000DEAB5626FC52DBBFAED689CBF16A4540	Refuge De Pombie	65400 Laruns, Pyrénées-Atlantiques, France	\N
61	0	0101000020E6100000A69C2FF65E7CD2BFA9F92AF9D86D4540	Refuge De Larribet	65400 Arrens, Marsous, Hautes-Pyrénées, France	\N
62	0	0101000020E61000009CA6CF0EB84E1B401232906797C34640	Refuge Du Mont Pourri	73210 Peisey Nancroix, Savoie, France	\N
63	0	0101000020E6100000C712D6C6D8E91A40BF81C98D222D4740	Refuge De La Dent D?Oche	74500 Bernex, Haute-Savoie, France	\N
64	0	0101000020E6100000BEBDCA2243F820405620D41E27544740	Bergseehütte SAC	Uri, Switzerland	\N
65	0	0101000020E6100000CDD5732CA96D1E40F591820D5C054740	Bivouac au Col de la Dent Blanche CAS	Wallis, Switzerland	\N
66	0	0101000020E610000060F1FE571F0C2140D6BA5B328C564740	Salbitschijenbiwak SAC	Uri, Switzerland	\N
67	0	0101000020E610000084EAC5BE53052140F224048A5C664740	Spannorthütte SAC	Uri, Switzerland	\N
68	0	0101000020E6100000827FB24EBCB71E406113E452EB0C4740	Cabane Arpitettaz CAS	Wallis, Switzerland	\N
69	0	0101000020E61000008A75AA7CCF48E4BF588BF447BD614540	Refugio De Lizara	22730, Aragón, Spain	\N
70	0	0101000020E6100000AE56C01909F8E43F58DB5E1CA6064540	Albergue De Montfalcó	22585 Tolva, Aragón, Spain	\N
71	0	0101000020E61000000A4CFFBF1E610AC08B780953B6904240	El Molonillo/Peña Partida	18160 Güejar Sierra, Andalucía, Spain	\N
72	0	0101000020E610000029110100A92D0AC0F39F054F27844240	La Campiñuela	18417 Trévelez, Andalucía, Spain	\N
73	0	0101000020E61000008E79782A3BCC3440BEAE152301FF4440	Titov Vrv	Tetovo, Municipality of Tetovo, North Macedonia	\N
74	0	0101000020E6100000A2EC2DE57C212B40C7F143A5113D4540	Rifugio Franchetti	Pietracamela, Abruzzo, Italy	\N
75	0	0101000020E610000052E2299ABDFA2840518B1C7D27114740	Rifugio Semenza	Tambre, Veneto, Italy	\N
76	0	0101000020E6100000A197F67244A31F40313D06D094EE4640	Rifugio Città di Mortara 	Alagna Valsesia, Piemonte, Italy	\N
77	0	0101000020E61000006E39F29B1D242040AB1ED555260C4740	Rifugio Andolla	Antrona Schieranico, Piemonte, Italy	\N
78	0	0101000020E61000000AD80E46ECAB2440B70BCD751AFF4540	Rifugio Forte dei Marmi	Stazzema, Toscana, Italy	\N
79	0	0101000020E6100000A88B14CAC2CF284038D66AB4C1504740	Rifugio Berti	Comelico Superiore, Veneto, Italy	\N
80	0	0101000020E610000071B43E4052BB2B406FE70CD649CF4640	Rifugio Premuda	San Dorligo della Valle, Friuli Venezia Giulia, Italy	\N
81	0	0101000020E61000006CCF2C0950C32240191BBAD91FF84640	Rifugio Elisa	Mandello del Lario, Lombardia, Italy	\N
82	0	0101000020E6100000A5BDC11726B31F40F90FE9B7AFFB4640	Rifugio CAI Saronno	Macugnaga, Piemonte, Italy	\N
83	0	0101000020E610000098DD9387857A2640A930B610E4584740	Rifugio Picco Ivigna	Scena, Trentino Alto Adige, Italy	\N
84	0	0101000020E61000003AE97DE36B8F1C404AEF1B5F7B8A4640	Rifugio Toesca	Bussoleno, Piemonte, Italy	\N
85	0	0101000020E6100000A913D044D8E02040382D78D1570C4740	Rifugio Al Cedo	Santa Maria Maggiore, Piemonte, Italy	\N
86	0	0101000020E6100000449D5ECE11661F4009ED8B3A29F34640	Capanna Gnifetti	Gressoney La Trinitè, Valle d?Aosta, Italy	\N
87	0	0101000020E6100000B8AE9811DE3E1E403A048E041AFC4640	Rifugio Aosta	Bionaz, Valle d?Aosta, Italy	\N
88	0	0101000020E6100000BBB31B22135525408EA8F523EA374740	Rifugio Cevedale	Pejo, Trentino Alto Adige, Italy	\N
89	0	0101000020E61000000D33349E08722340F0A485CB2A204740	Rifugio Ponti	Val Masino, Lombardia, Italy	\N
90	0	0101000020E6100000C46D7E0DD2B125405364085B47134740	Rifugio XII Apostoli	Stenico, Trentino Alto Adige, Italy	\N
91	0	0101000020E61000009F1C058882591B40DDD1FF722DE24640	Rifugio Elisabetta Soldini	Courmayeur, Valle d?Aosta, Italy	\N
92	0	0101000020E610000061D57994804F25409903A4C1291F4740	Rifugio Denza	Vermiglio, Trentino Alto Adige, Italy	\N
93	0	0101000020E61000000C1F115322F92A40338AE596560F4540	Rifugio Fonte Tavoloni 	Ovindoli, Abruzzo, Italy	\N
94	0	0101000020E610000037C2A2224EBF2840F2ED5D83BE4E4740	Rifugio Carducci	Auronzo di Cadore, Veneto, Italy	\N
95	0	0101000020E61000006FA53220D64E26400DE02D90A0044740	Rifugio Bindesi	Trento, Trentino Alto Adige, Italy	\N
96	0	0101000020E610000001C11C3D7ECB2D40C670D0B9365A4640	Mountain hut Miroslav Hirtz	53287 Jablanac, Ličko-senjska županija, Croatia	\N
97	0	0101000020E6100000398485EEED352C4098331D324C154740	Koca na Blegošu	4224 Gorenja vas, Slovenia	\N
98	0	0101000020E610000040F850A225BF1F400F441669E2594940	Wittener Hütte	Germany	\N
99	0	0101000020E610000000FDBE7FF3AA25409A99999999694740	Hochjoch-Hospiz	Austria	\N
100	0	0101000020E6100000D7A02FBDFD412640CDCCCCCCCCB44740	Meilerhütte	Germany	\N
101	0	0101000020E610000050C422861DA628406E85B01A4BC64740	Gaudeamushütte	Austria	\N
102	0	0101000020E6100000179CC1DF2F961940D5EB1681B15C4940	Rheydter Hütte	Germany	\N
103	0	0101000020E6100000FB66518EB8562C4057E883656C744940	Sektionshütte Krippen	Germany	\N
104	0	0101000020E61000001F7A839D234C2C40B45EF68814A34740	Neunkirchner Hütte	2620 Neunkirchen, Steiermark, Austria	\N
105	0	0101000020E61000009CE379FC2043E7BF8FC536A9682C4540	Refugio De Riglos	22808, Aragón, Spain	\N
106	0	0101000020E6100000563D4FC4941A2140EBB308E997564740	Salbithütte SAC	Uri, Switzerland	\N
107	0	0101000020E61000001D55C855B23A2040B8EB64DCCE424740	Finsteraarhornhütte SAC	Wallis, Switzerland	\N
108	0	0101000020E6100000DEFD765E1AE71D4038777A52B2FE4640	Cabane des Vignettes CAS	Wallis, Switzerland	\N
109	0	0101000020E6100000E769EE0B84312040FBE19FAF02504740	Glecksteinhütte SAC	Bern, Switzerland	\N
110	0	0101000020E6100000752B5D3C5F152240D9971BDB51454740	Länta-Hütte SAC	Graubünden, Switzerland	\N
111	0	0101000020E610000055ADDEFA26292040BAB9F14860214740	Monte-Leone-Hütte SAC	Wallis, Switzerland	\N
112	0	0101000020E6100000557F0CE8F9C222408F373B25D26E4740	Ringelspitzhütte SAC	Graubünden, Switzerland	\N
113	0	0101000020E6100000A4AA09A2EE0334408E23D6E253104640	Na poljanama Maljen	Maljen, Serbia	\N
114	0	0101000020E6100000A9DE1AD82A313440C5E6E3DA50114640	Dobra voda	Suvobor, Serbia	\N
115	0	0101000020E61000007250C24CDBFF2E402D095053CBC64640	Ivanova hiža	Karlovac town environment, Karlovačka, Croatia	\N
116	0	0101000020E6100000C6DCB5847CC02F40C746205ED7EB4640	Glavica	Medvednica, City of Zagreb, Croatia	\N
117	0	0101000020E6100000FFEC478AC8B83040D3F6AFAC34BD4540	Trpošnjik	Mosor, Splitsko-dalmatinska, Croatia	\N
118	0	0101000020E6100000C217265305932D40C4CE143AAFA54640	Bitorajka	Bitoraj, Primorsko-goranska, Croatia	\N
119	0	0101000020E6100000AB09A2EE0360304006D847A7AE084640	Zlatko Prgin	Dinara, Šibensko-kninska, Croatia	\N
120	0	0101000020E6100000D3872EA86F492E405C8FC2F528444640	Prpa	Velebit, Ličko-senjska, Croatia	\N
121	0	0101000020E6100000787FBC57AD5C2E408BFD65F7E43D4640	Ždrilo	Velebit, Ličko-senjska, Croatia	\N
122	0	0101000020E610000086032159C0F42D40B21188D7F59B4640	Miroslav Hirtz	Velika Kapela, Primorsko-goranska, Croatia	\N
123	0	0101000020E6100000A31EA2D11DAC3140462575029AC04640	Jezerce	Papuk, Požeško-slavonska, Croatia	\N
124	0	0101000020E61000003EE8D9ACFA4C2F405F0CE544BBE24640	Ivica Sudnik	Samoborska gora, Zagrebačka, Croatia	\N
125	0	0101000020E6100000AD3BCC4D8A7D2840CBDF185D39124640		61 Via Aristotele, Benedetti terme, Italy	\N
126	0	0101000020E6100000AF5E454607602340EDF2AD0FEB6B4440		1 Strada Biccari, Quarto Fabiana a mare, Italy	\N
127	0	0101000020E610000050BA3EBD63AA2840D5DBB0B7DE294640		0 Borgo Zabedeo, Polese lido, Italy	\N
128	0	0101000020E6100000E7204322C8042640F6AEE6A507F54540		2 Borgo Viti, Lorusso ligure, Italy	\N
129	0	0101000020E61000009F11B6E919B02140ABAC12D154364640		63 Contrada Brunilde, Quarto Serafina, Italy	\N
130	0	0101000020E61000009EBFBFF7ED2224402DAAEA8ABEE84640		666 Rotonda Marelli, Settimo Euridice ligure, Italy	\N
131	0	0101000020E6100000FF209221C76E274017844DF8002D4640		4 Borgo Di Gennaro, Settimo Venera umbro, Italy	\N
132	0	0101000020E6100000C2B28817FA8E2340D5809C8B1AB04640		709 Strada Rufina, Crespignano lido, Italy	\N
133	0	0101000020E6100000107BFC3960762540600A6A53D0274740		879 Rotonda Argo, San Annamaria lido, Italy	\N
134	0	0101000020E6100000CF5AC0BAE0462B40B9ED314745E34640		2 Incrocio Doda, Bruschi calabro, Italy	\N
135	0	0101000020E610000048B42E7FCFC525403379B93E620B4740		14 Contrada Ledda, San Amando, Italy	\N
136	0	0101000020E6100000E066F16261B42A4084E85AC52CF04640		2 Borgo Privitera, Borgo Ginevra, Italy	\N
137	0	0101000020E610000021263CFC90E62840C604EBEEF0074640		16 Via Taziano, Borgo Antimo del friuli, Italy	\N
138	0	0101000020E6100000CFB81567B161274070CFF3A78DA74640		6 Piazza Gaglioffo, Giovanni umbro, Italy	\N
139	0	0101000020E6100000C1F979F8D76F224054F0CAE48AB04640		81 Rotonda Pio, Quarto Callisto salentino, Italy	\N
140	0	0101000020E61000008248D0A975782B40741200D2EDC94640		0 Incrocio Natalia, Settimo Amone, Italy	\N
141	0	0101000020E6100000918B208436172940630E828E564E4540		799 Strada Biagetti, Nicolini salentino, Italy	\N
142	0	0101000020E610000023484A1F5F572240D37CDF09072C4640		7 Piazza Calligaris, San Leonzio del friuli, Italy	\N
143	0	0101000020E6100000A09339F130542140F7DBE8ADCB384740		4 Piazza Elisabetta, Di Marino lido, Italy	\N
144	0	0101000020E6100000068A0E37967A2540DB1FDE29D3664540		4 Via Sviturno, Gatto laziale, Italy	\N
145	0	0101000020E6100000CF59B09EA4CE2640F18288D4B4434740		248 Rotonda Nobili, San Ermenegarda calabro, Italy	\N
146	0	0101000020E6100000C153C8957A5A26407541D8840FE14640		589 Rotonda Placida, Fichera sardo, Italy	\N
147	0	0101000020E61000008577B988EF302140BAD3426E2B3D4740		53 Strada Latini, San Ombretta umbro, Italy	\N
148	0	0101000020E6100000589643E6259E2540B49487E013DD4540		84 Rotonda Sapiente, Miceli nell'emilia, Italy	\N
149	0	0101000020E6100000249E4720B9702840B1F84D61A5124640		441 Strada Morra, Malagoli veneto, Italy	\N
150	0	0101000020E61000008B89CDC7B55926407EB4EED57D084740		130 Via Calpurnia, Settimo Grazia, Italy	\N
151	0	0101000020E6100000D8B969334EEB27402CF8C84164804540		8 Via Cipolletta, Quarto Aleandro a mare, Italy	\N
152	0	0101000020E610000061D394AEAAD4204012A6835039FC4640		07 Piazza Anastasia, San Flora, Italy	\N
153	0	0101000020E6100000B53C6AA741AC27408F0134A550B84640		16 Rotonda Palladio, Luzzi salentino, Italy	\N
154	0	0101000020E6100000F78CE9AE91D52240ED48F59D5FE54640		685 Strada Catarsi, Carlotti terme, Italy	\N
155	0	0101000020E6100000626DE75663902B4097FA1E9A1ED44640		22 Contrada Ruberto, Venturelli calabro, Italy	\N
156	0	0101000020E6100000FFF9C78C011B2640DD706946501E4740		18 Borgo Catarsi, Quarto Ascanio, Italy	\N
157	0	0101000020E61000009C363EEEB67E2740BC2363B5F9BA4640		4 Via D'Amico, Quarto Anita, Italy	\N
158	0	0101000020E61000008A9466F3387C1E402B31CF4A5AE74640		3 Piazza Ataleo, Ranucci veneto, Italy	\N
159	0	0101000020E6100000F22895F084D22A404082870E26ED4440		54 Incrocio Bernardi, San Emmerico terme, Italy	\N
160	0	0101000020E61000007E1D386744712240C878399105CC4640		5 Strada Spiga, Erardo umbro, Italy	\N
161	0	0101000020E610000020D84C1993812240A475AFEEB30D4740		0 Via Liberata, Priscilla umbro, Italy	\N
162	0	0101000020E6100000242136FD7E2E26406E2AF7A7F91A4740		1 Piazza Beretta, Borgo Ventura, Italy	\N
163	0	0101000020E6100000485E8C37E8B927408860C1A2C7CA4640		116 Contrada Agostina, Niceto a mare, Italy	\N
164	0	0101000020E61000005E961BB1BB751E407379BD4571EF4640		085 Borgo Berardi, Rocca sardo, Italy	\N
165	0	0101000020E6100000BE2ABC708CED2340366964A1E7DD4640		3 Borgo Giordano, Colombano terme, Italy	\N
166	0	0101000020E610000053B4722F302B2540E4DC26DC2B4D4740		60 Incrocio Bernabei, Borgo Emilia laziale, Italy	\N
167	0	0101000020E61000009A97C3EE3B32254052B241CB5F574640		106 Piazza Tallone, Filice sardo, Italy	\N
168	0	0101000020E6100000622D3E05C0782840F70BD17C29DE4640		06 Incrocio Torrisi, Bonomi lido, Italy	\N
169	0	0101000020E6100000B05758703F782440773A4668BAB84640		674 Via Boni, Cozzolino terme, Italy	\N
170	0	0101000020E610000011D20957F63B2640E6B8AEF3CA084740		494 Borgo Maggio, Catena lido, Italy	\N
171	0	0101000020E61000004704E3E0D2692C408514F2F741A74640		0 Piazza Costanza, Fabio nell'emilia, Italy	\N
172	0	0101000020E61000002F0ACC54D2C8264038FE9F1E36CA4640		1 Borgo Novello, Borgo Mennone, Italy	\N
173	0	0101000020E610000046E80C31035E29405A46EA3D95E54640		31 Piazza Patriarca, Belotti del friuli, Italy	\N
174	0	0101000020E6100000E4F90CA8376B2340ABA3F496BC5E4440		73 Piazza Romano, Teodoto ligure, Italy	\N
175	0	0101000020E6100000967DB2BD71ED26406F7319EDA7C14640		440 Via Francesconi, Morabito lido, Italy	\N
176	0	0101000020E6100000FC68DDABFB5427401073EE1B04334740		1 Contrada Urso, Settimo Adria, Italy	\N
177	0	0101000020E610000069965F611C5B2540B52792F991CA4540		277 Strada Cremona, Castellani nell'emilia, Italy	\N
178	0	0101000020E6100000B4C6455ACF692740D8C523A765B04640		0 Strada Edda, Quarto Emiliano terme, Italy	\N
179	0	0101000020E61000003B843B61D3CC1E40935742D202D44640		7 Borgo Ischirione, Cozzolino ligure, Italy	\N
180	0	0101000020E6100000C03FA54A9455284094347F4C6BE54640		1 Rotonda Davide, Borgo Basileo sardo, Italy	\N
181	0	0101000020E610000003FBF900EEEB1E40FA6184F068EE4640		3 Rotonda Terenzio, San Gerino terme, Italy	\N
182	0	0101000020E610000007681140209E2640B177352F3D9D4640		9 Via Geronzio, Gustavo sardo, Italy	\N
183	0	0101000020E6100000525F96766AFE23402A7C6C81F3EE4640		52 Via Alessia, Loretta veneto, Italy	\N
184	0	0101000020E61000007319EDA7B5EF1E400B1060EC18EC4640		771 Incrocio Cimmino, San Leopoldo ligure, Italy	\N
185	0	0101000020E6100000F86B578DCA1A284015E06014A9B14640		3 Incrocio Pica, Delfina lido, Italy	\N
186	0	0101000020E6100000D634947FD2A12740811A081390584540		35 Strada Cornelia, Clara del friuli, Italy	\N
187	0	0101000020E61000009D63E53C08EA2640B7FB0BF3D4DC4540		35 Contrada Rosamunda, Settimo Gallicano, Italy	\N
188	0	0101000020E6100000EA0E18DAEF9B2B40948444DAC6764640		8 Rotonda Milella, Borgo Lieto, Italy	\N
189	0	0101000020E610000014BCD7FFEFC62640BA66F2CD36DE4640		88 Contrada Verulo, Quarto Vinebaldo lido, Italy	\N
190	0	0101000020E610000009168733BFBE27405D4E098849354540		1 Piazza Tonini, Quarto Severino salentino, Italy	\N
191	0	0101000020E6100000462AE7E6763A2940ABB8CC446CE14440		76 Piazza Papini, San Bino, Italy	\N
192	0	0101000020E610000075EED176A7F62640A7F97486F3B24640		0 Borgo Filice, Baldovino salentino, Italy	\N
193	0	0101000020E6100000F9A23D5E48F727405789C3E3ECE04640		92 Incrocio Fiorentini, Ulfo laziale, Italy	\N
194	0	0101000020E6100000731A587D64FD294065FED13769E64540		328 Via Salvatore, Sesto Gerolamo, Italy	\N
195	0	0101000020E6100000ABC5F18D322421407D1FB3582FFA4640		51 Incrocio Fusco, Ulfo calabro, Italy	\N
196	0	0101000020E610000035D252793B0228403A79ECC26AEA4640		15 Contrada Criscenti, Sesto Siro, Italy	\N
197	0	0101000020E6100000DD730580CFD02640F16261889CD44640		1 Borgo D'Ippolito, Valentino nell'emilia, Italy	\N
198	0	0101000020E61000006531564046E12040530E1C8645E74640		7 Borgo Claudia, Sesto Noemi terme, Italy	\N
199	0	0101000020E610000026B8A2DE9D5E2740311A434AFDDC4640		835 Piazza De Sanctis, Settimo Sabele, Italy	\N
200	0	0101000020E61000000A5BFD22B27524407121EA99B95B4640		032 Contrada Ansaldo, Ilaria a mare, Italy	\N
201	0	0101000020E6100000C132DBBA40CE2240D0EFFB372F274740		271 Incrocio Rea, Settimo Teodosio calabro, Italy	\N
202	0	0101000020E6100000CA558737C6B91F40EB79ED88F9BD4640		1 Rotonda Proserpina, Tufano sardo, Italy	\N
203	0	0101000020E61000006AEE320DD4F324401D098F9147B14640		285 Rotonda Lorusso, Settimo Ladislao, Italy	\N
204	0	0101000020E610000044053D8A291B2140F0FACC599F5A4440		73 Strada Aleramo, Neopolo a mare, Italy	\N
205	0	0101000020E61000002B1D07B9E6212040F08C11E4FBF04640		600 Rotonda Praticò, Quarto Apuleio a mare, Italy	\N
206	0	0101000020E61000007BEDE3B21BB727403464E190B2DD4640		84 Contrada Malatesta, Scrofani ligure, Italy	\N
207	0	0101000020E6100000D8E9ACBB1EE91F40A0A932E774D04640		402 Via Audace, Borgo Albina sardo, Italy	\N
208	0	0101000020E61000009C8136DEC21B294063731FCA61894540		9 Piazza Loredana, Criscenti terme, Italy	\N
209	0	0101000020E6100000E3B08FA91680204076A0F3BF01E94640		184 Borgo Ombretta, Borrelli a mare, Italy	\N
210	0	0101000020E6100000EE6EAF16E9832340C6F0225D7DCC4640		971 Via Lucidi, Borgo Noemi, Italy	\N
211	0	0101000020E6100000D81D41E037B02140C2F1214D61C54440		089 Strada Albino, Quarto Giliola, Italy	\N
212	0	0101000020E6100000A807BB174E80284061BC8B9C2AD94640		00 Via Socrate, Borgo Gedeone sardo, Italy	\N
213	0	0101000020E6100000FD18CE9085A322406C9CA80073DB4640		7 Rotonda Cozzani, Settimo Sarbello calabro, Italy	\N
214	0	0101000020E6100000E39F635122672540E113A1C7DEDE4640		5 Piazza Guarino, Carola salentino, Italy	\N
215	0	0101000020E610000098231A93B47928409916500361674640		660 Via Grato, Settimo Tibaldo, Italy	\N
216	0	0101000020E6100000ABBCD3539A032740A544B7031AEF4640		25 Contrada Telesca, Settimo Rosario veneto, Italy	\N
217	0	0101000020E61000001E424B0D239B2440D8D1DD1A7DA04640		514 Contrada Antonacci, Grieco a mare, Italy	\N
218	0	0101000020E6100000CF2CAE96E0891F405EB642FDD3234640		366 Borgo Danio, Borgo Galdino laziale, Italy	\N
219	0	0101000020E6100000D7BDBACF96BC254007205AD020C34640		25 Strada Cerrato, Ubertino sardo, Italy	\N
220	0	0101000020E6100000C96BCABA24832740A97E4A3A6FE54640		311 Rotonda Tolomeo, Settimo Degna, Italy	\N
221	0	0101000020E6100000A8DAB80F8AC32940DF67017F9D1A4540		39 Rotonda D'Urso, Elpidio umbro, Italy	\N
222	0	0101000020E6100000C272DFC556972640A4271BC528D24640		4 Contrada Natalia, Algiso sardo, Italy	\N
223	0	0101000020E61000005F306E5974411E40EC3F21F1E13A4740		47 Borgo Zappia, Settimo Ascanio veneto, Italy	\N
224	0	0101000020E61000006C109CE9142628401760C4E347124740		1 Rotonda Gianmaria, Archimede salentino, Italy	\N
225	0	0101000020E610000044EC0214D9FD284012AC600AC5EE4440		120 Via Cristoforo Colombo, Roma, Italy	\N
226	0	0101000020E6100000B0FECF61BEF827406DFD99E6C2F24640		32 Contrada Miotto, Valerio umbro, Italy	\N
227	0	0101000020E6100000EBB76576CCAF26407B8FE9BFBD424640		911 Incrocio Deiana, Mancino del friuli, Italy	\N
228	0	0101000020E6100000D6479682247220407379BD4571084740		515 Via Denti, Aiello a mare, Italy	\N
229	0	0101000020E610000097900F7A36872040AB251DE560074740		7 Rotonda Pacini, Ramella salentino, Italy	\N
230	0	0101000020E61000000DABD3DC65C22740D32F116F9DE34640		7 Contrada Carponio, Sesto Averardo sardo, Italy	\N
231	0	0101000020E61000009FEE97AA0FCF27402834FF9E0E024740		8 Piazza Allegretti, Borgo Aida, Italy	\N
232	0	0101000020E6100000E417B90265622C40EFC0A50815E24440		9 Strada Agrippa, Scala calabro, Italy	\N
233	0	0101000020E6100000B2463D44A37B2540F3C011EEDF764540		6 Via Venezia, Sandra ligure, Italy	\N
234	0	0101000020E6100000B6B0B84956A326409DC2A5BE87334740		328 Borgo Caselli, Girardi sardo, Italy	\N
235	0	0101000020E6100000D56C2FB319AD2840823C16365EC04640		5 Via Osvaldo, San Ponziano, Italy	\N
236	0	0101000020E610000076583C5002EE1E40E0CCF9731BE14640		6 Via Sannino, Quarto Orlando umbro, Italy	\N
237	0	0101000020E6100000470EC7A98CC52840B6A73F564BE04640		5 Rotonda Emiliana, Carlini nell'emilia, Italy	\N
238	0	0101000020E61000004DC00A4B97B91F4005C1E3DBBBF84540		76 Incrocio Celso, San Leonia veneto, Italy	\N
239	0	0101000020E610000059EB7A585E182740106D1162780E4640		150 Piazza Nicol�, San Godiva, Italy	\N
240	0	0101000020E610000051D9B0A6B2581F4089B7CEBF5DE14640		94 Strada Pellegrino, Carminati terme, Italy	\N
241	0	0101000020E6100000AD7603BB504F27406049A8CFC4374640		448 Rotonda Tomassoni, Omar laziale, Italy	\N
242	0	0101000020E61000004692C5A28EF72640D32934B511794640		2 Incrocio Coniglio, Sesto Luisa, Italy	\N
243	0	0101000020E6100000068B790C45182740C3CB1D47BD774640		74 Piazza Renna, Settimo Eligio, Italy	\N
244	0	0101000020E61000005CC0159A35C620401880A1A245F44640		78 Contrada Raffa, Quarto Liberto laziale, Italy	\N
245	0	0101000020E6100000FA2D9512DD7227409453967C47234640		784 Via Chiara, San Abdone lido, Italy	\N
246	0	0101000020E61000008ECD8E54DFA12B403562C1583A2D4540		702 Rotonda Bianchetti, Carlini ligure, Italy	\N
247	0	0101000020E610000020651FBF127F254034C06092257F4640		69 Strada Clemente, Settimo Urbano terme, Italy	\N
248	0	0101000020E610000064BB31F3D36E22404F401361C3C24640		77 Via Gualtiero, Lecca calabro, Italy	\N
249	0	0101000020E6100000D160AEA0C47E2240E41824D813C04640		79 Strada Vindonio, San Athos, Italy	\N
250	0	0101000020E61000006FD8B628B3B91E40086465EA64D64640		18 Rotonda Venustiano, Ermenegarda ligure, Italy	\N
251	0	0101000020E610000016CDB9CAC93E2140BC0E8B074A744640		578 Rotonda Sabatini, Sechi laziale, Italy	\N
252	0	0101000020E6100000B4064A65E54A274026DAFA8E86E14640		8 Via Cuzia, Damiana ligure, Italy	\N
253	0	0101000020E61000000736F80CF26822405273034F6B9C4640		11 Incrocio Favara, Letizia del friuli, Italy	\N
254	0	0101000020E6100000DF6124C511412140D11CFE3FF3744640		6 Borgo Petrelli, Settimo Gondulfo lido, Italy	\N
255	0	0101000020E610000077ED77CD50412140CB243493B9744640		016 Piazza Ascione, Sanfilippo nell'emilia, Italy	\N
256	0	0101000020E61000002E008DD2A5032D406B5CA4F55C204540		40 Piazza Marcella, Settimo Licia, Italy	\N
257	0	0101000020E61000004ED367075C6F1F403A57941282D64640		6 Rotonda Pedone, Settimo Sisto, Italy	\N
258	0	0101000020E61000006405BF0D316E1F409F07D22060D24640		36 Borgo Mannino, Carlini terme, Italy	\N
259	0	0101000020E61000006F4BE482334C2740A928A8F287304640		468 Piazza Romeo, Borgo Pierangelo terme, Italy	\N
260	0	0101000020E61000005BC52CC59F522B40DB68A5B50EFA4640		326 Borgo Mele, Loriana sardo, Italy	\N
261	0	0101000020E61000000D5F155E383A21402BCC310F4F724640		46 Borgo Triolo, Settimo Lea lido, Italy	\N
262	0	0101000020E6100000E04158326C5D2140821C9430D3704640		303 Rotonda Capizzi, Vidone laziale, Italy	\N
263	0	0101000020E6100000C1F979F8D7071F404EFA319C21CD4640		4 Incrocio Ardito, Sesto Ponziano, Italy	\N
264	0	0101000020E61000000C97B0917F3921404C9C267D6B734640		205 Via Fulvia, Bardomiano ligure, Italy	\N
265	0	0101000020E6100000EFA18ED838742840FA10AF46D1764640		361 Contrada Oderico, Libero salentino, Italy	\N
266	0	0101000020E6100000B032BF3F4AC11E4019CD25B094D54640		5 Strada Sabino, Quarto Loretta salentino, Italy	\N
267	0	0101000020E610000039FBB9579CA829401D9C3EF152FC4440		068 Borgo Valerio, Borgo Telica, Italy	\N
268	0	0101000020E6100000440E5BC4C1F71E4071033E3F8C7E4640		08 Rotonda Felice, Amalia veneto, Italy	\N
269	0	0101000020E6100000C69EE2DD36D82B400B8AD5D5D3E84640		058 Piazza Anna, Settimo Rossana a mare, Italy	\N
270	0	0101000020E6100000888961E2EA131F4040E7244A31CD4640		1 Strada Aleandro, Sesto Benvenuto, Italy	\N
271	0	0101000020E6100000E8F86871C6D81E40E7EBE86E8DD84640		07 Borgo Aloisio, Sesto Luna veneto, Italy	\N
272	0	0101000020E610000024BF34FBF2301F405FCE6C57E8CB4640		1 Rotonda Catellani, Colombo a mare, Italy	\N
273	0	0101000020E61000000242902859C7254075988AE832F64540		746 Contrada Masciandaro, Nicezio umbro, Italy	\N
274	0	0101000020E61000005CEC5113D8AF1E405650ACAE9ED84640		920 Strada Pariggiano, Ione calabro, Italy	\N
275	0	0101000020E6100000A6A84423E9E41E40BF20336145E14640		60 Via Carolina, Ghita salentino, Italy	\N
276	0	0101000020E6100000F07A7AB6582B2740B1ADFAB726234640		234 Rotonda Valentina, Parmenio nell'emilia, Italy	\N
277	0	0101000020E61000002252D32EA6C91E404392B47636E94640		68 Rotonda Adelaide, Settimo Orsolina, Italy	\N
278	0	0101000020E61000000BC336983C2C27405262D7F676234640		727 Rotonda Rosalinda, Catalano nell'emilia, Italy	\N
279	0	0101000020E61000004F722C94F1E8264075F2D885D5064740		49 Borgo Venusto, San Elsa, Italy	\N
280	0	0101000020E61000005C8BBBE6FA8F26407A4F8AFB343B4740		693 Incrocio Eloisa, Borgo Esterina umbro, Italy	\N
281	0	0101000020E61000007B9054956C0B28407BB5487FD4974640		1 Incrocio Salemme, Quarto Diamante terme, Italy	\N
282	0	0101000020E6100000BE52F1DA00B72B40D21D1F8887274540		563 Piazza Bianc, Sosteneo del friuli, Italy	\N
283	0	0101000020E6100000A732D6485C052740FDD8243FE2394640		260 Piazza Innocenza, Sesto Galileo umbro, Italy	\N
284	0	0101000020E6100000AD94545C0B4D2240EE885462E8B94640		317 Contrada Federico, Settimo Augusto, Italy	\N
285	0	0101000020E6100000333097F9B3641F40983BE93356DF4640		5 Contrada Geronzio, Gaudenzia nell'emilia, Italy	\N
286	0	0101000020E61000002B8AB2124E762740C1EA234B41314640		46 Incrocio Neoterio, Salvatori a mare, Italy	\N
287	0	0101000020E6100000905F8951219022403E5695229E864640		65 Borgo Orietta, Pellegrino a mare, Italy	\N
288	0	0101000020E610000096C1621E43E92640E580B80611044740		04 Borgo Maggiani, Indelicato terme, Italy	\N
289	0	0101000020E61000007090B52B99842B40E461461DC27E4640		423 Piazza Sanna, Silvano salentino, Italy	\N
290	0	0101000020E610000084B1CFAD219A26406BDECC43010E4740		7 Contrada Auberto, Venera ligure, Italy	\N
291	0	0101000020E6100000CC1D47BDF13F2240A5A31CCC26824640		6 Piazza Sansone, Gabriella veneto, Italy	\N
292	0	0101000020E610000048E58123DCFF26407F7E294D94084740		104 Rotonda Carollo, San Coriolano, Italy	\N
293	0	0101000020E61000006B5A73918C1625409D7C1FB358204740		802 Incrocio Raneri, Marta terme, Italy	\N
294	0	0101000020E6100000204F818241C01E40068B1E53D2D34640		33 Contrada Manicone, Borgo Arabella, Italy	\N
295	0	0101000020E6100000C0CBB161F2931E40B859BC5818D34640		487 Via Abbrescia, Quarto Astrid, Italy	\N
296	0	0101000020E610000070DA4246F68B2C40A79C8AAFD1364740		612 Rotonda Lamacchia, Quarto Vulmaro, Italy	\N
297	0	0101000020E6100000A9D5FC9D92882C4058FBE02131384740		90 Via Bertani, Lucia veneto, Italy	\N
298	0	0101000020E6100000F74A0FF91DD1274067DC8AB3D8024740		0 Contrada Salom�, Borgo Vittorio, Italy	\N
299	0	0101000020E61000004221A7542EE52C40A39BB3F457164740		8 Borgo Giuliana, Borgo Priamo, Italy	\N
300	0	0101000020E6100000D3D7987C586422408E7CB9AA47A84640		8 Contrada Manetti, Bacco a mare, Italy	\N
301	0	0101000020E610000008CDAE7B2B8A2440E646EC6EF9664540		8 Via Patruno, Flaviano nell'emilia, Italy	\N
302	0	0101000020E610000081EB8A19E1CD26408A4457D8C2194640		699 Strada Noto, Piera laziale, Italy	\N
303	0	0101000020E6100000B4CA4C69FD5122404A95CDC1D8134540		530 Borgo Romana, San Attilio, Italy	\N
304	0	0101000020E6100000E4BD6A65C267264033260EEA6CBC4640		4 Piazza Vodingo, Sesto Fulberto calabro, Italy	\N
305	0	0101000020E610000071C0536DDCD325406C312E0BDCB14640		16 Incrocio Glenda, Caggiano calabro, Italy	\N
306	0	0101000020E6100000B368F0ADFEEA2540D42AFA4333B54640		345 Incrocio Cipriani, Quarto Alfonso lido, Italy	\N
307	0	0101000020E61000005B2CA0AB08EA2740DE454E15422C4740		79 Contrada Palmieri, Loffredo lido, Italy	\N
308	0	0101000020E61000009703988D2933274052EC0D63778A4640		3 Via Monte Grappa, Lendinara, Italy	\N
309	0	0101000020E61000005389FC44AF582940E7D2AEF83CCA4640		413 Incrocio Felicia, Ludovico terme, Italy	\N
310	0	0101000020E61000000236D6B441802C4025D5D237C46B4440		44 Via dei Greci, Napoli, Italy	\N
311	0	0101000020E610000073220BE24DBC2740A1E4C40DAE2D4740		0 Piazza Luce, Liberatore veneto, Italy	\N
312	0	0101000020E610000046B1DCD26AB02540072E45A808074740		9 Contrada Democrito, Settimo Federica, Italy	\N
313	0	0101000020E6100000B17E7DBE77992240C0F858B043504440		104 Strada Soccorsi, Arcadio umbro, Italy	\N
314	0	0101000020E6100000EC3026FDBD2C27403B6AF1CE46024740		58 Rotonda De Col, Zenone veneto, Italy	\N
315	0	0101000020E6100000996EC8F5A5712B40C576F700DD3C4740		041 Piazza Urso, Settimo Vincenza nell'emilia, Italy	\N
316	0	0101000020E6100000AA5DB818A8F922406B0DA5F622154440		42 Rotonda Teodolinda, Fulvia laziale, Italy	\N
317	0	0101000020E610000034B10AE58E682040CFC941BFA57A4440		6 Contrada Claudio, Sesto Euseo, Italy	\N
318	0	0101000020E610000008D04AB5AABC2140800F5EBBB4374640		88 Borgo Gentile, Davino lido, Italy	\N
319	0	0101000020E6100000B35DA10F967D2D408F49905BDD324740		0 Incrocio Durante, Sesto Donatello, Italy	\N
320	0	0101000020E6100000852348A5D8C12840842458C114E24540		997 Piazza Neri, Cara laziale, Italy	\N
321	0	0101000020E6100000BF5076E915252B40EA398EC4703B4740		04 Strada Ercolano, Borgo Atanasio laziale, Italy	\N
322	0	0101000020E6100000B956D6917EDA2B40DF707A72A8054540		476 Borgo Cecchetti, Silvana ligure, Italy	\N
323	0	0101000020E61000007889A02067742340DE2A3EF493CE4640		38 Piazza Borrelli, Distefano ligure, Italy	\N
324	0	0101000020E6100000235399BDC70C254059CFFF6101ED4540		5 Borgo Zuliani, Raide veneto, Italy	\N
325	0	0101000020E610000027F33405D7392640E75E16C90D2C4740		594 Strada Beniamino, Sesto Amelia veneto, Italy	\N
326	0	0101000020E61000001C15EE4BECAC2A40DD11A9C4D02E4540		840 Contrada Fermiano, Betta veneto, Italy	\N
327	0	0101000020E6100000C1D4850E70E722408E6D63FDB0594540		767 Contrada Vanna, Alessio nell'emilia, Italy	\N
328	0	0101000020E6100000E5BA849E28A826407E7D63BE723F4640		938 Rotonda Liberati, Lidia salentino, Italy	\N
329	0	0101000020E610000055B1E72109D11F4018CFA0A17FB14640		81 Strada Vivaldo, Settimo Eufemia terme, Italy	\N
330	0	0101000020E61000007DEFCA89D18E2640DB0B16985F354540		71 Incrocio Erminio, Beniamina nell'emilia, Italy	\N
331	0	0101000020E6100000BB6D9516E41D244002678412C1A94640		748 Piazza Gaia, San Nadia umbro, Italy	\N
332	0	0101000020E6100000F67AF7C77BB52740FA449E245D4F4740		71 Via Manicone, San Lapo salentino, Italy	\N
333	0	0101000020E6100000DE68119BD960294098E8E225EEFB4440		9 Strada Privitera, Settimo Leda sardo, Italy	\N
334	0	0101000020E61000007ED3AA4CE7E52340C9CC052E8F254640		2 Strada Palumbo, Settimo Lauriano, Italy	\N
335	0	0101000020E61000004EDF217B732E2240D3F4D901D7214540		25 Rotonda Novella, Sesto Natalina salentino, Italy	\N
336	0	0101000020E61000004377A45588CA264008951348E43C4640		984 Rotonda Molinaro, Settimo Venceslao, Italy	\N
337	0	0101000020E610000072593B40E6692840252D4B2A09EC4440		30 Via Scorza, Viviano laziale, Italy	\N
338	0	0101000020E610000023E7B3F281D7214072C8618B38C84640		336 Contrada Schillaci, Babini del friuli, Italy	\N
339	0	0101000020E61000000C84AE8E2D752740A4897780272E4640		347 Via Rosario, Quarto Baldassarre ligure, Italy	\N
340	0	0101000020E6100000A63C5F58A33326408C811A63CCED4540		485 Strada Monica, Settimo Sidonia, Italy	\N
341	0	0101000020E6100000CC0C1B65FD922840A42C8DA905C14640		26 Strada Cammarata, Settimo Galdino, Italy	\N
342	0	0101000020E61000007332CC64933F2740FEDDF1DC31254640		966 Via Demetrio, Del Vecchio a mare, Italy	\N
343	0	0101000020E610000032D758784D462240743F4C67CC0B4740		5 Piazza Petrelli, Fiorenza ligure, Italy	\N
344	0	0101000020E61000002B16BF29ACC825401AB6775787864540		2 Borgo Lavecchia, San Raimondo nell'emilia, Italy	\N
345	0	0101000020E6100000FE00B562C9B62A4032CFA51364D94440		6 Rotonda Santo, San Apollinare del friuli, Italy	\N
346	0	0101000020E61000002AD890C9F3362640A3C629DFD80F4640		38 Rotonda Mosca, Molinari nell'emilia, Italy	\N
347	0	0101000020E610000098F0958AD7422540F3DD52735E994640		80 Piazza Damico, Silenzi ligure, Italy	\N
348	0	0101000020E6100000451B36806D772640B99BF1C7FE074740		64 Rotonda Lotito, Settimo Severa ligure, Italy	\N
349	0	0101000020E61000008948A8740B9027402B7D321015F14540		534 Rotonda Nicotra, Iorio a mare, Italy	\N
350	0	0101000020E6100000484B8A3496612B40F1F44A5986DF4640		0 Via Manfredi, Giadero salentino, Italy	\N
351	0	0101000020E610000006240626DCE0264059631A97BBDC4640		3 Incrocio Rocco, Settimo Altea, Italy	\N
352	0	0101000020E61000001A62067470422640EF6BC94F4FBD4540		33 Incrocio Lugli, Quarto Silverio, Italy	\N
353	0	0101000020E6100000F0F1536694F425402F5D77A9C7134640		7 Contrada Boris, Clarenzio sardo, Italy	\N
354	0	0101000020E6100000A5DAA7E3317F2240E75E16C90DEF4640		9 Rotonda Barra, Quarto Cleo a mare, Italy	\N
355	0	0101000020E6100000D12E956D967D2C40126C5CFFAE6D4440		1 Rotonda Villa, Quarto Marilena laziale, Italy	\N
356	0	0101000020E6100000DD6CBDF0941F27409F515F3BBDDA4640		57 Borgo Giobbe, Sesto Augusto ligure, Italy	\N
357	0	0101000020E610000096EA025E66002640FA4E82ED16F44540		7 Borgo Flora, Sesto Calcedonio sardo, Italy	\N
358	0	0101000020E61000009DDE20B5E43C25407F83F6EAE39D4540		90 Borgo Florina, Loreto umbro, Italy	\N
359	0	0101000020E6100000016E162F168E2340861BF0F9614A4440		3 Contrada Piero, Ciotola ligure, Italy	\N
360	0	0101000020E61000009F32480BE1EA20405C8A50114CDA4640		9 Rotonda Viviana, Quarto Semiramide calabro, Italy	\N
361	0	0101000020E6100000618841052C422B400938DFE3A78E4640		331 Incrocio No�, Bozzi a mare, Italy	\N
362	0	0101000020E6100000160F94803D132140276BD44334E04640		4 Incrocio Berenice, Sesto Galeazzo nell'emilia, Italy	\N
363	0	0101000020E610000097A13BD22A4C25401A80B2CE9DD44540		20 Strada Mareta, Letizia terme, Italy	\N
364	0	0101000020E6100000AD904D4DDD3827405B632BC313B14540		334 Strada Ludano, Maida del friuli, Italy	\N
365	0	0101000020E610000071E82D1EDEEB2C405F93DA30AF824440		3 Incrocio Alfonso, Sesto Nostriano nell'emilia, Italy	\N
366	0	0101000020E6100000DA48C8F6109B1F40EE2AFFB5176E4640		622 Via Evelina, Sesto Ermes, Italy	\N
367	0	0101000020E61000004D028A4798F02740C38366D7BD264640		227 Strada Belli, Settimo Rosalinda calabro, Italy	\N
368	0	0101000020E6100000BCB77DEAB38A2C404EF04DD3676E4440		947 Piazza Boschi, Pozzi nell'emilia, Italy	\N
369	0	0101000020E6100000CBC80F4BB93126404793E6EA22FD4640		41 Strada Zani, Settimo Napoleone, Italy	\N
370	0	0101000020E6100000A68E9FD7E925284065677682A2C64640		02 Borgo Grimaldo, Narseo sardo, Italy	\N
371	0	0101000020E6100000407562C55F5D294091FC773359C24640		245 Incrocio Narciso, Ventimiglia salentino, Italy	\N
372	0	0101000020E6100000CF328B506C4D244070D63B37C8184640		55 Borgo Alboino, Borgo Doda, Italy	\N
373	0	0101000020E61000007E6E0D11DC1122409453967C47EB4640		5 Incrocio Di Domenico, Borgo Nicarete, Italy	\N
374	0	0101000020E610000043A44BA4D989204072A8DF85ADD34640		65 Piazza Daniele, San Ottone, Italy	\N
375	0	0101000020E61000004371C79BFC022C404AF5F81807254540		82 Borgo Papapietro, San Goffredo, Italy	\N
376	0	0101000020E61000009EA74B10BFA422400292FAFC41944440		72 Borgo Iginio, Modesto umbro, Italy	\N
377	0	0101000020E61000000D88B59D5B012C40CF70B9B024144540		71 Borgo Pozzi, Borgo Lea, Italy	\N
378	0	0101000020E610000059935D1F8CFE26407E6DA23B2D3B4640		48 Piazza Manno, Massa laziale, Italy	\N
379	0	0101000020E6100000D50451F7010829403B736AC2510D4640		8 Via Agnese, Sesto Euseo, Italy	\N
380	0	0101000020E6100000CD6152D735012740D65F6523C6394640		750 Via Martorana, Testa lido, Italy	\N
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hike_track_points ("userHikeId", index, "pointId", datetime) FROM stdin;
\.


--
-- Data for Name: user_hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes (id, "userId", "hikeId", "startedAt", "updatedAt", "finishedAt", "psTotalKms", "psHighestAltitude", "psAltitudeRange", "psTotalTimeMinutes", "psAverageSpeed", "psAverageVerticalAscentSpeed", "maxElapsedTime", "weatherNotified", "unfinishedNotified") FROM stdin;
\.


--
-- Data for Name: user_hikes_track_points_user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes_track_points_user_hike_track_points ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash", approved, preferences, "plannedHikes") FROM stdin;
2	$2b$10$bXD9tMphzRwDgnVjoYxaz.Q6aLFTEaoOjEnzE94/ZDW51dEH29S3y	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N	t	\N	\N
4	$2b$10$iQZyiE/dKVOSMWROgVDAcu4xFH6jNppv79Pafsw4y4qPuFsWKmkUO	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N	t	\N	\N
5	$2b$10$/JemWR3Z3VufEySRCiikbeWXCl0fNFnnKGdnnIDbp5XJlh4ry9fQa	Laura	Zurru	5	laura@emergency.it	\N	t	\N	t	\N	\N
1	$2b$10$9Qu9a8HUVJbRR3.0hzBa5./O2kKMucuHSG5KZx0rKXIWBKAS3n7iq	German	Gorodnev	0	german@hiker.it	\N	t	\N	t	\N	\N
3	$2b$10$q5KTpuIAcs5zcBtRSaSH0OYeMyUtThJhu9g7.WvwNsDUfoYkDcKHa	vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N	t	\N	\N
6	$2b$10$M.6Nv/.zgjCjrpvIX7k0buHVLE1kr8PqYVnpsXLusm3bZtBwk35FO	Francesco	Grande	1	francesco@friend.it	\N	t	\N	t	\N	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 5, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 108, true);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 256, true);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 380, true);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_hikes_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

