--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: insert_hike(integer, character varying, integer, character varying, character varying, character varying, character varying, character varying, numeric, numeric, integer, character varying, jsonb, jsonb, jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hike(user_id integer, title character varying, difficulty integer, gpx_path character varying, country character varying, region character varying, province character varying, city character varying, length numeric, ascent numeric, expected_time integer, description character varying, pictures jsonb, start_point jsonb, end_point jsonb, reference_points jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'name')::varchar,
            (ref->>'address')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $$;


--
-- Name: insert_hut(integer, double precision, double precision, integer, numeric, character varying, character varying, character varying, character varying, numeric, time without time zone, time without time zone, character varying, character varying, jsonb, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut(user_id integer, lat double precision, lon double precision, number_of_beds integer, price numeric, title character varying, address character varying, owner_name character varying, website character varying, elevation numeric, working_time_start time without time zone, working_time_end time without time zone, email character varying, phone_number character varying, pictures jsonb, description character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber",
      "pictures",
      "description"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number,
      pictures,
      description
    );
    END
    $$;


--
-- Name: insert_hut_worker(integer, character varying, character varying, character varying, character varying, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut_worker(hwid integer, email character varying, password character varying, first_name character varying, last_name character varying, role integer, hut_id integer, approved boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$
      DECLARE
        user_id integer;
      BEGIN
      INSERT INTO "public"."users" (
        "id",
        "email",
        "password",
        "firstName",
        "lastName",
        "role",
        "verified",
        "approved"
      ) VALUES(
        hwid, email, password, first_name, last_name, role, true, approved
      ) returning id into user_id;

      INSERT INTO "public"."hut-worker" (
        "userId",
        "hutId"
      ) VALUES ( user_id, hut_id);
      END
      $$;


--
-- Name: insert_parking_lot(integer, double precision, double precision, character varying, integer, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_parking_lot(user_id integer, lat double precision, lon double precision, name character varying, max_cars integer, address character varying, city character varying, country character varying, region character varying, province character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: code-hike; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."code-hike" (code, "userHikeId") FROM stdin;
\.


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
1	1	0	5
1	2	100000	6
1	3	1	3
1	4	2	3
2	5	0	5
2	6	100000	6
3	7	0	5
3	8	100000	6
4	9	0	5
4	10	100000	6
5	11	0	5
5	12	100000	6
6	13	0	5
6	14	100000	6
7	15	0	5
7	16	100000	6
8	17	0	5
8	18	100000	6
8	19	1	3
8	20	2	3
9	21	0	5
9	22	100000	6
10	23	0	5
10	24	100000	6
11	25	0	5
11	26	100000	6
12	27	0	5
12	28	100000	6
13	29	0	5
13	30	100000	6
14	31	0	5
14	32	100000	6
15	33	0	5
15	34	100000	6
16	35	0	5
16	36	100000	6
17	37	0	5
17	38	100000	6
18	39	0	5
18	40	100000	6
19	41	0	5
19	42	100000	6
20	43	0	5
20	44	100000	6
21	45	0	5
21	46	100000	6
22	47	0	5
22	48	100000	6
23	49	0	5
23	50	100000	6
23	51	1	3
23	52	2	3
24	53	0	5
24	54	100000	6
25	55	0	5
25	56	100000	6
26	57	0	5
26	58	100000	6
27	59	0	5
27	60	100000	6
28	61	0	5
28	62	100000	6
29	63	0	5
29	64	100000	6
30	65	0	5
30	66	100000	6
30	67	1	3
30	68	2	3
30	69	3	3
31	70	0	5
31	71	100000	6
32	72	0	5
32	73	100000	6
33	74	0	5
33	75	100000	6
34	76	0	5
34	77	100000	6
35	78	0	5
35	79	100000	6
36	80	0	5
36	81	100000	6
37	82	0	5
37	83	100000	6
38	84	0	5
38	85	100000	6
38	86	1	3
38	87	2	3
39	88	0	5
39	89	100000	6
40	90	0	5
40	91	100000	6
41	92	0	5
41	93	100000	6
42	94	0	5
42	95	100000	6
43	96	0	5
43	97	100000	6
44	98	0	5
44	99	100000	6
45	100	0	5
45	101	100000	6
46	102	0	5
46	103	100000	6
46	104	1	3
46	105	2	3
47	106	0	5
47	107	100000	6
48	108	0	5
48	109	100000	6
49	110	0	5
49	111	100000	6
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country, condition, cause, pictures, "weatherStatus", "weatherDescription") FROM stdin;
1	2	7.20	80	7.00	2	Amprimo	Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.	/static/gpx/Amprimo.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/3.jpg"]	0	
2	2	9.30	200	5.40	1	Anello Chateau Beaulard - Cotolivier - Vazon	Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.	/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx	0.00	Piemonte	Torino	Beaulard	Italia	0		["/static/images/2.jpg"]	0	
3	2	5387.07	150	955.10	1	borgata ruà a cima di crosa	Raggiungi la partenza del Sentiero per la Cima di Crosa impostando sul navigatore “Borgata Ruà – Becetto“.\n\nParcheggiata la macchina a Borgata Ruà (o se impossibilitati a trovare un parcheggio anche a Becetto, allungando di 10 minuti il giro), si prende il sentiero sulla sinistra, nei pressi di una cartina (INDICAZIONI CIMA DI CROSA).	/static/gpx/Borgata Ruà-Cima di Crosa (1).gpx	0.00	Piemonte	Cuneo	Sampeyre	Italia	0		["/static/images/46.jpg"]	0	
4	2	3622.32	130	865.20	2	Colle della Gianna da Pian della Regina	Colle della Gianna at an altitude of approximately 2530m connects the Po Valley to the Pellice Valley allowing you to reach the Barbara Lowrie refuge, an ideal base for multi-day crossings.\n\nIt is advisable to carefully consult the weather forecasts especially for these areas frequently subject to very thick fog.\n\nBeing at moderately high altitudes in spring there is the possibility of finding tongues of snow that could make the ascent more difficult.	/static/gpx/Colle Della Gianna (1).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/37.jpg"]	0	
5	2	3221.31	120	712.94	3	Hike Zicher	Lungo l’itinerario non è garantita la piena copertura telefonica\nIn periodo estivo, la parte finale può essere molto esposta al sole e richiedere fatica.\nIn condizioni di vento forte, è preferibile non proseguire\nE’ possibile sviluppare un itinerario ad anello scendendo dal versante nord della montagna in direzione Bocchetta Sant’Antonio (ma attenzione ad un passaggio su rocce, soprattutto se ghiacciate).	/static/gpx/Hike_Zicher (2).gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Craveggio	Italia	0		["/static/images/29.jpg"]	0	
6	2	15636.67	150	1366.80	2	Usseaux Altro	The flowering of Eriofori along the shores of the lake between July and August is interesting, making it very suggestive.	/static/gpx/Laghi_Albergian.gpx	0.00	Piemonte	Torino	Usseaux	Italia	0		["/static/images/40.jpg"]	0	
7	2	15636.67	150	1366.80	3	Usseaux Altro	Itinerario vario e panoramico, non presenta particolari difficoltà ma per la lunghezza, il dislivello, la mancanza di punti di appoggio e la necessità di una certa capacità di orientamento su sentieri non sempre evidenti (specialmente per la variante in discesa) è consigliato a escursionisti allenati e esperti.	/static/gpx/Laghi_Albergiani.gpx	0.00	Piemonte	Torino	Usseaux	Italia	0		["/static/images/42.jpg"]	0	
8	2	9.40	210	6.30	2	Lago Bianco	Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.\n\nLa diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.\n\nLa Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.\n\nSi può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.	/static/gpx/Lago Bianco.gpx	0.00	Auvergne-Rhone-Alpes	Savoia	Val-Cenis	Francia	0		["/static/images/1.jpg"]	0	
9	2	21358.83	170	1087.90	2	Lago dei 7 colori (lago gignoux)	Parcheggia a Claviere e dirigiti verso la strada comunale Valle Gimont che, dopo poco, si fa sterrata.\n\nLascia alla tua destra i cartelli che indicano il Lago Gignoux e prosegui risalendo le piste da sci.\n\nGiunto a Sagna Longa noterai che la zona è di interesse sciistico, infatti ci sono numerosi arrivi di seggiovia. Segui le indicazioni per Colle Bercia, attraversa una chiesetta, dei caseggiati in pietra e prosegui per il largo sentiero.\n\nL’intero percorso si sviluppa circondato dai bellissimi Monti della Luna ed è caratterizzato da una dolce e semicostante salita su terreno sterrato a tratti ghiaioso.\n\nSuperato il Colle Bercia continua sull’ampia carreggiata che ti conduce ad un valico nel quale noterai particolari conformazioni rocciose e una punta (Cima Saurel 2451 mt). Tieniti sul sentiero basso e supera il valico, che segna anche il confine con la Francia, dopo il quale troverai il lago immerso in una conca.	/static/gpx/Lago dei 7 colori (lago gignoux) (1).gpx	0.00	Piemonte	Torino	Claviere	Italia	0		["/static/images/51.jpg"]	0	
10	2	4024.73	120	810.90	2	Lago d'Afframont 1986 m	Una volta parcheggiata la macchina dirigiti verso il villaggio Albaron. Poco dopo i caseggiati ti troverai di fronte ad un impianto di risalita dismesso, a sinistra troverai un campetto da calcio, proprio dopo il campetto si intravedono i primi cartelli con le indicazioni per il Lago di Afframont. Il sentiero da seguire è il 213, ma lungo il tragitto troverai solo bandiere bianco/rosse e cartelli di legno che indicano la destinazione.\n\nSi sale l’ex pista da sci e ci si addentra nel bosco. Il primo tratto rimane ombreggiato, mentre inizia a farsi sentire la salita. Ad un certo punto ci si affianca ad un ruscello, il Rio di Afframont, che scorre sulla sinistra e si supera con facilità in prossimità dei caseggiati in pietra (attenzione nei periodi di pioggia perché potrebbe essere impraticabile).	/static/gpx/Lago di Afframont 1986 m.gpx	0.00	Piemonte	Torino	Balme	Italia	0		["/static/images/52.jpg"]	0	
11	2	7580.49	110	1049.26	2	Briccas da Borgata Brich 20/02/21	After leaving the car, we continue along the road, first paved and then dirt.\n\nIn case of little snow or high temperatures it is possible to cover the first 150m in altitude without snowshoes.\n\nAs soon as we hit the first snow, we put on our snowshoes and set off on a well-defined path that crosses a wood.\n\nAfter having left the last huts behind us, we turn right towards the North/East near a GTA trail sign painted on a boulder.\n\nFrom here, after the last bush, an enormous, very wide slope opens up before us which culminates right at our peak	/static/gpx/Monte Briccas da Brich (1).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/35.jpg"]	0	
12	2	11664.79	150	1472.80	3	Monte Ferra Con Marco e Daniel	Fondamentali i bastoncini specialmente nella discesa dal Monte Ferra al lago Reisassa.\n\nUnico punto di appoggio è il rifugio Melezè ad inizio itinerario (consigliamo di contattare direttamente la struttura per verificare giorni e orari di apertura)	/static/gpx/Monte Ferra (1).gpx	0.00	Piemonte	Cuneo	Cuneo	Italia	0		["/static/images/28.jpg"]	0	
13	2	6229.07	200	1024.76	2	Da Crissolo a Ghincia	The Path to Monte Granè is a suggestive walk with a splendid view of Monviso (3841 m) and Viso Mozzo (3019 m).\n\nLeave the car in the car park and continue to the left of the sports field where a splendid path immersed in the woods appears before us and after about 1.5 km you come to the dirt road which in summer leads to the Black Eagle refuge.\n\nContinuing on the latter and having reached the refuge, continue along the Crissolo slopes to the end of the ski-lift where, just above the Ghincia Pastour hut, we will find a statue of the Madonna to indicate the end of the path to Monte Granè.\n\nThe return takes place along the same route as the outward journey.	/static/gpx/Monte Granè (2).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/36.jpg"]	0	
14	2	6588.82	150	936.79	2	Montr Pigna da Prea	Posteggiata la macchina nel parcheggio sotto l’abitato di Prea ci dirigiamo lungo la strada asfaltata situata sotto il cimitero, lasciandocelo sulla destra.\n\nAppena incontriamo la prima neve possiamo allacciare le ciaspole e proseguire fino alla borgata di Sant’Anna di Prea. (Nei mesi invernali, con nevicate nella norma, la strada viene pulita fino al parcheggio quindi si può iniziare ad indossare le ciaspole fin da subito).\n\nSubito dopo il cartello, all’ingresso di Sant’Anna di Prea, sulla destra vi è un magnifico sentiero immerso nel bosco che permette di tagliare la borgata accorciando la salita di circa 1 km.\n\nIncrociando nuovamente la strada principale e percorrendo circa 3 km si giunge alla Baita Monte Pigna situata a metà degli impianti di Lurisia.	/static/gpx/Monte Pigna Da Prea (1).gpx	0.00	Piemonte	Cuneo	Roccaforte Mondovì	Italia	0		["/static/images/47.jpg"]	0	
15	2	10065.93	130	842.70	2	Pian della Regina - Laghi del Monviso	The excursion can start near the Po, parking the car in one of the many spaces available. Once you have crossed the stream, follow via Ruata.\n\nTo get your bearings in Crissolo, we suggest following the signs for "La Capanna" and ignoring the various detours on the left that follow the ski lifts. Before reaching the restaurant, you finally take the road, following the signs for Monte Tivoli.\n\nThe path climbs up into the wood (splendid during the autumn season) and crosses the Sbarme stream.	/static/gpx/Pian della Regina - Laghi del Monviso (1).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/32.jpg"]	0	
16	2	7281.87	120	504.40	2	Fenestrelle Escursionismo	Itinerario di medio sviluppo con ampio panorama verso la Val Chisone.\n\nAttenzione nella stagione invernale: la zona soggetta a valanghe in caso di abbondanti precipitazioni nevose, specialmente nella conca che precede il rifugio.\n\nInformarsi sempre sullo stato della neve presso i gestori del rifugio o l’ufficio turistico di Fenestrelle.	/static/gpx/Rif. Selleries.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/43.jpg"]	0	
17	2	4156.24	150	850.76	0	Rifugio Meira Garneri da Sampeyre	Lascia l’auto nel parcheggio della seggiovia di Sampeyre.\n\nLasciato il parcheggio saliamo subito a destra degli impianti di risalita, dove alcuni cartelli rossi ci segnalano il sentiero attraverso il bosco.\n\nPrendendo rapidamente quota, alla fine del primo tratto di boscoso, raggiungiamo la frazione Sodani dove possiamo osservare la bella chiesa affrescata.\n\nUsciti dalla borgata proseguiamo nuovamente lungo il sentiero circondati da larici, faggi, betulle e dopo alcune deviazione, sempre ben segnalate, usciamo in una splendida radura.\n\nSaliamo gli ultimi 200m a lato della pista o volendo possiamo proseguire più a destra incrociando la strada carrozzabile che nel periodo estivo porta al rifugio.	/static/gpx/Rifugio Meira Garneri da Sampeyre (1).gpx	0.00	Piemonte	Cuneo	Sampeyre	Italia	0		["/static/images/45.jpg"]	0	
18	2	4388.16	200	923.62	2	Sentiero per ROCCA PATANUA	Itinerario interamente rivolto a Sud che normalmente si libera dalla neve già a inizio primavera.\n\n(l’itinerario è stato svolto in periodo invernale, seguito scarsa e quasi totalmente assente copertura nevosa).	/static/gpx/Rocca Patanua da Prarotto (1).gpx	0.00	Piemonte	Torino	Condove	Italia	0		["/static/images/28.jpg"]	0	
19	2	8085.21	150	829.13	3	Cima Durand-Colle Bauzano-Artesina	Lasciata la macchina nello spazioso parcheggio di Artesina o nei posteggi vicino al bar Tana del Lupo, saliamo sulle piste dove possiamo subito infilare le ciaspole.\n\nProcediamo per circa 400m sull’ampio sentiero in direzione Ovest (a destra) e dopo alcuni tornanti troviamo un bivio (a sinistra vi è la stradina che percorreremo al ritorno) dove proseguiamo sulla destra (sentiero F02) dirigendoci verso la Celletta, punto panoramico sulla valle Ellero.\n\nPercorriamo il sentiero per Serra della Turra che ci porta prima a passare sotto la seggiovia e poi ad un pianoro dove troviamo la Baita della Turra, tappa ideale per un eventuale break o colazione.	/static/gpx/Senriero per Anello cima Durand, Colle Bauzano, Artesina (1) (1).gpx	0.00	Piemonte	Cuneo	Artesina	Italia	0		["/static/images/48.jpg"]	0	
20	2	9039.75	120	1090.66	1	Rifugio Quintino Sella e Viso Mozzo	The path does not present any difficulty, in case of rain, however, the climb is not recommended as the route is entirely on stony ground.\n\nFrom up there you have a privileged view of a large part of the Monviso chain and the close distance to the Re di pietra is unique.	/static/gpx/Sentiero per Rifugio Quintino Sella e Viso Mozzo.gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/31.jpg"]	0	
21	2	16969.03	120	984.23	3	Da Ss659 a Ss6591	Take the A26 motorway towards Gravellona Toce and follow it to the end. From there stay on the SS33 del Sempione passing Domodossola. At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls. There are unpaved parking lots just before the Centro Fondo Riale.	/static/gpx/Sentiero per Rupe del Gesso - CIASPOLE.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Formazzo	Italia	0		["/static/images/38.jpg"]	0	
22	2	11301.88	140	1381.69	2	Albogno-Pieve Margineta Mater	Escursione senza molte difficoltà ideale per il periodo primaverile e autunnale. \nDopo circa 2 ore di bosco si esce su delle creste molto panoramiche e semplici, il ritorno purtroppo viene fatto su un sentiero poco segnato sulla parte iniziale e ma man mano che si scende compiano sia segni e gli ometti.	/static/gpx/albogno-pieve-margineta-mater-27-8-21.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Albogno	Italia	0		["/static/images/11.jpg"]	0	
37	2	3.10	225	29.20	2	La pieve romanica di Piesenzana e la valle delle tartufaie	Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. \nCirca 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. \nIn regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. \nA Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). \nContemporaneamente i ristoranti della zona propongono piatti a base di tartufi	/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx	0.00	Piemonte	Asti	Montechiaro d'Asti	Italia	0		["/static/images/5.jpg"]	0	
23	2	4.70	200	28.50	2	Alte Langhe Settentrionali - Cossano Belbo	Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.\nSi svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.\nSi imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.\nInizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.\nPercorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. \nSeguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. \nSi procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante	/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx	0.00	Piemonte	Cuneo	Cossano Belbo	Italia	0		["/static/images/4.jpg"]	0	
24	2	8503.26	150	558.51	2	Anello per il Monte Freidour (PERLEVIEDELMONDO)	At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls.	/static/gpx/anello monte freidour (1).gpx	0.00	Piemonte	Torino	San Pietro Val Lemina	Italia	0		["/static/images/39.jpg"]	0	
25	2	42458.63	320	23175.26	2	Anello Pieve di Ledro-Biacesa di Ledro-Rifugio Nino Pernici	Anello sui monti a nord-est del Lago di Ledro, percorso in 3 giorni andando con molta calma, percorribile anche in 2. \nAlcuni tratti della prima metà del percorso sono attrezzati con scale e corde.	/static/gpx/anello-pieve-di-ledro-biacesa-di-ledro-rifugio-nino-pernici.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/14.jpg"]	0	
26	2	19320.58	210	666.37	2	Anello sui colli imolesi: Dozza - Pieve S. Andrea	Crossing the provincial road you can see the first of the various signs of the Camino di San Antonio that we will find along the way. We cross and begin a slow but constant climb alongside the fields, which will lead us to a beautiful panoramic view of the surrounding valleys. Paying attention to the crossroads, we continue until we cross the paved road again. In reality there is very little traffic... with a decent view of the Vena del Gesso Romagnola we arrive at the delightful village of Pieve Sant'Andrea (worth a quick detour), to then resume our journey. Be careful not to follow the path of Sant'Antonio, we descend rapidly (shortly after we find the Sorgente delle Accarisie on our left, already existing in Roman times) until we reach the small hamlet of Valsellustra. Here too we cross the road and follow the paved via delle Ville uphill to arrive at a first panoramic point over the surrounding gullies.	/static/gpx/anello-sui-colli-imolesi-dozza-pieve-s-andrea-valsellustra-s.gpx	0.00	Emilia-Romagna	Bologna	Dozza	Italia	0		["/static/images/21.jpg"]	0	
27	2	10764.50	300	1852.46	2	Campione Pieve Campione	Campione Pieve Campione	/static/gpx/campione-pieve-campione.gpx	0.00	Lombardia	Brescia	Campione del Garda	Italia	0		["/static/images/17.jpg"]	0	
28	2	15650.26	210	838.33	2	Casalfiumanese (BO) - Pieve di Sant'Andrea	Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don't die from the heat and the clouds filter the sun's rays and allow you to better enjoy the landscapes	/static/gpx/casalfiumanese-bo-pieve-di-santandrea.gpx	0.00	Emilia-Romagna	Bologna	Casal Fiumese	Italia	0		["/static/images/24.jpg"]	0	
29	2	15650.26	210	838.33	2	Casalfiumanese (BO) - Pieve di Sant'Andrea	Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don't die from the heat and the clouds filter the sun's rays and allow you to better enjoy the landscapes	/static/gpx/casalfiumanese-bo-pieve.gpx	0.00	Emilia-romagna	Bologna	CasalFiumese	Italia	0		["/static/images/25.jpg"]	0	
30	2	17987.27	150	651.41	1	Cavriana pieve- Volta mantovana chiesetta Madonna dei Marchi	Bellissima passeggiata con displivello	/static/gpx/cavriana-pieve-volta-mantovana-chiesetta-madonna-dei-marchi.gpx	0.00	Lombardia	Mantova	Cavriana	Italia	0		["/static/images/13.jpg"]	0	
31	2	5474.28	140	791.51	2	Sentiero per CIMA CIANTIPLAGNA	The route is safe and within everyone's reach, even though you reach a relatively high altitude... for this reason it is good to take into account sudden changes in the weather (wind, rain, thick fog).\n\nDue to the total absence of shading, I recommend sunscreen cream and adequate water supply.\n\nIn late spring it is still possible to find accumulations of snow which can make the ascent difficult, especially in the final stretch towards the summit.\n\nFor cheese lovers, I highly recommend a stop at the Pian dell'Alpe bergeria...	/static/gpx/ciantiplagna.gpx	0.00	Piemonte	Torino	Meana di Susa	Italia	0		["/static/images/41.jpg"]	0	
32	2	6588.82	120	936.79	2	Da Voltino a Pieve di Tremosine e ritorno	Fa quasi paura ad avvicinarsi alla ringhiera. \nVicino alla postazione panoramica presso il bar ristorante che ho fotografato, c'è l'inizio del sentiero per la discesa al Porto di Tremosine.C'è scritto che è consigliato per escursionisti esperti.	/static/gpx/da-voltino-a-pieve-di-tremosine-e-ritorno.gpx	0.00	Lombardia	Brescia	Tremosine sul Garda	Italia	0		["/static/images/15.jpg"]	0	
33	2	13691.92	150	584.92	2	Dalla chiesa romanica di San Pietro di Fenestrella alla abba...	Chiesa di San Pietro de Fenestrella: \nLa chiesa è situata nel cimitero di Albugnano. \nEssa ha affinità compositive con la Canonica di santa Maria di Vezzolano e deriverebbe il suo nome ,secondo alcuni,dalla insolita presenza di tre finestre nell’abside,secondo altri, sarebbe stata così denominata perchè situata nello stretto colle (una gola) compreso tra il rilievo collinare di Albugnano e il rilievo ove sorge il cimitero: \nUna specie di finestra aperta sulla valle sottostante.	/static/gpx/dalla-chiesa-romanica-di-san-pietro-di-fenestrella-alla-abba.gpx	0.00	Piemonte	Asti	Albugnano	Italia	0		["/static/images/27.jpg"]	0	
34	2	14496.86	90	832.35	1	Gulo - Pieve Vergonte	Gulo - Pieve Vergonte	/static/gpx/gulo-pieve-vergonte.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Santa Maria	Italia	0		["/static/images/9.jpg"]	0	
35	2	9623.86	210	697.12	2	Il giro del Montorfano: la chiesa romanica, il borgo e la ve...	Il giro del Montorfano: la chiesa romanica, il borgo e la vetta	/static/gpx/il-giro-del-montorfano-la-chiesa-romanica-il-borgo-e-la-vett.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Bracchio	Italia	0		["/static/images/10.jpg"]	0	
36	2	12572.72	210	341.55	3	La chiesa romanica di S. Vittore(anello Montemagno--Viarigi)	Il percorso si svolge prevalentemente su sterrata. \nEsso non ha segnaletica ad eccezione dell’ultimo tratto (due km. circa) da località Madonna del Gombo fino a Montemagno. \nIn questo tratto si incontra la segnaletica del sentiero n.507 della Regione Piemonte.	/static/gpx/la-chiesa-romanica-di-s-vittoreanello-montemagno-viarigi.gpx	0.00	Piemonte	Asti	Montemagno	Italia	0		["/static/images/6.jpg"]	0	
38	2	12572.72	255	341.55	3	Le Paludi di Ostiglia Oasi del Busatello Sermide e Pieve	La tradizione afferma che la chiesa fu costruita nel 1082, per volere di Matilde di Canossa. Questa attribuzione risale al 1612 nella Historia ecclesiastica di Mantova dove il Donesmondi attribuisce l'edificazione della chiesa a Matilde, assieme ad altre chiese del territorio. \nIl Donesmondi affermò questa data riprendendo l'iscrizione da una lapide presente sulla facciata della pieve, visibile ancora oggi, dove sta scritto "D.O.M. ET B. MARIAE V. IN COELUM ASSUMPTAE ERECTA A.D. 1082 A CONNTISSA MATHILDE". Secondo un'analisi storica questa lapide non può essere ritenuta originale dell'XI secolo, ma risale al cinquecento. L'ipotesi è che questa iscrizione si stata realizzata durante il restauro del 1538. \nStoricamente, quindi, non ci sono documenti che attestano una data certa di costruzione della chiesa, ma sulla base degli elementi architettonici si può affermare che la pieve venne eretta nell'XI secolo. \nLa chiesa è in stile romanico, costruita in laterizio ed è composta da tre navat	/static/gpx/le-paludi-di-ostiglia-oasi-del-busatello-sermide-e-pieve-di-.gpx	0.00	Lombardia	Mantova	Pieve di Coriano	Italia	0		["/static/images/7.jpg"]	0	
39	2	2150.30	120	586.43	2	Sentiero per il MONTE CUCETTO	Escursione Facile e, nella parte alta, molto panoramica; la cima offre una buona panoramica dei rilievi tra bassa Val Chisone e Val Sangone.\n\nLasciata l’auto, il sentiero parte in corrispondenza del tornante ed entra nel bosco in direzione Nord-Ovest; al primo bivio, proseguire dritto e seguire le indicazioni per “Cucetto”; il sentiero inizia a guadagnare quota abbastanza rapidamente e costantemente, sempre nel bosco.\n\nDopo una serie di tornantini la vegetazione inizierà a diradarsi e si inizierà a scorgere un bel panorama con il Monviso in bella mostra (se il meteo lo permette).	/static/gpx/monte cucetto.gpx	0.00	Piemonte	Torino	Dubbione	Italia	0		["/static/images/50.jpg"]	0	
40	2	2127.35	200	277.52	2	Sentiero per il MONTE MURETTO	È presente un unico punto acqua nel luogo del parcheggio (fontana). Nella stessa piazzetta, al momento della recensione, è sempre aperto nei weekend un singolare bar allestito dentro un vecchio furgone.\n\nPer chi cammina con bimbi e soprattutto cani, attenzione in primavera alla presenza di processionarie.	/static/gpx/monte muretto.gpx	0.00	Piemonte	Torino	Torino	Italia	0		["/static/images/44.jpg"]	0	
41	2	8627.55	70	1018.01	1	Pieve di Ledro - Monte Cocca	Very challenging, but worth it! The view from the top is gorgeous! For the descent it is better to use sticks, or repeat the same route as the climb.	/static/gpx/pieve-di-ledro-monte-cocca.gpx	0.00	Trentino Alto Adige	Provincia di Trento	Pieve di Ledro	Italia	0		["/static/images/20.jpg"]	0	
42	2	22430.40	150	1004.43	2	Pieve S. Stefano a Pian delle Capanne	Causa pioggia e terreno scivoloso preso la 1º variante fino al passo Viamaggio poi proseguito ancora per la 2º variante. \nBisogna calcolare circa 4 km in più.	/static/gpx/pieve-s-stefano-a-pian-delle-capanne.gpx	0.00	Toscana	Arezzo	Pieve Santo Stefano	Italia	0		["/static/images/23.jpg"]	0	
43	2	4857.31	60	94.23	1	Piverone - Anello IV - “Via Romanica al Gesiun”	Piverone - Anello IV - “Via Romanica al Gesiun”	/static/gpx/piverone-anello-iv-via-romanica-al-gesiun.gpx	0.00	Piemonte	Torino	Pieverone	Italia	0		["/static/images/8.jpg"]	0	
44	2	6588.82	320	936.79	2	Plois - Pieve d'Alpago	percorso è tranquillamente percorribile	/static/gpx/plois-pieve-dalpago.gpx	0.00	Veneto	Belluno	Pieve d'Alpegno	Italia	0		["/static/images/19.jpg"]	0	
45	2	6588.82	200	936.79	2	Rifugio Galassi, forcella del ghiacciaio, Rifugio Antelao	Quinta giornata Alta via N°4\nRifugio Galassi, forcella del ghiacciaio, Rifugio Antelao, Pieve di Cadore.	/static/gpx/rifugio-galassi-forcella-del-ghiacciaio-rifugio-antelao-piev.gpx	0.00	Veneto	Belluno	Belluno	Italia	0		["/static/images/18.jpg"]	0	
46	2	8085.21	135	829.13	3	Riva del Garda - Pieve di Ledro - Panchina	Riva del Garda - Pieve di Ledro - Panchina	/static/gpx/riva-del-garda-pieve-di-ledro-panchina.gpx	0.00	Trentino Alto Adige	Provincia di Trento	Sant'Alessandro	Italia	0		["/static/images/16.jpg"]	0	
47	2	19553.11	210	1298.22	2	Sovicille delle Meraviglie - Villa Cetinale - Scala Santa	Suggestivo anello con visita della pieve di Pernina e del parco di Villa Cetinale/Castello di Celsa aperti in occasione dell'evento Sovicille delle Meraviglie ottobre 2021	/static/gpx/sovicille-delle-meraviglie-villa-cetinale-scala-santa-e-romi.gpx	0.00	Toscana	Siena	Sovicille	Italia	0		["/static/images/26.jpg"]	0	
48	2	5304.04	150	958.89	3	BERGERIE DI VALLONCRO’	Open and shade-free environment: remember sunscreen; if the walk is too long, the plateau at the base of the waterfall still offers various possibilities for pleasant picnics.	/static/gpx/vallone di massello (1).gpx	0.00	Piemonte	Torino	Massello	Italia	0		["/static/images/30.jpg"]	0	
49	2	22696.48	110	236.71	2	Ville Disunite - Anello Ghibullo - Villa Pasolini.	The first stretch is entirely on the right bank of the Ronco, on the Via Romea Germanica. Then you enter the territory to go towards the center of the journey, the area of ​​San Pietro in Trento where, within two kilometres, you come across a medieval tower, a 9th century parish church with a fantastic crypt, the ruins of a large villa and a perfectly healthy 16th century villa.	/static/gpx/ville-disunite-anello-ghibullo-villa-pasolini-torre-albicini.gpx	0.00	Emilia-Romagna	Ravenna	Lognana	Italia	0		["/static/images/23.jpg"]	0	
\.


--
-- Data for Name: hut-worker; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."hut-worker" ("userId", "hutId") FROM stdin;
7	1
8	2
9	3
10	4
11	5
12	6
13	7
14	8
15	9
16	10
17	11
18	12
19	13
20	14
21	15
22	16
23	17
24	18
25	19
26	20
27	21
28	22
29	23
30	24
31	25
32	26
33	27
34	28
35	29
36	30
37	31
38	32
39	33
40	34
41	35
42	36
43	37
44	38
45	39
46	40
47	41
48	42
49	43
50	44
51	45
52	46
53	47
54	48
55	49
56	50
57	51
58	52
59	53
60	54
61	55
62	56
63	57
64	58
65	59
66	60
67	61
68	62
69	63
70	64
71	65
72	66
73	67
74	68
75	69
76	70
77	71
78	72
79	73
80	74
81	75
82	76
83	77
84	78
85	79
86	80
87	81
88	82
89	83
90	84
91	85
92	86
93	87
94	88
95	89
96	90
97	91
98	92
99	93
100	94
101	95
102	96
103	97
104	98
105	99
106	100
107	101
108	102
109	103
110	104
111	105
112	106
113	107
114	108
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website, elevation, pictures, description, "workingTimeStart", "workingTimeEnd", "phoneNumber", email) FROM stdin;
1	112	5	124.00	Edmund-Graf-Hütte	2	Betta Giorgi	https://optimal-shadow.it	332.61	["/static/images/25f0f48e-cd5a-4b3a-99ad-f2e9259d467c.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]	Reiciendis cupiditate earum voluptatibus.\nNeque corrupti incidunt nihil odit.\nOmnis ea id.\nConsequuntur fugiat et amet totam cum vero esse ipsam.	01:00:00	21:00:00	+391747138157	Tirone.Izzi@gmail.com
2	113	3	45.00	Dr.Hernaus-Stöckl	2	Sandra Renda	https://troubled-inauguration.org	338.05	["/static/images/60f5b463-120c-45d7-b68b-747e6a20e4f4.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]	In commodi harum et consequatur alias in fuga veritatis fugiat.\nAt beatae suscipit voluptas rerum vero tenetur nam.\nConsectetur veritatis quod error amet repudiandae.	06:00:00	23:00:00	+395213024643	Sidonio47@yahoo.it
3	114	2	70.00	Amstettner Hütte	2	Vidiano Gagliano	https://vapid-suburb.net	271.82	["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg"]	Similique iure fugiat facere similique dolorem quidem modi quas.\nQuas quae beatae deleniti deserunt amet.\nQuod recusandae modi expedita molestias.\nEsse mollitia odit omnis cum optio vitae.	01:00:00	20:00:00	+392258806640	Lisandro_Silvestri@libero.it
4	115	3	85.00	Hochleckenhaus	2	Temistocle Leonardi	https://pink-site.org	327.95	["/static/images/90ed2500-1c29-4db5-ba74-36ac493363de.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg"]	Culpa hic quis eos ducimus error perspiciatis unde minima.\nIste facere commodi facilis.\nMinus aliquam harum totam explicabo magni.\nAliquam voluptatum aut eveniet placeat.	01:00:00	22:00:00	+398090795199	Durante_Bono65@yahoo.it
5	116	2	114.00	Kampthalerhütte	2	Monica De Rossi	https://muddy-astrologer.it	335.38	["/static/images/64b44b43-eb6d-4641-8c9b-c8b4ceb3e35f.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg"]	Dicta ducimus dolore.\nEst ducimus ut fuga odio inventore laboriosam.	01:00:00	18:00:00	+390161973678	Natalina.Fantozzi@hotmail.com
6	117	7	44.00	Lambacher Hütte	2	Alberta Manzi	https://masculine-carpeting.net	277.76	["/static/images/b2104cd4-03f5-4a0f-9a11-aad5088a38f2.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]	Harum ad nihil.\nVeritatis saepe voluptas occaecati quibusdam.\nFacere vitae voluptate quos maiores amet doloribus.	03:00:00	20:00:00	+394620229830	Pardo84@libero.it
7	118	3	76.00	Lustenauer Hütte	2	Apuleio Nobile	http://complicated-steward.com	319.67	["/static/images/90ed2500-1c29-4db5-ba74-36ac493363de.jpg", "/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]	Laboriosam incidunt corrupti blanditiis ratione dolor incidunt id dolor.\nAliquid officiis iure amet sit voluptatibus assumenda aperiam.\nFacere dolorum blanditiis soluta aliquid.\nFugiat inventore sint.\nSed eveniet delectus molestias fugiat facere.	04:00:00	18:00:00	+390925040058	Duccio.Romano15@hotmail.com
8	119	2	52.00	Gablonzer Hütte	2	Alceo Spanò	https://slushy-rape.it	279.25	["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg"]	Nisi ullam eos minus.\nFacere nihil tenetur quidem veniam soluta exercitationem magni non quia.\nBeatae pariatur quasi fugit possimus.\nOmnis dolor repellat necessitatibus.	02:00:00	20:00:00	+390818283441	Procopio_Marcello91@email.it
9	120	6	51.00	Katafygio «Flampouri»	2	Noè Iannaccone	http://peaceful-dart.org	331.61	["/static/images/dc0b5f7f-d79a-4499-92e0-c8f4e391345e.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg"]	Earum neque neque odio ipsam.\nFugiat quos voluptatem velit sit.\nExplicabo atque eos nihil qui soluta voluptatum libero.\nRerum consectetur possimus laboriosam enim expedita adipisci numquam.\nDelectus ratione suscipit temporibus officiis.	05:00:00	20:00:00	+391998171874	Golia_Sannino93@libero.it
10	121	5	36.00	Simonyhütte	2	Belina Spina	https://melodic-scheme.it	296.83	["/static/images/2253208c-36c9-46d5-abeb-8bb44f5f6739.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]	Ullam quod expedita.\nEum magni quod.\nTotam corporis labore nisi itaque quibusdam laborum modi.\nIncidunt commodi porro itaque animi exercitationem vero accusamus hic.	04:00:00	22:00:00	+395892151986	Fedro_Valli@yahoo.it
11	122	1	122.00	Vinzenz-Tollinger-Hütte	2	Pio Carrozza	http://scented-well.org	276.18	["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg"]	Molestias possimus dicta magnam.\nQuaerat aperiam totam provident quam quibusdam.\nReprehenderit enim voluptate laborum eius debitis sapiente laborum autem.\nEsse similique modi perferendis dignissimos laboriosam aspernatur quas sapiente.	02:00:00	23:00:00	+394782230808	Sapiente.Marchesi11@yahoo.it
12	123	2	66.00	Ottokar-Kernstock-Haus	2	Ilia Viola	https://poor-complex.com	290.97	["/static/images/1bdc418d-1e4f-48de-a7ca-e4253e0bcb62.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg"]	Provident incidunt suscipit dolorem nulla.\nAtque accusantium provident soluta.\nA molestias quos nam numquam unde minima aut.\nMolestiae saepe sapiente enim libero nobis iste exercitationem.\nPerspiciatis exercitationem id nulla eligendi minus delectus architecto accusantium at.	07:00:00	19:00:00	+390557677633	Cointa_Tarantino67@email.it
13	124	7	51.00	Reisseckhütte	2	Lautone Pellegrino	http://needy-copyright.it	263.95	["/static/images/1bdc418d-1e4f-48de-a7ca-e4253e0bcb62.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg"]	Laborum aut explicabo.\nEaque quis veniam voluptas odio sit ducimus qui quaerat.\nHarum ea numquam odit sequi ipsa voluptas distinctio quibusdam.\nSunt eligendi tenetur necessitatibus ad fuga.	09:00:00	18:00:00	+399455583532	Ennio17@email.it
14	125	2	40.00	Vernagthütte	2	Nicarete Fontana	https://live-nightingale.it	332.13	["/static/images/1bdc418d-1e4f-48de-a7ca-e4253e0bcb62.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg"]	Assumenda odio qui eius alias vel dicta.\nTemporibus impedit deleniti pariatur molestiae consectetur.\nRepudiandae deleniti atque fugit libero asperiores.\nAut voluptatibus aut consequuntur ex ea ducimus labore.\nQuisquam natus harum nostrum autem perferendis ut provident laudantium.	07:00:00	20:00:00	+392814868122	Benvenuta_Magnani@email.it
15	126	8	100.00	Wormser Hütte	2	Placida Del Bianco	https://unnatural-trigger.org	285.98	["/static/images/8cc297a4-7e71-47c2-b123-37a6c0560357.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]	Eveniet eum earum architecto inventore magnam fugiat.\nExercitationem non provident iste quae.\nVoluptatem consectetur exercitationem quidem.\nIusto illo repellendus deleniti odio in soluta totam quas itaque.	07:00:00	20:00:00	+398689070145	Simeone_Brignone@gmail.com
16	127	1	40.00	Biberacher Hütte	2	Ausiliatrice Cappiello	https://trim-union.com	335.07	["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]	Itaque tempore vel expedita nulla mollitia vel corporis.\nDolores molestias iste quam repellendus a quae molestiae.	05:00:00	21:00:00	+397957577336	Susanna8@yahoo.com
17	128	1	90.00	Katafygio «1777»	2	Eufemio Pellicanò	http://attractive-acquisition.it	298.07	["/static/images/8aabafae-5cbd-4a9d-8196-a266b7d40605.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg"]	Fugit atque dolorem quibusdam rerum debitis quibusdam minima in eveniet.\nDolorum molestiae facilis quas nesciunt sed alias aliquid quia.\nHic inventore dolore laborum.	01:00:00	23:00:00	+393732660520	Maffeo_Pavani@libero.it
18	129	3	103.00	Hochwaldhütte	2	Prospero Cozzani	https://treasured-secretariat.it	288.60	["/static/images/64b44b43-eb6d-4641-8c9b-c8b4ceb3e35f.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg"]	Quas id cupiditate voluptatem minima incidunt a ad sed.\nPossimus dolorem laudantium adipisci corporis vitae.	08:00:00	18:00:00	+397211258295	Lazzaro.Bodini@hotmail.com
19	130	1	79.00	Kölner Eifelhütte	2	Donna Biagi	https://curvy-scheduling.it	332.61	["/static/images/2253208c-36c9-46d5-abeb-8bb44f5f6739.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]	Sapiente iusto sequi sapiente.\nFacilis tempora magnam ducimus corrupti nostrum.\nAlias eius animi provident velit amet illo quam sunt.	03:00:00	23:00:00	+395330554950	Onorata.Raniolo@gmail.com
20	131	8	35.00	Madrisahütte	2	Saffiro Terzi	https://nippy-rabbit.it	339.78	["/static/images/3e7f5444-b782-4eec-a42a-d6c8a890d142.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg"]	Ducimus consequatur sit velit itaque non repellendus ex.\nVeniam aut voluptatum aut sunt corrupti vel.	04:00:00	20:00:00	+391855811351	Verena.Spina@yahoo.com
21	132	9	95.00	Dresdner Hütte	2	Giacinta Visintin	https://extroverted-antennae.com	307.42	["/static/images/3c557da0-efbd-4062-86bb-1e7322109752.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg"]	Nam officia aut magni optio.\nIllum perspiciatis soluta.\nA distinctio hic.\nEnim omnis nihil possimus maiores quibusdam iure optio.	09:00:00	21:00:00	+392353764500	Diomede_Bortoluzzi1@email.it
22	133	10	137.00	Fiderepasshütte	2	Sig. Appia Daniele	http://verifiable-fight.net	323.85	["/static/images/64b44b43-eb6d-4641-8c9b-c8b4ceb3e35f.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg"]	Ea aut aliquam beatae exercitationem est veritatis earum.\nExplicabo ratione perferendis non recusandae recusandae dolores repellendus ipsum ullam.	08:00:00	23:00:00	+399710395511	Colombo_Pasquini34@yahoo.com
23	134	7	40.00	Göppinger Hütte	2	Eufemia Viviani	http://rapid-mapping.org	274.11	["/static/images/90ed2500-1c29-4db5-ba74-36ac493363de.jpg", "/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]	Quisquam facere aliquam accusantium maxime.\nQuas dolor quis laboriosam.\nRepellendus quisquam eaque.\nVero labore ad cupiditate laudantium natus.	05:00:00	21:00:00	+393899865574	Silvestro_Burgio70@email.it
24	135	3	87.00	Oberzalimhütte	2	Tito Palmeri	https://familiar-siding.com	285.49	["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg"]	Distinctio expedita error ipsam quaerat repellat eligendi similique maxime.\nDeleniti ipsa dolore natus.\nSed tempore asperiores perferendis tenetur tempora aspernatur dignissimos veniam.\nFacere tenetur adipisci nihil.	05:00:00	22:00:00	+395618006895	Birino.DelBianco@libero.it
25	136	7	104.00	Rastkogelhütte	2	Palmira Ercoli	https://obedient-prophet.com	328.55	["/static/images/9bced8a8-84fa-4b18-b065-a1b53907d345.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]	Eos distinctio error quidem repellat doloremque voluptatem consequuntur ea.\nMolestiae totam exercitationem cumque expedita nobis consectetur repellendus harum.\nSapiente voluptatibus aliquam.\nSequi possimus neque veritatis tempora at praesentium nihil.	06:00:00	22:00:00	+397256395653	Renato.Traini@libero.it
26	137	1	91.00	Ansbacher Skihütte im Allgäu	2	Dott. Leonia Cerutti	https://liquid-spandex.org	292.11	["/static/images/9bced8a8-84fa-4b18-b065-a1b53907d345.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]	Amet quibusdam aperiam molestiae dolore beatae.\nExplicabo at eaque doloribus est magni iure dolorem quas ad.	02:00:00	23:00:00	+392012928525	Lazzaro45@yahoo.com
27	138	3	72.00	Kaltenberghütte	2	Barbarigo Paris	https://polite-pigsty.org	333.99	["/static/images/dc0b5f7f-d79a-4499-92e0-c8f4e391345e.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg"]	Quae officiis itaque ad sunt minus.\nEsse rerum consequatur.	01:00:00	21:00:00	+394143425207	Carmen_Pellicano@libero.it
28	139	6	150.00	Schweinfurter Hütte	2	Donna Cherubini	http://jovial-dictionary.it	278.35	["/static/images/2253208c-36c9-46d5-abeb-8bb44f5f6739.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]	Nulla minima animi.\nIpsa inventore quae vero.\nSint ducimus minima fugit.	06:00:00	22:00:00	+391462982750	Antero.Pugliese96@libero.it
29	140	1	55.00	Katafygio «Vardousion»	2	Namazio Granata	https://plush-station-wagon.com	293.50	["/static/images/b8909acc-6822-40ea-ac2a-6c8de7b03cf8.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg"]	Voluptatum suscipit autem.\nVoluptas rerum sequi dolorum.\nEx fuga ex officiis quae incidunt quod ut.\nVoluptatibus officia animi unde.\nIste aut cumque tenetur facere a in.	02:00:00	23:00:00	+390619473027	Luana_Branca61@yahoo.it
30	141	1	123.00	Kocbekov dom na Korošici	2	Elpidio De Filippo	https://naughty-tragedy.it	276.31	["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg"]	Magnam quibusdam mollitia alias nisi eius mollitia deleniti.\nNam asperiores unde magni incidunt provident harum.\nEum rerum impedit nemo amet perferendis molestiae quisquam.\nSequi corrupti omnis culpa commodi.	03:00:00	20:00:00	+391016534892	Clodoveo.Morri17@libero.it
31	142	5	139.00	Planinski dom Rašiške cete na Rašici	2	Plutarco Mulas	http://periodic-defender.it	336.14	["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg"]	A possimus deserunt numquam mollitia.\nAdipisci nisi rerum delectus totam est eos molestias.\nConsequatur voluptatibus reprehenderit culpa sunt rerum nemo illo quo explicabo.\nHarum qui illum consectetur veniam quas qui suscipit tempora.	06:00:00	18:00:00	+398132015018	Onesta26@yahoo.it
32	143	8	129.00	Prešernova koca na Stolu	2	Zeno Cenni	https://blissful-tour.it	272.89	["/static/images/b2104cd4-03f5-4a0f-9a11-aad5088a38f2.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg"]	Fugit distinctio vel iste voluptatem aliquam occaecati voluptas ratione ex.\nHarum ratione nisi error accusantium mollitia delectus.\nA dicta cupiditate libero illum.\nCumque cumque illum ipsam nulla unde placeat itaque.	07:00:00	22:00:00	+391542614603	Albrico46@gmail.com
33	144	5	126.00	Planinski dom na Mrzlici	2	Ing. Liborio Angeli	https://original-foal.org	306.61	["/static/images/8d44f676-d5ec-4991-8dd8-783156c55129.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg"]	Id necessitatibus sed sunt veniam provident odit sit voluptatum minima.\nExcepturi rem dolorem sequi eligendi ea sequi voluptates.\nMinus eum necessitatibus at illo quis deserunt ab impedit.\nEius quae quam et quod.\nEligendi asperiores iure aut voluptas quaerat repudiandae quibusdam deleniti distinctio.	03:00:00	23:00:00	+397695078266	Lorenzo_Barletta12@email.it
34	145	7	142.00	Koca na Planini nad Vrhniko	2	Dr. Adalardo Cipriano	http://acclaimed-prose.com	317.46	["/static/images/8aabafae-5cbd-4a9d-8196-a266b7d40605.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg"]	Mollitia harum eligendi alias.\nFacere minima eos ab consectetur repellat tenetur cum at asperiores.\nQuas iusto autem error ea architecto dolorum reprehenderit.	06:00:00	20:00:00	+392110483047	Severo_Bertini30@yahoo.it
35	146	3	117.00	Zavetišce gorske straže na Jelencih	2	Atanasia Benedetti	http://orderly-hake.org	298.11	["/static/images/9a116e20-4dbc-40ba-bdb6-ab60a9868259.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg"]	Consequatur iure incidunt architecto nobis ipsa fugit dicta dignissimos.\nAperiam impedit nobis quo voluptatibus.\nQui nisi unde maxime asperiores magni.\nQuibusdam aspernatur inventore nisi nam id necessitatibus.\nQuo voluptate deleniti earum veritatis voluptates voluptas voluptatem omnis autem.	01:00:00	19:00:00	+390719458338	Seconda94@yahoo.it
84	195	3	101.00	Meilerhütte	2	Diletta Manetti	http://orange-lynx.net	293.14	["/static/images/31e9a65d-714a-444f-b741-cd4a9e57d1d9.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]	Dolore totam quod harum qui quos adipisci facilis animi.\nLaborum fugiat tempore hic iste.	02:00:00	19:00:00	+394191570508	Ida.Pecora50@email.it
36	147	2	97.00	Planinski dom na Gori	2	Ursicio Inzerillo	https://criminal-sunshine.it	331.66	["/static/images/e6b3d215-ddf6-40d7-a3be-88add2fa0a73.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg"]	Perferendis sint autem quasi id molestiae culpa consequuntur molestiae.\nIure vero voluptatem quisquam consequuntur doloremque iure doloribus omnis quisquam.	09:00:00	23:00:00	+396603543683	Duilio_Prencipe52@libero.it
37	148	4	130.00	Bregarjevo zavetišce na planini Viševnik	2	Ileana Vecchi	https://jumpy-mist.it	275.24	["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg"]	Aperiam ratione optio quaerat possimus autem tempore quaerat.\nVeniam tempore dolores eos mollitia.\nPorro aut tenetur fuga.	02:00:00	18:00:00	+392844349654	Gioconda_Oliviero25@yahoo.it
38	149	10	138.00	Koca pod Bogatinom	2	Biagio Liguori	https://wooden-waiver.net	329.11	["/static/images/60f5b463-120c-45d7-b68b-747e6a20e4f4.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg"]	Nisi iure nostrum dolorum.\nPossimus ut ipsum nobis error nulla possimus eum culpa.\nId magnam commodi.\nLaborum aspernatur fugit adipisci placeat ipsum perspiciatis enim.\nDeleniti dicta eum minima eos exercitationem.	06:00:00	23:00:00	+398298709141	Gianni_Spiga23@hotmail.com
39	150	7	149.00	Pogacnikov dom na Kriških podih	2	Maurizio Lucchese	https://quiet-cayenne.com	300.92	["/static/images/1bdc418d-1e4f-48de-a7ca-e4253e0bcb62.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]	Explicabo delectus nesciunt sequi ut maiores harum qui atque rerum.\nQuis nisi deleniti consequuntur voluptatum ipsa quod nostrum beatae nisi.\nOccaecati sed ullam saepe.	02:00:00	19:00:00	+396467185594	Venceslao.Frasca29@email.it
40	151	7	128.00	Dom na Smrekovcu	2	Maurilio Marchesi	http://immense-origin.net	336.64	["/static/images/64b44b43-eb6d-4641-8c9b-c8b4ceb3e35f.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]	Sint quaerat asperiores suscipit corrupti.\nVoluptates hic cumque officiis reprehenderit.\nExcepturi perferendis voluptas.\nVeniam culpa sapiente vel eius sapiente natus doloribus magnam earum.	09:00:00	19:00:00	+393909499267	Venusta4@gmail.com
41	152	10	76.00	Refuge Du Chatelleret	2	Battista Flacco	https://euphoric-perpendicular.com	311.35	["/static/images/3e7f5444-b782-4eec-a42a-d6c8a890d142.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg"]	Vitae commodi nam culpa.\nQuae qui enim.	03:00:00	22:00:00	+394521239545	Rufo5@yahoo.it
42	153	1	103.00	Refuge De Chalance	2	Serapione Speranza	https://thirsty-honey.net	318.37	["/static/images/25f0f48e-cd5a-4b3a-99ad-f2e9259d467c.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg"]	Eligendi nam unde debitis.\nConsequuntur et quasi corporis vero.\nNumquam reprehenderit eos voluptatibus voluptate repellat ratione officiis impedit eius.\nVoluptas praesentium eum libero.	02:00:00	22:00:00	+397346249564	Lancilotto73@yahoo.it
43	154	5	128.00	Refuge Des Bans	2	Pauside Cassano	http://queasy-erection.net	274.72	["/static/images/64b44b43-eb6d-4641-8c9b-c8b4ceb3e35f.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg"]	Natus mollitia omnis consequatur maxime.\nA quidem officiis.\nLaborum commodi maiores nesciunt.	05:00:00	18:00:00	+398930360346	Berenice47@email.it
44	155	6	107.00	Refuge De Pombie	2	Giliola Marotta	https://notable-oar.org	338.69	["/static/images/8aabafae-5cbd-4a9d-8196-a266b7d40605.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg", "/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg"]	Nemo necessitatibus quod dolores quo odio ut dolore optio.\nConsequatur aspernatur maxime deserunt quod tempore reprehenderit.\nQui animi minima quam accusamus non.\nCum esse assumenda qui quasi nisi ratione facere libero harum.	03:00:00	18:00:00	+391506920624	Maurilio.Migliaccio@hotmail.com
45	156	7	59.00	Refuge De Larribet	2	Azzurra Peaquin	https://novel-castanet.it	300.89	["/static/images/8d44f676-d5ec-4991-8dd8-783156c55129.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg"]	Vel eos reiciendis nesciunt placeat molestias reprehenderit accusantium voluptatibus.\nNobis ipsum enim.\nOfficia perferendis quibusdam impedit placeat unde accusamus ullam tempora.\nSed aperiam accusamus eaque.\nTotam error quas temporibus libero.	03:00:00	22:00:00	+399688354366	Camelia_Antezza@hotmail.com
46	157	8	112.00	Refuge Du Mont Pourri	2	Ing. Ischirione Moroni	http://clear-fashion.net	308.96	["/static/images/b8909acc-6822-40ea-ac2a-6c8de7b03cf8.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg"]	Quae blanditiis alias doloribus dolorem facere.\nNecessitatibus temporibus reprehenderit laboriosam et neque delectus.\nLibero ducimus ea qui iure quisquam tenetur.\nRatione beatae aliquid maiores aspernatur aut voluptatum.	03:00:00	21:00:00	+395570853953	Valter_Pedrotti73@yahoo.com
47	158	9	101.00	Refuge De La Dent D?Oche	2	Teresa Corsini	https://querulous-ambition.net	310.96	["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg"]	Hic molestiae ab.\nConsectetur possimus corrupti laboriosam autem sint.	06:00:00	22:00:00	+396589765434	Emma.Tofani@gmail.com
48	159	2	67.00	Bergseehütte SAC	2	Capitolina Longo	http://noisy-communicant.com	285.36	["/static/images/e6b3d215-ddf6-40d7-a3be-88add2fa0a73.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg"]	Id commodi deserunt blanditiis maiores modi.\nAssumenda occaecati doloremque provident velit aspernatur nulla explicabo.\nPerspiciatis accusantium architecto aut eos vel vero.	01:00:00	22:00:00	+394740354603	Abbondanzio_Castellana@email.it
49	160	1	143.00	Bivouac au Col de la Dent Blanche CAS	2	Dott. Genesio Gennaro	http://winding-great-grandmother.org	328.55	["/static/images/2253208c-36c9-46d5-abeb-8bb44f5f6739.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg"]	Temporibus facilis quam nam sunt sunt corporis.\nEt nihil ab eum reiciendis.	04:00:00	23:00:00	+396258471210	Gaia88@yahoo.com
50	161	5	63.00	Salbitschijenbiwak SAC	2	Cointa Antezza	http://dizzy-murder.org	289.30	["/static/images/60f5b463-120c-45d7-b68b-747e6a20e4f4.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]	Doloribus harum officiis.\nHarum quasi adipisci libero mollitia veniam accusantium eum ipsum.\nNostrum deleniti sit ratione vero.\nVelit occaecati asperiores minus.\nExercitationem non fuga nesciunt porro quis adipisci recusandae.	09:00:00	19:00:00	+392614847755	Egisto_Benatti60@hotmail.com
51	162	8	54.00	Spannorthütte SAC	2	Edoardo Boccia	https://helpless-fondue.net	318.42	["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]	Debitis suscipit doloribus eaque iure inventore.\nRatione consectetur libero occaecati eius corporis.\nQuam cupiditate nihil deleniti nisi mollitia.	02:00:00	20:00:00	+395616685367	Ortensia29@hotmail.com
52	163	10	130.00	Cabane Arpitettaz CAS	2	Viscardo Pece	https://creative-pilgrim.it	334.97	["/static/images/2253208c-36c9-46d5-abeb-8bb44f5f6739.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg"]	Illum officia numquam dolores magni sint.\nItaque aliquam unde dolorum et accusamus eaque dolore.	07:00:00	19:00:00	+395798037885	Barbarigo.Pani@gmail.com
53	164	1	104.00	Refugio De Lizara	2	Marita Belli	https://stimulating-waterwheel.net	261.25	["/static/images/1bdc418d-1e4f-48de-a7ca-e4253e0bcb62.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]	Molestias optio distinctio.\nProvident numquam quod id animi exercitationem veniam nihil.\nOmnis odio doloremque ratione nam ea aliquid voluptatem ipsum.\nNulla corporis accusamus reiciendis consequuntur.	09:00:00	18:00:00	+399451235393	Palatino_Paladini@libero.it
54	165	2	64.00	Albergue De Montfalcó	2	Ing. Gianpietro Corsi	http://common-nature.com	285.34	["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg"]	Ducimus id ex dolore corporis facere maxime iusto dolor delectus.\nOdio repellendus aut dolorum enim voluptas tempora velit.	02:00:00	20:00:00	+392318462566	Sefora.Colucci13@gmail.com
55	166	4	82.00	El Molonillo/Peña Partida	2	Aleandro Saccone	http://impartial-group.net	322.09	["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg"]	Ab perferendis amet eius repudiandae perferendis iusto soluta incidunt.\nVoluptate ipsam quo qui laudantium veniam cum enim.\nNulla recusandae illum temporibus exercitationem.\nQui voluptatum deserunt nostrum corporis.\nEaque quisquam illo impedit explicabo animi suscipit nulla.	05:00:00	22:00:00	+392303457313	Alcino_Marrazzo10@yahoo.com
56	167	6	138.00	La Campiñuela	2	Menodora Mari	https://usable-accounting.it	268.98	["/static/images/31e9a65d-714a-444f-b741-cd4a9e57d1d9.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg"]	A omnis repudiandae hic quidem temporibus.\nDolorem nemo rem incidunt.	07:00:00	18:00:00	+396751924580	Gisella24@hotmail.com
57	168	7	96.00	Titov Vrv	2	Ivanoe Damiano	http://previous-jam.org	329.91	["/static/images/8d44f676-d5ec-4991-8dd8-783156c55129.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg"]	Porro architecto animi deleniti labore qui consequuntur blanditiis repellendus voluptatibus.\nQuasi beatae error explicabo delectus recusandae vel sit deserunt.	04:00:00	21:00:00	+399955190835	Efrem59@hotmail.com
58	169	1	73.00	Rifugio Franchetti	2	Eginardo Lai	https://hasty-paddock.net	319.76	["/static/images/31e9a65d-714a-444f-b741-cd4a9e57d1d9.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg"]	Labore delectus consequatur atque deleniti sapiente veritatis illum sint.\nLibero quae aperiam.	08:00:00	21:00:00	+397708903852	Daria.Evola69@libero.it
59	170	8	69.00	Rifugio Semenza	2	Casimira Andreoli	http://jaunty-racism.it	311.29	["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg"]	Eveniet nisi tempora perspiciatis placeat vero enim dolorum ipsa.\nQuasi laborum tempore vero incidunt.\nEligendi voluptatum sequi eum.\nTemporibus vitae porro nisi exercitationem quaerat ratione ab.	07:00:00	18:00:00	+395709908623	Severa.Poggio6@yahoo.it
60	171	4	136.00	Rifugio Città di Mortara 	2	Amos Di Girolamo	http://bountiful-ladybug.it	335.95	["/static/images/25f0f48e-cd5a-4b3a-99ad-f2e9259d467c.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg"]	Fuga nam distinctio perferendis nostrum voluptatum.\nReiciendis nemo autem nam.\nAperiam error dolorum nesciunt qui ducimus enim.	08:00:00	18:00:00	+398627382258	Osmondo.Accardi93@yahoo.it
61	172	3	82.00	Rifugio Andolla	2	Astianatte Massa	http://snoopy-mankind.com	327.57	["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg"]	Voluptatem quas ratione.\nQuod excepturi voluptates facere quae repudiandae dolorum praesentium itaque.\nPariatur placeat quos tenetur ad amet non facilis voluptates.	03:00:00	22:00:00	+397912113667	Felicia.DiBlasi75@libero.it
62	173	9	49.00	Rifugio Forte dei Marmi	2	Gloria Bernasconi	https://dangerous-everyone.net	299.05	["/static/images/9a116e20-4dbc-40ba-bdb6-ab60a9868259.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]	Ab alias blanditiis odio nisi eius iure illo laboriosam.\nQui iusto recusandae.\nDeleniti sapiente deleniti cum rerum cupiditate reprehenderit.	06:00:00	22:00:00	+393378612268	Tarso.Cardinali80@yahoo.com
63	174	8	111.00	Rifugio Berti	2	Damocle Visentin	http://authentic-altar.com	333.66	["/static/images/25f0f48e-cd5a-4b3a-99ad-f2e9259d467c.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]	Quisquam natus aperiam laudantium placeat accusamus optio veritatis eos.\nAliquid laborum eius doloribus ducimus consequuntur saepe repellat inventore repudiandae.\nVoluptatibus dicta alias.\nConsequatur aliquid debitis repudiandae at ut adipisci quae.	06:00:00	21:00:00	+393774481334	Fabiola58@yahoo.it
64	175	2	149.00	Rifugio Premuda	2	Vissia Errico	https://jumbo-constellation.org	286.80	["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg"]	Numquam provident impedit est tempore iste possimus.\nQuisquam ea repellat.\nAd quia laudantium ex.\nA veritatis asperiores earum nulla error ad alias tempore.	03:00:00	20:00:00	+390208212370	Bibiana_Saladino@hotmail.com
65	176	3	148.00	Rifugio Elisa	2	Zefiro Fasoli	http://prickly-party.it	283.72	["/static/images/3c557da0-efbd-4062-86bb-1e7322109752.jpg", "/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg"]	Qui odio et consequuntur sit laudantium dignissimos aspernatur.\nMolestiae sit blanditiis adipisci modi perspiciatis.\nRepellendus ducimus delectus mollitia labore ratione quibusdam aspernatur.\nExpedita nulla explicabo voluptas adipisci mollitia incidunt necessitatibus recusandae reiciendis.\nLaboriosam ducimus dolorum consequuntur vero autem et nobis nostrum optio.	07:00:00	23:00:00	+395135256786	Capitolina41@yahoo.it
66	177	8	62.00	Rifugio CAI Saronno	2	Pietro Minniti	http://scented-bore.it	312.34	["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]	Dignissimos adipisci commodi esse voluptas quidem in occaecati exercitationem velit.\nLaboriosam laudantium laboriosam blanditiis iste eaque similique modi ratione.\nEum consequatur beatae modi omnis minima nulla pariatur modi.	04:00:00	22:00:00	+395594194258	Omero70@hotmail.com
67	178	10	52.00	Rifugio Picco Ivigna	2	Soave Filippini	http://mammoth-scripture.com	268.67	["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]	In non sapiente dolorem.\nVoluptate soluta nesciunt doloribus aut.	05:00:00	21:00:00	+394367871218	Appia_Gaudiano@hotmail.com
68	179	9	145.00	Rifugio Toesca	2	Giona Ciccone	http://willing-texture.net	265.25	["/static/images/9a116e20-4dbc-40ba-bdb6-ab60a9868259.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg"]	Exercitationem quaerat molestias eveniet quis maiores incidunt et corporis consequatur.\nProvident esse blanditiis deleniti.\nSuscipit a minima.\nAlias hic laborum modi.\nSaepe molestias cupiditate ut fuga eum cupiditate a voluptatem.	05:00:00	21:00:00	+392068430047	Stefano38@email.it
69	180	2	143.00	Rifugio Al Cedo	2	Teresa Lipari	http://international-daffodil.com	262.63	["/static/images/b2104cd4-03f5-4a0f-9a11-aad5088a38f2.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg"]	Magni repellat labore.\nDistinctio deleniti sit placeat possimus aperiam voluptate.\nOfficiis quidem impedit tempora explicabo eius quae iure.	03:00:00	20:00:00	+398312042344	Guiberto.Cremonesi7@hotmail.com
70	181	8	54.00	Capanna Gnifetti	2	Enimia Amico	https://elegant-rivulet.com	299.88	["/static/images/9a116e20-4dbc-40ba-bdb6-ab60a9868259.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg"]	Voluptatibus dignissimos aliquam earum delectus adipisci reiciendis non ducimus aliquam.\nConsequuntur temporibus laboriosam minima ipsa consequuntur dolore repudiandae sequi sed.	04:00:00	22:00:00	+392236991851	Flaminia.Campana@yahoo.it
71	182	7	93.00	Rifugio Aosta	2	Caterina Cataldi	http://unfolded-effectiveness.com	280.23	["/static/images/9a116e20-4dbc-40ba-bdb6-ab60a9868259.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]	Praesentium soluta adipisci soluta.\nConsequuntur fugit aliquam.\nQuisquam aut dolor aliquid dolor incidunt possimus sunt.\nEaque doloremque aspernatur ea praesentium error.\nDebitis ab est molestias atque ullam corrupti.	09:00:00	19:00:00	+392720547336	Gelsomina.Cappai@libero.it
72	183	3	83.00	Rifugio Cevedale	2	Loredana De Stefano	https://rubbery-ruckus.net	314.79	["/static/images/3c557da0-efbd-4062-86bb-1e7322109752.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg"]	Odio dolore expedita alias labore eligendi ut provident incidunt ab.\nLaborum veritatis corrupti nisi beatae fugiat vel at officiis hic.\nTempora assumenda quis molestiae illo laboriosam provident.\nDeleniti fugiat necessitatibus quisquam at in repudiandae.\nAutem accusantium corrupti.	02:00:00	23:00:00	+398648905479	Valter_Favara@libero.it
73	184	9	43.00	Rifugio Ponti	2	Emidio Papa	https://tan-authenticity.org	287.72	["/static/images/dc0b5f7f-d79a-4499-92e0-c8f4e391345e.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg"]	Explicabo earum earum ducimus inventore quasi beatae.\nEst reprehenderit doloremque commodi reprehenderit placeat nostrum quod placeat eos.\nSaepe fugit praesentium dolorum.\nOdit quos dolores ea.	06:00:00	18:00:00	+395617826529	Isabella74@hotmail.com
74	185	2	115.00	Rifugio XII Apostoli	2	Vilfredo Macaluso	http://short-term-cruelty.it	274.86	["/static/images/b8909acc-6822-40ea-ac2a-6c8de7b03cf8.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]	Minima deleniti beatae dolor soluta similique adipisci.\nAccusamus explicabo ullam vitae ipsa sit nobis laudantium.\nQuis ab excepturi dicta consequatur voluptas ipsum quaerat voluptas.	04:00:00	23:00:00	+393441710025	Flavio_Ianni99@yahoo.com
75	186	4	147.00	Rifugio Elisabetta Soldini	2	Uberto Addis	http://villainous-volunteering.net	265.54	["/static/images/9bced8a8-84fa-4b18-b065-a1b53907d345.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg"]	Accusamus aut fugiat necessitatibus eum excepturi dolorem ab maiores.\nPerspiciatis odio hic.	06:00:00	21:00:00	+394510148003	Enecone.Gigliotti@yahoo.it
76	187	10	59.00	Rifugio Denza	2	Guendalina Patruno	https://urban-rotation.com	330.54	["/static/images/9bced8a8-84fa-4b18-b065-a1b53907d345.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg"]	Facere laboriosam quas.\nRecusandae in numquam sed saepe.\nConsectetur incidunt incidunt dolore dolorem in quia in cupiditate.	09:00:00	18:00:00	+396317515044	Omar_Patti49@email.it
77	188	1	46.00	Rifugio Fonte Tavoloni 	2	Manfredo Urso	http://mountainous-authorisation.org	305.39	["/static/images/2253208c-36c9-46d5-abeb-8bb44f5f6739.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg"]	Temporibus fuga quisquam.\nNostrum accusantium maxime quo.	01:00:00	21:00:00	+391087627783	Peleo45@libero.it
78	189	5	138.00	Rifugio Carducci	2	Quiteria Restivo	http://weird-sunroom.org	329.54	["/static/images/25f0f48e-cd5a-4b3a-99ad-f2e9259d467c.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]	Voluptatum id corporis consectetur officiis sequi ullam repudiandae sunt.\nSit veritatis iste veritatis commodi.	09:00:00	21:00:00	+392401117487	Giovanna_Ciulla33@libero.it
79	190	5	117.00	Rifugio Bindesi	2	Licia Calì	https://weird-antelope.it	268.91	["/static/images/b2104cd4-03f5-4a0f-9a11-aad5088a38f2.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg"]	Unde esse veritatis laudantium nobis aspernatur in ullam debitis.\nConsectetur excepturi eligendi magnam voluptate voluptate nisi odio.\nVoluptas necessitatibus exercitationem tempora amet facilis.\nCorporis voluptates qui dolorum.	02:00:00	22:00:00	+397702697989	Garimberto_Scalise@libero.it
80	191	7	133.00	Mountain hut Miroslav Hirtz	2	Benigna Schirru	https://dim-blackberry.net	329.21	["/static/images/25f0f48e-cd5a-4b3a-99ad-f2e9259d467c.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg"]	Iusto illo est sequi a delectus cum.\nAsperiores inventore voluptates.	09:00:00	19:00:00	+397589285733	Pollione50@hotmail.com
81	192	3	150.00	Koca na Blegošu	2	Giocondo Vinci	https://cautious-silence.com	290.29	["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]	Error perspiciatis sequi.\nPlaceat earum sunt voluptatem nulla quis quis libero cum dignissimos.\nNihil adipisci nulla aliquid asperiores minima.\nAutem quos aliquam similique velit occaecati corrupti.	03:00:00	22:00:00	+397661372386	Gaetano.Valenti@libero.it
82	193	3	57.00	Wittener Hütte	2	Elmo Franceschi	https://bleak-church.com	277.26	["/static/images/25f0f48e-cd5a-4b3a-99ad-f2e9259d467c.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg"]	Voluptatibus sit iusto aliquam itaque pariatur.\nVitae eligendi facilis delectus ex a suscipit ipsam modi.\nQuia hic ipsum repudiandae.\nQuis tempora corrupti animi quod aut alias.\nVelit doloremque earum quisquam eos.	05:00:00	21:00:00	+397100247785	Beltramo.DiLorenzo80@email.it
83	194	1	78.00	Hochjoch-Hospiz	2	Dott. Gloria Iandolo	http://studious-naming.it	262.81	["/static/images/dc0b5f7f-d79a-4499-92e0-c8f4e391345e.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg"]	Hic voluptates doloribus repellendus.\nDignissimos officia delectus distinctio tenetur perspiciatis.\nDolorem perspiciatis nobis eos asperiores cum.\nArchitecto ab in voluptatibus laborum.\nOdio unde officia voluptatem itaque.	05:00:00	20:00:00	+396045714456	Stanislao.Bianc@libero.it
85	196	4	89.00	Gaudeamushütte	2	Martina Giovannelli	http://traumatic-crazy.it	266.89	["/static/images/64b44b43-eb6d-4641-8c9b-c8b4ceb3e35f.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]	Cumque corrupti dolores facilis.\nAutem nisi suscipit dolorem vitae suscipit mollitia maxime ea quidem.	01:00:00	22:00:00	+393480974368	Aristarco_Cruciani26@gmail.com
86	197	8	108.00	Rheydter Hütte	2	Ing. Nestore Florio	https://defenseless-snack.com	322.06	["/static/images/1bdc418d-1e4f-48de-a7ca-e4253e0bcb62.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg"]	Reprehenderit velit possimus fuga molestiae quod.\nDistinctio reprehenderit voluptatibus harum excepturi necessitatibus ratione illum delectus in.\nFacilis cum ullam.	05:00:00	20:00:00	+399101323395	Ursicio68@gmail.com
87	198	5	116.00	Sektionshütte Krippen	2	Zarina Recchia	https://wavy-month.net	296.89	["/static/images/b8909acc-6822-40ea-ac2a-6c8de7b03cf8.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg"]	Provident voluptates eaque.\nDolorum labore eligendi.\nNatus fuga odit temporibus quas eum harum.\nTenetur optio dolore.\nVoluptatum sint dolor hic unde vel incidunt deleniti.	01:00:00	20:00:00	+394640231399	Astrid_Meloni85@yahoo.it
88	199	3	98.00	Neunkirchner Hütte	2	Abele Novello	http://digital-melon.com	333.30	["/static/images/e6b3d215-ddf6-40d7-a3be-88add2fa0a73.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg"]	Quos distinctio et excepturi eius rerum adipisci optio.\nAut consequatur fugiat accusamus nobis similique tenetur occaecati enim vitae.\nVoluptatem quam dolor iusto facilis non rerum.\nPerferendis quam alias non fugiat.\nUt quo cumque eos aliquam mollitia enim quod.	05:00:00	19:00:00	+393451774306	Tommaso.Fratello78@gmail.com
89	200	5	44.00	Refugio De Riglos	2	Vladimiro Ferrari	http://outlying-jasmine.net	264.83	["/static/images/8cc297a4-7e71-47c2-b123-37a6c0560357.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg", "/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg"]	Sint incidunt dolorem nemo a esse nobis veritatis adipisci beatae.\nBeatae aspernatur esse aliquam maiores iure porro enim.\nFacere ipsa at pariatur vero natus.\nSequi itaque magni.	08:00:00	22:00:00	+398625152502	Edgardo92@gmail.com
90	201	5	37.00	Salbithütte SAC	2	Camilla Barberi	https://understated-wrestler.org	260.63	["/static/images/8cc297a4-7e71-47c2-b123-37a6c0560357.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg"]	Adipisci repellat assumenda molestiae magnam deleniti asperiores.\nDelectus quod ut cum.\nRatione incidunt culpa nam consectetur adipisci laboriosam ullam odio perferendis.	06:00:00	23:00:00	+393207258467	Palatino8@yahoo.it
91	202	10	61.00	Finsteraarhornhütte SAC	2	Iginio Fiorenza	https://unsung-boom.net	261.20	["/static/images/8d44f676-d5ec-4991-8dd8-783156c55129.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg"]	Quisquam repellendus veniam dolores dicta.\nConsequatur laboriosam id rerum aspernatur perferendis dolores odio pariatur.	05:00:00	21:00:00	+395515291012	Stefania.Zambuto@yahoo.com
92	203	6	73.00	Cabane des Vignettes CAS	2	Gioacchina Bertani	http://grumpy-push.com	278.78	["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg"]	Praesentium deserunt aspernatur odit voluptas fugit illum.\nOfficia error iusto ea libero minima laborum tempora.\nQuibusdam nam eligendi soluta.\nMagnam animi distinctio neque cupiditate nam quia illo.\nPlaceat aliquid veniam.	08:00:00	19:00:00	+396573578202	Luminosa.Cortesi@yahoo.com
93	204	3	68.00	Glecksteinhütte SAC	2	Sig. Abbondanza Giardina	https://vigilant-messy.it	314.46	["/static/images/b8909acc-6822-40ea-ac2a-6c8de7b03cf8.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg"]	Dolor iure pariatur odio quibusdam consequatur harum asperiores.\nTempora rem cum dolores temporibus.\nVel praesentium iste nisi sunt nulla minus.\nAsperiores inventore iusto dignissimos quasi similique excepturi possimus tenetur provident.\nNisi blanditiis nulla ratione nobis harum tempora fugiat ab.	04:00:00	18:00:00	+396518161708	Adalberto92@yahoo.it
94	205	7	38.00	Länta-Hütte SAC	2	Oronzo Corridori	http://queasy-making.net	288.37	["/static/images/8cc297a4-7e71-47c2-b123-37a6c0560357.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg"]	Harum veritatis ea deleniti.\nIncidunt nesciunt officiis.	06:00:00	18:00:00	+393929409666	Ilario1@yahoo.it
95	206	10	54.00	Monte-Leone-Hütte SAC	2	Viola Concas	https://agreeable-renaissance.net	309.15	["/static/images/60f5b463-120c-45d7-b68b-747e6a20e4f4.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg"]	Accusamus tempore vel nisi in.\nFugiat numquam tenetur.\nImpedit libero cumque sed ea.\nModi unde asperiores omnis inventore.\nAutem sunt labore velit est eveniet.	04:00:00	19:00:00	+398181032987	Menelao.Longo@yahoo.it
96	207	8	140.00	Ringelspitzhütte SAC	2	Onorata Spanu	http://gigantic-cross-contamination.com	319.93	["/static/images/31e9a65d-714a-444f-b741-cd4a9e57d1d9.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg"]	Dolorem ducimus commodi doloribus molestias.\nEx inventore error veritatis tempore pariatur possimus inventore cupiditate.\nEius debitis ea.\nEa quaerat necessitatibus a dicta accusantium.	01:00:00	21:00:00	+390564208445	Graziana64@hotmail.com
97	208	4	131.00	Na poljanama Maljen	2	Alfio Maione	https://extraneous-filly.org	306.14	["/static/images/b8909acc-6822-40ea-ac2a-6c8de7b03cf8.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]	Quae recusandae deleniti rerum aliquid.\nNon at dolore fugit excepturi magnam.\nAliquam rem suscipit molestias sunt.\nTenetur ratione modi quisquam in dicta nulla.\nAliquam explicabo quia quasi.	07:00:00	18:00:00	+392415917523	Elvino56@libero.it
98	209	2	61.00	Dobra voda	2	Diogene Nocerino	http://flickering-leeway.org	326.83	["/static/images/9bced8a8-84fa-4b18-b065-a1b53907d345.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg"]	Ex ab maxime sequi eveniet ullam temporibus saepe possimus.\nRepellendus eveniet dolores veritatis beatae.\nOfficiis quibusdam fugit fugiat.\nLaborum optio et tempora adipisci optio.\nDebitis similique in suscipit.	09:00:00	21:00:00	+392290680466	Delfina_Peaquin35@yahoo.it
99	210	6	142.00	Ivanova hiža	2	Fatima Puca	https://hungry-owner.com	332.88	["/static/images/3e7f5444-b782-4eec-a42a-d6c8a890d142.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg"]	Odio reiciendis suscipit assumenda inventore non quam reprehenderit dolorem laudantium.\nIllum dolorum aperiam et excepturi.\nIpsum ullam corrupti.\nVoluptate commodi laboriosam eligendi animi distinctio hic quibusdam a.	04:00:00	23:00:00	+399841371439	Evaristo.Russo38@yahoo.it
100	211	9	138.00	Glavica	2	Lucrezia Morri	https://little-hanger.net	331.41	["/static/images/60f5b463-120c-45d7-b68b-747e6a20e4f4.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg"]	Vero voluptate qui dolor nihil veniam.\nMolestiae suscipit nostrum error aliquid delectus nemo.	08:00:00	21:00:00	+399729938896	Galeazzo_Lucia@email.it
101	212	6	55.00	Trpošnjik	2	Orlando Zanatta	http://official-kick-off.net	279.10	["/static/images/9a116e20-4dbc-40ba-bdb6-ab60a9868259.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]	Laborum quasi a.\nNecessitatibus at eos eius.\nMinus provident blanditiis.	04:00:00	19:00:00	+393351453152	Bino86@yahoo.it
102	213	10	57.00	Bitorajka	2	Antelmo Di Lorenzo	http://piercing-university.net	318.07	["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg", "/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]	Repellat provident quisquam.\nError occaecati cupiditate.	05:00:00	21:00:00	+396408254243	Corinna_Bonifazi98@hotmail.com
103	214	2	124.00	Zlatko Prgin	2	Adalberta Bianchetti	https://quarrelsome-acceptance.org	320.24	["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg"]	In cupiditate doloribus tenetur quidem laudantium in.\nUllam tempora necessitatibus consequuntur.\nOfficiis voluptatibus quis repellendus dignissimos.\nConsequuntur odit veritatis ipsam.\nCorporis suscipit dolor quis temporibus.	04:00:00	21:00:00	+396138487339	Protasio49@yahoo.com
104	215	7	88.00	Prpa	2	Gonzaga Pizzo	http://lumbering-extinction.it	265.75	["/static/images/8aabafae-5cbd-4a9d-8196-a266b7d40605.jpg", "/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg"]	Cum dicta ullam velit praesentium ratione quam.\nOdit repellat delectus optio distinctio vitae sunt necessitatibus ab.\nIure ea tempora assumenda corrupti tempora illo dolorum expedita.\nAssumenda possimus corrupti.	04:00:00	21:00:00	+393956041552	Rosita.DiLorenzo80@libero.it
105	216	4	97.00	Ždrilo	2	Santina Tonelli	https://rubbery-madam.net	310.71	["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg", "/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg"]	Ex dolor nostrum voluptate natus est.\nTempora placeat veritatis esse facilis debitis.\nCommodi minima omnis tempora accusantium.	09:00:00	22:00:00	+395612448087	Erminio28@gmail.com
106	217	1	136.00	Miroslav Hirtz	2	Romoaldo Viola	http://fortunate-knee.it	327.37	["/static/images/8aabafae-5cbd-4a9d-8196-a266b7d40605.jpg", "/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg", "/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg"]	Laboriosam id cum doloremque id voluptate dolor.\nQuam ipsam dicta doloremque excepturi cumque.	09:00:00	23:00:00	+395607494619	Gabriele_Terzo@gmail.com
107	218	10	122.00	Jezerce	2	Auro Cicchetti	https://prime-user.com	295.47	["/static/images/b8909acc-6822-40ea-ac2a-6c8de7b03cf8.jpg", "/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg", "/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg", "/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg"]	Consequuntur officia nisi voluptate.\nAut eius voluptatem dolore.	01:00:00	18:00:00	+392014779558	Giulitta62@email.it
108	219	6	57.00	Ivica Sudnik	2	Ing. Enimia Mattei	https://spotless-proximal.net	311.60	["/static/images/90ed2500-1c29-4db5-ba74-36ac493363de.jpg", "/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg", "/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg", "/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg", "/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]	Odio temporibus nulla quo.\nAssumenda nam saepe suscipit doloremque provident minima.\nVelit impedit accusantium blanditiis temporibus.\nSaepe quas ex.	01:00:00	23:00:00	+394150495959	Ezechiele.Giovannelli4@libero.it
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
1	220	72	2	Italy	Ravenna		Bruni laziale
2	221	36	2	Italy	Forlì-Cesena		Rocco lido
3	222	115	2	Italy	Taranto		Sesto Alessio
4	223	117	2	Italy	Pisa		Serena a mare
5	224	257	2	Italy	Milano		Valerico nell'emilia
6	225	194	2	Italy	Catania		San Amaranto
7	226	238	2	Italy	Matera		Consiglio terme
8	227	256	2	Italy	Potenza		Macaria umbro
9	228	256	2	Italy	Barletta-Andria-Trani		Sessa umbro
10	229	97	2	Italy	Frosinone		Adelina del friuli
11	230	188	2	Italy	Pesaro e Urbino		San Pauside
12	231	106	2	Italy	Carbonia-Iglesias		San Bertolfo
13	232	43	2	Italy	Pescara		Quarto Cataldo ligure
14	233	139	2	Italy	Torino		Marzano veneto
15	234	220	2	Italy	Vercelli		San Ezio
16	235	104	2	Italy	Lecce		Quarto Catullo
17	236	213	2	Italy	Crotone		Bonini calabro
18	237	241	2	Italy	Terni		Zunino salentino
19	238	208	2	Italy	Imperia		Sesto Adelaide a mare
20	239	274	2	Italy	Reggio Emilia		Albino a mare
21	240	172	2	Italy	Enna		San Anna
22	241	228	2	Italy	Rieti		Arabella veneto
23	242	6	2	Italy	Massa-Carrara		Borgo Ivetta
24	243	98	2	Italy	Brindisi		Settimo Floriana veneto
25	244	107	2	Italy	Forlì-Cesena		Settimo Cherubino
26	245	250	2	Italy	Caltanissetta		Alamanno umbro
27	246	50	2	Italy	Cremona		Onesta salentino
28	247	35	2	Italy	Teramo		Sesto Marco
29	248	89	2	Italy	Macerata		Quarto Enea lido
30	249	97	2	Italy	Caserta		San Barbarigo veneto
31	250	60	2	Italy	Ravenna		Borgo Romola
32	251	254	2	Italy	Siracusa		Gaio calabro
33	252	38	2	Italy	Livorno		Ostuni a mare
34	253	5	2	Italy	Isernia		Quarto Albrico
35	254	129	2	Italy	Rieti		Settimo Leone
36	255	155	2	Italy	Sassari		Dragone ligure
37	256	52	2	Italy	Terni		Pariggiano sardo
38	257	54	2	Italy	Carbonia-Iglesias		Piero veneto
39	258	115	2	Italy	Napoli		Seconda nell'emilia
40	259	123	2	Italy	Foggia		Alighiero umbro
41	260	20	2	Italy	Pesaro e Urbino		Borgo Ildegarda laziale
42	261	296	2	Italy	Terni		Gulino calabro
43	262	258	2	Italy	Macerata		Petrelli veneto
44	263	161	2	Italy	Ancona		Borgo Marta
45	264	271	2	Italy	Sassari		Ciotola nell'emilia
46	265	86	2	Italy	L'Aquila		Rossini laziale
47	266	246	2	Italy	Treviso		La Sala sardo
48	267	50	2	Italy	Bologna		Sorrentino ligure
49	268	50	2	Italy	Matera		Sesto Lena laziale
50	269	269	2	Italy	Enna		Settimo Bruno veneto
51	270	68	2	Italy	Como		Sesto Gianluca nell'emilia
52	271	11	2	Italy	Belluno		San Ascanio veneto
53	272	242	2	Italy	Oristano		Viale ligure
54	273	8	2	Italy	Forlì-Cesena		Quarto Metello
55	274	290	2	Italy	Roma		Aristofane calabro
56	275	221	2	Italy	Forlì-Cesena		Lodovica nell'emilia
57	276	232	2	Italy	Torino		Sesto Ivano
58	277	182	2	Italy	Frosinone		Quarto Pierangelo salentino
59	278	212	2	Italy	Ascoli Piceno		Costantin del friuli
60	279	282	2	Italy	Ravenna		Quarto Cassio laziale
61	280	104	2	Italy	Sondrio		San Adalgisa ligure
62	281	159	2	Italy	Brindisi		Fulvia sardo
63	282	207	2	Italy	Isernia		Sesto Alberta ligure
64	283	70	2	Italy	Foggia		Sesto Dulina nell'emilia
65	284	291	2	Italy	Verona		Quarto Leonardo a mare
66	285	50	2	Italy	Pisa		Sesto Calpurnia
67	286	199	2	Italy	Arezzo		Settimo Aurelia sardo
68	287	84	2	Italy	Campobasso		Pierluigi veneto
69	288	110	2	Italy	Fermo		Settimo Gregorio
70	289	15	2	Italy	Bologna		Errante ligure
71	290	206	2	Italy	Barletta-Andria-Trani		Lauri sardo
72	291	270	2	Italy	Como		Lisa salentino
73	292	145	2	Italy	Livorno		Borgo Natalia lido
74	293	255	2	Italy	Catanzaro		Anita del friuli
75	294	177	2	Italy	Caserta		Fancello laziale
76	295	252	2	Italy	Ragusa		Pavani sardo
77	296	252	2	Italy	Asti		Sesto Anselmo
78	297	267	2	Italy	Brescia		Quarto Novella
79	298	109	2	Italy	Ravenna		Settimo Elisa veneto
80	299	143	2	Italy	Brindisi		Bonagiunta terme
81	300	84	2	Italy	Forlì-Cesena		Borgo Asella
82	301	96	2	Italy	Genova		Frasca laziale
83	302	105	2	Italy	Isernia		Fausta salentino
84	303	220	2	Italy	Ferrara		San Caronte
85	304	88	2	Italy	Lecco		Settimo Graziano calabro
86	305	69	2	Italy	Siena		Di Luca nell'emilia
87	306	252	2	Italy	Benevento		Raimondo terme
88	307	208	2	Italy	Siena		Settimo Ticone
89	308	164	2	Italy	Lucca		Carta sardo
90	309	231	2	Italy	Viterbo		Borgo Ataleo umbro
91	310	242	2	Italy	Brindisi		Borgo Cointa
92	311	70	2	Italy	La Spezia		Borgo Emidio
93	312	104	2	Italy	L'Aquila		Quarto Liborio
94	313	254	2	Italy	Arezzo		Astrid umbro
95	314	89	2	Italy	Nuoro		Sesto Federico
96	315	121	2	Italy	Pisa		Fiordaliso nell'emilia
97	316	103	2	Italy	Caserta		Maida umbro
98	317	203	2	Italy	Messina		Borgo Silvano laziale
99	318	89	2	Italy	Udine		Ciriaco sardo
100	319	210	2	Italy	Campobasso		Castaldo a mare
101	320	79	2	Italy	Teramo		Roma
102	321	262	2	Italy	Pavia		San Rina
103	322	109	2	Italy	Pesaro e Urbino		Borgo Elimena
104	323	57	2	Italy	Aosta		Santi lido
105	324	156	2	Italy	Modena		Patroclo laziale
106	325	98	2	Italy	Milano		Boris veneto
107	326	91	2	Italy	Firenze		Tomasi del friuli
108	327	93	2	Italy	Bari		Sesto Nazzareno sardo
109	328	234	2	Italy	Foggia		Borgo Bacco
110	329	30	2	Italy	Pesaro e Urbino		Asaro umbro
111	330	85	2	Italy	Verbano-Cusio-Ossola		Lombardo del friuli
112	331	34	2	Italy	Verbano-Cusio-Ossola		Ferrari ligure
113	332	181	2	Italy	Fermo		Piacentini a mare
114	333	277	2	Italy	Ancona		Quarto Ida
115	334	111	2	Italy	Pordenone		San Danilo
116	335	150	2	Italy	Catania		Borgo Gomberto
117	336	223	2	Italy	Rovigo		San Salustio
118	337	231	2	Italy	Pescara		Borgo Brunilde
119	338	141	2	Italy	Cuneo		San Virginio umbro
120	339	128	2	Italy	Cuneo		Balzano sardo
121	340	58	2	Italy	Lucca		Settimo Perla
122	341	252	2	Italy	Napoli		Settimo Diego
123	342	299	2	Italy	Sondrio		San Galdino laziale
124	343	153	2	Italy	Macerata		Pia del friuli
125	344	83	2	Italy	Bergamo		San Elda sardo
126	345	57	2	Italy	Chieti		Settimo Evodio
127	346	1	2	Italy	Enna		Parmenio del friuli
128	347	256	2	Italy	Palermo		Vianello a mare
129	348	168	2	Italy	Verona		Afro salentino
130	349	1	2	Italy	Lucca		Cristiano umbro
131	350	1	2	Italy	Ascoli Piceno		Borgo Egeo del friuli
132	351	205	2	Italy	Piacenza		Sesto Vinicio del friuli
133	352	81	2	Italy	Barletta-Andria-Trani		Cremenzio terme
134	353	103	2	Italy	Bolzano		Signorelli laziale
135	354	50	2	Italy	Lodi		Rosselli salentino
136	355	121	2	Italy	Campobasso		Bergamini lido
137	356	1	2	Italy	Siena		Quarto Cristiano
138	357	1	2	Italy	Pescara		San Algiso
139	358	37	2	Italy	Modena		Sartor laziale
140	359	1	2	Italy	Rimini		Luigia veneto
141	360	291	2	Italy	Matera		Monaci veneto
142	361	155	2	Italy	Mantova		Anastasia a mare
143	362	120	2	Italy	Latina		Settimo Aquilino a mare
144	363	218	2	Italy	Bolzano		Quarto Gennaro
145	364	37	2	Italy	Prato		Borgo Fabiano
146	365	237	2	Italy	Pordenone		Sesto Iride lido
147	366	205	2	Italy	Padova		Luisa veneto
148	367	108	2	Italy	Venezia		Lipari lido
149	368	195	2	Italy	Venezia		Borgo Rosario laziale
150	369	65	2	Italy	Roma		Borgo Fedro del friuli
151	370	76	2	Italy	Massa-Carrara		Aurelio umbro
152	371	197	2	Italy	Terni		Borgo Bacco a mare
153	372	53	2	Italy	Forlì-Cesena		Monterosso ligure
154	373	182	2	Italy	Viterbo		Quarto Dora
155	374	68	2	Italy	Ravenna		Borgo Tito umbro
156	375	141	2	Italy	Lecce		Borgo Apollonia lido
157	376	199	2	Italy	Messina		San Colmanno laziale
158	377	67	2	Italy	Chieti		Quarto Donata terme
159	378	167	2	Italy	Reggio Emilia		Semprini nell'emilia
160	379	143	2	Italy	Olbia-Tempio		Borgo Natalina lido
161	380	243	2	Italy	Caserta		San Flavio salentino
162	381	269	2	Italy	Frosinone		Lo Iacono terme
163	382	288	2	Italy	Piacenza		Ponti calabro
164	383	183	2	Italy	Firenze		Settimo Stefano
165	384	50	2	Italy	Catanzaro		Costantin ligure
166	385	30	2	Italy	La Spezia		Paladini umbro
167	386	238	2	Italy	Barletta-Andria-Trani		San Cristiana
168	387	124	2	Italy	Medio Campidano		Sesto Eloisa ligure
169	388	108	2	Italy	Massa-Carrara		Sesto Franco
170	389	134	2	Italy	Cremona		Guido ligure
171	390	136	2	Italy	Palermo		Mauri ligure
172	391	192	2	Italy	Campobasso		Borgo Amanzio
173	392	66	2	Italy	Napoli		Settimo Celso
174	393	282	2	Italy	Matera		Genesia laziale
175	394	142	2	Italy	Isernia		Cesario sardo
176	395	271	2	Italy	Caltanissetta		Pieri umbro
177	396	228	2	Italy	Bolzano		Viviana lido
178	397	143	2	Italy	Oristano		Aris lido
179	398	148	2	Italy	Perugia		Enrica veneto
180	399	86	2	Italy	Perugia		Quarto Patrizia
181	400	81	2	Italy	Novara		D'Alessandro umbro
182	401	281	2	Italy	Ascoli Piceno		Sesto Diomede
183	402	6	2	Italy	Cremona		Borgo Teodosio
184	403	93	2	Italy	Matera		Lendinara
185	404	231	2	Italy	Biella		Pipitone ligure
186	405	36	2	Italy	Como		Napoli
187	406	177	2	Italy	Salerno		Sesto Sabino del friuli
188	407	125	2	Italy	Ogliastra		Borgo Senofonte lido
189	408	121	2	Italy	Ragusa		Borgo Erico terme
190	409	188	2	Italy	Gorizia		Borgo Alessio
191	410	164	2	Italy	Pavia		San Diodoro nell'emilia
192	411	251	2	Italy	Trapani		Massari sardo
193	412	106	2	Italy	Palermo		Bruto salentino
194	413	255	2	Italy	Campobasso		Chiara terme
195	414	256	2	Italy	Perugia		Quarto Zelinda laziale
196	415	42	2	Italy	Mantova		Settimo Tosca laziale
197	416	250	2	Italy	Rieti		Fulvia lido
198	417	275	2	Italy	Trieste		Settimo Ebe
199	418	107	2	Italy	Taranto		Sesto Fiore
200	419	144	2	Italy	Enna		Quarto Gerasimo
201	420	34	2	Italy	Medio Campidano		Ursicio ligure
202	421	149	2	Italy	Como		Greta veneto
203	422	410	2	Italy	Bergamo		Basileo ligure
204	423	171	2	Italy	Viterbo		Franco umbro
205	424	88	2	Italy	Brescia		San Matroniano salentino
206	425	126	2	Italy	Latina		San Pantaleone
207	426	230	2	Italy	Genova		Settimo Abelardo
208	427	295	2	Italy	Potenza		Sesto Cirino
209	428	127	2	Italy	Varese		Platania laziale
210	429	49	2	Italy	Agrigento		Falbo terme
211	430	197	2	Italy	Aosta		Settimo Emma ligure
212	431	216	2	Italy	Napoli		Borgo Rino
213	432	9	2	Italy	Reggio Emilia		Pintus a mare
214	433	76	2	Italy	Pistoia		Luchini salentino
215	434	178	2	Italy	Viterbo		Terzo del friuli
216	435	151	2	Italy	Rovigo		Romolo calabro
217	436	191	2	Italy	Treviso		Quarto Marisa del friuli
218	437	178	2	Italy	Livorno		Borgo Giliola
219	438	293	2	Italy	Brescia		Borgo Incoronata nell'emilia
220	439	280	2	Italy	Olbia-Tempio		Fortunato laziale
221	440	111	2	Italy	Livorno		San Mercede
222	441	3	2	Italy	Roma		Borgo Ivone lido
223	442	232	2	Italy	Cuneo		Sesto Tulliano calabro
224	443	169	2	Italy	Parma		D'Urso ligure
225	444	246	2	Italy	Avellino		Borgo Saverio
226	445	249	2	Italy	Modena		Maurizio sardo
227	446	53	2	Italy	Alessandria		Sesto Delfina nell'emilia
228	447	300	2	Italy	Monza e della Brianza		Borgo Zanita calabro
229	448	31	2	Italy	Vicenza		Salomone salentino
230	449	279	2	Italy	Ascoli Piceno		Quarto Argo
231	450	154	2	Italy	Pesaro e Urbino		Sesto Golia umbro
232	451	150	2	Italy	Avellino		Patanè a mare
233	452	212	2	Italy	Ragusa		Malerba ligure
234	453	63	2	Italy	Nuoro		Lorenzo laziale
235	454	134	2	Italy	Genova		Bodini calabro
236	455	116	2	Italy	Avellino		Loiacono laziale
237	456	36	2	Italy	Imperia		Degano ligure
238	457	98	2	Italy	Cremona		San Teodoro a mare
239	458	260	2	Italy	Reggio Calabria		Borgo Bonaldo umbro
240	459	277	2	Italy	Potenza		Quarto Amedeo nell'emilia
241	460	70	2	Italy	Sondrio		Teodolinda lido
242	461	28	2	Italy	Lecce		Saffo ligure
243	462	241	2	Italy	Biella		San Illuminato sardo
244	463	36	2	Italy	Gorizia		Settimo Dante
245	464	212	2	Italy	Cremona		Cassandra terme
246	465	278	2	Italy	Ragusa		Borgo Susanna a mare
247	466	196	2	Italy	Sondrio		Quarto Venerio nell'emilia
248	467	39	2	Italy	Belluno		Lena del friuli
249	468	77	2	Italy	Ancona		Santarsia lido
250	469	9	2	Italy	Reggio Emilia		Settimo Giuda
251	470	96	2	Italy	Vibo Valentia		Galante calabro
252	471	113	2	Italy	Matera		Flaminia umbro
253	472	193	2	Italy	Venezia		Di Dio salentino
254	473	36	2	Italy	Brescia		Loreto sardo
255	474	156	2	Italy	Terni		Cirillo terme
256	475	121	2	Italy	Bolzano		Geronimo a mare
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address, altitude) FROM stdin;
1	0	0101000020E610000043D95E8288A91C40720950EB278D4640	Start Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
2	0	0101000020E610000051A7B8816D921C408D966B20C98C4640	End Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
3	0	0101000020E6100000C668CC0D4EA81C40DA8DB03B2C8D4640	Ref Point 1		1256.85
4	0	0101000020E6100000116FE90D01A21C4022DFF1622B8D4640	Ref Point 2		1283.61
5	0	0101000020E61000004337FB03E5161B401CEBE2361A844640	Start Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
6	0	0101000020E61000001092054CE0161B401FD8F15F20844640	End Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
7	0	0101000020E6100000910F7A36ABCE1C4029AF95D05D4C4640	Start Point	Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia	\N
8	0	0101000020E6100000FC8EE1B19FB51C40B0FECF61BE4E4640	End Point	Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia	\N
9	0	0101000020E6100000000060A24D751C40000028D7DB594640	Start Point	Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia	\N
10	0	0101000020E61000000000A08E3B6A1C400000D8486C5C4640	End Point	Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia	\N
11	0	0101000020E6100000D218ADA3AA112140B7291E17D5124740	Start Point	Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia	\N
12	0	0101000020E61000001764CBF2751121406AFAEC80EB144740	End Point	Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia	\N
13	0	0101000020E610000000004078111A1C400000981E08854640	Start Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
14	0	0101000020E61000000000A0281F1A1C400000E05411854640	End Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
15	0	0101000020E610000000004078111A1C400000981E08854640	Start Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
16	0	0101000020E61000000000A0281F1A1C400000E05411854640	End Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
17	0	0101000020E610000058CB9D9960C81B408731E9EFA59C4640	Start Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
18	0	0101000020E61000003BE0BA6246C81B401E34BBEEAD9C4640	End Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
19	0	0101000020E61000007EE4D6A4DBC21B40147AFD497C9C4640	fountain		2027.00
20	0	0101000020E6100000B7B8C667B2BF1B4090A4A487A19B4640	Peak		2131.00
21	0	0101000020E6100000E449D23593FF1A4008B0C8AF1F784640	Start Point	Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia	\N
22	0	0101000020E6100000E449D23593FF1A4008B0C8AF1F784640	End Point	Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia	\N
23	0	0101000020E6100000010060133FE51C400000DC629AA64640	Start Point	Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia	\N
24	0	0101000020E61000000100E07E80F41C400000C0086CA54640	End Point	Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia	\N
25	0	0101000020E61000000000A0E235A31C40000090BAAD5A4640	Start Point	Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia	\N
26	0	0101000020E61000000000A03601A21C40000078DBA45A4640	End Point	Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia	\N
27	0	0101000020E61000000000601346EE1B4000006C0D81494640	Start Point	SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia	\N
28	0	0101000020E6100000000000063BEE1B4000001C7B81494640	End Point	SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia	\N
29	0	0101000020E6100000000020F7999B1C40000018F79E594640	Start Point	Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
30	0	0101000020E61000000000803E6C7C1C400000004B28584640	End Point	Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
31	0	0101000020E610000001002004C9F31E400000609288234640	Start Point	Pigna - Gardiola, Chiusa di Pesio, Cuneo, Piemonte, 12088, Italia	\N
32	0	0101000020E6100000000000DC44CF1E400000B4502D214640	End Point		\N
33	0	0101000020E61000002F3196E997781C408F8D40BCAE594640	Start Point	Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
34	0	0101000020E61000009C8A54185B781C4057B08D78B2594640	End Point	Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
35	0	0101000020E61000000000209E8E4B1C4000003C6BAE844640	Start Point	Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia	\N
36	0	0101000020E6100000000080AFFC7A1C4000004CCD1C864640	End Point	Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia	\N
37	0	0101000020E6100000000000A020B91C40000074E3C0494640	Start Point	Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia	\N
38	0	0101000020E61000000000C0CE5A9F1C400000B06F46474640	End Point	Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia	\N
39	0	0101000020E610000000000030C0F21C400000005015934640	Start Point	Alpe Tulivit, Condove, Torino, Piemonte, Italia	\N
40	0	0101000020E61000000000C02BE9E01C400000442ED1964640	End Point	Alpe Tulivit, Condove, Torino, Piemonte, Italia	\N
41	0	0101000020E61000000000E04399051F40000078D59A1F4640	Start Point	Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia	\N
42	0	0101000020E61000000000A0B2D4041F400000A07A911F4640	End Point	Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia	\N
43	0	0101000020E610000000002073E0601C4000001C93C2594640	Start Point	Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia	\N
44	0	0101000020E61000000000A01680701C400000C08D37554640	End Point	Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia	\N
45	0	0101000020E61000000000C09D43D520400000CC2FB7354740	Start Point	Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia	\N
46	0	0101000020E61000000000C09D43D520400000CC2FB7354740	End Point	Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia	\N
47	0	0101000020E6100000E4BD6A65C2D720401A506F46CD114740	Start Point	Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia	\N
48	0	0101000020E61000005665DF15C1D72040C6C1A563CE114740	End Point	Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia	\N
49	0	0101000020E61000005F9A22C0E96520406C76A4FACE554640	Start Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
50	0	0101000020E61000002368CC24EA652040CC7EDDE9CE554640	End Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
51	0	0101000020E61000006B662D05A46D20401557957D57564640	Ref Point 1		482.53
52	0	0101000020E610000024D236FE44652040813D26529A554640	Ref Point 2		242.59
53	0	0101000020E6100000A06F0B96EA221D4008E6E8F17B7B4640	Start Point	Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia	\N
54	0	0101000020E61000006DE7FBA9F1221D40EF552B137E7B4640	End Point	Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia	\N
55	0	0101000020E61000009F02603C83762540D61EF64201F14640	Start Point	Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
56	0	0101000020E610000088F19A5775762540910E0F61FCF04640	End Point	Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
57	0	0101000020E6100000F435CB65A343274097530262122E4640	Start Point	5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia	\N
58	0	0101000020E61000006BD44334BA43274097530262122E4640	End Point	5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia	\N
59	0	0101000020E6100000EAE923F0877F2540EE7C3F355EE04640	Start Point	Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia	\N
60	0	0101000020E610000053CF8250DE7F254040A19E3E02E14640	End Point	Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia	\N
61	0	0101000020E610000033FE7DC6853B274059349D9D0C264640	Start Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
62	0	0101000020E61000005859DB148F3B2740001DE6CB0B264640	End Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
63	0	0101000020E610000033FE7DC6853B274059349D9D0C264640	Start Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
64	0	0101000020E61000005859DB148F3B2740001DE6CB0B264640	End Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
65	0	0101000020E6100000E82E89B3223A254036CB65A373AC4640	Start Point	Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia	\N
66	0	0101000020E61000008C9DF0129C3A2540486AA16472AC4640	End Point	Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia	\N
67	0	0101000020E610000088DA368C82402540AC02B5183CAC4640	Ref Point 1		130.12
68	0	0101000020E6100000A06B5F402F44254016C1FF56B2AB4640	Ref Point 2		139.74
69	0	0101000020E6100000527FBDC2824B2540151C5E1091AA4640	Fontain		107.32
70	0	0101000020E61000001C98DC28B2361C4032FFE89B34894640	Start Point	Cima Ciantiplagna, Strada militare del Colle dell'Assietta, Bergerie dell'Assietta, Usseaux, Torino, Piemonte, Italia	\N
71	0	0101000020E6100000EE5C18E9450D1C402FFB75A73B894640	End Point	Cima Ciantiplagna, Strada militare del Colle dell'Assietta, Bergerie dell'Assietta, Usseaux, Torino, Piemonte, Italia	\N
72	0	0101000020E6100000A0DCB6EF518725409E7E501729E44640	Start Point	Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia	\N
73	0	0101000020E610000055DD239BAB86254016342DB132E44640	End Point	Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia	\N
74	0	0101000020E6100000C3F5285C8FE21F408C9FC6BDF9894640	Start Point	Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia	\N
75	0	0101000020E610000001F8A75489E21F40F030ED9BFB894640	End Point	Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia	\N
76	0	0101000020E6100000B282DF86187F20400B47904AB1FF4640	Start Point	Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia	\N
77	0	0101000020E610000012842BA0508720400F48C2BE9D004740	End Point	Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia	\N
78	0	0101000020E6100000EAE8B81AD9E520408813984EEBFA4640	Start Point	Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia	\N
79	0	0101000020E6100000EAE8B81AD9E520408813984EEBFA4640	End Point	Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia	\N
80	0	0101000020E61000006EFC89CA86A52040D87DC7F0D87D4640	Start Point	Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia	\N
81	0	0101000020E61000009E0B23BDA8A52040B1A371A8DF7D4640	End Point	Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia	\N
82	0	0101000020E61000009F3E027FF83920409E245D33F9804640	Start Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
83	0	0101000020E610000099F56228273A20408DEDB5A0F7804640	End Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
84	0	0101000020E6100000880E81238136264090847D3B89844640	Start Point	Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia	\N
85	0	0101000020E6100000B6132521913626406AFB57569A844640	End Point	Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia	\N
86	0	0101000020E61000007A17EFC7ED37264008C89750C1854640	Ref Point 1		22.75
87	0	0101000020E61000009AB0FD648C4F26405C7171546E844640	Ref Point 2		35.55
88	0	0101000020E61000001899805F23F91C402A38BC20227B4640	Start Point	Pralamar, Pinasca, Torino, Piemonte, 10063, Italia	\N
89	0	0101000020E610000001344A97FEF51C40BB438A01127D4640	End Point	Pralamar, Pinasca, Torino, Piemonte, 10063, Italia	\N
90	0	0101000020E6100000A5660FB402431D4025E82FF488754640	Start Point	Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia	\N
91	0	0101000020E61000008D093197543D1D405E6919A9F7764640	End Point	Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia	\N
92	0	0101000020E6100000E14389963C762540E55FCB2BD7F14640	Start Point	Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
93	0	0101000020E6100000C2DF2F664B7625408C14CAC2D7F14640	End Point	Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
94	0	0101000020E6100000768D96033D14284038BA4A77D7D54540	Start Point	Via Poggiolino delle Viole, Castellare, Pieve Santo Stefano, Arezzo, Toscana, 52036, Italia	\N
95	0	0101000020E610000058E6ADBA0E4D28404546072461D34540	End Point	Bike Help, Pian della Capanna, Pieve Santo Stefano, Arezzo, Toscana, Italia	\N
96	0	0101000020E6100000C1CAA145B60320407715527E52B94640	Start Point	26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia	\N
97	0	0101000020E6100000A4C2D84290032040E8BCC62E51B94640	End Point	26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia	\N
98	0	0101000020E61000003B54539275B82840BF7D1D3867164740	Start Point	Municipio, Via Roma, Torres, Tignes, Pieve d'Alpago, Alpago, Belluno, Veneto, 32010, Italia	\N
99	0	0101000020E6100000D6C8AEB48CB42840F51263997E154740	End Point	Municipio, Via Roma, Torres, Tignes, Pieve d'Alpago, Alpago, Belluno, Veneto, 32010, Italia	\N
100	0	0101000020E61000009296CADB11862840B91803EB383C4740	Start Point	Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia	\N
101	0	0101000020E6100000F94D61A582BA28401363997E89364740	End Point	Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia	\N
102	0	0101000020E6100000B0389CF9D5B4254010E9B7AF03F14640	Start Point	Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
170	0	0101000020E610000052E2299ABDFA2840518B1C7D27114740	Rifugio Semenza	Tambre, Veneto, Italy	\N
103	0	0101000020E61000009414580053762540A04FE449D2F14640	End Point	Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
104	0	0101000020E6100000B0389CF9D5B4254010E9B7AF03F14640	Peak		67.09
105	0	0101000020E6100000A9C0C936708725400936AE7FD7EF4640	Lake		712.07
106	0	0101000020E6100000D576137CD3742640A9BF5E61C1A34540	Start Point	4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia	\N
107	0	0101000020E61000001A19E42EC274264009FCE1E7BFA34540	End Point	4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia	\N
108	0	0101000020E61000003D98141F9F201C409A5FCD01827B4640	Start Point	Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia	\N
109	0	0101000020E6100000CC7A319413FD1B40BD361B2B317D4640	End Point	Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia	\N
110	0	0101000020E61000003BE466B801472840A2427573F12B4640	Start Point	Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia	\N
111	0	0101000020E610000029CFBC1C76472840EA3F6B7EFC2B4640	End Point	Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia	\N
112	0	0101000020E61000002D64979723B62440C66F2527958D4740	Edmund-Graf-Hütte	6574 Pettneu am Arlberg, Tyrol, Austria	\N
113	0	0101000020E6100000455BF9D0380E2A4056DBD4F478794740	Dr.Hernaus-Stöckl	9020 Klagenfurt, Kärnten, Austria	\N
114	0	0101000020E61000003AD4CD22968A2D406DAF4FF575F14740	Amstettner Hütte	3340 Waidhofen an der Ybbs, Niederösterreich, Austria	\N
115	0	0101000020E61000003470C88518362B404F23C0A11DEA4740	Hochleckenhaus	4853 Steinbach am Attersee, Oberösterreich, Austria	\N
116	0	0101000020E6100000745CA7EA5C3230400E95C9F10B114840	Kampthalerhütte	2384 Breitenfurt bei Wien, Niederösterreich, Austria	\N
117	0	0101000020E610000059E5350827672B402FB2862AC2D34740	Lambacher Hütte	4822 Bad Goisern, Oberösterreich, Austria	\N
118	0	0101000020E610000019FDD2643FA62340662869A087B24740	Lustenauer Hütte	6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria	\N
119	0	0101000020E610000036849931B0F52A4014BD78F039C44740	Gablonzer Hütte	4825 Gosau-Hintertal, Oberösterreich, Austria	\N
120	0	0101000020E6100000202F5A3629BF3740D489BAC5B2144340	Katafygio «Flampouri»	136 72 Acharnes, Attica region, Greece	\N
121	0	0101000020E6100000103E4BA24D3F2B40F731169C1AC04740	Simonyhütte	4830 Hallstatt, Oberösterreich, Austria	\N
122	0	0101000020E610000033190145D5182740BF9048EBDFA04740	Vinzenz-Tollinger-Hütte	6060 Hall in Tirol, Tyrol, Austria	\N
123	0	0101000020E61000001F1E0B5901B82E4091BFCBF1EAB34740	Ottokar-Kernstock-Haus	8600 Bruck an der Mur, Steiermark, Austria	\N
124	0	0101000020E610000018E4FB977DBF2A40D6A3B4422D754740	Reisseckhütte	9814 Mühldorf, Mölltal, Kärnten, Austria	\N
125	0	0101000020E61000007B116DC7D4A52540C0401020436D4740	Vernagthütte	Austria	\N
126	0	0101000020E6100000286211C30EF323407EC9C6832D884740	Wormser Hütte	Austria	\N
127	0	0101000020E6100000999CDA19A60E24406CD097DEFEA04740	Biberacher Hütte	Austria	\N
128	0	0101000020E610000007BC276AC4133740DDF934DDA1A84440	Katafygio «1777»	620 55 Kerkini, Central Macedonia region, Greece	\N
129	0	0101000020E6100000D5AF743E3C0B2A40E6E786A6EC704840	Hochwaldhütte	Germany	\N
130	0	0101000020E6100000C2FBAA5CA8EC19408FC536A968544940	Kölner Eifelhütte	Germany	\N
131	0	0101000020E6100000323CF6B358D223401763601DC7794740	Madrisahütte	Austria	\N
132	0	0101000020E6100000313F373465472640CDC98B4CC07F4740	Dresdner Hütte	Austria	\N
133	0	0101000020E6100000CDCCCCCCCC6C24403E07962364A84740	Fiderepasshütte	Germany	\N
134	0	0101000020E6100000B727486C77172440A9DDAF027C9B4740	Göppinger Hütte	Austria	\N
135	0	0101000020E6100000A379008BFC622340C7629B54348A4740	Oberzalimhütte	Austria	\N
136	0	0101000020E610000013B70A62A0932740B3B45373B99D4740	Rastkogelhütte	Austria	\N
137	0	0101000020E61000009D2D20B41E0E2440D54F49E70DC24740	Ansbacher Skihütte im Allgäu	Germany	\N
138	0	0101000020E610000009E066F16249244097E13FDD408F4740	Kaltenberghütte	Austria	\N
139	0	0101000020E61000000AD7A3703D0A2640E277D32D3B944740	Schweinfurter Hütte	Austria	\N
140	0	0101000020E61000006DC438245A213640DA172BC5E9574340	Katafygio «Vardousion»	330 53 Delphi, Central Greece region, Greece	\N
141	0	0101000020E6100000630F270F8F472D40336D62F5852D4740	Kocbekov dom na Korošici	3334 Luče, Mozirje, Slovenia	\N
142	0	0101000020E6100000D1F5D08072062D40D25C9F20CE114740	Planinski dom Rašiške cete na Rašici	1211 Ljubljana, Šmartno, Slovenia	\N
143	0	0101000020E6100000F70F966F85592C40971550C935374740	Prešernova koca na Stolu	4274 Žirovnica, Slovenia	\N
144	0	0101000020E6100000AA5C8F5FCB372E408E6CD71919184740	Planinski dom na Mrzlici	3302 Griže, Slovenia	\N
145	0	0101000020E6100000651A4D2EC6802C40577A6D3656FC4640	Koca na Planini nad Vrhniko	1360 Vrhnika, Slovenia	\N
146	0	0101000020E6100000245DF94DDD322C4077DAB7E6D0144740	Zavetišce gorske straže na Jelencih	0, -, Slovenia	\N
147	0	0101000020E6100000313F3734656F2E406F7F2E1A32264740	Planinski dom na Gori	Šentjungert, 3310 Žalec, Slovenia	\N
148	0	0101000020E610000098F2E7FC90A22B40C7CBA2C928274740	Bregarjevo zavetišce na planini Viševnik	4265 Bohinjsko jezero, Slovenia	\N
149	0	0101000020E610000091860959CC862B401635F33FD4244740	Koca pod Bogatinom	4265 Bohinjsko jezero, Slovenia	\N
150	0	0101000020E6100000678B3942E5992B40007F639573334740	Pogacnikov dom na Kriških podih	5232 Soca, Slovenia	\N
151	0	0101000020E610000008F580BBE4CC2D402A9C0F95E7344740	Dom na Smrekovcu	3325 Šoštanj, Slovenia	\N
152	0	0101000020E610000073F6CE68AB32194060E811A3E77C4640	Refuge Du Chatelleret	38520 Saint Christophe En Oisans, Isère, France	\N
153	0	0101000020E610000084622B685AF218408177F2E9B16B4640	Refuge De Chalance	5800 La Chapelle En Valgaudemar, Hautes-Alpes, France	\N
154	0	0101000020E6100000963D096CCE711940AE7FD767CE6A4640	Refuge Des Bans	5290 Vallouise, Hautes-Alpes, France	\N
155	0	0101000020E6100000DEAB5626FC52DBBFAED689CBF16A4540	Refuge De Pombie	65400 Laruns, Pyrénées-Atlantiques, France	\N
156	0	0101000020E6100000A69C2FF65E7CD2BFA9F92AF9D86D4540	Refuge De Larribet	65400 Arrens, Marsous, Hautes-Pyrénées, France	\N
157	0	0101000020E61000009CA6CF0EB84E1B401232906797C34640	Refuge Du Mont Pourri	73210 Peisey Nancroix, Savoie, France	\N
158	0	0101000020E6100000C712D6C6D8E91A40BF81C98D222D4740	Refuge De La Dent D?Oche	74500 Bernex, Haute-Savoie, France	\N
159	0	0101000020E6100000BEBDCA2243F820405620D41E27544740	Bergseehütte SAC	Uri, Switzerland	\N
160	0	0101000020E6100000CDD5732CA96D1E40F591820D5C054740	Bivouac au Col de la Dent Blanche CAS	Wallis, Switzerland	\N
161	0	0101000020E610000060F1FE571F0C2140D6BA5B328C564740	Salbitschijenbiwak SAC	Uri, Switzerland	\N
162	0	0101000020E610000084EAC5BE53052140F224048A5C664740	Spannorthütte SAC	Uri, Switzerland	\N
163	0	0101000020E6100000827FB24EBCB71E406113E452EB0C4740	Cabane Arpitettaz CAS	Wallis, Switzerland	\N
164	0	0101000020E61000008A75AA7CCF48E4BF588BF447BD614540	Refugio De Lizara	22730, Aragón, Spain	\N
165	0	0101000020E6100000AE56C01909F8E43F58DB5E1CA6064540	Albergue De Montfalcó	22585 Tolva, Aragón, Spain	\N
166	0	0101000020E61000000A4CFFBF1E610AC08B780953B6904240	El Molonillo/Peña Partida	18160 Güejar Sierra, Andalucía, Spain	\N
167	0	0101000020E610000029110100A92D0AC0F39F054F27844240	La Campiñuela	18417 Trévelez, Andalucía, Spain	\N
168	0	0101000020E61000008E79782A3BCC3440BEAE152301FF4440	Titov Vrv	Tetovo, Municipality of Tetovo, North Macedonia	\N
169	0	0101000020E6100000A2EC2DE57C212B40C7F143A5113D4540	Rifugio Franchetti	Pietracamela, Abruzzo, Italy	\N
171	0	0101000020E6100000A197F67244A31F40313D06D094EE4640	Rifugio Città di Mortara 	Alagna Valsesia, Piemonte, Italy	\N
172	0	0101000020E61000006E39F29B1D242040AB1ED555260C4740	Rifugio Andolla	Antrona Schieranico, Piemonte, Italy	\N
173	0	0101000020E61000000AD80E46ECAB2440B70BCD751AFF4540	Rifugio Forte dei Marmi	Stazzema, Toscana, Italy	\N
174	0	0101000020E6100000A88B14CAC2CF284038D66AB4C1504740	Rifugio Berti	Comelico Superiore, Veneto, Italy	\N
175	0	0101000020E610000071B43E4052BB2B406FE70CD649CF4640	Rifugio Premuda	San Dorligo della Valle, Friuli Venezia Giulia, Italy	\N
176	0	0101000020E61000006CCF2C0950C32240191BBAD91FF84640	Rifugio Elisa	Mandello del Lario, Lombardia, Italy	\N
177	0	0101000020E6100000A5BDC11726B31F40F90FE9B7AFFB4640	Rifugio CAI Saronno	Macugnaga, Piemonte, Italy	\N
178	0	0101000020E610000098DD9387857A2640A930B610E4584740	Rifugio Picco Ivigna	Scena, Trentino Alto Adige, Italy	\N
179	0	0101000020E61000003AE97DE36B8F1C404AEF1B5F7B8A4640	Rifugio Toesca	Bussoleno, Piemonte, Italy	\N
180	0	0101000020E6100000A913D044D8E02040382D78D1570C4740	Rifugio Al Cedo	Santa Maria Maggiore, Piemonte, Italy	\N
181	0	0101000020E6100000449D5ECE11661F4009ED8B3A29F34640	Capanna Gnifetti	Gressoney La Trinitè, Valle d?Aosta, Italy	\N
182	0	0101000020E6100000B8AE9811DE3E1E403A048E041AFC4640	Rifugio Aosta	Bionaz, Valle d?Aosta, Italy	\N
183	0	0101000020E6100000BBB31B22135525408EA8F523EA374740	Rifugio Cevedale	Pejo, Trentino Alto Adige, Italy	\N
184	0	0101000020E61000000D33349E08722340F0A485CB2A204740	Rifugio Ponti	Val Masino, Lombardia, Italy	\N
185	0	0101000020E6100000C46D7E0DD2B125405364085B47134740	Rifugio XII Apostoli	Stenico, Trentino Alto Adige, Italy	\N
186	0	0101000020E61000009F1C058882591B40DDD1FF722DE24640	Rifugio Elisabetta Soldini	Courmayeur, Valle d?Aosta, Italy	\N
187	0	0101000020E610000061D57994804F25409903A4C1291F4740	Rifugio Denza	Vermiglio, Trentino Alto Adige, Italy	\N
188	0	0101000020E61000000C1F115322F92A40338AE596560F4540	Rifugio Fonte Tavoloni 	Ovindoli, Abruzzo, Italy	\N
189	0	0101000020E610000037C2A2224EBF2840F2ED5D83BE4E4740	Rifugio Carducci	Auronzo di Cadore, Veneto, Italy	\N
190	0	0101000020E61000006FA53220D64E26400DE02D90A0044740	Rifugio Bindesi	Trento, Trentino Alto Adige, Italy	\N
191	0	0101000020E610000001C11C3D7ECB2D40C670D0B9365A4640	Mountain hut Miroslav Hirtz	53287 Jablanac, Ličko-senjska županija, Croatia	\N
192	0	0101000020E6100000398485EEED352C4098331D324C154740	Koca na Blegošu	4224 Gorenja vas, Slovenia	\N
193	0	0101000020E610000040F850A225BF1F400F441669E2594940	Wittener Hütte	Germany	\N
194	0	0101000020E610000000FDBE7FF3AA25409A99999999694740	Hochjoch-Hospiz	Austria	\N
195	0	0101000020E6100000D7A02FBDFD412640CDCCCCCCCCB44740	Meilerhütte	Germany	\N
196	0	0101000020E610000050C422861DA628406E85B01A4BC64740	Gaudeamushütte	Austria	\N
197	0	0101000020E6100000179CC1DF2F961940D5EB1681B15C4940	Rheydter Hütte	Germany	\N
198	0	0101000020E6100000FB66518EB8562C4057E883656C744940	Sektionshütte Krippen	Germany	\N
199	0	0101000020E61000001F7A839D234C2C40B45EF68814A34740	Neunkirchner Hütte	2620 Neunkirchen, Steiermark, Austria	\N
200	0	0101000020E61000009CE379FC2043E7BF8FC536A9682C4540	Refugio De Riglos	22808, Aragón, Spain	\N
201	0	0101000020E6100000563D4FC4941A2140EBB308E997564740	Salbithütte SAC	Uri, Switzerland	\N
202	0	0101000020E61000001D55C855B23A2040B8EB64DCCE424740	Finsteraarhornhütte SAC	Wallis, Switzerland	\N
203	0	0101000020E6100000DEFD765E1AE71D4038777A52B2FE4640	Cabane des Vignettes CAS	Wallis, Switzerland	\N
204	0	0101000020E6100000E769EE0B84312040FBE19FAF02504740	Glecksteinhütte SAC	Bern, Switzerland	\N
205	0	0101000020E6100000752B5D3C5F152240D9971BDB51454740	Länta-Hütte SAC	Graubünden, Switzerland	\N
206	0	0101000020E610000055ADDEFA26292040BAB9F14860214740	Monte-Leone-Hütte SAC	Wallis, Switzerland	\N
207	0	0101000020E6100000557F0CE8F9C222408F373B25D26E4740	Ringelspitzhütte SAC	Graubünden, Switzerland	\N
208	0	0101000020E6100000A4AA09A2EE0334408E23D6E253104640	Na poljanama Maljen	Maljen, Serbia	\N
209	0	0101000020E6100000A9DE1AD82A313440C5E6E3DA50114640	Dobra voda	Suvobor, Serbia	\N
210	0	0101000020E61000007250C24CDBFF2E402D095053CBC64640	Ivanova hiža	Karlovac town environment, Karlovačka, Croatia	\N
211	0	0101000020E6100000C6DCB5847CC02F40C746205ED7EB4640	Glavica	Medvednica, City of Zagreb, Croatia	\N
212	0	0101000020E6100000FFEC478AC8B83040D3F6AFAC34BD4540	Trpošnjik	Mosor, Splitsko-dalmatinska, Croatia	\N
213	0	0101000020E6100000C217265305932D40C4CE143AAFA54640	Bitorajka	Bitoraj, Primorsko-goranska, Croatia	\N
214	0	0101000020E6100000AB09A2EE0360304006D847A7AE084640	Zlatko Prgin	Dinara, Šibensko-kninska, Croatia	\N
215	0	0101000020E6100000D3872EA86F492E405C8FC2F528444640	Prpa	Velebit, Ličko-senjska, Croatia	\N
216	0	0101000020E6100000787FBC57AD5C2E408BFD65F7E43D4640	Ždrilo	Velebit, Ličko-senjska, Croatia	\N
217	0	0101000020E610000086032159C0F42D40B21188D7F59B4640	Miroslav Hirtz	Velika Kapela, Primorsko-goranska, Croatia	\N
218	0	0101000020E6100000A31EA2D11DAC3140462575029AC04640	Jezerce	Papuk, Požeško-slavonska, Croatia	\N
219	0	0101000020E61000003EE8D9ACFA4C2F405F0CE544BBE24640	Ivica Sudnik	Samoborska gora, Zagrebačka, Croatia	\N
220	0	0101000020E6100000AD3BCC4D8A7D2840CBDF185D39124640		69 Via Modica, Bruni laziale, Italy	\N
221	0	0101000020E6100000AF5E454607602340EDF2AD0FEB6B4440		243 Borgo Ilva, Rocco lido, Italy	\N
222	0	0101000020E610000050BA3EBD63AA2840D5DBB0B7DE294640		2 Strada Delizia, Sesto Alessio, Italy	\N
223	0	0101000020E6100000E7204322C8042640F6AEE6A507F54540		1 Strada Bacci, Serena a mare, Italy	\N
224	0	0101000020E61000009F11B6E919B02140ABAC12D154364640		782 Borgo Italia, Valerico nell'emilia, Italy	\N
225	0	0101000020E61000009EBFBFF7ED2224402DAAEA8ABEE84640		56 Rotonda Quinziano, San Amaranto, Italy	\N
226	0	0101000020E6100000FF209221C76E274017844DF8002D4640		4 Piazza Vittori, Consiglio terme, Italy	\N
227	0	0101000020E6100000C2B28817FA8E2340D5809C8B1AB04640		8 Via Argiolas, Macaria umbro, Italy	\N
228	0	0101000020E6100000107BFC3960762540600A6A53D0274740		51 Piazza Vito, Sessa umbro, Italy	\N
229	0	0101000020E6100000CF5AC0BAE0462B40B9ED314745E34640		8 Borgo Grandi, Adelina del friuli, Italy	\N
230	0	0101000020E610000048B42E7FCFC525403379B93E620B4740		790 Rotonda Concas, San Pauside, Italy	\N
231	0	0101000020E6100000E066F16261B42A4084E85AC52CF04640		365 Contrada Aimone, San Bertolfo, Italy	\N
232	0	0101000020E610000021263CFC90E62840C604EBEEF0074640		8 Piazza Errico, Quarto Cataldo ligure, Italy	\N
233	0	0101000020E6100000CFB81567B161274070CFF3A78DA74640		6 Piazza Tedeschi, Marzano veneto, Italy	\N
234	0	0101000020E6100000C1F979F8D76F224054F0CAE48AB04640		28 Via Radolfo, San Ezio, Italy	\N
235	0	0101000020E61000008248D0A975782B40741200D2EDC94640		960 Borgo Alvise, Quarto Catullo, Italy	\N
236	0	0101000020E6100000918B208436172940630E828E564E4540		9 Via Dacio, Bonini calabro, Italy	\N
237	0	0101000020E610000023484A1F5F572240D37CDF09072C4640		99 Via Palumbo, Zunino salentino, Italy	\N
238	0	0101000020E6100000A09339F130542140F7DBE8ADCB384740		98 Via Baroni, Sesto Adelaide a mare, Italy	\N
239	0	0101000020E6100000068A0E37967A2540DB1FDE29D3664540		924 Piazza Zefiro, Albino a mare, Italy	\N
240	0	0101000020E6100000CF59B09EA4CE2640F18288D4B4434740		03 Rotonda Petrella, San Anna, Italy	\N
241	0	0101000020E6100000C153C8957A5A26407541D8840FE14640		8 Contrada Berengario, Arabella veneto, Italy	\N
242	0	0101000020E61000008577B988EF302140BAD3426E2B3D4740		25 Borgo Edelberga, Borgo Ivetta, Italy	\N
243	0	0101000020E6100000589643E6259E2540B49487E013DD4540		8 Contrada Aratone, Settimo Floriana veneto, Italy	\N
244	0	0101000020E6100000249E4720B9702840B1F84D61A5124640		4 Via Bortolo, Settimo Cherubino, Italy	\N
245	0	0101000020E61000008B89CDC7B55926407EB4EED57D084740		381 Strada Randazzo, Alamanno umbro, Italy	\N
246	0	0101000020E6100000D8B969334EEB27402CF8C84164804540		4 Piazza Cleonico, Onesta salentino, Italy	\N
247	0	0101000020E610000061D394AEAAD4204012A6835039FC4640		028 Rotonda Acquaviva, Sesto Marco, Italy	\N
248	0	0101000020E6100000B53C6AA741AC27408F0134A550B84640		32 Strada Reina, Quarto Enea lido, Italy	\N
249	0	0101000020E6100000F78CE9AE91D52240ED48F59D5FE54640		17 Via Mattia, San Barbarigo veneto, Italy	\N
250	0	0101000020E6100000626DE75663902B4097FA1E9A1ED44640		9 Incrocio Ventura, Borgo Romola, Italy	\N
251	0	0101000020E6100000FFF9C78C011B2640DD706946501E4740		0 Piazza Minerva, Gaio calabro, Italy	\N
252	0	0101000020E61000009C363EEEB67E2740BC2363B5F9BA4640		1 Incrocio Baraldi, Ostuni a mare, Italy	\N
253	0	0101000020E61000008A9466F3387C1E402B31CF4A5AE74640		439 Strada Crocefisso, Quarto Albrico, Italy	\N
254	0	0101000020E6100000F22895F084D22A404082870E26ED4440		05 Incrocio Sandro, Settimo Leone, Italy	\N
255	0	0101000020E61000007E1D386744712240C878399105CC4640		3 Piazza Ermes, Dragone ligure, Italy	\N
256	0	0101000020E610000020D84C1993812240A475AFEEB30D4740		4 Via Nanni, Pariggiano sardo, Italy	\N
257	0	0101000020E6100000242136FD7E2E26406E2AF7A7F91A4740		03 Incrocio Zanella, Piero veneto, Italy	\N
258	0	0101000020E6100000485E8C37E8B927408860C1A2C7CA4640		69 Borgo Narciso, Seconda nell'emilia, Italy	\N
259	0	0101000020E61000005E961BB1BB751E407379BD4571EF4640		155 Incrocio Antonio, Alighiero umbro, Italy	\N
260	0	0101000020E6100000BE2ABC708CED2340366964A1E7DD4640		8 Piazza Serafino, Borgo Ildegarda laziale, Italy	\N
261	0	0101000020E610000053B4722F302B2540E4DC26DC2B4D4740		07 Strada Saponaro, Gulino calabro, Italy	\N
262	0	0101000020E61000009A97C3EE3B32254052B241CB5F574640		720 Borgo Ceccarelli, Petrelli veneto, Italy	\N
263	0	0101000020E6100000622D3E05C0782840F70BD17C29DE4640		2 Contrada Quirino, Borgo Marta, Italy	\N
264	0	0101000020E6100000B05758703F782440773A4668BAB84640		5 Contrada Neiva, Ciotola nell'emilia, Italy	\N
265	0	0101000020E610000011D20957F63B2640E6B8AEF3CA084740		147 Incrocio Schiavon, Rossini laziale, Italy	\N
266	0	0101000020E61000004704E3E0D2692C408514F2F741A74640		6 Piazza Fortugno, La Sala sardo, Italy	\N
267	0	0101000020E61000002F0ACC54D2C8264038FE9F1E36CA4640		587 Incrocio Salomone, Sorrentino ligure, Italy	\N
268	0	0101000020E610000046E80C31035E29405A46EA3D95E54640		2 Borgo Ermes, Sesto Lena laziale, Italy	\N
269	0	0101000020E6100000E4F90CA8376B2340ABA3F496BC5E4440		27 Incrocio Eginardo, Settimo Bruno veneto, Italy	\N
270	0	0101000020E6100000967DB2BD71ED26406F7319EDA7C14640		78 Contrada Edilberto, Sesto Gianluca nell'emilia, Italy	\N
271	0	0101000020E6100000FC68DDABFB5427401073EE1B04334740		1 Strada Deodato, San Ascanio veneto, Italy	\N
272	0	0101000020E610000069965F611C5B2540B52792F991CA4540		91 Incrocio Spizzirri, Viale ligure, Italy	\N
273	0	0101000020E6100000B4C6455ACF692740D8C523A765B04640		24 Borgo Ercole, Quarto Metello, Italy	\N
274	0	0101000020E61000003B843B61D3CC1E40935742D202D44640		34 Piazza Montalbano, Aristofane calabro, Italy	\N
275	0	0101000020E6100000C03FA54A9455284094347F4C6BE54640		192 Rotonda Flaviano, Lodovica nell'emilia, Italy	\N
276	0	0101000020E610000003FBF900EEEB1E40FA6184F068EE4640		3 Rotonda Di Ciocco, Sesto Ivano, Italy	\N
277	0	0101000020E610000007681140209E2640B177352F3D9D4640		6 Via Fedro, Quarto Pierangelo salentino, Italy	\N
278	0	0101000020E6100000525F96766AFE23402A7C6C81F3EE4640		099 Strada Fasano, Costantin del friuli, Italy	\N
279	0	0101000020E61000007319EDA7B5EF1E400B1060EC18EC4640		72 Borgo Coronato, Quarto Cassio laziale, Italy	\N
280	0	0101000020E6100000F86B578DCA1A284015E06014A9B14640		62 Via Scalia, San Adalgisa ligure, Italy	\N
281	0	0101000020E6100000D634947FD2A12740811A081390584540		9 Piazza Militello, Fulvia sardo, Italy	\N
282	0	0101000020E61000009D63E53C08EA2640B7FB0BF3D4DC4540		1 Strada Raffaella, Sesto Alberta ligure, Italy	\N
283	0	0101000020E6100000EA0E18DAEF9B2B40948444DAC6764640		4 Borgo Guglielmo, Sesto Dulina nell'emilia, Italy	\N
284	0	0101000020E610000014BCD7FFEFC62640BA66F2CD36DE4640		02 Piazza Lazzaro, Quarto Leonardo a mare, Italy	\N
285	0	0101000020E610000009168733BFBE27405D4E098849354540		20 Via Demetria, Sesto Calpurnia, Italy	\N
286	0	0101000020E6100000462AE7E6763A2940ABB8CC446CE14440		08 Via Cleopatra, Settimo Aurelia sardo, Italy	\N
287	0	0101000020E610000075EED176A7F62640A7F97486F3B24640		9 Piazza Carnevale, Pierluigi veneto, Italy	\N
288	0	0101000020E6100000F9A23D5E48F727405789C3E3ECE04640		759 Rotonda Caforio, Settimo Gregorio, Italy	\N
289	0	0101000020E6100000731A587D64FD294065FED13769E64540		852 Contrada Liboria, Errante ligure, Italy	\N
290	0	0101000020E6100000ABC5F18D322421407D1FB3582FFA4640		21 Strada Bergamasco, Lauri sardo, Italy	\N
291	0	0101000020E610000035D252793B0228403A79ECC26AEA4640		5 Strada Spagnuolo, Lisa salentino, Italy	\N
292	0	0101000020E6100000DD730580CFD02640F16261889CD44640		632 Incrocio Bernadetta, Borgo Natalia lido, Italy	\N
293	0	0101000020E61000006531564046E12040530E1C8645E74640		4 Incrocio Ferrero, Anita del friuli, Italy	\N
294	0	0101000020E610000026B8A2DE9D5E2740311A434AFDDC4640		1 Rotonda Deriu, Fancello laziale, Italy	\N
295	0	0101000020E61000000A5BFD22B27524407121EA99B95B4640		36 Borgo Pagani, Pavani sardo, Italy	\N
296	0	0101000020E6100000C132DBBA40CE2240D0EFFB372F274740		68 Contrada Alceo, Sesto Anselmo, Italy	\N
297	0	0101000020E6100000CA558737C6B91F40EB79ED88F9BD4640		10 Incrocio Evangelisti, Quarto Novella, Italy	\N
298	0	0101000020E61000006AEE320DD4F324401D098F9147B14640		682 Contrada Laura, Settimo Elisa veneto, Italy	\N
299	0	0101000020E610000044053D8A291B2140F0FACC599F5A4440		5 Via Lucio, Bonagiunta terme, Italy	\N
300	0	0101000020E61000002B1D07B9E6212040F08C11E4FBF04640		37 Incrocio Minniti, Borgo Asella, Italy	\N
301	0	0101000020E61000007BEDE3B21BB727403464E190B2DD4640		50 Piazza Elsa, Frasca laziale, Italy	\N
302	0	0101000020E6100000D8E9ACBB1EE91F40A0A932E774D04640		0 Rotonda Archippo, Fausta salentino, Italy	\N
303	0	0101000020E61000009C8136DEC21B294063731FCA61894540		84 Incrocio Solinas, San Caronte, Italy	\N
304	0	0101000020E6100000E3B08FA91680204076A0F3BF01E94640		35 Rotonda Ernesto, Settimo Graziano calabro, Italy	\N
305	0	0101000020E6100000EE6EAF16E9832340C6F0225D7DCC4640		5 Strada Salvo, Di Luca nell'emilia, Italy	\N
306	0	0101000020E6100000D81D41E037B02140C2F1214D61C54440		1 Rotonda Riccardo, Raimondo terme, Italy	\N
307	0	0101000020E6100000A807BB174E80284061BC8B9C2AD94640		4 Piazza Argenio, Settimo Ticone, Italy	\N
308	0	0101000020E6100000FD18CE9085A322406C9CA80073DB4640		653 Via Caradonna, Carta sardo, Italy	\N
309	0	0101000020E6100000E39F635122672540E113A1C7DEDE4640		0 Incrocio Desiderata, Borgo Ataleo umbro, Italy	\N
310	0	0101000020E610000098231A93B47928409916500361674640		95 Rotonda Verecondo, Borgo Cointa, Italy	\N
311	0	0101000020E6100000ABBCD3539A032740A544B7031AEF4640		3 Contrada Brandi, Borgo Emidio, Italy	\N
312	0	0101000020E61000001E424B0D239B2440D8D1DD1A7DA04640		7 Rotonda Aratone, Quarto Liborio, Italy	\N
313	0	0101000020E6100000CF2CAE96E0891F405EB642FDD3234640		613 Via Agostina, Astrid umbro, Italy	\N
314	0	0101000020E6100000D7BDBACF96BC254007205AD020C34640		21 Rotonda Lecca, Sesto Federico, Italy	\N
315	0	0101000020E6100000C96BCABA24832740A97E4A3A6FE54640		2 Borgo Vladimiro, Fiordaliso nell'emilia, Italy	\N
316	0	0101000020E6100000A8DAB80F8AC32940DF67017F9D1A4540		70 Piazza Gatto, Maida umbro, Italy	\N
317	0	0101000020E6100000C272DFC556972640A4271BC528D24640		205 Borgo Alberico, Borgo Silvano laziale, Italy	\N
318	0	0101000020E61000005F306E5974411E40EC3F21F1E13A4740		824 Piazza Agata, Ciriaco sardo, Italy	\N
319	0	0101000020E61000006C109CE9142628401760C4E347124740		86 Incrocio Romana, Castaldo a mare, Italy	\N
320	0	0101000020E610000044EC0214D9FD284012AC600AC5EE4440		120 Via Cristoforo Colombo, Roma, Italy	\N
321	0	0101000020E6100000B0FECF61BEF827406DFD99E6C2F24640		010 Incrocio Spagnolo, San Rina, Italy	\N
322	0	0101000020E6100000EBB76576CCAF26407B8FE9BFBD424640		76 Piazza Floridia, Borgo Elimena, Italy	\N
323	0	0101000020E6100000D6479682247220407379BD4571084740		39 Via Isidora, Santi lido, Italy	\N
324	0	0101000020E610000097900F7A36872040AB251DE560074740		7 Strada Cristina, Patroclo laziale, Italy	\N
325	0	0101000020E61000000DABD3DC65C22740D32F116F9DE34640		48 Strada Gualberto, Boris veneto, Italy	\N
326	0	0101000020E61000009FEE97AA0FCF27402834FF9E0E024740		853 Piazza Marcello, Tomasi del friuli, Italy	\N
327	0	0101000020E6100000E417B90265622C40EFC0A50815E24440		092 Via Corrao, Sesto Nazzareno sardo, Italy	\N
328	0	0101000020E6100000B2463D44A37B2540F3C011EEDF764540		5 Contrada Semeraro, Borgo Bacco, Italy	\N
329	0	0101000020E6100000B6B0B84956A326409DC2A5BE87334740		690 Piazza Aquino, Asaro umbro, Italy	\N
330	0	0101000020E6100000D56C2FB319AD2840823C16365EC04640		974 Rotonda Piersilvio, Lombardo del friuli, Italy	\N
331	0	0101000020E610000076583C5002EE1E40E0CCF9731BE14640		3 Rotonda Poggi, Ferrari ligure, Italy	\N
332	0	0101000020E6100000470EC7A98CC52840B6A73F564BE04640		228 Borgo Errante, Piacentini a mare, Italy	\N
333	0	0101000020E61000004DC00A4B97B91F4005C1E3DBBBF84540		0 Incrocio Enzo, Quarto Ida, Italy	\N
334	0	0101000020E610000059EB7A585E182740106D1162780E4640		9 Contrada Liberatore, San Danilo, Italy	\N
335	0	0101000020E610000051D9B0A6B2581F4089B7CEBF5DE14640		0 Contrada Todaro, Borgo Gomberto, Italy	\N
336	0	0101000020E6100000AD7603BB504F27406049A8CFC4374640		89 Rotonda Vittore, San Salustio, Italy	\N
337	0	0101000020E61000004692C5A28EF72640D32934B511794640		529 Borgo Iacovone, Borgo Brunilde, Italy	\N
338	0	0101000020E6100000068B790C45182740C3CB1D47BD774640		697 Rotonda Manica, San Virginio umbro, Italy	\N
339	0	0101000020E61000005CC0159A35C620401880A1A245F44640		93 Incrocio Palazzolo, Balzano sardo, Italy	\N
340	0	0101000020E6100000FA2D9512DD7227409453967C47234640		89 Piazza Ione, Settimo Perla, Italy	\N
341	0	0101000020E61000008ECD8E54DFA12B403562C1583A2D4540		09 Contrada Dionisia, Settimo Diego, Italy	\N
342	0	0101000020E610000020651FBF127F254034C06092257F4640		58 Strada Cleofe, San Galdino laziale, Italy	\N
343	0	0101000020E610000064BB31F3D36E22404F401361C3C24640		3 Borgo Simeoni, Pia del friuli, Italy	\N
344	0	0101000020E6100000D160AEA0C47E2240E41824D813C04640		383 Rotonda Almiro, San Elda sardo, Italy	\N
345	0	0101000020E61000006FD8B628B3B91E40086465EA64D64640		522 Piazza Sosteneo, Settimo Evodio, Italy	\N
346	0	0101000020E610000016CDB9CAC93E2140BC0E8B074A744640		842 Incrocio Tavani, Parmenio del friuli, Italy	\N
347	0	0101000020E6100000B4064A65E54A274026DAFA8E86E14640		321 Rotonda Bonanno, Vianello a mare, Italy	\N
348	0	0101000020E61000000736F80CF26822405273034F6B9C4640		082 Borgo Melchiade, Afro salentino, Italy	\N
349	0	0101000020E6100000DF6124C511412140D11CFE3FF3744640		2 Via Rodrigo, Cristiano umbro, Italy	\N
350	0	0101000020E610000077ED77CD50412140CB243493B9744640		9 Piazza Cannas, Borgo Egeo del friuli, Italy	\N
351	0	0101000020E61000002E008DD2A5032D406B5CA4F55C204540		069 Contrada Aleramo, Sesto Vinicio del friuli, Italy	\N
352	0	0101000020E61000004ED367075C6F1F403A57941282D64640		9 Rotonda Dalmazio, Cremenzio terme, Italy	\N
353	0	0101000020E61000006405BF0D316E1F409F07D22060D24640		77 Contrada Eustosio, Signorelli laziale, Italy	\N
354	0	0101000020E61000006F4BE482334C2740A928A8F287304640		107 Rotonda Loreno, Rosselli salentino, Italy	\N
355	0	0101000020E61000005BC52CC59F522B40DB68A5B50EFA4640		882 Piazza De Bona, Bergamini lido, Italy	\N
356	0	0101000020E61000000D5F155E383A21402BCC310F4F724640		2 Piazza Cassio, Quarto Cristiano, Italy	\N
357	0	0101000020E6100000E04158326C5D2140821C9430D3704640		51 Piazza Polissena, San Algiso, Italy	\N
358	0	0101000020E6100000C1F979F8D7071F404EFA319C21CD4640		265 Incrocio Serafino, Sartor laziale, Italy	\N
359	0	0101000020E61000000C97B0917F3921404C9C267D6B734640		9 Contrada Orsola, Luigia veneto, Italy	\N
360	0	0101000020E6100000EFA18ED838742840FA10AF46D1764640		4 Incrocio Surace, Monaci veneto, Italy	\N
361	0	0101000020E6100000B032BF3F4AC11E4019CD25B094D54640		80 Rotonda Costanzo, Anastasia a mare, Italy	\N
362	0	0101000020E610000039FBB9579CA829401D9C3EF152FC4440		3 Borgo Castelli, Settimo Aquilino a mare, Italy	\N
363	0	0101000020E6100000440E5BC4C1F71E4071033E3F8C7E4640		77 Borgo Consolata, Quarto Gennaro, Italy	\N
364	0	0101000020E6100000C69EE2DD36D82B400B8AD5D5D3E84640		5 Borgo Maffeo, Borgo Fabiano, Italy	\N
365	0	0101000020E6100000888961E2EA131F4040E7244A31CD4640		057 Rotonda Angeletti, Sesto Iride lido, Italy	\N
366	0	0101000020E6100000E8F86871C6D81E40E7EBE86E8DD84640		904 Strada Orsola, Luisa veneto, Italy	\N
367	0	0101000020E610000024BF34FBF2301F405FCE6C57E8CB4640		39 Strada Musso, Lipari lido, Italy	\N
368	0	0101000020E61000000242902859C7254075988AE832F64540		9 Contrada Giordano, Borgo Rosario laziale, Italy	\N
369	0	0101000020E61000005CEC5113D8AF1E405650ACAE9ED84640		7 Borgo Stefani, Borgo Fedro del friuli, Italy	\N
370	0	0101000020E6100000A6A84423E9E41E40BF20336145E14640		79 Contrada Carola, Aurelio umbro, Italy	\N
371	0	0101000020E6100000F07A7AB6582B2740B1ADFAB726234640		668 Borgo Panzeri, Borgo Bacco a mare, Italy	\N
372	0	0101000020E61000002252D32EA6C91E404392B47636E94640		535 Incrocio Ortenzi, Monterosso ligure, Italy	\N
373	0	0101000020E61000000BC336983C2C27405262D7F676234640		62 Via Angeletti, Quarto Dora, Italy	\N
374	0	0101000020E61000004F722C94F1E8264075F2D885D5064740		507 Contrada Lavecchia, Borgo Tito umbro, Italy	\N
375	0	0101000020E61000005C8BBBE6FA8F26407A4F8AFB343B4740		3 Borgo Cattaneo, Borgo Apollonia lido, Italy	\N
376	0	0101000020E61000007B9054956C0B28407BB5487FD4974640		6 Via Lupi, San Colmanno laziale, Italy	\N
377	0	0101000020E6100000BE52F1DA00B72B40D21D1F8887274540		936 Via Papini, Quarto Donata terme, Italy	\N
378	0	0101000020E6100000A732D6485C052740FDD8243FE2394640		934 Via Bibiano, Semprini nell'emilia, Italy	\N
379	0	0101000020E6100000AD94545C0B4D2240EE885462E8B94640		29 Rotonda Pecoraro, Borgo Natalina lido, Italy	\N
380	0	0101000020E6100000333097F9B3641F40983BE93356DF4640		3 Via Colombano, San Flavio salentino, Italy	\N
381	0	0101000020E61000002B8AB2124E762740C1EA234B41314640		19 Borgo Pezzella, Lo Iacono terme, Italy	\N
382	0	0101000020E6100000905F8951219022403E5695229E864640		4 Rotonda Acacio, Ponti calabro, Italy	\N
383	0	0101000020E610000096C1621E43E92640E580B80611044740		852 Contrada Ruperto, Settimo Stefano, Italy	\N
384	0	0101000020E61000007090B52B99842B40E461461DC27E4640		9 Borgo Delfino, Costantin ligure, Italy	\N
385	0	0101000020E610000084B1CFAD219A26406BDECC43010E4740		75 Incrocio Giannone, Paladini umbro, Italy	\N
386	0	0101000020E6100000CC1D47BDF13F2240A5A31CCC26824640		866 Piazza Pivetta, San Cristiana, Italy	\N
387	0	0101000020E610000048E58123DCFF26407F7E294D94084740		94 Strada Gioconda, Sesto Eloisa ligure, Italy	\N
388	0	0101000020E61000006B5A73918C1625409D7C1FB358204740		915 Borgo Cristiana, Sesto Franco, Italy	\N
389	0	0101000020E6100000204F818241C01E40068B1E53D2D34640		849 Rotonda Allegretti, Guido ligure, Italy	\N
390	0	0101000020E6100000C0CBB161F2931E40B859BC5818D34640		718 Rotonda Sostrato, Mauri ligure, Italy	\N
391	0	0101000020E610000070DA4246F68B2C40A79C8AAFD1364740		7 Borgo Giuliano, Borgo Amanzio, Italy	\N
392	0	0101000020E6100000A9D5FC9D92882C4058FBE02131384740		2 Piazza Carriero, Settimo Celso, Italy	\N
393	0	0101000020E6100000F74A0FF91DD1274067DC8AB3D8024740		07 Strada Cleofe, Genesia laziale, Italy	\N
394	0	0101000020E61000004221A7542EE52C40A39BB3F457164740		79 Rotonda Di Giacomo, Cesario sardo, Italy	\N
395	0	0101000020E6100000D3D7987C586422408E7CB9AA47A84640		974 Rotonda Mazzotti, Pieri umbro, Italy	\N
396	0	0101000020E610000008CDAE7B2B8A2440E646EC6EF9664540		313 Incrocio Cornelia, Viviana lido, Italy	\N
397	0	0101000020E610000081EB8A19E1CD26408A4457D8C2194640		6 Strada Fabiano, Aris lido, Italy	\N
398	0	0101000020E6100000B4CA4C69FD5122404A95CDC1D8134540		2 Borgo Palladia, Enrica veneto, Italy	\N
399	0	0101000020E6100000E4BD6A65C267264033260EEA6CBC4640		99 Rotonda Fanara, Quarto Patrizia, Italy	\N
400	0	0101000020E610000071C0536DDCD325406C312E0BDCB14640		49 Contrada Ottilia, D'Alessandro umbro, Italy	\N
401	0	0101000020E6100000B368F0ADFEEA2540D42AFA4333B54640		89 Piazza Arrigo, Sesto Diomede, Italy	\N
402	0	0101000020E61000005B2CA0AB08EA2740DE454E15422C4740		30 Incrocio Mistretta, Borgo Teodosio, Italy	\N
403	0	0101000020E61000009703988D2933274052EC0D63778A4640		0 Via Monte Grappa, Lendinara, Italy	\N
404	0	0101000020E61000005389FC44AF582940E7D2AEF83CCA4640		469 Contrada Ferretti, Pipitone ligure, Italy	\N
405	0	0101000020E61000000236D6B441802C4025D5D237C46B4440		44 Via dei Greci, Napoli, Italy	\N
406	0	0101000020E610000073220BE24DBC2740A1E4C40DAE2D4740		3 Strada Audace, Sesto Sabino del friuli, Italy	\N
407	0	0101000020E610000046B1DCD26AB02540072E45A808074740		38 Strada Kofler, Borgo Senofonte lido, Italy	\N
408	0	0101000020E6100000B17E7DBE77992240C0F858B043504440		0 Strada Del Gaudio, Borgo Erico terme, Italy	\N
409	0	0101000020E6100000EC3026FDBD2C27403B6AF1CE46024740		28 Incrocio Di Ciocco, Borgo Alessio, Italy	\N
410	0	0101000020E6100000996EC8F5A5712B40C576F700DD3C4740		9 Strada Sinfronio, San Diodoro nell'emilia, Italy	\N
411	0	0101000020E6100000AA5DB818A8F922406B0DA5F622154440		17 Strada Dalila, Massari sardo, Italy	\N
412	0	0101000020E610000034B10AE58E682040CFC941BFA57A4440		948 Piazza Amaranto, Bruto salentino, Italy	\N
413	0	0101000020E610000008D04AB5AABC2140800F5EBBB4374640		8 Rotonda D'Elia, Chiara terme, Italy	\N
414	0	0101000020E6100000B35DA10F967D2D408F49905BDD324740		028 Contrada Fortunata, Quarto Zelinda laziale, Italy	\N
415	0	0101000020E6100000852348A5D8C12840842458C114E24540		4 Contrada Ulpiano, Settimo Tosca laziale, Italy	\N
416	0	0101000020E6100000BF5076E915252B40EA398EC4703B4740		02 Strada Bisconti, Fulvia lido, Italy	\N
417	0	0101000020E6100000B956D6917EDA2B40DF707A72A8054540		59 Via Asterio, Settimo Ebe, Italy	\N
418	0	0101000020E61000007889A02067742340DE2A3EF493CE4640		56 Strada Cont, Sesto Fiore, Italy	\N
419	0	0101000020E6100000235399BDC70C254059CFFF6101ED4540		006 Rotonda Menconi, Quarto Gerasimo, Italy	\N
420	0	0101000020E610000027F33405D7392640E75E16C90D2C4740		982 Piazza Livia, Ursicio ligure, Italy	\N
421	0	0101000020E61000001C15EE4BECAC2A40DD11A9C4D02E4540		166 Via Manetto, Greta veneto, Italy	\N
422	0	0101000020E6100000C1D4850E70E722408E6D63FDB0594540		158 Borgo Lorena, Basileo ligure, Italy	\N
423	0	0101000020E6100000E5BA849E28A826407E7D63BE723F4640		83 Rotonda Bortoluzzi, Franco umbro, Italy	\N
424	0	0101000020E610000055B1E72109D11F4018CFA0A17FB14640		041 Rotonda Errera, San Matroniano salentino, Italy	\N
425	0	0101000020E61000007DEFCA89D18E2640DB0B16985F354540		37 Via Sebastiano, San Pantaleone, Italy	\N
426	0	0101000020E6100000BB6D9516E41D244002678412C1A94640		7 Contrada Romilda, Settimo Abelardo, Italy	\N
427	0	0101000020E6100000F67AF7C77BB52740FA449E245D4F4740		3 Borgo Mazza, Sesto Cirino, Italy	\N
428	0	0101000020E6100000DE68119BD960294098E8E225EEFB4440		44 Piazza Venusto, Platania laziale, Italy	\N
429	0	0101000020E61000007ED3AA4CE7E52340C9CC052E8F254640		4 Borgo Amico, Falbo terme, Italy	\N
430	0	0101000020E61000004EDF217B732E2240D3F4D901D7214540		281 Via Anselmi, Settimo Emma ligure, Italy	\N
431	0	0101000020E61000004377A45588CA264008951348E43C4640		24 Borgo Vitiello, Borgo Rino, Italy	\N
432	0	0101000020E610000072593B40E6692840252D4B2A09EC4440		50 Contrada Eulalia, Pintus a mare, Italy	\N
433	0	0101000020E610000023E7B3F281D7214072C8618B38C84640		03 Rotonda Caruso, Luchini salentino, Italy	\N
434	0	0101000020E61000000C84AE8E2D752740A4897780272E4640		006 Incrocio Acacio, Terzo del friuli, Italy	\N
435	0	0101000020E6100000A63C5F58A33326408C811A63CCED4540		932 Piazza Maiello, Romolo calabro, Italy	\N
436	0	0101000020E6100000CC0C1B65FD922840A42C8DA905C14640		2 Rotonda Liverani, Quarto Marisa del friuli, Italy	\N
437	0	0101000020E61000007332CC64933F2740FEDDF1DC31254640		144 Piazza Aristofane, Borgo Giliola, Italy	\N
438	0	0101000020E610000032D758784D462240743F4C67CC0B4740		70 Piazza Eros, Borgo Incoronata nell'emilia, Italy	\N
439	0	0101000020E61000002B16BF29ACC825401AB6775787864540		6 Piazza Basso, Fortunato laziale, Italy	\N
440	0	0101000020E6100000FE00B562C9B62A4032CFA51364D94440		7 Via Rotolo, San Mercede, Italy	\N
441	0	0101000020E61000002AD890C9F3362640A3C629DFD80F4640		223 Contrada Aristofane, Borgo Ivone lido, Italy	\N
442	0	0101000020E610000098F0958AD7422540F3DD52735E994640		4 Incrocio Gerasimo, Sesto Tulliano calabro, Italy	\N
443	0	0101000020E6100000451B36806D772640B99BF1C7FE074740		9 Strada Lana, D'Urso ligure, Italy	\N
444	0	0101000020E61000008948A8740B9027402B7D321015F14540		955 Rotonda Barbarigo, Borgo Saverio, Italy	\N
445	0	0101000020E6100000484B8A3496612B40F1F44A5986DF4640		6 Strada Candido, Maurizio sardo, Italy	\N
446	0	0101000020E610000006240626DCE0264059631A97BBDC4640		218 Borgo Abibo, Sesto Delfina nell'emilia, Italy	\N
447	0	0101000020E61000001A62067470422640EF6BC94F4FBD4540		09 Via Costantini, Borgo Zanita calabro, Italy	\N
448	0	0101000020E6100000F0F1536694F425402F5D77A9C7134640		111 Contrada Teodora, Salomone salentino, Italy	\N
449	0	0101000020E6100000A5DAA7E3317F2240E75E16C90DEF4640		293 Strada Druina, Quarto Argo, Italy	\N
450	0	0101000020E6100000D12E956D967D2C40126C5CFFAE6D4440		6 Via Asella, Sesto Golia umbro, Italy	\N
451	0	0101000020E6100000DD6CBDF0941F27409F515F3BBDDA4640		78 Piazza Ambra, Patanè a mare, Italy	\N
452	0	0101000020E610000096EA025E66002640FA4E82ED16F44540		959 Piazza Paolini, Malerba ligure, Italy	\N
453	0	0101000020E61000009DDE20B5E43C25407F83F6EAE39D4540		217 Borgo Pavan, Lorenzo laziale, Italy	\N
454	0	0101000020E6100000016E162F168E2340861BF0F9614A4440		48 Borgo Cupido, Bodini calabro, Italy	\N
455	0	0101000020E61000009F32480BE1EA20405C8A50114CDA4640		5 Incrocio Vala, Loiacono laziale, Italy	\N
456	0	0101000020E6100000618841052C422B400938DFE3A78E4640		62 Incrocio Montesano, Degano ligure, Italy	\N
457	0	0101000020E6100000160F94803D132140276BD44334E04640		74 Strada Adelina, San Teodoro a mare, Italy	\N
458	0	0101000020E610000097A13BD22A4C25401A80B2CE9DD44540		5 Contrada Veronica, Borgo Bonaldo umbro, Italy	\N
459	0	0101000020E6100000AD904D4DDD3827405B632BC313B14540		4 Via Diana, Quarto Amedeo nell'emilia, Italy	\N
460	0	0101000020E610000071E82D1EDEEB2C405F93DA30AF824440		917 Rotonda Mosti, Teodolinda lido, Italy	\N
461	0	0101000020E6100000DA48C8F6109B1F40EE2AFFB5176E4640		261 Incrocio Ariele, Saffo ligure, Italy	\N
462	0	0101000020E61000004D028A4798F02740C38366D7BD264640		478 Incrocio Girardo, San Illuminato sardo, Italy	\N
463	0	0101000020E6100000BCB77DEAB38A2C404EF04DD3676E4440		9 Via Flore, Settimo Dante, Italy	\N
464	0	0101000020E6100000CBC80F4BB93126404793E6EA22FD4640		758 Rotonda Petito, Cassandra terme, Italy	\N
465	0	0101000020E6100000A68E9FD7E925284065677682A2C64640		24 Borgo Dalida, Borgo Susanna a mare, Italy	\N
466	0	0101000020E6100000407562C55F5D294091FC773359C24640		9 Borgo Massimo, Quarto Venerio nell'emilia, Italy	\N
467	0	0101000020E6100000CF328B506C4D244070D63B37C8184640		08 Incrocio Isaia, Lena del friuli, Italy	\N
468	0	0101000020E61000007E6E0D11DC1122409453967C47EB4640		906 Strada Pia, Santarsia lido, Italy	\N
469	0	0101000020E610000043A44BA4D989204072A8DF85ADD34640		762 Contrada Dacio, Settimo Giuda, Italy	\N
470	0	0101000020E61000004371C79BFC022C404AF5F81807254540		136 Contrada Livia, Galante calabro, Italy	\N
471	0	0101000020E61000009EA74B10BFA422400292FAFC41944440		295 Borgo Vilfredo, Flaminia umbro, Italy	\N
472	0	0101000020E61000000D88B59D5B012C40CF70B9B024144540		3 Borgo Annabella, Di Dio salentino, Italy	\N
473	0	0101000020E610000059935D1F8CFE26407E6DA23B2D3B4640		5 Borgo Caronte, Loreto sardo, Italy	\N
474	0	0101000020E6100000D50451F7010829403B736AC2510D4640		955 Contrada Alviero, Cirillo terme, Italy	\N
475	0	0101000020E6100000CD6152D735012740D65F6523C6394640		55 Via Lombardo, Geronimo a mare, Italy	\N
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hike_track_points ("userHikeId", index, "pointId", datetime) FROM stdin;
\.


--
-- Data for Name: user_hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes (id, "userId", "hikeId", "startedAt", "updatedAt", "finishedAt", "psTotalKms", "psHighestAltitude", "psAltitudeRange", "psTotalTimeMinutes", "psAverageSpeed", "psAverageVerticalAscentSpeed", "maxElapsedTime", "weatherNotified", "unfinishedNotified") FROM stdin;
\.


--
-- Data for Name: user_hikes_track_points_user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes_track_points_user_hike_track_points ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash", approved, preferences, "plannedHikes") FROM stdin;
2	$2b$10$eU4TA1smbJ1qXUqbObuLhOnNbvxGLqXMjBIXCalKHvQHXuihjC5Ru	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N	t	\N	\N
4	$2b$10$pN.4w7V84D.OuL9LQYL16.1mj/Uz1SqtSk3wvPfdOB3yGfIZRo/Oi	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N	t	\N	\N
5	$2b$10$/2.YT1BWQv/A06kqVPvLX.kc2IzJKuCEda8MJ3s9eFFKrxRWAtM7y	Laura	Zurru	5	laura@emergency.it	\N	t	\N	t	\N	\N
1	$2b$10$4zJjXmHH1jfZ5qALUgidhOdLDzEnXHV5loVMtwQvucgazId9DYdcS	German	Gorodnev	0	german@hiker.it	\N	t	\N	t	\N	\N
3	$2b$10$FpuQdYzweq6qKhdMycaQaeHfN1wDeAbpvyVH7kfKVGs3f9E9SjZAG	Vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N	t	\N	\N
6	$2b$10$j.b5tuLHcXWLQEsnFTCUKuyogh4feEocFRqzvVEn2PeT9HIWOb9Dy	Francesco	Grande	1	francesco@friend.it	\N	t	\N	t	\N	\N
7	$2b$10$qmS4a3u09RRZta/e/DHXF.d68RL6gkx47je61d8hMmTrJ4kLmBbG6	Desiderio	Sucameli	4	hutWorker0@gmail.com	\N	t	\N	t	\N	\N
8	$2b$10$PdOjMl6jUq2XTFY0QkUNHOSPNk4YYcpaFAd.ouPKlAV8Mk/0sZKyy	Marana	Petrelli	4	hutWorker1@gmail.com	\N	t	\N	f	\N	\N
9	$2b$10$bxExR8ijs3o6H6atC3.q7OB6NEdxHgiJhsCHKR6A0XZx/44BHutnq	Loredana	D'Ambrosio	4	hutWorker2@gmail.com	\N	t	\N	t	\N	\N
10	$2b$10$F8mIaoEmGFJQl7tY5A2iy.QfpQEwzEewao//ygJffGORnJssg376i	Socrate	Cruciani	4	hutWorker3@gmail.com	\N	t	\N	f	\N	\N
11	$2b$10$HIXEz678Gs0pUpvrmu7LK.z95Bd9Yu8s.I.1ZCnE2hADq4KZrD6Ge	Gianni	Medici	4	hutWorker4@gmail.com	\N	t	\N	t	\N	\N
12	$2b$10$aNKciYJHxavKc9JgZOR0LOfu4M8hTStZSZzJ6qmCIzVqjoTN/.Kiy	Adone	Rotondo	4	hutWorker5@gmail.com	\N	t	\N	f	\N	\N
13	$2b$10$ISZHyuDETXWAji4/gT7l8.nYLGshNsULv8eo5lti9ktNYLzGWpCj6	Teodora	Piscitelli	4	hutWorker6@gmail.com	\N	t	\N	t	\N	\N
14	$2b$10$F2lokctyQggaUEWBinEeSO1qM18BkFDJk3t0MTxYxOUD6vCk/dtQO	Ianira	Casella	4	hutWorker7@gmail.com	\N	t	\N	f	\N	\N
15	$2b$10$oKEpsd6fgN/w7XOYEbxque8QRKoZVfn/yRt1hF6LSENkDVcJHsjhC	Clelia	Argiolas	4	hutWorker8@gmail.com	\N	t	\N	t	\N	\N
16	$2b$10$qQMJGkXtyPsO/1w23eSgX.PIK01LFE5eO7vw6dEiQaditnZItCnZ2	Tarsilla	Pezzi	4	hutWorker9@gmail.com	\N	t	\N	f	\N	\N
17	$2b$10$yCgFD/6.uRsUFltAjlirY.pGjzxBIy8ynqiuyBBZ0TdlcWG30YsRi	Furseo	Moras	4	hutWorker10@gmail.com	\N	t	\N	t	\N	\N
18	$2b$10$HhDlf6P0x8WHqBxY.QbdRe5Vf4eywNV9Mogc8kkh1CCu47efOLp4.	Assunta	Capannolo	4	hutWorker11@gmail.com	\N	t	\N	f	\N	\N
19	$2b$10$ja7dzU4oaY7qjNTLtKZ/x.EPQTdIP.0Ll6xiQWHQJf7Xl27ybkHNq	Vincenza	Casula	4	hutWorker12@gmail.com	\N	t	\N	t	\N	\N
20	$2b$10$Ny86BVQCOjGOVsNL75diPeO9lqKjBqfLdbHS22r.hwHX/Zc89j3FC	Prospero	Pizzi	4	hutWorker13@gmail.com	\N	t	\N	f	\N	\N
21	$2b$10$MG3TXTQpLGJR.//dPGzyHewnxQ6b5MfD.2RzIDraLzfYjClfbDDO6	Costante	Marone	4	hutWorker14@gmail.com	\N	t	\N	t	\N	\N
22	$2b$10$jWxsO8LTw4JxcKhhR8ol3exBZudrWOAnxWtTecjVAEHpao7RfEtsq	Zenaide	Liuzzi	4	hutWorker15@gmail.com	\N	t	\N	f	\N	\N
23	$2b$10$Dyi1j29s96bGEHlh0CzIqeLRHk2mGlq3J86XDwmbHbeIl309AzOdq	Davide	Pizzuti	4	hutWorker16@gmail.com	\N	t	\N	t	\N	\N
24	$2b$10$4N0oxZgGdcOUH7O.gSVKFuR5zMA8oUabcWa57sHn0FxA6Co19ueyy	Ivone	Borgia	4	hutWorker17@gmail.com	\N	t	\N	f	\N	\N
25	$2b$10$EGhje5SvMzqpv/ojhXJUF.k6.4/t3TrobWixUlKkddwbh.ohrkTEG	Nico	Carvelli	4	hutWorker18@gmail.com	\N	t	\N	t	\N	\N
26	$2b$10$9XEYHmaS7t3KROKQbxLJS.78sbdYtxgBocE2RxRSdUtMOpi5H5QxG	Mareta	Zullo	4	hutWorker19@gmail.com	\N	t	\N	f	\N	\N
27	$2b$10$Licj6NqJ3ou13UGPymm95uM7sawOPEM6.8DzlsC09Kxji./wjXwXm	Fiorenziano	Belvisi	4	hutWorker20@gmail.com	\N	t	\N	t	\N	\N
28	$2b$10$UlfYKaHmjRbemnXjUHCVy.ft/pJ.3euAJvot67j/cijdzMYBE.KZO	Ludovico	D'Anna	4	hutWorker21@gmail.com	\N	t	\N	f	\N	\N
29	$2b$10$EtN98ltbuePCRzY0ycbuLOP3JkdjqXH.zODVJXJXEKUx8Z6FygrCe	Asia	Giugliano	4	hutWorker22@gmail.com	\N	t	\N	t	\N	\N
30	$2b$10$LSTzT1XqtOWFFWGcUCMZoeVYt0sPb18bTfp1FWWeMgrGCXqHYHov2	Massimiliano	Pozzi	4	hutWorker23@gmail.com	\N	t	\N	f	\N	\N
31	$2b$10$3sXf8zl4QvxYwDw6vfBTa.BwOlvBv4PFhQpW5YSFKQcR7g/CI2UhK	Gelsomina	Desogus	4	hutWorker24@gmail.com	\N	t	\N	t	\N	\N
32	$2b$10$kYiAjEp6n6i/BBS/AtI48eCzx/64y/i7avEeL9figzEJfV6ojnTu6	Marica	Cardini	4	hutWorker25@gmail.com	\N	t	\N	f	\N	\N
33	$2b$10$dn5an0NA725KvyU2s6/wMuB3e9pfbqkk8Hgh5kRB8qffS3Fb7NoG6	Gianmaria	Munaro	4	hutWorker26@gmail.com	\N	t	\N	t	\N	\N
34	$2b$10$3eNE3FmfdUwB5P4lE/KwSurYuCdZMgQ4nP.mS8LcjEusM7dFG2iMi	Ermilo	Leoni	4	hutWorker27@gmail.com	\N	t	\N	f	\N	\N
35	$2b$10$Wwm1qMi8SI3IUB0P75poIex0mM/VY6tKvvOWHkU/WrBEuuxCX4Cp6	Penelope	Tonini	4	hutWorker28@gmail.com	\N	t	\N	t	\N	\N
36	$2b$10$4Hu/faoF/mf7krQMtuhv0uG3uk0IIH26nKox6vatAwNcTBQy0JMju	Babila	Di Gregorio	4	hutWorker29@gmail.com	\N	t	\N	f	\N	\N
37	$2b$10$ds49u6HxmLRpv6iGvPTF3.zqdran8vEgh9OnRV8PusaQTBvSSfMea	Rodrigo	Salatiello	4	hutWorker30@gmail.com	\N	t	\N	t	\N	\N
38	$2b$10$Qnjd.BOmFBxVpUvKpgVcauPvJHqa1QgkNcAgYwjeRnp2Y4RkX6r5K	Girolamo	Barra	4	hutWorker31@gmail.com	\N	t	\N	f	\N	\N
39	$2b$10$r9Wcdx3C50sl3qyl/INWQ.ANsNt11.p9Ba.MqlCyoZKdHi2FkIJMe	Bassiano	Luongo	4	hutWorker32@gmail.com	\N	t	\N	t	\N	\N
40	$2b$10$LSjBf/nhMXzYjSkbt/W59.LHZiW5yI9v6eOv5YkX3fI5pYikUWBJ2	Maurilio	Di Rocco	4	hutWorker33@gmail.com	\N	t	\N	f	\N	\N
41	$2b$10$525g3RbeLIlN6XxcYwAxXOazqx/ykZdB8GgEUCtADbDTvos.aNJrS	Agesilao	Carraro	4	hutWorker34@gmail.com	\N	t	\N	t	\N	\N
42	$2b$10$O2DplYKdaxnastytGQOED.pyOuHD1ES4V3Fjua0cviJ1OoOJQN48G	Sandro	Pastore	4	hutWorker35@gmail.com	\N	t	\N	f	\N	\N
43	$2b$10$DzJYx6umuXU0GeUbJ5Tfc.01MxUwQ/grovPrKOGkSulx8r5nrXYjW	Stella	Mastroianni	4	hutWorker36@gmail.com	\N	t	\N	t	\N	\N
44	$2b$10$WuZ5L2ZI6vqs0T/vNGJTNu8RzCKXJrWPtshmcNblbjwkClqCBlEV.	Ursmaro	Puleo	4	hutWorker37@gmail.com	\N	t	\N	f	\N	\N
45	$2b$10$mhan4.rUhr/Hh2xbWtPCuuJR/SL1L6m520iLmGt3AfZtL.eu5Ch32	Fermiano	Talarico	4	hutWorker38@gmail.com	\N	t	\N	t	\N	\N
46	$2b$10$knSVI8d6PHxCQTFq7L63A.NqkZdQ.ShcjXJ2R3X0sjrvWxy6NkmNG	Editta	Anzalone	4	hutWorker39@gmail.com	\N	t	\N	f	\N	\N
47	$2b$10$RA1I5CNGwmbeWPEmVe3YsuemhlwlgkALu4WgvRETyEDdoEGMQ.dSi	Fernanda	Torri	4	hutWorker40@gmail.com	\N	t	\N	t	\N	\N
48	$2b$10$.rbihTF6rNhsBh.3oqwLI.hbKD3MJpgKpIsLVmMsVPq7cLssqMzJm	Saffo	Iuliano	4	hutWorker41@gmail.com	\N	t	\N	f	\N	\N
49	$2b$10$niMWJI2WJKaVAmgZ6iYHjuC4tbEpxSAhG/pTaYhddFFImg92NGAu6	Domenica	Vallone	4	hutWorker42@gmail.com	\N	t	\N	t	\N	\N
50	$2b$10$4PpJ88LkGwJwNXbU6Il8zebBYTtXRw63m07q26i/HibhTSgrCWeZS	Imelda	Scorza	4	hutWorker43@gmail.com	\N	t	\N	f	\N	\N
51	$2b$10$R/8rQi/I/Si1tyYdn9Zcq.wFTYx75nu.fP4MGDeW7t3M7RsxjjRRe	Elpidio	Manno	4	hutWorker44@gmail.com	\N	t	\N	t	\N	\N
52	$2b$10$Zq9JueKVxXEkynHgKRcn.OtDV5oAQzdgbRJVmkJXLr0dt0SxbX4nS	Solange	Coviello	4	hutWorker45@gmail.com	\N	t	\N	f	\N	\N
53	$2b$10$9SgKetAejqOC6YbKKiiYKuATkDtrbC.PNieHfyh12lV9HhVow0YZu	Stella	Filice	4	hutWorker46@gmail.com	\N	t	\N	t	\N	\N
54	$2b$10$nVOAs5XeHQDMb.t3KlmZZu9t5t1B0GWqK2SYsTGuVJQ0ZxFd0J2oa	Cirano	Tomaselli	4	hutWorker47@gmail.com	\N	t	\N	f	\N	\N
55	$2b$10$ZuFMoYFNBF5jLyehXoDHFOKHLeWM7GMf4R9L2bgi15CuYhOrT86Z6	Giuseppina	Vacca	4	hutWorker48@gmail.com	\N	t	\N	t	\N	\N
56	$2b$10$QEOvLhSRWKF2oMnj52Nktu6tbSyjX78aNEYmEhe3sElDFw5/7YlgW	Brigitta	Montesano	4	hutWorker49@gmail.com	\N	t	\N	f	\N	\N
57	$2b$10$lUZZpAdf4hJKr0HGqhlbOOVrWNoGJd6LxMG6JinJGcwPk17Q37wf6	Natalina	Baraldi	4	hutWorker50@gmail.com	\N	t	\N	t	\N	\N
58	$2b$10$goFn9mGf.WDzglbseotR5eLq1TzZwMBlCDMGVcn4nqs.317obo.22	Cino	Lo Presti	4	hutWorker51@gmail.com	\N	t	\N	f	\N	\N
59	$2b$10$fvBB2ymmrI.P5XdJbEv1MeJR45.Ws/r/j6j5v8GRL5W6a4xADfa.u	Carmela	Raniolo	4	hutWorker52@gmail.com	\N	t	\N	t	\N	\N
60	$2b$10$GwM1Z3WDkruQJY0CGj2rNuZ0dRKXcTyLXIfeQvmS1IzeOKWeXYm4q	Fosca	Zanotti	4	hutWorker53@gmail.com	\N	t	\N	f	\N	\N
61	$2b$10$9VD3Wy7gqB2Vc7BD/wXCpeeU0ByLWiFfqhbo1gcKWIcZdwQqLOQ4e	Lanfranco	Ragone	4	hutWorker54@gmail.com	\N	t	\N	t	\N	\N
62	$2b$10$LvMcd8zTmk6zoP.DvY078ebvrZ07bWZCR6ZYk0mreGzGYW1LLfdRC	Miranda	Luise	4	hutWorker55@gmail.com	\N	t	\N	f	\N	\N
63	$2b$10$oV/ikU.6ysB/fbUy.GOru.bKd9WHdN0i39L5R0lrFuJuFCNHeG8J6	Sisto	Catellani	4	hutWorker56@gmail.com	\N	t	\N	t	\N	\N
64	$2b$10$sbqwjMRMMER2.EfW5f9t3uYcfsLYfz2I9mHSJR927C6B5PGXra.J2	Romolo	Secchi	4	hutWorker57@gmail.com	\N	t	\N	f	\N	\N
65	$2b$10$YSFF0SL5flmfgXC0x3KhSOL2b6DU.yA0XD6N4zKFbJFkVH7GPKoVa	Quiteria	Pucci	4	hutWorker58@gmail.com	\N	t	\N	t	\N	\N
66	$2b$10$QDSx3KJtg/PRFGFK86nN0eYZuHODbGyXNaFYdrJtdPFPRCpr01cDC	Benigna	Tonini	4	hutWorker59@gmail.com	\N	t	\N	f	\N	\N
67	$2b$10$9dfXj9fMiHfJER6wK8LNO.VQwONbZprH/utCdjc7I9Ap5fdoenXyW	Attilio	Di Palma	4	hutWorker60@gmail.com	\N	t	\N	t	\N	\N
68	$2b$10$k6Meft6HNhXbCsRfXGUDSeA9REXPfZg7PPZUrM82trblyg9npEDzu	Morgana	Ricci	4	hutWorker61@gmail.com	\N	t	\N	f	\N	\N
69	$2b$10$EKXaDgtmKMICdUuAQlVMce57DU5MOjCIVNBnpRC7fdNuouyX4WxPK	Adamo	Troisi	4	hutWorker62@gmail.com	\N	t	\N	t	\N	\N
70	$2b$10$vXcDXEghVVg3Tz8yDvC/nuF6/4WQckR3kIsJKK1bV2FVegzPGWnLq	Generoso	Benedetto	4	hutWorker63@gmail.com	\N	t	\N	f	\N	\N
71	$2b$10$hrWdB7l6si8PO9pc0m3zF.NTkG.pSu00QLF3.4j6y6ZCUofqdO.te	Cassiopea	Scanu	4	hutWorker64@gmail.com	\N	t	\N	t	\N	\N
72	$2b$10$XYwScUtX/kra6uci./qSJuUO300PNZKPsiIlkSTwvZLMSgOl1wVoi	Manuele	Di Benedetto	4	hutWorker65@gmail.com	\N	t	\N	f	\N	\N
73	$2b$10$XMAVnUQn/xXlZDV53wXy4uU3jEiuYkc3L9BHpDUAkj9v2tAACIMy2	Diamante	Abbondanza	4	hutWorker66@gmail.com	\N	t	\N	t	\N	\N
74	$2b$10$PAXsRGqImJwLDhI0LoLR8eTAJaRcDowUloecsS4.bH0/SsL0P6Tza	Ottaviano	Caccavo	4	hutWorker67@gmail.com	\N	t	\N	f	\N	\N
75	$2b$10$aZmZRpLr5cEAzSqd1NZrNeW5JNs0ZG4wRV5Gs9fVBEKIrakYXd.hO	Porfirio	Bindi	4	hutWorker68@gmail.com	\N	t	\N	t	\N	\N
76	$2b$10$xbvUEufohC6Q.6nl67yk5eRId3Y6oSfXZlIrbxeMF4JcBWR.9tcp6	Cuniberto	Secci	4	hutWorker69@gmail.com	\N	t	\N	f	\N	\N
77	$2b$10$gTIcNv7xQ1KjqN3tReY0AeUoFSfmifjev0yYMXuc8y/eM.a06sQAS	Zenobia	Reale	4	hutWorker70@gmail.com	\N	t	\N	t	\N	\N
78	$2b$10$rJS3IK/TVVsBl4QDPqpqWeB/cjENdDWqsTifvXo9m9N/RMWUIgcCm	Gaudenzio	Guglielmi	4	hutWorker71@gmail.com	\N	t	\N	f	\N	\N
79	$2b$10$SDJURmSFZm0ZnsB7fCgGH.mKRiRF/k5ZqbcIW7/zbg2aOfibSI29y	Gioventino	Gatta	4	hutWorker72@gmail.com	\N	t	\N	t	\N	\N
80	$2b$10$EftKKtzIcParRORVZLR2VeaYolIs4QeWc.9u6xvAw7wpS/ofyK/fC	Germana	Iezzi	4	hutWorker73@gmail.com	\N	t	\N	f	\N	\N
81	$2b$10$zIOh7C/bjhs2HlhJl/mMHOCBwqYdi2oQvE9roqstPuyH5gTXwx2mi	Mamante	Fontana	4	hutWorker74@gmail.com	\N	t	\N	t	\N	\N
82	$2b$10$YQomxA7NyDDx4InyI1/z5umA88Da0ug.KeqNwH5wTME3nwgs/nwZm	Viviano	Cerutti	4	hutWorker75@gmail.com	\N	t	\N	f	\N	\N
83	$2b$10$zVe2KuO4NwmENcd2nC6MOuQbg3f9zJdEWNoeYSi3Jn/5ybpBj4fpu	Venanzio	Virgilio	4	hutWorker76@gmail.com	\N	t	\N	t	\N	\N
84	$2b$10$AuDy2QrwOQAQz6jETFBzvOxIjpS/p.1lwBpMFHD6CcR2LS7hmU5M2	Veriana	Piredda	4	hutWorker77@gmail.com	\N	t	\N	f	\N	\N
85	$2b$10$zEmqe.BmKNxQGlypiUMk1eRKwpNZzn0ubKqw5wQ1MbREJoEr.qCci	Benigna	Accardo	4	hutWorker78@gmail.com	\N	t	\N	t	\N	\N
86	$2b$10$0j7P/3.X141ZBCjcwJMoi.T0pi/4HzrSWeGjRMlbnzHpdAQa8hOPa	Iginia	Boccia	4	hutWorker79@gmail.com	\N	t	\N	f	\N	\N
87	$2b$10$rVm6ADWyRikLvnm03jnrouWFA.dUDhcDjDbrPD5W2ynvbssMiZszW	Ilaria	Vannini	4	hutWorker80@gmail.com	\N	t	\N	t	\N	\N
88	$2b$10$XcrfNFy4p3ve2l.aEBg6PeALfuyHIBsjzdTJ5LXDZPeIFEN.JdZTG	Niniano	Traini	4	hutWorker81@gmail.com	\N	t	\N	f	\N	\N
89	$2b$10$JZz.zbizzM3JKyJijvQaz.DUfE6Aj8PdqBaHvavwE/.Y2nTt8ajBy	Prudenzio	Iovino	4	hutWorker82@gmail.com	\N	t	\N	t	\N	\N
90	$2b$10$kuxFFrGyzEX5LrEfZ2ZrLe29iDyYHrNSJThdx6S96L1h6j5XRdyxK	Plinio	Sacchet	4	hutWorker83@gmail.com	\N	t	\N	f	\N	\N
91	$2b$10$dLYxVx4W2X1YLJjXdF3uT.6FeaBAyboYCiaMeYBLYIVy1u6nQhJzm	Zabina	Acquadro	4	hutWorker84@gmail.com	\N	t	\N	t	\N	\N
92	$2b$10$fhBz5t5iAMZiJpVREPGpAeCY.QtAjg7/7hgiikLrDlwEH2nTa/djS	Giosuè	Rago	4	hutWorker85@gmail.com	\N	t	\N	f	\N	\N
93	$2b$10$iSDnABJIucYGwIvmTqg06emXWDzGT90/uzNW4umkvHBeE5SPEvNry	Delia	Balistreri	4	hutWorker86@gmail.com	\N	t	\N	t	\N	\N
94	$2b$10$XHFYgGMtzDldX5kuZOxkXuvF1BBl3E7IPx0pyYdsBIzxhFFwgqIr.	Ettore	Bove	4	hutWorker87@gmail.com	\N	t	\N	f	\N	\N
95	$2b$10$B49Iu1CS.llUvhh3k1BgiewYEzhFdLDcOdml68CtQS11I0PmHiNWu	Rossana	Cara	4	hutWorker88@gmail.com	\N	t	\N	t	\N	\N
96	$2b$10$SQRluA.BGeyGgwXRVT6SFuE0O6K50CHY.h8jEvLbyLkhL0R4wtNYq	Rosalia	Granata	4	hutWorker89@gmail.com	\N	t	\N	f	\N	\N
97	$2b$10$sX7NeT7bC8znXYZlvGFUCOrbb6xvv6vGCMgqVvyN6eIBn57qNUhOm	Postumio	Mastrogiacomo	4	hutWorker90@gmail.com	\N	t	\N	t	\N	\N
98	$2b$10$caFw5U5o/cChVv74iJx19.cjVQhqHV/XLgLnbBCMiYAJNZWva44DG	Lidania	Amerio	4	hutWorker91@gmail.com	\N	t	\N	f	\N	\N
99	$2b$10$JdwYXRekRru6GsvtmypvuefzhhTWauJQetaamJNq1pj7vSEnjkChC	Cristiana	Moretti	4	hutWorker92@gmail.com	\N	t	\N	t	\N	\N
100	$2b$10$xPNDhTJEZLmGRcBIgihRQ.76WWK7qyj7JM.CfVOmrdeEyBdOwodaC	Zabina	Scrofani	4	hutWorker93@gmail.com	\N	t	\N	f	\N	\N
101	$2b$10$yqLVkLVHVCT5tHjreBHZ0Ocr7DF2xZ93xSM0CAA9jG0yD7TdSUeGy	Ghita	Tretola	4	hutWorker94@gmail.com	\N	t	\N	t	\N	\N
102	$2b$10$Liwz7qjPabM1GHH8ce67g.9vGxEGHq8GAsKS37de3D70ZnSLTxpm6	Leandro	Callegari	4	hutWorker95@gmail.com	\N	t	\N	f	\N	\N
103	$2b$10$DWDyJotXu0cgLZMgNGUbv.ymgx8f7NBwAblFpRvOXiaafgMFYiY4y	Daciano	Damiano	4	hutWorker96@gmail.com	\N	t	\N	t	\N	\N
104	$2b$10$r5zqLeoRKYGkIlJ7nPtD0.lA9qlzHYsW4lkQFjenwyMroLoJPmhIy	Quasimodo	Braia	4	hutWorker97@gmail.com	\N	t	\N	f	\N	\N
105	$2b$10$.idvbwc/sOr0P4.8AsZ4W.CrVjoTv4GDHTDL6/ZpxEpqh3R/2WevS	Amato	Ferrando	4	hutWorker98@gmail.com	\N	t	\N	t	\N	\N
106	$2b$10$N62siMtwMyI.kMuxrVP1e.2B4qcKKPfFeUioXBx3lrEuIzv6x.ZI2	Cecco	Ciani	4	hutWorker99@gmail.com	\N	t	\N	f	\N	\N
107	$2b$10$v7PgFdXIHxumhm2c4fI6Y.yvv7xLVzF9wvo5nQQKlONk2NUn.LeOO	Ilenia	Fumagalli	4	hutWorker100@gmail.com	\N	t	\N	t	\N	\N
108	$2b$10$rjh7aGKFdpmTrsd7SpEgIuywgl/2W2Upp5Sr71u2NKA7PsASl4Te2	Severiano	Mori	4	hutWorker101@gmail.com	\N	t	\N	f	\N	\N
109	$2b$10$jqtppLnE7IM2kFiSaALy6.F8Jve.iVgRSOuIpHzThmyYW2H9wu9gu	Antonella	Farina	4	hutWorker102@gmail.com	\N	t	\N	t	\N	\N
110	$2b$10$nAYWTXl9qkwf7Kb11c3Qtef2v3q0PTf2FqyYO0PhNwkporkw34rE2	Fatima	Fischetti	4	hutWorker103@gmail.com	\N	t	\N	f	\N	\N
111	$2b$10$pkC2nVJwKkmcAyh8euRTDuTAq9ddxeGa0gZ7eYtRxX8r3edCKX.8W	Annabella	De Palma	4	hutWorker104@gmail.com	\N	t	\N	t	\N	\N
112	$2b$10$V2dB49HhrczJtiT/69Qvye.6H7a3yzeNpLPFBwlZi1QfU6fNV2BAW	Cesare	De Blasi	4	hutWorker105@gmail.com	\N	t	\N	f	\N	\N
113	$2b$10$H8n3L4uDaVqfj2kLfkkWa.TE07bRlHqKd44gR5zxEtu2CR9cWDofK	Grato	Scalia	4	hutWorker106@gmail.com	\N	t	\N	t	\N	\N
114	$2b$10$uAlSwrloogcIGEuMaTyg5uDbQ9v3W/Wi1tDJ8VTn5n.jHuklbzqlW	Tiziana	Zanetti	4	hutWorker107@gmail.com	\N	t	\N	f	\N	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 49, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 108, true);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 256, true);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 475, true);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_hikes_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

