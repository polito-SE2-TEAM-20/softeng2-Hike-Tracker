--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: insert_hike(integer, character varying, integer, character varying, character varying, character varying, character varying, character varying, numeric, numeric, integer, character varying, jsonb, jsonb, jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hike(user_id integer, title character varying, difficulty integer, gpx_path character varying, country character varying, region character varying, province character varying, city character varying, length numeric, ascent numeric, expected_time integer, description character varying, pictures jsonb, start_point jsonb, end_point jsonb, reference_points jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $$;


--
-- Name: insert_hut(integer, double precision, double precision, integer, numeric, character varying, character varying, character varying, character varying, numeric, time without time zone, time without time zone, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut(user_id integer, lat double precision, lon double precision, number_of_beds integer, price numeric, title character varying, address character varying, owner_name character varying, website character varying, elevation numeric, working_time_start time without time zone, working_time_end time without time zone, email character varying, phone_number character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number
    );
    END
    $$;


--
-- Name: insert_parking_lot(integer, double precision, double precision, character varying, integer, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_parking_lot(user_id integer, lat double precision, lon double precision, name character varying, max_cars integer, address character varying, city character varying, country character varying, region character varying, province character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: code-hike; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."code-hike" (code, "userHikeId") FROM stdin;
\.


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country, condition, cause, pictures, "weatherStatus", "weatherDescription") FROM stdin;
\.


--
-- Data for Name: hut-worker; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."hut-worker" ("userId", "hutId") FROM stdin;
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website, elevation, pictures, description, "workingTimeStart", "workingTimeEnd", "phoneNumber", email) FROM stdin;
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address, altitude) FROM stdin;
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hike_track_points ("userHikeId", index, "pointId", datetime) FROM stdin;
\.


--
-- Data for Name: user_hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes (id, "userId", "hikeId", "startedAt", "updatedAt", "finishedAt", "psTotalKms", "psHighestAltitude", "psAltitudeRange", "psTotalTimeMinutes", "psAverageSpeed", "psAverageVerticalAscentSpeed", "maxElapsedTime", "weatherNotified", "unfinishedNotified") FROM stdin;
\.


--
-- Data for Name: user_hikes_track_points_user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes_track_points_user_hike_track_points ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash", approved, preferences, "plannedHikes") FROM stdin;
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 5, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 108, true);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 256, true);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 364, true);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_hikes_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

