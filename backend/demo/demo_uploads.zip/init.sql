--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$eU4TA1smbJ1qXUqbObuLhOnNbvxGLqXMjBIXCalKHvQHXuihjC5Ru',
    'Antonio',
    'Battipaglia',
    2,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$pN.4w7V84D.OuL9LQYL16.1mj/Uz1SqtSk3wvPfdOB3yGfIZRo/Oi',
    'Erfan',
    'Gholami',
    4,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$/2.YT1BWQv/A06kqVPvLX.kc2IzJKuCEda8MJ3s9eFFKrxRWAtM7y',
    'Laura',
    'Zurru',
    5,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$4zJjXmHH1jfZ5qALUgidhOdLDzEnXHV5loVMtwQvucgazId9DYdcS',
    'German',
    'Gorodnev',
    0,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$FpuQdYzweq6qKhdMycaQaeHfN1wDeAbpvyVH7kfKVGs3f9E9SjZAG',
    'Vincenzo',
    'Sagristano',
    3,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    6,
    'francesco@friend.it',
    '$2b$10$j.b5tuLHcXWLQEsnFTCUKuyogh4feEocFRqzvVEn2PeT9HIWOb9Dy',
    'Francesco',
    'Grande',
    1,
    true,
    true
  );
  

      CREATE OR REPLACE FUNCTION public.insert_hike(
        user_id integer,
        title varchar,
        difficulty integer,
        gpx_path varchar,
        country varchar,
        region varchar,
        province varchar,
        city varchar,
        length numeric(12,2),
        ascent numeric(12,2),
        expected_time integer,
        description varchar,
        pictures jsonb,
        start_point jsonb,
        end_point jsonb,
        reference_points jsonb
      )  RETURNS VOID AS
      $func$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'name')::varchar,
            (ref->>'address')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hike"(
        2,
        'Amprimo',
        2,
        '/static/gpx/Amprimo.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        7.2,
        7,
        80,
        'Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.',
        '["/static/images/3.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.165559804,"lat":45.102780737}'::jsonb,
        '{"name":"End Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.14299586,"lat":45.099887898}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":7.164360252,"lat":45.102912389,"altitude":1256.852},{"name":"Ref Point 2","address":"","lon":7.158207147,"lat":45.102886551,"altitude":1283.605}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello Chateau Beaulard - Cotolivier - Vazon',
        1,
        '/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Beaulard',
        9.3,
        5.4,
        200,
        'Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.',
        '["/static/images/2.jpg"]'::jsonb,
        '{"name":"Start Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.772358,"lat":45.03205}'::jsonb,
        '{"name":"End Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.77234,"lat":45.032238}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'borgata ruà a cima di crosa',
        1,
        '/static/gpx/Borgata Ruà-Cima di Crosa (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Sampeyre',
        5387.070533803441,
        955.0963319999998,
        150,
        'Raggiungi la partenza del Sentiero per la Cima di Crosa impostando sul navigatore “Borgata Ruà – Becetto“.

Parcheggiata la macchina a Borgata Ruà (o se impossibilitati a trovare un parcheggio anche a Becetto, allungando di 10 minuti il giro), si prende il sentiero sulla sinistra, nei pressi di una cartina (INDICAZIONI CIMA DI CROSA).',
        '["/static/images/46.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia","lon":7.201825,"lat":44.596613}'::jsonb,
        '{"name":"End Point","address":"Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia","lon":7.177367,"lat":44.615185}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Colle della Gianna da Pian della Regina',
        2,
        '/static/gpx/Colle Della Gianna (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        3622.3230077193216,
        865.2000000000003,
        130,
        'Colle della Gianna at an altitude of approximately 2530m connects the Po Valley to the Pellice Valley allowing you to reach the Barbara Lowrie refuge, an ideal base for multi-day crossings.

It is advisable to carefully consult the weather forecasts especially for these areas frequently subject to very thick fog.

Being at moderately high altitudes in spring there is the possibility of finding tongues of snow that could make the ascent more difficult.',
        '["/static/images/37.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia","lon":7.114553963765502,"lat":44.70202149823308}'::jsonb,
        '{"name":"End Point","address":"Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia","lon":7.103742817416787,"lat":44.722054582089186}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Hike Zicher',
        3,
        '/static/gpx/Hike_Zicher (2).gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Craveggio',
        3221.31231047859,
        712.936152,
        120,
        'Lungo l’itinerario non è garantita la piena copertura telefonica
In periodo estivo, la parte finale può essere molto esposta al sole e richiedere fatica.
In condizioni di vento forte, è preferibile non proseguire
E’ possibile sviluppare un itinerario ad anello scendendo dal versante nord della montagna in direzione Bocchetta Sant’Antonio (ma attenzione ad un passaggio su rocce, soprattutto se ghiacciate).',
        '["/static/images/29.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia","lon":8.534505,"lat":46.147128}'::jsonb,
        '{"name":"End Point","address":"Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia","lon":8.534103,"lat":46.163437}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Usseaux Altro',
        2,
        '/static/gpx/Laghi_Albergian.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Usseaux',
        15636.670195666402,
        1366.7991943359375,
        150,
        'The flowering of Eriofori along the shores of the lake between July and August is interesting, making it very suggestive.',
        '["/static/images/40.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025457266718149,"lat":45.0393102876842}'::jsonb,
        '{"name":"End Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025509485974908,"lat":45.039591416716576}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Usseaux Altro',
        3,
        '/static/gpx/Laghi_Albergiani.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Usseaux',
        15636.670195666402,
        1366.7991943359375,
        150,
        'Itinerario vario e panoramico, non presenta particolari difficoltà ma per la lunghezza, il dislivello, la mancanza di punti di appoggio e la necessità di una certa capacità di orientamento su sentieri non sempre evidenti (specialmente per la variante in discesa) è consigliato a escursionisti allenati e esperti.',
        '["/static/images/42.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025457266718149,"lat":45.0393102876842}'::jsonb,
        '{"name":"End Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025509485974908,"lat":45.039591416716576}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago Bianco',
        2,
        '/static/gpx/Lago Bianco.gpx',
        'Francia',
        'Auvergne-Rhone-Alpes',
        'Savoia',
        'Val-Cenis',
        9.4,
        6.3,
        210,
        'Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.

La diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.

La Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.

Si può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.',
        '["/static/images/1.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945681,"lat":45.223814}'::jsonb,
        '{"name":"End Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945581,"lat":45.224058}'::jsonb,
        '[{"name":"fountain","address":"","lon":6.940291,"lat":45.222543,"altitude":2027},{"name":"Peak","address":"","lon":6.937204,"lat":45.215867,"altitude":2131}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Lago dei 7 colori (lago gignoux)',
        2,
        '/static/gpx/Lago dei 7 colori (lago gignoux) (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Claviere',
        21358.82545547226,
        1087.900000000002,
        170,
        'Parcheggia a Claviere e dirigiti verso la strada comunale Valle Gimont che, dopo poco, si fa sterrata.

Lascia alla tua destra i cartelli che indicano il Lago Gignoux e prosegui risalendo le piste da sci.

Giunto a Sagna Longa noterai che la zona è di interesse sciistico, infatti ci sono numerosi arrivi di seggiovia. Segui le indicazioni per Colle Bercia, attraversa una chiesetta, dei caseggiati in pietra e prosegui per il largo sentiero.

L’intero percorso si sviluppa circondato dai bellissimi Monti della Luna ed è caratterizzato da una dolce e semicostante salita su terreno sterrato a tratti ghiaioso.

Superato il Colle Bercia continua sull’ampia carreggiata che ti conduce ad un valico nel quale noterai particolari conformazioni rocciose e una punta (Cima Saurel 2451 mt). Tieniti sul sentiero basso e supera il valico, che segna anche il confine con la Francia, dopo il quale troverai il lago immerso in una conca.',
        '["/static/images/51.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia","lon":6.749585,"lat":44.938467}'::jsonb,
        '{"name":"End Point","address":"Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia","lon":6.749585,"lat":44.938467}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago d''Afframont 1986 m',
        2,
        '/static/gpx/Lago di Afframont 1986 m.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Balme',
        4024.727690039548,
        810.8999999999994,
        120,
        'Una volta parcheggiata la macchina dirigiti verso il villaggio Albaron. Poco dopo i caseggiati ti troverai di fronte ad un impianto di risalita dismesso, a sinistra troverai un campetto da calcio, proprio dopo il campetto si intravedono i primi cartelli con le indicazioni per il Lago di Afframont. Il sentiero da seguire è il 213, ma lungo il tragitto troverai solo bandiere bianco/rosse e cartelli di legno che indicano la destinazione.

Si sale l’ex pista da sci e ci si addentra nel bosco. Il primo tratto rimane ombreggiato, mentre inizia a farsi sentire la salita. Ad un certo punto ci si affianca ad un ruscello, il Rio di Afframont, che scorre sulla sinistra e si supera con facilità in prossimità dei caseggiati in pietra (attenzione nei periodi di pioggia perché potrebbe essere impraticabile).',
        '["/static/images/52.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia","lon":7.223873427137733,"lat":45.30158649198711}'::jsonb,
        '{"name":"End Point","address":"Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia","lon":7.238771421834827,"lat":45.292359441518784}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Briccas da Borgata Brich 20/02/21',
        2,
        '/static/gpx/Monte Briccas da Brich (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        7580.49492167635,
        1049.2599999999993,
        110,
        'After leaving the car, we continue along the road, first paved and then dirt.

In case of little snow or high temperatures it is possible to cover the first 150m in altitude without snowshoes.

As soon as we hit the first snow, we put on our snowshoes and set off on a well-defined path that crosses a wood.

After having left the last huts behind us, we turn right towards the North/East near a GTA trail sign painted on a boulder.

From here, after the last bush, an enormous, very wide slope opens up before us which culminates right at our peak',
        '["/static/images/35.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia","lon":7.159385243430734,"lat":44.70842678099871}'::jsonb,
        '{"name":"End Point","address":"Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia","lon":7.158207753673196,"lat":44.708156045526266}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Monte Ferra Con Marco e Daniel',
        3,
        '/static/gpx/Monte Ferra (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cuneo',
        11664.786185753126,
        1472.7999999999993,
        150,
        'Fondamentali i bastoncini specialmente nella discesa dal Monte Ferra al lago Reisassa.

Unico punto di appoggio è il rifugio Melezè ad inizio itinerario (consigliamo di contattare direttamente la struttura per verificare giorni e orari di apertura)',
        '["/static/images/28.jpg"]'::jsonb,
        '{"name":"Start Point","address":"SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia","lon":6.982689192518592,"lat":44.57425086759031}'::jsonb,
        '{"name":"End Point","address":"SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia","lon":6.982647031545639,"lat":44.574263943359256}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Crissolo a Ghincia',
        2,
        '/static/gpx/Monte Granè (2).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        6229.073301997005,
        1024.7599999999993,
        200,
        'The Path to Monte Granè is a suggestive walk with a splendid view of Monviso (3841 m) and Viso Mozzo (3019 m).

Leave the car in the car park and continue to the left of the sports field where a splendid path immersed in the woods appears before us and after about 1.5 km you come to the dirt road which in summer leads to the Black Eagle refuge.

Continuing on the latter and having reached the refuge, continue along the Crissolo slopes to the end of the ski-lift where, just above the Ghincia Pastour hut, we will find a statue of the Madonna to indicate the end of the path to Monte Granè.

The return takes place along the same route as the outward journey.',
        '["/static/images/36.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.151954518631101,"lat":44.70016373321414}'::jsonb,
        '{"name":"End Point","address":"Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.121506668627262,"lat":44.688729643821716}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Montr Pigna da Prea',
        2,
        '/static/gpx/Monte Pigna Da Prea (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Roccaforte Mondovì',
        6588.816640728274,
        936.79,
        150,
        'Posteggiata la macchina nel parcheggio sotto l’abitato di Prea ci dirigiamo lungo la strada asfaltata situata sotto il cimitero, lasciandocelo sulla destra.

Appena incontriamo la prima neve possiamo allacciare le ciaspole e proseguire fino alla borgata di Sant’Anna di Prea. (Nei mesi invernali, con nevicate nella norma, la strada viene pulita fino al parcheggio quindi si può iniziare ad indossare le ciaspole fin da subito).

Subito dopo il cartello, all’ingresso di Sant’Anna di Prea, sulla destra vi è un magnifico sentiero immerso nel bosco che permette di tagliare la borgata accorciando la salita di circa 1 km.

Incrociando nuovamente la strada principale e percorrendo circa 3 km si giunge alla Baita Monte Pigna situata a metà degli impianti di Lurisia.',
        '["/static/images/47.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Pigna - Gardiola, Chiusa di Pesio, Cuneo, Piemonte, 12088, Italia","lon":7.738071503117681,"lat":44.27760533988476}'::jsonb,
        '{"name":"End Point","address":"","lon":7.702411115169525,"lat":44.25919541157782}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pian della Regina - Laghi del Monviso',
        2,
        '/static/gpx/Pian della Regina - Laghi del Monviso (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        10065.934631649065,
        842.6999999999998,
        130,
        'The excursion can start near the Po, parking the car in one of the many spaces available. Once you have crossed the stream, follow via Ruata.

To get your bearings in Crissolo, we suggest following the signs for "La Capanna" and ignoring the various detours on the left that follow the ski lifts. Before reaching the restaurant, you finally take the road, following the signs for Monte Tivoli.

The path climbs up into the wood (splendid during the autumn season) and crosses the Sbarme stream.',
        '["/static/images/32.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.117767,"lat":44.700645}'::jsonb,
        '{"name":"End Point","address":"Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.117535,"lat":44.700759}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Fenestrelle Escursionismo',
        2,
        '/static/gpx/Rif. Selleries.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        7281.87058844728,
        504.40087890625,
        120,
        'Itinerario di medio sviluppo con ampio panorama verso la Val Chisone.

Attenzione nella stagione invernale: la zona soggetta a valanghe in caso di abbondanti precipitazioni nevose, specialmente nella conca che precede il rifugio.

Informarsi sempre sullo stato della neve presso i gestori del rifugio o l’ufficio turistico di Fenestrelle.',
        '["/static/images/43.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia","lon":7.0737862307578325,"lat":45.03657284192741}'::jsonb,
        '{"name":"End Point","address":"Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia","lon":7.120104543864727,"lat":45.047753965482116}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Meira Garneri da Sampeyre',
        0,
        '/static/gpx/Rifugio Meira Garneri da Sampeyre (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Sampeyre',
        4156.23862253066,
        850.7600000000003,
        150,
        'Lascia l’auto nel parcheggio della seggiovia di Sampeyre.

Lasciato il parcheggio saliamo subito a destra degli impianti di risalita, dove alcuni cartelli rossi ci segnalano il sentiero attraverso il bosco.

Prendendo rapidamente quota, alla fine del primo tratto di boscoso, raggiungiamo la frazione Sodani dove possiamo osservare la bella chiesa affrescata.

Usciti dalla borgata proseguiamo nuovamente lungo il sentiero circondati da larici, faggi, betulle e dopo alcune deviazione, sempre ben segnalate, usciamo in una splendida radura.

Saliamo gli ultimi 200m a lato della pista o volendo possiamo proseguire più a destra incrociando la strada carrozzabile che nel periodo estivo porta al rifugio.',
        '["/static/images/45.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia","lon":7.180788516998291,"lat":44.57619898952544}'::jsonb,
        '{"name":"End Point","address":"Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia","lon":7.155619841068983,"lat":44.55683704465628}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per ROCCA PATANUA',
        2,
        '/static/gpx/Rocca Patanua da Prarotto (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Condove',
        4388.161778983409,
        923.6238601720527,
        200,
        'Itinerario interamente rivolto a Sud che normalmente si libera dalla neve già a inizio primavera.

(l’itinerario è stato svolto in periodo invernale, seguito scarsa e quasi totalmente assente copertura nevosa).',
        '["/static/images/28.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Alpe Tulivit, Condove, Torino, Piemonte, Italia","lon":7.237061262130737,"lat":45.14908790588379}'::jsonb,
        '{"name":"End Point","address":"Alpe Tulivit, Condove, Torino, Piemonte, Italia","lon":7.219639476388693,"lat":45.17825868912041}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Cima Durand-Colle Bauzano-Artesina',
        3,
        '/static/gpx/Senriero per Anello cima Durand, Colle Bauzano, Artesina (1) (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Artesina',
        8085.211186643268,
        829.1299999999999,
        150,
        'Lasciata la macchina nello spazioso parcheggio di Artesina o nei posteggi vicino al bar Tana del Lupo, saliamo sulle piste dove possiamo subito infilare le ciaspole.

Procediamo per circa 400m sull’ampio sentiero in direzione Ovest (a destra) e dopo alcuni tornanti troviamo un bivio (a sinistra vi è la stradina che percorreremo al ritorno) dove proseguiamo sulla destra (sentiero F02) dirigendoci verso la Celletta, punto panoramico sulla valle Ellero.

Percorriamo il sentiero per Serra della Turra che ci porta prima a passare sotto la seggiovia e poi ad un pianoro dove troviamo la Baita della Turra, tappa ideale per un eventuale break o colazione.',
        '["/static/images/48.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia","lon":7.755467472597957,"lat":44.24691265448928}'::jsonb,
        '{"name":"End Point","address":"Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia","lon":7.754717627540231,"lat":44.246627166867256}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Quintino Sella e Viso Mozzo',
        1,
        '/static/gpx/Sentiero per Rifugio Quintino Sella e Viso Mozzo.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        9039.751801123071,
        1090.660000000001,
        120,
        'The path does not present any difficulty, in case of rain, however, the climb is not recommended as the route is entirely on stony ground.

From up there you have a privileged view of a large part of the Monviso chain and the close distance to the Re di pietra is unique.',
        '["/static/images/31.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia","lon":7.094606207683682,"lat":44.70125044696033}'::jsonb,
        '{"name":"End Point","address":"Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia","lon":7.109863618388772,"lat":44.66575786471367}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Ss659 a Ss6591',
        3,
        '/static/gpx/Sentiero per Rupe del Gesso - CIASPOLE.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Formazzo',
        16969.02550810036,
        984.23046875,
        120,
        'Take the A26 motorway towards Gravellona Toce and follow it to the end. From there stay on the SS33 del Sempione passing Domodossola. At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls. There are unpaved parking lots just before the Centro Fondo Riale.',
        '["/static/images/38.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia","lon":8.41653149574995,"lat":46.41965291462839}'::jsonb,
        '{"name":"End Point","address":"Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia","lon":8.41653149574995,"lat":46.41965291462839}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Albogno-Pieve Margineta Mater',
        2,
        '/static/gpx/albogno-pieve-margineta-mater-27-8-21.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Albogno',
        11301.8785751773,
        1381.6880000000006,
        140,
        'Escursione senza molte difficoltà ideale per il periodo primaverile e autunnale. 
Dopo circa 2 ore di bosco si esce su delle creste molto panoramiche e semplici, il ritorno purtroppo viene fatto su un sentiero poco segnato sulla parte iniziale e ma man mano che si scende compiano sia segni e gli ometti.',
        '["/static/images/11.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia","lon":8.421405,"lat":46.139077}'::jsonb,
        '{"name":"End Point","address":"Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia","lon":8.421395,"lat":46.139111}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Alte Langhe Settentrionali - Cossano Belbo',
        2,
        '/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cossano Belbo',
        4.7,
        28.5,
        200,
        'Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.
Si svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.
Si imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.
Inizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.
Percorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. 
Seguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. 
Si procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante',
        '["/static/images/4.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199049,"lat":44.670379}'::jsonb,
        '{"name":"End Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199052,"lat":44.670377}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":8.214142,"lat":44.674545,"altitude":482.526},{"name":"Ref Point 2","address":"","lon":8.197792,"lat":44.668772,"altitude":242.585}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello per il Monte Freidour (PERLEVIEDELMONDO)',
        2,
        '/static/gpx/anello monte freidour (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'San Pietro Val Lemina',
        8503.263605697935,
        558.511400000002,
        150,
        'At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls.',
        '["/static/images/39.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia","lon":7.284098,"lat":44.96472}'::jsonb,
        '{"name":"End Point","address":"Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia","lon":7.284125,"lat":44.964785}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Anello Pieve di Ledro-Biacesa di Ledro-Rifugio Nino Pernici',
        2,
        '/static/gpx/anello-pieve-di-ledro-biacesa-di-ledro-rifugio-nino-pernici.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        42458.63040670248,
        23175.26399999994,
        320,
        'Anello sui monti a nord-est del Lago di Ledro, percorso in 3 giorni andando con molta calma, percorribile anche in 2. 
Alcuni tratti della prima metà del percorso sono attrezzati con scale e corde.',
        '["/static/images/14.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.73147,"lat":45.882851}'::jsonb,
        '{"name":"End Point","address":"Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731364,"lat":45.882702}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Anello sui colli imolesi: Dozza - Pieve S. Andrea',
        2,
        '/static/gpx/anello-sui-colli-imolesi-dozza-pieve-s-andrea-valsellustra-s.gpx',
        'Italia',
        'Emilia-Romagna',
        'Bologna',
        'Dozza',
        19320.58160760896,
        666.374,
        210,
        'Crossing the provincial road you can see the first of the various signs of the Camino di San Antonio that we will find along the way. We cross and begin a slow but constant climb alongside the fields, which will lead us to a beautiful panoramic view of the surrounding valleys. Paying attention to the crossroads, we continue until we cross the paved road again. In reality there is very little traffic... with a decent view of the Vena del Gesso Romagnola we arrive at the delightful village of Pieve Sant''Andrea (worth a quick detour), to then resume our journey. Be careful not to follow the path of Sant''Antonio, we descend rapidly (shortly after we find the Sorgente delle Accarisie on our left, already existing in Roman times) until we reach the small hamlet of Valsellustra. Here too we cross the road and follow the paved via delle Ville uphill to arrive at a first panoramic point over the surrounding gullies.',
        '["/static/images/21.jpg"]'::jsonb,
        '{"name":"Start Point","address":"5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia","lon":11.632106,"lat":44.359936}'::jsonb,
        '{"name":"End Point","address":"5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia","lon":11.63228,"lat":44.359936}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Campione Pieve Campione',
        2,
        '/static/gpx/campione-pieve-campione.gpx',
        'Italia',
        'Lombardia',
        'Brescia',
        'Campione del Garda',
        10764.501653316338,
        1852.4639999999995,
        300,
        'Campione Pieve Campione',
        '["/static/images/17.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia","lon":10.749084,"lat":45.752875}'::jsonb,
        '{"name":"End Point","address":"Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia","lon":10.749743,"lat":45.757881}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Casalfiumanese (BO) - Pieve di Sant''Andrea',
        2,
        '/static/gpx/casalfiumanese-bo-pieve-di-santandrea.gpx',
        'Italia',
        'Emilia-Romagna',
        'Bologna',
        'Casal Fiumese',
        15650.261397546863,
        838.3309999999993,
        210,
        'Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don''t die from the heat and the clouds filter the sun''s rays and allow you to better enjoy the landscapes',
        '["/static/images/24.jpg"]'::jsonb,
        '{"name":"Start Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616255,"lat":44.29726}'::jsonb,
        '{"name":"End Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616326,"lat":44.297235}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Casalfiumanese (BO) - Pieve di Sant''Andrea',
        2,
        '/static/gpx/casalfiumanese-bo-pieve.gpx',
        'Italia',
        'Emilia-romagna',
        'Bologna',
        'CasalFiumese',
        15650.261397546863,
        838.3309999999993,
        210,
        'Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don''t die from the heat and the clouds filter the sun''s rays and allow you to better enjoy the landscapes',
        '["/static/images/25.jpg"]'::jsonb,
        '{"name":"Start Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616255,"lat":44.29726}'::jsonb,
        '{"name":"End Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616326,"lat":44.297235}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Cavriana pieve- Volta mantovana chiesetta Madonna dei Marchi',
        1,
        '/static/gpx/cavriana-pieve-volta-mantovana-chiesetta-madonna-dei-marchi.gpx',
        'Italia',
        'Lombardia',
        'Mantova',
        'Cavriana',
        17987.27359307591,
        651.414999999999,
        150,
        'Bellissima passeggiata con displivello',
        '["/static/images/13.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia","lon":10.613546,"lat":45.347279}'::jsonb,
        '{"name":"End Point","address":"Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia","lon":10.614472,"lat":45.347241}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":10.625996,"lat":45.345584,"altitude":130.117},{"name":"Ref Point 2","address":"","lon":10.633173,"lat":45.34138,"altitude":139.742},{"name":"Fontain","address":"","lon":10.647482,"lat":45.332552,"altitude":107.319}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per CIMA CIANTIPLAGNA',
        2,
        '/static/gpx/ciantiplagna.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Meana di Susa',
        5474.279781243261,
        791.5095210000009,
        140,
        'The route is safe and within everyone''s reach, even though you reach a relatively high altitude... for this reason it is good to take into account sudden changes in the weather (wind, rain, thick fog).

Due to the total absence of shading, I recommend sunscreen cream and adequate water supply.

In late spring it is still possible to find accumulations of snow which can make the ascent difficult, especially in the final stretch towards the summit.

For cheese lovers, I highly recommend a stop at the Pian dell''Alpe bergeria...',
        '["/static/images/41.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Cima Ciantiplagna, Strada militare del Colle dell''Assietta, Bergerie dell''Assietta, Usseaux, Torino, Piemonte, Italia","lon":7.053414,"lat":45.071918}'::jsonb,
        '{"name":"End Point","address":"Cima Ciantiplagna, Strada militare del Colle dell''Assietta, Bergerie dell''Assietta, Usseaux, Torino, Piemonte, Italia","lon":7.012962,"lat":45.072133}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Voltino a Pieve di Tremosine e ritorno',
        2,
        '/static/gpx/da-voltino-a-pieve-di-tremosine-e-ritorno.gpx',
        'Italia',
        'Lombardia',
        'Brescia',
        'Tremosine sul Garda',
        6588.816640728274,
        936.79,
        120,
        'Fa quasi paura ad avvicinarsi alla ringhiera. 
Vicino alla postazione panoramica presso il bar ristorante che ho fotografato, c''è l''inizio del sentiero per la discesa al Porto di Tremosine.C''è scritto che è consigliato per escursionisti esperti.',
        '["/static/images/15.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia","lon":10.764297,"lat":45.782504}'::jsonb,
        '{"name":"End Point","address":"Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia","lon":10.763028,"lat":45.782797}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Dalla chiesa romanica di San Pietro di Fenestrella alla abba...',
        2,
        '/static/gpx/dalla-chiesa-romanica-di-san-pietro-di-fenestrella-alla-abba.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Albugnano',
        13691.922955982358,
        584.9190000000001,
        150,
        'Chiesa di San Pietro de Fenestrella: 
La chiesa è situata nel cimitero di Albugnano. 
Essa ha affinità compositive con la Canonica di santa Maria di Vezzolano e deriverebbe il suo nome ,secondo alcuni,dalla insolita presenza di tre finestre nell’abside,secondo altri, sarebbe stata così denominata perchè situata nello stretto colle (una gola) compreso tra il rilievo collinare di Albugnano e il rilievo ove sorge il cimitero: 
Una specie di finestra aperta sulla valle sottostante.',
        '["/static/images/27.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia","lon":7.97125,"lat":45.077934}'::jsonb,
        '{"name":"End Point","address":"Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia","lon":7.971227,"lat":45.077991}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Gulo - Pieve Vergonte',
        1,
        '/static/gpx/gulo-pieve-vergonte.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Santa Maria',
        14496.863954985321,
        832.3479999999993,
        90,
        'Gulo - Pieve Vergonte',
        '["/static/images/9.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia","lon":8.248234,"lat":45.997598}'::jsonb,
        '{"name":"End Point","address":"Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia","lon":8.264287,"lat":46.004814}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Il giro del Montorfano: la chiesa romanica, il borgo e la ve...',
        2,
        '/static/gpx/il-giro-del-montorfano-la-chiesa-romanica-il-borgo-e-la-vett.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Bracchio',
        9623.856463002363,
        697.1199999999999,
        210,
        'Il giro del Montorfano: la chiesa romanica, il borgo e la vetta',
        '["/static/images/10.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia","lon":8.448922,"lat":45.960306}'::jsonb,
        '{"name":"End Point","address":"Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia","lon":8.448922,"lat":45.960306}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'La chiesa romanica di S. Vittore(anello Montemagno--Viarigi)',
        3,
        '/static/gpx/la-chiesa-romanica-di-s-vittoreanello-montemagno-viarigi.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montemagno',
        12572.716765417841,
        341.5519999999999,
        210,
        'Il percorso si svolge prevalentemente su sterrata. 
Esso non ha segnaletica ad eccezione dell’ultimo tratto (due km. circa) da località Madonna del Gombo fino a Montemagno. 
In questo tratto si incontra la segnaletica del sentiero n.507 della Regione Piemonte.',
        '["/static/images/6.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia","lon":8.323294,"lat":44.983183}'::jsonb,
        '{"name":"End Point","address":"Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia","lon":8.323553,"lat":44.983388}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'La pieve romanica di Piesenzana e la valle delle tartufaie',
        2,
        '/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montechiaro d''Asti',
        3.1,
        29.2,
        225,
        'Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. 
Circa 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. 
In regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. 
A Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). 
Contemporaneamente i ristoranti della zona propongono piatti a base di tartufi',
        '["/static/images/5.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.113224,"lat":45.007605}'::jsonb,
        '{"name":"End Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.11358,"lat":45.007557}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Le Paludi di Ostiglia Oasi del Busatello Sermide e Pieve',
        3,
        '/static/gpx/le-paludi-di-ostiglia-oasi-del-busatello-sermide-e-pieve-di-.gpx',
        'Italia',
        'Lombardia',
        'Mantova',
        'Pieve di Coriano',
        12572.716765417841,
        341.5519999999999,
        255,
        'La tradizione afferma che la chiesa fu costruita nel 1082, per volere di Matilde di Canossa. Questa attribuzione risale al 1612 nella Historia ecclesiastica di Mantova dove il Donesmondi attribuisce l''edificazione della chiesa a Matilde, assieme ad altre chiese del territorio. 
Il Donesmondi affermò questa data riprendendo l''iscrizione da una lapide presente sulla facciata della pieve, visibile ancora oggi, dove sta scritto "D.O.M. ET B. MARIAE V. IN COELUM ASSUMPTAE ERECTA A.D. 1082 A CONNTISSA MATHILDE". Secondo un''analisi storica questa lapide non può essere ritenuta originale dell''XI secolo, ma risale al cinquecento. L''ipotesi è che questa iscrizione si stata realizzata durante il restauro del 1538. 
Storicamente, quindi, non ci sono documenti che attestano una data certa di costruzione della chiesa, ma sulla base degli elementi architettonici si può affermare che la pieve venne eretta nell''XI secolo. 
La chiesa è in stile romanico, costruita in laterizio ed è composta da tre navat',
        '["/static/images/7.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia","lon":11.106454,"lat":45.035438}'::jsonb,
        '{"name":"End Point","address":"Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia","lon":11.106576,"lat":45.03596}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":11.109236,"lat":45.044962,"altitude":22.75},{"name":"Ref Point 2","address":"","lon":11.155368,"lat":45.034617,"altitude":35.551}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per il MONTE CUCETTO',
        2,
        '/static/gpx/monte cucetto.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Dubbione',
        2150.3010767004043,
        586.4262699999999,
        120,
        'Escursione Facile e, nella parte alta, molto panoramica; la cima offre una buona panoramica dei rilievi tra bassa Val Chisone e Val Sangone.

Lasciata l’auto, il sentiero parte in corrispondenza del tornante ed entra nel bosco in direzione Nord-Ovest; al primo bivio, proseguire dritto e seguire le indicazioni per “Cucetto”; il sentiero inizia a guadagnare quota abbastanza rapidamente e costantemente, sempre nel bosco.

Dopo una serie di tornantini la vegetazione inizierà a diradarsi e si inizierà a scorgere un bel panorama con il Monviso in bella mostra (se il meteo lo permette).',
        '["/static/images/50.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Pralamar, Pinasca, Torino, Piemonte, 10063, Italia","lon":7.243299,"lat":44.961979}'::jsonb,
        '{"name":"End Point","address":"Pralamar, Pinasca, Torino, Piemonte, 10063, Italia","lon":7.240229,"lat":44.977112}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per il MONTE MURETTO',
        2,
        '/static/gpx/monte muretto.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Torino',
        2127.346730436805,
        277.51812700000005,
        200,
        'È presente un unico punto acqua nel luogo del parcheggio (fontana). Nella stessa piazzetta, al momento della recensione, è sempre aperto nei weekend un singolare bar allestito dentro un vecchio furgone.

Per chi cammina con bimbi e soprattutto cani, attenzione in primavera alla presenza di processionarie.',
        '["/static/images/44.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia","lon":7.31544,"lat":44.918242}'::jsonb,
        '{"name":"End Point","address":"Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia","lon":7.309893,"lat":44.929433}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pieve di Ledro - Monte Cocca',
        1,
        '/static/gpx/pieve-di-ledro-monte-cocca.gpx',
        'Italia',
        'Trentino Alto Adige',
        'Provincia di Trento',
        'Pieve di Ledro',
        8627.552532528542,
        1018.0050000000002,
        70,
        'Very challenging, but worth it! The view from the top is gorgeous! For the descent it is better to use sticks, or repeat the same route as the climb.',
        '["/static/images/20.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.730931,"lat":45.889379}'::jsonb,
        '{"name":"End Point","address":"Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731044,"lat":45.889397}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pieve S. Stefano a Pian delle Capanne',
        2,
        '/static/gpx/pieve-s-stefano-a-pian-delle-capanne.gpx',
        'Italia',
        'Toscana',
        'Arezzo',
        'Pieve Santo Stefano',
        22430.396794868582,
        1004.4300000000019,
        150,
        'Causa pioggia e terreno scivoloso preso la 1º variante fino al passo Viamaggio poi proseguito ancora per la 2º variante. 
Bisogna calcolare circa 4 km in più.',
        '["/static/images/23.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Poggiolino delle Viole, Castellare, Pieve Santo Stefano, Arezzo, Toscana, 52036, Italia","lon":12.039528,"lat":43.670638}'::jsonb,
        '{"name":"End Point","address":"Bike Help, Pian della Capanna, Pieve Santo Stefano, Arezzo, Toscana, Italia","lon":12.150503,"lat":43.651402}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Piverone - Anello IV - “Via Romanica al Gesiun”',
        1,
        '/static/gpx/piverone-anello-iv-via-romanica-al-gesiun.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Pieverone',
        4857.311515489554,
        94.22999999999996,
        60,
        'Piverone - Anello IV - “Via Romanica al Gesiun”',
        '["/static/images/8.jpg"]'::jsonb,
        '{"name":"Start Point","address":"26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia","lon":8.00725,"lat":45.44783}'::jsonb,
        '{"name":"End Point","address":"26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia","lon":8.00696,"lat":45.44779}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Plois - Pieve d''Alpago',
        2,
        '/static/gpx/plois-pieve-dalpago.gpx',
        'Italia',
        'Veneto',
        'Belluno',
        'Pieve d''Alpegno',
        6588.816640728274,
        936.79,
        320,
        'percorso è tranquillamente percorribile',
        '["/static/images/19.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Municipio, Via Roma, Torres, Tignes, Pieve d''Alpago, Alpago, Belluno, Veneto, 32010, Italia","lon":12.360272,"lat":46.175025}'::jsonb,
        '{"name":"End Point","address":"Municipio, Via Roma, Torres, Tignes, Pieve d''Alpago, Alpago, Belluno, Veneto, 32010, Italia","lon":12.352636,"lat":46.167926}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Galassi, forcella del ghiacciaio, Rifugio Antelao',
        2,
        '/static/gpx/rifugio-galassi-forcella-del-ghiacciaio-rifugio-antelao-piev.gpx',
        'Italia',
        'Veneto',
        'Belluno',
        'Belluno',
        6588.816640728274,
        936.79,
        200,
        'Quinta giornata Alta via N°4
Rifugio Galassi, forcella del ghiacciaio, Rifugio Antelao, Pieve di Cadore.',
        '["/static/images/18.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia","lon":12.261855,"lat":46.470487}'::jsonb,
        '{"name":"End Point","address":"Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia","lon":12.364278,"lat":46.426071}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Riva del Garda - Pieve di Ledro - Panchina',
        3,
        '/static/gpx/riva-del-garda-pieve-di-ledro-panchina.gpx',
        'Italia',
        'Trentino Alto Adige',
        'Provincia di Trento',
        'Sant''Alessandro',
        8085.211186643268,
        829.1299999999999,
        135,
        'Riva del Garda - Pieve di Ledro - Panchina',
        '["/static/images/16.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.853195,"lat":45.882925}'::jsonb,
        '{"name":"End Point","address":"Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731102,"lat":45.88923}'::jsonb,
        '[{"name":"Peak","address":"","lon":10.853195,"lat":45.882925,"altitude":67.085},{"name":"Lake","address":"","lon":10.764528,"lat":45.873764,"altitude":712.069}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sovicille delle Meraviglie - Villa Cetinale - Scala Santa',
        2,
        '/static/gpx/sovicille-delle-meraviglie-villa-cetinale-scala-santa-e-romi.gpx',
        'Italia',
        'Toscana',
        'Siena',
        'Sovicille',
        19553.110970430764,
        1298.215999999996,
        210,
        'Suggestivo anello con visita della pieve di Pernina e del parco di Villa Cetinale/Castello di Celsa aperti in occasione dell''evento Sovicille delle Meraviglie ottobre 2021',
        '["/static/images/26.jpg"]'::jsonb,
        '{"name":"Start Point","address":"4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia","lon":11.228176,"lat":43.279339}'::jsonb,
        '{"name":"End Point","address":"4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia","lon":11.228044,"lat":43.279294}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'BERGERIE DI VALLONCRO’',
        3,
        '/static/gpx/vallone di massello (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Massello',
        5304.03695311155,
        958.8864720000013,
        150,
        'Open and shade-free environment: remember sunscreen; if the walk is too long, the plateau at the base of the waterfall still offers various possibilities for pleasant picnics.',
        '["/static/images/30.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia","lon":7.031857,"lat":44.964905}'::jsonb,
        '{"name":"End Point","address":"Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia","lon":6.997145,"lat":44.978063}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Ville Disunite - Anello Ghibullo - Villa Pasolini.',
        2,
        '/static/gpx/ville-disunite-anello-ghibullo-villa-pasolini-torre-albicini.gpx',
        'Italia',
        'Emilia-Romagna',
        'Ravenna',
        'Lognana',
        22696.477033711653,
        236.7130000000004,
        110,
        'The first stretch is entirely on the right bank of the Ronco, on the Via Romea Germanica. Then you enter the territory to go towards the center of the journey, the area of ​​San Pietro in Trento where, within two kilometres, you come across a medieval tower, a 9th century parish church with a fantastic crypt, the ruins of a large villa and a perfectly healthy 16th century villa.',
        '["/static/images/23.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia","lon":12.138685,"lat":44.343306}'::jsonb,
        '{"name":"End Point","address":"Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia","lon":12.139573,"lat":44.343643}'::jsonb,
        NULL
      );
    
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2),
        working_time_start time without time zone,
        working_time_end time without time zone,
        email varchar,
        phone_number varchar,
        pictures jsonb,
        description varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber",
      "pictures",
      "description"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number,
      pictures,
      description
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        5,
        124::numeric(12,2),
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Betta Giorgi',
        'https://optimal-shadow.it',
        332.608,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Tirone.Izzi@gmail.com',
        '+391747138157',
        '["/static/images/25f0f48e-cd5a-4b3a-99ad-f2e9259d467c.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]'::jsonb,
        'Reiciendis cupiditate earum voluptatibus.
Neque corrupti incidunt nihil odit.
Omnis ea id.
Consequuntur fugiat et amet totam cum vero esse ipsam.'
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        3,
        45::numeric(12,2),
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Sandra Renda',
        'https://troubled-inauguration.org',
        338.054,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Sidonio47@yahoo.it',
        '+395213024643',
        '["/static/images/60f5b463-120c-45d7-b68b-747e6a20e4f4.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]'::jsonb,
        'In commodi harum et consequatur alias in fuga veritatis fugiat.
At beatae suscipit voluptas rerum vero tenetur nam.
Consectetur veritatis quod error amet repudiandae.'
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        2,
        70::numeric(12,2),
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Vidiano Gagliano',
        'https://vapid-suburb.net',
        271.822,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Lisandro_Silvestri@libero.it',
        '+392258806640',
        '["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg"]'::jsonb,
        'Similique iure fugiat facere similique dolorem quidem modi quas.
Quas quae beatae deleniti deserunt amet.
Quod recusandae modi expedita molestias.
Esse mollitia odit omnis cum optio vitae.'
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        3,
        85::numeric(12,2),
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Temistocle Leonardi',
        'https://pink-site.org',
        327.951,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Durante_Bono65@yahoo.it',
        '+398090795199',
        '["/static/images/90ed2500-1c29-4db5-ba74-36ac493363de.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg"]'::jsonb,
        'Culpa hic quis eos ducimus error perspiciatis unde minima.
Iste facere commodi facilis.
Minus aliquam harum totam explicabo magni.
Aliquam voluptatum aut eveniet placeat.'
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        2,
        114::numeric(12,2),
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Monica De Rossi',
        'https://muddy-astrologer.it',
        335.382,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Natalina.Fantozzi@hotmail.com',
        '+390161973678',
        '["/static/images/64b44b43-eb6d-4641-8c9b-c8b4ceb3e35f.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg"]'::jsonb,
        'Dicta ducimus dolore.
Est ducimus ut fuga odio inventore laboriosam.'
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        7,
        44::numeric(12,2),
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Alberta Manzi',
        'https://masculine-carpeting.net',
        277.755,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Pardo84@libero.it',
        '+394620229830',
        '["/static/images/b2104cd4-03f5-4a0f-9a11-aad5088a38f2.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]'::jsonb,
        'Harum ad nihil.
Veritatis saepe voluptas occaecati quibusdam.
Facere vitae voluptate quos maiores amet doloribus.'
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        3,
        76::numeric(12,2),
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Apuleio Nobile',
        'http://complicated-steward.com',
        319.674,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Duccio.Romano15@hotmail.com',
        '+390925040058',
        '["/static/images/90ed2500-1c29-4db5-ba74-36ac493363de.jpg","/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]'::jsonb,
        'Laboriosam incidunt corrupti blanditiis ratione dolor incidunt id dolor.
Aliquid officiis iure amet sit voluptatibus assumenda aperiam.
Facere dolorum blanditiis soluta aliquid.
Fugiat inventore sint.
Sed eveniet delectus molestias fugiat facere.'
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        2,
        52::numeric(12,2),
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Alceo Spanò',
        'https://slushy-rape.it',
        279.246,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Procopio_Marcello91@email.it',
        '+390818283441',
        '["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg"]'::jsonb,
        'Nisi ullam eos minus.
Facere nihil tenetur quidem veniam soluta exercitationem magni non quia.
Beatae pariatur quasi fugit possimus.
Omnis dolor repellat necessitatibus.'
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        6,
        51::numeric(12,2),
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Noè Iannaccone',
        'http://peaceful-dart.org',
        331.605,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Golia_Sannino93@libero.it',
        '+391998171874',
        '["/static/images/dc0b5f7f-d79a-4499-92e0-c8f4e391345e.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg"]'::jsonb,
        'Earum neque neque odio ipsam.
Fugiat quos voluptatem velit sit.
Explicabo atque eos nihil qui soluta voluptatum libero.
Rerum consectetur possimus laboriosam enim expedita adipisci numquam.
Delectus ratione suscipit temporibus officiis.'
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        5,
        36::numeric(12,2),
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Belina Spina',
        'https://melodic-scheme.it',
        296.83,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Fedro_Valli@yahoo.it',
        '+395892151986',
        '["/static/images/2253208c-36c9-46d5-abeb-8bb44f5f6739.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]'::jsonb,
        'Ullam quod expedita.
Eum magni quod.
Totam corporis labore nisi itaque quibusdam laborum modi.
Incidunt commodi porro itaque animi exercitationem vero accusamus hic.'
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        1,
        122::numeric(12,2),
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Pio Carrozza',
        'http://scented-well.org',
        276.18,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Sapiente.Marchesi11@yahoo.it',
        '+394782230808',
        '["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg"]'::jsonb,
        'Molestias possimus dicta magnam.
Quaerat aperiam totam provident quam quibusdam.
Reprehenderit enim voluptate laborum eius debitis sapiente laborum autem.
Esse similique modi perferendis dignissimos laboriosam aspernatur quas sapiente.'
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        2,
        66::numeric(12,2),
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Ilia Viola',
        'https://poor-complex.com',
        290.968,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Cointa_Tarantino67@email.it',
        '+390557677633',
        '["/static/images/1bdc418d-1e4f-48de-a7ca-e4253e0bcb62.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg"]'::jsonb,
        'Provident incidunt suscipit dolorem nulla.
Atque accusantium provident soluta.
A molestias quos nam numquam unde minima aut.
Molestiae saepe sapiente enim libero nobis iste exercitationem.
Perspiciatis exercitationem id nulla eligendi minus delectus architecto accusantium at.'
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        7,
        51::numeric(12,2),
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Lautone Pellegrino',
        'http://needy-copyright.it',
        263.947,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Ennio17@email.it',
        '+399455583532',
        '["/static/images/1bdc418d-1e4f-48de-a7ca-e4253e0bcb62.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg"]'::jsonb,
        'Laborum aut explicabo.
Eaque quis veniam voluptas odio sit ducimus qui quaerat.
Harum ea numquam odit sequi ipsa voluptas distinctio quibusdam.
Sunt eligendi tenetur necessitatibus ad fuga.'
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        2,
        40::numeric(12,2),
        'Vernagthütte',
        'Austria',
        'Nicarete Fontana',
        'https://live-nightingale.it',
        332.129,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Benvenuta_Magnani@email.it',
        '+392814868122',
        '["/static/images/1bdc418d-1e4f-48de-a7ca-e4253e0bcb62.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg"]'::jsonb,
        'Assumenda odio qui eius alias vel dicta.
Temporibus impedit deleniti pariatur molestiae consectetur.
Repudiandae deleniti atque fugit libero asperiores.
Aut voluptatibus aut consequuntur ex ea ducimus labore.
Quisquam natus harum nostrum autem perferendis ut provident laudantium.'
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        8,
        100::numeric(12,2),
        'Wormser Hütte',
        'Austria',
        'Placida Del Bianco',
        'https://unnatural-trigger.org',
        285.984,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Simeone_Brignone@gmail.com',
        '+398689070145',
        '["/static/images/8cc297a4-7e71-47c2-b123-37a6c0560357.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]'::jsonb,
        'Eveniet eum earum architecto inventore magnam fugiat.
Exercitationem non provident iste quae.
Voluptatem consectetur exercitationem quidem.
Iusto illo repellendus deleniti odio in soluta totam quas itaque.'
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        1,
        40::numeric(12,2),
        'Biberacher Hütte',
        'Austria',
        'Ausiliatrice Cappiello',
        'https://trim-union.com',
        335.074,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Susanna8@yahoo.com',
        '+397957577336',
        '["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]'::jsonb,
        'Itaque tempore vel expedita nulla mollitia vel corporis.
Dolores molestias iste quam repellendus a quae molestiae.'
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        1,
        90::numeric(12,2),
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Eufemio Pellicanò',
        'http://attractive-acquisition.it',
        298.067,
        '01:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Maffeo_Pavani@libero.it',
        '+393732660520',
        '["/static/images/8aabafae-5cbd-4a9d-8196-a266b7d40605.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg"]'::jsonb,
        'Fugit atque dolorem quibusdam rerum debitis quibusdam minima in eveniet.
Dolorum molestiae facilis quas nesciunt sed alias aliquid quia.
Hic inventore dolore laborum.'
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        3,
        103::numeric(12,2),
        'Hochwaldhütte',
        'Germany',
        'Prospero Cozzani',
        'https://treasured-secretariat.it',
        288.598,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Lazzaro.Bodini@hotmail.com',
        '+397211258295',
        '["/static/images/64b44b43-eb6d-4641-8c9b-c8b4ceb3e35f.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg"]'::jsonb,
        'Quas id cupiditate voluptatem minima incidunt a ad sed.
Possimus dolorem laudantium adipisci corporis vitae.'
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        1,
        79::numeric(12,2),
        'Kölner Eifelhütte',
        'Germany',
        'Donna Biagi',
        'https://curvy-scheduling.it',
        332.611,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Onorata.Raniolo@gmail.com',
        '+395330554950',
        '["/static/images/2253208c-36c9-46d5-abeb-8bb44f5f6739.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]'::jsonb,
        'Sapiente iusto sequi sapiente.
Facilis tempora magnam ducimus corrupti nostrum.
Alias eius animi provident velit amet illo quam sunt.'
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        8,
        35::numeric(12,2),
        'Madrisahütte',
        'Austria',
        'Saffiro Terzi',
        'https://nippy-rabbit.it',
        339.777,
        '04:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Verena.Spina@yahoo.com',
        '+391855811351',
        '["/static/images/3e7f5444-b782-4eec-a42a-d6c8a890d142.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg"]'::jsonb,
        'Ducimus consequatur sit velit itaque non repellendus ex.
Veniam aut voluptatum aut sunt corrupti vel.'
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        9,
        95::numeric(12,2),
        'Dresdner Hütte',
        'Austria',
        'Giacinta Visintin',
        'https://extroverted-antennae.com',
        307.417,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Diomede_Bortoluzzi1@email.it',
        '+392353764500',
        '["/static/images/3c557da0-efbd-4062-86bb-1e7322109752.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg"]'::jsonb,
        'Nam officia aut magni optio.
Illum perspiciatis soluta.
A distinctio hic.
Enim omnis nihil possimus maiores quibusdam iure optio.'
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        10,
        137::numeric(12,2),
        'Fiderepasshütte',
        'Germany',
        'Sig. Appia Daniele',
        'http://verifiable-fight.net',
        323.848,
        '08:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Colombo_Pasquini34@yahoo.com',
        '+399710395511',
        '["/static/images/64b44b43-eb6d-4641-8c9b-c8b4ceb3e35f.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg"]'::jsonb,
        'Ea aut aliquam beatae exercitationem est veritatis earum.
Explicabo ratione perferendis non recusandae recusandae dolores repellendus ipsum ullam.'
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        7,
        40::numeric(12,2),
        'Göppinger Hütte',
        'Austria',
        'Eufemia Viviani',
        'http://rapid-mapping.org',
        274.107,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Silvestro_Burgio70@email.it',
        '+393899865574',
        '["/static/images/90ed2500-1c29-4db5-ba74-36ac493363de.jpg","/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]'::jsonb,
        'Quisquam facere aliquam accusantium maxime.
Quas dolor quis laboriosam.
Repellendus quisquam eaque.
Vero labore ad cupiditate laudantium natus.'
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        3,
        87::numeric(12,2),
        'Oberzalimhütte',
        'Austria',
        'Tito Palmeri',
        'https://familiar-siding.com',
        285.494,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Birino.DelBianco@libero.it',
        '+395618006895',
        '["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg"]'::jsonb,
        'Distinctio expedita error ipsam quaerat repellat eligendi similique maxime.
Deleniti ipsa dolore natus.
Sed tempore asperiores perferendis tenetur tempora aspernatur dignissimos veniam.
Facere tenetur adipisci nihil.'
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        7,
        104::numeric(12,2),
        'Rastkogelhütte',
        'Austria',
        'Palmira Ercoli',
        'https://obedient-prophet.com',
        328.55,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Renato.Traini@libero.it',
        '+397256395653',
        '["/static/images/9bced8a8-84fa-4b18-b065-a1b53907d345.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]'::jsonb,
        'Eos distinctio error quidem repellat doloremque voluptatem consequuntur ea.
Molestiae totam exercitationem cumque expedita nobis consectetur repellendus harum.
Sapiente voluptatibus aliquam.
Sequi possimus neque veritatis tempora at praesentium nihil.'
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        1,
        91::numeric(12,2),
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Dott. Leonia Cerutti',
        'https://liquid-spandex.org',
        292.111,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Lazzaro45@yahoo.com',
        '+392012928525',
        '["/static/images/9bced8a8-84fa-4b18-b065-a1b53907d345.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]'::jsonb,
        'Amet quibusdam aperiam molestiae dolore beatae.
Explicabo at eaque doloribus est magni iure dolorem quas ad.'
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        3,
        72::numeric(12,2),
        'Kaltenberghütte',
        'Austria',
        'Barbarigo Paris',
        'https://polite-pigsty.org',
        333.986,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Carmen_Pellicano@libero.it',
        '+394143425207',
        '["/static/images/dc0b5f7f-d79a-4499-92e0-c8f4e391345e.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg"]'::jsonb,
        'Quae officiis itaque ad sunt minus.
Esse rerum consequatur.'
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        6,
        150::numeric(12,2),
        'Schweinfurter Hütte',
        'Austria',
        'Donna Cherubini',
        'http://jovial-dictionary.it',
        278.35,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Antero.Pugliese96@libero.it',
        '+391462982750',
        '["/static/images/2253208c-36c9-46d5-abeb-8bb44f5f6739.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]'::jsonb,
        'Nulla minima animi.
Ipsa inventore quae vero.
Sint ducimus minima fugit.'
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        1,
        55::numeric(12,2),
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Namazio Granata',
        'https://plush-station-wagon.com',
        293.495,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Luana_Branca61@yahoo.it',
        '+390619473027',
        '["/static/images/b8909acc-6822-40ea-ac2a-6c8de7b03cf8.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg"]'::jsonb,
        'Voluptatum suscipit autem.
Voluptas rerum sequi dolorum.
Ex fuga ex officiis quae incidunt quod ut.
Voluptatibus officia animi unde.
Iste aut cumque tenetur facere a in.'
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        1,
        123::numeric(12,2),
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Elpidio De Filippo',
        'https://naughty-tragedy.it',
        276.307,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Clodoveo.Morri17@libero.it',
        '+391016534892',
        '["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg"]'::jsonb,
        'Magnam quibusdam mollitia alias nisi eius mollitia deleniti.
Nam asperiores unde magni incidunt provident harum.
Eum rerum impedit nemo amet perferendis molestiae quisquam.
Sequi corrupti omnis culpa commodi.'
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        5,
        139::numeric(12,2),
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Plutarco Mulas',
        'http://periodic-defender.it',
        336.138,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Onesta26@yahoo.it',
        '+398132015018',
        '["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg"]'::jsonb,
        'A possimus deserunt numquam mollitia.
Adipisci nisi rerum delectus totam est eos molestias.
Consequatur voluptatibus reprehenderit culpa sunt rerum nemo illo quo explicabo.
Harum qui illum consectetur veniam quas qui suscipit tempora.'
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        8,
        129::numeric(12,2),
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Zeno Cenni',
        'https://blissful-tour.it',
        272.888,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Albrico46@gmail.com',
        '+391542614603',
        '["/static/images/b2104cd4-03f5-4a0f-9a11-aad5088a38f2.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg"]'::jsonb,
        'Fugit distinctio vel iste voluptatem aliquam occaecati voluptas ratione ex.
Harum ratione nisi error accusantium mollitia delectus.
A dicta cupiditate libero illum.
Cumque cumque illum ipsam nulla unde placeat itaque.'
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        5,
        126::numeric(12,2),
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Ing. Liborio Angeli',
        'https://original-foal.org',
        306.607,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Lorenzo_Barletta12@email.it',
        '+397695078266',
        '["/static/images/8d44f676-d5ec-4991-8dd8-783156c55129.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg"]'::jsonb,
        'Id necessitatibus sed sunt veniam provident odit sit voluptatum minima.
Excepturi rem dolorem sequi eligendi ea sequi voluptates.
Minus eum necessitatibus at illo quis deserunt ab impedit.
Eius quae quam et quod.
Eligendi asperiores iure aut voluptas quaerat repudiandae quibusdam deleniti distinctio.'
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        7,
        142::numeric(12,2),
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Dr. Adalardo Cipriano',
        'http://acclaimed-prose.com',
        317.461,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Severo_Bertini30@yahoo.it',
        '+392110483047',
        '["/static/images/8aabafae-5cbd-4a9d-8196-a266b7d40605.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg"]'::jsonb,
        'Mollitia harum eligendi alias.
Facere minima eos ab consectetur repellat tenetur cum at asperiores.
Quas iusto autem error ea architecto dolorum reprehenderit.'
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        3,
        117::numeric(12,2),
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Atanasia Benedetti',
        'http://orderly-hake.org',
        298.111,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Seconda94@yahoo.it',
        '+390719458338',
        '["/static/images/9a116e20-4dbc-40ba-bdb6-ab60a9868259.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg"]'::jsonb,
        'Consequatur iure incidunt architecto nobis ipsa fugit dicta dignissimos.
Aperiam impedit nobis quo voluptatibus.
Qui nisi unde maxime asperiores magni.
Quibusdam aspernatur inventore nisi nam id necessitatibus.
Quo voluptate deleniti earum veritatis voluptates voluptas voluptatem omnis autem.'
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        2,
        97::numeric(12,2),
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Ursicio Inzerillo',
        'https://criminal-sunshine.it',
        331.664,
        '09:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Duilio_Prencipe52@libero.it',
        '+396603543683',
        '["/static/images/e6b3d215-ddf6-40d7-a3be-88add2fa0a73.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg"]'::jsonb,
        'Perferendis sint autem quasi id molestiae culpa consequuntur molestiae.
Iure vero voluptatem quisquam consequuntur doloremque iure doloribus omnis quisquam.'
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        4,
        130::numeric(12,2),
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Ileana Vecchi',
        'https://jumpy-mist.it',
        275.236,
        '02:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Gioconda_Oliviero25@yahoo.it',
        '+392844349654',
        '["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg"]'::jsonb,
        'Aperiam ratione optio quaerat possimus autem tempore quaerat.
Veniam tempore dolores eos mollitia.
Porro aut tenetur fuga.'
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        10,
        138::numeric(12,2),
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Biagio Liguori',
        'https://wooden-waiver.net',
        329.114,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Gianni_Spiga23@hotmail.com',
        '+398298709141',
        '["/static/images/60f5b463-120c-45d7-b68b-747e6a20e4f4.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg"]'::jsonb,
        'Nisi iure nostrum dolorum.
Possimus ut ipsum nobis error nulla possimus eum culpa.
Id magnam commodi.
Laborum aspernatur fugit adipisci placeat ipsum perspiciatis enim.
Deleniti dicta eum minima eos exercitationem.'
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        7,
        149::numeric(12,2),
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Maurizio Lucchese',
        'https://quiet-cayenne.com',
        300.924,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Venceslao.Frasca29@email.it',
        '+396467185594',
        '["/static/images/1bdc418d-1e4f-48de-a7ca-e4253e0bcb62.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]'::jsonb,
        'Explicabo delectus nesciunt sequi ut maiores harum qui atque rerum.
Quis nisi deleniti consequuntur voluptatum ipsa quod nostrum beatae nisi.
Occaecati sed ullam saepe.'
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        7,
        128::numeric(12,2),
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Maurilio Marchesi',
        'http://immense-origin.net',
        336.635,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Venusta4@gmail.com',
        '+393909499267',
        '["/static/images/64b44b43-eb6d-4641-8c9b-c8b4ceb3e35f.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]'::jsonb,
        'Sint quaerat asperiores suscipit corrupti.
Voluptates hic cumque officiis reprehenderit.
Excepturi perferendis voluptas.
Veniam culpa sapiente vel eius sapiente natus doloribus magnam earum.'
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        10,
        76::numeric(12,2),
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Battista Flacco',
        'https://euphoric-perpendicular.com',
        311.353,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Rufo5@yahoo.it',
        '+394521239545',
        '["/static/images/3e7f5444-b782-4eec-a42a-d6c8a890d142.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg"]'::jsonb,
        'Vitae commodi nam culpa.
Quae qui enim.'
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        1,
        103::numeric(12,2),
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Serapione Speranza',
        'https://thirsty-honey.net',
        318.371,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Lancilotto73@yahoo.it',
        '+397346249564',
        '["/static/images/25f0f48e-cd5a-4b3a-99ad-f2e9259d467c.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg"]'::jsonb,
        'Eligendi nam unde debitis.
Consequuntur et quasi corporis vero.
Numquam reprehenderit eos voluptatibus voluptate repellat ratione officiis impedit eius.
Voluptas praesentium eum libero.'
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        5,
        128::numeric(12,2),
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Pauside Cassano',
        'http://queasy-erection.net',
        274.719,
        '05:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Berenice47@email.it',
        '+398930360346',
        '["/static/images/64b44b43-eb6d-4641-8c9b-c8b4ceb3e35f.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg"]'::jsonb,
        'Natus mollitia omnis consequatur maxime.
A quidem officiis.
Laborum commodi maiores nesciunt.'
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        6,
        107::numeric(12,2),
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Giliola Marotta',
        'https://notable-oar.org',
        338.691,
        '03:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Maurilio.Migliaccio@hotmail.com',
        '+391506920624',
        '["/static/images/8aabafae-5cbd-4a9d-8196-a266b7d40605.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg","/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg"]'::jsonb,
        'Nemo necessitatibus quod dolores quo odio ut dolore optio.
Consequatur aspernatur maxime deserunt quod tempore reprehenderit.
Qui animi minima quam accusamus non.
Cum esse assumenda qui quasi nisi ratione facere libero harum.'
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        7,
        59::numeric(12,2),
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Azzurra Peaquin',
        'https://novel-castanet.it',
        300.891,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Camelia_Antezza@hotmail.com',
        '+399688354366',
        '["/static/images/8d44f676-d5ec-4991-8dd8-783156c55129.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg"]'::jsonb,
        'Vel eos reiciendis nesciunt placeat molestias reprehenderit accusantium voluptatibus.
Nobis ipsum enim.
Officia perferendis quibusdam impedit placeat unde accusamus ullam tempora.
Sed aperiam accusamus eaque.
Totam error quas temporibus libero.'
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        8,
        112::numeric(12,2),
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Ing. Ischirione Moroni',
        'http://clear-fashion.net',
        308.961,
        '03:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Valter_Pedrotti73@yahoo.com',
        '+395570853953',
        '["/static/images/b8909acc-6822-40ea-ac2a-6c8de7b03cf8.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg"]'::jsonb,
        'Quae blanditiis alias doloribus dolorem facere.
Necessitatibus temporibus reprehenderit laboriosam et neque delectus.
Libero ducimus ea qui iure quisquam tenetur.
Ratione beatae aliquid maiores aspernatur aut voluptatum.'
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        9,
        101::numeric(12,2),
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Teresa Corsini',
        'https://querulous-ambition.net',
        310.958,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Emma.Tofani@gmail.com',
        '+396589765434',
        '["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg"]'::jsonb,
        'Hic molestiae ab.
Consectetur possimus corrupti laboriosam autem sint.'
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        2,
        67::numeric(12,2),
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Capitolina Longo',
        'http://noisy-communicant.com',
        285.36,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Abbondanzio_Castellana@email.it',
        '+394740354603',
        '["/static/images/e6b3d215-ddf6-40d7-a3be-88add2fa0a73.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg"]'::jsonb,
        'Id commodi deserunt blanditiis maiores modi.
Assumenda occaecati doloremque provident velit aspernatur nulla explicabo.
Perspiciatis accusantium architecto aut eos vel vero.'
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        1,
        143::numeric(12,2),
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Dott. Genesio Gennaro',
        'http://winding-great-grandmother.org',
        328.545,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Gaia88@yahoo.com',
        '+396258471210',
        '["/static/images/2253208c-36c9-46d5-abeb-8bb44f5f6739.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg"]'::jsonb,
        'Temporibus facilis quam nam sunt sunt corporis.
Et nihil ab eum reiciendis.'
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        5,
        63::numeric(12,2),
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Cointa Antezza',
        'http://dizzy-murder.org',
        289.304,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Egisto_Benatti60@hotmail.com',
        '+392614847755',
        '["/static/images/60f5b463-120c-45d7-b68b-747e6a20e4f4.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]'::jsonb,
        'Doloribus harum officiis.
Harum quasi adipisci libero mollitia veniam accusantium eum ipsum.
Nostrum deleniti sit ratione vero.
Velit occaecati asperiores minus.
Exercitationem non fuga nesciunt porro quis adipisci recusandae.'
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        8,
        54::numeric(12,2),
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Edoardo Boccia',
        'https://helpless-fondue.net',
        318.415,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Ortensia29@hotmail.com',
        '+395616685367',
        '["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]'::jsonb,
        'Debitis suscipit doloribus eaque iure inventore.
Ratione consectetur libero occaecati eius corporis.
Quam cupiditate nihil deleniti nisi mollitia.'
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        10,
        130::numeric(12,2),
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Viscardo Pece',
        'https://creative-pilgrim.it',
        334.967,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Barbarigo.Pani@gmail.com',
        '+395798037885',
        '["/static/images/2253208c-36c9-46d5-abeb-8bb44f5f6739.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg"]'::jsonb,
        'Illum officia numquam dolores magni sint.
Itaque aliquam unde dolorum et accusamus eaque dolore.'
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        1,
        104::numeric(12,2),
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Marita Belli',
        'https://stimulating-waterwheel.net',
        261.246,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Palatino_Paladini@libero.it',
        '+399451235393',
        '["/static/images/1bdc418d-1e4f-48de-a7ca-e4253e0bcb62.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]'::jsonb,
        'Molestias optio distinctio.
Provident numquam quod id animi exercitationem veniam nihil.
Omnis odio doloremque ratione nam ea aliquid voluptatem ipsum.
Nulla corporis accusamus reiciendis consequuntur.'
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        2,
        64::numeric(12,2),
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Ing. Gianpietro Corsi',
        'http://common-nature.com',
        285.341,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Sefora.Colucci13@gmail.com',
        '+392318462566',
        '["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg"]'::jsonb,
        'Ducimus id ex dolore corporis facere maxime iusto dolor delectus.
Odio repellendus aut dolorum enim voluptas tempora velit.'
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        4,
        82::numeric(12,2),
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Aleandro Saccone',
        'http://impartial-group.net',
        322.087,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Alcino_Marrazzo10@yahoo.com',
        '+392303457313',
        '["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg"]'::jsonb,
        'Ab perferendis amet eius repudiandae perferendis iusto soluta incidunt.
Voluptate ipsam quo qui laudantium veniam cum enim.
Nulla recusandae illum temporibus exercitationem.
Qui voluptatum deserunt nostrum corporis.
Eaque quisquam illo impedit explicabo animi suscipit nulla.'
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        6,
        138::numeric(12,2),
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Menodora Mari',
        'https://usable-accounting.it',
        268.977,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Gisella24@hotmail.com',
        '+396751924580',
        '["/static/images/31e9a65d-714a-444f-b741-cd4a9e57d1d9.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg"]'::jsonb,
        'A omnis repudiandae hic quidem temporibus.
Dolorem nemo rem incidunt.'
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        7,
        96::numeric(12,2),
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Ivanoe Damiano',
        'http://previous-jam.org',
        329.909,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Efrem59@hotmail.com',
        '+399955190835',
        '["/static/images/8d44f676-d5ec-4991-8dd8-783156c55129.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg"]'::jsonb,
        'Porro architecto animi deleniti labore qui consequuntur blanditiis repellendus voluptatibus.
Quasi beatae error explicabo delectus recusandae vel sit deserunt.'
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        1,
        73::numeric(12,2),
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Eginardo Lai',
        'https://hasty-paddock.net',
        319.761,
        '08:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Daria.Evola69@libero.it',
        '+397708903852',
        '["/static/images/31e9a65d-714a-444f-b741-cd4a9e57d1d9.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg"]'::jsonb,
        'Labore delectus consequatur atque deleniti sapiente veritatis illum sint.
Libero quae aperiam.'
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        8,
        69::numeric(12,2),
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Casimira Andreoli',
        'http://jaunty-racism.it',
        311.292,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Severa.Poggio6@yahoo.it',
        '+395709908623',
        '["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg"]'::jsonb,
        'Eveniet nisi tempora perspiciatis placeat vero enim dolorum ipsa.
Quasi laborum tempore vero incidunt.
Eligendi voluptatum sequi eum.
Temporibus vitae porro nisi exercitationem quaerat ratione ab.'
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        4,
        136::numeric(12,2),
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Amos Di Girolamo',
        'http://bountiful-ladybug.it',
        335.946,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Osmondo.Accardi93@yahoo.it',
        '+398627382258',
        '["/static/images/25f0f48e-cd5a-4b3a-99ad-f2e9259d467c.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg"]'::jsonb,
        'Fuga nam distinctio perferendis nostrum voluptatum.
Reiciendis nemo autem nam.
Aperiam error dolorum nesciunt qui ducimus enim.'
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        3,
        82::numeric(12,2),
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Astianatte Massa',
        'http://snoopy-mankind.com',
        327.57,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Felicia.DiBlasi75@libero.it',
        '+397912113667',
        '["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg"]'::jsonb,
        'Voluptatem quas ratione.
Quod excepturi voluptates facere quae repudiandae dolorum praesentium itaque.
Pariatur placeat quos tenetur ad amet non facilis voluptates.'
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        9,
        49::numeric(12,2),
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Gloria Bernasconi',
        'https://dangerous-everyone.net',
        299.047,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Tarso.Cardinali80@yahoo.com',
        '+393378612268',
        '["/static/images/9a116e20-4dbc-40ba-bdb6-ab60a9868259.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]'::jsonb,
        'Ab alias blanditiis odio nisi eius iure illo laboriosam.
Qui iusto recusandae.
Deleniti sapiente deleniti cum rerum cupiditate reprehenderit.'
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        8,
        111::numeric(12,2),
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Damocle Visentin',
        'http://authentic-altar.com',
        333.664,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Fabiola58@yahoo.it',
        '+393774481334',
        '["/static/images/25f0f48e-cd5a-4b3a-99ad-f2e9259d467c.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]'::jsonb,
        'Quisquam natus aperiam laudantium placeat accusamus optio veritatis eos.
Aliquid laborum eius doloribus ducimus consequuntur saepe repellat inventore repudiandae.
Voluptatibus dicta alias.
Consequatur aliquid debitis repudiandae at ut adipisci quae.'
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        2,
        149::numeric(12,2),
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Vissia Errico',
        'https://jumbo-constellation.org',
        286.801,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Bibiana_Saladino@hotmail.com',
        '+390208212370',
        '["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg"]'::jsonb,
        'Numquam provident impedit est tempore iste possimus.
Quisquam ea repellat.
Ad quia laudantium ex.
A veritatis asperiores earum nulla error ad alias tempore.'
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        3,
        148::numeric(12,2),
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Zefiro Fasoli',
        'http://prickly-party.it',
        283.72,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Capitolina41@yahoo.it',
        '+395135256786',
        '["/static/images/3c557da0-efbd-4062-86bb-1e7322109752.jpg","/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg"]'::jsonb,
        'Qui odio et consequuntur sit laudantium dignissimos aspernatur.
Molestiae sit blanditiis adipisci modi perspiciatis.
Repellendus ducimus delectus mollitia labore ratione quibusdam aspernatur.
Expedita nulla explicabo voluptas adipisci mollitia incidunt necessitatibus recusandae reiciendis.
Laboriosam ducimus dolorum consequuntur vero autem et nobis nostrum optio.'
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        8,
        62::numeric(12,2),
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Pietro Minniti',
        'http://scented-bore.it',
        312.336,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Omero70@hotmail.com',
        '+395594194258',
        '["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]'::jsonb,
        'Dignissimos adipisci commodi esse voluptas quidem in occaecati exercitationem velit.
Laboriosam laudantium laboriosam blanditiis iste eaque similique modi ratione.
Eum consequatur beatae modi omnis minima nulla pariatur modi.'
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        10,
        52::numeric(12,2),
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Soave Filippini',
        'http://mammoth-scripture.com',
        268.665,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Appia_Gaudiano@hotmail.com',
        '+394367871218',
        '["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]'::jsonb,
        'In non sapiente dolorem.
Voluptate soluta nesciunt doloribus aut.'
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        9,
        145::numeric(12,2),
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Giona Ciccone',
        'http://willing-texture.net',
        265.254,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Stefano38@email.it',
        '+392068430047',
        '["/static/images/9a116e20-4dbc-40ba-bdb6-ab60a9868259.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg"]'::jsonb,
        'Exercitationem quaerat molestias eveniet quis maiores incidunt et corporis consequatur.
Provident esse blanditiis deleniti.
Suscipit a minima.
Alias hic laborum modi.
Saepe molestias cupiditate ut fuga eum cupiditate a voluptatem.'
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        2,
        143::numeric(12,2),
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Teresa Lipari',
        'http://international-daffodil.com',
        262.634,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Guiberto.Cremonesi7@hotmail.com',
        '+398312042344',
        '["/static/images/b2104cd4-03f5-4a0f-9a11-aad5088a38f2.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg"]'::jsonb,
        'Magni repellat labore.
Distinctio deleniti sit placeat possimus aperiam voluptate.
Officiis quidem impedit tempora explicabo eius quae iure.'
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        8,
        54::numeric(12,2),
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Enimia Amico',
        'https://elegant-rivulet.com',
        299.884,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Flaminia.Campana@yahoo.it',
        '+392236991851',
        '["/static/images/9a116e20-4dbc-40ba-bdb6-ab60a9868259.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg"]'::jsonb,
        'Voluptatibus dignissimos aliquam earum delectus adipisci reiciendis non ducimus aliquam.
Consequuntur temporibus laboriosam minima ipsa consequuntur dolore repudiandae sequi sed.'
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        7,
        93::numeric(12,2),
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Caterina Cataldi',
        'http://unfolded-effectiveness.com',
        280.226,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Gelsomina.Cappai@libero.it',
        '+392720547336',
        '["/static/images/9a116e20-4dbc-40ba-bdb6-ab60a9868259.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]'::jsonb,
        'Praesentium soluta adipisci soluta.
Consequuntur fugit aliquam.
Quisquam aut dolor aliquid dolor incidunt possimus sunt.
Eaque doloremque aspernatur ea praesentium error.
Debitis ab est molestias atque ullam corrupti.'
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        3,
        83::numeric(12,2),
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Loredana De Stefano',
        'https://rubbery-ruckus.net',
        314.789,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Valter_Favara@libero.it',
        '+398648905479',
        '["/static/images/3c557da0-efbd-4062-86bb-1e7322109752.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg"]'::jsonb,
        'Odio dolore expedita alias labore eligendi ut provident incidunt ab.
Laborum veritatis corrupti nisi beatae fugiat vel at officiis hic.
Tempora assumenda quis molestiae illo laboriosam provident.
Deleniti fugiat necessitatibus quisquam at in repudiandae.
Autem accusantium corrupti.'
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        9,
        43::numeric(12,2),
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Emidio Papa',
        'https://tan-authenticity.org',
        287.721,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Isabella74@hotmail.com',
        '+395617826529',
        '["/static/images/dc0b5f7f-d79a-4499-92e0-c8f4e391345e.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg"]'::jsonb,
        'Explicabo earum earum ducimus inventore quasi beatae.
Est reprehenderit doloremque commodi reprehenderit placeat nostrum quod placeat eos.
Saepe fugit praesentium dolorum.
Odit quos dolores ea.'
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        2,
        115::numeric(12,2),
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Vilfredo Macaluso',
        'http://short-term-cruelty.it',
        274.856,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Flavio_Ianni99@yahoo.com',
        '+393441710025',
        '["/static/images/b8909acc-6822-40ea-ac2a-6c8de7b03cf8.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]'::jsonb,
        'Minima deleniti beatae dolor soluta similique adipisci.
Accusamus explicabo ullam vitae ipsa sit nobis laudantium.
Quis ab excepturi dicta consequatur voluptas ipsum quaerat voluptas.'
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        4,
        147::numeric(12,2),
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Uberto Addis',
        'http://villainous-volunteering.net',
        265.538,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Enecone.Gigliotti@yahoo.it',
        '+394510148003',
        '["/static/images/9bced8a8-84fa-4b18-b065-a1b53907d345.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg"]'::jsonb,
        'Accusamus aut fugiat necessitatibus eum excepturi dolorem ab maiores.
Perspiciatis odio hic.'
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        10,
        59::numeric(12,2),
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Guendalina Patruno',
        'https://urban-rotation.com',
        330.542,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Omar_Patti49@email.it',
        '+396317515044',
        '["/static/images/9bced8a8-84fa-4b18-b065-a1b53907d345.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg"]'::jsonb,
        'Facere laboriosam quas.
Recusandae in numquam sed saepe.
Consectetur incidunt incidunt dolore dolorem in quia in cupiditate.'
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        1,
        46::numeric(12,2),
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Manfredo Urso',
        'http://mountainous-authorisation.org',
        305.387,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Peleo45@libero.it',
        '+391087627783',
        '["/static/images/2253208c-36c9-46d5-abeb-8bb44f5f6739.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg"]'::jsonb,
        'Temporibus fuga quisquam.
Nostrum accusantium maxime quo.'
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        5,
        138::numeric(12,2),
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Quiteria Restivo',
        'http://weird-sunroom.org',
        329.544,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Giovanna_Ciulla33@libero.it',
        '+392401117487',
        '["/static/images/25f0f48e-cd5a-4b3a-99ad-f2e9259d467c.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]'::jsonb,
        'Voluptatum id corporis consectetur officiis sequi ullam repudiandae sunt.
Sit veritatis iste veritatis commodi.'
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        5,
        117::numeric(12,2),
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Licia Calì',
        'https://weird-antelope.it',
        268.913,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Garimberto_Scalise@libero.it',
        '+397702697989',
        '["/static/images/b2104cd4-03f5-4a0f-9a11-aad5088a38f2.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg"]'::jsonb,
        'Unde esse veritatis laudantium nobis aspernatur in ullam debitis.
Consectetur excepturi eligendi magnam voluptate voluptate nisi odio.
Voluptas necessitatibus exercitationem tempora amet facilis.
Corporis voluptates qui dolorum.'
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        7,
        133::numeric(12,2),
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Benigna Schirru',
        'https://dim-blackberry.net',
        329.209,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Pollione50@hotmail.com',
        '+397589285733',
        '["/static/images/25f0f48e-cd5a-4b3a-99ad-f2e9259d467c.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg"]'::jsonb,
        'Iusto illo est sequi a delectus cum.
Asperiores inventore voluptates.'
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        3,
        150::numeric(12,2),
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Giocondo Vinci',
        'https://cautious-silence.com',
        290.286,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Gaetano.Valenti@libero.it',
        '+397661372386',
        '["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]'::jsonb,
        'Error perspiciatis sequi.
Placeat earum sunt voluptatem nulla quis quis libero cum dignissimos.
Nihil adipisci nulla aliquid asperiores minima.
Autem quos aliquam similique velit occaecati corrupti.'
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        3,
        57::numeric(12,2),
        'Wittener Hütte',
        'Germany',
        'Elmo Franceschi',
        'https://bleak-church.com',
        277.262,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Beltramo.DiLorenzo80@email.it',
        '+397100247785',
        '["/static/images/25f0f48e-cd5a-4b3a-99ad-f2e9259d467c.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg"]'::jsonb,
        'Voluptatibus sit iusto aliquam itaque pariatur.
Vitae eligendi facilis delectus ex a suscipit ipsam modi.
Quia hic ipsum repudiandae.
Quis tempora corrupti animi quod aut alias.
Velit doloremque earum quisquam eos.'
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        1,
        78::numeric(12,2),
        'Hochjoch-Hospiz',
        'Austria',
        'Dott. Gloria Iandolo',
        'http://studious-naming.it',
        262.806,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Stanislao.Bianc@libero.it',
        '+396045714456',
        '["/static/images/dc0b5f7f-d79a-4499-92e0-c8f4e391345e.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg"]'::jsonb,
        'Hic voluptates doloribus repellendus.
Dignissimos officia delectus distinctio tenetur perspiciatis.
Dolorem perspiciatis nobis eos asperiores cum.
Architecto ab in voluptatibus laborum.
Odio unde officia voluptatem itaque.'
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        3,
        101::numeric(12,2),
        'Meilerhütte',
        'Germany',
        'Diletta Manetti',
        'http://orange-lynx.net',
        293.139,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Ida.Pecora50@email.it',
        '+394191570508',
        '["/static/images/31e9a65d-714a-444f-b741-cd4a9e57d1d9.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]'::jsonb,
        'Dolore totam quod harum qui quos adipisci facilis animi.
Laborum fugiat tempore hic iste.'
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        4,
        89::numeric(12,2),
        'Gaudeamushütte',
        'Austria',
        'Martina Giovannelli',
        'http://traumatic-crazy.it',
        266.889,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Aristarco_Cruciani26@gmail.com',
        '+393480974368',
        '["/static/images/64b44b43-eb6d-4641-8c9b-c8b4ceb3e35f.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]'::jsonb,
        'Cumque corrupti dolores facilis.
Autem nisi suscipit dolorem vitae suscipit mollitia maxime ea quidem.'
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        8,
        108::numeric(12,2),
        'Rheydter Hütte',
        'Germany',
        'Ing. Nestore Florio',
        'https://defenseless-snack.com',
        322.058,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Ursicio68@gmail.com',
        '+399101323395',
        '["/static/images/1bdc418d-1e4f-48de-a7ca-e4253e0bcb62.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg"]'::jsonb,
        'Reprehenderit velit possimus fuga molestiae quod.
Distinctio reprehenderit voluptatibus harum excepturi necessitatibus ratione illum delectus in.
Facilis cum ullam.'
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        5,
        116::numeric(12,2),
        'Sektionshütte Krippen',
        'Germany',
        'Zarina Recchia',
        'https://wavy-month.net',
        296.888,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Astrid_Meloni85@yahoo.it',
        '+394640231399',
        '["/static/images/b8909acc-6822-40ea-ac2a-6c8de7b03cf8.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg"]'::jsonb,
        'Provident voluptates eaque.
Dolorum labore eligendi.
Natus fuga odit temporibus quas eum harum.
Tenetur optio dolore.
Voluptatum sint dolor hic unde vel incidunt deleniti.'
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        3,
        98::numeric(12,2),
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Abele Novello',
        'http://digital-melon.com',
        333.303,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Tommaso.Fratello78@gmail.com',
        '+393451774306',
        '["/static/images/e6b3d215-ddf6-40d7-a3be-88add2fa0a73.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg"]'::jsonb,
        'Quos distinctio et excepturi eius rerum adipisci optio.
Aut consequatur fugiat accusamus nobis similique tenetur occaecati enim vitae.
Voluptatem quam dolor iusto facilis non rerum.
Perferendis quam alias non fugiat.
Ut quo cumque eos aliquam mollitia enim quod.'
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        5,
        44::numeric(12,2),
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Vladimiro Ferrari',
        'http://outlying-jasmine.net',
        264.831,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Edgardo92@gmail.com',
        '+398625152502',
        '["/static/images/8cc297a4-7e71-47c2-b123-37a6c0560357.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg","/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg"]'::jsonb,
        'Sint incidunt dolorem nemo a esse nobis veritatis adipisci beatae.
Beatae aspernatur esse aliquam maiores iure porro enim.
Facere ipsa at pariatur vero natus.
Sequi itaque magni.'
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        5,
        37::numeric(12,2),
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Camilla Barberi',
        'https://understated-wrestler.org',
        260.627,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Palatino8@yahoo.it',
        '+393207258467',
        '["/static/images/8cc297a4-7e71-47c2-b123-37a6c0560357.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg"]'::jsonb,
        'Adipisci repellat assumenda molestiae magnam deleniti asperiores.
Delectus quod ut cum.
Ratione incidunt culpa nam consectetur adipisci laboriosam ullam odio perferendis.'
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        10,
        61::numeric(12,2),
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Iginio Fiorenza',
        'https://unsung-boom.net',
        261.204,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Stefania.Zambuto@yahoo.com',
        '+395515291012',
        '["/static/images/8d44f676-d5ec-4991-8dd8-783156c55129.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg"]'::jsonb,
        'Quisquam repellendus veniam dolores dicta.
Consequatur laboriosam id rerum aspernatur perferendis dolores odio pariatur.'
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        6,
        73::numeric(12,2),
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Gioacchina Bertani',
        'http://grumpy-push.com',
        278.778,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Luminosa.Cortesi@yahoo.com',
        '+396573578202',
        '["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg"]'::jsonb,
        'Praesentium deserunt aspernatur odit voluptas fugit illum.
Officia error iusto ea libero minima laborum tempora.
Quibusdam nam eligendi soluta.
Magnam animi distinctio neque cupiditate nam quia illo.
Placeat aliquid veniam.'
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        3,
        68::numeric(12,2),
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Sig. Abbondanza Giardina',
        'https://vigilant-messy.it',
        314.46,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Adalberto92@yahoo.it',
        '+396518161708',
        '["/static/images/b8909acc-6822-40ea-ac2a-6c8de7b03cf8.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg"]'::jsonb,
        'Dolor iure pariatur odio quibusdam consequatur harum asperiores.
Tempora rem cum dolores temporibus.
Vel praesentium iste nisi sunt nulla minus.
Asperiores inventore iusto dignissimos quasi similique excepturi possimus tenetur provident.
Nisi blanditiis nulla ratione nobis harum tempora fugiat ab.'
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        7,
        38::numeric(12,2),
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Oronzo Corridori',
        'http://queasy-making.net',
        288.365,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Ilario1@yahoo.it',
        '+393929409666',
        '["/static/images/8cc297a4-7e71-47c2-b123-37a6c0560357.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/1c87b0d0-ad87-484b-8f61-d9170d1a4c73.jpg"]'::jsonb,
        'Harum veritatis ea deleniti.
Incidunt nesciunt officiis.'
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        10,
        54::numeric(12,2),
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Viola Concas',
        'https://agreeable-renaissance.net',
        309.148,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Menelao.Longo@yahoo.it',
        '+398181032987',
        '["/static/images/60f5b463-120c-45d7-b68b-747e6a20e4f4.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/9929890f-b403-48ac-8c53-17a7928506ff.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg"]'::jsonb,
        'Accusamus tempore vel nisi in.
Fugiat numquam tenetur.
Impedit libero cumque sed ea.
Modi unde asperiores omnis inventore.
Autem sunt labore velit est eveniet.'
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        8,
        140::numeric(12,2),
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Onorata Spanu',
        'http://gigantic-cross-contamination.com',
        319.931,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Graziana64@hotmail.com',
        '+390564208445',
        '["/static/images/31e9a65d-714a-444f-b741-cd4a9e57d1d9.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg"]'::jsonb,
        'Dolorem ducimus commodi doloribus molestias.
Ex inventore error veritatis tempore pariatur possimus inventore cupiditate.
Eius debitis ea.
Ea quaerat necessitatibus a dicta accusantium.'
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        4,
        131::numeric(12,2),
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Alfio Maione',
        'https://extraneous-filly.org',
        306.143,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Elvino56@libero.it',
        '+392415917523',
        '["/static/images/b8909acc-6822-40ea-ac2a-6c8de7b03cf8.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]'::jsonb,
        'Quae recusandae deleniti rerum aliquid.
Non at dolore fugit excepturi magnam.
Aliquam rem suscipit molestias sunt.
Tenetur ratione modi quisquam in dicta nulla.
Aliquam explicabo quia quasi.'
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        2,
        61::numeric(12,2),
        'Dobra voda',
        'Suvobor, Serbia',
        'Diogene Nocerino',
        'http://flickering-leeway.org',
        326.83,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Delfina_Peaquin35@yahoo.it',
        '+392290680466',
        '["/static/images/9bced8a8-84fa-4b18-b065-a1b53907d345.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg"]'::jsonb,
        'Ex ab maxime sequi eveniet ullam temporibus saepe possimus.
Repellendus eveniet dolores veritatis beatae.
Officiis quibusdam fugit fugiat.
Laborum optio et tempora adipisci optio.
Debitis similique in suscipit.'
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        6,
        142::numeric(12,2),
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Fatima Puca',
        'https://hungry-owner.com',
        332.876,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Evaristo.Russo38@yahoo.it',
        '+399841371439',
        '["/static/images/3e7f5444-b782-4eec-a42a-d6c8a890d142.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/9ff5b9ae-eb85-43d1-b1b4-2739151af941.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg"]'::jsonb,
        'Odio reiciendis suscipit assumenda inventore non quam reprehenderit dolorem laudantium.
Illum dolorum aperiam et excepturi.
Ipsum ullam corrupti.
Voluptate commodi laboriosam eligendi animi distinctio hic quibusdam a.'
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        9,
        138::numeric(12,2),
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Lucrezia Morri',
        'https://little-hanger.net',
        331.408,
        '08:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Galeazzo_Lucia@email.it',
        '+399729938896',
        '["/static/images/60f5b463-120c-45d7-b68b-747e6a20e4f4.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/4a74a4be-9379-46af-9fe2-d8611a5ef1ae.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/909d7fa4-2d88-4768-8f6b-2250ff7f5731.jpg"]'::jsonb,
        'Vero voluptate qui dolor nihil veniam.
Molestiae suscipit nostrum error aliquid delectus nemo.'
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        6,
        55::numeric(12,2),
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Orlando Zanatta',
        'http://official-kick-off.net',
        279.101,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Bino86@yahoo.it',
        '+393351453152',
        '["/static/images/9a116e20-4dbc-40ba-bdb6-ab60a9868259.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/d7d6dffb-1a52-43f0-8059-af64d7cb016c.jpg"]'::jsonb,
        'Laborum quasi a.
Necessitatibus at eos eius.
Minus provident blanditiis.'
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        10,
        57::numeric(12,2),
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Antelmo Di Lorenzo',
        'http://piercing-university.net',
        318.069,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Corinna_Bonifazi98@hotmail.com',
        '+396408254243',
        '["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg","/static/images/ad5235d9-78fc-466e-8bca-ac0e84bd7cc9.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg"]'::jsonb,
        'Repellat provident quisquam.
Error occaecati cupiditate.'
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        2,
        124::numeric(12,2),
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Adalberta Bianchetti',
        'https://quarrelsome-acceptance.org',
        320.239,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Protasio49@yahoo.com',
        '+396138487339',
        '["/static/images/3faa8125-4d02-4300-b95f-74aac41ba4db.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg"]'::jsonb,
        'In cupiditate doloribus tenetur quidem laudantium in.
Ullam tempora necessitatibus consequuntur.
Officiis voluptatibus quis repellendus dignissimos.
Consequuntur odit veritatis ipsam.
Corporis suscipit dolor quis temporibus.'
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        7,
        88::numeric(12,2),
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Gonzaga Pizzo',
        'http://lumbering-extinction.it',
        265.754,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Rosita.DiLorenzo80@libero.it',
        '+393956041552',
        '["/static/images/8aabafae-5cbd-4a9d-8196-a266b7d40605.jpg","/static/images/642cfb5f-1945-4783-a22c-29eebbd2212a.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg"]'::jsonb,
        'Cum dicta ullam velit praesentium ratione quam.
Odit repellat delectus optio distinctio vitae sunt necessitatibus ab.
Iure ea tempora assumenda corrupti tempora illo dolorum expedita.
Assumenda possimus corrupti.'
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        4,
        97::numeric(12,2),
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Santina Tonelli',
        'https://rubbery-madam.net',
        310.711,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Erminio28@gmail.com',
        '+395612448087',
        '["/static/images/7c62f772-8cd6-4fa4-a0fb-da8aab8c5855.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/324cbba7-ffe0-48f4-baa3-0363658b13ab.jpg","/static/images/091c0fcc-b6cb-4a98-8d57-4ee228f77482.jpg"]'::jsonb,
        'Ex dolor nostrum voluptate natus est.
Tempora placeat veritatis esse facilis debitis.
Commodi minima omnis tempora accusantium.'
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        1,
        136::numeric(12,2),
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Romoaldo Viola',
        'http://fortunate-knee.it',
        327.373,
        '09:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Gabriele_Terzo@gmail.com',
        '+395607494619',
        '["/static/images/8aabafae-5cbd-4a9d-8196-a266b7d40605.jpg","/static/images/67c14f14-790c-4e62-8e54-9d22cb703dc4.jpg","/static/images/d9bbf90d-8dd2-442b-8dd8-87eb6cae8b5a.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/2450ceaf-ddb8-444b-b24d-f0405c7dc9a8.jpg"]'::jsonb,
        'Laboriosam id cum doloremque id voluptate dolor.
Quam ipsam dicta doloremque excepturi cumque.'
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        10,
        122::numeric(12,2),
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Auro Cicchetti',
        'https://prime-user.com',
        295.47,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Giulitta62@email.it',
        '+392014779558',
        '["/static/images/b8909acc-6822-40ea-ac2a-6c8de7b03cf8.jpg","/static/images/2e614b17-9d2a-4e3c-90ac-4d2629bd1bf3.jpg","/static/images/f1aa867a-eaf0-4700-9d93-e4d8e9152331.jpg","/static/images/0e589541-f332-417a-ab11-a89fb37ac859.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg"]'::jsonb,
        'Consequuntur officia nisi voluptate.
Aut eius voluptatem dolore.'
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        6,
        57::numeric(12,2),
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Ing. Enimia Mattei',
        'https://spotless-proximal.net',
        311.602,
        '01:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Ezechiele.Giovannelli4@libero.it',
        '+394150495959',
        '["/static/images/90ed2500-1c29-4db5-ba74-36ac493363de.jpg","/static/images/95e11c18-e00f-4287-8d5c-3ddf8272df83.jpg","/static/images/b75da490-0dbe-4e58-bfa9-548fbc9daee1.jpg","/static/images/655defdd-43a3-4583-8d3c-40ed296f24ac.jpg","/static/images/2b2f2476-6fec-40b4-8481-695d6f69f144.jpg"]'::jsonb,
        'Odio temporibus nulla quo.
Assumenda nam saepe suscipit doloremque provident minima.
Velit impedit accusantium blanditiis temporibus.
Saepe quas ex.'
      );
    
  

      CREATE OR REPLACE FUNCTION public.insert_hut_worker(
        hwid integer,
        email varchar,
        password varchar,
        first_name varchar,
        last_name varchar,
        role integer,
        hut_id integer,
        approved boolean
      ) RETURNS VOID AS
      $func$
      DECLARE
        user_id integer;
      BEGIN
      INSERT INTO "public"."users" (
        "id",
        "email",
        "password",
        "firstName",
        "lastName",
        "role",
        "verified",
        "approved"
      ) VALUES(
        hwid, email, password, first_name, last_name, role, true, approved
      ) returning id into user_id;

      INSERT INTO "public"."hut-worker" (
        "userId",
        "hutId"
      ) VALUES ( user_id, hut_id);
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hut_worker"(
        7,
        'hutWorker0@gmail.com',
        '$2b$10$qmS4a3u09RRZta/e/DHXF.d68RL6gkx47je61d8hMmTrJ4kLmBbG6',
        'Desiderio',
        'Sucameli',
        4,
        1,
        true
      );
    

      select public."insert_hut_worker"(
        8,
        'hutWorker1@gmail.com',
        '$2b$10$PdOjMl6jUq2XTFY0QkUNHOSPNk4YYcpaFAd.ouPKlAV8Mk/0sZKyy',
        'Marana',
        'Petrelli',
        4,
        2,
        false
      );
    

      select public."insert_hut_worker"(
        9,
        'hutWorker2@gmail.com',
        '$2b$10$bxExR8ijs3o6H6atC3.q7OB6NEdxHgiJhsCHKR6A0XZx/44BHutnq',
        'Loredana',
        'D''Ambrosio',
        4,
        3,
        true
      );
    

      select public."insert_hut_worker"(
        10,
        'hutWorker3@gmail.com',
        '$2b$10$F8mIaoEmGFJQl7tY5A2iy.QfpQEwzEewao//ygJffGORnJssg376i',
        'Socrate',
        'Cruciani',
        4,
        4,
        false
      );
    

      select public."insert_hut_worker"(
        11,
        'hutWorker4@gmail.com',
        '$2b$10$HIXEz678Gs0pUpvrmu7LK.z95Bd9Yu8s.I.1ZCnE2hADq4KZrD6Ge',
        'Gianni',
        'Medici',
        4,
        5,
        true
      );
    

      select public."insert_hut_worker"(
        12,
        'hutWorker5@gmail.com',
        '$2b$10$aNKciYJHxavKc9JgZOR0LOfu4M8hTStZSZzJ6qmCIzVqjoTN/.Kiy',
        'Adone',
        'Rotondo',
        4,
        6,
        false
      );
    

      select public."insert_hut_worker"(
        13,
        'hutWorker6@gmail.com',
        '$2b$10$ISZHyuDETXWAji4/gT7l8.nYLGshNsULv8eo5lti9ktNYLzGWpCj6',
        'Teodora',
        'Piscitelli',
        4,
        7,
        true
      );
    

      select public."insert_hut_worker"(
        14,
        'hutWorker7@gmail.com',
        '$2b$10$F2lokctyQggaUEWBinEeSO1qM18BkFDJk3t0MTxYxOUD6vCk/dtQO',
        'Ianira',
        'Casella',
        4,
        8,
        false
      );
    

      select public."insert_hut_worker"(
        15,
        'hutWorker8@gmail.com',
        '$2b$10$oKEpsd6fgN/w7XOYEbxque8QRKoZVfn/yRt1hF6LSENkDVcJHsjhC',
        'Clelia',
        'Argiolas',
        4,
        9,
        true
      );
    

      select public."insert_hut_worker"(
        16,
        'hutWorker9@gmail.com',
        '$2b$10$qQMJGkXtyPsO/1w23eSgX.PIK01LFE5eO7vw6dEiQaditnZItCnZ2',
        'Tarsilla',
        'Pezzi',
        4,
        10,
        false
      );
    

      select public."insert_hut_worker"(
        17,
        'hutWorker10@gmail.com',
        '$2b$10$yCgFD/6.uRsUFltAjlirY.pGjzxBIy8ynqiuyBBZ0TdlcWG30YsRi',
        'Furseo',
        'Moras',
        4,
        11,
        true
      );
    

      select public."insert_hut_worker"(
        18,
        'hutWorker11@gmail.com',
        '$2b$10$HhDlf6P0x8WHqBxY.QbdRe5Vf4eywNV9Mogc8kkh1CCu47efOLp4.',
        'Assunta',
        'Capannolo',
        4,
        12,
        false
      );
    

      select public."insert_hut_worker"(
        19,
        'hutWorker12@gmail.com',
        '$2b$10$ja7dzU4oaY7qjNTLtKZ/x.EPQTdIP.0Ll6xiQWHQJf7Xl27ybkHNq',
        'Vincenza',
        'Casula',
        4,
        13,
        true
      );
    

      select public."insert_hut_worker"(
        20,
        'hutWorker13@gmail.com',
        '$2b$10$Ny86BVQCOjGOVsNL75diPeO9lqKjBqfLdbHS22r.hwHX/Zc89j3FC',
        'Prospero',
        'Pizzi',
        4,
        14,
        false
      );
    

      select public."insert_hut_worker"(
        21,
        'hutWorker14@gmail.com',
        '$2b$10$MG3TXTQpLGJR.//dPGzyHewnxQ6b5MfD.2RzIDraLzfYjClfbDDO6',
        'Costante',
        'Marone',
        4,
        15,
        true
      );
    

      select public."insert_hut_worker"(
        22,
        'hutWorker15@gmail.com',
        '$2b$10$jWxsO8LTw4JxcKhhR8ol3exBZudrWOAnxWtTecjVAEHpao7RfEtsq',
        'Zenaide',
        'Liuzzi',
        4,
        16,
        false
      );
    

      select public."insert_hut_worker"(
        23,
        'hutWorker16@gmail.com',
        '$2b$10$Dyi1j29s96bGEHlh0CzIqeLRHk2mGlq3J86XDwmbHbeIl309AzOdq',
        'Davide',
        'Pizzuti',
        4,
        17,
        true
      );
    

      select public."insert_hut_worker"(
        24,
        'hutWorker17@gmail.com',
        '$2b$10$4N0oxZgGdcOUH7O.gSVKFuR5zMA8oUabcWa57sHn0FxA6Co19ueyy',
        'Ivone',
        'Borgia',
        4,
        18,
        false
      );
    

      select public."insert_hut_worker"(
        25,
        'hutWorker18@gmail.com',
        '$2b$10$EGhje5SvMzqpv/ojhXJUF.k6.4/t3TrobWixUlKkddwbh.ohrkTEG',
        'Nico',
        'Carvelli',
        4,
        19,
        true
      );
    

      select public."insert_hut_worker"(
        26,
        'hutWorker19@gmail.com',
        '$2b$10$9XEYHmaS7t3KROKQbxLJS.78sbdYtxgBocE2RxRSdUtMOpi5H5QxG',
        'Mareta',
        'Zullo',
        4,
        20,
        false
      );
    

      select public."insert_hut_worker"(
        27,
        'hutWorker20@gmail.com',
        '$2b$10$Licj6NqJ3ou13UGPymm95uM7sawOPEM6.8DzlsC09Kxji./wjXwXm',
        'Fiorenziano',
        'Belvisi',
        4,
        21,
        true
      );
    

      select public."insert_hut_worker"(
        28,
        'hutWorker21@gmail.com',
        '$2b$10$UlfYKaHmjRbemnXjUHCVy.ft/pJ.3euAJvot67j/cijdzMYBE.KZO',
        'Ludovico',
        'D''Anna',
        4,
        22,
        false
      );
    

      select public."insert_hut_worker"(
        29,
        'hutWorker22@gmail.com',
        '$2b$10$EtN98ltbuePCRzY0ycbuLOP3JkdjqXH.zODVJXJXEKUx8Z6FygrCe',
        'Asia',
        'Giugliano',
        4,
        23,
        true
      );
    

      select public."insert_hut_worker"(
        30,
        'hutWorker23@gmail.com',
        '$2b$10$LSTzT1XqtOWFFWGcUCMZoeVYt0sPb18bTfp1FWWeMgrGCXqHYHov2',
        'Massimiliano',
        'Pozzi',
        4,
        24,
        false
      );
    

      select public."insert_hut_worker"(
        31,
        'hutWorker24@gmail.com',
        '$2b$10$3sXf8zl4QvxYwDw6vfBTa.BwOlvBv4PFhQpW5YSFKQcR7g/CI2UhK',
        'Gelsomina',
        'Desogus',
        4,
        25,
        true
      );
    

      select public."insert_hut_worker"(
        32,
        'hutWorker25@gmail.com',
        '$2b$10$kYiAjEp6n6i/BBS/AtI48eCzx/64y/i7avEeL9figzEJfV6ojnTu6',
        'Marica',
        'Cardini',
        4,
        26,
        false
      );
    

      select public."insert_hut_worker"(
        33,
        'hutWorker26@gmail.com',
        '$2b$10$dn5an0NA725KvyU2s6/wMuB3e9pfbqkk8Hgh5kRB8qffS3Fb7NoG6',
        'Gianmaria',
        'Munaro',
        4,
        27,
        true
      );
    

      select public."insert_hut_worker"(
        34,
        'hutWorker27@gmail.com',
        '$2b$10$3eNE3FmfdUwB5P4lE/KwSurYuCdZMgQ4nP.mS8LcjEusM7dFG2iMi',
        'Ermilo',
        'Leoni',
        4,
        28,
        false
      );
    

      select public."insert_hut_worker"(
        35,
        'hutWorker28@gmail.com',
        '$2b$10$Wwm1qMi8SI3IUB0P75poIex0mM/VY6tKvvOWHkU/WrBEuuxCX4Cp6',
        'Penelope',
        'Tonini',
        4,
        29,
        true
      );
    

      select public."insert_hut_worker"(
        36,
        'hutWorker29@gmail.com',
        '$2b$10$4Hu/faoF/mf7krQMtuhv0uG3uk0IIH26nKox6vatAwNcTBQy0JMju',
        'Babila',
        'Di Gregorio',
        4,
        30,
        false
      );
    

      select public."insert_hut_worker"(
        37,
        'hutWorker30@gmail.com',
        '$2b$10$ds49u6HxmLRpv6iGvPTF3.zqdran8vEgh9OnRV8PusaQTBvSSfMea',
        'Rodrigo',
        'Salatiello',
        4,
        31,
        true
      );
    

      select public."insert_hut_worker"(
        38,
        'hutWorker31@gmail.com',
        '$2b$10$Qnjd.BOmFBxVpUvKpgVcauPvJHqa1QgkNcAgYwjeRnp2Y4RkX6r5K',
        'Girolamo',
        'Barra',
        4,
        32,
        false
      );
    

      select public."insert_hut_worker"(
        39,
        'hutWorker32@gmail.com',
        '$2b$10$r9Wcdx3C50sl3qyl/INWQ.ANsNt11.p9Ba.MqlCyoZKdHi2FkIJMe',
        'Bassiano',
        'Luongo',
        4,
        33,
        true
      );
    

      select public."insert_hut_worker"(
        40,
        'hutWorker33@gmail.com',
        '$2b$10$LSjBf/nhMXzYjSkbt/W59.LHZiW5yI9v6eOv5YkX3fI5pYikUWBJ2',
        'Maurilio',
        'Di Rocco',
        4,
        34,
        false
      );
    

      select public."insert_hut_worker"(
        41,
        'hutWorker34@gmail.com',
        '$2b$10$525g3RbeLIlN6XxcYwAxXOazqx/ykZdB8GgEUCtADbDTvos.aNJrS',
        'Agesilao',
        'Carraro',
        4,
        35,
        true
      );
    

      select public."insert_hut_worker"(
        42,
        'hutWorker35@gmail.com',
        '$2b$10$O2DplYKdaxnastytGQOED.pyOuHD1ES4V3Fjua0cviJ1OoOJQN48G',
        'Sandro',
        'Pastore',
        4,
        36,
        false
      );
    

      select public."insert_hut_worker"(
        43,
        'hutWorker36@gmail.com',
        '$2b$10$DzJYx6umuXU0GeUbJ5Tfc.01MxUwQ/grovPrKOGkSulx8r5nrXYjW',
        'Stella',
        'Mastroianni',
        4,
        37,
        true
      );
    

      select public."insert_hut_worker"(
        44,
        'hutWorker37@gmail.com',
        '$2b$10$WuZ5L2ZI6vqs0T/vNGJTNu8RzCKXJrWPtshmcNblbjwkClqCBlEV.',
        'Ursmaro',
        'Puleo',
        4,
        38,
        false
      );
    

      select public."insert_hut_worker"(
        45,
        'hutWorker38@gmail.com',
        '$2b$10$mhan4.rUhr/Hh2xbWtPCuuJR/SL1L6m520iLmGt3AfZtL.eu5Ch32',
        'Fermiano',
        'Talarico',
        4,
        39,
        true
      );
    

      select public."insert_hut_worker"(
        46,
        'hutWorker39@gmail.com',
        '$2b$10$knSVI8d6PHxCQTFq7L63A.NqkZdQ.ShcjXJ2R3X0sjrvWxy6NkmNG',
        'Editta',
        'Anzalone',
        4,
        40,
        false
      );
    

      select public."insert_hut_worker"(
        47,
        'hutWorker40@gmail.com',
        '$2b$10$RA1I5CNGwmbeWPEmVe3YsuemhlwlgkALu4WgvRETyEDdoEGMQ.dSi',
        'Fernanda',
        'Torri',
        4,
        41,
        true
      );
    

      select public."insert_hut_worker"(
        48,
        'hutWorker41@gmail.com',
        '$2b$10$.rbihTF6rNhsBh.3oqwLI.hbKD3MJpgKpIsLVmMsVPq7cLssqMzJm',
        'Saffo',
        'Iuliano',
        4,
        42,
        false
      );
    

      select public."insert_hut_worker"(
        49,
        'hutWorker42@gmail.com',
        '$2b$10$niMWJI2WJKaVAmgZ6iYHjuC4tbEpxSAhG/pTaYhddFFImg92NGAu6',
        'Domenica',
        'Vallone',
        4,
        43,
        true
      );
    

      select public."insert_hut_worker"(
        50,
        'hutWorker43@gmail.com',
        '$2b$10$4PpJ88LkGwJwNXbU6Il8zebBYTtXRw63m07q26i/HibhTSgrCWeZS',
        'Imelda',
        'Scorza',
        4,
        44,
        false
      );
    

      select public."insert_hut_worker"(
        51,
        'hutWorker44@gmail.com',
        '$2b$10$R/8rQi/I/Si1tyYdn9Zcq.wFTYx75nu.fP4MGDeW7t3M7RsxjjRRe',
        'Elpidio',
        'Manno',
        4,
        45,
        true
      );
    

      select public."insert_hut_worker"(
        52,
        'hutWorker45@gmail.com',
        '$2b$10$Zq9JueKVxXEkynHgKRcn.OtDV5oAQzdgbRJVmkJXLr0dt0SxbX4nS',
        'Solange',
        'Coviello',
        4,
        46,
        false
      );
    

      select public."insert_hut_worker"(
        53,
        'hutWorker46@gmail.com',
        '$2b$10$9SgKetAejqOC6YbKKiiYKuATkDtrbC.PNieHfyh12lV9HhVow0YZu',
        'Stella',
        'Filice',
        4,
        47,
        true
      );
    

      select public."insert_hut_worker"(
        54,
        'hutWorker47@gmail.com',
        '$2b$10$nVOAs5XeHQDMb.t3KlmZZu9t5t1B0GWqK2SYsTGuVJQ0ZxFd0J2oa',
        'Cirano',
        'Tomaselli',
        4,
        48,
        false
      );
    

      select public."insert_hut_worker"(
        55,
        'hutWorker48@gmail.com',
        '$2b$10$ZuFMoYFNBF5jLyehXoDHFOKHLeWM7GMf4R9L2bgi15CuYhOrT86Z6',
        'Giuseppina',
        'Vacca',
        4,
        49,
        true
      );
    

      select public."insert_hut_worker"(
        56,
        'hutWorker49@gmail.com',
        '$2b$10$QEOvLhSRWKF2oMnj52Nktu6tbSyjX78aNEYmEhe3sElDFw5/7YlgW',
        'Brigitta',
        'Montesano',
        4,
        50,
        false
      );
    

      select public."insert_hut_worker"(
        57,
        'hutWorker50@gmail.com',
        '$2b$10$lUZZpAdf4hJKr0HGqhlbOOVrWNoGJd6LxMG6JinJGcwPk17Q37wf6',
        'Natalina',
        'Baraldi',
        4,
        51,
        true
      );
    

      select public."insert_hut_worker"(
        58,
        'hutWorker51@gmail.com',
        '$2b$10$goFn9mGf.WDzglbseotR5eLq1TzZwMBlCDMGVcn4nqs.317obo.22',
        'Cino',
        'Lo Presti',
        4,
        52,
        false
      );
    

      select public."insert_hut_worker"(
        59,
        'hutWorker52@gmail.com',
        '$2b$10$fvBB2ymmrI.P5XdJbEv1MeJR45.Ws/r/j6j5v8GRL5W6a4xADfa.u',
        'Carmela',
        'Raniolo',
        4,
        53,
        true
      );
    

      select public."insert_hut_worker"(
        60,
        'hutWorker53@gmail.com',
        '$2b$10$GwM1Z3WDkruQJY0CGj2rNuZ0dRKXcTyLXIfeQvmS1IzeOKWeXYm4q',
        'Fosca',
        'Zanotti',
        4,
        54,
        false
      );
    

      select public."insert_hut_worker"(
        61,
        'hutWorker54@gmail.com',
        '$2b$10$9VD3Wy7gqB2Vc7BD/wXCpeeU0ByLWiFfqhbo1gcKWIcZdwQqLOQ4e',
        'Lanfranco',
        'Ragone',
        4,
        55,
        true
      );
    

      select public."insert_hut_worker"(
        62,
        'hutWorker55@gmail.com',
        '$2b$10$LvMcd8zTmk6zoP.DvY078ebvrZ07bWZCR6ZYk0mreGzGYW1LLfdRC',
        'Miranda',
        'Luise',
        4,
        56,
        false
      );
    

      select public."insert_hut_worker"(
        63,
        'hutWorker56@gmail.com',
        '$2b$10$oV/ikU.6ysB/fbUy.GOru.bKd9WHdN0i39L5R0lrFuJuFCNHeG8J6',
        'Sisto',
        'Catellani',
        4,
        57,
        true
      );
    

      select public."insert_hut_worker"(
        64,
        'hutWorker57@gmail.com',
        '$2b$10$sbqwjMRMMER2.EfW5f9t3uYcfsLYfz2I9mHSJR927C6B5PGXra.J2',
        'Romolo',
        'Secchi',
        4,
        58,
        false
      );
    

      select public."insert_hut_worker"(
        65,
        'hutWorker58@gmail.com',
        '$2b$10$YSFF0SL5flmfgXC0x3KhSOL2b6DU.yA0XD6N4zKFbJFkVH7GPKoVa',
        'Quiteria',
        'Pucci',
        4,
        59,
        true
      );
    

      select public."insert_hut_worker"(
        66,
        'hutWorker59@gmail.com',
        '$2b$10$QDSx3KJtg/PRFGFK86nN0eYZuHODbGyXNaFYdrJtdPFPRCpr01cDC',
        'Benigna',
        'Tonini',
        4,
        60,
        false
      );
    

      select public."insert_hut_worker"(
        67,
        'hutWorker60@gmail.com',
        '$2b$10$9dfXj9fMiHfJER6wK8LNO.VQwONbZprH/utCdjc7I9Ap5fdoenXyW',
        'Attilio',
        'Di Palma',
        4,
        61,
        true
      );
    

      select public."insert_hut_worker"(
        68,
        'hutWorker61@gmail.com',
        '$2b$10$k6Meft6HNhXbCsRfXGUDSeA9REXPfZg7PPZUrM82trblyg9npEDzu',
        'Morgana',
        'Ricci',
        4,
        62,
        false
      );
    

      select public."insert_hut_worker"(
        69,
        'hutWorker62@gmail.com',
        '$2b$10$EKXaDgtmKMICdUuAQlVMce57DU5MOjCIVNBnpRC7fdNuouyX4WxPK',
        'Adamo',
        'Troisi',
        4,
        63,
        true
      );
    

      select public."insert_hut_worker"(
        70,
        'hutWorker63@gmail.com',
        '$2b$10$vXcDXEghVVg3Tz8yDvC/nuF6/4WQckR3kIsJKK1bV2FVegzPGWnLq',
        'Generoso',
        'Benedetto',
        4,
        64,
        false
      );
    

      select public."insert_hut_worker"(
        71,
        'hutWorker64@gmail.com',
        '$2b$10$hrWdB7l6si8PO9pc0m3zF.NTkG.pSu00QLF3.4j6y6ZCUofqdO.te',
        'Cassiopea',
        'Scanu',
        4,
        65,
        true
      );
    

      select public."insert_hut_worker"(
        72,
        'hutWorker65@gmail.com',
        '$2b$10$XYwScUtX/kra6uci./qSJuUO300PNZKPsiIlkSTwvZLMSgOl1wVoi',
        'Manuele',
        'Di Benedetto',
        4,
        66,
        false
      );
    

      select public."insert_hut_worker"(
        73,
        'hutWorker66@gmail.com',
        '$2b$10$XMAVnUQn/xXlZDV53wXy4uU3jEiuYkc3L9BHpDUAkj9v2tAACIMy2',
        'Diamante',
        'Abbondanza',
        4,
        67,
        true
      );
    

      select public."insert_hut_worker"(
        74,
        'hutWorker67@gmail.com',
        '$2b$10$PAXsRGqImJwLDhI0LoLR8eTAJaRcDowUloecsS4.bH0/SsL0P6Tza',
        'Ottaviano',
        'Caccavo',
        4,
        68,
        false
      );
    

      select public."insert_hut_worker"(
        75,
        'hutWorker68@gmail.com',
        '$2b$10$aZmZRpLr5cEAzSqd1NZrNeW5JNs0ZG4wRV5Gs9fVBEKIrakYXd.hO',
        'Porfirio',
        'Bindi',
        4,
        69,
        true
      );
    

      select public."insert_hut_worker"(
        76,
        'hutWorker69@gmail.com',
        '$2b$10$xbvUEufohC6Q.6nl67yk5eRId3Y6oSfXZlIrbxeMF4JcBWR.9tcp6',
        'Cuniberto',
        'Secci',
        4,
        70,
        false
      );
    

      select public."insert_hut_worker"(
        77,
        'hutWorker70@gmail.com',
        '$2b$10$gTIcNv7xQ1KjqN3tReY0AeUoFSfmifjev0yYMXuc8y/eM.a06sQAS',
        'Zenobia',
        'Reale',
        4,
        71,
        true
      );
    

      select public."insert_hut_worker"(
        78,
        'hutWorker71@gmail.com',
        '$2b$10$rJS3IK/TVVsBl4QDPqpqWeB/cjENdDWqsTifvXo9m9N/RMWUIgcCm',
        'Gaudenzio',
        'Guglielmi',
        4,
        72,
        false
      );
    

      select public."insert_hut_worker"(
        79,
        'hutWorker72@gmail.com',
        '$2b$10$SDJURmSFZm0ZnsB7fCgGH.mKRiRF/k5ZqbcIW7/zbg2aOfibSI29y',
        'Gioventino',
        'Gatta',
        4,
        73,
        true
      );
    

      select public."insert_hut_worker"(
        80,
        'hutWorker73@gmail.com',
        '$2b$10$EftKKtzIcParRORVZLR2VeaYolIs4QeWc.9u6xvAw7wpS/ofyK/fC',
        'Germana',
        'Iezzi',
        4,
        74,
        false
      );
    

      select public."insert_hut_worker"(
        81,
        'hutWorker74@gmail.com',
        '$2b$10$zIOh7C/bjhs2HlhJl/mMHOCBwqYdi2oQvE9roqstPuyH5gTXwx2mi',
        'Mamante',
        'Fontana',
        4,
        75,
        true
      );
    

      select public."insert_hut_worker"(
        82,
        'hutWorker75@gmail.com',
        '$2b$10$YQomxA7NyDDx4InyI1/z5umA88Da0ug.KeqNwH5wTME3nwgs/nwZm',
        'Viviano',
        'Cerutti',
        4,
        76,
        false
      );
    

      select public."insert_hut_worker"(
        83,
        'hutWorker76@gmail.com',
        '$2b$10$zVe2KuO4NwmENcd2nC6MOuQbg3f9zJdEWNoeYSi3Jn/5ybpBj4fpu',
        'Venanzio',
        'Virgilio',
        4,
        77,
        true
      );
    

      select public."insert_hut_worker"(
        84,
        'hutWorker77@gmail.com',
        '$2b$10$AuDy2QrwOQAQz6jETFBzvOxIjpS/p.1lwBpMFHD6CcR2LS7hmU5M2',
        'Veriana',
        'Piredda',
        4,
        78,
        false
      );
    

      select public."insert_hut_worker"(
        85,
        'hutWorker78@gmail.com',
        '$2b$10$zEmqe.BmKNxQGlypiUMk1eRKwpNZzn0ubKqw5wQ1MbREJoEr.qCci',
        'Benigna',
        'Accardo',
        4,
        79,
        true
      );
    

      select public."insert_hut_worker"(
        86,
        'hutWorker79@gmail.com',
        '$2b$10$0j7P/3.X141ZBCjcwJMoi.T0pi/4HzrSWeGjRMlbnzHpdAQa8hOPa',
        'Iginia',
        'Boccia',
        4,
        80,
        false
      );
    

      select public."insert_hut_worker"(
        87,
        'hutWorker80@gmail.com',
        '$2b$10$rVm6ADWyRikLvnm03jnrouWFA.dUDhcDjDbrPD5W2ynvbssMiZszW',
        'Ilaria',
        'Vannini',
        4,
        81,
        true
      );
    

      select public."insert_hut_worker"(
        88,
        'hutWorker81@gmail.com',
        '$2b$10$XcrfNFy4p3ve2l.aEBg6PeALfuyHIBsjzdTJ5LXDZPeIFEN.JdZTG',
        'Niniano',
        'Traini',
        4,
        82,
        false
      );
    

      select public."insert_hut_worker"(
        89,
        'hutWorker82@gmail.com',
        '$2b$10$JZz.zbizzM3JKyJijvQaz.DUfE6Aj8PdqBaHvavwE/.Y2nTt8ajBy',
        'Prudenzio',
        'Iovino',
        4,
        83,
        true
      );
    

      select public."insert_hut_worker"(
        90,
        'hutWorker83@gmail.com',
        '$2b$10$kuxFFrGyzEX5LrEfZ2ZrLe29iDyYHrNSJThdx6S96L1h6j5XRdyxK',
        'Plinio',
        'Sacchet',
        4,
        84,
        false
      );
    

      select public."insert_hut_worker"(
        91,
        'hutWorker84@gmail.com',
        '$2b$10$dLYxVx4W2X1YLJjXdF3uT.6FeaBAyboYCiaMeYBLYIVy1u6nQhJzm',
        'Zabina',
        'Acquadro',
        4,
        85,
        true
      );
    

      select public."insert_hut_worker"(
        92,
        'hutWorker85@gmail.com',
        '$2b$10$fhBz5t5iAMZiJpVREPGpAeCY.QtAjg7/7hgiikLrDlwEH2nTa/djS',
        'Giosuè',
        'Rago',
        4,
        86,
        false
      );
    

      select public."insert_hut_worker"(
        93,
        'hutWorker86@gmail.com',
        '$2b$10$iSDnABJIucYGwIvmTqg06emXWDzGT90/uzNW4umkvHBeE5SPEvNry',
        'Delia',
        'Balistreri',
        4,
        87,
        true
      );
    

      select public."insert_hut_worker"(
        94,
        'hutWorker87@gmail.com',
        '$2b$10$XHFYgGMtzDldX5kuZOxkXuvF1BBl3E7IPx0pyYdsBIzxhFFwgqIr.',
        'Ettore',
        'Bove',
        4,
        88,
        false
      );
    

      select public."insert_hut_worker"(
        95,
        'hutWorker88@gmail.com',
        '$2b$10$B49Iu1CS.llUvhh3k1BgiewYEzhFdLDcOdml68CtQS11I0PmHiNWu',
        'Rossana',
        'Cara',
        4,
        89,
        true
      );
    

      select public."insert_hut_worker"(
        96,
        'hutWorker89@gmail.com',
        '$2b$10$SQRluA.BGeyGgwXRVT6SFuE0O6K50CHY.h8jEvLbyLkhL0R4wtNYq',
        'Rosalia',
        'Granata',
        4,
        90,
        false
      );
    

      select public."insert_hut_worker"(
        97,
        'hutWorker90@gmail.com',
        '$2b$10$sX7NeT7bC8znXYZlvGFUCOrbb6xvv6vGCMgqVvyN6eIBn57qNUhOm',
        'Postumio',
        'Mastrogiacomo',
        4,
        91,
        true
      );
    

      select public."insert_hut_worker"(
        98,
        'hutWorker91@gmail.com',
        '$2b$10$caFw5U5o/cChVv74iJx19.cjVQhqHV/XLgLnbBCMiYAJNZWva44DG',
        'Lidania',
        'Amerio',
        4,
        92,
        false
      );
    

      select public."insert_hut_worker"(
        99,
        'hutWorker92@gmail.com',
        '$2b$10$JdwYXRekRru6GsvtmypvuefzhhTWauJQetaamJNq1pj7vSEnjkChC',
        'Cristiana',
        'Moretti',
        4,
        93,
        true
      );
    

      select public."insert_hut_worker"(
        100,
        'hutWorker93@gmail.com',
        '$2b$10$xPNDhTJEZLmGRcBIgihRQ.76WWK7qyj7JM.CfVOmrdeEyBdOwodaC',
        'Zabina',
        'Scrofani',
        4,
        94,
        false
      );
    

      select public."insert_hut_worker"(
        101,
        'hutWorker94@gmail.com',
        '$2b$10$yqLVkLVHVCT5tHjreBHZ0Ocr7DF2xZ93xSM0CAA9jG0yD7TdSUeGy',
        'Ghita',
        'Tretola',
        4,
        95,
        true
      );
    

      select public."insert_hut_worker"(
        102,
        'hutWorker95@gmail.com',
        '$2b$10$Liwz7qjPabM1GHH8ce67g.9vGxEGHq8GAsKS37de3D70ZnSLTxpm6',
        'Leandro',
        'Callegari',
        4,
        96,
        false
      );
    

      select public."insert_hut_worker"(
        103,
        'hutWorker96@gmail.com',
        '$2b$10$DWDyJotXu0cgLZMgNGUbv.ymgx8f7NBwAblFpRvOXiaafgMFYiY4y',
        'Daciano',
        'Damiano',
        4,
        97,
        true
      );
    

      select public."insert_hut_worker"(
        104,
        'hutWorker97@gmail.com',
        '$2b$10$r5zqLeoRKYGkIlJ7nPtD0.lA9qlzHYsW4lkQFjenwyMroLoJPmhIy',
        'Quasimodo',
        'Braia',
        4,
        98,
        false
      );
    

      select public."insert_hut_worker"(
        105,
        'hutWorker98@gmail.com',
        '$2b$10$.idvbwc/sOr0P4.8AsZ4W.CrVjoTv4GDHTDL6/ZpxEpqh3R/2WevS',
        'Amato',
        'Ferrando',
        4,
        99,
        true
      );
    

      select public."insert_hut_worker"(
        106,
        'hutWorker99@gmail.com',
        '$2b$10$N62siMtwMyI.kMuxrVP1e.2B4qcKKPfFeUioXBx3lrEuIzv6x.ZI2',
        'Cecco',
        'Ciani',
        4,
        100,
        false
      );
    

      select public."insert_hut_worker"(
        107,
        'hutWorker100@gmail.com',
        '$2b$10$v7PgFdXIHxumhm2c4fI6Y.yvv7xLVzF9wvo5nQQKlONk2NUn.LeOO',
        'Ilenia',
        'Fumagalli',
        4,
        101,
        true
      );
    

      select public."insert_hut_worker"(
        108,
        'hutWorker101@gmail.com',
        '$2b$10$rjh7aGKFdpmTrsd7SpEgIuywgl/2W2Upp5Sr71u2NKA7PsASl4Te2',
        'Severiano',
        'Mori',
        4,
        102,
        false
      );
    

      select public."insert_hut_worker"(
        109,
        'hutWorker102@gmail.com',
        '$2b$10$jqtppLnE7IM2kFiSaALy6.F8Jve.iVgRSOuIpHzThmyYW2H9wu9gu',
        'Antonella',
        'Farina',
        4,
        103,
        true
      );
    

      select public."insert_hut_worker"(
        110,
        'hutWorker103@gmail.com',
        '$2b$10$nAYWTXl9qkwf7Kb11c3Qtef2v3q0PTf2FqyYO0PhNwkporkw34rE2',
        'Fatima',
        'Fischetti',
        4,
        104,
        false
      );
    

      select public."insert_hut_worker"(
        111,
        'hutWorker104@gmail.com',
        '$2b$10$pkC2nVJwKkmcAyh8euRTDuTAq9ddxeGa0gZ7eYtRxX8r3edCKX.8W',
        'Annabella',
        'De Palma',
        4,
        105,
        true
      );
    

      select public."insert_hut_worker"(
        112,
        'hutWorker105@gmail.com',
        '$2b$10$V2dB49HhrczJtiT/69Qvye.6H7a3yzeNpLPFBwlZi1QfU6fNV2BAW',
        'Cesare',
        'De Blasi',
        4,
        106,
        false
      );
    

      select public."insert_hut_worker"(
        113,
        'hutWorker106@gmail.com',
        '$2b$10$H8n3L4uDaVqfj2kLfkkWa.TE07bRlHqKd44gR5zxEtu2CR9cWDofK',
        'Grato',
        'Scalia',
        4,
        107,
        true
      );
    

      select public."insert_hut_worker"(
        114,
        'hutWorker107@gmail.com',
        '$2b$10$uAlSwrloogcIGEuMaTyg5uDbQ9v3W/Wi1tDJ8VTn5n.jHuklbzqlW',
        'Tiziana',
        'Zanetti',
        4,
        108,
        false
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '69 Via Modica, Bruni laziale, Italy',
        'Bruni laziale',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        36,
        '243 Borgo Ilva, Rocco lido, Italy',
        'Rocco lido',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        115,
        '2 Strada Delizia, Sesto Alessio, Italy',
        'Sesto Alessio',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        117,
        '1 Strada Bacci, Serena a mare, Italy',
        'Serena a mare',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        257,
        '782 Borgo Italia, Valerico nell''emilia, Italy',
        'Valerico nell''emilia',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        194,
        '56 Rotonda Quinziano, San Amaranto, Italy',
        'San Amaranto',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        238,
        '4 Piazza Vittori, Consiglio terme, Italy',
        'Consiglio terme',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        256,
        '8 Via Argiolas, Macaria umbro, Italy',
        'Macaria umbro',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        256,
        '51 Piazza Vito, Sessa umbro, Italy',
        'Sessa umbro',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        97,
        '8 Borgo Grandi, Adelina del friuli, Italy',
        'Adelina del friuli',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        188,
        '790 Rotonda Concas, San Pauside, Italy',
        'San Pauside',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        106,
        '365 Contrada Aimone, San Bertolfo, Italy',
        'San Bertolfo',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        43,
        '8 Piazza Errico, Quarto Cataldo ligure, Italy',
        'Quarto Cataldo ligure',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        139,
        '6 Piazza Tedeschi, Marzano veneto, Italy',
        'Marzano veneto',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        220,
        '28 Via Radolfo, San Ezio, Italy',
        'San Ezio',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        104,
        '960 Borgo Alvise, Quarto Catullo, Italy',
        'Quarto Catullo',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        213,
        '9 Via Dacio, Bonini calabro, Italy',
        'Bonini calabro',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        241,
        '99 Via Palumbo, Zunino salentino, Italy',
        'Zunino salentino',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        208,
        '98 Via Baroni, Sesto Adelaide a mare, Italy',
        'Sesto Adelaide a mare',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        274,
        '924 Piazza Zefiro, Albino a mare, Italy',
        'Albino a mare',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        172,
        '03 Rotonda Petrella, San Anna, Italy',
        'San Anna',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        228,
        '8 Contrada Berengario, Arabella veneto, Italy',
        'Arabella veneto',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '25 Borgo Edelberga, Borgo Ivetta, Italy',
        'Borgo Ivetta',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        98,
        '8 Contrada Aratone, Settimo Floriana veneto, Italy',
        'Settimo Floriana veneto',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        107,
        '4 Via Bortolo, Settimo Cherubino, Italy',
        'Settimo Cherubino',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        250,
        '381 Strada Randazzo, Alamanno umbro, Italy',
        'Alamanno umbro',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        50,
        '4 Piazza Cleonico, Onesta salentino, Italy',
        'Onesta salentino',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        35,
        '028 Rotonda Acquaviva, Sesto Marco, Italy',
        'Sesto Marco',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        89,
        '32 Strada Reina, Quarto Enea lido, Italy',
        'Quarto Enea lido',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        97,
        '17 Via Mattia, San Barbarigo veneto, Italy',
        'San Barbarigo veneto',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        60,
        '9 Incrocio Ventura, Borgo Romola, Italy',
        'Borgo Romola',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        254,
        '0 Piazza Minerva, Gaio calabro, Italy',
        'Gaio calabro',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        38,
        '1 Incrocio Baraldi, Ostuni a mare, Italy',
        'Ostuni a mare',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '439 Strada Crocefisso, Quarto Albrico, Italy',
        'Quarto Albrico',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        129,
        '05 Incrocio Sandro, Settimo Leone, Italy',
        'Settimo Leone',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        155,
        '3 Piazza Ermes, Dragone ligure, Italy',
        'Dragone ligure',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        52,
        '4 Via Nanni, Pariggiano sardo, Italy',
        'Pariggiano sardo',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        54,
        '03 Incrocio Zanella, Piero veneto, Italy',
        'Piero veneto',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        115,
        '69 Borgo Narciso, Seconda nell''emilia, Italy',
        'Seconda nell''emilia',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        123,
        '155 Incrocio Antonio, Alighiero umbro, Italy',
        'Alighiero umbro',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '8 Piazza Serafino, Borgo Ildegarda laziale, Italy',
        'Borgo Ildegarda laziale',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        296,
        '07 Strada Saponaro, Gulino calabro, Italy',
        'Gulino calabro',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        258,
        '720 Borgo Ceccarelli, Petrelli veneto, Italy',
        'Petrelli veneto',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        161,
        '2 Contrada Quirino, Borgo Marta, Italy',
        'Borgo Marta',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        271,
        '5 Contrada Neiva, Ciotola nell''emilia, Italy',
        'Ciotola nell''emilia',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        86,
        '147 Incrocio Schiavon, Rossini laziale, Italy',
        'Rossini laziale',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        246,
        '6 Piazza Fortugno, La Sala sardo, Italy',
        'La Sala sardo',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        50,
        '587 Incrocio Salomone, Sorrentino ligure, Italy',
        'Sorrentino ligure',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        50,
        '2 Borgo Ermes, Sesto Lena laziale, Italy',
        'Sesto Lena laziale',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        269,
        '27 Incrocio Eginardo, Settimo Bruno veneto, Italy',
        'Settimo Bruno veneto',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        68,
        '78 Contrada Edilberto, Sesto Gianluca nell''emilia, Italy',
        'Sesto Gianluca nell''emilia',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '1 Strada Deodato, San Ascanio veneto, Italy',
        'San Ascanio veneto',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        242,
        '91 Incrocio Spizzirri, Viale ligure, Italy',
        'Viale ligure',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '24 Borgo Ercole, Quarto Metello, Italy',
        'Quarto Metello',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        290,
        '34 Piazza Montalbano, Aristofane calabro, Italy',
        'Aristofane calabro',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        221,
        '192 Rotonda Flaviano, Lodovica nell''emilia, Italy',
        'Lodovica nell''emilia',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        232,
        '3 Rotonda Di Ciocco, Sesto Ivano, Italy',
        'Sesto Ivano',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        182,
        '6 Via Fedro, Quarto Pierangelo salentino, Italy',
        'Quarto Pierangelo salentino',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        212,
        '099 Strada Fasano, Costantin del friuli, Italy',
        'Costantin del friuli',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        282,
        '72 Borgo Coronato, Quarto Cassio laziale, Italy',
        'Quarto Cassio laziale',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        104,
        '62 Via Scalia, San Adalgisa ligure, Italy',
        'San Adalgisa ligure',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        159,
        '9 Piazza Militello, Fulvia sardo, Italy',
        'Fulvia sardo',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        207,
        '1 Strada Raffaella, Sesto Alberta ligure, Italy',
        'Sesto Alberta ligure',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        70,
        '4 Borgo Guglielmo, Sesto Dulina nell''emilia, Italy',
        'Sesto Dulina nell''emilia',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        291,
        '02 Piazza Lazzaro, Quarto Leonardo a mare, Italy',
        'Quarto Leonardo a mare',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        50,
        '20 Via Demetria, Sesto Calpurnia, Italy',
        'Sesto Calpurnia',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        199,
        '08 Via Cleopatra, Settimo Aurelia sardo, Italy',
        'Settimo Aurelia sardo',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        84,
        '9 Piazza Carnevale, Pierluigi veneto, Italy',
        'Pierluigi veneto',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        110,
        '759 Rotonda Caforio, Settimo Gregorio, Italy',
        'Settimo Gregorio',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '852 Contrada Liboria, Errante ligure, Italy',
        'Errante ligure',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        206,
        '21 Strada Bergamasco, Lauri sardo, Italy',
        'Lauri sardo',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        270,
        '5 Strada Spagnuolo, Lisa salentino, Italy',
        'Lisa salentino',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        145,
        '632 Incrocio Bernadetta, Borgo Natalia lido, Italy',
        'Borgo Natalia lido',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        255,
        '4 Incrocio Ferrero, Anita del friuli, Italy',
        'Anita del friuli',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        177,
        '1 Rotonda Deriu, Fancello laziale, Italy',
        'Fancello laziale',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        252,
        '36 Borgo Pagani, Pavani sardo, Italy',
        'Pavani sardo',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        252,
        '68 Contrada Alceo, Sesto Anselmo, Italy',
        'Sesto Anselmo',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        267,
        '10 Incrocio Evangelisti, Quarto Novella, Italy',
        'Quarto Novella',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        109,
        '682 Contrada Laura, Settimo Elisa veneto, Italy',
        'Settimo Elisa veneto',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        143,
        '5 Via Lucio, Bonagiunta terme, Italy',
        'Bonagiunta terme',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        84,
        '37 Incrocio Minniti, Borgo Asella, Italy',
        'Borgo Asella',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        96,
        '50 Piazza Elsa, Frasca laziale, Italy',
        'Frasca laziale',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        105,
        '0 Rotonda Archippo, Fausta salentino, Italy',
        'Fausta salentino',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        220,
        '84 Incrocio Solinas, San Caronte, Italy',
        'San Caronte',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        88,
        '35 Rotonda Ernesto, Settimo Graziano calabro, Italy',
        'Settimo Graziano calabro',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        69,
        '5 Strada Salvo, Di Luca nell''emilia, Italy',
        'Di Luca nell''emilia',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        252,
        '1 Rotonda Riccardo, Raimondo terme, Italy',
        'Raimondo terme',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        208,
        '4 Piazza Argenio, Settimo Ticone, Italy',
        'Settimo Ticone',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        164,
        '653 Via Caradonna, Carta sardo, Italy',
        'Carta sardo',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        231,
        '0 Incrocio Desiderata, Borgo Ataleo umbro, Italy',
        'Borgo Ataleo umbro',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        242,
        '95 Rotonda Verecondo, Borgo Cointa, Italy',
        'Borgo Cointa',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        70,
        '3 Contrada Brandi, Borgo Emidio, Italy',
        'Borgo Emidio',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        104,
        '7 Rotonda Aratone, Quarto Liborio, Italy',
        'Quarto Liborio',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        254,
        '613 Via Agostina, Astrid umbro, Italy',
        'Astrid umbro',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        89,
        '21 Rotonda Lecca, Sesto Federico, Italy',
        'Sesto Federico',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        121,
        '2 Borgo Vladimiro, Fiordaliso nell''emilia, Italy',
        'Fiordaliso nell''emilia',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        103,
        '70 Piazza Gatto, Maida umbro, Italy',
        'Maida umbro',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        203,
        '205 Borgo Alberico, Borgo Silvano laziale, Italy',
        'Borgo Silvano laziale',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        89,
        '824 Piazza Agata, Ciriaco sardo, Italy',
        'Ciriaco sardo',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        210,
        '86 Incrocio Romana, Castaldo a mare, Italy',
        'Castaldo a mare',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        79,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        262,
        '010 Incrocio Spagnolo, San Rina, Italy',
        'San Rina',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        109,
        '76 Piazza Floridia, Borgo Elimena, Italy',
        'Borgo Elimena',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        57,
        '39 Via Isidora, Santi lido, Italy',
        'Santi lido',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        156,
        '7 Strada Cristina, Patroclo laziale, Italy',
        'Patroclo laziale',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        98,
        '48 Strada Gualberto, Boris veneto, Italy',
        'Boris veneto',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        91,
        '853 Piazza Marcello, Tomasi del friuli, Italy',
        'Tomasi del friuli',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        93,
        '092 Via Corrao, Sesto Nazzareno sardo, Italy',
        'Sesto Nazzareno sardo',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        234,
        '5 Contrada Semeraro, Borgo Bacco, Italy',
        'Borgo Bacco',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        30,
        '690 Piazza Aquino, Asaro umbro, Italy',
        'Asaro umbro',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        85,
        '974 Rotonda Piersilvio, Lombardo del friuli, Italy',
        'Lombardo del friuli',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        34,
        '3 Rotonda Poggi, Ferrari ligure, Italy',
        'Ferrari ligure',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        181,
        '228 Borgo Errante, Piacentini a mare, Italy',
        'Piacentini a mare',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        277,
        '0 Incrocio Enzo, Quarto Ida, Italy',
        'Quarto Ida',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        111,
        '9 Contrada Liberatore, San Danilo, Italy',
        'San Danilo',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        150,
        '0 Contrada Todaro, Borgo Gomberto, Italy',
        'Borgo Gomberto',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        223,
        '89 Rotonda Vittore, San Salustio, Italy',
        'San Salustio',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        231,
        '529 Borgo Iacovone, Borgo Brunilde, Italy',
        'Borgo Brunilde',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        141,
        '697 Rotonda Manica, San Virginio umbro, Italy',
        'San Virginio umbro',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        128,
        '93 Incrocio Palazzolo, Balzano sardo, Italy',
        'Balzano sardo',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        58,
        '89 Piazza Ione, Settimo Perla, Italy',
        'Settimo Perla',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        252,
        '09 Contrada Dionisia, Settimo Diego, Italy',
        'Settimo Diego',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        299,
        '58 Strada Cleofe, San Galdino laziale, Italy',
        'San Galdino laziale',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        153,
        '3 Borgo Simeoni, Pia del friuli, Italy',
        'Pia del friuli',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        83,
        '383 Rotonda Almiro, San Elda sardo, Italy',
        'San Elda sardo',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        57,
        '522 Piazza Sosteneo, Settimo Evodio, Italy',
        'Settimo Evodio',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '842 Incrocio Tavani, Parmenio del friuli, Italy',
        'Parmenio del friuli',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        256,
        '321 Rotonda Bonanno, Vianello a mare, Italy',
        'Vianello a mare',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        168,
        '082 Borgo Melchiade, Afro salentino, Italy',
        'Afro salentino',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '2 Via Rodrigo, Cristiano umbro, Italy',
        'Cristiano umbro',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '9 Piazza Cannas, Borgo Egeo del friuli, Italy',
        'Borgo Egeo del friuli',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        205,
        '069 Contrada Aleramo, Sesto Vinicio del friuli, Italy',
        'Sesto Vinicio del friuli',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        81,
        '9 Rotonda Dalmazio, Cremenzio terme, Italy',
        'Cremenzio terme',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        103,
        '77 Contrada Eustosio, Signorelli laziale, Italy',
        'Signorelli laziale',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        50,
        '107 Rotonda Loreno, Rosselli salentino, Italy',
        'Rosselli salentino',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        121,
        '882 Piazza De Bona, Bergamini lido, Italy',
        'Bergamini lido',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '2 Piazza Cassio, Quarto Cristiano, Italy',
        'Quarto Cristiano',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '51 Piazza Polissena, San Algiso, Italy',
        'San Algiso',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        37,
        '265 Incrocio Serafino, Sartor laziale, Italy',
        'Sartor laziale',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '9 Contrada Orsola, Luigia veneto, Italy',
        'Luigia veneto',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        291,
        '4 Incrocio Surace, Monaci veneto, Italy',
        'Monaci veneto',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        155,
        '80 Rotonda Costanzo, Anastasia a mare, Italy',
        'Anastasia a mare',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        120,
        '3 Borgo Castelli, Settimo Aquilino a mare, Italy',
        'Settimo Aquilino a mare',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        218,
        '77 Borgo Consolata, Quarto Gennaro, Italy',
        'Quarto Gennaro',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        37,
        '5 Borgo Maffeo, Borgo Fabiano, Italy',
        'Borgo Fabiano',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        237,
        '057 Rotonda Angeletti, Sesto Iride lido, Italy',
        'Sesto Iride lido',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        205,
        '904 Strada Orsola, Luisa veneto, Italy',
        'Luisa veneto',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        108,
        '39 Strada Musso, Lipari lido, Italy',
        'Lipari lido',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        195,
        '9 Contrada Giordano, Borgo Rosario laziale, Italy',
        'Borgo Rosario laziale',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        65,
        '7 Borgo Stefani, Borgo Fedro del friuli, Italy',
        'Borgo Fedro del friuli',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        76,
        '79 Contrada Carola, Aurelio umbro, Italy',
        'Aurelio umbro',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        197,
        '668 Borgo Panzeri, Borgo Bacco a mare, Italy',
        'Borgo Bacco a mare',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        53,
        '535 Incrocio Ortenzi, Monterosso ligure, Italy',
        'Monterosso ligure',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        182,
        '62 Via Angeletti, Quarto Dora, Italy',
        'Quarto Dora',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        68,
        '507 Contrada Lavecchia, Borgo Tito umbro, Italy',
        'Borgo Tito umbro',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        141,
        '3 Borgo Cattaneo, Borgo Apollonia lido, Italy',
        'Borgo Apollonia lido',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        199,
        '6 Via Lupi, San Colmanno laziale, Italy',
        'San Colmanno laziale',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        67,
        '936 Via Papini, Quarto Donata terme, Italy',
        'Quarto Donata terme',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        167,
        '934 Via Bibiano, Semprini nell''emilia, Italy',
        'Semprini nell''emilia',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        143,
        '29 Rotonda Pecoraro, Borgo Natalina lido, Italy',
        'Borgo Natalina lido',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        243,
        '3 Via Colombano, San Flavio salentino, Italy',
        'San Flavio salentino',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        269,
        '19 Borgo Pezzella, Lo Iacono terme, Italy',
        'Lo Iacono terme',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        288,
        '4 Rotonda Acacio, Ponti calabro, Italy',
        'Ponti calabro',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        183,
        '852 Contrada Ruperto, Settimo Stefano, Italy',
        'Settimo Stefano',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        50,
        '9 Borgo Delfino, Costantin ligure, Italy',
        'Costantin ligure',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '75 Incrocio Giannone, Paladini umbro, Italy',
        'Paladini umbro',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        238,
        '866 Piazza Pivetta, San Cristiana, Italy',
        'San Cristiana',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        124,
        '94 Strada Gioconda, Sesto Eloisa ligure, Italy',
        'Sesto Eloisa ligure',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        108,
        '915 Borgo Cristiana, Sesto Franco, Italy',
        'Sesto Franco',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        134,
        '849 Rotonda Allegretti, Guido ligure, Italy',
        'Guido ligure',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        136,
        '718 Rotonda Sostrato, Mauri ligure, Italy',
        'Mauri ligure',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        192,
        '7 Borgo Giuliano, Borgo Amanzio, Italy',
        'Borgo Amanzio',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        66,
        '2 Piazza Carriero, Settimo Celso, Italy',
        'Settimo Celso',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        282,
        '07 Strada Cleofe, Genesia laziale, Italy',
        'Genesia laziale',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        142,
        '79 Rotonda Di Giacomo, Cesario sardo, Italy',
        'Cesario sardo',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        271,
        '974 Rotonda Mazzotti, Pieri umbro, Italy',
        'Pieri umbro',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        228,
        '313 Incrocio Cornelia, Viviana lido, Italy',
        'Viviana lido',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        143,
        '6 Strada Fabiano, Aris lido, Italy',
        'Aris lido',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        148,
        '2 Borgo Palladia, Enrica veneto, Italy',
        'Enrica veneto',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        86,
        '99 Rotonda Fanara, Quarto Patrizia, Italy',
        'Quarto Patrizia',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        81,
        '49 Contrada Ottilia, D''Alessandro umbro, Italy',
        'D''Alessandro umbro',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        281,
        '89 Piazza Arrigo, Sesto Diomede, Italy',
        'Sesto Diomede',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '30 Incrocio Mistretta, Borgo Teodosio, Italy',
        'Borgo Teodosio',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        93,
        '0 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        231,
        '469 Contrada Ferretti, Pipitone ligure, Italy',
        'Pipitone ligure',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        36,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        177,
        '3 Strada Audace, Sesto Sabino del friuli, Italy',
        'Sesto Sabino del friuli',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        125,
        '38 Strada Kofler, Borgo Senofonte lido, Italy',
        'Borgo Senofonte lido',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        121,
        '0 Strada Del Gaudio, Borgo Erico terme, Italy',
        'Borgo Erico terme',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        188,
        '28 Incrocio Di Ciocco, Borgo Alessio, Italy',
        'Borgo Alessio',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        164,
        '9 Strada Sinfronio, San Diodoro nell''emilia, Italy',
        'San Diodoro nell''emilia',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        251,
        '17 Strada Dalila, Massari sardo, Italy',
        'Massari sardo',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        106,
        '948 Piazza Amaranto, Bruto salentino, Italy',
        'Bruto salentino',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        255,
        '8 Rotonda D''Elia, Chiara terme, Italy',
        'Chiara terme',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        256,
        '028 Contrada Fortunata, Quarto Zelinda laziale, Italy',
        'Quarto Zelinda laziale',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        42,
        '4 Contrada Ulpiano, Settimo Tosca laziale, Italy',
        'Settimo Tosca laziale',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        250,
        '02 Strada Bisconti, Fulvia lido, Italy',
        'Fulvia lido',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        275,
        '59 Via Asterio, Settimo Ebe, Italy',
        'Settimo Ebe',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        107,
        '56 Strada Cont, Sesto Fiore, Italy',
        'Sesto Fiore',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        144,
        '006 Rotonda Menconi, Quarto Gerasimo, Italy',
        'Quarto Gerasimo',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        34,
        '982 Piazza Livia, Ursicio ligure, Italy',
        'Ursicio ligure',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        149,
        '166 Via Manetto, Greta veneto, Italy',
        'Greta veneto',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '158 Borgo Lorena, Basileo ligure, Italy',
        'Basileo ligure',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        171,
        '83 Rotonda Bortoluzzi, Franco umbro, Italy',
        'Franco umbro',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        88,
        '041 Rotonda Errera, San Matroniano salentino, Italy',
        'San Matroniano salentino',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        126,
        '37 Via Sebastiano, San Pantaleone, Italy',
        'San Pantaleone',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        230,
        '7 Contrada Romilda, Settimo Abelardo, Italy',
        'Settimo Abelardo',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        295,
        '3 Borgo Mazza, Sesto Cirino, Italy',
        'Sesto Cirino',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        127,
        '44 Piazza Venusto, Platania laziale, Italy',
        'Platania laziale',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        49,
        '4 Borgo Amico, Falbo terme, Italy',
        'Falbo terme',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        197,
        '281 Via Anselmi, Settimo Emma ligure, Italy',
        'Settimo Emma ligure',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        216,
        '24 Borgo Vitiello, Borgo Rino, Italy',
        'Borgo Rino',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '50 Contrada Eulalia, Pintus a mare, Italy',
        'Pintus a mare',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        76,
        '03 Rotonda Caruso, Luchini salentino, Italy',
        'Luchini salentino',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        178,
        '006 Incrocio Acacio, Terzo del friuli, Italy',
        'Terzo del friuli',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        151,
        '932 Piazza Maiello, Romolo calabro, Italy',
        'Romolo calabro',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        191,
        '2 Rotonda Liverani, Quarto Marisa del friuli, Italy',
        'Quarto Marisa del friuli',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        178,
        '144 Piazza Aristofane, Borgo Giliola, Italy',
        'Borgo Giliola',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        293,
        '70 Piazza Eros, Borgo Incoronata nell''emilia, Italy',
        'Borgo Incoronata nell''emilia',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        280,
        '6 Piazza Basso, Fortunato laziale, Italy',
        'Fortunato laziale',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        111,
        '7 Via Rotolo, San Mercede, Italy',
        'San Mercede',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '223 Contrada Aristofane, Borgo Ivone lido, Italy',
        'Borgo Ivone lido',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        232,
        '4 Incrocio Gerasimo, Sesto Tulliano calabro, Italy',
        'Sesto Tulliano calabro',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        169,
        '9 Strada Lana, D''Urso ligure, Italy',
        'D''Urso ligure',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        246,
        '955 Rotonda Barbarigo, Borgo Saverio, Italy',
        'Borgo Saverio',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        249,
        '6 Strada Candido, Maurizio sardo, Italy',
        'Maurizio sardo',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        53,
        '218 Borgo Abibo, Sesto Delfina nell''emilia, Italy',
        'Sesto Delfina nell''emilia',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        300,
        '09 Via Costantini, Borgo Zanita calabro, Italy',
        'Borgo Zanita calabro',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        31,
        '111 Contrada Teodora, Salomone salentino, Italy',
        'Salomone salentino',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        279,
        '293 Strada Druina, Quarto Argo, Italy',
        'Quarto Argo',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        154,
        '6 Via Asella, Sesto Golia umbro, Italy',
        'Sesto Golia umbro',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        150,
        '78 Piazza Ambra, Patanè a mare, Italy',
        'Patanè a mare',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        212,
        '959 Piazza Paolini, Malerba ligure, Italy',
        'Malerba ligure',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        63,
        '217 Borgo Pavan, Lorenzo laziale, Italy',
        'Lorenzo laziale',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        134,
        '48 Borgo Cupido, Bodini calabro, Italy',
        'Bodini calabro',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        116,
        '5 Incrocio Vala, Loiacono laziale, Italy',
        'Loiacono laziale',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        36,
        '62 Incrocio Montesano, Degano ligure, Italy',
        'Degano ligure',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        98,
        '74 Strada Adelina, San Teodoro a mare, Italy',
        'San Teodoro a mare',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        260,
        '5 Contrada Veronica, Borgo Bonaldo umbro, Italy',
        'Borgo Bonaldo umbro',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        277,
        '4 Via Diana, Quarto Amedeo nell''emilia, Italy',
        'Quarto Amedeo nell''emilia',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        70,
        '917 Rotonda Mosti, Teodolinda lido, Italy',
        'Teodolinda lido',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        28,
        '261 Incrocio Ariele, Saffo ligure, Italy',
        'Saffo ligure',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        241,
        '478 Incrocio Girardo, San Illuminato sardo, Italy',
        'San Illuminato sardo',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        36,
        '9 Via Flore, Settimo Dante, Italy',
        'Settimo Dante',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        212,
        '758 Rotonda Petito, Cassandra terme, Italy',
        'Cassandra terme',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        278,
        '24 Borgo Dalida, Borgo Susanna a mare, Italy',
        'Borgo Susanna a mare',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        196,
        '9 Borgo Massimo, Quarto Venerio nell''emilia, Italy',
        'Quarto Venerio nell''emilia',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        39,
        '08 Incrocio Isaia, Lena del friuli, Italy',
        'Lena del friuli',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        77,
        '906 Strada Pia, Santarsia lido, Italy',
        'Santarsia lido',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '762 Contrada Dacio, Settimo Giuda, Italy',
        'Settimo Giuda',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        96,
        '136 Contrada Livia, Galante calabro, Italy',
        'Galante calabro',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        113,
        '295 Borgo Vilfredo, Flaminia umbro, Italy',
        'Flaminia umbro',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        193,
        '3 Borgo Annabella, Di Dio salentino, Italy',
        'Di Dio salentino',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        36,
        '5 Borgo Caronte, Loreto sardo, Italy',
        'Loreto sardo',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        156,
        '955 Contrada Alviero, Cirillo terme, Italy',
        'Cirillo terme',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        121,
        '55 Via Lombardo, Geronimo a mare, Italy',
        'Geronimo a mare',
        'Italy',
        'Bolzano',
        ''
      );
    
  