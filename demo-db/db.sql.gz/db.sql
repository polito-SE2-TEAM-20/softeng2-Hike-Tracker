--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: insert_hut(integer, double precision, double precision, integer, numeric, character varying, character varying, character varying, character varying, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut(user_id integer, lat double precision, lon double precision, number_of_beds integer, price numeric, title character varying, address character varying, owner_name character varying, website character varying, elevation numeric) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation
    );
    END
    $$;


--
-- Name: insert_parking_lot(integer, double precision, double precision, character varying, integer, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_parking_lot(user_id integer, lat double precision, lon double precision, name character varying, max_cars integer, address character varying, city character varying, country character varying, region character varying, province character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country) FROM stdin;
1	2	3.30	476	15.40	1	Airline Trail - Detour		/static/gpx/001_Airline_Trail___Detour.gpx	0.00	Parma		Alivernini ligure	USA
2	2	3.70	1308	18.90	2	Airline Trail		/static/gpx/002_Airline_Trail.gpx	0.00	Firenze		Lelli lido	USA
3	2	9.20	1500	28.60	0	Colchester Railroad		/static/gpx/003_Colchester_Railroad.gpx	0.00	Sassari		Borgo Bassilla salentino	USA
4	2	1.80	345	19.20	2	Willimantic Flower Bridge		/static/gpx/004_Willimantic_Flower_Bridge.gpx	0.00	Pistoia		Quarto Alberta nell'emilia	USA
5	2	1.20	240	9.00	2	Willimantic Pedestrian Bridge		/static/gpx/005_Willimantic_Pedestrian_Bridge.gpx	0.00	Caserta		San Ileana	USA
6	2	5.30	576	29.50	2	Two Sister'S Preserve Loop Trail		/static/gpx/006_Two_Sister_S_Preserve_Loop_Trail.gpx	0.00	Novara		Pace sardo	USA
7	2	3.40	975	24.50	0	Putnam River Trail		/static/gpx/007_Putnam_River_Trail.gpx	0.00	Teramo		Settimo Deodato	USA
8	2	2.10	663	18.40	2	Airline Trail Bypass		/static/gpx/008_Airline_Trail_Bypass.gpx	0.00	Carbonia-Iglesias		Macchia salentino	USA
9	2	5.50	17010	8.40	2	Indian Neck		/static/gpx/009_Indian_Neck.gpx	0.00	Viterbo		Sesto Melissa calabro	USA
10	2	3.60	13464	15.00	0	Stony Creek		/static/gpx/010_Stony_Creek.gpx	0.00	Campobasso		Tabita calabro	USA
11	2	7.60	10680	20.70	2	Quarry-Westwoods		/static/gpx/011_Quarry_Westwoods.gpx	0.00	Vicenza		Sesto Ulstano salentino	USA
12	2	8.70	21855	18.40	2	Short Beach		/static/gpx/012_Short_Beach.gpx	0.00	Fermo		Quarto Anatolia sardo	USA
13	2	1.60	210	5.10	1	Charter Oak Greenway		/static/gpx/013_Charter_Oak_Greenway.gpx	0.00	Olbia-Tempio		Santarossa ligure	USA
14	2	2.40	1050	12.20	0	Bissell Greenway		/static/gpx/014_Bissell_Greenway.gpx	0.00	Teramo		Sesto Eufrasia laziale	USA
15	2	2.10	364	13.20	2	Riverfront Trail System		/static/gpx/015_Riverfront_Trail_System.gpx	0.00	Catanzaro		Occhipinti del friuli	USA
16	2	4.20	675	13.20	2	Millers Pond Park Trail		/static/gpx/016_Millers_Pond_Park_Trail.gpx	0.00	Lecce		Sesto Speranza	USA
17	2	1.50	440	12.40	2	Mattabesett Trail		/static/gpx/017_Mattabesett_Trail.gpx	0.00	Pordenone		Tiberio salentino	USA
18	2	0.70	195	27.70	2	Jefferson Park Trail		/static/gpx/018_Jefferson_Park_Trail.gpx	0.00	Forlì-Cesena		Cola umbro	USA
19	2	0.80	98	19.30	2	Cockaponset Trail		/static/gpx/019_Cockaponset_Trail.gpx	0.00	Ogliastra		Quarto Goffredo	USA
20	2	3.90	374	7.30	1	Mt. Nebo Park		/static/gpx/020_Mt__Nebo_Park.gpx	0.00	Imperia		Quarto Melezio laziale	USA
21	2	1.60	156	12.90	2	 		/static/gpx/021__.gpx	0.00	Verbano-Cusio-Ossola		De Lorenzo terme	USA
22	2	0.70	154	16.40	2	Proposed Trail		/static/gpx/022_Proposed_Trail.gpx	0.00	Ravenna		Grosso sardo	USA
23	2	1.80	240	15.60	2	Blinnshed Ridge Trail		/static/gpx/023_Blinnshed_Ridge_Trail.gpx	0.00	Caltanissetta		Quarto Evasio	USA
24	2	4.80	910	18.10	2	Neck River Trail		/static/gpx/024_Neck_River_Trail.gpx	0.00	Asti		Bertolussi terme	USA
25	2	1.40	143	22.50	2	Unnamed Trail		/static/gpx/025_Unnamed_Trail.gpx	0.00	Trento		Iginia del friuli	USA
26	2	0.70	165	9.20	2	Oil Mill Brook Trail		/static/gpx/026_Oil_Mill_Brook_Trail.gpx	0.00	Latina		Borgo Diamante laziale	USA
27	2	1.30	170	8.90	2	Chatfield Trail		/static/gpx/027_Chatfield_Trail.gpx	0.00	Livorno		Rufino laziale	USA
28	2	1.30	637	10.20	2	Unamed Trail		/static/gpx/028_Unamed_Trail.gpx	0.00	La Spezia		Borgo Letterio salentino	USA
29	2	3.60	540	10.10	2	Lost Pond Trail		/static/gpx/029_Lost_Pond_Trail.gpx	0.00	Pordenone		Borgo Niceforo sardo	USA
30	2	1.40	110	11.30	2	Ccc Camp Hadley Trail		/static/gpx/030_Ccc_Camp_Hadley_Trail.gpx	0.00	Firenze		Sesto Oddone	USA
31	2	0.70	60	9.90	2	Double Loop Trail		/static/gpx/031_Double_Loop_Trail.gpx	0.00	Bergamo		Curci umbro	USA
32	2	1.00	28	20.50	2	Over Brook Trail		/static/gpx/032_Over_Brook_Trail.gpx	0.00	Siracusa		Centofanti umbro	USA
33	2	0.90	45	20.60	2	Cockaponset Forest Trail		/static/gpx/033_Cockaponset_Forest_Trail.gpx	0.00	Milano		San Giorgio laziale	USA
34	2	1.00	55	16.20	2	Pattaconk Trail		/static/gpx/034_Pattaconk_Trail.gpx	0.00	Brescia		Settimo Socrate	USA
35	2	2.60	429	26.70	2	Westwoods Forest Trail		/static/gpx/035_Westwoods_Forest_Trail.gpx	0.00	Roma		Sonia veneto	USA
36	2	4.10	868	20.00	2	Blinnshed Loop Trail		/static/gpx/036_Blinnshed_Loop_Trail.gpx	0.00	Potenza		Bedini terme	USA
37	2	3.40	675	9.70	2	Unnamed Tsail		/static/gpx/037_Unnamed_Tsail.gpx	0.00	Foggia		Daniele veneto	USA
38	2	2.10	264	12.60	0	Messerschmidt Wma Trail		/static/gpx/038_Messerschmidt_Wma_Trail.gpx	0.00	Caserta		San Valfredo ligure	USA
39	2	3.90	455	17.90	2	Westwoods Nature Trail		/static/gpx/039_Westwoods_Nature_Trail.gpx	0.00	Napoli		Gulino lido	USA
40	2	1.60	144	11.20	2	Enduro		/static/gpx/040_Enduro.gpx	0.00	Asti		Borgo Ermete	USA
41	2	2.00	225	28.20	2	Land Trust Trail		/static/gpx/041_Land_Trust_Trail.gpx	0.00	Modena		Borgo Ludovica	USA
42	2	0.90	28	29.90	2	Beaver Brook Park Trail		/static/gpx/042_Beaver_Brook_Park_Trail.gpx	0.00	Caserta		Olivieri veneto	USA
43	2	1.40	140	20.30	0	Housatonic Forest Trail		/static/gpx/043_Housatonic_Forest_Trail.gpx	0.00	Roma		Antonia calabro	USA
44	2	9.90	1430	17.80	0	Farmington Canal Trail		/static/gpx/044_Farmington_Canal_Trail.gpx	0.00	Caserta		Erminia nell'emilia	USA
45	2	1.00	90	14.40	1	Beckley Furnace Park Path		/static/gpx/045_Beckley_Furnace_Park_Path.gpx	0.00	Napoli		Emilia laziale	USA
46	2	1.10	372	18.90	2	Farmington River Trail		/static/gpx/046_Farmington_River_Trail.gpx	0.00	Pescara		Pandolfi salentino	USA
47	2	5.60	610	18.90	2	Farminton Canal Trail		/static/gpx/047_Farminton_Canal_Trail.gpx	0.00	Bologna		Borgo Armando	USA
48	2	0.60	36	12.00	2	Farminton River Trail		/static/gpx/048_Farminton_River_Trail.gpx	0.00	Grosseto		Arcangeli umbro	USA
49	2	10.00	6150	10.70	1	Hop River Trail		/static/gpx/049_Hop_River_Trail.gpx	0.00	Lodi		Quarto Candida	USA
50	2	0.80	170	20.40	1	Hoprivertrail - Detouraround316		/static/gpx/050_Hoprivertrail___Detouraround316.gpx	0.00	Cagliari		Settimo Rosalinda salentino	USA
51	2	1.00	70	19.30	0	Hop River Trail - Long Hill Rd.		/static/gpx/051_Hop_River_Trail___Long_Hill_Rd_.gpx	0.00	Crotone		Di Rocco salentino	USA
52	2	1.40	180	22.90	0	Hop River Trail - Rockville Spur		/static/gpx/052_Hop_River_Trail___Rockville_Spur.gpx	0.00	Pesaro e Urbino		Sesto Elogio lido	USA
53	2	3.50	468	24.20	2	Housatonic Rail Trail		/static/gpx/053_Housatonic_Rail_Trail.gpx	0.00	Vercelli		Cerrato ligure	USA
54	2	3.10	1680	24.10	1	Middletown Bikeway		/static/gpx/054_Middletown_Bikeway.gpx	0.00	Benevento		Settimo Acario	USA
55	2	2.20	840	26.90	2	Mattabesett Trolley Trail		/static/gpx/055_Mattabesett_Trolley_Trail.gpx	0.00	Forlì-Cesena		Guastella del friuli	USA
56	2	0.90	273	24.10	1	Moosup Valley State Park Trail		/static/gpx/056_Moosup_Valley_State_Park_Trail.gpx	0.00	Siracusa		Verulo veneto	USA
57	2	1.00	66	5.90	0	Quinnebaug River Trail		/static/gpx/057_Quinnebaug_River_Trail.gpx	0.00	Enna		Fulvia del friuli	USA
58	2	1.00	105	18.50	2	Tracey Road Trail		/static/gpx/058_Tracey_Road_Trail.gpx	0.00	Gorizia		Quarto Abdone	USA
59	2	1.60	280	13.20	1	Trolley Trail		/static/gpx/059_Trolley_Trail.gpx	0.00	Campobasso		Stabile lido	USA
60	2	1.30	154	18.40	2	Quinnebaug Hatchery Trail		/static/gpx/060_Quinnebaug_Hatchery_Trail.gpx	0.00	Taranto		Ascanio calabro	USA
61	2	1.40	240	24.90	2	Hopeville Park Trail		/static/gpx/061_Hopeville_Park_Trail.gpx	0.00	Treviso		Settimo Napoleone nell'emilia	USA
62	2	0.80	50	16.30	2	Hopeville Park Path		/static/gpx/062_Hopeville_Park_Path.gpx	0.00	Venezia		Venturelli a mare	USA
63	2	1.00	42	20.70	2	Nehantic Trail		/static/gpx/063_Nehantic_Trail.gpx	0.00	Belluno		Di Somma calabro	USA
64	2	1.30	126	14.20	1	Camp Columbia Trail		/static/gpx/064_Camp_Columbia_Trail.gpx	0.00	Brescia		Paganelli veneto	USA
65	2	0.60	77	6.90	0	Shelton Land Trust Trail		/static/gpx/065_Shelton_Land_Trust_Trail.gpx	0.00	Prato		Settimo Elsa	USA
66	2	0.80	55	24.20	0	Dinosaur Park Sidewalk		/static/gpx/066_Dinosaur_Park_Sidewalk.gpx	0.00	Crotone		Asterio calabro	USA
67	2	1.00	24	7.30	0	Dinosaur Park Trail		/static/gpx/067_Dinosaur_Park_Trail.gpx	0.00	Barletta-Andria-Trani		Borgo Lea umbro	USA
68	2	0.90	75	7.60	1	Access Road		/static/gpx/068_Access_Road.gpx	0.00	Venezia		Anatolia salentino	USA
69	2	1.40	231	21.00	1	Day Pond Park Path		/static/gpx/069_Day_Pond_Park_Path.gpx	0.00	Benevento		Settimo Miranda	USA
70	2	1.30	624	28.80	0	Day Pond Park Trail		/static/gpx/070_Day_Pond_Park_Trail.gpx	0.00	Caltanissetta		Sesto Colomba veneto	USA
71	2	7.30	2338	17.30	0	Salmon River Trail		/static/gpx/071_Salmon_River_Trail.gpx	0.00	Avellino		Desiderato veneto	USA
72	2	2.80	1370	19.80	0	Salmon River Trial		/static/gpx/072_Salmon_River_Trial.gpx	0.00	Caltanissetta		Borgo Esterina sardo	USA
73	2	2.20	264	10.80	0	Dennis Hill Park Trail		/static/gpx/073_Dennis_Hill_Park_Trail.gpx	0.00	Catania		Settimo Audace	USA
74	2	1.30	104	13.40	1	Railroad Trail		/static/gpx/074_Railroad_Trail.gpx	0.00	Imperia		Borgo Basileo	USA
75	2	0.80	65	24.80	0	Gillette Castle Trail		/static/gpx/075_Gillette_Castle_Trail.gpx	0.00	Forlì-Cesena		Vissia del friuli	USA
76	2	1.00	30	5.20	1	Kent Falls Park Path		/static/gpx/076_Kent_Falls_Park_Path.gpx	0.00	Forlì-Cesena		Cornelio sardo	USA
77	2	0.90	99	18.20	2	Kent Falls Park Trail		/static/gpx/077_Kent_Falls_Park_Trail.gpx	0.00	Latina		Pennestrì a mare	USA
78	2	0.90	36	21.80	2	Lovers Leap Park Trail		/static/gpx/078_Lovers_Leap_Park_Trail.gpx	0.00	Caserta		Siriano terme	USA
79	2	1.20	77	24.90	2	Enders Forest Trail		/static/gpx/079_Enders_Forest_Trail.gpx	0.00	Firenze		Eligibile a mare	USA
80	2	1.30	154	11.40	1	Gay City Park Path		/static/gpx/080_Gay_City_Park_Path.gpx	0.00	Bergamo		Errera a mare	USA
81	2	1.90	345	18.20	1	Gay City Park Trail		/static/gpx/081_Gay_City_Park_Trail.gpx	0.00	Bergamo		Sesto Vittoriano	USA
82	2	9.90	1320	15.60	1	Split Rock Trail		/static/gpx/082_Split_Rock_Trail.gpx	0.00	Sassari		Gloria lido	USA
83	2	0.60	26	17.70	2	Gillette Castle Path		/static/gpx/083_Gillette_Castle_Path.gpx	0.00	Sassari		Alboino a mare	USA
84	2	1.00	285	18.60	1	Great Pond Forest Trail		/static/gpx/084_Great_Pond_Forest_Trail.gpx	0.00	Parma		San Gineto	USA
85	2	1.20	450	20.20	2	Haddam Meadows Park Trail		/static/gpx/085_Haddam_Meadows_Park_Trail.gpx	0.00	Lecce		Quarto Casto	USA
86	2	0.60	36	18.10	0	Haley Farm Park Trail		/static/gpx/086_Haley_Farm_Park_Trail.gpx	0.00	Latina		San Claudio sardo	USA
87	2	0.80	60	13.60	2	Hammonasset Park Path		/static/gpx/087_Hammonasset_Park_Path.gpx	0.00	Pisa		Borgo Maffeo	USA
88	2	0.90	260	28.80	2	Nature Trail		/static/gpx/088_Nature_Trail.gpx	0.00	Cagliari		San Eutalio	USA
89	2	0.80	36	11.30	2	Hammonasset Bike Path		/static/gpx/089_Hammonasset_Bike_Path.gpx	0.00	Isernia		Giunta sardo	USA
90	2	0.70	28	19.60	0	Hammonasset Park Boardwalk		/static/gpx/090_Hammonasset_Park_Boardwalk.gpx	0.00	Belluno		Quarto Rolando laziale	USA
91	2	0.80	104	20.00	0	Meigs Point Jetty		/static/gpx/091_Meigs_Point_Jetty.gpx	0.00	Medio Campidano		Venerando veneto	USA
92	2	2.00	375	27.00	2	Willard Island Nature Trail		/static/gpx/092_Willard_Island_Nature_Trail.gpx	0.00	Savona		Lo Presti veneto	USA
93	2	1.60	390	16.50	1	Moraine Nature Trail		/static/gpx/093_Moraine_Nature_Trail.gpx	0.00	Nuoro		Simeoli salentino	USA
94	2	2.20	228	29.50	2	Haystack Park Trail		/static/gpx/094_Haystack_Park_Trail.gpx	0.00	Belluno		Tammaro umbro	USA
95	2	1.30	150	28.80	2	Higganum Reservoir Park Trail		/static/gpx/095_Higganum_Reservoir_Park_Trail.gpx	0.00	Carbonia-Iglesias		Tumbarello a mare	USA
96	2	2.70	455	18.90	2	Appalachian Trail		/static/gpx/096_Appalachian_Trail.gpx	0.00	Novara		Liguori del friuli	USA
97	2	1.80	351	28.50	0	Mohawk Trail		/static/gpx/097_Mohawk_Trail.gpx	0.00	Livorno		San Aniello sardo	USA
98	2	1.00	108	8.50	2	Pine Knob Loop		/static/gpx/098_Pine_Knob_Loop.gpx	0.00	Udine		Tarso veneto	USA
99	2	8.20	2568	22.60	2	Appalachian/Pine Knob Loop		/static/gpx/099_Appalachian_Pine_Knob_Loop.gpx	0.00	Bergamo		Settimo Mimma	USA
100	2	1.00	320	15.90	0	White Mountain Trail		/static/gpx/100_White_Mountain_Trail.gpx	0.00	Cuneo		Severi ligure	USA
101	2	0.90	104	16.90	1	River Trail		/static/gpx/101_River_Trail.gpx	0.00	Pescara		Falzone sardo	USA
102	2	1.10	140	24.90	0	Hurd Park Trail		/static/gpx/102_Hurd_Park_Trail.gpx	0.00	Pordenone		Sesto Ettore laziale	USA
103	2	1.40	117	20.40	0	Hurd Park Path		/static/gpx/103_Hurd_Park_Path.gpx	0.00	Barletta-Andria-Trani		Sesto Maccabeo	USA
104	2	3.50	385	5.10	0	Paugussett Trail		/static/gpx/104_Paugussett_Trail.gpx	0.00	Catanzaro		Quarto Diodata lido	USA
105	2	0.60	84	7.40	0	Waterfall Trail		/static/gpx/105_Waterfall_Trail.gpx	0.00	Bolzano		Debora umbro	USA
106	2	2.50	345	19.10	0	Paugussett Trail Connector		/static/gpx/106_Paugussett_Trail_Connector.gpx	0.00	Palermo		Settimo Proserpina umbro	USA
107	2	1.40	108	6.20	1	Minetto Park Trail		/static/gpx/107_Minetto_Park_Trail.gpx	0.00	Imperia		De Angelis lido	USA
108	2	0.80	24	11.50	2	Coincident Macedonia Brook Rd		/static/gpx/108_Coincident_Macedonia_Brook_Rd.gpx	0.00	Cremona		D'Ippolito terme	USA
109	2	1.80	297	6.80	1	Coincident Weber Road		/static/gpx/109_Coincident_Weber_Road.gpx	0.00	Rieti		Cecchi veneto	USA
110	2	8.90	5558	28.40	2	Macedonia Ridge Trail		/static/gpx/110_Macedonia_Ridge_Trail.gpx	0.00	Cagliari		Sesto Veridiana sardo	USA
111	2	4.70	1464	7.70	2	Cobble Mountain Trail		/static/gpx/111_Cobble_Mountain_Trail.gpx	0.00	Rimini		Sesto Elimena	USA
112	2	3.50	910	16.80	2	Shenipsit Trail		/static/gpx/112_Shenipsit_Trail.gpx	0.00	Belluno		Florina sardo	USA
113	2	1.30	130	19.70	2	Meshomasic Forest Trail		/static/gpx/113_Meshomasic_Forest_Trail.gpx	0.00	Firenze		Candida veneto	USA
114	2	2.10	1260	15.10	0	Crest Trail		/static/gpx/114_Crest_Trail.gpx	0.00	Monza e della Brianza		Paolucci salentino	USA
115	2	2.90	312	24.40	0	Campground Trail		/static/gpx/115_Campground_Trail.gpx	0.00	Udine		Quarto Fidenziano del friuli	USA
116	2	4.30	816	29.70	2	Brook Trail		/static/gpx/116_Brook_Trail.gpx	0.00	Cuneo		Nico calabro	USA
117	2	0.70	50	29.40	1	Kettletown Park Trail		/static/gpx/117_Kettletown_Park_Trail.gpx	0.00	Palermo		Quarto Paolo	USA
118	2	0.80	180	20.10	0	North Ridge Trail		/static/gpx/118_North_Ridge_Trail.gpx	0.00	Ferrara		Cacciapuoti calabro	USA
119	2	8.40	1551	9.00	1	North Ridge Loop Trail		/static/gpx/119_North_Ridge_Loop_Trail.gpx	0.00	Lucca		Biasci umbro	USA
120	2	1.10	96	25.20	1	Miller Brook Connector Trail		/static/gpx/120_Miller_Brook_Connector_Trail.gpx	0.00	Enna		Landolfo umbro	USA
121	2	8.80	1960	11.10	0	Miller Trail		/static/gpx/121_Miller_Trail.gpx	0.00	Brindisi		Sesto Lisandro nell'emilia	USA
122	2	2.10	270	12.40	1	Miller Trail Spur		/static/gpx/122_Miller_Trail_Spur.gpx	0.00	Siracusa		Borgo Giacinta	USA
123	2	3.20	420	23.80	2	Pomperaug Trail		/static/gpx/123_Pomperaug_Trail.gpx	0.00	Piacenza		Capoccia del friuli	USA
124	2	0.60	30	11.80	2	Brook Trail Access		/static/gpx/124_Brook_Trail_Access.gpx	0.00	Brindisi		Marinetta umbro	USA
125	2	3.50	540	26.90	1	Waramaug Lake Park Trail		/static/gpx/125_Waramaug_Lake_Park_Trail.gpx	0.00	Enna		Borgo Marino	USA
126	2	0.70	110	7.70	1	Well Groomed Trail		/static/gpx/126_Well_Groomed_Trail.gpx	0.00	Cagliari		Aurora del friuli	USA
127	2	1.80	630	14.80	1	Mashamoquet Brook Park Trail		/static/gpx/127_Mashamoquet_Brook_Park_Trail.gpx	0.00	Cagliari		Quarto Giuseppe	USA
128	2	1.00	104	24.70	0	Shenipsit Trail Spur		/static/gpx/128_Shenipsit_Trail_Spur.gpx	0.00	Catanzaro		Settimo Ildegarda	USA
129	2	2.60	396	13.00	0	Shenipsit		/static/gpx/129_Shenipsit.gpx	0.00	Vibo Valentia		San Zenebio	USA
130	2	1.00	30	11.90	1	Nassahegon Forest Trail		/static/gpx/130_Nassahegon_Forest_Trail.gpx	0.00	Massa-Carrara		Guerriero veneto	USA
131	2	1.00	26	27.10	2	Tunxis Trail		/static/gpx/131_Tunxis_Trail.gpx	0.00	Arezzo		Spanò umbro	USA
132	2	2.10	594	28.50	1	Black Spruce Bog Trail		/static/gpx/132_Black_Spruce_Bog_Trail.gpx	0.00	Pavia		Iannucci ligure	USA
133	2	4.90	720	16.30	2	Mohawk Forest Trail		/static/gpx/133_Mohawk_Forest_Trail.gpx	0.00	Rieti		San Aldo	USA
134	2	1.50	165	19.40	2	Ethan Allen Youth Trail		/static/gpx/134_Ethan_Allen_Youth_Trail.gpx	0.00	Treviso		Settimo Mancio lido	USA
135	2	1.20	120	27.00	2	Punch Brook Trail		/static/gpx/135_Punch_Brook_Trail.gpx	0.00	Taranto		San Simeone del friuli	USA
136	2	2.00	728	13.80	2	Red Cedar Lake Trail		/static/gpx/136_Red_Cedar_Lake_Trail.gpx	0.00	Rieti		Gioconda sardo	USA
137	2	0.80	50	13.60	2	Under Mountain Trail		/static/gpx/137_Under_Mountain_Trail.gpx	0.00	Napoli		San Romolo	USA
138	2	4.30	840	28.50	2	Mount Tom Trail		/static/gpx/138_Mount_Tom_Trail.gpx	0.00	Padova		Surano laziale	USA
139	2	5.50	616	18.70	0	Naugatuck Trail		/static/gpx/139_Naugatuck_Trail.gpx	0.00	Novara		Sesto Sansone	USA
140	2	2.90	403	17.40	2	Nehantic Forest Trail		/static/gpx/140_Nehantic_Forest_Trail.gpx	0.00	Modena		San Gosto a mare	USA
141	2	1.80	754	20.20	1	Naugatuck Forest Trail		/static/gpx/141_Naugatuck_Forest_Trail.gpx	0.00	Lodi		Norma ligure	USA
142	2	1.60	240	9.60	2	Naugatuck Spur		/static/gpx/142_Naugatuck_Spur.gpx	0.00	Macerata		Vascotto laziale	USA
143	2	3.90	910	6.10	2	Whitemore Trail		/static/gpx/143_Whitemore_Trail.gpx	0.00	Treviso		Protasio salentino	USA
144	2	4.80	1232	22.80	2	Quinnipiac Trail		/static/gpx/144_Quinnipiac_Trail.gpx	0.00	Ferrara		Colmanno nell'emilia	USA
145	2	1.60	132	10.30	0	Nehantic Forest Trai		/static/gpx/145_Nehantic_Forest_Trai.gpx	0.00	Caltanissetta		Onorio sardo	USA
146	2	1.00	52	25.70	2	Nepaug Forest Trail		/static/gpx/146_Nepaug_Forest_Trail.gpx	0.00	Pavia		Settimo Timoteo ligure	USA
147	2	3.60	370	27.40	1	Naugatuck		/static/gpx/147_Naugatuck.gpx	0.00	Macerata		Adalgiso umbro	USA
148	2	8.70	979	5.50	2	Nyantaquit Trail		/static/gpx/148_Nyantaquit_Trail.gpx	0.00	Ancona		Sesto Cristoforo	USA
149	2	2.20	198	20.10	1	Tipping Rock Loop Trail		/static/gpx/149_Tipping_Rock_Loop_Trail.gpx	0.00	Brindisi		Settimo Ildebrando laziale	USA
150	2	1.20	225	13.00	1	Valley Outlook Trail		/static/gpx/150_Valley_Outlook_Trail.gpx	0.00	Trento		Baldo a mare	USA
151	2	1.10	273	24.70	1	Shelter 4 Loop Trail		/static/gpx/151_Shelter_4_Loop_Trail.gpx	0.00	Rieti		Donato umbro	USA
152	2	0.70	135	9.50	0	Osbornedale Park Trail		/static/gpx/152_Osbornedale_Park_Trail.gpx	0.00	Brindisi		San Fazio	USA
153	2	0.80	135	25.60	0	Unnamed		/static/gpx/153_Unnamed.gpx	0.00	Sondrio		Borgo Deodato calabro	USA
154	2	0.60	48	18.10	0	Paugnut Forest Trail		/static/gpx/154_Paugnut_Forest_Trail.gpx	0.00	Mantova		Ragusa a mare	USA
155	2	1.80	360	23.60	1	Charles L Pack Trail		/static/gpx/155_Charles_L_Pack_Trail.gpx	0.00	Rieti		Borgo Piersilvio calabro	USA
156	2	2.50	260	28.90	1	Peoples Forest Trail		/static/gpx/156_Peoples_Forest_Trail.gpx	0.00	Crotone		Settimo Vittore	USA
314	2	0.80	28	23.90	2	Pachaug		/static/gpx/314_Pachaug.gpx	0.00	Vibo Valentia		Pecora laziale	USA
157	2	0.70	182	27.40	2	Putnam Memorial Trail		/static/gpx/157_Putnam_Memorial_Trail.gpx	0.00	Potenza		San Noemi veneto	USA
158	2	1.70	300	7.40	0	Platt Hill Park Trail		/static/gpx/158_Platt_Hill_Park_Trail.gpx	0.00	Enna		Amone veneto	USA
159	2	0.70	50	13.90	1	Metacomet Trail		/static/gpx/159_Metacomet_Trail.gpx	0.00	Trento		Sesto Iginio	USA
160	2	0.90	84	20.40	1	Metacomet Trail Bypass		/static/gpx/160_Metacomet_Trail_Bypass.gpx	0.00	Lodi		Quarto Italo	USA
161	2	8.40	2106	5.50	0	Penwood Park Trail		/static/gpx/161_Penwood_Park_Trail.gpx	0.00	Terni		Pedrazzini calabro	USA
162	2	0.70	90	10.20	0	Quadick Park Path		/static/gpx/162_Quadick_Park_Path.gpx	0.00	Imperia		Borgo Elaide ligure	USA
163	2	3.70	686	13.70	0	Quadick Red Trail		/static/gpx/163_Quadick_Red_Trail.gpx	0.00	Cuneo		Ivo veneto	USA
164	2	3.10	793	13.80	2	Pootatuck Forest Trail		/static/gpx/164_Pootatuck_Forest_Trail.gpx	0.00	Imperia		Sesto Fernanda	USA
165	2	0.70	156	23.70	0	River Highland Park Trail		/static/gpx/165_River_Highland_Park_Trail.gpx	0.00	Ogliastra		Settimo Bonaldo umbro	USA
166	2	0.60	52	10.10	2	Tunxis		/static/gpx/166_Tunxis.gpx	0.00	Udine		Lorusso ligure	USA
167	2	0.80	182	14.30	1	Old Furnace Trail		/static/gpx/167_Old_Furnace_Trail.gpx	0.00	Trapani		San Nives	USA
168	2	1.50	132	27.70	1	Old Furnace Park Trail		/static/gpx/168_Old_Furnace_Park_Trail.gpx	0.00	Catanzaro		Sesto Amelia	USA
169	2	3.70	444	14.40	1	Kestral Trail		/static/gpx/169_Kestral_Trail.gpx	0.00	Brindisi		Quarto Eufebio terme	USA
170	2	2.50	870	6.60	1	Warbler Trail		/static/gpx/170_Warbler_Trail.gpx	0.00	Rieti		Quarto Efrem salentino	USA
171	2	8.60	1116	18.70	2	Muir Trail		/static/gpx/171_Muir_Trail.gpx	0.00	Chieti		Adelina terme	USA
172	2	1.40	364	23.90	1	Shadow Pond Nature Trail		/static/gpx/172_Shadow_Pond_Nature_Trail.gpx	0.00	Bolzano		Sesto Nadia calabro	USA
173	2	1.20	555	24.00	1	Jesse Gerard Trail		/static/gpx/173_Jesse_Gerard_Trail.gpx	0.00	Campobasso		Carlino lido	USA
174	2	5.10	1131	28.50	0	Robert Ross Trail		/static/gpx/174_Robert_Ross_Trail.gpx	0.00	Trieste		San Fatima lido	USA
175	2	0.90	33	8.50	1	Agnes Bowen Trail		/static/gpx/175_Agnes_Bowen_Trail.gpx	0.00	Reggio Calabria		San Olimpio	USA
176	2	1.90	255	21.50	1	Elliot Bronson Trail		/static/gpx/176_Elliot_Bronson_Trail.gpx	0.00	Pescara		San Pierluigi salentino	USA
177	2	5.10	741	24.10	2	Walt Landgraf Trail		/static/gpx/177_Walt_Landgraf_Trail.gpx	0.00	Fermo		Borgo Lorella	USA
178	2	0.60	30	12.30	1	Squantz Pond Park Trail		/static/gpx/178_Squantz_Pond_Park_Trail.gpx	0.00	Rovigo		Franzè del friuli	USA
179	2	0.50	33	21.50	1	Putnam Memorial Museum Trail		/static/gpx/179_Putnam_Memorial_Museum_Trail.gpx	0.00	Lodi		Borgo Vezio terme	USA
180	2	0.70	45	19.00	0	Quinnipiac Park Trail		/static/gpx/180_Quinnipiac_Park_Trail.gpx	0.00	Ravenna		San Fabiola	USA
181	2	0.70	77	14.20	2	Boardwalk		/static/gpx/181_Boardwalk.gpx	0.00	Vibo Valentia		Settimo Respicio	USA
182	2	1.00	28	10.30	2	Rocky Neck Park Sidewalk		/static/gpx/182_Rocky_Neck_Park_Sidewalk.gpx	0.00	Trento		Quarto Raniero	USA
183	2	0.80	120	6.20	1	Rocky Neck Park Path		/static/gpx/183_Rocky_Neck_Park_Path.gpx	0.00	Chieti		San Vincenza terme	USA
184	2	7.50	1020	7.30	0	Rocky Neck Park Trail		/static/gpx/184_Rocky_Neck_Park_Trail.gpx	0.00	Biella		Quarto Sante umbro	USA
185	2	3.40	690	24.90	1	Rope Swing		/static/gpx/185_Rope_Swing.gpx	0.00	L'Aquila		Settimo Prassede	USA
186	2	1.00	65	13.40	0	Sherwood Island Park Path		/static/gpx/186_Sherwood_Island_Park_Path.gpx	0.00	Reggio Calabria		Settimo Cleo veneto	USA
187	2	2.60	270	19.60	1	Sleeping Giant Park Trail		/static/gpx/187_Sleeping_Giant_Park_Trail.gpx	0.00	Milano		Sesto Leonilda lido	USA
188	2	0.60	80	18.90	0	Sherwood Island Nature Trail		/static/gpx/188_Sherwood_Island_Nature_Trail.gpx	0.00	Bolzano		Borgo Secondiano	USA
189	2	0.60	30	6.90	2	Sleeping Giant Park Path		/static/gpx/189_Sleeping_Giant_Park_Path.gpx	0.00	Ragusa		Borgo Bambina terme	USA
190	2	1.30	180	28.50	0	Tower Trail		/static/gpx/190_Tower_Trail.gpx	0.00	Roma		San Auberto	USA
191	2	1.00	210	11.10	1	Quinnipiac Trail Spur		/static/gpx/191_Quinnipiac_Trail_Spur.gpx	0.00	Sondrio		Spadoni del friuli	USA
192	2	1.70	132	6.60	0	Southford Falls Park Trail		/static/gpx/192_Southford_Falls_Park_Trail.gpx	0.00	Teramo		Borgo Sabina	USA
193	2	0.80	80	26.80	1	Tunxis Forest Trail		/static/gpx/193_Tunxis_Forest_Trail.gpx	0.00	Barletta-Andria-Trani		Alano a mare	USA
194	2	1.40	473	14.90	2	Sleeping Giant Trail		/static/gpx/194_Sleeping_Giant_Trail.gpx	0.00	Ogliastra		Totaro umbro	USA
195	2	1.30	144	14.40	2	Stratton Brook Park Path		/static/gpx/195_Stratton_Brook_Park_Path.gpx	0.00	Imperia		Borgo Guglielmo	USA
196	2	2.10	187	22.80	2	Bike Trail		/static/gpx/196_Bike_Trail.gpx	0.00	Bolzano		Alida laziale	USA
197	2	0.70	182	6.10	2	Stratton Brook Park Trail		/static/gpx/197_Stratton_Brook_Park_Trail.gpx	0.00	Cuneo		Settimo Parmenio	USA
198	2	1.50	170	22.60	0	Simsbury Park Trail		/static/gpx/198_Simsbury_Park_Trail.gpx	0.00	Salerno		Paolicelli sardo	USA
199	2	1.00	180	21.20	1	Wolcott Trail		/static/gpx/199_Wolcott_Trail.gpx	0.00	Udine		Lezzi del friuli	USA
200	2	6.00	1170	13.20	0	Madden Fyler Pond Trail		/static/gpx/200_Madden_Fyler_Pond_Trail.gpx	0.00	Palermo		San Venerando	USA
201	2	5.80	900	8.60	0	Sunny Brook Park Trail		/static/gpx/201_Sunny_Brook_Park_Trail.gpx	0.00	Pescara		Cristiana lido	USA
202	2	1.70	165	17.60	0	Fadoir Spring Trail		/static/gpx/202_Fadoir_Spring_Trail.gpx	0.00	Siracusa		Sesto Lazzaro	USA
203	2	0.80	70	20.40	1	Fadoir Trail		/static/gpx/203_Fadoir_Trail.gpx	0.00	Verbano-Cusio-Ossola		Sesto Raimondo lido	USA
204	2	4.10	611	14.30	1	Walnut Mountain Trail		/static/gpx/204_Walnut_Mountain_Trail.gpx	0.00	Forlì-Cesena		Settimo Bonaldo veneto	USA
205	2	0.80	22	16.90	2	Wolcott		/static/gpx/205_Wolcott.gpx	0.00	Alessandria		Addari lido	USA
206	2	2.90	1665	28.80	1	Old Metacomet Trail		/static/gpx/206_Old_Metacomet_Trail.gpx	0.00	Aosta		Pipitone sardo	USA
207	2	3.10	880	8.50	2	Talcott Mountain Park Trail		/static/gpx/207_Talcott_Mountain_Park_Trail.gpx	0.00	Aosta		Sesto Maffeo	USA
208	2	3.40	2060	28.10	1	Falls Brook Trail		/static/gpx/208_Falls_Brook_Trail.gpx	0.00	Pisa		Franco del friuli	USA
209	2	0.90	105	15.90	2	Whittemore Glen Trail		/static/gpx/209_Whittemore_Glen_Trail.gpx	0.00	Novara		Bortot del friuli	USA
210	2	0.90	88	19.00	0	Wharton Brook Park Trail		/static/gpx/210_Wharton_Brook_Park_Trail.gpx	0.00	Novara		Stefania sardo	USA
211	2	3.20	6810	12.70	2	Larkin Bridle Trail		/static/gpx/211_Larkin_Bridle_Trail.gpx	0.00	Crotone		San Ester del friuli	USA
212	2	0.80	252	22.60	2	Bluff Point Bike Path		/static/gpx/212_Bluff_Point_Bike_Path.gpx	0.00	Arezzo		Quarto Alvaro	USA
213	2	0.70	112	8.90	1	Bluff Point Trail		/static/gpx/213_Bluff_Point_Trail.gpx	0.00	Trento		Sesto Antonello	USA
214	2	0.80	228	6.20	0	Hrt - Main Street Spur		/static/gpx/214_Hrt___Main_Street_Spur.gpx	0.00	Teramo		Eros terme	USA
215	2	3.90	780	26.50	2	Laurel Brook Trail		/static/gpx/215_Laurel_Brook_Trail.gpx	0.00	Salerno		San Dina calabro	USA
216	2	0.60	77	11.40	2	Wadsworth Falls Park Trail		/static/gpx/216_Wadsworth_Falls_Park_Trail.gpx	0.00	Foggia		Prospera veneto	USA
217	2	0.80	154	25.80	2	White Birch Trail		/static/gpx/217_White_Birch_Trail.gpx	0.00	Campobasso		Gentili lido	USA
218	2	3.70	429	20.50	2	Red Cedar Trail		/static/gpx/218_Red_Cedar_Trail.gpx	0.00	Caserta		Athos terme	USA
219	2	4.60	624	11.20	2	Little Falls Trail		/static/gpx/219_Little_Falls_Trail.gpx	0.00	Verona		Sesto Oscar lido	USA
220	2	2.30	231	5.40	2	Deer Trail		/static/gpx/220_Deer_Trail.gpx	0.00	L'Aquila		Avola salentino	USA
221	2	0.70	210	13.10	2	Rockfall Land Trust Trail		/static/gpx/221_Rockfall_Land_Trust_Trail.gpx	0.00	Bolzano		Errera ligure	USA
222	2	1.40	182	13.90	2	Bridge Trail		/static/gpx/222_Bridge_Trail.gpx	0.00	Ragusa		Salustio a mare	USA
223	2	1.00	40	20.60	2	Main Trail		/static/gpx/223_Main_Trail.gpx	0.00	Matera		Perin umbro	USA
224	2	0.80	165	14.10	2	American Legion Forest Trail		/static/gpx/224_American_Legion_Forest_Trail.gpx	0.00	Foggia		San Selvaggia	USA
225	2	5.20	1185	15.20	2	Turkey Vultures Ledges Trail		/static/gpx/225_Turkey_Vultures_Ledges_Trail.gpx	0.00	Lecco		Doda terme	USA
226	2	5.40	5148	25.10	2	Henry R Buck Trail		/static/gpx/226_Henry_R_Buck_Trail.gpx	0.00	Piacenza		Quarto Santo a mare	USA
227	2	1.50	140	22.40	2	Mashapaug Pond View Trail		/static/gpx/227_Mashapaug_Pond_View_Trail.gpx	0.00	Ogliastra		Quarto Valeria	USA
228	2	2.00	260	21.80	2	Bigelow Hollow Park Trail		/static/gpx/228_Bigelow_Hollow_Park_Trail.gpx	0.00	Medio Campidano		Fulberto sardo	USA
229	2	5.10	2398	29.20	2	Breakneck Pond View Trail		/static/gpx/229_Breakneck_Pond_View_Trail.gpx	0.00	Pordenone		Settimo Vanda del friuli	USA
230	2	1.20	176	9.40	2	East Ridge Trail		/static/gpx/230_East_Ridge_Trail.gpx	0.00	Ogliastra		D'Amato terme	USA
231	2	4.60	700	13.00	2	Bigelow Pond Loop Trail		/static/gpx/231_Bigelow_Pond_Loop_Trail.gpx	0.00	Teramo		Amelia umbro	USA
232	2	1.00	84	26.50	2	Ridge Trail		/static/gpx/232_Ridge_Trail.gpx	0.00	Enna		Franchini calabro	USA
233	2	3.90	611	6.30	2	Nipmuck Trail		/static/gpx/233_Nipmuck_Trail.gpx	0.00	Perugia		Provenzano a mare	USA
234	2	1.00	143	13.90	2	Mattatuck Trail		/static/gpx/234_Mattatuck_Trail.gpx	0.00	Messina		Laurentino del friuli	USA
235	2	0.60	48	18.20	2	Black Rock Park Trail		/static/gpx/235_Black_Rock_Park_Trail.gpx	0.00	Bologna		Abibo lido	USA
236	2	3.60	600	8.60	1	Poquonnock River Walk		/static/gpx/236_Poquonnock_River_Walk.gpx	0.00	Sondrio		Gasser del friuli	USA
237	2	0.90	350	15.00	0	Kempf & Shenipsit Trail		/static/gpx/237_Kempf___Shenipsit_Trail.gpx	0.00	Campobasso		Altea a mare	USA
238	2	1.10	168	14.30	1	Kempf Trail		/static/gpx/238_Kempf_Trail.gpx	0.00	La Spezia		San Agape laziale	USA
239	2	0.80	26	22.20	1	Railroad Bed		/static/gpx/239_Railroad_Bed.gpx	0.00	Medio Campidano		Natale laziale	USA
240	2	1.10	98	26.60	1	Mohegan Trail		/static/gpx/240_Mohegan_Trail.gpx	0.00	Benevento		Esuperio a mare	USA
241	2	1.90	140	27.30	1	Burr Pond Park Trail		/static/gpx/241_Burr_Pond_Park_Trail.gpx	0.00	Grosseto		Baldini nell'emilia	USA
242	2	0.50	60	27.60	2	Burr Pond Park Path		/static/gpx/242_Burr_Pond_Park_Path.gpx	0.00	Cosenza		Pisu nell'emilia	USA
243	2	0.80	100	29.40	0	Campbell Falls Trail		/static/gpx/243_Campbell_Falls_Trail.gpx	0.00	Alessandria		Sesto Gentile	USA
244	2	1.30	450	19.00	2	Deep Woods Trail		/static/gpx/244_Deep_Woods_Trail.gpx	0.00	Roma		San Gilda umbro	USA
245	2	6.00	1274	10.40	2	Chimney Trail		/static/gpx/245_Chimney_Trail.gpx	0.00	Cremona		Sesto Appia	USA
246	2	1.10	299	15.80	2	Chimney Connector Trail		/static/gpx/246_Chimney_Connector_Trail.gpx	0.00	Ogliastra		Settimo Tosco nell'emilia	USA
247	2	2.20	600	7.70	2	East Woods Trail		/static/gpx/247_East_Woods_Trail.gpx	0.00	Lucca		Ave del friuli	USA
248	2	1.70	180	24.20	2	East Woods Connector Trail		/static/gpx/248_East_Woods_Connector_Trail.gpx	0.00	Cuneo		Abbrescia laziale	USA
249	2	0.60	44	14.50	2	Covered Bridge Connector Trail		/static/gpx/249_Covered_Bridge_Connector_Trail.gpx	0.00	Milano		Bartolomei del friuli	USA
250	2	1.20	518	12.20	2	Covered Bridge Trail		/static/gpx/250_Covered_Bridge_Trail.gpx	0.00	Viterbo		Mauro umbro	USA
251	2	8.00	1131	9.40	2	Lookout Trail		/static/gpx/251_Lookout_Trail.gpx	0.00	Salerno		Quarto Birino veneto	USA
252	2	0.90	50	11.10	2	Chatfield Hollow Park Trail		/static/gpx/252_Chatfield_Hollow_Park_Trail.gpx	0.00	Rieti		Asterio salentino	USA
253	2	0.90	144	13.10	2	Lookout Spur Trail		/static/gpx/253_Lookout_Spur_Trail.gpx	0.00	Caserta		Lippolis umbro	USA
254	2	2.20	319	24.50	2	Chimney Spur Trail		/static/gpx/254_Chimney_Spur_Trail.gpx	0.00	Pescara		Minniti salentino	USA
255	2	1.00	70	26.70	2	Deep Woods Access Trail		/static/gpx/255_Deep_Woods_Access_Trail.gpx	0.00	Savona		Di Carlo calabro	USA
256	2	4.10	429	14.80	2	West Crest Trail		/static/gpx/256_West_Crest_Trail.gpx	0.00	Potenza		Borgo Beniamina	USA
257	2	0.80	196	24.20	2	Chatfield Park Path		/static/gpx/257_Chatfield_Park_Path.gpx	0.00	Prato		Quarto Corrado	USA
258	2	6.90	3345	19.50	2	Pond Trail		/static/gpx/258_Pond_Trail.gpx	0.00	Lecce		Cherubini veneto	USA
259	2	0.60	105	23.90	0	Paul F Wildermann		/static/gpx/259_Paul_F_Wildermann.gpx	0.00	Frosinone		Borgo Odorico	USA
260	2	0.90	60	24.80	2	Cockaponset Forest Path		/static/gpx/260_Cockaponset_Forest_Path.gpx	0.00	Catanzaro		Cardinale a mare	USA
261	2	0.80	56	28.70	2	Kay Fullerton Trail		/static/gpx/261_Kay_Fullerton_Trail.gpx	0.00	Agrigento		Sesto Otello	USA
262	2	4.70	855	28.50	0	Quinimay Trail		/static/gpx/262_Quinimay_Trail.gpx	0.00	Biella		Sesto Fiammetta	USA
263	2	2.20	330	29.80	2	Cowboy Way Trail		/static/gpx/263_Cowboy_Way_Trail.gpx	0.00	Venezia		Cornelio salentino	USA
264	2	3.30	996	21.80	2	Muck Rock Road Trail		/static/gpx/264_Muck_Rock_Road_Trail.gpx	0.00	Messina		Borgo Savina	USA
265	2	2.20	322	12.00	2	Weber Road Trail		/static/gpx/265_Weber_Road_Trail.gpx	0.00	Como		San Eufemia	USA
266	2	0.90	112	10.00	2	Beechnut Bog Trail		/static/gpx/266_Beechnut_Bog_Trail.gpx	0.00	Caltanissetta		Settimo Antigone terme	USA
267	2	1.30	154	13.20	2	Wood Road Trail		/static/gpx/267_Wood_Road_Trail.gpx	0.00	Avellino		Settimo Mercurio	USA
268	2	1.50	120	13.30	2	Bumpy Hill Road Trail		/static/gpx/268_Bumpy_Hill_Road_Trail.gpx	0.00	Campobasso		Rosalia salentino	USA
269	2	4.30	720	23.20	2	Kristens Way Trail		/static/gpx/269_Kristens_Way_Trail.gpx	0.00	Napoli		Sesto Tommaso	USA
270	2	0.70	66	15.40	2	Messerschmidt Lane Trail		/static/gpx/270_Messerschmidt_Lane_Trail.gpx	0.00	Piacenza		Giove lido	USA
271	2	4.40	720	28.10	2	Tower Hill Connector Trail		/static/gpx/271_Tower_Hill_Connector_Trail.gpx	0.00	Genova		Geremia ligure	USA
272	2	8.00	1806	16.00	2	Mattabesset Trail		/static/gpx/272_Mattabesset_Trail.gpx	0.00	Taranto		Borgo Zetico	USA
273	2	1.40	140	17.70	2	Mattabasset Trail		/static/gpx/273_Mattabasset_Trail.gpx	0.00	Ogliastra		Ferrero a mare	USA
274	2	7.90	1770	27.40	2	Old Mattebesset Trail		/static/gpx/274_Old_Mattebesset_Trail.gpx	0.00	Palermo		Erberto sardo	USA
275	2	1.70	588	18.70	2	Huntington Park Trail		/static/gpx/275_Huntington_Park_Trail.gpx	0.00	Firenze		Sesto Delia	USA
276	2	7.00	1050	8.40	2	Huntington Ridge Trail		/static/gpx/276_Huntington_Ridge_Trail.gpx	0.00	Napoli		Masucci nell'emilia	USA
277	2	1.30	300	5.70	2	Aspetuck Valley Trail		/static/gpx/277_Aspetuck_Valley_Trail.gpx	0.00	Siena		Settimo Archippo	USA
278	2	1.40	168	5.00	2	Vista Trail		/static/gpx/278_Vista_Trail.gpx	0.00	Lucca		San Annunziata	USA
279	2	0.80	108	26.50	2	Devils Hopyard Park Trail		/static/gpx/279_Devils_Hopyard_Park_Trail.gpx	0.00	Pavia		Borgo Desiderio	USA
280	2	2.10	392	27.70	2	Witch Hazel/Millington Trail		/static/gpx/280_Witch_Hazel_Millington_Trail.gpx	0.00	Catanzaro		Meo calabro	USA
281	2	2.10	351	8.70	2	Millington Trail		/static/gpx/281_Millington_Trail.gpx	0.00	Mantova		Borgo Radolfo	USA
282	2	0.80	300	26.10	2	Loop Trail		/static/gpx/282_Loop_Trail.gpx	0.00	Vibo Valentia		Sesto Mercurio	USA
283	2	6.40	1596	9.40	2	Witch Hazel Trail		/static/gpx/283_Witch_Hazel_Trail.gpx	0.00	Cagliari		Settimo Vittoriano sardo	USA
284	2	8.00	800	21.40	2	Woodcutters Trail		/static/gpx/284_Woodcutters_Trail.gpx	0.00	Milano		Quarto Sara	USA
285	2	1.50	165	21.30	2	Chapman Falls Trail		/static/gpx/285_Chapman_Falls_Trail.gpx	0.00	Ravenna		Luigi lido	USA
286	2	0.70	110	20.70	2	Devils Oven Spur Trail		/static/gpx/286_Devils_Oven_Spur_Trail.gpx	0.00	Gorizia		San Aristide	USA
287	2	9.10	2453	14.30	2	Maxs Trail		/static/gpx/287_Maxs_Trail.gpx	0.00	Bolzano		Borgo Alfreda	USA
288	2	1.10	78	17.40	2	Machimoodus Park Trail		/static/gpx/288_Machimoodus_Park_Trail.gpx	0.00	Mantova		San Orlando	USA
289	2	1.40	130	22.20	0	Fishermans Trail		/static/gpx/289_Fishermans_Trail.gpx	0.00	Pordenone		Liuzzi salentino	USA
290	2	2.30	2882	18.50	2	Ccc Trail		/static/gpx/290_Ccc_Trail.gpx	0.00	Reggio Calabria		San Alcina calabro	USA
291	2	5.20	924	10.90	2	Natchaug Trail		/static/gpx/291_Natchaug_Trail.gpx	0.00	Matera		Borgo Ermilo	USA
292	2	0.60	60	13.20	2	Natchaug Forest Trail		/static/gpx/292_Natchaug_Forest_Trail.gpx	0.00	Venezia		Borgo Giocondo lido	USA
293	2	1.40	375	12.60	2	Goodwin Forest Trail		/static/gpx/293_Goodwin_Forest_Trail.gpx	0.00	Teramo		Sesto Pacifico	USA
294	2	4.40	645	27.90	2	Pine Acres Pond Trail		/static/gpx/294_Pine_Acres_Pond_Trail.gpx	0.00	Prato		Cataldo ligure	USA
295	2	1.40	252	12.40	2	Brown Hill Pond Trail		/static/gpx/295_Brown_Hill_Pond_Trail.gpx	0.00	Savona		San Frontiniano terme	USA
296	2	1.90	247	8.70	2	Yellow White Loop Trail		/static/gpx/296_Yellow_White_Loop_Trail.gpx	0.00	Torino		San Remondo lido	USA
297	2	3.10	975	26.20	2	Red Yellow Connector Trail		/static/gpx/297_Red_Yellow_Connector_Trail.gpx	0.00	Ragusa		Sesto Ultimo	USA
298	2	6.30	1188	13.40	2	Governor'S Island Trail		/static/gpx/298_Governor_S_Island_Trail.gpx	0.00	Como		Borgo Querano	USA
299	2	0.70	156	25.80	2	Goodwin Foresttrail		/static/gpx/299_Goodwin_Foresttrail.gpx	0.00	Varese		Argo calabro	USA
300	2	1.00	187	8.10	2	Forest Discovery Trail		/static/gpx/300_Forest_Discovery_Trail.gpx	0.00	Olbia-Tempio		Consolata calabro	USA
301	2	0.60	70	24.70	2	Goodwin Heritage Trail		/static/gpx/301_Goodwin_Heritage_Trail.gpx	0.00	Salerno		Bartolo umbro	USA
302	2	4.00	418	15.40	2	Crest		/static/gpx/302_Crest.gpx	0.00	Oristano		Quarto Alceste calabro	USA
303	2	8.80	880	27.20	0	Mansfield Hollow Park Trail		/static/gpx/303_Mansfield_Hollow_Park_Trail.gpx	0.00	Sondrio		Quarto Carmela sardo	USA
304	2	3.10	374	8.70	2	Nipmuck Trail - East Branch		/static/gpx/304_Nipmuck_Trail___East_Branch.gpx	0.00	Verona		Antea calabro	USA
305	2	7.40	1925	26.70	0	Nipmuck Alternate		/static/gpx/305_Nipmuck_Alternate.gpx	0.00	Salerno		Viviana veneto	USA
306	2	0.80	50	24.70	1	Mashamoquet Brook Nature Trail		/static/gpx/306_Mashamoquet_Brook_Nature_Trail.gpx	0.00	Rieti		Quarto Elita	USA
307	2	2.00	210	13.40	2	Nipmuck Forest Trail		/static/gpx/307_Nipmuck_Forest_Trail.gpx	0.00	Pavia		Niceforo salentino	USA
308	2	0.90	120	26.80	2	Morey Pond Trail		/static/gpx/308_Morey_Pond_Trail.gpx	0.00	Mantova		San Fatima	USA
309	2	1.90	247	5.10	2	Nipmuck Foreat Trail		/static/gpx/309_Nipmuck_Foreat_Trail.gpx	0.00	Ravenna		Feliciano nell'emilia	USA
310	2	3.10	649	28.40	2	Pharisee Rock Trail		/static/gpx/310_Pharisee_Rock_Trail.gpx	0.00	Rieti		Carlucci a mare	USA
311	2	1.40	280	11.00	2	Pachaug Forest Trail		/static/gpx/311_Pachaug_Forest_Trail.gpx	0.00	Biella		Manca lido	USA
312	2	4.10	480	7.30	2	Pachaug Trail		/static/gpx/312_Pachaug_Trail.gpx	0.00	Brescia		Carbon sardo	USA
313	2	4.40	790	17.10	2	Canonicus Trail		/static/gpx/313_Canonicus_Trail.gpx	0.00	Napoli		Settimo Beata	USA
315	2	2.50	500	15.80	2	Laurel Loop Trail		/static/gpx/315_Laurel_Loop_Trail.gpx	0.00	Reggio Emilia		Turchi umbro	USA
316	2	1.10	108	26.20	2	Pachaug/Nehantic Connector		/static/gpx/316_Pachaug_Nehantic_Connector.gpx	0.00	Catania		Loiacono laziale	USA
317	2	2.60	406	28.50	2	Pachaug/Tippecansett Connector		/static/gpx/317_Pachaug_Tippecansett_Connector.gpx	0.00	Fermo		Borgo Massimo	USA
318	2	1.90	270	23.90	2	Nehantic/Pachaug Connector		/static/gpx/318_Nehantic_Pachaug_Connector.gpx	0.00	Sassari		Manica calabro	USA
319	2	4.90	1534	19.70	2	Quinebaug/Pachaug Connector		/static/gpx/319_Quinebaug_Pachaug_Connector.gpx	0.00	Modena		Giandomenico umbro	USA
320	2	0.70	56	12.60	2	Quinebaug Trail		/static/gpx/320_Quinebaug_Trail.gpx	0.00	Cosenza		San Demetrio	USA
321	2	2.50	1027	22.60	2	Pachaug/Narragansett Connector		/static/gpx/321_Pachaug_Narragansett_Connector.gpx	0.00	Pavia		Guerriero salentino	USA
322	2	0.80	90	21.30	2	Narragansett Trail		/static/gpx/322_Narragansett_Trail.gpx	0.00	Arezzo		Sesto Carla	USA
323	2	2.80	1027	7.90	2	Green Falls Loop Trail		/static/gpx/323_Green_Falls_Loop_Trail.gpx	0.00	Lecco		Settimo Giacobbe	USA
324	2	0.80	121	6.90	2	Green Falls Water Access Trail		/static/gpx/324_Green_Falls_Water_Access_Trail.gpx	0.00	Potenza		Giovannetti del friuli	USA
325	2	0.90	70	14.40	2	Freeman Trail		/static/gpx/325_Freeman_Trail.gpx	0.00	Ragusa		Vulmaro a mare	USA
326	2	4.10	507	13.30	2	Tippecansett Trail		/static/gpx/326_Tippecansett_Trail.gpx	0.00	Matera		Zoe sardo	USA
327	2	1.80	210	26.30	2	Tippecansett/Freeman Trail		/static/gpx/327_Tippecansett_Freeman_Trail.gpx	0.00	Pistoia		Santangelo salentino	USA
328	2	2.00	273	20.30	1	Green Falls Pond Trail		/static/gpx/328_Green_Falls_Pond_Trail.gpx	0.00	Asti		Borgo Lidio terme	USA
329	2	2.80	350	13.30	2	Nehantic/Pachaug Trail		/static/gpx/329_Nehantic_Pachaug_Trail.gpx	0.00	Teramo		Addis lido	USA
330	2	2.80	705	25.20	2	Phillips Pond Spur Trail		/static/gpx/330_Phillips_Pond_Spur_Trail.gpx	0.00	Barletta-Andria-Trani		Chiacchio sardo	USA
331	2	1.10	120	14.60	2	Quinebaug/Nehantic Connector		/static/gpx/331_Quinebaug_Nehantic_Connector.gpx	0.00	Roma		Quarto Fiore	USA
332	2	1.80	154	21.50	2	Nehantic/Quinebaug Connector		/static/gpx/332_Nehantic_Quinebaug_Connector.gpx	0.00	Lecco		San Tranquillo ligure	USA
333	2	0.90	84	27.10	2	Patagansett Trail		/static/gpx/333_Patagansett_Trail.gpx	0.00	Pordenone		Tiziana nell'emilia	USA
334	2	4.90	590	10.80	2	Paugussett Forest Trail		/static/gpx/334_Paugussett_Forest_Trail.gpx	0.00	Avellino		San Orlando	USA
335	2	0.70	120	15.40	2	Zoar Trail		/static/gpx/335_Zoar_Trail.gpx	0.00	Taranto		Bonanni umbro	USA
336	2	0.90	392	22.00	2	Lillinonah Trail		/static/gpx/336_Lillinonah_Trail.gpx	0.00	Teramo		Pennestrì laziale	USA
337	2	2.10	408	27.70	2	Zoar Trail (Old)		/static/gpx/337_Zoar_Trail__Old_.gpx	0.00	Asti		Moretto lido	USA
338	2	5.40	588	24.40	0	Upper Gussy Trail		/static/gpx/338_Upper_Gussy_Trail.gpx	0.00	Olbia-Tempio		San Fernanda	USA
339	2	1.90	377	17.90	2	Pierrepont Park Trail		/static/gpx/339_Pierrepont_Park_Trail.gpx	0.00	Forlì-Cesena		Borgo Addolorata	USA
340	2	1.80	195	6.50	2	Shenipsit Forest Trail		/static/gpx/340_Shenipsit_Forest_Trail.gpx	0.00	Grosseto		Quarto Cunegonda umbro	USA
341	2	3.90	602	27.80	2	Quary Trail		/static/gpx/341_Quary_Trail.gpx	0.00	Monza e della Brianza		Borgo Perseo calabro	USA
342	2	3.80	476	14.70	2	Shenipsit Forest Road		/static/gpx/342_Shenipsit_Forest_Road.gpx	0.00	Firenze		Paradiso sardo	USA
343	2	0.60	28	24.10	2	Topsmead Forest Trail		/static/gpx/343_Topsmead_Forest_Trail.gpx	0.00	Reggio Calabria		Barbarigo terme	USA
344	2	6.40	2025	8.20	2	Edith M Chase Ecology Trail		/static/gpx/344_Edith_M_Chase_Ecology_Trail.gpx	0.00	Lucca		Quarto Rinaldo	USA
345	2	2.70	1190	15.10	2	Bernard H Stairs Trail		/static/gpx/345_Bernard_H_Stairs_Trail.gpx	0.00	Sondrio		San Terenzio	USA
346	2	4.20	672	15.00	2	West Rock Park Trail		/static/gpx/346_West_Rock_Park_Trail.gpx	0.00	Biella		Borgo Lara terme	USA
347	2	7.00	972	9.70	2	West Rock Summit Trail		/static/gpx/347_West_Rock_Summit_Trail.gpx	0.00	Brescia		San Cleo salentino	USA
348	2	2.00	2364	18.30	2	Regicides Trail		/static/gpx/348_Regicides_Trail.gpx	0.00	Lecce		Gianpietro salentino	USA
349	2	3.70	1859	14.80	0	Sanford Feeder Trail		/static/gpx/349_Sanford_Feeder_Trail.gpx	0.00	Pordenone		D'Urso salentino	USA
350	2	5.00	2532	26.70	2	North Summit Trail		/static/gpx/350_North_Summit_Trail.gpx	0.00	Barletta-Andria-Trani		Genna ligure	USA
351	2	3.40	476	13.20	2	Westville Feeder Trail		/static/gpx/351_Westville_Feeder_Trail.gpx	0.00	Brescia		San Guiberto calabro	USA
352	2	1.70	209	19.70	2	West Rock Park Road		/static/gpx/352_West_Rock_Park_Road.gpx	0.00	Caltanissetta		San Amando calabro	USA
353	2	2.00	455	29.60	2	Bennetts Pond Trail		/static/gpx/353_Bennetts_Pond_Trail.gpx	0.00	Macerata		Ermenegilda veneto	USA
354	2	4.20	539	28.80	0	Ives Trail		/static/gpx/354_Ives_Trail.gpx	0.00	Forlì-Cesena		Settimo Ombretta	USA
355	2	4.30	564	29.90	0	Ridgefield Open Space Trail		/static/gpx/355_Ridgefield_Open_Space_Trail.gpx	0.00	Avellino		Borgo Genesia lido	USA
356	2	0.60	72	5.30	1	George Dudley Seymour Park Trail		/static/gpx/356_George_Dudley_Seymour_Park_Trail.gpx	0.00	Grosseto		Simeoni lido	USA
357	2	0.90	52	23.40	2	Grta		/static/gpx/357_Grta.gpx	0.00	Udine		Egle salentino	USA
358	2	1.30	140	12.30	1	Mohegan Forest Trail		/static/gpx/358_Mohegan_Forest_Trail.gpx	0.00	Caserta		Quarto Alberta a mare	USA
359	2	9.70	1806	20.90	1	Mount Bushnell Trail		/static/gpx/359_Mount_Bushnell_Trail.gpx	0.00	Sassari		Eva lido	USA
360	2	1.20	266	15.80	2	Nye Holman Trail		/static/gpx/360_Nye_Holman_Trail.gpx	0.00	Vercelli		Fiorenzo nell'emilia	USA
361	2	1.10	165	13.10	2	Al'S Trail		/static/gpx/361_Al_S_Trail.gpx	0.00	Pescara		Borgo Fidenziano calabro	USA
362	2	2.40	684	16.00	2	Salt Rock State Park Trail		/static/gpx/362_Salt_Rock_State_Park_Trail.gpx	0.00	Udine		Borgo Gastone	USA
363	2	1.10	225	10.60	0	Scantic River Trail		/static/gpx/363_Scantic_River_Trail.gpx	0.00	Aosta		Minerva del friuli	USA
364	2	0.60	112	30.00	0	Scantic River Park Trail		/static/gpx/364_Scantic_River_Park_Trail.gpx	0.00	L'Aquila		Settimo Amando a mare	USA
365	2	0.50	55	28.30	2	Scantic Park Access		/static/gpx/365_Scantic_Park_Access.gpx	0.00	Barletta-Andria-Trani		Sesto Giusta ligure	USA
366	2	0.80	221	9.10	0	Sunrise Park Trail		/static/gpx/366_Sunrise_Park_Trail.gpx	0.00	Benevento		Regolo del friuli	USA
367	2	7.50	1782	18.30	1	Kitchel Trail		/static/gpx/367_Kitchel_Trail.gpx	0.00	Fermo		Quarto Eligio	USA
368	2	1.30	168	18.10	2	Old Driveway		/static/gpx/368_Old_Driveway.gpx	0.00	Palermo		Fabiano veneto	USA
369	2	1.20	182	5.50	1	Kitchel		/static/gpx/369_Kitchel.gpx	0.00	Agrigento		Venturini a mare	USA
370	2	0.60	140	5.50	2	Driveway		/static/gpx/370_Driveway.gpx	0.00	Lodi		Campanile ligure	USA
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website, elevation) FROM stdin;
1	1	1	70.00	Edmund-Graf-Hütte	2	Dott. Fidenziano Garifo	http://husky-divan.it	\N
2	2	2	77.00	Dr.Hernaus-Stöckl	2	Domenico Casagrande	http://legitimate-span.it	\N
3	3	8	63.00	Amstettner Hütte	2	Ing. Andrea Monni	http://cheery-crush.net	\N
4	4	2	60.00	Hochleckenhaus	2	Raide Provenzano	https://eager-canoe.net	\N
5	5	10	131.00	Kampthalerhütte	2	Remo Di Michele	http://proud-commodity.net	\N
6	6	7	99.00	Lambacher Hütte	2	Cristiano D'Angelo	https://icky-conscience.com	\N
7	7	3	63.00	Lustenauer Hütte	2	Fosca Sevi	https://yearly-ladle.it	\N
8	8	5	46.00	Gablonzer Hütte	2	Orsolina Carrara	http://hoarse-velocity.it	\N
9	9	2	102.00	Katafygio «Flampouri»	2	Federico Pacifico	http://supportive-ecclesia.com	\N
10	10	2	43.00	Simonyhütte	2	Ivanoe Fortunato	https://ultimate-petition.org	\N
11	11	2	126.00	Vinzenz-Tollinger-Hütte	2	Simeone Floris	https://visible-dragonfruit.org	\N
12	12	7	120.00	Ottokar-Kernstock-Haus	2	Ladislao Mariotti	https://admirable-mailer.com	\N
13	13	6	92.00	Reisseckhütte	2	Querano Zanotti	https://impractical-nod.com	\N
14	14	10	62.00	Vernagthütte	2	Ella Verme	http://snoopy-noodle.it	\N
15	15	8	96.00	Wormser Hütte	2	Dott. Daria Belvisi	http://pointed-ectodermal.com	\N
16	16	7	128.00	Biberacher Hütte	2	Ing. Carmelo Prisco	https://real-doubling.net	\N
17	17	5	124.00	Katafygio «1777»	2	Elpidio Lana	https://trifling-release.net	\N
18	18	8	120.00	Hochwaldhütte	2	Baldovino Milani	https://remarkable-sigh.com	\N
19	19	2	49.00	Kölner Eifelhütte	2	Tea Marinucci	https://slimy-airplane.it	\N
20	20	10	37.00	Madrisahütte	2	Nicodemo Lotti	https://best-jaguar.net	\N
21	21	8	100.00	Dresdner Hütte	2	Sig. Ottilia Giordano	http://outlying-carriage.net	\N
22	22	9	55.00	Fiderepasshütte	2	Ada Serena	https://equatorial-accordion.com	\N
23	23	5	35.00	Göppinger Hütte	2	Dr. Alvaro Meo	http://glistening-rock.org	\N
24	24	9	61.00	Oberzalimhütte	2	Aloisio Buzzi	http://grouchy-debris.org	\N
25	25	10	75.00	Rastkogelhütte	2	Crispino Aramini	http://ethical-shame.org	\N
26	26	1	148.00	Ansbacher Skihütte im Allgäu	2	Erminia Bandini	http://flamboyant-entree.it	\N
27	27	4	72.00	Kaltenberghütte	2	Chiaffredo Nota	http://lined-giant.net	\N
28	28	5	105.00	Schweinfurter Hütte	2	Giada Catellani	https://experienced-musculature.net	\N
29	29	4	53.00	Katafygio «Vardousion»	2	Wanda Allegretti	https://dangerous-beret.net	\N
30	30	3	135.00	Kocbekov dom na Korošici	2	Bice Licciardello	https://pink-permission.com	\N
31	31	7	64.00	Planinski dom Rašiške cete na Rašici	2	Melchiorre Paolino	https://jittery-paint.com	\N
32	32	2	129.00	Prešernova koca na Stolu	2	Benvenuta Beltrame	http://fake-fashion.it	\N
33	33	9	130.00	Planinski dom na Mrzlici	2	Taziano Girone	https://united-lacquerware.org	\N
34	34	3	66.00	Koca na Planini nad Vrhniko	2	Polissena Iorio	http://fair-shoreline.org	\N
35	35	4	106.00	Zavetišce gorske straže na Jelencih	2	Cleofe Polito	https://any-synonym.net	\N
36	36	10	101.00	Planinski dom na Gori	2	Gianluigi Iacolare	http://pristine-territory.net	\N
37	37	6	56.00	Bregarjevo zavetišce na planini Viševnik	2	Cirillo Mosti	http://quiet-husband.com	\N
38	38	8	99.00	Koca pod Bogatinom	2	Alfonsa Pratesi	https://worse-cobbler.it	\N
39	39	2	56.00	Pogacnikov dom na Kriških podih	2	Ing. Benigna Padovan	http://treasured-orientation.org	\N
40	40	4	36.00	Dom na Smrekovcu	2	Virginia Zago	http://aromatic-brushfire.org	\N
41	41	3	39.00	Refuge Du Chatelleret	2	Sarbello Puglisi	http://quaint-eclipse.org	\N
42	42	7	39.00	Refuge De Chalance	2	Dr. Ulderico Manca	https://delicious-outback.net	\N
43	43	10	53.00	Refuge Des Bans	2	Giuliana Pozzi	https://rash-perfume.com	\N
44	44	10	121.00	Refuge De Pombie	2	Cunegonda Rosselli	http://pungent-casement.net	\N
45	45	10	76.00	Refuge De Larribet	2	Azeglio Mazzaro	http://heavy-ideal.com	\N
46	46	6	136.00	Refuge Du Mont Pourri	2	Porfirio Martinelli	https://noisy-burglar.org	\N
47	47	9	82.00	Refuge De La Dent D?Oche	2	Aurora Rosi	https://dramatic-suppression.org	\N
48	48	1	89.00	Bergseehütte SAC	2	Sabato Furlan	http://whirlwind-good.it	\N
49	49	2	40.00	Bivouac au Col de la Dent Blanche CAS	2	Evasio De Bonis	https://lovable-coal.net	\N
50	50	6	69.00	Salbitschijenbiwak SAC	2	Mirella De Maio	http://vigilant-marble.it	\N
51	51	1	128.00	Spannorthütte SAC	2	Daria Sodano	https://buzzing-saucer.com	\N
52	52	8	100.00	Cabane Arpitettaz CAS	2	Zetico La Torre	http://experienced-voice.net	\N
53	53	7	65.00	Refugio De Lizara	2	Olga Tonini	http://bare-burrow.net	\N
54	54	2	48.00	Albergue De Montfalcó	2	Gandolfo Sorbello	https://baggy-pantsuit.it	\N
55	55	5	76.00	El Molonillo/Peña Partida	2	Gonzaga Bergamasco	http://uncomfortable-yellow.net	\N
56	56	10	128.00	La Campiñuela	2	Massima Di Liberto	http://impolite-homonym.it	\N
57	57	5	104.00	Titov Vrv	2	Eligio Parise	http://faint-ceramic.net	\N
58	58	3	139.00	Rifugio Franchetti	2	Angela Albanese	http://yellow-divide.net	\N
59	59	6	57.00	Rifugio Semenza	2	Liboria Rossi	http://lustrous-corn.org	\N
60	60	2	102.00	Rifugio Città di Mortara 	2	Sig. Calpurnia Giuffrida	https://harmful-top.com	\N
61	61	7	94.00	Rifugio Andolla	2	Donatella Spinelli	https://biodegradable-gang.org	\N
62	62	4	47.00	Rifugio Forte dei Marmi	2	Mansueto Talarico	https://idle-running.com	\N
63	63	3	72.00	Rifugio Berti	2	Foca Moscato	http://genuine-lawmaker.org	\N
64	64	7	85.00	Rifugio Premuda	2	Ing. Nicezio Mariotti	http://bright-implement.org	\N
65	65	4	38.00	Rifugio Elisa	2	Melania Zappia	http://whole-brief.com	\N
66	66	8	107.00	Rifugio CAI Saronno	2	Giasone Zambuto	http://nervous-primary.it	\N
67	67	3	147.00	Rifugio Picco Ivigna	2	Bonaventura Ceccarini	http://astonishing-dollar.com	\N
68	68	6	90.00	Rifugio Toesca	2	Nicea La Rocca	http://general-numismatist.com	\N
69	69	6	51.00	Rifugio Al Cedo	2	Sabrina Santarelli	https://intentional-patrimony.net	\N
70	70	1	106.00	Capanna Gnifetti	2	Sig. Giuditta Spanu	https://quick-foodstuffs.net	\N
71	71	5	106.00	Rifugio Aosta	2	Ovidio Lisi	http://deficient-malice.it	\N
72	72	4	144.00	Rifugio Cevedale	2	Dr. Narsete Angelini	https://sweet-ballot.org	\N
73	73	1	120.00	Rifugio Ponti	2	Berengario Di Domenico	http://elastic-employment.org	\N
74	74	1	120.00	Rifugio XII Apostoli	2	Paride Iacono	http://angry-downfall.com	\N
75	75	6	116.00	Rifugio Elisabetta Soldini	2	Rolfo Pasqua	http://exemplary-classmate.org	\N
76	76	9	107.00	Rifugio Denza	2	Nunziata Cuzzocrea	http://fantastic-vitamin.net	\N
77	77	8	83.00	Rifugio Fonte Tavoloni 	2	Morena Perotti	http://fortunate-sprout.org	\N
78	78	1	134.00	Rifugio Carducci	2	Bonavita Varriale	https://joint-touch.org	\N
79	79	5	44.00	Rifugio Bindesi	2	Babila Masucci	http://livid-vanadyl.com	\N
80	80	3	35.00	Mountain hut Miroslav Hirtz	2	Dr. Ambra Mori	http://private-genius.it	\N
81	81	5	120.00	Koca na Blegošu	2	Telchide Ravaioli	https://alert-oval.org	\N
82	82	6	35.00	Wittener Hütte	2	Temistocle Pece	https://comfortable-resist.org	\N
83	83	10	35.00	Hochjoch-Hospiz	2	Aleardo Pantano	http://flat-thermals.org	\N
84	84	5	124.00	Meilerhütte	2	Martino Latorre	http://far-off-collection.com	\N
85	85	7	97.00	Gaudeamushütte	2	Maria Candido	http://small-perch.com	\N
86	86	9	149.00	Rheydter Hütte	2	Alma Paonessa	http://focused-professional.it	\N
87	87	1	89.00	Sektionshütte Krippen	2	Rosamunda Procopio	https://thankful-still.it	\N
88	88	2	118.00	Neunkirchner Hütte	2	Benvenuta Mazzola	https://cruel-shadow.net	\N
89	89	9	60.00	Refugio De Riglos	2	Pierluigi Cozzani	https://advanced-preserves.net	\N
90	90	6	67.00	Salbithütte SAC	2	Albrico Sapienza	https://neighboring-land.it	\N
91	91	10	146.00	Finsteraarhornhütte SAC	2	Apollinare Leoncini	http://creative-square.it	\N
92	92	7	82.00	Cabane des Vignettes CAS	2	Fedora Fini	https://repulsive-imitation.net	\N
93	93	10	127.00	Glecksteinhütte SAC	2	Teodoto Caporaso	http://grizzled-wrestler.org	\N
94	94	1	81.00	Länta-Hütte SAC	2	Cecilio Dal Farra	https://delectable-major-league.it	\N
95	95	5	146.00	Monte-Leone-Hütte SAC	2	Godiva Cancelliere	https://suspicious-celebration.org	\N
96	96	4	36.00	Ringelspitzhütte SAC	2	Napoleone Capone	https://strange-joy.net	\N
97	97	10	86.00	Na poljanama Maljen	2	Amalia Silvestrini	http://infamous-plight.net	\N
98	98	8	128.00	Dobra voda	2	Turibio Torresi	https://limping-nutrition.org	\N
99	99	5	81.00	Ivanova hiža	2	Giuseppina Pili	http://damaged-employee.org	\N
100	100	3	66.00	Glavica	2	Dr. Mauro Salamone	https://unequaled-instrument.org	\N
101	101	2	129.00	Trpošnjik	2	Coriolano Chilà	http://juicy-downgrade.org	\N
102	102	6	69.00	Bitorajka	2	Eufebio Viola	https://raw-agreement.net	\N
103	103	6	98.00	Zlatko Prgin	2	Dr. Ticone Ottonello	https://mealy-sentiment.org	\N
104	104	6	138.00	Prpa	2	Varo Di Pede	http://slim-stiletto.it	\N
105	105	6	134.00	Ždrilo	2	Costanza Franzoni	https://colorful-lady.net	\N
106	106	7	113.00	Miroslav Hirtz	2	Laurentino Coccia	http://agonizing-nonconformist.org	\N
107	107	3	144.00	Jezerce	2	Primo Zappacosta	https://skinny-prosecution.org	\N
108	108	2	125.00	Ivica Sudnik	2	Armida Bellucci	http://hefty-bubble.net	\N
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
1	109	72	2	Italy	Genova		Sesto Crescente sardo
2	110	115	2	Italy	Novara		Gioia terme
3	111	71	2	Italy	Alessandria		Mamante terme
4	112	119	2	Italy	Brindisi		Orio terme
5	113	46	2	Italy	Trieste		Quarto Albrico
6	114	47	2	Italy	Fermo		Evola salentino
7	115	165	2	Italy	Modena		Gino nell'emilia
8	116	119	2	Italy	Cosenza		Settimo Nino
9	117	84	2	Italy	Prato		Borgo Alceste
10	118	214	2	Italy	Rimini		Quarto Gianpaolo
11	119	159	2	Italy	Firenze		Rauso umbro
12	120	231	2	Italy	Caltanissetta		Toti ligure
13	121	131	2	Italy	Bologna		Falbo lido
14	122	192	2	Italy	Bergamo		Giambattista calabro
15	123	175	2	Italy	Padova		Settimo Marana lido
16	124	168	2	Italy	Forlì-Cesena		Filipponi lido
17	125	187	2	Italy	Nuoro		Sesto Godiva veneto
18	126	289	2	Italy	Viterbo		Sesto Efrem
19	127	222	2	Italy	Oristano		Selene ligure
20	128	117	2	Italy	Caltanissetta		Borgo Giuseppa del friuli
21	129	190	2	Italy	Milano		Metello ligure
22	130	247	2	Italy	Verona		Esuperio sardo
23	131	6	2	Italy	Sondrio		Lana calabro
24	132	176	2	Italy	Bolzano		Valenti laziale
25	133	92	2	Italy	La Spezia		Quarto Birino del friuli
26	134	29	2	Italy	Siracusa		Sesto Landolfo
27	135	188	2	Italy	L'Aquila		Borgo Amaranto
28	136	286	2	Italy	Salerno		Abbondio veneto
29	137	180	2	Italy	Padova		Concas calabro
30	138	70	2	Italy	Padova		Settimo Porzia
31	139	54	2	Italy	Vicenza		Sesto Savina terme
32	140	139	2	Italy	Latina		Pizzitola ligure
33	141	116	2	Italy	Vicenza		Fabrizi a mare
34	142	5	2	Italy	Pisa		Settimo Tiziano
35	143	289	2	Italy	Parma		Borgo Pia salentino
36	144	224	2	Italy	Verbano-Cusio-Ossola		Urdino calabro
37	145	284	2	Italy	Ogliastra		Eligibile laziale
38	146	257	2	Italy	Frosinone		Quarto Gandolfo sardo
39	147	85	2	Italy	Pesaro e Urbino		Egisto calabro
40	148	258	2	Italy	Enna		Ladislao laziale
41	149	20	2	Italy	Ragusa		Quarto Costantino
42	150	285	2	Italy	Brindisi		Orazio umbro
43	151	300	2	Italy	Belluno		Cangiano umbro
44	152	77	2	Italy	Oristano		Quarto Quintilio nell'emilia
45	153	149	2	Italy	Brindisi		San Evandro
46	154	239	2	Italy	Verbano-Cusio-Ossola		Rolando veneto
47	155	290	2	Italy	Roma		Sesto Taziano lido
48	156	113	2	Italy	Piacenza		Quarto Dione
49	157	246	2	Italy	Arezzo		Settimo Agapito veneto
50	158	231	2	Italy	Frosinone		Sesto Regolo laziale
51	159	30	2	Italy	Lecco		Dina sardo
52	160	11	2	Italy	Benevento		Settimo Roberto sardo
53	161	239	2	Italy	Terni		Quarto Pusicio calabro
54	162	8	2	Italy	Siena		Evodio nell'emilia
55	163	151	2	Italy	Brescia		Ambrosini sardo
56	164	149	2	Italy	Lecco		Annabella lido
57	165	296	2	Italy	Fermo		Piccoli nell'emilia
58	166	261	2	Italy	Udine		Sinopoli veneto
59	167	33	2	Italy	Ferrara		Coreno lido
60	168	148	2	Italy	Lodi		Spano a mare
61	169	67	2	Italy	Lodi		Lenzi a mare
62	170	244	2	Italy	Verbano-Cusio-Ossola		Benvenuti lido
63	171	284	2	Italy	Torino		Restivo ligure
64	172	99	2	Italy	Pesaro e Urbino		Emilio nell'emilia
65	173	210	2	Italy	Carbonia-Iglesias		Quarto Ilda ligure
66	174	93	2	Italy	Rimini		Borgo Frido salentino
67	175	72	2	Italy	Mantova		San Fortunato
68	176	130	2	Italy	Novara		Patrizia veneto
69	177	66	2	Italy	Caserta		Belli a mare
70	178	15	2	Italy	Belluno		Settimo Lisandro laziale
71	179	168	2	Italy	Varese		Borgo Marinella veneto
72	180	291	2	Italy	Vicenza		Settimo Damocle
73	181	253	2	Italy	Gorizia		Palmisano terme
74	182	180	2	Italy	Nuoro		Eliodoro del friuli
75	183	161	2	Italy	Brescia		Braia veneto
76	184	190	2	Italy	Rieti		Rutilo calabro
77	185	253	2	Italy	Chieti		Settimo Pollione nell'emilia
78	186	213	2	Italy	Pavia		Crispino sardo
79	187	110	2	Italy	Benevento		Olinda veneto
80	188	109	2	Italy	Pisa		Leopardo terme
81	189	263	2	Italy	Benevento		Quarto Everardo salentino
82	190	198	2	Italy	Rieti		San Quintiliano
83	191	260	2	Italy	Vicenza		Vanna veneto
84	192	53	2	Italy	Pavia		Bartolomeo ligure
85	193	197	2	Italy	Livorno		Sesto Aleandro
86	194	33	2	Italy	Ascoli Piceno		Settimo Alcide laziale
87	195	35	2	Italy	Venezia		Bosco laziale
88	196	268	2	Italy	Novara		Borgo Olimpio
89	197	129	2	Italy	Rovigo		Elifio laziale
90	198	179	2	Italy	Alessandria		Riccardi terme
91	199	264	2	Italy	Napoli		Bonanno calabro
92	200	86	2	Italy	Agrigento		Borgo Cleonico
93	201	183	2	Italy	Rovigo		Modesto lido
94	202	194	2	Italy	Como		Sireno salentino
95	203	206	2	Italy	Caltanissetta		Borgo Platone
96	204	277	2	Italy	Bolzano		Borgo Verena ligure
97	205	122	2	Italy	Crotone		Sesto Aronne ligure
98	206	130	2	Italy	Lecce		Quarto Nicezio
99	207	102	2	Italy	Varese		Borgo Verdiana
100	208	95	2	Italy	Bari		Sesto Zefiro
101	209	212	2	Italy	Agrigento		Roma
102	210	225	2	Italy	Pisa		Lucarini nell'emilia
103	211	98	2	Italy	Lucca		Tedde sardo
104	212	277	2	Italy	Bari		Borgo Bruto laziale
105	213	205	2	Italy	Genova		Quarto Guido
106	214	154	2	Italy	Treviso		Cacciapuoti umbro
107	215	294	2	Italy	Trieste		Erico veneto
108	216	235	2	Italy	Verbano-Cusio-Ossola		Sesto Aurelia
109	217	86	2	Italy	Pesaro e Urbino		Lautone lido
110	218	255	2	Italy	Trieste		Nava umbro
111	219	262	2	Italy	Olbia-Tempio		Rampazzo salentino
112	220	135	2	Italy	Cosenza		Sesto Cleandro a mare
113	221	233	2	Italy	Salerno		Iorio del friuli
114	222	234	2	Italy	Pordenone		Sidonia lido
115	223	101	2	Italy	Palermo		Settimo Flavia
116	224	84	2	Italy	Rimini		Quarto Melissa
117	225	216	2	Italy	Terni		Benvenuto terme
118	226	92	2	Italy	Medio Campidano		Sesto Olga calabro
119	227	87	2	Italy	Crotone		San Gualberto sardo
120	228	187	2	Italy	Verbano-Cusio-Ossola		Settimo Bardomiano nell'emilia
121	229	256	2	Italy	Barletta-Andria-Trani		Criscenti veneto
122	230	123	2	Italy	Pesaro e Urbino		Settimo Viliana
123	231	204	2	Italy	Rieti		Melezio ligure
124	232	152	2	Italy	Asti		San Aida laziale
125	233	266	2	Italy	Vicenza		San Diocleziano laziale
126	234	136	2	Italy	Reggio Calabria		Giorgio laziale
127	235	1	2	Italy	Ogliastra		Borgo Geronzio sardo
128	236	86	2	Italy	Cagliari		Quarto Pippo
129	237	33	2	Italy	Gorizia		Quarto Ada
130	238	1	2	Italy	Ragusa		Sesto Francesca
131	239	1	2	Italy	Carbonia-Iglesias		Leoni salentino
132	240	85	2	Italy	Bolzano		Calligaris salentino
133	241	223	2	Italy	Reggio Calabria		Dante laziale
134	242	137	2	Italy	Parma		San Orchidea umbro
135	243	77	2	Italy	Caltanissetta		Borgo Manetto sardo
136	244	131	2	Italy	Roma		Bionaz nell'emilia
137	245	1	2	Italy	Cagliari		Sesto Irene
138	246	1	2	Italy	Piacenza		Cinelli del friuli
139	247	82	2	Italy	L'Aquila		Mazzoleno nell'emilia
140	248	1	2	Italy	La Spezia		Zaccaro terme
141	249	129	2	Italy	Campobasso		Folco salentino
142	250	233	2	Italy	Verbano-Cusio-Ossola		Sesto Isidoro
143	251	27	2	Italy	Pisa		Porfirio laziale
144	252	58	2	Italy	Pavia		Garifo calabro
145	253	296	2	Italy	Mantova		Sesto Alboino salentino
146	254	153	2	Italy	Verona		Sesto Angela
147	255	232	2	Italy	Genova		Borgo Gennaro
148	256	142	2	Italy	Viterbo		Settimo Stiliano umbro
149	257	61	2	Italy	Perugia		Duccio laziale
150	258	54	2	Italy	Forlì-Cesena		Bini del friuli
151	259	221	2	Italy	Lecce		Livio lido
152	260	106	2	Italy	Arezzo		De Bona laziale
153	261	200	2	Italy	Brescia		Quarto Cloe nell'emilia
154	262	101	2	Italy	Trapani		Settimo Aloisio veneto
155	263	209	2	Italy	Livorno		Borgo Coriolano laziale
156	264	298	2	Italy	Cagliari		Artemisa lido
157	265	249	2	Italy	Lodi		Sesto Gioacchina nell'emilia
158	266	168	2	Italy	Siracusa		Pesaresi lido
159	267	51	2	Italy	Modena		Ivetta calabro
160	268	35	2	Italy	Teramo		Di Gaetano veneto
161	269	152	2	Italy	Agrigento		Quarto Tammaro
162	270	43	2	Italy	Ragusa		Delle Monache umbro
163	271	100	2	Italy	Caserta		Sesto Aimone
164	272	206	2	Italy	Verbano-Cusio-Ossola		Sesto Foca sardo
165	273	144	2	Italy	Cuneo		Quarto Verena veneto
166	274	30	2	Italy	Cuneo		Di Luca umbro
167	275	218	2	Italy	Cuneo		Pierro ligure
168	276	42	2	Italy	Prato		Cappelli lido
169	277	37	2	Italy	Biella		Borgo Alamanno del friuli
170	278	113	2	Italy	Bologna		Ines umbro
171	279	254	2	Italy	Biella		Emiliano nell'emilia
172	280	258	2	Italy	Novara		Bacco terme
173	281	133	2	Italy	Treviso		Settimo Ermanno salentino
174	282	155	2	Italy	Cosenza		Settimo Rino salentino
175	283	137	2	Italy	Asti		Quarto Liberato
176	284	242	2	Italy	Monza e della Brianza		Borgo Elaide
177	285	224	2	Italy	Grosseto		Sesto Penelope del friuli
178	286	138	2	Italy	Verbano-Cusio-Ossola		Niccolai lido
179	287	275	2	Italy	Caltanissetta		Alessia a mare
180	288	111	2	Italy	Monza e della Brianza		Turco umbro
181	289	106	2	Italy	Caserta		Eufrasia veneto
182	290	85	2	Italy	Matera		Bassiano umbro
183	291	6	2	Italy	Bolzano		Carbon terme
184	292	265	2	Italy	Siracusa		Lendinara
185	293	181	2	Italy	Modena		Quarto Lamberto
186	294	295	2	Italy	Ancona		Napoli
187	295	69	2	Italy	Macerata		Quarto Teodata del friuli
188	296	240	2	Italy	Verbano-Cusio-Ossola		Quarto Benedetto
189	297	212	2	Italy	Cuneo		Alice del friuli
190	298	241	2	Italy	Lecce		Settimo Fiorenzo del friuli
191	299	143	2	Italy	Ferrara		Pizzitola calabro
192	300	244	2	Italy	Arezzo		Settimo Ariosto a mare
193	301	249	2	Italy	Potenza		Marciano veneto
194	302	187	2	Italy	Pescara		San Fabiana calabro
195	303	291	2	Italy	Aosta		Sesto Amanzio
196	304	98	2	Italy	Rimini		Ferrario ligure
197	305	121	2	Italy	Roma		San Ulrico laziale
198	306	171	2	Italy	Caltanissetta		Quarto Fatima lido
199	307	101	2	Italy	Agrigento		Settimo Ippocrate
200	308	292	2	Italy	Imperia		Giannelli a mare
201	309	158	2	Italy	Pistoia		San Alice
202	310	41	2	Italy	Verona		Borgo Gottardo
203	311	410	2	Italy	Milano		Sesto Iris calabro
204	312	73	2	Italy	Bari		Siro lido
205	313	171	2	Italy	Catanzaro		San Adelasia umbro
206	314	233	2	Italy	Verbano-Cusio-Ossola		Settimo Ermenegilda
207	315	141	2	Italy	Belluno		Quarto Lucia
208	316	266	2	Italy	Gorizia		Edvige umbro
209	317	60	2	Italy	Forlì-Cesena		Perri lido
210	318	98	2	Italy	Bolzano		Sesto Astrid
211	319	185	2	Italy	Carbonia-Iglesias		Bassiano del friuli
212	320	222	2	Italy	Verbano-Cusio-Ossola		Lattanzi terme
213	321	9	2	Italy	Chieti		Settimo Indro veneto
214	322	118	2	Italy	Ancona		Settimo Federico ligure
215	323	283	2	Italy	Belluno		Manuela lido
216	324	30	2	Italy	Latina		San Macario
217	325	57	2	Italy	Trapani		Paolo umbro
218	326	291	2	Italy	Rovigo		Onorino del friuli
219	327	43	2	Italy	Ascoli Piceno		Diodoro umbro
220	328	128	2	Italy	Sassari		Volpe sardo
221	329	240	2	Italy	Crotone		Sesto Lidio sardo
222	330	3	2	Italy	Siracusa		Basile laziale
223	331	214	2	Italy	Reggio Calabria		Sesto Rosa ligure
224	332	225	2	Italy	Trapani		Gagliardi nell'emilia
225	333	208	2	Italy	Modena		San Fiorenza
226	334	291	2	Italy	Asti		Sesto Salustio nell'emilia
227	335	192	2	Italy	Terni		Borgo Telica veneto
228	336	260	2	Italy	Varese		Rossetti del friuli
229	337	275	2	Italy	Verbano-Cusio-Ossola		Maruta umbro
230	338	65	2	Italy	Macerata		Galluzzo veneto
231	339	294	2	Italy	Ancona		Quarto Varo sardo
232	340	186	2	Italy	Napoli		Cosimo sardo
233	341	295	2	Italy	Gorizia		Quarto Gaspare
234	342	281	2	Italy	Pavia		Borgo Rossana
235	343	200	2	Italy	Crotone		Quarto Alarico terme
236	344	76	2	Italy	Agrigento		San Azelia
237	345	103	2	Italy	Verona		Valeria lido
238	346	241	2	Italy	Ascoli Piceno		San Gallicano
239	347	161	2	Italy	Bologna		Adalrico nell'emilia
240	348	165	2	Italy	Fermo		Damiana a mare
241	349	224	2	Italy	Milano		Casano laziale
242	350	54	2	Italy	La Spezia		Selvaggia terme
243	351	139	2	Italy	L'Aquila		Tomasi a mare
244	352	131	2	Italy	Lecce		San Berenice terme
245	353	59	2	Italy	Foggia		Borgo Guelfo calabro
246	354	46	2	Italy	Pavia		Basilia a mare
247	355	257	2	Italy	Bergamo		Samona nell'emilia
248	356	54	2	Italy	Trapani		Boffa lido
249	357	70	2	Italy	Asti		Farella laziale
250	358	9	2	Italy	Perugia		Quarto Goffredo
251	359	30	2	Italy	Ogliastra		San Nino ligure
252	360	193	2	Italy	Terni		Petrelli a mare
253	361	37	2	Italy	Crotone		Astrid veneto
254	362	113	2	Italy	Savona		Mariano calabro
255	363	145	2	Italy	Trieste		Borgo Verulo umbro
256	364	145	2	Italy	Novara		Settimo Everardo ligure
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address) FROM stdin;
1	0	0101000020E61000002D64979723B62440C66F2527958D4740	Edmund-Graf-Hütte	6574 Pettneu am Arlberg, Tyrol, Austria
2	0	0101000020E6100000455BF9D0380E2A4056DBD4F478794740	Dr.Hernaus-Stöckl	9020 Klagenfurt, Kärnten, Austria
3	0	0101000020E61000003AD4CD22968A2D406DAF4FF575F14740	Amstettner Hütte	3340 Waidhofen an der Ybbs, Niederösterreich, Austria
4	0	0101000020E61000003470C88518362B404F23C0A11DEA4740	Hochleckenhaus	4853 Steinbach am Attersee, Oberösterreich, Austria
5	0	0101000020E6100000745CA7EA5C3230400E95C9F10B114840	Kampthalerhütte	2384 Breitenfurt bei Wien, Niederösterreich, Austria
6	0	0101000020E610000059E5350827672B402FB2862AC2D34740	Lambacher Hütte	4822 Bad Goisern, Oberösterreich, Austria
7	0	0101000020E610000019FDD2643FA62340662869A087B24740	Lustenauer Hütte	6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria
8	0	0101000020E610000036849931B0F52A4014BD78F039C44740	Gablonzer Hütte	4825 Gosau-Hintertal, Oberösterreich, Austria
9	0	0101000020E6100000202F5A3629BF3740D489BAC5B2144340	Katafygio «Flampouri»	136 72 Acharnes, Attica region, Greece
10	0	0101000020E6100000103E4BA24D3F2B40F731169C1AC04740	Simonyhütte	4830 Hallstatt, Oberösterreich, Austria
11	0	0101000020E610000033190145D5182740BF9048EBDFA04740	Vinzenz-Tollinger-Hütte	6060 Hall in Tirol, Tyrol, Austria
12	0	0101000020E61000001F1E0B5901B82E4091BFCBF1EAB34740	Ottokar-Kernstock-Haus	8600 Bruck an der Mur, Steiermark, Austria
13	0	0101000020E610000018E4FB977DBF2A40D6A3B4422D754740	Reisseckhütte	9814 Mühldorf, Mölltal, Kärnten, Austria
14	0	0101000020E61000007B116DC7D4A52540C0401020436D4740	Vernagthütte	Austria
15	0	0101000020E6100000286211C30EF323407EC9C6832D884740	Wormser Hütte	Austria
16	0	0101000020E6100000999CDA19A60E24406CD097DEFEA04740	Biberacher Hütte	Austria
17	0	0101000020E610000007BC276AC4133740DDF934DDA1A84440	Katafygio «1777»	620 55 Kerkini, Central Macedonia region, Greece
18	0	0101000020E6100000D5AF743E3C0B2A40E6E786A6EC704840	Hochwaldhütte	Germany
19	0	0101000020E6100000C2FBAA5CA8EC19408FC536A968544940	Kölner Eifelhütte	Germany
20	0	0101000020E6100000323CF6B358D223401763601DC7794740	Madrisahütte	Austria
21	0	0101000020E6100000313F373465472640CDC98B4CC07F4740	Dresdner Hütte	Austria
22	0	0101000020E6100000CDCCCCCCCC6C24403E07962364A84740	Fiderepasshütte	Germany
23	0	0101000020E6100000B727486C77172440A9DDAF027C9B4740	Göppinger Hütte	Austria
24	0	0101000020E6100000A379008BFC622340C7629B54348A4740	Oberzalimhütte	Austria
25	0	0101000020E610000013B70A62A0932740B3B45373B99D4740	Rastkogelhütte	Austria
26	0	0101000020E61000009D2D20B41E0E2440D54F49E70DC24740	Ansbacher Skihütte im Allgäu	Germany
27	0	0101000020E610000009E066F16249244097E13FDD408F4740	Kaltenberghütte	Austria
28	0	0101000020E61000000AD7A3703D0A2640E277D32D3B944740	Schweinfurter Hütte	Austria
29	0	0101000020E61000006DC438245A213640DA172BC5E9574340	Katafygio «Vardousion»	330 53 Delphi, Central Greece region, Greece
30	0	0101000020E6100000630F270F8F472D40336D62F5852D4740	Kocbekov dom na Korošici	3334 Luče, Mozirje, Slovenia
31	0	0101000020E6100000D1F5D08072062D40D25C9F20CE114740	Planinski dom Rašiške cete na Rašici	1211 Ljubljana, Šmartno, Slovenia
32	0	0101000020E6100000F70F966F85592C40971550C935374740	Prešernova koca na Stolu	4274 Žirovnica, Slovenia
33	0	0101000020E6100000AA5C8F5FCB372E408E6CD71919184740	Planinski dom na Mrzlici	3302 Griže, Slovenia
34	0	0101000020E6100000651A4D2EC6802C40577A6D3656FC4640	Koca na Planini nad Vrhniko	1360 Vrhnika, Slovenia
35	0	0101000020E6100000245DF94DDD322C4077DAB7E6D0144740	Zavetišce gorske straže na Jelencih	0, -, Slovenia
36	0	0101000020E6100000313F3734656F2E406F7F2E1A32264740	Planinski dom na Gori	Šentjungert, 3310 Žalec, Slovenia
37	0	0101000020E610000098F2E7FC90A22B40C7CBA2C928274740	Bregarjevo zavetišce na planini Viševnik	4265 Bohinjsko jezero, Slovenia
38	0	0101000020E610000091860959CC862B401635F33FD4244740	Koca pod Bogatinom	4265 Bohinjsko jezero, Slovenia
39	0	0101000020E6100000678B3942E5992B40007F639573334740	Pogacnikov dom na Kriških podih	5232 Soca, Slovenia
40	0	0101000020E610000008F580BBE4CC2D402A9C0F95E7344740	Dom na Smrekovcu	3325 Šoštanj, Slovenia
41	0	0101000020E610000073F6CE68AB32194060E811A3E77C4640	Refuge Du Chatelleret	38520 Saint Christophe En Oisans, Isère, France
42	0	0101000020E610000084622B685AF218408177F2E9B16B4640	Refuge De Chalance	5800 La Chapelle En Valgaudemar, Hautes-Alpes, France
43	0	0101000020E6100000963D096CCE711940AE7FD767CE6A4640	Refuge Des Bans	5290 Vallouise, Hautes-Alpes, France
44	0	0101000020E6100000DEAB5626FC52DBBFAED689CBF16A4540	Refuge De Pombie	65400 Laruns, Pyrénées-Atlantiques, France
45	0	0101000020E6100000A69C2FF65E7CD2BFA9F92AF9D86D4540	Refuge De Larribet	65400 Arrens, Marsous, Hautes-Pyrénées, France
46	0	0101000020E61000009CA6CF0EB84E1B401232906797C34640	Refuge Du Mont Pourri	73210 Peisey Nancroix, Savoie, France
47	0	0101000020E6100000C712D6C6D8E91A40BF81C98D222D4740	Refuge De La Dent D?Oche	74500 Bernex, Haute-Savoie, France
48	0	0101000020E6100000BEBDCA2243F820405620D41E27544740	Bergseehütte SAC	Uri, Switzerland
49	0	0101000020E6100000CDD5732CA96D1E40F591820D5C054740	Bivouac au Col de la Dent Blanche CAS	Wallis, Switzerland
50	0	0101000020E610000060F1FE571F0C2140D6BA5B328C564740	Salbitschijenbiwak SAC	Uri, Switzerland
51	0	0101000020E610000084EAC5BE53052140F224048A5C664740	Spannorthütte SAC	Uri, Switzerland
52	0	0101000020E6100000827FB24EBCB71E406113E452EB0C4740	Cabane Arpitettaz CAS	Wallis, Switzerland
53	0	0101000020E61000008A75AA7CCF48E4BF588BF447BD614540	Refugio De Lizara	22730, Aragón, Spain
54	0	0101000020E6100000AE56C01909F8E43F58DB5E1CA6064540	Albergue De Montfalcó	22585 Tolva, Aragón, Spain
55	0	0101000020E61000000A4CFFBF1E610AC08B780953B6904240	El Molonillo/Peña Partida	18160 Güejar Sierra, Andalucía, Spain
56	0	0101000020E610000029110100A92D0AC0F39F054F27844240	La Campiñuela	18417 Trévelez, Andalucía, Spain
57	0	0101000020E61000008E79782A3BCC3440BEAE152301FF4440	Titov Vrv	Tetovo, Municipality of Tetovo, North Macedonia
58	0	0101000020E6100000A2EC2DE57C212B40C7F143A5113D4540	Rifugio Franchetti	Pietracamela, Abruzzo, Italy
59	0	0101000020E610000052E2299ABDFA2840518B1C7D27114740	Rifugio Semenza	Tambre, Veneto, Italy
60	0	0101000020E6100000A197F67244A31F40313D06D094EE4640	Rifugio Città di Mortara 	Alagna Valsesia, Piemonte, Italy
61	0	0101000020E61000006E39F29B1D242040AB1ED555260C4740	Rifugio Andolla	Antrona Schieranico, Piemonte, Italy
62	0	0101000020E61000000AD80E46ECAB2440B70BCD751AFF4540	Rifugio Forte dei Marmi	Stazzema, Toscana, Italy
63	0	0101000020E6100000A88B14CAC2CF284038D66AB4C1504740	Rifugio Berti	Comelico Superiore, Veneto, Italy
64	0	0101000020E610000071B43E4052BB2B406FE70CD649CF4640	Rifugio Premuda	San Dorligo della Valle, Friuli Venezia Giulia, Italy
65	0	0101000020E61000006CCF2C0950C32240191BBAD91FF84640	Rifugio Elisa	Mandello del Lario, Lombardia, Italy
66	0	0101000020E6100000A5BDC11726B31F40F90FE9B7AFFB4640	Rifugio CAI Saronno	Macugnaga, Piemonte, Italy
67	0	0101000020E610000098DD9387857A2640A930B610E4584740	Rifugio Picco Ivigna	Scena, Trentino Alto Adige, Italy
68	0	0101000020E61000003AE97DE36B8F1C404AEF1B5F7B8A4640	Rifugio Toesca	Bussoleno, Piemonte, Italy
69	0	0101000020E6100000A913D044D8E02040382D78D1570C4740	Rifugio Al Cedo	Santa Maria Maggiore, Piemonte, Italy
70	0	0101000020E6100000449D5ECE11661F4009ED8B3A29F34640	Capanna Gnifetti	Gressoney La Trinitè, Valle d?Aosta, Italy
71	0	0101000020E6100000B8AE9811DE3E1E403A048E041AFC4640	Rifugio Aosta	Bionaz, Valle d?Aosta, Italy
72	0	0101000020E6100000BBB31B22135525408EA8F523EA374740	Rifugio Cevedale	Pejo, Trentino Alto Adige, Italy
73	0	0101000020E61000000D33349E08722340F0A485CB2A204740	Rifugio Ponti	Val Masino, Lombardia, Italy
74	0	0101000020E6100000C46D7E0DD2B125405364085B47134740	Rifugio XII Apostoli	Stenico, Trentino Alto Adige, Italy
75	0	0101000020E61000009F1C058882591B40DDD1FF722DE24640	Rifugio Elisabetta Soldini	Courmayeur, Valle d?Aosta, Italy
76	0	0101000020E610000061D57994804F25409903A4C1291F4740	Rifugio Denza	Vermiglio, Trentino Alto Adige, Italy
77	0	0101000020E61000000C1F115322F92A40338AE596560F4540	Rifugio Fonte Tavoloni 	Ovindoli, Abruzzo, Italy
78	0	0101000020E610000037C2A2224EBF2840F2ED5D83BE4E4740	Rifugio Carducci	Auronzo di Cadore, Veneto, Italy
79	0	0101000020E61000006FA53220D64E26400DE02D90A0044740	Rifugio Bindesi	Trento, Trentino Alto Adige, Italy
80	0	0101000020E610000001C11C3D7ECB2D40C670D0B9365A4640	Mountain hut Miroslav Hirtz	53287 Jablanac, Ličko-senjska županija, Croatia
81	0	0101000020E6100000398485EEED352C4098331D324C154740	Koca na Blegošu	4224 Gorenja vas, Slovenia
82	0	0101000020E610000040F850A225BF1F400F441669E2594940	Wittener Hütte	Germany
83	0	0101000020E610000000FDBE7FF3AA25409A99999999694740	Hochjoch-Hospiz	Austria
84	0	0101000020E6100000D7A02FBDFD412640CDCCCCCCCCB44740	Meilerhütte	Germany
85	0	0101000020E610000050C422861DA628406E85B01A4BC64740	Gaudeamushütte	Austria
86	0	0101000020E6100000179CC1DF2F961940D5EB1681B15C4940	Rheydter Hütte	Germany
87	0	0101000020E6100000FB66518EB8562C4057E883656C744940	Sektionshütte Krippen	Germany
88	0	0101000020E61000001F7A839D234C2C40B45EF68814A34740	Neunkirchner Hütte	2620 Neunkirchen, Steiermark, Austria
89	0	0101000020E61000009CE379FC2043E7BF8FC536A9682C4540	Refugio De Riglos	22808, Aragón, Spain
90	0	0101000020E6100000563D4FC4941A2140EBB308E997564740	Salbithütte SAC	Uri, Switzerland
91	0	0101000020E61000001D55C855B23A2040B8EB64DCCE424740	Finsteraarhornhütte SAC	Wallis, Switzerland
92	0	0101000020E6100000DEFD765E1AE71D4038777A52B2FE4640	Cabane des Vignettes CAS	Wallis, Switzerland
93	0	0101000020E6100000E769EE0B84312040FBE19FAF02504740	Glecksteinhütte SAC	Bern, Switzerland
94	0	0101000020E6100000752B5D3C5F152240D9971BDB51454740	Länta-Hütte SAC	Graubünden, Switzerland
95	0	0101000020E610000055ADDEFA26292040BAB9F14860214740	Monte-Leone-Hütte SAC	Wallis, Switzerland
96	0	0101000020E6100000557F0CE8F9C222408F373B25D26E4740	Ringelspitzhütte SAC	Graubünden, Switzerland
97	0	0101000020E6100000A4AA09A2EE0334408E23D6E253104640	Na poljanama Maljen	Maljen, Serbia
98	0	0101000020E6100000A9DE1AD82A313440C5E6E3DA50114640	Dobra voda	Suvobor, Serbia
99	0	0101000020E61000007250C24CDBFF2E402D095053CBC64640	Ivanova hiža	Karlovac town environment, Karlovačka, Croatia
100	0	0101000020E6100000C6DCB5847CC02F40C746205ED7EB4640	Glavica	Medvednica, City of Zagreb, Croatia
101	0	0101000020E6100000FFEC478AC8B83040D3F6AFAC34BD4540	Trpošnjik	Mosor, Splitsko-dalmatinska, Croatia
102	0	0101000020E6100000C217265305932D40C4CE143AAFA54640	Bitorajka	Bitoraj, Primorsko-goranska, Croatia
103	0	0101000020E6100000AB09A2EE0360304006D847A7AE084640	Zlatko Prgin	Dinara, Šibensko-kninska, Croatia
104	0	0101000020E6100000D3872EA86F492E405C8FC2F528444640	Prpa	Velebit, Ličko-senjska, Croatia
105	0	0101000020E6100000787FBC57AD5C2E408BFD65F7E43D4640	Ždrilo	Velebit, Ličko-senjska, Croatia
106	0	0101000020E610000086032159C0F42D40B21188D7F59B4640	Miroslav Hirtz	Velika Kapela, Primorsko-goranska, Croatia
107	0	0101000020E6100000A31EA2D11DAC3140462575029AC04640	Jezerce	Papuk, Požeško-slavonska, Croatia
108	0	0101000020E61000003EE8D9ACFA4C2F405F0CE544BBE24640	Ivica Sudnik	Samoborska gora, Zagrebačka, Croatia
109	0	0101000020E6100000AD3BCC4D8A7D2840CBDF185D39124640		58 Rotonda Greppi, Sesto Crescente sardo, Italy
110	0	0101000020E6100000AF5E454607602340EDF2AD0FEB6B4440		9 Via Gianluigi, Gioia terme, Italy
111	0	0101000020E610000050BA3EBD63AA2840D5DBB0B7DE294640		4 Borgo Rubino, Mamante terme, Italy
112	0	0101000020E6100000E7204322C8042640F6AEE6A507F54540		7 Piazza Bevilacqua, Orio terme, Italy
113	0	0101000020E61000009F11B6E919B02140ABAC12D154364640		2 Borgo Quiteria, Quarto Albrico, Italy
114	0	0101000020E61000009EBFBFF7ED2224402DAAEA8ABEE84640		748 Via Brunetti, Evola salentino, Italy
115	0	0101000020E6100000FF209221C76E274017844DF8002D4640		708 Borgo Adelaide, Gino nell'emilia, Italy
116	0	0101000020E6100000C2B28817FA8E2340D5809C8B1AB04640		7 Rotonda Balistreri, Settimo Nino, Italy
117	0	0101000020E6100000107BFC3960762540600A6A53D0274740		810 Borgo Parmenio, Borgo Alceste, Italy
118	0	0101000020E6100000CF5AC0BAE0462B40B9ED314745E34640		0 Strada Selene, Quarto Gianpaolo, Italy
119	0	0101000020E610000048B42E7FCFC525403379B93E620B4740		358 Piazza Natali, Rauso umbro, Italy
120	0	0101000020E6100000E066F16261B42A4084E85AC52CF04640		772 Borgo D'Avino, Toti ligure, Italy
121	0	0101000020E610000021263CFC90E62840C604EBEEF0074640		17 Piazza Tumino, Falbo lido, Italy
122	0	0101000020E6100000CFB81567B161274070CFF3A78DA74640		75 Rotonda Melania, Giambattista calabro, Italy
123	0	0101000020E6100000C1F979F8D76F224054F0CAE48AB04640		8 Piazza Asaro, Settimo Marana lido, Italy
124	0	0101000020E61000008248D0A975782B40741200D2EDC94640		35 Incrocio Fiammetta, Filipponi lido, Italy
125	0	0101000020E6100000918B208436172940630E828E564E4540		58 Rotonda Matera, Sesto Godiva veneto, Italy
126	0	0101000020E610000023484A1F5F572240D37CDF09072C4640		432 Via Surano, Sesto Efrem, Italy
127	0	0101000020E6100000A09339F130542140F7DBE8ADCB384740		409 Via Di Iorio, Selene ligure, Italy
128	0	0101000020E6100000068A0E37967A2540DB1FDE29D3664540		6 Piazza Sofia, Borgo Giuseppa del friuli, Italy
129	0	0101000020E6100000CF59B09EA4CE2640F18288D4B4434740		62 Piazza Teodoro, Metello ligure, Italy
130	0	0101000020E6100000C153C8957A5A26407541D8840FE14640		5 Via Claudio, Esuperio sardo, Italy
131	0	0101000020E61000008577B988EF302140BAD3426E2B3D4740		1 Contrada Licata, Lana calabro, Italy
132	0	0101000020E6100000589643E6259E2540B49487E013DD4540		4 Contrada Filomeno, Valenti laziale, Italy
133	0	0101000020E6100000249E4720B9702840B1F84D61A5124640		82 Borgo Grimaldo, Quarto Birino del friuli, Italy
134	0	0101000020E61000008B89CDC7B55926407EB4EED57D084740		96 Rotonda Erasmo, Sesto Landolfo, Italy
135	0	0101000020E6100000D8B969334EEB27402CF8C84164804540		69 Via Acario, Borgo Amaranto, Italy
136	0	0101000020E610000061D394AEAAD4204012A6835039FC4640		418 Borgo Di Blasi, Abbondio veneto, Italy
137	0	0101000020E6100000B53C6AA741AC27408F0134A550B84640		1 Strada Silvano, Concas calabro, Italy
138	0	0101000020E6100000F78CE9AE91D52240ED48F59D5FE54640		679 Via Biagetti, Settimo Porzia, Italy
139	0	0101000020E6100000626DE75663902B4097FA1E9A1ED44640		40 Rotonda Catania, Sesto Savina terme, Italy
140	0	0101000020E6100000FFF9C78C011B2640DD706946501E4740		09 Rotonda Isotta, Pizzitola ligure, Italy
141	0	0101000020E61000009C363EEEB67E2740BC2363B5F9BA4640		256 Borgo Azelio, Fabrizi a mare, Italy
142	0	0101000020E61000008A9466F3387C1E402B31CF4A5AE74640		5 Rotonda Mancuso, Settimo Tiziano, Italy
143	0	0101000020E6100000F22895F084D22A404082870E26ED4440		144 Borgo Leale, Borgo Pia salentino, Italy
144	0	0101000020E61000007E1D386744712240C878399105CC4640		94 Strada Marchetto, Urdino calabro, Italy
145	0	0101000020E610000020D84C1993812240A475AFEEB30D4740		74 Piazza Fulgenzio, Eligibile laziale, Italy
146	0	0101000020E6100000242136FD7E2E26406E2AF7A7F91A4740		74 Rotonda Castellani, Quarto Gandolfo sardo, Italy
147	0	0101000020E6100000485E8C37E8B927408860C1A2C7CA4640		7 Contrada Ester, Egisto calabro, Italy
148	0	0101000020E61000005E961BB1BB751E407379BD4571EF4640		905 Borgo Di Francesco, Ladislao laziale, Italy
149	0	0101000020E6100000BE2ABC708CED2340366964A1E7DD4640		271 Via Muratore, Quarto Costantino, Italy
150	0	0101000020E610000053B4722F302B2540E4DC26DC2B4D4740		8 Incrocio Danio, Orazio umbro, Italy
151	0	0101000020E61000009A97C3EE3B32254052B241CB5F574640		38 Incrocio Mazzini, Cangiano umbro, Italy
152	0	0101000020E6100000622D3E05C0782840F70BD17C29DE4640		291 Rotonda Merli, Quarto Quintilio nell'emilia, Italy
153	0	0101000020E6100000B05758703F782440773A4668BAB84640		5 Rotonda Drago, San Evandro, Italy
154	0	0101000020E610000011D20957F63B2640E6B8AEF3CA084740		699 Borgo Tufano, Rolando veneto, Italy
155	0	0101000020E61000004704E3E0D2692C408514F2F741A74640		8 Via Cerrani, Sesto Taziano lido, Italy
156	0	0101000020E61000002F0ACC54D2C8264038FE9F1E36CA4640		3 Rotonda Natale, Quarto Dione, Italy
157	0	0101000020E610000046E80C31035E29405A46EA3D95E54640		00 Piazza Gioacchino, Settimo Agapito veneto, Italy
158	0	0101000020E6100000E4F90CA8376B2340ABA3F496BC5E4440		5 Contrada Ippocrate, Sesto Regolo laziale, Italy
159	0	0101000020E6100000967DB2BD71ED26406F7319EDA7C14640		33 Incrocio Manna, Dina sardo, Italy
160	0	0101000020E6100000FC68DDABFB5427401073EE1B04334740		3 Via Puccio, Settimo Roberto sardo, Italy
161	0	0101000020E610000069965F611C5B2540B52792F991CA4540		2 Via Rolfo, Quarto Pusicio calabro, Italy
162	0	0101000020E6100000B4C6455ACF692740D8C523A765B04640		958 Piazza Affinito, Evodio nell'emilia, Italy
163	0	0101000020E61000003B843B61D3CC1E40935742D202D44640		3 Borgo Furseo, Ambrosini sardo, Italy
164	0	0101000020E6100000C03FA54A9455284094347F4C6BE54640		1 Borgo Norina, Annabella lido, Italy
165	0	0101000020E610000003FBF900EEEB1E40FA6184F068EE4640		878 Incrocio Ermenegilda, Piccoli nell'emilia, Italy
166	0	0101000020E610000007681140209E2640B177352F3D9D4640		22 Contrada Caccamo, Sinopoli veneto, Italy
167	0	0101000020E6100000525F96766AFE23402A7C6C81F3EE4640		63 Borgo Capogna, Coreno lido, Italy
168	0	0101000020E61000007319EDA7B5EF1E400B1060EC18EC4640		4 Borgo Aureliano, Spano a mare, Italy
169	0	0101000020E6100000F86B578DCA1A284015E06014A9B14640		5 Piazza Quaglia, Lenzi a mare, Italy
170	0	0101000020E6100000D634947FD2A12740811A081390584540		79 Incrocio Maruta, Benvenuti lido, Italy
171	0	0101000020E61000009D63E53C08EA2640B7FB0BF3D4DC4540		27 Via Elita, Restivo ligure, Italy
172	0	0101000020E6100000EA0E18DAEF9B2B40948444DAC6764640		38 Borgo Mori, Emilio nell'emilia, Italy
173	0	0101000020E610000014BCD7FFEFC62640BA66F2CD36DE4640		0 Contrada Scotti, Quarto Ilda ligure, Italy
174	0	0101000020E610000009168733BFBE27405D4E098849354540		490 Incrocio Giosuele, Borgo Frido salentino, Italy
175	0	0101000020E6100000462AE7E6763A2940ABB8CC446CE14440		5 Via Tancredi, San Fortunato, Italy
176	0	0101000020E610000075EED176A7F62640A7F97486F3B24640		0 Piazza Crescenzia, Patrizia veneto, Italy
177	0	0101000020E6100000F9A23D5E48F727405789C3E3ECE04640		78 Rotonda Annamaria, Belli a mare, Italy
178	0	0101000020E6100000731A587D64FD294065FED13769E64540		8 Via Melitina, Settimo Lisandro laziale, Italy
179	0	0101000020E6100000ABC5F18D322421407D1FB3582FFA4640		98 Via Boi, Borgo Marinella veneto, Italy
180	0	0101000020E610000035D252793B0228403A79ECC26AEA4640		7 Strada Benedetto, Settimo Damocle, Italy
181	0	0101000020E6100000DD730580CFD02640F16261889CD44640		004 Piazza Montesano, Palmisano terme, Italy
182	0	0101000020E61000006531564046E12040530E1C8645E74640		899 Contrada Zenone, Eliodoro del friuli, Italy
183	0	0101000020E610000026B8A2DE9D5E2740311A434AFDDC4640		869 Rotonda Delogu, Braia veneto, Italy
184	0	0101000020E61000000A5BFD22B27524407121EA99B95B4640		90 Incrocio Brando, Rutilo calabro, Italy
185	0	0101000020E6100000C132DBBA40CE2240D0EFFB372F274740		72 Borgo Zefiro, Settimo Pollione nell'emilia, Italy
186	0	0101000020E6100000CA558737C6B91F40EB79ED88F9BD4640		7 Incrocio Barnaba, Crispino sardo, Italy
187	0	0101000020E61000006AEE320DD4F324401D098F9147B14640		277 Via Pasquale, Olinda veneto, Italy
188	0	0101000020E610000044053D8A291B2140F0FACC599F5A4440		33 Rotonda Altieri, Leopardo terme, Italy
189	0	0101000020E61000002B1D07B9E6212040F08C11E4FBF04640		3 Rotonda Floriana, Quarto Everardo salentino, Italy
190	0	0101000020E61000007BEDE3B21BB727403464E190B2DD4640		80 Rotonda Puglisi, San Quintiliano, Italy
191	0	0101000020E6100000D8E9ACBB1EE91F40A0A932E774D04640		33 Rotonda Spadoni, Vanna veneto, Italy
192	0	0101000020E61000009C8136DEC21B294063731FCA61894540		910 Borgo Sabazio, Bartolomeo ligure, Italy
193	0	0101000020E6100000E3B08FA91680204076A0F3BF01E94640		3 Piazza Morgana, Sesto Aleandro, Italy
194	0	0101000020E6100000EE6EAF16E9832340C6F0225D7DCC4640		7 Strada Benigno, Settimo Alcide laziale, Italy
195	0	0101000020E6100000D81D41E037B02140C2F1214D61C54440		08 Rotonda Pipitone, Bosco laziale, Italy
196	0	0101000020E6100000A807BB174E80284061BC8B9C2AD94640		765 Contrada Santarsia, Borgo Olimpio, Italy
197	0	0101000020E6100000FD18CE9085A322406C9CA80073DB4640		1 Rotonda Rambaldi, Elifio laziale, Italy
198	0	0101000020E6100000E39F635122672540E113A1C7DEDE4640		73 Contrada Melissa, Riccardi terme, Italy
199	0	0101000020E610000098231A93B47928409916500361674640		491 Strada Abramio, Bonanno calabro, Italy
200	0	0101000020E6100000ABBCD3539A032740A544B7031AEF4640		79 Rotonda Amata, Borgo Cleonico, Italy
201	0	0101000020E61000001E424B0D239B2440D8D1DD1A7DA04640		97 Borgo Ruotolo, Modesto lido, Italy
202	0	0101000020E6100000CF2CAE96E0891F405EB642FDD3234640		863 Contrada Arcibaldo, Sireno salentino, Italy
203	0	0101000020E6100000D7BDBACF96BC254007205AD020C34640		5 Strada Reginaldo, Borgo Platone, Italy
204	0	0101000020E6100000C96BCABA24832740A97E4A3A6FE54640		9 Contrada Venustiano, Borgo Verena ligure, Italy
205	0	0101000020E6100000A8DAB80F8AC32940DF67017F9D1A4540		295 Strada Marinucci, Sesto Aronne ligure, Italy
206	0	0101000020E6100000C272DFC556972640A4271BC528D24640		016 Via Liboria, Quarto Nicezio, Italy
207	0	0101000020E61000005F306E5974411E40EC3F21F1E13A4740		15 Piazza Gosto, Borgo Verdiana, Italy
208	0	0101000020E61000006C109CE9142628401760C4E347124740		5 Piazza D'Amico, Sesto Zefiro, Italy
209	0	0101000020E610000044EC0214D9FD284012AC600AC5EE4440		120 Via Cristoforo Colombo, Roma, Italy
210	0	0101000020E6100000B0FECF61BEF827406DFD99E6C2F24640		594 Borgo Casali, Lucarini nell'emilia, Italy
211	0	0101000020E6100000EBB76576CCAF26407B8FE9BFBD424640		842 Borgo Faraone, Tedde sardo, Italy
212	0	0101000020E6100000D6479682247220407379BD4571084740		5 Borgo Sparacino, Borgo Bruto laziale, Italy
213	0	0101000020E610000097900F7A36872040AB251DE560074740		127 Piazza Gianni, Quarto Guido, Italy
214	0	0101000020E61000000DABD3DC65C22740D32F116F9DE34640		467 Contrada Gumesindo, Cacciapuoti umbro, Italy
215	0	0101000020E61000009FEE97AA0FCF27402834FF9E0E024740		38 Via Evandro, Erico veneto, Italy
216	0	0101000020E6100000E417B90265622C40EFC0A50815E24440		14 Borgo La Monaca, Sesto Aurelia, Italy
217	0	0101000020E6100000B2463D44A37B2540F3C011EEDF764540		242 Borgo Bortolo, Lautone lido, Italy
218	0	0101000020E6100000B6B0B84956A326409DC2A5BE87334740		95 Rotonda Igino, Nava umbro, Italy
219	0	0101000020E6100000D56C2FB319AD2840823C16365EC04640		51 Piazza Lo Bianco, Rampazzo salentino, Italy
220	0	0101000020E610000076583C5002EE1E40E0CCF9731BE14640		140 Incrocio Otilia, Sesto Cleandro a mare, Italy
221	0	0101000020E6100000470EC7A98CC52840B6A73F564BE04640		054 Incrocio Remigio, Iorio del friuli, Italy
222	0	0101000020E61000004DC00A4B97B91F4005C1E3DBBBF84540		0 Piazza Carriero, Sidonia lido, Italy
223	0	0101000020E610000059EB7A585E182740106D1162780E4640		2 Contrada Zanella, Settimo Flavia, Italy
224	0	0101000020E610000051D9B0A6B2581F4089B7CEBF5DE14640		93 Strada Di Costanzo, Quarto Melissa, Italy
225	0	0101000020E6100000AD7603BB504F27406049A8CFC4374640		319 Strada Laura, Benvenuto terme, Italy
226	0	0101000020E61000004692C5A28EF72640D32934B511794640		1 Strada Ciro, Sesto Olga calabro, Italy
227	0	0101000020E6100000068B790C45182740C3CB1D47BD774640		921 Contrada Macrì, San Gualberto sardo, Italy
228	0	0101000020E61000005CC0159A35C620401880A1A245F44640		75 Via Giocondo, Settimo Bardomiano nell'emilia, Italy
229	0	0101000020E6100000FA2D9512DD7227409453967C47234640		23 Borgo Migliore, Criscenti veneto, Italy
230	0	0101000020E61000008ECD8E54DFA12B403562C1583A2D4540		7 Piazza Beltrame, Settimo Viliana, Italy
231	0	0101000020E610000020651FBF127F254034C06092257F4640		486 Rotonda Ianni, Melezio ligure, Italy
232	0	0101000020E610000064BB31F3D36E22404F401361C3C24640		99 Incrocio Vincenza, San Aida laziale, Italy
233	0	0101000020E6100000D160AEA0C47E2240E41824D813C04640		70 Strada Pavone, San Diocleziano laziale, Italy
234	0	0101000020E61000006FD8B628B3B91E40086465EA64D64640		009 Incrocio Gerolamo, Giorgio laziale, Italy
235	0	0101000020E610000016CDB9CAC93E2140BC0E8B074A744640		04 Incrocio Morini, Borgo Geronzio sardo, Italy
236	0	0101000020E6100000B4064A65E54A274026DAFA8E86E14640		58 Rotonda Ildegarda, Quarto Pippo, Italy
237	0	0101000020E61000000736F80CF26822405273034F6B9C4640		22 Contrada Nerea, Quarto Ada, Italy
238	0	0101000020E6100000DF6124C511412140D11CFE3FF3744640		4 Piazza Edilberto, Sesto Francesca, Italy
239	0	0101000020E610000077ED77CD50412140CB243493B9744640		2 Piazza Di Natale, Leoni salentino, Italy
240	0	0101000020E61000002E008DD2A5032D406B5CA4F55C204540		604 Rotonda Celeste, Calligaris salentino, Italy
241	0	0101000020E61000004ED367075C6F1F403A57941282D64640		166 Rotonda Alviero, Dante laziale, Italy
242	0	0101000020E61000006405BF0D316E1F409F07D22060D24640		87 Incrocio Bernardini, San Orchidea umbro, Italy
243	0	0101000020E61000006F4BE482334C2740A928A8F287304640		1 Via Valsecchi, Borgo Manetto sardo, Italy
244	0	0101000020E61000005BC52CC59F522B40DB68A5B50EFA4640		10 Contrada De Napoli, Bionaz nell'emilia, Italy
245	0	0101000020E61000000D5F155E383A21402BCC310F4F724640		9 Piazza Egle, Sesto Irene, Italy
246	0	0101000020E6100000E04158326C5D2140821C9430D3704640		968 Via Narciso, Cinelli del friuli, Italy
247	0	0101000020E6100000C1F979F8D7071F404EFA319C21CD4640		928 Incrocio Pantaleo, Mazzoleno nell'emilia, Italy
248	0	0101000020E61000000C97B0917F3921404C9C267D6B734640		838 Piazza Igino, Zaccaro terme, Italy
249	0	0101000020E6100000EFA18ED838742840FA10AF46D1764640		9 Via Argiolas, Folco salentino, Italy
250	0	0101000020E6100000B032BF3F4AC11E4019CD25B094D54640		011 Borgo Mazzoleno, Sesto Isidoro, Italy
251	0	0101000020E610000039FBB9579CA829401D9C3EF152FC4440		09 Incrocio Leoncini, Porfirio laziale, Italy
252	0	0101000020E6100000440E5BC4C1F71E4071033E3F8C7E4640		453 Borgo Torquato, Garifo calabro, Italy
253	0	0101000020E6100000C69EE2DD36D82B400B8AD5D5D3E84640		793 Incrocio Basile, Sesto Alboino salentino, Italy
254	0	0101000020E6100000888961E2EA131F4040E7244A31CD4640		8 Via Salvi, Sesto Angela, Italy
255	0	0101000020E6100000E8F86871C6D81E40E7EBE86E8DD84640		7 Via La Rosa, Borgo Gennaro, Italy
256	0	0101000020E610000024BF34FBF2301F405FCE6C57E8CB4640		0 Incrocio Manica, Settimo Stiliano umbro, Italy
257	0	0101000020E61000000242902859C7254075988AE832F64540		1 Via Franchi, Duccio laziale, Italy
258	0	0101000020E61000005CEC5113D8AF1E405650ACAE9ED84640		04 Contrada Olivieri, Bini del friuli, Italy
259	0	0101000020E6100000A6A84423E9E41E40BF20336145E14640		137 Contrada Quinziano, Livio lido, Italy
260	0	0101000020E6100000F07A7AB6582B2740B1ADFAB726234640		80 Piazza Bardo, De Bona laziale, Italy
261	0	0101000020E61000002252D32EA6C91E404392B47636E94640		153 Strada Saia, Quarto Cloe nell'emilia, Italy
262	0	0101000020E61000000BC336983C2C27405262D7F676234640		65 Via Castiglioni, Settimo Aloisio veneto, Italy
263	0	0101000020E61000004F722C94F1E8264075F2D885D5064740		0 Incrocio Afro, Borgo Coriolano laziale, Italy
264	0	0101000020E61000005C8BBBE6FA8F26407A4F8AFB343B4740		095 Incrocio Gianuario, Artemisa lido, Italy
265	0	0101000020E61000007B9054956C0B28407BB5487FD4974640		4 Contrada Andrisani, Sesto Gioacchina nell'emilia, Italy
266	0	0101000020E6100000BE52F1DA00B72B40D21D1F8887274540		423 Via Guiberto, Pesaresi lido, Italy
267	0	0101000020E6100000A732D6485C052740FDD8243FE2394640		02 Via Tarquinia, Ivetta calabro, Italy
268	0	0101000020E6100000AD94545C0B4D2240EE885462E8B94640		73 Strada Surace, Di Gaetano veneto, Italy
269	0	0101000020E6100000333097F9B3641F40983BE93356DF4640		964 Rotonda Moser, Quarto Tammaro, Italy
270	0	0101000020E61000002B8AB2124E762740C1EA234B41314640		64 Incrocio Gianmarco, Delle Monache umbro, Italy
271	0	0101000020E6100000905F8951219022403E5695229E864640		8 Piazza Recchia, Sesto Aimone, Italy
272	0	0101000020E610000096C1621E43E92640E580B80611044740		496 Strada Antioco, Sesto Foca sardo, Italy
273	0	0101000020E61000007090B52B99842B40E461461DC27E4640		87 Piazza Mario, Quarto Verena veneto, Italy
274	0	0101000020E610000084B1CFAD219A26406BDECC43010E4740		1 Contrada Sosteneo, Di Luca umbro, Italy
275	0	0101000020E6100000CC1D47BDF13F2240A5A31CCC26824640		2 Rotonda Cesaretti, Pierro ligure, Italy
276	0	0101000020E610000048E58123DCFF26407F7E294D94084740		1 Borgo Sostene, Cappelli lido, Italy
277	0	0101000020E61000006B5A73918C1625409D7C1FB358204740		962 Strada Moffa, Borgo Alamanno del friuli, Italy
278	0	0101000020E6100000204F818241C01E40068B1E53D2D34640		21 Contrada Tralli, Ines umbro, Italy
279	0	0101000020E6100000C0CBB161F2931E40B859BC5818D34640		40 Contrada Giovanna, Emiliano nell'emilia, Italy
280	0	0101000020E610000070DA4246F68B2C40A79C8AAFD1364740		100 Incrocio Saracino, Bacco terme, Italy
281	0	0101000020E6100000A9D5FC9D92882C4058FBE02131384740		55 Strada Letterio, Settimo Ermanno salentino, Italy
282	0	0101000020E6100000F74A0FF91DD1274067DC8AB3D8024740		9 Contrada Edilberto, Settimo Rino salentino, Italy
283	0	0101000020E61000004221A7542EE52C40A39BB3F457164740		8 Via Bindi, Quarto Liberato, Italy
284	0	0101000020E6100000D3D7987C586422408E7CB9AA47A84640		5 Borgo Adamo, Borgo Elaide, Italy
285	0	0101000020E610000008CDAE7B2B8A2440E646EC6EF9664540		821 Rotonda Di Salvo, Sesto Penelope del friuli, Italy
286	0	0101000020E610000081EB8A19E1CD26408A4457D8C2194640		5 Strada Cortesi, Niccolai lido, Italy
287	0	0101000020E6100000B4CA4C69FD5122404A95CDC1D8134540		19 Piazza Furno, Alessia a mare, Italy
288	0	0101000020E6100000E4BD6A65C267264033260EEA6CBC4640		0 Incrocio Damiano, Turco umbro, Italy
289	0	0101000020E610000071C0536DDCD325406C312E0BDCB14640		5 Contrada Grazia, Eufrasia veneto, Italy
290	0	0101000020E6100000B368F0ADFEEA2540D42AFA4333B54640		495 Borgo Pianigiani, Bassiano umbro, Italy
291	0	0101000020E61000005B2CA0AB08EA2740DE454E15422C4740		469 Borgo Nicoletti, Carbon terme, Italy
292	0	0101000020E61000009703988D2933274052EC0D63778A4640		029 Via Monte Grappa, Lendinara, Italy
293	0	0101000020E61000005389FC44AF582940E7D2AEF83CCA4640		76 Incrocio Egger, Quarto Lamberto, Italy
294	0	0101000020E61000000236D6B441802C4025D5D237C46B4440		44 Via dei Greci, Napoli, Italy
295	0	0101000020E610000073220BE24DBC2740A1E4C40DAE2D4740		744 Piazza Ragusa, Quarto Teodata del friuli, Italy
296	0	0101000020E610000046B1DCD26AB02540072E45A808074740		80 Borgo Brigandì, Quarto Benedetto, Italy
297	0	0101000020E6100000B17E7DBE77992240C0F858B043504440		378 Strada Ulfo, Alice del friuli, Italy
298	0	0101000020E6100000EC3026FDBD2C27403B6AF1CE46024740		50 Incrocio Cerrani, Settimo Fiorenzo del friuli, Italy
299	0	0101000020E6100000996EC8F5A5712B40C576F700DD3C4740		567 Rotonda Pivetta, Pizzitola calabro, Italy
300	0	0101000020E6100000AA5DB818A8F922406B0DA5F622154440		19 Piazza Romeo, Settimo Ariosto a mare, Italy
301	0	0101000020E610000034B10AE58E682040CFC941BFA57A4440		066 Rotonda Regolo, Marciano veneto, Italy
302	0	0101000020E610000008D04AB5AABC2140800F5EBBB4374640		7 Piazza Smeralda, San Fabiana calabro, Italy
303	0	0101000020E6100000B35DA10F967D2D408F49905BDD324740		71 Piazza Lorena, Sesto Amanzio, Italy
304	0	0101000020E6100000852348A5D8C12840842458C114E24540		6 Piazza Sibilla, Ferrario ligure, Italy
305	0	0101000020E6100000BF5076E915252B40EA398EC4703B4740		28 Rotonda Ruotolo, San Ulrico laziale, Italy
306	0	0101000020E6100000B956D6917EDA2B40DF707A72A8054540		6 Borgo Paradiso, Quarto Fatima lido, Italy
307	0	0101000020E61000007889A02067742340DE2A3EF493CE4640		33 Borgo Zuliani, Settimo Ippocrate, Italy
308	0	0101000020E6100000235399BDC70C254059CFFF6101ED4540		9 Strada Odilia, Giannelli a mare, Italy
309	0	0101000020E610000027F33405D7392640E75E16C90D2C4740		30 Rotonda Lana, San Alice, Italy
310	0	0101000020E61000001C15EE4BECAC2A40DD11A9C4D02E4540		95 Piazza Renda, Borgo Gottardo, Italy
311	0	0101000020E6100000C1D4850E70E722408E6D63FDB0594540		81 Via Marrone, Sesto Iris calabro, Italy
312	0	0101000020E6100000E5BA849E28A826407E7D63BE723F4640		19 Piazza Moreno, Siro lido, Italy
313	0	0101000020E610000055B1E72109D11F4018CFA0A17FB14640		53 Piazza Maurizi, San Adelasia umbro, Italy
314	0	0101000020E61000007DEFCA89D18E2640DB0B16985F354540		20 Via Puddu, Settimo Ermenegilda, Italy
315	0	0101000020E6100000BB6D9516E41D244002678412C1A94640		7 Strada Algiso, Quarto Lucia, Italy
316	0	0101000020E6100000F67AF7C77BB52740FA449E245D4F4740		4 Rotonda Barsotti, Edvige umbro, Italy
317	0	0101000020E6100000DE68119BD960294098E8E225EEFB4440		13 Borgo Fadda, Perri lido, Italy
318	0	0101000020E61000007ED3AA4CE7E52340C9CC052E8F254640		66 Piazza Micheletti, Sesto Astrid, Italy
319	0	0101000020E61000004EDF217B732E2240D3F4D901D7214540		0 Via Leonardo, Bassiano del friuli, Italy
320	0	0101000020E61000004377A45588CA264008951348E43C4640		2 Borgo Maio, Lattanzi terme, Italy
321	0	0101000020E610000072593B40E6692840252D4B2A09EC4440		6 Rotonda Otilia, Settimo Indro veneto, Italy
322	0	0101000020E610000023E7B3F281D7214072C8618B38C84640		2 Piazza Pezzi, Settimo Federico ligure, Italy
323	0	0101000020E61000000C84AE8E2D752740A4897780272E4640		505 Via Grossi, Manuela lido, Italy
324	0	0101000020E6100000A63C5F58A33326408C811A63CCED4540		7 Via Fatima, San Macario, Italy
325	0	0101000020E6100000CC0C1B65FD922840A42C8DA905C14640		412 Strada Miceli, Paolo umbro, Italy
326	0	0101000020E61000007332CC64933F2740FEDDF1DC31254640		623 Piazza Fiorenza, Onorino del friuli, Italy
327	0	0101000020E610000032D758784D462240743F4C67CC0B4740		270 Via Di Tullio, Diodoro umbro, Italy
328	0	0101000020E61000002B16BF29ACC825401AB6775787864540		97 Contrada Virgilio, Volpe sardo, Italy
329	0	0101000020E6100000FE00B562C9B62A4032CFA51364D94440		06 Borgo Orazio, Sesto Lidio sardo, Italy
330	0	0101000020E61000002AD890C9F3362640A3C629DFD80F4640		96 Via Gualtiero, Basile laziale, Italy
331	0	0101000020E610000098F0958AD7422540F3DD52735E994640		11 Piazza Noemi, Sesto Rosa ligure, Italy
332	0	0101000020E6100000451B36806D772640B99BF1C7FE074740		774 Borgo Anna, Gagliardi nell'emilia, Italy
333	0	0101000020E61000008948A8740B9027402B7D321015F14540		94 Via Samona, San Fiorenza, Italy
334	0	0101000020E6100000484B8A3496612B40F1F44A5986DF4640		73 Rotonda Luisa, Sesto Salustio nell'emilia, Italy
335	0	0101000020E610000006240626DCE0264059631A97BBDC4640		8 Incrocio Betti, Borgo Telica veneto, Italy
336	0	0101000020E61000001A62067470422640EF6BC94F4FBD4540		35 Strada Carina, Rossetti del friuli, Italy
337	0	0101000020E6100000F0F1536694F425402F5D77A9C7134640		13 Incrocio Donda, Maruta umbro, Italy
338	0	0101000020E6100000A5DAA7E3317F2240E75E16C90DEF4640		28 Strada Giorgia, Galluzzo veneto, Italy
339	0	0101000020E6100000D12E956D967D2C40126C5CFFAE6D4440		8 Rotonda Ragusa, Quarto Varo sardo, Italy
340	0	0101000020E6100000DD6CBDF0941F27409F515F3BBDDA4640		384 Via Luchetti, Cosimo sardo, Italy
341	0	0101000020E610000096EA025E66002640FA4E82ED16F44540		8 Piazza Argimiro, Quarto Gaspare, Italy
342	0	0101000020E61000009DDE20B5E43C25407F83F6EAE39D4540		9 Incrocio Leonardi, Borgo Rossana, Italy
343	0	0101000020E6100000016E162F168E2340861BF0F9614A4440		31 Via Campisi, Quarto Alarico terme, Italy
344	0	0101000020E61000009F32480BE1EA20405C8A50114CDA4640		868 Contrada Tarso, San Azelia, Italy
345	0	0101000020E6100000618841052C422B400938DFE3A78E4640		58 Strada Decimo, Valeria lido, Italy
346	0	0101000020E6100000160F94803D132140276BD44334E04640		6 Rotonda Mazzotti, San Gallicano, Italy
347	0	0101000020E610000097A13BD22A4C25401A80B2CE9DD44540		0 Contrada Isabella, Adalrico nell'emilia, Italy
348	0	0101000020E6100000AD904D4DDD3827405B632BC313B14540		181 Incrocio Aristotele, Damiana a mare, Italy
349	0	0101000020E610000071E82D1EDEEB2C405F93DA30AF824440		0 Rotonda Tito, Casano laziale, Italy
350	0	0101000020E6100000DA48C8F6109B1F40EE2AFFB5176E4640		072 Incrocio Abbrescia, Selvaggia terme, Italy
351	0	0101000020E61000004D028A4798F02740C38366D7BD264640		16 Contrada Borrelli, Tomasi a mare, Italy
352	0	0101000020E6100000BCB77DEAB38A2C404EF04DD3676E4440		766 Via Ammoscato, San Berenice terme, Italy
353	0	0101000020E6100000CBC80F4BB93126404793E6EA22FD4640		80 Borgo Bozzo, Borgo Guelfo calabro, Italy
354	0	0101000020E6100000A68E9FD7E925284065677682A2C64640		88 Strada Acquadro, Basilia a mare, Italy
355	0	0101000020E6100000407562C55F5D294091FC773359C24640		32 Via Lai, Samona nell'emilia, Italy
356	0	0101000020E6100000CF328B506C4D244070D63B37C8184640		78 Via Marcianò, Boffa lido, Italy
357	0	0101000020E61000007E6E0D11DC1122409453967C47EB4640		2 Incrocio D'Errico, Farella laziale, Italy
358	0	0101000020E610000043A44BA4D989204072A8DF85ADD34640		4 Contrada Schiavone, Quarto Goffredo, Italy
359	0	0101000020E61000004371C79BFC022C404AF5F81807254540		80 Contrada Ausilia, San Nino ligure, Italy
360	0	0101000020E61000009EA74B10BFA422400292FAFC41944440		06 Via Gumesindo, Petrelli a mare, Italy
361	0	0101000020E61000000D88B59D5B012C40CF70B9B024144540		012 Contrada Colmanno, Astrid veneto, Italy
362	0	0101000020E610000059935D1F8CFE26407E6DA23B2D3B4640		025 Borgo Valeriana, Mariano calabro, Italy
363	0	0101000020E6100000D50451F7010829403B736AC2510D4640		1 Borgo Surace, Borgo Verulo umbro, Italy
364	0	0101000020E6100000CD6152D735012740D65F6523C6394640		6 Contrada Spadaro, Settimo Everardo ligure, Italy
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash") FROM stdin;
2	$2b$10$AFzx6MUxAQsDFZ/3ZRAzT.sRjcSUcW6CIl9wLVFG0jUt/HpbPNu.y	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N
4	$2b$10$djdjOAwinolLHtg7z4uP.OFXTByc6RUzBcLkcARUWznXtFejE8rvy	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N
5	$2b$10$.hLdfGDCtM2rNcDfF1.e1e4TT.irQQT8S2XnJ23CXeR7wChTFNyam	Laura	Zurru	5	laura@emergency.it	\N	t	\N
1	$2b$10$XXTXAkgzbQpEGKG353mi4uuPJRDRvOoXGgJ2kYcesDWDHxNu2hEfG	German	Gorodnev	0	german@hiker.it	\N	t	\N
3	$2b$10$tJ6KO3zGmBMrX7Pdcp8pZehfNc/vtoFapFbqzPN3oO4JNLjzO8FTe	vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 370, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 108, true);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 256, true);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 364, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: hike_points PK_7fc686c35c52228d8494a7c4947; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_7fc686c35c52228d8494a7c4947" PRIMARY KEY ("hikeId", "pointId");


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

