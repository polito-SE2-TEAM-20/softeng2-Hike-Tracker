--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$HQ7CyxeHCRCoMJZP3OBOu.NrPlokc4lhOlZzstilVNlykG2Zkqtfe',
    'Antonio',
    'Battipaglia',
    2,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$UUSwPeGya14II7LY1xIXlusjrY4E1jmtEi3fLzv.OK8EpaYQXKU6m',
    'Erfan',
    'Gholami',
    4,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$5GP.MfTYv4ZVww9kYhqJteVwL30ls1uCVYMbRhW1QVWu8Cdxzy.qC',
    'Laura',
    'Zurru',
    5,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$ZPVoPBf9zf.pvp6IwXOJye4EWS5QnhFk2bqk9hZtDUCKiCaWgAeGy',
    'German',
    'Gorodnev',
    0,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$gQmHsLZOwI9n/k771I/xfegtv1mmGGADpQPKsb22feotKWEtH8hbC',
    'Vincenzo',
    'Sagristano',
    3,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    6,
    'francesco@friend.it',
    '$2b$10$8C7Kqwqf5AvvI0ZSp0g4/OVMcN0zIm099TYB34yXAXk/7CA.mzgxK',
    'Francesco',
    'Grande',
    1,
    true,
    true
  );
  

      CREATE OR REPLACE FUNCTION public.insert_hike(
        user_id integer,
        title varchar,
        difficulty integer,
        gpx_path varchar,
        country varchar,
        region varchar,
        province varchar,
        city varchar,
        length numeric(12,2),
        ascent numeric(12,2),
        expected_time integer,
        description varchar,
        pictures jsonb,
        start_point jsonb,
        end_point jsonb,
        reference_points jsonb
      )  RETURNS VOID AS
      $func$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hike"(
        2,
        'Amprimo',
        2,
        '/static/gpx/Amprimo.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        0.7,
        23.2,
        80,
        'Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.',
        '["/static/images/3.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.165559804,"lat":45.102780737}'::jsonb,
        '{"name":"End Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.14299586,"lat":45.099887898}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":7.164360252,"lat":45.102912389,"altitude":1256.852},{"name":"Ref Point 2","address":"","lon":7.158207147,"lat":45.102886551,"altitude":1283.605}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello Chateau Beaulard - Cotolivier - Vazon',
        1,
        '/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Beaulard',
        8.2,
        22,
        200,
        'Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.',
        '["/static/images/2.jpg"]'::jsonb,
        '{"name":"Start Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.772358,"lat":45.03205}'::jsonb,
        '{"name":"End Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.77234,"lat":45.032238}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'borgata ruà a cima di crosa',
        1,
        '/static/gpx/Borgata Ruà-Cima di Crosa (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Sampeyre',
        5387.070533803441,
        955.0963319999998,
        150,
        'Raggiungi la partenza del Sentiero per la Cima di Crosa impostando sul navigatore “Borgata Ruà – Becetto“.

Parcheggiata la macchina a Borgata Ruà (o se impossibilitati a trovare un parcheggio anche a Becetto, allungando di 10 minuti il giro), si prende il sentiero sulla sinistra, nei pressi di una cartina (INDICAZIONI CIMA DI CROSA).',
        '["/static/images/46.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia","lon":7.201825,"lat":44.596613}'::jsonb,
        '{"name":"End Point","address":"Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia","lon":7.177367,"lat":44.615185}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Colle della Gianna da Pian della Regina',
        2,
        '/static/gpx/Colle Della Gianna (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        3622.3230077193216,
        865.2000000000003,
        130,
        'Colle della Gianna at an altitude of approximately 2530m connects the Po Valley to the Pellice Valley allowing you to reach the Barbara Lowrie refuge, an ideal base for multi-day crossings.

It is advisable to carefully consult the weather forecasts especially for these areas frequently subject to very thick fog.

Being at moderately high altitudes in spring there is the possibility of finding tongues of snow that could make the ascent more difficult.',
        '["/static/images/37.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia","lon":7.114553963765502,"lat":44.70202149823308}'::jsonb,
        '{"name":"End Point","address":"Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia","lon":7.103742817416787,"lat":44.722054582089186}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Hike Zicher',
        3,
        '/static/gpx/Hike_Zicher (2).gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Craveggio',
        3221.31231047859,
        712.936152,
        120,
        'Lungo l’itinerario non è garantita la piena copertura telefonica
In periodo estivo, la parte finale può essere molto esposta al sole e richiedere fatica.
In condizioni di vento forte, è preferibile non proseguire
E’ possibile sviluppare un itinerario ad anello scendendo dal versante nord della montagna in direzione Bocchetta Sant’Antonio (ma attenzione ad un passaggio su rocce, soprattutto se ghiacciate).',
        '["/static/images/29.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia","lon":8.534505,"lat":46.147128}'::jsonb,
        '{"name":"End Point","address":"Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia","lon":8.534103,"lat":46.163437}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Usseaux Altro',
        2,
        '/static/gpx/Laghi_Albergian.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Usseaux',
        15636.670195666402,
        1366.7991943359375,
        150,
        'The flowering of Eriofori along the shores of the lake between July and August is interesting, making it very suggestive.',
        '["/static/images/40.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025457266718149,"lat":45.0393102876842}'::jsonb,
        '{"name":"End Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025509485974908,"lat":45.039591416716576}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Usseaux Altro',
        3,
        '/static/gpx/Laghi_Albergiani.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Usseaux',
        15636.670195666402,
        1366.7991943359375,
        150,
        'Itinerario vario e panoramico, non presenta particolari difficoltà ma per la lunghezza, il dislivello, la mancanza di punti di appoggio e la necessità di una certa capacità di orientamento su sentieri non sempre evidenti (specialmente per la variante in discesa) è consigliato a escursionisti allenati e esperti.',
        '["/static/images/42.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025457266718149,"lat":45.0393102876842}'::jsonb,
        '{"name":"End Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025509485974908,"lat":45.039591416716576}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago Bianco',
        2,
        '/static/gpx/Lago Bianco.gpx',
        'Francia',
        'Auvergne-Rhone-Alpes',
        'Savoia',
        'Val-Cenis',
        9.3,
        13,
        210,
        'Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.

La diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.

La Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.

Si può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.',
        '["/static/images/1.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945681,"lat":45.223814}'::jsonb,
        '{"name":"End Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945581,"lat":45.224058}'::jsonb,
        '[{"name":"fountain","address":"","lon":6.940291,"lat":45.222543,"altitude":2027},{"name":"Peak","address":"","lon":6.937204,"lat":45.215867,"altitude":2131}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Lago dei 7 colori (lago gignoux)',
        2,
        '/static/gpx/Lago dei 7 colori (lago gignoux) (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Claviere',
        21358.82545547226,
        1087.900000000002,
        170,
        'Parcheggia a Claviere e dirigiti verso la strada comunale Valle Gimont che, dopo poco, si fa sterrata.

Lascia alla tua destra i cartelli che indicano il Lago Gignoux e prosegui risalendo le piste da sci.

Giunto a Sagna Longa noterai che la zona è di interesse sciistico, infatti ci sono numerosi arrivi di seggiovia. Segui le indicazioni per Colle Bercia, attraversa una chiesetta, dei caseggiati in pietra e prosegui per il largo sentiero.

L’intero percorso si sviluppa circondato dai bellissimi Monti della Luna ed è caratterizzato da una dolce e semicostante salita su terreno sterrato a tratti ghiaioso.

Superato il Colle Bercia continua sull’ampia carreggiata che ti conduce ad un valico nel quale noterai particolari conformazioni rocciose e una punta (Cima Saurel 2451 mt). Tieniti sul sentiero basso e supera il valico, che segna anche il confine con la Francia, dopo il quale troverai il lago immerso in una conca.',
        '["/static/images/51.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia","lon":6.749585,"lat":44.938467}'::jsonb,
        '{"name":"End Point","address":"Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia","lon":6.749585,"lat":44.938467}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago d''Afframont 1986 m',
        2,
        '/static/gpx/Lago di Afframont 1986 m.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Balme',
        4024.727690039548,
        810.8999999999994,
        120,
        'Una volta parcheggiata la macchina dirigiti verso il villaggio Albaron. Poco dopo i caseggiati ti troverai di fronte ad un impianto di risalita dismesso, a sinistra troverai un campetto da calcio, proprio dopo il campetto si intravedono i primi cartelli con le indicazioni per il Lago di Afframont. Il sentiero da seguire è il 213, ma lungo il tragitto troverai solo bandiere bianco/rosse e cartelli di legno che indicano la destinazione.

Si sale l’ex pista da sci e ci si addentra nel bosco. Il primo tratto rimane ombreggiato, mentre inizia a farsi sentire la salita. Ad un certo punto ci si affianca ad un ruscello, il Rio di Afframont, che scorre sulla sinistra e si supera con facilità in prossimità dei caseggiati in pietra (attenzione nei periodi di pioggia perché potrebbe essere impraticabile).',
        '["/static/images/52.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia","lon":7.223873427137733,"lat":45.30158649198711}'::jsonb,
        '{"name":"End Point","address":"Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia","lon":7.238771421834827,"lat":45.292359441518784}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Briccas da Borgata Brich 20/02/21',
        2,
        '/static/gpx/Monte Briccas da Brich (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        7580.49492167635,
        1049.2599999999993,
        110,
        'After leaving the car, we continue along the road, first paved and then dirt.

In case of little snow or high temperatures it is possible to cover the first 150m in altitude without snowshoes.

As soon as we hit the first snow, we put on our snowshoes and set off on a well-defined path that crosses a wood.

After having left the last huts behind us, we turn right towards the North/East near a GTA trail sign painted on a boulder.

From here, after the last bush, an enormous, very wide slope opens up before us which culminates right at our peak',
        '["/static/images/35.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia","lon":7.159385243430734,"lat":44.70842678099871}'::jsonb,
        '{"name":"End Point","address":"Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia","lon":7.158207753673196,"lat":44.708156045526266}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Monte Ferra Con Marco e Daniel',
        3,
        '/static/gpx/Monte Ferra (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cuneo',
        11664.786185753126,
        1472.7999999999993,
        150,
        'Fondamentali i bastoncini specialmente nella discesa dal Monte Ferra al lago Reisassa.

Unico punto di appoggio è il rifugio Melezè ad inizio itinerario (consigliamo di contattare direttamente la struttura per verificare giorni e orari di apertura)',
        '["/static/images/28.jpg"]'::jsonb,
        '{"name":"Start Point","address":"SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia","lon":6.982689192518592,"lat":44.57425086759031}'::jsonb,
        '{"name":"End Point","address":"SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia","lon":6.982647031545639,"lat":44.574263943359256}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Crissolo a Ghincia',
        2,
        '/static/gpx/Monte Granè (2).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        6229.073301997005,
        1024.7599999999993,
        200,
        'The Path to Monte Granè is a suggestive walk with a splendid view of Monviso (3841 m) and Viso Mozzo (3019 m).

Leave the car in the car park and continue to the left of the sports field where a splendid path immersed in the woods appears before us and after about 1.5 km you come to the dirt road which in summer leads to the Black Eagle refuge.

Continuing on the latter and having reached the refuge, continue along the Crissolo slopes to the end of the ski-lift where, just above the Ghincia Pastour hut, we will find a statue of the Madonna to indicate the end of the path to Monte Granè.

The return takes place along the same route as the outward journey.',
        '["/static/images/36.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.151954518631101,"lat":44.70016373321414}'::jsonb,
        '{"name":"End Point","address":"Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.121506668627262,"lat":44.688729643821716}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Montr Pigna da Prea',
        2,
        '/static/gpx/Monte Pigna Da Prea (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Roccaforte Mondovì',
        6588.816640728274,
        936.79,
        150,
        'Posteggiata la macchina nel parcheggio sotto l’abitato di Prea ci dirigiamo lungo la strada asfaltata situata sotto il cimitero, lasciandocelo sulla destra.

Appena incontriamo la prima neve possiamo allacciare le ciaspole e proseguire fino alla borgata di Sant’Anna di Prea. (Nei mesi invernali, con nevicate nella norma, la strada viene pulita fino al parcheggio quindi si può iniziare ad indossare le ciaspole fin da subito).

Subito dopo il cartello, all’ingresso di Sant’Anna di Prea, sulla destra vi è un magnifico sentiero immerso nel bosco che permette di tagliare la borgata accorciando la salita di circa 1 km.

Incrociando nuovamente la strada principale e percorrendo circa 3 km si giunge alla Baita Monte Pigna situata a metà degli impianti di Lurisia.',
        '["/static/images/47.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Pigna - Gardiola, Chiusa di Pesio, Cuneo, Piemonte, 12088, Italia","lon":7.738071503117681,"lat":44.27760533988476}'::jsonb,
        '{"name":"End Point","address":"","lon":7.702411115169525,"lat":44.25919541157782}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pian della Regina - Laghi del Monviso',
        2,
        '/static/gpx/Pian della Regina - Laghi del Monviso (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        10065.934631649065,
        842.6999999999998,
        130,
        'The excursion can start near the Po, parking the car in one of the many spaces available. Once you have crossed the stream, follow via Ruata.

To get your bearings in Crissolo, we suggest following the signs for "La Capanna" and ignoring the various detours on the left that follow the ski lifts. Before reaching the restaurant, you finally take the road, following the signs for Monte Tivoli.

The path climbs up into the wood (splendid during the autumn season) and crosses the Sbarme stream.',
        '["/static/images/32.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.117767,"lat":44.700645}'::jsonb,
        '{"name":"End Point","address":"Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.117535,"lat":44.700759}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Fenestrelle Escursionismo',
        2,
        '/static/gpx/Rif. Selleries.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        7281.87058844728,
        504.40087890625,
        120,
        'Itinerario di medio sviluppo con ampio panorama verso la Val Chisone.

Attenzione nella stagione invernale: la zona soggetta a valanghe in caso di abbondanti precipitazioni nevose, specialmente nella conca che precede il rifugio.

Informarsi sempre sullo stato della neve presso i gestori del rifugio o l’ufficio turistico di Fenestrelle.',
        '["/static/images/43.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia","lon":7.0737862307578325,"lat":45.03657284192741}'::jsonb,
        '{"name":"End Point","address":"Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia","lon":7.120104543864727,"lat":45.047753965482116}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Meira Garneri da Sampeyre',
        0,
        '/static/gpx/Rifugio Meira Garneri da Sampeyre (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Sampeyre',
        4156.23862253066,
        850.7600000000003,
        150,
        'Lascia l’auto nel parcheggio della seggiovia di Sampeyre.

Lasciato il parcheggio saliamo subito a destra degli impianti di risalita, dove alcuni cartelli rossi ci segnalano il sentiero attraverso il bosco.

Prendendo rapidamente quota, alla fine del primo tratto di boscoso, raggiungiamo la frazione Sodani dove possiamo osservare la bella chiesa affrescata.

Usciti dalla borgata proseguiamo nuovamente lungo il sentiero circondati da larici, faggi, betulle e dopo alcune deviazione, sempre ben segnalate, usciamo in una splendida radura.

Saliamo gli ultimi 200m a lato della pista o volendo possiamo proseguire più a destra incrociando la strada carrozzabile che nel periodo estivo porta al rifugio.',
        '["/static/images/45.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia","lon":7.180788516998291,"lat":44.57619898952544}'::jsonb,
        '{"name":"End Point","address":"Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia","lon":7.155619841068983,"lat":44.55683704465628}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per ROCCA PATANUA',
        2,
        '/static/gpx/Rocca Patanua da Prarotto (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Condove',
        4388.161778983409,
        923.6238601720527,
        200,
        'Itinerario interamente rivolto a Sud che normalmente si libera dalla neve già a inizio primavera.

(l’itinerario è stato svolto in periodo invernale, seguito scarsa e quasi totalmente assente copertura nevosa).',
        '["/static/images/28.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Alpe Tulivit, Condove, Torino, Piemonte, Italia","lon":7.237061262130737,"lat":45.14908790588379}'::jsonb,
        '{"name":"End Point","address":"Alpe Tulivit, Condove, Torino, Piemonte, Italia","lon":7.219639476388693,"lat":45.17825868912041}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Cima Durand-Colle Bauzano-Artesina',
        3,
        '/static/gpx/Senriero per Anello cima Durand, Colle Bauzano, Artesina (1) (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Artesina',
        8085.211186643268,
        829.1299999999999,
        150,
        'Lasciata la macchina nello spazioso parcheggio di Artesina o nei posteggi vicino al bar Tana del Lupo, saliamo sulle piste dove possiamo subito infilare le ciaspole.

Procediamo per circa 400m sull’ampio sentiero in direzione Ovest (a destra) e dopo alcuni tornanti troviamo un bivio (a sinistra vi è la stradina che percorreremo al ritorno) dove proseguiamo sulla destra (sentiero F02) dirigendoci verso la Celletta, punto panoramico sulla valle Ellero.

Percorriamo il sentiero per Serra della Turra che ci porta prima a passare sotto la seggiovia e poi ad un pianoro dove troviamo la Baita della Turra, tappa ideale per un eventuale break o colazione.',
        '["/static/images/48.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia","lon":7.755467472597957,"lat":44.24691265448928}'::jsonb,
        '{"name":"End Point","address":"Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia","lon":7.754717627540231,"lat":44.246627166867256}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Quintino Sella e Viso Mozzo',
        1,
        '/static/gpx/Sentiero per Rifugio Quintino Sella e Viso Mozzo.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        9039.751801123071,
        1090.660000000001,
        120,
        'The path does not present any difficulty, in case of rain, however, the climb is not recommended as the route is entirely on stony ground.

From up there you have a privileged view of a large part of the Monviso chain and the close distance to the Re di pietra is unique.',
        '["/static/images/31.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia","lon":7.094606207683682,"lat":44.70125044696033}'::jsonb,
        '{"name":"End Point","address":"Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia","lon":7.109863618388772,"lat":44.66575786471367}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Ss659 a Ss6591',
        3,
        '/static/gpx/Sentiero per Rupe del Gesso - CIASPOLE.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Formazzo',
        16969.02550810036,
        984.23046875,
        120,
        'Take the A26 motorway towards Gravellona Toce and follow it to the end. From there stay on the SS33 del Sempione passing Domodossola. At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls. There are unpaved parking lots just before the Centro Fondo Riale.',
        '["/static/images/38.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia","lon":8.41653149574995,"lat":46.41965291462839}'::jsonb,
        '{"name":"End Point","address":"Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia","lon":8.41653149574995,"lat":46.41965291462839}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Albogno-Pieve Margineta Mater',
        2,
        '/static/gpx/albogno-pieve-margineta-mater-27-8-21.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Albogno',
        11301.8785751773,
        1381.6880000000006,
        140,
        'Escursione senza molte difficoltà ideale per il periodo primaverile e autunnale. 
Dopo circa 2 ore di bosco si esce su delle creste molto panoramiche e semplici, il ritorno purtroppo viene fatto su un sentiero poco segnato sulla parte iniziale e ma man mano che si scende compiano sia segni e gli ometti.',
        '["/static/images/11.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia","lon":8.421405,"lat":46.139077}'::jsonb,
        '{"name":"End Point","address":"Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia","lon":8.421395,"lat":46.139111}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Alte Langhe Settentrionali - Cossano Belbo',
        2,
        '/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cossano Belbo',
        7.5,
        16.7,
        200,
        'Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.
Si svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.
Si imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.
Inizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.
Percorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. 
Seguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. 
Si procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante',
        '["/static/images/4.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199049,"lat":44.670379}'::jsonb,
        '{"name":"End Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199052,"lat":44.670377}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":8.214142,"lat":44.674545,"altitude":482.526},{"name":"Ref Point 2","address":"","lon":8.197792,"lat":44.668772,"altitude":242.585}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello per il Monte Freidour (PERLEVIEDELMONDO)',
        2,
        '/static/gpx/anello monte freidour (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'San Pietro Val Lemina',
        8503.263605697935,
        558.511400000002,
        150,
        'At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls.',
        '["/static/images/39.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia","lon":7.284098,"lat":44.96472}'::jsonb,
        '{"name":"End Point","address":"Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia","lon":7.284125,"lat":44.964785}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Anello Pieve di Ledro-Biacesa di Ledro-Rifugio Nino Pernici',
        2,
        '/static/gpx/anello-pieve-di-ledro-biacesa-di-ledro-rifugio-nino-pernici.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        42458.63040670248,
        23175.26399999994,
        320,
        'Anello sui monti a nord-est del Lago di Ledro, percorso in 3 giorni andando con molta calma, percorribile anche in 2. 
Alcuni tratti della prima metà del percorso sono attrezzati con scale e corde.',
        '["/static/images/14.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.73147,"lat":45.882851}'::jsonb,
        '{"name":"End Point","address":"Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731364,"lat":45.882702}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Anello sui colli imolesi: Dozza - Pieve S. Andrea',
        2,
        '/static/gpx/anello-sui-colli-imolesi-dozza-pieve-s-andrea-valsellustra-s.gpx',
        'Italia',
        'Emilia-Romagna',
        'Bologna',
        'Dozza',
        19320.58160760896,
        666.374,
        210,
        'Crossing the provincial road you can see the first of the various signs of the Camino di San Antonio that we will find along the way. We cross and begin a slow but constant climb alongside the fields, which will lead us to a beautiful panoramic view of the surrounding valleys. Paying attention to the crossroads, we continue until we cross the paved road again. In reality there is very little traffic... with a decent view of the Vena del Gesso Romagnola we arrive at the delightful village of Pieve Sant''Andrea (worth a quick detour), to then resume our journey. Be careful not to follow the path of Sant''Antonio, we descend rapidly (shortly after we find the Sorgente delle Accarisie on our left, already existing in Roman times) until we reach the small hamlet of Valsellustra. Here too we cross the road and follow the paved via delle Ville uphill to arrive at a first panoramic point over the surrounding gullies.',
        '["/static/images/21.jpg"]'::jsonb,
        '{"name":"Start Point","address":"5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia","lon":11.632106,"lat":44.359936}'::jsonb,
        '{"name":"End Point","address":"5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia","lon":11.63228,"lat":44.359936}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Campione Pieve Campione',
        2,
        '/static/gpx/campione-pieve-campione.gpx',
        'Italia',
        'Lombardia',
        'Brescia',
        'Campione del Garda',
        10764.501653316338,
        1852.4639999999995,
        300,
        'Campione Pieve Campione',
        '["/static/images/17.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia","lon":10.749084,"lat":45.752875}'::jsonb,
        '{"name":"End Point","address":"Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia","lon":10.749743,"lat":45.757881}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Casalfiumanese (BO) - Pieve di Sant''Andrea',
        2,
        '/static/gpx/casalfiumanese-bo-pieve-di-santandrea.gpx',
        'Italia',
        'Emilia-Romagna',
        'Bologna',
        'Casal Fiumese',
        15650.261397546863,
        838.3309999999993,
        210,
        'Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don''t die from the heat and the clouds filter the sun''s rays and allow you to better enjoy the landscapes',
        '["/static/images/24.jpg"]'::jsonb,
        '{"name":"Start Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616255,"lat":44.29726}'::jsonb,
        '{"name":"End Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616326,"lat":44.297235}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Casalfiumanese (BO) - Pieve di Sant''Andrea',
        2,
        '/static/gpx/casalfiumanese-bo-pieve.gpx',
        'Italia',
        'Emilia-romagna',
        'Bologna',
        'CasalFiumese',
        15650.261397546863,
        838.3309999999993,
        210,
        'Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don''t die from the heat and the clouds filter the sun''s rays and allow you to better enjoy the landscapes',
        '["/static/images/25.jpg"]'::jsonb,
        '{"name":"Start Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616255,"lat":44.29726}'::jsonb,
        '{"name":"End Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616326,"lat":44.297235}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Cavriana pieve- Volta mantovana chiesetta Madonna dei Marchi',
        1,
        '/static/gpx/cavriana-pieve-volta-mantovana-chiesetta-madonna-dei-marchi.gpx',
        'Italia',
        'Lombardia',
        'Mantova',
        'Cavriana',
        17987.27359307591,
        651.414999999999,
        150,
        'Bellissima passeggiata con displivello',
        '["/static/images/13.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia","lon":10.613546,"lat":45.347279}'::jsonb,
        '{"name":"End Point","address":"Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia","lon":10.614472,"lat":45.347241}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":10.625996,"lat":45.345584,"altitude":130.117},{"name":"Ref Point 2","address":"","lon":10.633173,"lat":45.34138,"altitude":139.742},{"name":"Fontain","address":"","lon":10.647482,"lat":45.332552,"altitude":107.319}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per CIMA CIANTIPLAGNA',
        2,
        '/static/gpx/ciantiplagna.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Meana di Susa',
        5474.279781243261,
        791.5095210000009,
        140,
        'The route is safe and within everyone''s reach, even though you reach a relatively high altitude... for this reason it is good to take into account sudden changes in the weather (wind, rain, thick fog).

Due to the total absence of shading, I recommend sunscreen cream and adequate water supply.

In late spring it is still possible to find accumulations of snow which can make the ascent difficult, especially in the final stretch towards the summit.

For cheese lovers, I highly recommend a stop at the Pian dell''Alpe bergeria...',
        '["/static/images/41.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Cima Ciantiplagna, Strada militare del Colle dell''Assietta, Bergerie dell''Assietta, Usseaux, Torino, Piemonte, Italia","lon":7.053414,"lat":45.071918}'::jsonb,
        '{"name":"End Point","address":"Cima Ciantiplagna, Strada militare del Colle dell''Assietta, Bergerie dell''Assietta, Usseaux, Torino, Piemonte, Italia","lon":7.012962,"lat":45.072133}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Voltino a Pieve di Tremosine e ritorno',
        2,
        '/static/gpx/da-voltino-a-pieve-di-tremosine-e-ritorno.gpx',
        'Italia',
        'Lombardia',
        'Brescia',
        'Tremosine sul Garda',
        6588.816640728274,
        936.79,
        120,
        'Fa quasi paura ad avvicinarsi alla ringhiera. 
Vicino alla postazione panoramica presso il bar ristorante che ho fotografato, c''è l''inizio del sentiero per la discesa al Porto di Tremosine.C''è scritto che è consigliato per escursionisti esperti.',
        '["/static/images/15.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia","lon":10.764297,"lat":45.782504}'::jsonb,
        '{"name":"End Point","address":"Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia","lon":10.763028,"lat":45.782797}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Dalla chiesa romanica di San Pietro di Fenestrella alla abba...',
        2,
        '/static/gpx/dalla-chiesa-romanica-di-san-pietro-di-fenestrella-alla-abba.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Albugnano',
        13691.922955982358,
        584.9190000000001,
        150,
        'Chiesa di San Pietro de Fenestrella: 
La chiesa è situata nel cimitero di Albugnano. 
Essa ha affinità compositive con la Canonica di santa Maria di Vezzolano e deriverebbe il suo nome ,secondo alcuni,dalla insolita presenza di tre finestre nell’abside,secondo altri, sarebbe stata così denominata perchè situata nello stretto colle (una gola) compreso tra il rilievo collinare di Albugnano e il rilievo ove sorge il cimitero: 
Una specie di finestra aperta sulla valle sottostante.',
        '["/static/images/27.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia","lon":7.97125,"lat":45.077934}'::jsonb,
        '{"name":"End Point","address":"Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia","lon":7.971227,"lat":45.077991}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Gulo - Pieve Vergonte',
        1,
        '/static/gpx/gulo-pieve-vergonte.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Santa Maria',
        14496.863954985321,
        832.3479999999993,
        90,
        'Gulo - Pieve Vergonte',
        '["/static/images/9.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia","lon":8.248234,"lat":45.997598}'::jsonb,
        '{"name":"End Point","address":"Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia","lon":8.264287,"lat":46.004814}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Il giro del Montorfano: la chiesa romanica, il borgo e la ve...',
        2,
        '/static/gpx/il-giro-del-montorfano-la-chiesa-romanica-il-borgo-e-la-vett.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Bracchio',
        9623.856463002363,
        697.1199999999999,
        210,
        'Il giro del Montorfano: la chiesa romanica, il borgo e la vetta',
        '["/static/images/10.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia","lon":8.448922,"lat":45.960306}'::jsonb,
        '{"name":"End Point","address":"Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia","lon":8.448922,"lat":45.960306}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'La chiesa romanica di S. Vittore(anello Montemagno--Viarigi)',
        3,
        '/static/gpx/la-chiesa-romanica-di-s-vittoreanello-montemagno-viarigi.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montemagno',
        12572.716765417841,
        341.5519999999999,
        210,
        'Il percorso si svolge prevalentemente su sterrata. 
Esso non ha segnaletica ad eccezione dell’ultimo tratto (due km. circa) da località Madonna del Gombo fino a Montemagno. 
In questo tratto si incontra la segnaletica del sentiero n.507 della Regione Piemonte.',
        '["/static/images/6.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia","lon":8.323294,"lat":44.983183}'::jsonb,
        '{"name":"End Point","address":"Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia","lon":8.323553,"lat":44.983388}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'La pieve romanica di Piesenzana e la valle delle tartufaie',
        2,
        '/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montechiaro d''Asti',
        3.1,
        21.1,
        225,
        'Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. 
Circa 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. 
In regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. 
A Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). 
Contemporaneamente i ristoranti della zona propongono piatti a base di tartufi',
        '["/static/images/5.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.113224,"lat":45.007605}'::jsonb,
        '{"name":"End Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.11358,"lat":45.007557}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Le Paludi di Ostiglia Oasi del Busatello Sermide e Pieve',
        3,
        '/static/gpx/le-paludi-di-ostiglia-oasi-del-busatello-sermide-e-pieve-di-.gpx',
        'Italia',
        'Lombardia',
        'Mantova',
        'Pieve di Coriano',
        12572.716765417841,
        341.5519999999999,
        255,
        'La tradizione afferma che la chiesa fu costruita nel 1082, per volere di Matilde di Canossa. Questa attribuzione risale al 1612 nella Historia ecclesiastica di Mantova dove il Donesmondi attribuisce l''edificazione della chiesa a Matilde, assieme ad altre chiese del territorio. 
Il Donesmondi affermò questa data riprendendo l''iscrizione da una lapide presente sulla facciata della pieve, visibile ancora oggi, dove sta scritto "D.O.M. ET B. MARIAE V. IN COELUM ASSUMPTAE ERECTA A.D. 1082 A CONNTISSA MATHILDE". Secondo un''analisi storica questa lapide non può essere ritenuta originale dell''XI secolo, ma risale al cinquecento. L''ipotesi è che questa iscrizione si stata realizzata durante il restauro del 1538. 
Storicamente, quindi, non ci sono documenti che attestano una data certa di costruzione della chiesa, ma sulla base degli elementi architettonici si può affermare che la pieve venne eretta nell''XI secolo. 
La chiesa è in stile romanico, costruita in laterizio ed è composta da tre navat',
        '["/static/images/7.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia","lon":11.106454,"lat":45.035438}'::jsonb,
        '{"name":"End Point","address":"Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia","lon":11.106576,"lat":45.03596}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":11.109236,"lat":45.044962,"altitude":22.75},{"name":"Ref Point 2","address":"","lon":11.155368,"lat":45.034617,"altitude":35.551}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per il MONTE CUCETTO',
        2,
        '/static/gpx/monte cucetto.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Dubbione',
        2150.3010767004043,
        586.4262699999999,
        120,
        'Escursione Facile e, nella parte alta, molto panoramica; la cima offre una buona panoramica dei rilievi tra bassa Val Chisone e Val Sangone.

Lasciata l’auto, il sentiero parte in corrispondenza del tornante ed entra nel bosco in direzione Nord-Ovest; al primo bivio, proseguire dritto e seguire le indicazioni per “Cucetto”; il sentiero inizia a guadagnare quota abbastanza rapidamente e costantemente, sempre nel bosco.

Dopo una serie di tornantini la vegetazione inizierà a diradarsi e si inizierà a scorgere un bel panorama con il Monviso in bella mostra (se il meteo lo permette).',
        '["/static/images/50.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Pralamar, Pinasca, Torino, Piemonte, 10063, Italia","lon":7.243299,"lat":44.961979}'::jsonb,
        '{"name":"End Point","address":"Pralamar, Pinasca, Torino, Piemonte, 10063, Italia","lon":7.240229,"lat":44.977112}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per il MONTE MURETTO',
        2,
        '/static/gpx/monte muretto.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Torino',
        2127.346730436805,
        277.51812700000005,
        200,
        'È presente un unico punto acqua nel luogo del parcheggio (fontana). Nella stessa piazzetta, al momento della recensione, è sempre aperto nei weekend un singolare bar allestito dentro un vecchio furgone.

Per chi cammina con bimbi e soprattutto cani, attenzione in primavera alla presenza di processionarie.',
        '["/static/images/44.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia","lon":7.31544,"lat":44.918242}'::jsonb,
        '{"name":"End Point","address":"Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia","lon":7.309893,"lat":44.929433}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pieve di Ledro - Monte Cocca',
        1,
        '/static/gpx/pieve-di-ledro-monte-cocca.gpx',
        'Italia',
        'Trentino Alto Adige',
        'Provincia di Trento',
        'Pieve di Ledro',
        8627.552532528542,
        1018.0050000000002,
        70,
        'Very challenging, but worth it! The view from the top is gorgeous! For the descent it is better to use sticks, or repeat the same route as the climb.',
        '["/static/images/20.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.730931,"lat":45.889379}'::jsonb,
        '{"name":"End Point","address":"Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731044,"lat":45.889397}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pieve S. Stefano a Pian delle Capanne',
        2,
        '/static/gpx/pieve-s-stefano-a-pian-delle-capanne.gpx',
        'Italia',
        'Toscana',
        'Arezzo',
        'Pieve Santo Stefano',
        22430.396794868582,
        1004.4300000000019,
        150,
        'Causa pioggia e terreno scivoloso preso la 1º variante fino al passo Viamaggio poi proseguito ancora per la 2º variante. 
Bisogna calcolare circa 4 km in più.',
        '["/static/images/23.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Poggiolino delle Viole, Castellare, Pieve Santo Stefano, Arezzo, Toscana, 52036, Italia","lon":12.039528,"lat":43.670638}'::jsonb,
        '{"name":"End Point","address":"Bike Help, Pian della Capanna, Pieve Santo Stefano, Arezzo, Toscana, Italia","lon":12.150503,"lat":43.651402}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Piverone - Anello IV - “Via Romanica al Gesiun”',
        1,
        '/static/gpx/piverone-anello-iv-via-romanica-al-gesiun.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Pieverone',
        4857.311515489554,
        94.22999999999996,
        60,
        'Piverone - Anello IV - “Via Romanica al Gesiun”',
        '["/static/images/8.jpg"]'::jsonb,
        '{"name":"Start Point","address":"26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia","lon":8.00725,"lat":45.44783}'::jsonb,
        '{"name":"End Point","address":"26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia","lon":8.00696,"lat":45.44779}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Plois - Pieve d''Alpago',
        2,
        '/static/gpx/plois-pieve-dalpago.gpx',
        'Italia',
        'Veneto',
        'Belluno',
        'Pieve d''Alpegno',
        6588.816640728274,
        936.79,
        320,
        'percorso è tranquillamente percorribile',
        '["/static/images/19.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Municipio, Via Roma, Torres, Tignes, Pieve d''Alpago, Alpago, Belluno, Veneto, 32010, Italia","lon":12.360272,"lat":46.175025}'::jsonb,
        '{"name":"End Point","address":"Municipio, Via Roma, Torres, Tignes, Pieve d''Alpago, Alpago, Belluno, Veneto, 32010, Italia","lon":12.352636,"lat":46.167926}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Galassi, forcella del ghiacciaio, Rifugio Antelao',
        2,
        '/static/gpx/rifugio-galassi-forcella-del-ghiacciaio-rifugio-antelao-piev.gpx',
        'Italia',
        'Veneto',
        'Belluno',
        'Belluno',
        6588.816640728274,
        936.79,
        200,
        'Quinta giornata Alta via N°4
Rifugio Galassi, forcella del ghiacciaio, Rifugio Antelao, Pieve di Cadore.',
        '["/static/images/18.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia","lon":12.261855,"lat":46.470487}'::jsonb,
        '{"name":"End Point","address":"Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia","lon":12.364278,"lat":46.426071}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Riva del Garda - Pieve di Ledro - Panchina',
        3,
        '/static/gpx/riva-del-garda-pieve-di-ledro-panchina.gpx',
        'Italia',
        'Trentino Alto Adige',
        'Provincia di Trento',
        'Sant''Alessandro',
        8085.211186643268,
        829.1299999999999,
        135,
        'Riva del Garda - Pieve di Ledro - Panchina',
        '["/static/images/16.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.853195,"lat":45.882925}'::jsonb,
        '{"name":"End Point","address":"Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731102,"lat":45.88923}'::jsonb,
        '[{"name":"Peak","address":"","lon":10.853195,"lat":45.882925,"altitude":67.085},{"name":"Lake","address":"","lon":10.764528,"lat":45.873764,"altitude":712.069}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sovicille delle Meraviglie - Villa Cetinale - Scala Santa',
        2,
        '/static/gpx/sovicille-delle-meraviglie-villa-cetinale-scala-santa-e-romi.gpx',
        'Italia',
        'Toscana',
        'Siena',
        'Sovicille',
        19553.110970430764,
        1298.215999999996,
        210,
        'Suggestivo anello con visita della pieve di Pernina e del parco di Villa Cetinale/Castello di Celsa aperti in occasione dell''evento Sovicille delle Meraviglie ottobre 2021',
        '["/static/images/26.jpg"]'::jsonb,
        '{"name":"Start Point","address":"4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia","lon":11.228176,"lat":43.279339}'::jsonb,
        '{"name":"End Point","address":"4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia","lon":11.228044,"lat":43.279294}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'BERGERIE DI VALLONCRO’',
        3,
        '/static/gpx/vallone di massello (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Massello',
        5304.03695311155,
        958.8864720000013,
        150,
        'Open and shade-free environment: remember sunscreen; if the walk is too long, the plateau at the base of the waterfall still offers various possibilities for pleasant picnics.',
        '["/static/images/30.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia","lon":7.031857,"lat":44.964905}'::jsonb,
        '{"name":"End Point","address":"Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia","lon":6.997145,"lat":44.978063}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Ville Disunite - Anello Ghibullo - Villa Pasolini.',
        2,
        '/static/gpx/ville-disunite-anello-ghibullo-villa-pasolini-torre-albicini.gpx',
        'Italia',
        'Emilia-Romagna',
        'Ravenna',
        'Lognana',
        22696.477033711653,
        236.7130000000004,
        110,
        'The first stretch is entirely on the right bank of the Ronco, on the Via Romea Germanica. Then you enter the territory to go towards the center of the journey, the area of ​​San Pietro in Trento where, within two kilometres, you come across a medieval tower, a 9th century parish church with a fantastic crypt, the ruins of a large villa and a perfectly healthy 16th century villa.',
        '["/static/images/23.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia","lon":12.138685,"lat":44.343306}'::jsonb,
        '{"name":"End Point","address":"Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia","lon":12.139573,"lat":44.343643}'::jsonb,
        NULL
      );
    
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2),
        working_time_start time without time zone,
        working_time_end time without time zone,
        email varchar,
        phone_number varchar,
        pictures jsonb
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber",
      "pictures"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number,
      pictures
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        2,
        100::numeric(12,2),
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Dr. Cleo Pedrazzini',
        'http://skinny-context.net',
        274.871,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Sabrina.Monaco1@libero.it',
        '+396477681179',
        '["/static/images/0f68f939-1081-45c4-88f1-1c6240d0b402.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        2,
        60::numeric(12,2),
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Socrate Santini',
        'http://bubbly-commonsense.org',
        322.202,
        '02:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Tirone21@hotmail.com',
        '+393859731489',
        '["/static/images/c3704bc1-511d-4d88-8554-edb5bcbd5b74.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        8,
        52::numeric(12,2),
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Neiva Cortese',
        'https://dense-guilty.net',
        337.331,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Graziano31@gmail.com',
        '+392822151553',
        '["/static/images/0671e710-77e3-41ad-ac94-973a8aa4d10e.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        3,
        41::numeric(12,2),
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Edvige Cipriano',
        'https://prestigious-compassion.it',
        291.771,
        '07:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Lautone1@gmail.com',
        '+390008999831',
        '["/static/images/67c24cb6-647b-434e-a296-40a071d11211.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        3,
        42::numeric(12,2),
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Paola Siri',
        'https://motionless-ferret.net',
        319.644,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Uriele63@email.it',
        '+395568481870',
        '["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        10,
        48::numeric(12,2),
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Priamo Cenni',
        'https://some-noon.net',
        308.75,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Tarso_DAngeli41@yahoo.com',
        '+390436493428',
        '["/static/images/67c24cb6-647b-434e-a296-40a071d11211.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        1,
        55::numeric(12,2),
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Sig. Colmanno Di Ciocco',
        'http://alienated-anywhere.net',
        286.63,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Desiderato_Verme@yahoo.com',
        '+397308624175',
        '["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        9,
        81::numeric(12,2),
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Protasio Femina',
        'http://cylindrical-endive.net',
        275.714,
        '08:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Ursino_Bressan@libero.it',
        '+399331825008',
        '["/static/images/0f68f939-1081-45c4-88f1-1c6240d0b402.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        1,
        136::numeric(12,2),
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Foca Barra',
        'https://present-schooner.it',
        313.478,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Vedasto30@hotmail.com',
        '+399592823690',
        '["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        6,
        82::numeric(12,2),
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Ing. Dafne Di Rocco',
        'http://snarling-ring.net',
        277.541,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Porziano.Pianigiani2@gmail.com',
        '+398273080275',
        '["/static/images/6d3e3fa9-dedb-4c76-8d2e-1efd1026617d.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        4,
        44::numeric(12,2),
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Dionisia Benatti',
        'https://weepy-scent.it',
        332.605,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Ramiro45@yahoo.com',
        '+399738237125',
        '["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        9,
        149::numeric(12,2),
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Nunziata Rapuano',
        'https://crafty-gossip.org',
        300.417,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Adelmo_Bandini@hotmail.com',
        '+392770103757',
        '["/static/images/872ff603-5819-4c1c-a4bc-cee33e1db7dd.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        1,
        102::numeric(12,2),
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Alba Cottone',
        'https://filthy-platinum.com',
        299.497,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Fernando_Fonti40@yahoo.it',
        '+398530063453',
        '["/static/images/4451e87f-0108-4fd7-872b-fa91671f8104.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        5,
        79::numeric(12,2),
        'Vernagthütte',
        'Austria',
        'Eva Boschi',
        'https://some-emanate.com',
        300.424,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Ginevra_Vecchi@libero.it',
        '+397606217964',
        '["/static/images/6618e934-60ac-4e23-ab86-d8dd255db78d.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        1,
        101::numeric(12,2),
        'Wormser Hütte',
        'Austria',
        'Ulberto Cascio',
        'http://flamboyant-scrambled.it',
        310.454,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Filippo.Farina@yahoo.it',
        '+391064788618',
        '["/static/images/95ab3575-30d3-4c94-a91f-0f2bac28e717.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        5,
        117::numeric(12,2),
        'Biberacher Hütte',
        'Austria',
        'Ettore Sorrentino',
        'http://carefree-gold.com',
        302.796,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Damiana.Giardina72@gmail.com',
        '+392926156719',
        '["/static/images/22233684-687e-4f05-832d-2edc726209fb.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        6,
        69::numeric(12,2),
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Sig. Vissia Loi',
        'https://amazing-vintner.it',
        267.705,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Arturo.Zanella84@email.it',
        '+399406527950',
        '["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        8,
        137::numeric(12,2),
        'Hochwaldhütte',
        'Germany',
        'Vera Bulgarelli',
        'https://tempting-screwdriver.it',
        312.96,
        '03:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Damocle_Silvestro@libero.it',
        '+396503212968',
        '["/static/images/0f68f939-1081-45c4-88f1-1c6240d0b402.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        5,
        50::numeric(12,2),
        'Kölner Eifelhütte',
        'Germany',
        'Beata Castiglioni',
        'https://first-mortise.net',
        294.393,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Giuda_Garofalo56@email.it',
        '+399668925231',
        '["/static/images/872ff603-5819-4c1c-a4bc-cee33e1db7dd.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        7,
        129::numeric(12,2),
        'Madrisahütte',
        'Austria',
        'Romilda Carrieri',
        'http://valuable-self-confidence.it',
        317.749,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Manuela.Palladino@hotmail.com',
        '+393312416945',
        '["/static/images/dc748eef-5832-462c-b8ea-565a7beb4298.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        7,
        114::numeric(12,2),
        'Dresdner Hütte',
        'Austria',
        'Remo Vecchi',
        'https://frugal-calorie.it',
        336.539,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Venanzio6@email.it',
        '+399559148306',
        '["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        10,
        124::numeric(12,2),
        'Fiderepasshütte',
        'Germany',
        'Fernanda Baldi',
        'https://vengeful-eyelid.net',
        312.973,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Illuminato69@email.it',
        '+390410672257',
        '["/static/images/c3704bc1-511d-4d88-8554-edb5bcbd5b74.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        9,
        69::numeric(12,2),
        'Göppinger Hütte',
        'Austria',
        'Marta Capriotti',
        'https://subdued-conflict.it',
        287.192,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Protasio_Gatta50@yahoo.com',
        '+392104014652',
        '["/static/images/7bb60d4d-4477-40ff-8ad1-39ff877f826b.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        7,
        46::numeric(12,2),
        'Oberzalimhütte',
        'Austria',
        'Pantaleone Gandolfo',
        'https://grandiose-bonus.org',
        290.639,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Eliano.Maresca@gmail.com',
        '+390932027900',
        '["/static/images/0f68f939-1081-45c4-88f1-1c6240d0b402.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        2,
        111::numeric(12,2),
        'Rastkogelhütte',
        'Austria',
        'Rachele Ferroni',
        'http://unacceptable-lotion.it',
        316.147,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Angelo45@yahoo.it',
        '+397340527958',
        '["/static/images/9333cf6d-3c60-4462-a815-09ea3a54fbaf.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        2,
        63::numeric(12,2),
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Bartolo Maione',
        'http://fragrant-leadership.net',
        289.528,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Cantidio80@email.it',
        '+395403199549',
        '["/static/images/872ff603-5819-4c1c-a4bc-cee33e1db7dd.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        3,
        81::numeric(12,2),
        'Kaltenberghütte',
        'Austria',
        'Brigida De Meo',
        'https://delightful-offset.org',
        268.265,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Coronato.Salis35@hotmail.com',
        '+391346038164',
        '["/static/images/c4b3fba9-e26e-4fb0-a093-78dac6a2f062.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        9,
        99::numeric(12,2),
        'Schweinfurter Hütte',
        'Austria',
        'Eugenio Fava',
        'https://yummy-buddy.com',
        267.075,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Angelo_Battaglia73@gmail.com',
        '+399539954735',
        '["/static/images/c4b3fba9-e26e-4fb0-a093-78dac6a2f062.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        5,
        136::numeric(12,2),
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Malco Zappia',
        'https://required-gemsbok.it',
        267.254,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Semplicio94@libero.it',
        '+398389378545',
        '["/static/images/dc748eef-5832-462c-b8ea-565a7beb4298.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        2,
        97::numeric(12,2),
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Tobia Tortorici',
        'https://reasonable-toll.org',
        276.456,
        '03:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Sicuro_Speranza@yahoo.it',
        '+393802662367',
        '["/static/images/eb0a64be-eeba-49fb-b952-227f7ad04a48.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        7,
        135::numeric(12,2),
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Dr. Rosamunda Marega',
        'https://hoarse-trek.org',
        308.836,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Loreno45@libero.it',
        '+393441588001',
        '["/static/images/9333cf6d-3c60-4462-a815-09ea3a54fbaf.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        9,
        120::numeric(12,2),
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Ventura Panzeri',
        'https://squeaky-egg.com',
        269.151,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Amerigo19@hotmail.com',
        '+393577936454',
        '["/static/images/7bb60d4d-4477-40ff-8ad1-39ff877f826b.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        8,
        83::numeric(12,2),
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Servidio Restivo',
        'https://infinite-menopause.com',
        308.637,
        '09:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Ivano_Casali60@yahoo.it',
        '+394099778080',
        '["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        1,
        139::numeric(12,2),
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Zena Luciano',
        'https://elegant-rifle.it',
        304.781,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Erardo8@yahoo.it',
        '+396439505466',
        '["/static/images/6618e934-60ac-4e23-ab86-d8dd255db78d.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        1,
        99::numeric(12,2),
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Catena Vitali',
        'https://indelible-pat.com',
        336.124,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Immacolata.Lucarelli38@hotmail.com',
        '+397571728324',
        '["/static/images/0671e710-77e3-41ad-ac94-973a8aa4d10e.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        5,
        67::numeric(12,2),
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Clara Pellegrino',
        'http://impractical-landing.net',
        273.671,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Fermo.Macr@hotmail.com',
        '+391017052480',
        '["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        8,
        70::numeric(12,2),
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Debora Vuillermoz',
        'http://glorious-insight.it',
        327.943,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Ulstano.Barra91@yahoo.it',
        '+391078441442',
        '["/static/images/95ab3575-30d3-4c94-a91f-0f2bac28e717.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        9,
        57::numeric(12,2),
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Ing. Terzo Nocerino',
        'https://delicious-kneejerk.it',
        293.066,
        '09:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Ilva78@hotmail.com',
        '+399291961277',
        '["/static/images/eb0a64be-eeba-49fb-b952-227f7ad04a48.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        7,
        130::numeric(12,2),
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Dott. Clinio Ravaioli',
        'https://doting-ischemia.org',
        280.487,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Vilfredo_Floridia80@hotmail.com',
        '+391622215321',
        '["/static/images/9333cf6d-3c60-4462-a815-09ea3a54fbaf.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        8,
        66::numeric(12,2),
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Luciano Mora',
        'http://demanding-leadership.org',
        295.333,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Quinzio_Lari@email.it',
        '+394180735251',
        '["/static/images/0f68f939-1081-45c4-88f1-1c6240d0b402.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        3,
        145::numeric(12,2),
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Vito Cardia',
        'https://wiry-electrocardiogram.org',
        278.976,
        '04:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Uberto.Pani14@yahoo.it',
        '+392308289684',
        '["/static/images/67c24cb6-647b-434e-a296-40a071d11211.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        8,
        103::numeric(12,2),
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Endrigo Cuzzocrea',
        'http://impartial-loop.it',
        313.401,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Corbiniano.Nota64@yahoo.it',
        '+397210865856',
        '["/static/images/6618e934-60ac-4e23-ab86-d8dd255db78d.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        8,
        124::numeric(12,2),
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Audace Panza',
        'https://clever-anniversary.com',
        319.732,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Aristarco_Giordano@yahoo.com',
        '+398548079655',
        '["/static/images/9333cf6d-3c60-4462-a815-09ea3a54fbaf.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        2,
        62::numeric(12,2),
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Cristina Ambrosini',
        'https://indolent-report.it',
        289.638,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Verulo.Micco@hotmail.com',
        '+399565289614',
        '["/static/images/9333cf6d-3c60-4462-a815-09ea3a54fbaf.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        4,
        76::numeric(12,2),
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Lorenza Renna',
        'http://conscious-republican.com',
        311.8,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Lorenza_Schiavone@hotmail.com',
        '+396831826511',
        '["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        6,
        48::numeric(12,2),
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Leonia Perrotta',
        'https://whirlwind-optimization.net',
        279.703,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Doriano.Colantuono@gmail.com',
        '+399284366863',
        '["/static/images/eb0a64be-eeba-49fb-b952-227f7ad04a48.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        2,
        138::numeric(12,2),
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Dott. Aiace Salatiello',
        'https://watchful-visor.it',
        333.58,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Lisa.Semprini@gmail.com',
        '+394438043314',
        '["/static/images/0671e710-77e3-41ad-ac94-973a8aa4d10e.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        9,
        96::numeric(12,2),
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Veronica Anelli',
        'http://favorable-enthusiasm.com',
        310.293,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Elsa_Giorgi@email.it',
        '+399968972020',
        '["/static/images/9333cf6d-3c60-4462-a815-09ea3a54fbaf.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        3,
        50::numeric(12,2),
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Anna Martini',
        'https://thoughtful-ruler.it',
        272.359,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Icaro.Zanetti51@email.it',
        '+394125424129',
        '["/static/images/7bb60d4d-4477-40ff-8ad1-39ff877f826b.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        3,
        106::numeric(12,2),
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Gemma Baldini',
        'https://cultivated-selling.it',
        273.827,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Verdiana_Paolucci@email.it',
        '+390699931041',
        '["/static/images/c4b3fba9-e26e-4fb0-a093-78dac6a2f062.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        7,
        50::numeric(12,2),
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Aresio Piva',
        'http://authorized-annual.net',
        283.913,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Aurelia_Giustra35@email.it',
        '+392888430430',
        '["/static/images/dc748eef-5832-462c-b8ea-565a7beb4298.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        3,
        52::numeric(12,2),
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Gabriella Modica',
        'https://plastic-surge.org',
        335.602,
        '08:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Liberto_Rizza84@gmail.com',
        '+395879803717',
        '["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        10,
        147::numeric(12,2),
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Adone Siino',
        'https://calm-reflection.org',
        299.241,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Pupolo.Bruno@yahoo.it',
        '+392409622118',
        '["/static/images/4451e87f-0108-4fd7-872b-fa91671f8104.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        2,
        68::numeric(12,2),
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Margherita Petronio',
        'https://shiny-colloquy.it',
        277.036,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Valfrido92@yahoo.it',
        '+398840025832',
        '["/static/images/22233684-687e-4f05-832d-2edc726209fb.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        7,
        150::numeric(12,2),
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Ladislao Zagaria',
        'http://voluminous-actor.com',
        270.11,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Verano.Ciuffreda@libero.it',
        '+399191553686',
        '["/static/images/67c24cb6-647b-434e-a296-40a071d11211.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        3,
        139::numeric(12,2),
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Glenda Capuano',
        'https://big-interject.org',
        285.881,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Gentile_Campus@gmail.com',
        '+393970679851',
        '["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        3,
        133::numeric(12,2),
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Armando Verme',
        'https://best-scent.it',
        280.364,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Ornella.Mazza@email.it',
        '+397195737803',
        '["/static/images/67c24cb6-647b-434e-a296-40a071d11211.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        8,
        122::numeric(12,2),
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Niniano Coretti',
        'https://kosher-reflection.it',
        296.913,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Calogero.Riggio@gmail.com',
        '+397011225410',
        '["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        7,
        103::numeric(12,2),
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Ilva Cappelletti',
        'https://frayed-shootdown.it',
        281.901,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Teodora27@hotmail.com',
        '+399168275353',
        '["/static/images/bcb89119-072b-4034-b2f6-5df38bfbd34c.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        5,
        49::numeric(12,2),
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Adelmo Maggiani',
        'http://overjoyed-diary.org',
        288.477,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Cesare_Scalia78@yahoo.com',
        '+395202280767',
        '["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        1,
        147::numeric(12,2),
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Morena Campus',
        'https://snappy-rose.net',
        301.81,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Nicola.Martucci13@email.it',
        '+399430423800',
        '["/static/images/872ff603-5819-4c1c-a4bc-cee33e1db7dd.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        8,
        134::numeric(12,2),
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Aciscolo Greco',
        'https://tragic-plastic.it',
        330.853,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Zabedeo_Paone68@hotmail.com',
        '+392805906490',
        '["/static/images/67c24cb6-647b-434e-a296-40a071d11211.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        5,
        47::numeric(12,2),
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Domezio Sacchet',
        'http://fatherly-gas.it',
        323.764,
        '08:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Bertolfo40@yahoo.com',
        '+399994171649',
        '["/static/images/c4b3fba9-e26e-4fb0-a093-78dac6a2f062.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        1,
        125::numeric(12,2),
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Alfio Critelli',
        'https://potable-vengeance.it',
        318.39,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Crocefisso58@libero.it',
        '+394496907698',
        '["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        2,
        88::numeric(12,2),
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Costante Di Nardo',
        'https://fatal-celsius.com',
        322.738,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Dorotea_Caretti12@yahoo.it',
        '+397575587345',
        '["/static/images/bcb89119-072b-4034-b2f6-5df38bfbd34c.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        8,
        66::numeric(12,2),
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Fosco Musumeci',
        'https://untrue-exterior.it',
        284.549,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Gioventino.Cinelli35@email.it',
        '+398282452440',
        '["/static/images/7bb60d4d-4477-40ff-8ad1-39ff877f826b.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        8,
        112::numeric(12,2),
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Celinia Bodini',
        'http://fixed-snack.org',
        274.943,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Gaetano7@yahoo.it',
        '+391734924363',
        '["/static/images/4451e87f-0108-4fd7-872b-fa91671f8104.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        5,
        107::numeric(12,2),
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Liborio Baraldi',
        'http://equal-inhibitor.it',
        327.847,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Ivanoe19@libero.it',
        '+394378843882',
        '["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        2,
        45::numeric(12,2),
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Berenice Liccardo',
        'https://pointless-cell.it',
        298.111,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Graziella66@gmail.com',
        '+392723698779',
        '["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        4,
        63::numeric(12,2),
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Olimpia Ciccone',
        'http://fearless-characterization.it',
        267.216,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Archimede12@libero.it',
        '+392760127484',
        '["/static/images/6d3e3fa9-dedb-4c76-8d2e-1efd1026617d.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        7,
        42::numeric(12,2),
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Giambattista Pedrazzini',
        'http://scrawny-dependent.net',
        276.972,
        '04:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Carlotta_Massari@gmail.com',
        '+394320077149',
        '["/static/images/3abd12a2-ca82-4d5e-b93f-c4bf780d74b3.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        8,
        119::numeric(12,2),
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Dr. Artemisa Paola',
        'https://rural-future.org',
        285.495,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Unna.Marra@yahoo.it',
        '+395653224954',
        '["/static/images/eb0a64be-eeba-49fb-b952-227f7ad04a48.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        10,
        82::numeric(12,2),
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Oderico Criscenti',
        'https://tender-grandfather.it',
        284,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Samona.Ferrigno@gmail.com',
        '+392172272328',
        '["/static/images/4451e87f-0108-4fd7-872b-fa91671f8104.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        1,
        48::numeric(12,2),
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Ildegarda De Gregorio',
        'https://front-lawn.it',
        324.074,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Rubiano_Natale@yahoo.it',
        '+391791291755',
        '["/static/images/872ff603-5819-4c1c-a4bc-cee33e1db7dd.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        2,
        123::numeric(12,2),
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Concordio Postiglione',
        'https://profitable-accelerant.com',
        280.8,
        '09:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Tarquinia46@gmail.com',
        '+392372949725',
        '["/static/images/dc748eef-5832-462c-b8ea-565a7beb4298.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        2,
        50::numeric(12,2),
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Ella Cascone',
        'http://sophisticated-hearth.net',
        266.152,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Zaira_Morra@yahoo.com',
        '+391085712642',
        '["/static/images/3abd12a2-ca82-4d5e-b93f-c4bf780d74b3.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        7,
        124::numeric(12,2),
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Oscar Pizzitola',
        'http://constant-complicity.com',
        304.002,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Romualdo.Zanetti@gmail.com',
        '+399019271725',
        '["/static/images/4451e87f-0108-4fd7-872b-fa91671f8104.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        3,
        55::numeric(12,2),
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Cremenzio Turchi',
        'http://weekly-noon.com',
        319.835,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Vedasto86@libero.it',
        '+398894518618',
        '["/static/images/3abd12a2-ca82-4d5e-b93f-c4bf780d74b3.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        5,
        135::numeric(12,2),
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Giorgio Passeri',
        'http://worrisome-officer.it',
        281.153,
        '09:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Concetta.Ferrarini@email.it',
        '+397076493339',
        '["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        10,
        46::numeric(12,2),
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Alfonsa Motisi',
        'http://cluttered-yin.it',
        314.247,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Dolores_Petrone43@yahoo.it',
        '+398678541747',
        '["/static/images/22233684-687e-4f05-832d-2edc726209fb.jpg","/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        3,
        121::numeric(12,2),
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Donna Caterino',
        'http://prize-tanker.com',
        336.356,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Cassandra.Clemente@gmail.com',
        '+392735740271',
        '["/static/images/22233684-687e-4f05-832d-2edc726209fb.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        8,
        69::numeric(12,2),
        'Wittener Hütte',
        'Germany',
        'Franca Dell''Amico',
        'https://strong-inglenook.com',
        280.809,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Luana.Saccone@hotmail.com',
        '+394103633449',
        '["/static/images/0671e710-77e3-41ad-ac94-973a8aa4d10e.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        8,
        55::numeric(12,2),
        'Hochjoch-Hospiz',
        'Austria',
        'Venusta Iannone',
        'http://dental-meteorology.it',
        303.426,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Teudosia.Galluzzo@gmail.com',
        '+398655320033',
        '["/static/images/bcb89119-072b-4034-b2f6-5df38bfbd34c.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        1,
        86::numeric(12,2),
        'Meilerhütte',
        'Germany',
        'Milo Orlandi',
        'https://sinful-washtub.com',
        268.306,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Clemenzia.Femina@email.it',
        '+390139104946',
        '["/static/images/95ab3575-30d3-4c94-a91f-0f2bac28e717.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        6,
        104::numeric(12,2),
        'Gaudeamushütte',
        'Austria',
        'Armida Pierro',
        'http://energetic-following.net',
        282.714,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Casimiro_DeAngelis@email.it',
        '+396725429882',
        '["/static/images/3abd12a2-ca82-4d5e-b93f-c4bf780d74b3.jpg","/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        2,
        97::numeric(12,2),
        'Rheydter Hütte',
        'Germany',
        'Tiziano Lo Presti',
        'http://elementary-pasture.org',
        296.715,
        '01:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Floriano58@libero.it',
        '+391229668017',
        '["/static/images/0671e710-77e3-41ad-ac94-973a8aa4d10e.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        10,
        102::numeric(12,2),
        'Sektionshütte Krippen',
        'Germany',
        'Flora Pratesi',
        'http://boring-log.com',
        321.864,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Minerva_Pastorino85@libero.it',
        '+395503747794',
        '["/static/images/c4b3fba9-e26e-4fb0-a093-78dac6a2f062.jpg","/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        8,
        120::numeric(12,2),
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Mattia Zanella',
        'https://dazzling-mean.com',
        279.344,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Uliva.Atzeni@yahoo.it',
        '+395268989475',
        '["/static/images/3abd12a2-ca82-4d5e-b93f-c4bf780d74b3.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        1,
        83::numeric(12,2),
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Gemma Femina',
        'https://funny-singular.it',
        298.651,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Angelica8@yahoo.it',
        '+394703791166',
        '["/static/images/872ff603-5819-4c1c-a4bc-cee33e1db7dd.jpg","/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        4,
        139::numeric(12,2),
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Dr. Astianatte De Vita',
        'https://educated-songbird.com',
        274.968,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Beata69@gmail.com',
        '+395532391540',
        '["/static/images/6d3e3fa9-dedb-4c76-8d2e-1efd1026617d.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        9,
        119::numeric(12,2),
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Dott. Taziano Matteucci',
        'https://massive-earplug.it',
        321.44,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Ebe.Marinucci68@gmail.com',
        '+395379570686',
        '["/static/images/eb0a64be-eeba-49fb-b952-227f7ad04a48.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        7,
        61::numeric(12,2),
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Marcella Fior',
        'http://terrific-river.net',
        323.542,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Settimio_Zaccaro34@email.it',
        '+394528378236',
        '["/static/images/c3704bc1-511d-4d88-8554-edb5bcbd5b74.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        4,
        136::numeric(12,2),
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Rosa Cardinale',
        'https://easy-going-fifth.it',
        279.696,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Tesifonte73@gmail.com',
        '+397142222411',
        '["/static/images/6d3e3fa9-dedb-4c76-8d2e-1efd1026617d.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        9,
        118::numeric(12,2),
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Giuliana Iaria',
        'http://beloved-moose.org',
        276.38,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Odorico.Vannini25@yahoo.it',
        '+393840787903',
        '["/static/images/bcb89119-072b-4034-b2f6-5df38bfbd34c.jpg","/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg","/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        2,
        116::numeric(12,2),
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Sefora Montanaro',
        'http://deserted-afoul.it',
        275.3,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Ruggero67@libero.it',
        '+390740904391',
        '["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        7,
        42::numeric(12,2),
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Fabiana La Sala',
        'https://darling-stepdaughter.org',
        286.333,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Daria_Sartor14@yahoo.it',
        '+392617763619',
        '["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        9,
        137::numeric(12,2),
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Dr. Caronte Praticò',
        'https://corrupt-netbook.net',
        269.921,
        '03:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Miriam.Montagner@yahoo.it',
        '+390116918349',
        '["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg","/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        6,
        36::numeric(12,2),
        'Dobra voda',
        'Suvobor, Serbia',
        'Cirino Ferri',
        'http://jam-packed-nickname.org',
        301.78,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Caterina_Caccavo@email.it',
        '+391443339759',
        '["/static/images/67c24cb6-647b-434e-a296-40a071d11211.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        9,
        80::numeric(12,2),
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Genesio Barletta',
        'http://second-hand-zampone.org',
        271.53,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Venerando.Saccone@yahoo.it',
        '+395080902700',
        '["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        4,
        135::numeric(12,2),
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Diego Lippi',
        'http://showy-scorn.net',
        323.03,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Pericle_Vinci@yahoo.com',
        '+399153148071',
        '["/static/images/6618e934-60ac-4e23-ab86-d8dd255db78d.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        2,
        93::numeric(12,2),
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Prudenzio Tralli',
        'https://aggravating-fillet.it',
        290.378,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Matteo.Simeoni58@yahoo.it',
        '+395189514248',
        '["/static/images/dc748eef-5832-462c-b8ea-565a7beb4298.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        7,
        49::numeric(12,2),
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Nives Prato',
        'http://creative-keyboard.net',
        336.271,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Leonida.Passeri36@yahoo.it',
        '+399706861320',
        '["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        3,
        129::numeric(12,2),
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Secondiano Celentano',
        'https://short-term-feeding.it',
        302.233,
        '09:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Alboino.Pascarella12@libero.it',
        '+395563203954',
        '["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg","/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg","/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        5,
        79::numeric(12,2),
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Ing. Brigida Vailati',
        'https://cute-weedkiller.net',
        275.977,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Fabio90@yahoo.com',
        '+390883084561',
        '["/static/images/0671e710-77e3-41ad-ac94-973a8aa4d10e.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg","/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        4,
        93::numeric(12,2),
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Annabella Migliore',
        'https://famous-diversity.it',
        328.03,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Raide.Liccardo83@libero.it',
        '+398728865165',
        '["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        9,
        73::numeric(12,2),
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Macaria Pappalardo',
        'http://defensive-timbale.net',
        277.325,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Ortensio_Mosca63@gmail.com',
        '+399146824130',
        '["/static/images/c4b3fba9-e26e-4fb0-a093-78dac6a2f062.jpg","/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg","/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        4,
        131::numeric(12,2),
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Teresa Di Pede',
        'https://entire-tailspin.it',
        308.178,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Selene_Ghilardi86@yahoo.com',
        '+398230459591',
        '["/static/images/95ab3575-30d3-4c94-a91f-0f2bac28e717.jpg","/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg","/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg","/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg","/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        4,
        67::numeric(12,2),
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Apollina Tirelli',
        'http://kindly-rabbi.net',
        334.662,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Ulstano.Casali51@libero.it',
        '+399515051730',
        '["/static/images/dc748eef-5832-462c-b8ea-565a7beb4298.jpg","/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg","/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg","/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg","/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg"]'::jsonb
      );
    
  

      CREATE OR REPLACE FUNCTION public.insert_hut_worker(
        hwid integer,
        email varchar,
        password varchar,
        first_name varchar,
        last_name varchar,
        role integer,
        hut_id integer,
        approved boolean
      ) RETURNS VOID AS
      $func$
      DECLARE
        user_id integer;
      BEGIN
      INSERT INTO "public"."users" (
        "id",
        "email",
        "password",
        "firstName",
        "lastName",
        "role",
        "verified",
        "approved"
      ) VALUES(
        hwid, email, password, first_name, last_name, role, true, approved
      ) returning id into user_id;

      INSERT INTO "public"."hut-worker" (
        "userId",
        "hutId"
      ) VALUES ( user_id, hut_id);
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hut_worker"(
        7,
        'hutWorker0@gmail.com',
        '$2b$10$gF1RwkxSs/Xz7j9gsmUOrujxOke0clLxJMYlVGZEuXAuVj65TeLSi',
        'Armida',
        'Pedrazzini',
        4,
        1,
        true
      );
    

      select public."insert_hut_worker"(
        8,
        'hutWorker1@gmail.com',
        '$2b$10$3/tHXxcdcJ10jbMxDdYbxu641SyEikcWJzh9t6mpTTTgfKExAECl6',
        'Ascanio',
        'Evola',
        4,
        2,
        false
      );
    

      select public."insert_hut_worker"(
        9,
        'hutWorker2@gmail.com',
        '$2b$10$ucMLMQHy6i29eKojnlsUNOw4IDpsPYr3sxV67Ye81qUKu.l6DDXRm',
        'Boris',
        'Corrado',
        4,
        3,
        true
      );
    

      select public."insert_hut_worker"(
        10,
        'hutWorker3@gmail.com',
        '$2b$10$uXNCvctE2jEbW0SWI56mcOdmlGV.ILO57P/q/hcHcIHV3TR3/7FHS',
        'Priamo',
        'Di Dio',
        4,
        4,
        false
      );
    

      select public."insert_hut_worker"(
        11,
        'hutWorker4@gmail.com',
        '$2b$10$Aqhd5gtUDcuEnl.TlijkFupHlKA1Dlnddh.QmAWiXezahkaZQKH9q',
        'Magda',
        'Palano',
        4,
        5,
        true
      );
    

      select public."insert_hut_worker"(
        12,
        'hutWorker5@gmail.com',
        '$2b$10$.DpomHQzaVZl2Pzccc/H9uDcuidrwikU5vRruZUKERBLN4pNuVeaO',
        'Alessandra',
        'Carrara',
        4,
        6,
        false
      );
    

      select public."insert_hut_worker"(
        13,
        'hutWorker6@gmail.com',
        '$2b$10$MTJb2LyIBgZP/FcnE/LguOqLUDhq8nti14pJDGCE/ajfYANfuUJM6',
        'Lamberto',
        'Montanaro',
        4,
        7,
        true
      );
    

      select public."insert_hut_worker"(
        14,
        'hutWorker7@gmail.com',
        '$2b$10$i14abM8jbFlH7aDSKHeeee/XLeN22qoaE7/FDq9eaNwclkHZRa7Q2',
        'Eugenia',
        'Liguori',
        4,
        8,
        false
      );
    

      select public."insert_hut_worker"(
        15,
        'hutWorker8@gmail.com',
        '$2b$10$gEE3AjQceLDoLnZuOEXHZ.UwJtS.campgKbh70lee/dJ3EREfHGZ6',
        'Livia',
        'Cerri',
        4,
        9,
        true
      );
    

      select public."insert_hut_worker"(
        16,
        'hutWorker9@gmail.com',
        '$2b$10$pi5ybDtDnjpGRGqFOOatOebW.p..oaHYyE283/2LhJik/WmhGUgrq',
        'Dina',
        'Maresca',
        4,
        10,
        false
      );
    

      select public."insert_hut_worker"(
        17,
        'hutWorker10@gmail.com',
        '$2b$10$dACuCW3SDr/yuVSAZ/YWmutf63pHn/c96HlKBK46ydwvk8XS./1uO',
        'Lavinia',
        'Salvatore',
        4,
        11,
        true
      );
    

      select public."insert_hut_worker"(
        18,
        'hutWorker11@gmail.com',
        '$2b$10$U293OUDTWAzrXUloEWB8HOjdqG3UoU/pWkaeuHvFfhXYGHAlvkThC',
        'Ferruccio',
        'Pitzalis',
        4,
        12,
        false
      );
    

      select public."insert_hut_worker"(
        19,
        'hutWorker12@gmail.com',
        '$2b$10$tJbJ7JUG4dFS0VPMDgE8du5nevBd7lpaBELpc3E/oPFM9HFYkBHmC',
        'Monica',
        'Bellomo',
        4,
        13,
        true
      );
    

      select public."insert_hut_worker"(
        20,
        'hutWorker13@gmail.com',
        '$2b$10$8YYe1ubIaxZ8YXkQ8gRgoewEWGQ6viu6DnRzyZ6ncLFSR7.M.1xVe',
        'Lucrezia',
        'Galeazzi',
        4,
        14,
        false
      );
    

      select public."insert_hut_worker"(
        21,
        'hutWorker14@gmail.com',
        '$2b$10$yomX6TjN7pl.jNG6CJ7HpeEHucWQy3gXCFHIcwY0YvxZrNI7bfdma',
        'Adelgardo',
        'Pollina',
        4,
        15,
        true
      );
    

      select public."insert_hut_worker"(
        22,
        'hutWorker15@gmail.com',
        '$2b$10$sLplYpMkidItcbOoTyjnt.Un5c9w3W3Ap9T/r9Rv.FwARhf.EP1K6',
        'Aristione',
        'De Santis',
        4,
        16,
        false
      );
    

      select public."insert_hut_worker"(
        23,
        'hutWorker16@gmail.com',
        '$2b$10$yVnrlqVi5HUD8YrunldyWOkeEps73ejzI6F4hLIUGgV0INwKs/ZTG',
        'Albina',
        'Girardi',
        4,
        17,
        true
      );
    

      select public."insert_hut_worker"(
        24,
        'hutWorker17@gmail.com',
        '$2b$10$sm7ds1DWiSukNbxvjuZOKOmM52W4473MMVuYXaOLIq3A/.qI2Xt4.',
        'Gemma',
        'Centofanti',
        4,
        18,
        false
      );
    

      select public."insert_hut_worker"(
        25,
        'hutWorker18@gmail.com',
        '$2b$10$A11y8GwOksd4MKYeMln4ouZDktRySMmoM2aKv7JHtYtp15e4iioFy',
        'Licia',
        'Ranieri',
        4,
        19,
        true
      );
    

      select public."insert_hut_worker"(
        26,
        'hutWorker19@gmail.com',
        '$2b$10$37iZdUAgFzzcpk0eu6QyV.uWs/1h.8b41higuCzi.y5x94ul4dKOS',
        'Rosmunda',
        'Tonelli',
        4,
        20,
        false
      );
    

      select public."insert_hut_worker"(
        27,
        'hutWorker20@gmail.com',
        '$2b$10$y.Y3SpKQcLvxO.znZKiUYONfOlHF3oy9zDojNRPD.ia46YSjONgs6',
        'Melitina',
        'Luchetti',
        4,
        21,
        true
      );
    

      select public."insert_hut_worker"(
        28,
        'hutWorker21@gmail.com',
        '$2b$10$UMfO6puWTWVkBTrIvm.kb.jZZyjesD0rcIceIhQovzogdwYqzM572',
        'Mirta',
        'Montalbano',
        4,
        22,
        false
      );
    

      select public."insert_hut_worker"(
        29,
        'hutWorker22@gmail.com',
        '$2b$10$0Zpsz7LqLmLC.mqgeErROerimksYmc0mP605I/zDO8stdhJDFmIUS',
        'Basilio',
        'Rizzi',
        4,
        23,
        true
      );
    

      select public."insert_hut_worker"(
        30,
        'hutWorker23@gmail.com',
        '$2b$10$grwr6C/dKKy8suDHfLUid.1EDiAQIjXrhPTgVMJtIQDki1Sk9ltp6',
        'Doroteo',
        'Del Prete',
        4,
        24,
        false
      );
    

      select public."insert_hut_worker"(
        31,
        'hutWorker24@gmail.com',
        '$2b$10$AzAP1kqkoIn0ZeS9DWFQheQvniNkSirD.eP2unR5BxTOObhmW1Z1.',
        'Manfredo',
        'Oliviero',
        4,
        25,
        true
      );
    

      select public."insert_hut_worker"(
        32,
        'hutWorker25@gmail.com',
        '$2b$10$DV3chTLcOa11cdU34hY4g.z7.eV/9eDZodjVrpQ52CRXrxilIxlo6',
        'Ambra',
        'Riccio',
        4,
        26,
        false
      );
    

      select public."insert_hut_worker"(
        33,
        'hutWorker26@gmail.com',
        '$2b$10$WhUC/yPFCiLPwpg2DUjnu.DrW46NSv4vnLX9nIcm.8j.nqMJEzku6',
        'Giotto',
        'Guarneri',
        4,
        27,
        true
      );
    

      select public."insert_hut_worker"(
        34,
        'hutWorker27@gmail.com',
        '$2b$10$lFlZl1ojsh.uQ8NqNnRa3Opwc.iDB87IZFToGOL6/PGm47hXKkDHm',
        'Luciana',
        'Pizzi',
        4,
        28,
        false
      );
    

      select public."insert_hut_worker"(
        35,
        'hutWorker28@gmail.com',
        '$2b$10$M7GecpMaIy01AyPNuTFO1.sZLM9nnqHRmyWWD6NsAkL9zYqa5wLfu',
        'Savino',
        'Passuello',
        4,
        29,
        true
      );
    

      select public."insert_hut_worker"(
        36,
        'hutWorker29@gmail.com',
        '$2b$10$K6p.ejz.f3nhVR10358XDuEo/LPZDucCODVtM5GDKzOcSxqrD.U8K',
        'Cristiano',
        'Tumino',
        4,
        30,
        false
      );
    

      select public."insert_hut_worker"(
        37,
        'hutWorker30@gmail.com',
        '$2b$10$yp4jUzFyRdmDOp75R13JPO5ffdg9NY6PfsOry/1mT9a6O9nLp5oVe',
        'Messalina',
        'Natali',
        4,
        31,
        true
      );
    

      select public."insert_hut_worker"(
        38,
        'hutWorker31@gmail.com',
        '$2b$10$U9JbJtMWzYyZ3Y3Q8o5yV.fGrzFLjAShtmdlY3FypgGOz2UGpddY.',
        'Ovidio',
        'De Lucia',
        4,
        32,
        false
      );
    

      select public."insert_hut_worker"(
        39,
        'hutWorker32@gmail.com',
        '$2b$10$cNpSz293dcjDA6CcnMYDzOMo7Yy0Dhtuus/1yNp16J4HHboBBf7cu',
        'Emma',
        'Iuliano',
        4,
        33,
        true
      );
    

      select public."insert_hut_worker"(
        40,
        'hutWorker33@gmail.com',
        '$2b$10$OyH/0wGW/4XqQtKXglnciOstSXSllBFAP/Q0QUP8Nn0UgR4.penJe',
        'Ultimo',
        'Ballarin',
        4,
        34,
        false
      );
    

      select public."insert_hut_worker"(
        41,
        'hutWorker34@gmail.com',
        '$2b$10$i64EoOetS4PqvNvQWEpjvOEz1K2De0IHBvCTcPQvTlF4ppFIG9WKq',
        'Agesilao',
        'Cerrato',
        4,
        35,
        true
      );
    

      select public."insert_hut_worker"(
        42,
        'hutWorker35@gmail.com',
        '$2b$10$J7X5yb7FMaE4K/asAGtk4O3faB4Pxkjg/9O1T0GhqamQR6oLKa5x.',
        'Ippocrate',
        'Fasano',
        4,
        36,
        false
      );
    

      select public."insert_hut_worker"(
        43,
        'hutWorker36@gmail.com',
        '$2b$10$rypL6Q.sakmhXLrhi30NVeb3WgrVDP6Z75R9oWpupP/bgymLsFc5u',
        'Floriana',
        'Albano',
        4,
        37,
        true
      );
    

      select public."insert_hut_worker"(
        44,
        'hutWorker37@gmail.com',
        '$2b$10$/QteuAC2jYS5z7.28TkBqeTdnt5ECjaezsqqUEiYN4W2NROgjLiY.',
        'Zanita',
        'Lodi',
        4,
        38,
        false
      );
    

      select public."insert_hut_worker"(
        45,
        'hutWorker38@gmail.com',
        '$2b$10$FvUrNfyQBU3IozZh/57Zo..k6dwFzErQeNH/CfHCMrceUubSfylfW',
        'Egidio',
        'Vacca',
        4,
        39,
        true
      );
    

      select public."insert_hut_worker"(
        46,
        'hutWorker39@gmail.com',
        '$2b$10$9U98fYbiIULVpwDOY28JaOXINNOUmWC.j4afZPibaPuPMcwVpY.8q',
        'Gianmarco',
        'Costantini',
        4,
        40,
        false
      );
    

      select public."insert_hut_worker"(
        47,
        'hutWorker40@gmail.com',
        '$2b$10$nUnIGXJvkRuuzpRRPTO.h.70o439UzOxjDh.wxCV4jR.Vr8yX3U4K',
        'Ornella',
        'Bongiovanni',
        4,
        41,
        true
      );
    

      select public."insert_hut_worker"(
        48,
        'hutWorker41@gmail.com',
        '$2b$10$n.MyE/XSA16n/dx7ghGSbOAjK8vzeVt03ONc2QsS95Aw6isdzTmbC',
        'Giacinta',
        'Narciso',
        4,
        42,
        false
      );
    

      select public."insert_hut_worker"(
        49,
        'hutWorker42@gmail.com',
        '$2b$10$r0zwWh4nD8NE.6fCPrl19.6WFe7pZjJGNJGnwNQuNUSMTHD5ofYN.',
        'Margherita',
        'Buzzi',
        4,
        43,
        true
      );
    

      select public."insert_hut_worker"(
        50,
        'hutWorker43@gmail.com',
        '$2b$10$Fwcoib0/ShfFAvRWDrY4y.qgNer9u4w9b8.d4OYuZuImr48jhScwi',
        'Adalgisa',
        'Benvenuto',
        4,
        44,
        false
      );
    

      select public."insert_hut_worker"(
        51,
        'hutWorker44@gmail.com',
        '$2b$10$N91xEnntWi4f6hCpHeSpBOPD5YxbszRdz3WBnyWY8vbKP2NPpTMOO',
        'Carmela',
        'Sarti',
        4,
        45,
        true
      );
    

      select public."insert_hut_worker"(
        52,
        'hutWorker45@gmail.com',
        '$2b$10$PYZNv3e/PnPFr57wqbX0y.URfmWWhxltLJvWR2YYL4lo4wAWGGxti',
        'Samanta',
        'Tiberti',
        4,
        46,
        false
      );
    

      select public."insert_hut_worker"(
        53,
        'hutWorker46@gmail.com',
        '$2b$10$a5qen9x/J/ebxogxeodICui0ih7Kt1PVI.qb4bLx/zLiMJvHoylOq',
        'Rosamunda',
        'Landi',
        4,
        47,
        true
      );
    

      select public."insert_hut_worker"(
        54,
        'hutWorker47@gmail.com',
        '$2b$10$2LHYft5YXYwqGXJl0pSFyOC9Q5/XCY/1duFVDja1INYgfyLeNpVeC',
        'Siria',
        'Mangano',
        4,
        48,
        false
      );
    

      select public."insert_hut_worker"(
        55,
        'hutWorker48@gmail.com',
        '$2b$10$qNtk.jHvoYi49/5ltXqimODe6UnGCRwMjisMgiBUpo0iwkAYzce.S',
        'Patrizio',
        'Manzi',
        4,
        49,
        true
      );
    

      select public."insert_hut_worker"(
        56,
        'hutWorker49@gmail.com',
        '$2b$10$1lp5ihkzvYZNKy.QueYr1OhMXgG6126BXKrOqtk4dYEn.HQl1YkPm',
        'Assunta',
        'Rusciano',
        4,
        50,
        false
      );
    

      select public."insert_hut_worker"(
        57,
        'hutWorker50@gmail.com',
        '$2b$10$nQBJndLXCDoNcXVthXAM7.oQN964b3qUjVupoAsNIkpt0DPRTlPvW',
        'Ausilio',
        'Faraci',
        4,
        51,
        true
      );
    

      select public."insert_hut_worker"(
        58,
        'hutWorker51@gmail.com',
        '$2b$10$dRg09wkX2sxSm72kEK88D.vOzkgqy3Re2.588haK2kDWEizbUZlEm',
        'Taddeo',
        'Boschetti',
        4,
        52,
        false
      );
    

      select public."insert_hut_worker"(
        59,
        'hutWorker52@gmail.com',
        '$2b$10$mWTp8Zh/I0v1v3xDUphICeDYudlnJwq2wyEx/.zGjyk.bHcRsfqu.',
        'Martina',
        'Tofani',
        4,
        53,
        true
      );
    

      select public."insert_hut_worker"(
        60,
        'hutWorker53@gmail.com',
        '$2b$10$UYTivpi5JjxxUUDKSbz4AeWrY2KXcuiOteZpdx1RJ.Ls3RSanRLmW',
        'Ettore',
        'Mele',
        4,
        54,
        false
      );
    

      select public."insert_hut_worker"(
        61,
        'hutWorker54@gmail.com',
        '$2b$10$nHp7G1LeEbifpwSE5WrDvecERPCnJ.qNHqDApIwixs/vTB8qkKGJW',
        'Donatello',
        'Cherubini',
        4,
        55,
        true
      );
    

      select public."insert_hut_worker"(
        62,
        'hutWorker55@gmail.com',
        '$2b$10$LK.Q8FRfI7h3oWerSjpH..is4OXsmCbgmjVTm/UyrtVAjgYup4VZ6',
        'Nilde',
        'Simonini',
        4,
        56,
        false
      );
    

      select public."insert_hut_worker"(
        63,
        'hutWorker56@gmail.com',
        '$2b$10$VrkbwmxOgNUG2zFTL5Ae4OhlNKGKfsPposItLo3FJUUWm2sKAECge',
        'Imelda',
        'Argenio',
        4,
        57,
        true
      );
    

      select public."insert_hut_worker"(
        64,
        'hutWorker57@gmail.com',
        '$2b$10$7qAhXlnhkjZ3oM5IEEsaaeRD5Bz8PZnTlRB0iizMeOOaBofQHjxPm',
        'Leonida',
        'Caggiano',
        4,
        58,
        false
      );
    

      select public."insert_hut_worker"(
        65,
        'hutWorker58@gmail.com',
        '$2b$10$SmYKkA.RCH2oWgcrhbOR8.bqiqahefHIBX6gZ7Vi2.ntCCyfBN7py',
        'Sabina',
        'Altieri',
        4,
        59,
        true
      );
    

      select public."insert_hut_worker"(
        66,
        'hutWorker59@gmail.com',
        '$2b$10$YrsdPmxwolVNfKqb/UtMEuK0jjlDM36GD9qyA9bt2P.wW12Mbdh/O',
        'Placido',
        'Foglia',
        4,
        60,
        false
      );
    

      select public."insert_hut_worker"(
        67,
        'hutWorker60@gmail.com',
        '$2b$10$pGIKGpxQtiLTR.NnxN3IGeO00Opeb.67yCMGPXxqRMhEzVeLmdLBO',
        'Quiteria',
        'Catarsi',
        4,
        61,
        true
      );
    

      select public."insert_hut_worker"(
        68,
        'hutWorker61@gmail.com',
        '$2b$10$DG8uZP/B.80s6dYSDPhAXOEY/o7N4jOSXY4uS5nttih14bfRGIniy',
        'Desdemona',
        'Carrozzo',
        4,
        62,
        false
      );
    

      select public."insert_hut_worker"(
        69,
        'hutWorker62@gmail.com',
        '$2b$10$XpAnHoQSNLa6S5WLdgYcBeGi49oEpRz55uEg.qPz3B49GH3Onyf4m',
        'Giambattista',
        'Gambino',
        4,
        63,
        true
      );
    

      select public."insert_hut_worker"(
        70,
        'hutWorker63@gmail.com',
        '$2b$10$3APAZXHiIa8B5fxqVqZyGOlcXJfbSwilo/ZGEqiHnwgsiu5VQDdNS',
        'Flaminia',
        'Mazzotta',
        4,
        64,
        false
      );
    

      select public."insert_hut_worker"(
        71,
        'hutWorker64@gmail.com',
        '$2b$10$k/YHSPH8PFEuWHKfTYaYTOnlyae6j5Xq0L77oj2yfiS7/yvtu5PVu',
        'Boris',
        'Medici',
        4,
        65,
        true
      );
    

      select public."insert_hut_worker"(
        72,
        'hutWorker65@gmail.com',
        '$2b$10$JBsk.uJNCxbeF/i74Ke2reDcAjKj8Iqn1cBmRAp3al/4Va4w6OeTC',
        'Venusta',
        'Bertani',
        4,
        66,
        false
      );
    

      select public."insert_hut_worker"(
        73,
        'hutWorker66@gmail.com',
        '$2b$10$Gw47AScCthtSHx.NUPjd4etkPEu335t7SOcjEWJTbGjGkNY851wuG',
        'Antonia',
        'Gioia',
        4,
        67,
        true
      );
    

      select public."insert_hut_worker"(
        74,
        'hutWorker67@gmail.com',
        '$2b$10$vifha.Xzp7YBmukWc2rRYu5nHq45z.e57LSXikZv.Y4AW1fhRloFe',
        'Cuzia',
        'Grosso',
        4,
        68,
        false
      );
    

      select public."insert_hut_worker"(
        75,
        'hutWorker68@gmail.com',
        '$2b$10$OBvcdssT12APyRhd.ezKVObT.F2.Ii5ocUb6OURhK11ksZl.bWXH6',
        'Adelaide',
        'Narcisi',
        4,
        69,
        true
      );
    

      select public."insert_hut_worker"(
        76,
        'hutWorker69@gmail.com',
        '$2b$10$vgm66i8o3MXk5hYgAVQNjO7kJuimk1XOgdZPO8qzsO7gKYsuFVxAm',
        'Fazio',
        'Coccia',
        4,
        70,
        false
      );
    

      select public."insert_hut_worker"(
        77,
        'hutWorker70@gmail.com',
        '$2b$10$0eZ8vRw7jxeLPDLnvkBT8.PqFd2wwDZbZAabwyRb1Ya9lWJccVfNe',
        'Roberta',
        'D''Amore',
        4,
        71,
        true
      );
    

      select public."insert_hut_worker"(
        78,
        'hutWorker71@gmail.com',
        '$2b$10$NymAoXK3bzV1wwPDz7qsQODYk.r2QmGu7nhuPfLhGVtdPnzTNK2uO',
        'Tecla',
        'Pasquini',
        4,
        72,
        false
      );
    

      select public."insert_hut_worker"(
        79,
        'hutWorker72@gmail.com',
        '$2b$10$4BovtmhaRFFx256nkjngLuwhnX6TE7Ah17ov6bnnIiReRNOjcMLSq',
        'Osanna',
        'Cammarata',
        4,
        73,
        true
      );
    

      select public."insert_hut_worker"(
        80,
        'hutWorker73@gmail.com',
        '$2b$10$KHgfNxK5UWBlE4lAdXWWrOrnfUyIqR83SfanTxEZZ8nalzoWkijFe',
        'Severa',
        'Siino',
        4,
        74,
        false
      );
    

      select public."insert_hut_worker"(
        81,
        'hutWorker74@gmail.com',
        '$2b$10$TuOGte97FfNhX2BiTMWMLuv6TZw5sFL0fdTKwam34GmiPe6ghBSaa',
        'Osvaldo',
        'Cipriano',
        4,
        75,
        true
      );
    

      select public."insert_hut_worker"(
        82,
        'hutWorker75@gmail.com',
        '$2b$10$pVGOe/qXRUese.qQwtw1XOxJfab1jIkAa.Ws.For.FBpCpkTa50gG',
        'Graciliano',
        'Favara',
        4,
        76,
        false
      );
    

      select public."insert_hut_worker"(
        83,
        'hutWorker76@gmail.com',
        '$2b$10$L0hMYaT6qlVp8OZIzh1cI.pZI/i/WJVLhgbgJOCRnNY.QX3ZMf6P.',
        'Lodovico',
        'Tucci',
        4,
        77,
        true
      );
    

      select public."insert_hut_worker"(
        84,
        'hutWorker77@gmail.com',
        '$2b$10$/kaPrdMIBwBD5qCpXCDEK.guqzd1bqzq9gHiz2p/TLrNPzvsax7PS',
        'Valentina',
        'Santarsiero',
        4,
        78,
        false
      );
    

      select public."insert_hut_worker"(
        85,
        'hutWorker78@gmail.com',
        '$2b$10$NbNmfzwAADG/egT6qqpnPuAjZOk1CVITtRFwMDF0eKX7C0Lk4Ayjq',
        'Virone',
        'De Carolis',
        4,
        79,
        true
      );
    

      select public."insert_hut_worker"(
        86,
        'hutWorker79@gmail.com',
        '$2b$10$5Y4DKkeubiVra.xXwz6LNuHBJtpXZ1z.xTGZ.nix21dmif/XeqUwa',
        'Euclide',
        'Daniele',
        4,
        80,
        false
      );
    

      select public."insert_hut_worker"(
        87,
        'hutWorker80@gmail.com',
        '$2b$10$V0rP21Bs2S7I72YBXE/fJ.1vqLg66kkn6QvpfqaPIjNqk.8yg/Vs.',
        'Fernanda',
        'De Rosa',
        4,
        81,
        true
      );
    

      select public."insert_hut_worker"(
        88,
        'hutWorker81@gmail.com',
        '$2b$10$dss.w3K2zjgnGJzrRxGuJuqKk20IAh0mkIr9vT0w9sAfMN7JZFvSW',
        'Venusto',
        'Liberati',
        4,
        82,
        false
      );
    

      select public."insert_hut_worker"(
        89,
        'hutWorker82@gmail.com',
        '$2b$10$LH/IX8wb06j6dBerbsavf.Fsf5ujAunhWnhAvEIjKxqO0Nz8gH.sG',
        'Crescenzio',
        'Golinelli',
        4,
        83,
        true
      );
    

      select public."insert_hut_worker"(
        90,
        'hutWorker83@gmail.com',
        '$2b$10$i3a4bfNc02B2ft5SBCmgsuQDZ93kZeeSuB7MavQf59e5RwzM2w1T6',
        'Marinetta',
        'Aprile',
        4,
        84,
        false
      );
    

      select public."insert_hut_worker"(
        91,
        'hutWorker84@gmail.com',
        '$2b$10$fXJz9YKXUqnNZ1X.OFrcUuPG7/kd6uhngekNNuh5qKoX89KLwG7fS',
        'Sabrina',
        'Manica',
        4,
        85,
        true
      );
    

      select public."insert_hut_worker"(
        92,
        'hutWorker85@gmail.com',
        '$2b$10$PqeAbLu2H5FjpLzglrWXPuaoV1AmuDNp5HtC3t/X3wd3qmdQ3nbk2',
        'Irma',
        'Cusumano',
        4,
        86,
        false
      );
    

      select public."insert_hut_worker"(
        93,
        'hutWorker86@gmail.com',
        '$2b$10$MhFB7AJyFpLvhxBusr8JT.TgyVKfhDtcjY0wGrTArtNAik1qTQ6XC',
        'Beato',
        'Scognamiglio',
        4,
        87,
        true
      );
    

      select public."insert_hut_worker"(
        94,
        'hutWorker87@gmail.com',
        '$2b$10$xH.J/rgP65CKj66w5u2TieV1mKrWsXFxTV1OT18aoc3SUaiSlrMZC',
        'Carmela',
        'Cavalli',
        4,
        88,
        false
      );
    

      select public."insert_hut_worker"(
        95,
        'hutWorker88@gmail.com',
        '$2b$10$sTv/fulafgTi4fmZZ5W8Fuijvw5SME45jbH/fsRZE7GCWokrPyosW',
        'Lia',
        'Bedini',
        4,
        89,
        true
      );
    

      select public."insert_hut_worker"(
        96,
        'hutWorker89@gmail.com',
        '$2b$10$lMmrYXsOTk2il8XhIuWHSO37GNqzpeMH4XJL26L4d4LighT/n2jwK',
        'Euclide',
        'Caradonna',
        4,
        90,
        false
      );
    

      select public."insert_hut_worker"(
        97,
        'hutWorker90@gmail.com',
        '$2b$10$QFXuwXkfKHuks8KwT5o.YukiXeGS3oInRDPM4gpeH3Ir1hUvtW3CO',
        'Santina',
        'Tallarico',
        4,
        91,
        true
      );
    

      select public."insert_hut_worker"(
        98,
        'hutWorker91@gmail.com',
        '$2b$10$Y2PP7TYU7KHyui1iMUfYf.IRjgFfRpRufe2.dfGvQoqYhfLdshc7m',
        'Rossella',
        'Scherini',
        4,
        92,
        false
      );
    

      select public."insert_hut_worker"(
        99,
        'hutWorker92@gmail.com',
        '$2b$10$XuIIN0WwJeM7UCj.izHZUuYy3u.PoCeKwwZvMaCSGv7woGix5JGt.',
        'Viola',
        'Ruberto',
        4,
        93,
        true
      );
    

      select public."insert_hut_worker"(
        100,
        'hutWorker93@gmail.com',
        '$2b$10$6TTutyVB0tw0yZOrCKyaMeF8wYOZ8yF09WxqV7WaYJz/xirml5M4K',
        'Deodato',
        'Concas',
        4,
        94,
        false
      );
    

      select public."insert_hut_worker"(
        101,
        'hutWorker94@gmail.com',
        '$2b$10$JwaBQwqKZBzdJmRncavxxeyt5H8ep1zA1CMPlotrChZ0RlGYazuwe',
        'Prisca',
        'Cavalieri',
        4,
        95,
        true
      );
    

      select public."insert_hut_worker"(
        102,
        'hutWorker95@gmail.com',
        '$2b$10$zlfrNpZjJnTJ6QDpBu2mAeMA0BPiO9tdWXISJ.ihZzBjMmF4kJQsu',
        'Donna',
        'Iannello',
        4,
        96,
        false
      );
    

      select public."insert_hut_worker"(
        103,
        'hutWorker96@gmail.com',
        '$2b$10$fcaib5ByKtXj0jr89xqr0ezpB9yDTVwl5ToS2GS4v/rkwXvfnFCwW',
        'Laurentino',
        'Biccari',
        4,
        97,
        true
      );
    

      select public."insert_hut_worker"(
        104,
        'hutWorker97@gmail.com',
        '$2b$10$dFQHUSF0ZSkHz.aRg4jwfu4oTsIAbb9oSkZrC9BhRW.IE86k8beF.',
        'Debora',
        'Lupi',
        4,
        98,
        false
      );
    

      select public."insert_hut_worker"(
        105,
        'hutWorker98@gmail.com',
        '$2b$10$MS2nmKLpo/tjNqRfUhzJAuTMyXaNmptuGNjqYlqTLPlry.29pHSNO',
        'Proteo',
        'Lupi',
        4,
        99,
        true
      );
    

      select public."insert_hut_worker"(
        106,
        'hutWorker99@gmail.com',
        '$2b$10$s8bh4AllLS6XnSzrheXKP.u1e9CYuZEMYvdb2NmwAJWwVIXIXTYkC',
        'Carolina',
        'Longhi',
        4,
        100,
        false
      );
    

      select public."insert_hut_worker"(
        107,
        'hutWorker100@gmail.com',
        '$2b$10$fN/2Ek3ghhSdkjNMvRlJKOvYqzigv12Z4qElv2uswvpHHwvBJPrKq',
        'Virgilio',
        'Sartor',
        4,
        101,
        true
      );
    

      select public."insert_hut_worker"(
        108,
        'hutWorker101@gmail.com',
        '$2b$10$xlyhXILwrmkYMIyuKff2Vuoo.1Xmfiaz0VhMu8eXtjH9GXIOSplPu',
        'Celso',
        'Cannata',
        4,
        102,
        false
      );
    

      select public."insert_hut_worker"(
        109,
        'hutWorker102@gmail.com',
        '$2b$10$7sDzPYrO/wvE/NiPF55MPuuYh1Pz8es62Etg7EmyzQJoY3GJ5Pa5W',
        'Vinicio',
        'Tesi',
        4,
        103,
        true
      );
    

      select public."insert_hut_worker"(
        110,
        'hutWorker103@gmail.com',
        '$2b$10$e2dppqDcPbOI7eG34jIdsOT1GA9wykD1HoBg51j5to93HDu.cK4jG',
        'Gerardo',
        'Crispino',
        4,
        104,
        false
      );
    

      select public."insert_hut_worker"(
        111,
        'hutWorker104@gmail.com',
        '$2b$10$SQRgvB3jRSu7UYgAESI9ROwX5DLDb1RvwkshSbPPau37R6b0DgS9a',
        'Amina',
        'Distefano',
        4,
        105,
        true
      );
    

      select public."insert_hut_worker"(
        112,
        'hutWorker105@gmail.com',
        '$2b$10$Tw.GVJpjodIHjPM/yYz5HOuIhAsCyDMKya9/EPPbR3GyaZiq9ZZC2',
        'Cointa',
        'Granata',
        4,
        106,
        false
      );
    

      select public."insert_hut_worker"(
        113,
        'hutWorker106@gmail.com',
        '$2b$10$zuM9hfLyeBOlfgxPgU0aA.sDCCkfQmM8pZyvfVfmv90gvsvgb5lay',
        'Evaristo',
        'Pichler',
        4,
        107,
        true
      );
    

      select public."insert_hut_worker"(
        114,
        'hutWorker107@gmail.com',
        '$2b$10$.slKxSV9Q9OnNb0j7Tjy4eoJ1y1WQzqnhzLxD1MA0qtighGEI0xx.',
        'Iside',
        'Anselmo',
        4,
        108,
        false
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '1 Borgo Italo, Borgo Giosu� salentino, Italy',
        'Borgo Giosu� salentino',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        150,
        '2 Piazza Miglio, Vinebaldo veneto, Italy',
        'Vinebaldo veneto',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        198,
        '528 Rotonda Zordan, Sesto Rainelda sardo, Italy',
        'Sesto Rainelda sardo',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        203,
        '89 Contrada Chiara, Comito veneto, Italy',
        'Comito veneto',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        26,
        '756 Rotonda Lombardi, Emmerico laziale, Italy',
        'Emmerico laziale',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        253,
        '18 Piazza Otilia, Settimo Godeberta, Italy',
        'Settimo Godeberta',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        149,
        '01 Strada Semprini, Malizia terme, Italy',
        'Malizia terme',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        291,
        '39 Piazza Celentano, Sesto Beato ligure, Italy',
        'Sesto Beato ligure',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        140,
        '22 Strada Filipponi, Settimo Costanza, Italy',
        'Settimo Costanza',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        223,
        '571 Via Romano, Sesto Nazario, Italy',
        'Sesto Nazario',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        111,
        '4 Via Cordioli, Renda salentino, Italy',
        'Renda salentino',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        253,
        '9 Contrada Ornella, Pascali nell''emilia, Italy',
        'Pascali nell''emilia',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        57,
        '1 Contrada D''Elia, Guida lido, Italy',
        'Guida lido',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        275,
        '12 Borgo Ilva, Borgo Severiano, Italy',
        'Borgo Severiano',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        47,
        '10 Incrocio Egidio, Liotta umbro, Italy',
        'Liotta umbro',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        67,
        '3 Piazza Violante, Chessa a mare, Italy',
        'Chessa a mare',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        157,
        '4 Contrada Daniele, Luciano ligure, Italy',
        'Luciano ligure',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        57,
        '37 Incrocio Casimira, Giulitta lido, Italy',
        'Giulitta lido',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        181,
        '52 Contrada Cointa, Severino umbro, Italy',
        'Severino umbro',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        106,
        '23 Contrada Liotta, Olindo laziale, Italy',
        'Olindo laziale',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        209,
        '9 Rotonda Ermete, Furio ligure, Italy',
        'Furio ligure',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        253,
        '436 Borgo Umberto, Settimo Emma, Italy',
        'Settimo Emma',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '55 Incrocio Di Santo, Iacono ligure, Italy',
        'Iacono ligure',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        136,
        '8 Rotonda Italia, Balboni laziale, Italy',
        'Balboni laziale',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        36,
        '734 Strada Villari, San Ansaldo, Italy',
        'San Ansaldo',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        169,
        '89 Piazza Venanzio, Genesia salentino, Italy',
        'Genesia salentino',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        183,
        '1 Borgo Irma, Salis terme, Italy',
        'Salis terme',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        234,
        '010 Borgo Schiavo, Sansone ligure, Italy',
        'Sansone ligure',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        207,
        '53 Via Di Domenico, Quarto Gesualdo a mare, Italy',
        'Quarto Gesualdo a mare',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        52,
        '6 Piazza Gaudenzia, Di Caccamo nell''emilia, Italy',
        'Di Caccamo nell''emilia',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        280,
        '287 Piazza Eraldo, Nazario salentino, Italy',
        'Nazario salentino',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        30,
        '59 Borgo Argelia, Villani del friuli, Italy',
        'Villani del friuli',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        27,
        '0 Rotonda Butera, Sesto Mimma laziale, Italy',
        'Sesto Mimma laziale',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '8 Strada Alcide, Plutarco laziale, Italy',
        'Plutarco laziale',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        232,
        '40 Rotonda Landolfo, Batilda umbro, Italy',
        'Batilda umbro',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        86,
        '00 Incrocio Guarneri, Quarto Costanza calabro, Italy',
        'Quarto Costanza calabro',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        255,
        '918 Piazza Mora, Borgo Piergiorgio lido, Italy',
        'Borgo Piergiorgio lido',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        238,
        '5 Strada Alda, San Artemisa sardo, Italy',
        'San Artemisa sardo',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        160,
        '03 Incrocio Pitzalis, Settimo Fosco, Italy',
        'Settimo Fosco',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        27,
        '849 Strada Coccia, Macario terme, Italy',
        'Macario terme',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '378 Strada Cremenzio, Fiorentino a mare, Italy',
        'Fiorentino a mare',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        167,
        '0 Via Sabato, Motta sardo, Italy',
        'Motta sardo',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        166,
        '93 Rotonda Lo Iacono, Colella sardo, Italy',
        'Colella sardo',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        170,
        '2 Rotonda Foca, Settimo Milena, Italy',
        'Settimo Milena',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        26,
        '6 Contrada Mencarelli, Colonna sardo, Italy',
        'Colonna sardo',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        217,
        '7 Contrada Mautone, San Everardo, Italy',
        'San Everardo',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        294,
        '69 Incrocio Sinfronio, Sesto Eugenia, Italy',
        'Sesto Eugenia',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        179,
        '838 Piazza Alfieri, Sesto Azeglio, Italy',
        'Sesto Azeglio',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        34,
        '49 Strada Fabio, Settimo Cleo, Italy',
        'Settimo Cleo',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        111,
        '0 Contrada Novello, Sardina salentino, Italy',
        'Sardina salentino',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        253,
        '38 Incrocio Trasea, Di Maria salentino, Italy',
        'Di Maria salentino',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '3 Strada Giampaolo, Mollica ligure, Italy',
        'Mollica ligure',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        170,
        '79 Strada Passuello, San Bruto, Italy',
        'San Bruto',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '9 Contrada Ignazio, Maffeo ligure, Italy',
        'Maffeo ligure',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        214,
        '3 Borgo Caforio, Erenia calabro, Italy',
        'Erenia calabro',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        72,
        '335 Piazza Amato, Borgo Ambrogio salentino, Italy',
        'Borgo Ambrogio salentino',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        133,
        '38 Via Giaccio, Borgo Emidio, Italy',
        'Borgo Emidio',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        136,
        '2 Piazza Acario, Sesto Claudio, Italy',
        'Sesto Claudio',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        240,
        '6 Rotonda Papapietro, Sesto Umberto umbro, Italy',
        'Sesto Umberto umbro',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        230,
        '56 Borgo Liberati, Sesto Cleopatra, Italy',
        'Sesto Cleopatra',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        282,
        '089 Borgo Barone, Sesto Morgana, Italy',
        'Sesto Morgana',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        31,
        '564 Borgo Bozzi, Tanzi ligure, Italy',
        'Tanzi ligure',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        132,
        '3 Borgo Croce, Quarto Adalberto del friuli, Italy',
        'Quarto Adalberto del friuli',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        198,
        '782 Piazza Chimenti, Settimo Ischirione veneto, Italy',
        'Settimo Ischirione veneto',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        244,
        '025 Contrada Domezio, San Proserpina, Italy',
        'San Proserpina',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        94,
        '9 Rotonda Parente, Mirabella calabro, Italy',
        'Mirabella calabro',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        217,
        '0 Piazza Beltrami, Palombi terme, Italy',
        'Palombi terme',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        243,
        '161 Piazza Iolanda, Sesto Griselda terme, Italy',
        'Sesto Griselda terme',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        50,
        '7 Incrocio Zanotti, San Temistocle salentino, Italy',
        'San Temistocle salentino',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '1 Via Belmonte, Luciano a mare, Italy',
        'Luciano a mare',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        290,
        '1 Piazza Vinebaldo, Adelaide veneto, Italy',
        'Adelaide veneto',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        224,
        '31 Strada Luana, Carrieri a mare, Italy',
        'Carrieri a mare',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        162,
        '4 Incrocio Sapienza, Quarto Zarina, Italy',
        'Quarto Zarina',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        70,
        '705 Strada Cesaretti, Borgo Amando, Italy',
        'Borgo Amando',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        253,
        '599 Strada Richelmo, Surano terme, Italy',
        'Surano terme',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        283,
        '7 Contrada Capitani, Borgo Antonella lido, Italy',
        'Borgo Antonella lido',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        27,
        '105 Borgo Leoni, Quarto Speranzio nell''emilia, Italy',
        'Quarto Speranzio nell''emilia',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        241,
        '3 Borgo Immacolato, San Pardo, Italy',
        'San Pardo',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        266,
        '91 Via Norina, Quarto Giadero lido, Italy',
        'Quarto Giadero lido',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        25,
        '589 Via Marianna, Calò lido, Italy',
        'Calò lido',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        223,
        '520 Incrocio Ferrante, Sesto Gianmaria a mare, Italy',
        'Sesto Gianmaria a mare',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        161,
        '162 Strada Giadero, Teodoto lido, Italy',
        'Teodoto lido',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        78,
        '7 Via Ruperto, Borgo Abibo lido, Italy',
        'Borgo Abibo lido',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        252,
        '42 Contrada Calandro, Oreste a mare, Italy',
        'Oreste a mare',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        116,
        '100 Borgo Sostrato, Di Tommaso terme, Italy',
        'Di Tommaso terme',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        207,
        '2 Via Campagna, San Beatrice salentino, Italy',
        'San Beatrice salentino',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        293,
        '89 Incrocio Pompili, Farella laziale, Italy',
        'Farella laziale',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        109,
        '935 Strada Galante, San Ivo, Italy',
        'San Ivo',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        82,
        '97 Rotonda Giunta, Quarto Crescenzia del friuli, Italy',
        'Quarto Crescenzia del friuli',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        183,
        '0 Via Gedeone, San Desiderato veneto, Italy',
        'San Desiderato veneto',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        270,
        '87 Borgo Pantaleone, Petrucci veneto, Italy',
        'Petrucci veneto',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        36,
        '339 Via Trovato, Oreste lido, Italy',
        'Oreste lido',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        185,
        '20 Borgo Apollo, Santo nell''emilia, Italy',
        'Santo nell''emilia',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        97,
        '5 Contrada Fiorini, Barsaba lido, Italy',
        'Barsaba lido',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        85,
        '8 Incrocio Tarcisio, Lorenza terme, Italy',
        'Lorenza terme',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        122,
        '087 Borgo Garavaglia, Baiocco sardo, Italy',
        'Baiocco sardo',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        190,
        '4 Strada Matarazzo, Quarto Teodoto laziale, Italy',
        'Quarto Teodoto laziale',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        55,
        '28 Via Fusco, Sesto Ermenegilda laziale, Italy',
        'Sesto Ermenegilda laziale',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        276,
        '3 Rotonda Esuperio, Sesto Giosu�, Italy',
        'Sesto Giosu�',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        133,
        '8 Piazza Davoli, Puca terme, Italy',
        'Puca terme',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        283,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        113,
        '75 Via Milena, Telemaco nell''emilia, Italy',
        'Telemaco nell''emilia',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        200,
        '0 Strada De Candido, Carminati a mare, Italy',
        'Carminati a mare',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        118,
        '80 Incrocio Antelmo, Signorile nell''emilia, Italy',
        'Signorile nell''emilia',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        281,
        '68 Incrocio Cupido, Quarto Dionisia, Italy',
        'Quarto Dionisia',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        56,
        '687 Via Melchiorre, Quarto Flaviana calabro, Italy',
        'Quarto Flaviana calabro',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        155,
        '76 Contrada Romoaldo, Vittore calabro, Italy',
        'Vittore calabro',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        52,
        '82 Contrada Viliberto, Giusto veneto, Italy',
        'Giusto veneto',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        270,
        '4 Incrocio Quiteria, Borgo Geminiano nell''emilia, Italy',
        'Borgo Geminiano nell''emilia',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        55,
        '98 Rotonda Perini, Settimo Candido ligure, Italy',
        'Settimo Candido ligure',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        242,
        '21 Incrocio Ivo, Doronzo ligure, Italy',
        'Doronzo ligure',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        292,
        '63 Incrocio Annabella, Falzone calabro, Italy',
        'Falzone calabro',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        250,
        '217 Contrada Gioacchini, Borgo Serafina laziale, Italy',
        'Borgo Serafina laziale',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        157,
        '911 Rotonda Santilli, Quarto Luigi, Italy',
        'Quarto Luigi',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        137,
        '16 Rotonda Mos�, Ippolito del friuli, Italy',
        'Ippolito del friuli',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        265,
        '65 Via Nazzareno, Borgo Violante umbro, Italy',
        'Borgo Violante umbro',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        180,
        '481 Contrada Brumat, Masala terme, Italy',
        'Masala terme',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        35,
        '3 Piazza Crespi, Izzi del friuli, Italy',
        'Izzi del friuli',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        74,
        '624 Piazza Massimo, Borgo Marisa, Italy',
        'Borgo Marisa',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        50,
        '0 Contrada Milella, Settimo Argo, Italy',
        'Settimo Argo',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        208,
        '72 Strada Palazzo, Cattaneo laziale, Italy',
        'Cattaneo laziale',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        254,
        '8 Strada Albano, Settimo Silvio sardo, Italy',
        'Settimo Silvio sardo',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        256,
        '0 Contrada Bernadetta, Termine a mare, Italy',
        'Termine a mare',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        282,
        '65 Incrocio Costa, Valerico veneto, Italy',
        'Valerico veneto',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        132,
        '37 Via Giustra, Quarto Genesio, Italy',
        'Quarto Genesio',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        278,
        '0 Incrocio Mazzanti, Settimo Siria, Italy',
        'Settimo Siria',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '5 Contrada Santo, La Monaca umbro, Italy',
        'La Monaca umbro',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        131,
        '088 Via Melitina, Quarto Rosita, Italy',
        'Quarto Rosita',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        78,
        '1 Strada Annamaria, Albina calabro, Italy',
        'Albina calabro',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '34 Borgo Aciscolo, Sesto Fabio, Italy',
        'Sesto Fabio',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '0 Strada Santarsia, Tamara del friuli, Italy',
        'Tamara del friuli',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        271,
        '824 Incrocio Evodio, Vladimiro laziale, Italy',
        'Vladimiro laziale',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        245,
        '42 Incrocio Corbiniano, San Giobbe, Italy',
        'San Giobbe',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        49,
        '5 Via Bianchetti, Quarto Tiziana umbro, Italy',
        'Quarto Tiziana umbro',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        170,
        '215 Borgo Zucca, Settimo Ilda, Italy',
        'Settimo Ilda',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        30,
        '9 Borgo Verecondo, Sesto Appia ligure, Italy',
        'Sesto Appia ligure',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '4 Rotonda Zanetta, Mulè a mare, Italy',
        'Mulè a mare',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '39 Contrada Arduino, Doroteo ligure, Italy',
        'Doroteo ligure',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        90,
        '765 Strada Di Cesare, Indelicato sardo, Italy',
        'Indelicato sardo',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '2 Contrada Baroni, Giadero a mare, Italy',
        'Giadero a mare',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        209,
        '271 Via Giorgio, Corinna a mare, Italy',
        'Corinna a mare',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        35,
        '8 Contrada Prato, Pisu ligure, Italy',
        'Pisu ligure',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        174,
        '3 Strada Gazzola, Quarto Agnese, Italy',
        'Quarto Agnese',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        178,
        '8 Rotonda Domezio, Cataldo veneto, Italy',
        'Cataldo veneto',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        266,
        '64 Strada Asterio, Sesto Carlo terme, Italy',
        'Sesto Carlo terme',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        128,
        '41 Borgo Festuccia, Cammarata laziale, Italy',
        'Cammarata laziale',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        125,
        '463 Rotonda Crocefisso, Adelchi veneto, Italy',
        'Adelchi veneto',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        102,
        '67 Strada Flaminia, Quarto Tarquinia umbro, Italy',
        'Quarto Tarquinia umbro',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        278,
        '4 Borgo Monti, Paola lido, Italy',
        'Paola lido',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        172,
        '44 Rotonda Veronica, Calpurnia umbro, Italy',
        'Calpurnia umbro',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        281,
        '46 Strada Siciliano, San Volfango laziale, Italy',
        'San Volfango laziale',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        29,
        '690 Rotonda Belvisi, Sesto Taziana, Italy',
        'Sesto Taziana',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        207,
        '49 Rotonda Pantaleo, Di Somma laziale, Italy',
        'Di Somma laziale',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        210,
        '609 Borgo Ireneo, San Ione calabro, Italy',
        'San Ione calabro',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        189,
        '088 Contrada Giovinazzo, Edgardo sardo, Italy',
        'Edgardo sardo',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        82,
        '70 Borgo Marzi, Di Giuseppe a mare, Italy',
        'Di Giuseppe a mare',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        103,
        '5 Incrocio Fiorenza, Sesto Odidone, Italy',
        'Sesto Odidone',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        164,
        '097 Rotonda Alcibiade, Borgo Mirella lido, Italy',
        'Borgo Mirella lido',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        225,
        '602 Contrada Perilli, Miranda salentino, Italy',
        'Miranda salentino',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        235,
        '901 Borgo Consiglio, Borgo Verulo, Italy',
        'Borgo Verulo',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        105,
        '905 Strada Casale, Grange del friuli, Italy',
        'Grange del friuli',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        204,
        '897 Borgo Alcino, Severino lido, Italy',
        'Severino lido',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        119,
        '071 Rotonda Amadori, San Savina, Italy',
        'San Savina',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        208,
        '78 Borgo Taide, Sesto Cleopatra del friuli, Italy',
        'Sesto Cleopatra del friuli',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        263,
        '0 Borgo Viale, Borgo Carla salentino, Italy',
        'Borgo Carla salentino',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '640 Borgo Metello, Settimo Afro, Italy',
        'Settimo Afro',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        135,
        '103 Piazza Riolo, San Garimberto, Italy',
        'San Garimberto',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        288,
        '85 Borgo Edilberto, San Liberto sardo, Italy',
        'San Liberto sardo',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        49,
        '6 Contrada Golia, Castellana lido, Italy',
        'Castellana lido',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        222,
        '82 Rotonda Tonelli, Benigna nell''emilia, Italy',
        'Benigna nell''emilia',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        149,
        '8 Borgo Marotta, Borgo Michele, Italy',
        'Borgo Michele',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        256,
        '3 Strada Giacomo, Righi ligure, Italy',
        'Righi ligure',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        211,
        '90 Strada Marini, San Aristo del friuli, Italy',
        'San Aristo del friuli',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        174,
        '58 Borgo Salomone, Barbieri umbro, Italy',
        'Barbieri umbro',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        300,
        '829 Strada Esposito, Conti calabro, Italy',
        'Conti calabro',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        255,
        '433 Via Euclide, Rondoni terme, Italy',
        'Rondoni terme',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        227,
        '4 Borgo Bortolo, Leonardi terme, Italy',
        'Leonardi terme',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        110,
        '781 Via Lucarelli, Cerullo umbro, Italy',
        'Cerullo umbro',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        182,
        '487 Via Acario, San Oriana, Italy',
        'San Oriana',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        161,
        '36 Borgo Bernardo, Borgo Erico, Italy',
        'Borgo Erico',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        52,
        '561 Strada Cesare, Violi a mare, Italy',
        'Violi a mare',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        27,
        '27 Contrada Tabita, Settimo Melissa, Italy',
        'Settimo Melissa',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '409 Contrada Carponio, Lo Piccolo del friuli, Italy',
        'Lo Piccolo del friuli',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        148,
        '66 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        158,
        '12 Strada Di Girolamo, San Lanfranco umbro, Italy',
        'San Lanfranco umbro',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        171,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        256,
        '04 Incrocio Bortoluzzi, San Gigliola a mare, Italy',
        'San Gigliola a mare',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        73,
        '8 Piazza Sucera, Liliana lido, Italy',
        'Liliana lido',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        221,
        '33 Incrocio Galasso, San Massimiliano, Italy',
        'San Massimiliano',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        150,
        '4 Via Godeberta, Zambuto del friuli, Italy',
        'Zambuto del friuli',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        291,
        '9 Strada Cuzia, Quarto Divo, Italy',
        'Quarto Divo',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        32,
        '317 Contrada Adrione, San Alina a mare, Italy',
        'San Alina a mare',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        204,
        '0 Piazza Boffa, San Guendalina, Italy',
        'San Guendalina',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        270,
        '450 Incrocio Ciccarelli, Settimo Maffeo, Italy',
        'Settimo Maffeo',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        206,
        '501 Contrada Ludovica, Remondo calabro, Italy',
        'Remondo calabro',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        173,
        '13 Rotonda Fernanda, San Bindo, Italy',
        'San Bindo',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        102,
        '8 Borgo Servidio, Eliano calabro, Italy',
        'Eliano calabro',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        276,
        '548 Contrada Umile, Nicotra a mare, Italy',
        'Nicotra a mare',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        273,
        '446 Borgo Liberatore, Sesto Moreno, Italy',
        'Sesto Moreno',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        250,
        '6 Rotonda Pascali, Laezza del friuli, Italy',
        'Laezza del friuli',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        63,
        '44 Strada Abenzio, Indelicato umbro, Italy',
        'Indelicato umbro',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        237,
        '5 Via Gargiulo, Genesio calabro, Italy',
        'Genesio calabro',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '57 Incrocio Teodora, La Malfa del friuli, Italy',
        'La Malfa del friuli',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        297,
        '370 Via Carminati, Settimo Quirino del friuli, Italy',
        'Settimo Quirino del friuli',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        62,
        '728 Contrada Pavan, Borgo Sidonio ligure, Italy',
        'Borgo Sidonio ligure',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        281,
        '922 Piazza Fonda, Pircher ligure, Italy',
        'Pircher ligure',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        234,
        '932 Borgo Peleo, Cavallini lido, Italy',
        'Cavallini lido',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        207,
        '72 Contrada Cornelia, Borgo Iorio calabro, Italy',
        'Borgo Iorio calabro',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        84,
        '7 Contrada Fumagalli, Sesto Fedora, Italy',
        'Sesto Fedora',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        103,
        '8 Incrocio Moretto, Quarto Valtena, Italy',
        'Quarto Valtena',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        158,
        '41 Borgo Guido, Guerriero umbro, Italy',
        'Guerriero umbro',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        81,
        '670 Incrocio Ferruccio, Quarto Dionisio, Italy',
        'Quarto Dionisio',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '6 Incrocio Flore, Bertoldo umbro, Italy',
        'Bertoldo umbro',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        179,
        '73 Via Cingolani, Tassi salentino, Italy',
        'Tassi salentino',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        117,
        '56 Incrocio Asaro, Neri laziale, Italy',
        'Neri laziale',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        172,
        '71 Incrocio Berardi, Quarto Eros lido, Italy',
        'Quarto Eros lido',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        166,
        '223 Rotonda Frasca, San Albano, Italy',
        'San Albano',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        109,
        '74 Piazza Rocco, Mazzone a mare, Italy',
        'Mazzone a mare',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        100,
        '1 Piazza Belmonte, Settimo Telemaco, Italy',
        'Settimo Telemaco',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        295,
        '0 Incrocio Giglio, Borgo Beronico, Italy',
        'Borgo Beronico',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        90,
        '56 Incrocio Di Bari, Sesto Clodomiro ligure, Italy',
        'Sesto Clodomiro ligure',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '464 Piazza Proserpina, Gesualdo del friuli, Italy',
        'Gesualdo del friuli',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        52,
        '665 Incrocio Margiotta, Borgo Galatea terme, Italy',
        'Borgo Galatea terme',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        158,
        '029 Incrocio Elmo, Valerico terme, Italy',
        'Valerico terme',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        106,
        '079 Incrocio Enzo, Sesto Caronte umbro, Italy',
        'Sesto Caronte umbro',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        130,
        '474 Piazza Maria, Falchi sardo, Italy',
        'Falchi sardo',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        271,
        '7 Piazza Nazzaro, Oronzo veneto, Italy',
        'Oronzo veneto',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        147,
        '657 Borgo Massimiliano, Lombardo ligure, Italy',
        'Lombardo ligure',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        280,
        '23 Via Moras, Arena sardo, Italy',
        'Arena sardo',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        80,
        '0 Rotonda Socrate, Quarto Minerva terme, Italy',
        'Quarto Minerva terme',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        288,
        '03 Strada Adami, Egidio veneto, Italy',
        'Egidio veneto',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        146,
        '41 Borgo Viviana, Borgo Icilio, Italy',
        'Borgo Icilio',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        55,
        '927 Strada Genchi, Amadeo umbro, Italy',
        'Amadeo umbro',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        53,
        '971 Strada Immacolato, Domenico lido, Italy',
        'Domenico lido',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        154,
        '7 Via Loredana, Agape terme, Italy',
        'Agape terme',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        291,
        '1 Contrada Celeste, Poletti del friuli, Italy',
        'Poletti del friuli',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        123,
        '0 Strada Travaglini, Quarto Menelao ligure, Italy',
        'Quarto Menelao ligure',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        173,
        '2 Borgo Gottardo, San Gentile veneto, Italy',
        'San Gentile veneto',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        250,
        '833 Borgo Mazzei, Cino salentino, Italy',
        'Cino salentino',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        246,
        '65 Strada Brancaleone, D''Avino calabro, Italy',
        'D''Avino calabro',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        72,
        '8 Strada Cadoni, Quarto Camillo a mare, Italy',
        'Quarto Camillo a mare',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        290,
        '83 Rotonda Porzia, Benigna sardo, Italy',
        'Benigna sardo',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        94,
        '56 Via Verenzio, Di Michele laziale, Italy',
        'Di Michele laziale',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        135,
        '338 Strada Antonia, Borgo Eufronio del friuli, Italy',
        'Borgo Eufronio del friuli',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        74,
        '1 Strada Bonomi, Caiazzo nell''emilia, Italy',
        'Caiazzo nell''emilia',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        124,
        '41 Borgo Carmen, Settimo Graziella a mare, Italy',
        'Settimo Graziella a mare',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        238,
        '01 Incrocio Sucameli, Quarto Eugenio, Italy',
        'Quarto Eugenio',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        55,
        '034 Borgo Maura, Archimede salentino, Italy',
        'Archimede salentino',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        211,
        '788 Piazza Caterino, San Bonifacio umbro, Italy',
        'San Bonifacio umbro',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '86 Piazza Carriero, Didimo sardo, Italy',
        'Didimo sardo',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        162,
        '116 Borgo Zanotti, Borgo Saul lido, Italy',
        'Borgo Saul lido',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        236,
        '060 Contrada Ilva, Ezio laziale, Italy',
        'Ezio laziale',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        27,
        '41 Incrocio Bartolomeo, Perini ligure, Italy',
        'Perini ligure',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        183,
        '3 Rotonda Tullia, San Noemi, Italy',
        'San Noemi',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        32,
        '86 Rotonda Melchiade, Quarto Emiliano, Italy',
        'Quarto Emiliano',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        155,
        '780 Borgo Correale, Lidio umbro, Italy',
        'Lidio umbro',
        'Italy',
        'Como',
        ''
      );
    
  