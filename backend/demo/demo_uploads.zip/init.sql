--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$bXD9tMphzRwDgnVjoYxaz.Q6aLFTEaoOjEnzE94/ZDW51dEH29S3y',
    'Antonio',
    'Battipaglia',
    2,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$iQZyiE/dKVOSMWROgVDAcu4xFH6jNppv79Pafsw4y4qPuFsWKmkUO',
    'Erfan',
    'Gholami',
    4,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$/JemWR3Z3VufEySRCiikbeWXCl0fNFnnKGdnnIDbp5XJlh4ry9fQa',
    'Laura',
    'Zurru',
    5,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$9Qu9a8HUVJbRR3.0hzBa5./O2kKMucuHSG5KZx0rKXIWBKAS3n7iq',
    'German',
    'Gorodnev',
    0,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$q5KTpuIAcs5zcBtRSaSH0OYeMyUtThJhu9g7.WvwNsDUfoYkDcKHa',
    'vincenzo',
    'Sagristano',
    3,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    6,
    'francesco@friend.it',
    '$2b$10$M.6Nv/.zgjCjrpvIX7k0buHVLE1kr8PqYVnpsXLusm3bZtBwk35FO',
    'Francesco',
    'Grande',
    1,
    true,
    true
  );
  

      CREATE OR REPLACE FUNCTION public.insert_hike(
        user_id integer,
        title varchar,
        difficulty integer,
        gpx_path varchar,
        country varchar,
        region varchar,
        province varchar,
        city varchar,
        length numeric(12,2),
        ascent numeric(12,2),
        expected_time integer,
        description varchar,
        pictures jsonb,
        start_point jsonb,
        end_point jsonb,
        reference_points jsonb
      )  RETURNS VOID AS
      $func$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hike"(
        2,
        'Amprimo',
        2,
        '/static/gpx/Amprimo.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        0.9,
        18.1,
        80,
        'Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.',
        '["/static/images/3.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.165559804,"lat":45.102780737}'::jsonb,
        '{"name":"End Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.14299586,"lat":45.099887898}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":7.164360252,"lat":45.102912389,"altitude":1256.852},{"name":"Ref Point 2","address":"","lon":7.158207147,"lat":45.102886551,"altitude":1283.605}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello Chateau Beaulard - Cotolivier - Vazon',
        1,
        '/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Beaulard',
        3.2,
        19.8,
        200,
        'Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.',
        '["/static/images/2.jpg"]'::jsonb,
        '{"name":"Start Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.772358,"lat":45.03205}'::jsonb,
        '{"name":"End Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.77234,"lat":45.032238}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago Bianco',
        2,
        '/static/gpx/Lago Bianco.gpx',
        'Francia',
        'Auvergne-Rhone-Alpes',
        'Savoia',
        'Val-Cenis',
        4.1,
        16.4,
        210,
        'Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.

La diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.

La Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.

Si può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.',
        '["/static/images/1.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945681,"lat":45.223814}'::jsonb,
        '{"name":"End Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945581,"lat":45.224058}'::jsonb,
        '[{"name":"fountain","address":"","lon":6.940291,"lat":45.222543,"altitude":2027},{"name":"Peak","address":"","lon":6.937204,"lat":45.215867,"altitude":2131}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Alte Langhe Settentrionali - Cossano Belbo',
        2,
        '/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cossano Belbo',
        4.9,
        19.3,
        200,
        'Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.
Si svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.
Si imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.
Inizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.
Percorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. 
Seguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. 
Si procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante',
        '["/static/images/4.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199049,"lat":44.670379}'::jsonb,
        '{"name":"End Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199052,"lat":44.670377}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":8.214142,"lat":44.674545,"altitude":482.526},{"name":"Ref Point 2","address":"","lon":8.197792,"lat":44.668772,"altitude":242.585}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'La pieve romanica di Piesenzana e la valle delle tartufaie',
        2,
        '/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montechiaro d''Asti',
        3.8,
        8.8,
        225,
        'Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. 
Circa 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. 
In regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. 
A Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). 
Contemporaneamente i ristoranti della zona propongono piatti a base di tartufi',
        '["/static/images/5.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.113224,"lat":45.007605}'::jsonb,
        '{"name":"End Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.11358,"lat":45.007557}'::jsonb,
        NULL
      );
    
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2),
        working_time_start time without time zone,
        working_time_end time without time zone,
        email varchar,
        phone_number varchar,
        pictures jsonb
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber",
      "pictures"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number,
      pictures
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        2,
        128::numeric(12,2),
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Pauside Cara',
        'http://pretty-dusk.com',
        316.566,
        '08:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Albina.Vuillermoz@yahoo.it',
        '+394798486632',
        '["/static/images/80fb26b5-ade4-4113-9748-53a4749e1411.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        1,
        143::numeric(12,2),
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Dott. Fulvio Marra',
        'https://constant-edition.com',
        313.382,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Sansone.Vanni1@libero.it',
        '+390285090373',
        '["/static/images/43900d12-7f53-4110-a6b7-772e716dbc60.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        5,
        92::numeric(12,2),
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Dott. Stefania Ratti',
        'http://silver-generator.org',
        309.674,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Maiorico.Sabbatini89@libero.it',
        '+394185980230',
        '["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        5,
        64::numeric(12,2),
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Dott. Giovanna Falchi',
        'https://oval-agenda.net',
        313.905,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Bartolomea.Volpe47@gmail.com',
        '+392250090821',
        '["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        3,
        140::numeric(12,2),
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Davino Tavani',
        'http://impressive-immigration.it',
        284.722,
        '03:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Pacifico_Graziano16@gmail.com',
        '+390501878239',
        '["/static/images/425e8ee2-72c0-4156-b550-6e1d904663a2.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        10,
        35::numeric(12,2),
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Sig. Acrisio Cipolla',
        'https://sure-footed-hellcat.com',
        334.355,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Zaccheo_Nobili54@email.it',
        '+391125661678',
        '["/static/images/8a8c2365-2d64-43f8-a221-b05bf5ffaa47.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        8,
        139::numeric(12,2),
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Davide Cascio',
        'https://embellished-tunnel.org',
        270.016,
        '09:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Vedasto_Greco93@yahoo.com',
        '+390142739596',
        '["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        6,
        143::numeric(12,2),
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Tolomeo Rondinone',
        'https://new-maize.org',
        283.21,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Elaide_Ceccarini10@gmail.com',
        '+396388964781',
        '["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        10,
        61::numeric(12,2),
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Rinaldo Barresi',
        'http://delirious-endorsement.com',
        267.668,
        '08:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Dionigi_Lorenzini@libero.it',
        '+398763362180',
        '["/static/images/c2613970-2a27-4a40-9cc5-fd2312ca4e60.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        4,
        93::numeric(12,2),
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Sante Vicari',
        'https://pleasing-yellowjacket.com',
        317.929,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Ciriaco53@hotmail.com',
        '+399305063084',
        '["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        8,
        146::numeric(12,2),
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Isaia Quinto',
        'https://idolized-report.it',
        334.049,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Taide_Palazzo37@hotmail.com',
        '+393040962718',
        '["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        10,
        90::numeric(12,2),
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Ing. Vulmaro Rosset',
        'https://dismal-moat.net',
        319.264,
        '09:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Giasone_Parrinello23@yahoo.it',
        '+397749487530',
        '["/static/images/87ce0c23-8549-46fc-8538-103433b20a3c.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        7,
        131::numeric(12,2),
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Daniela Vecchi',
        'https://gleeful-ounce.com',
        267.348,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Climaco.Verme11@hotmail.com',
        '+399777302009',
        '["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        7,
        87::numeric(12,2),
        'Vernagthütte',
        'Austria',
        'Sig. Aidano Di Palma',
        'http://monstrous-lunchmeat.it',
        291.255,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Zaccheo_DiCesare72@libero.it',
        '+393822712112',
        '["/static/images/78948680-d691-4336-a553-7c89e39fe780.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        7,
        38::numeric(12,2),
        'Wormser Hütte',
        'Austria',
        'Virgilio Zanatta',
        'https://memorable-prince.com',
        326.689,
        '09:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Fulberto.Marziali13@yahoo.com',
        '+393920267921',
        '["/static/images/c983162f-6637-43d8-8c74-044279d45f87.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        9,
        126::numeric(12,2),
        'Biberacher Hütte',
        'Austria',
        'Ione Battisti',
        'http://decisive-subsidy.it',
        278.972,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Massimiliano.Torrisi@yahoo.com',
        '+399842921608',
        '["/static/images/425e8ee2-72c0-4156-b550-6e1d904663a2.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        6,
        120::numeric(12,2),
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Ciro Palombi',
        'http://which-nucleotide.it',
        264.716,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Tizio.Cappai68@hotmail.com',
        '+397844400219',
        '["/static/images/8b792b0e-5416-45af-abbc-286a77a5d644.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        5,
        150::numeric(12,2),
        'Hochwaldhütte',
        'Germany',
        'Verdiana Spadafora',
        'http://silky-candidate.it',
        312.468,
        '03:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Quartilla.Orlando71@yahoo.it',
        '+396134112829',
        '["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        4,
        78::numeric(12,2),
        'Kölner Eifelhütte',
        'Germany',
        'Sig. Olimpia Fabbricatore',
        'http://frugal-listening.it',
        266.328,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Rosanna.Marangon@email.it',
        '+396803473301',
        '["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        10,
        133::numeric(12,2),
        'Madrisahütte',
        'Austria',
        'Evandro Castelli',
        'https://solid-playwright.it',
        331.769,
        '08:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Antonia.Scocco13@yahoo.it',
        '+398611512559',
        '["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        5,
        101::numeric(12,2),
        'Dresdner Hütte',
        'Austria',
        'Damiana Macchi',
        'http://hurtful-luxury.org',
        305.249,
        '05:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Crocefisso.Baldassarre5@email.it',
        '+390676150687',
        '["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        10,
        84::numeric(12,2),
        'Fiderepasshütte',
        'Germany',
        'Damiano Riccardi',
        'https://lumbering-stove.it',
        308.374,
        '08:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Everardo77@yahoo.it',
        '+393794340860',
        '["/static/images/425e8ee2-72c0-4156-b550-6e1d904663a2.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        3,
        89::numeric(12,2),
        'Göppinger Hütte',
        'Austria',
        'Ildegarda Marzano',
        'https://hefty-tankful.org',
        321.943,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Cordelia.Gabrielli@hotmail.com',
        '+390619141860',
        '["/static/images/e9b41d5b-2e1b-4dbd-ac79-d0f63cb2ddc7.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        6,
        108::numeric(12,2),
        'Oberzalimhütte',
        'Austria',
        'Fidenzio Antenucci',
        'https://tart-pig.com',
        261.62,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Gerardo_Cristiano@yahoo.it',
        '+392958166004',
        '["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        6,
        108::numeric(12,2),
        'Rastkogelhütte',
        'Austria',
        'Sig. Evidio Bortot',
        'https://ready-workhorse.it',
        273.271,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Zosima_Marciano54@hotmail.com',
        '+396899934149',
        '["/static/images/43900d12-7f53-4110-a6b7-772e716dbc60.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        7,
        64::numeric(12,2),
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Severiano Tolu',
        'http://wealthy-dog.org',
        292.154,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Oliviera1@email.it',
        '+399511494409',
        '["/static/images/8a8c2365-2d64-43f8-a221-b05bf5ffaa47.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        4,
        91::numeric(12,2),
        'Kaltenberghütte',
        'Austria',
        'Marana Vallone',
        'http://decent-keyboard.com',
        298.262,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Liberio.Baroni@libero.it',
        '+396383997357',
        '["/static/images/36bdeba2-0744-4db0-85d3-4ce367c3faf8.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        10,
        102::numeric(12,2),
        'Schweinfurter Hütte',
        'Austria',
        'Abele Vecchi',
        'http://expert-laugh.org',
        295.218,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Cora_Zanon@yahoo.it',
        '+390910410494',
        '["/static/images/c983162f-6637-43d8-8c74-044279d45f87.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        1,
        41::numeric(12,2),
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Amilcare Capocotta',
        'http://square-tub.net',
        276.192,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Clemenzia30@yahoo.it',
        '+396281741714',
        '["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        4,
        71::numeric(12,2),
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Amanzio Pianigiani',
        'http://healthy-stud.org',
        270.591,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Valente.Morri26@libero.it',
        '+397259085438',
        '["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        1,
        61::numeric(12,2),
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Ilaria Iannone',
        'https://outstanding-deviance.com',
        268.059,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Edoardo_Mignogna6@email.it',
        '+399332654392',
        '["/static/images/78948680-d691-4336-a553-7c89e39fe780.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        9,
        135::numeric(12,2),
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Dott. Zenone Righi',
        'https://amusing-hospice.it',
        339.132,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Gioacchino_Biagini47@hotmail.com',
        '+397678378747',
        '["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        4,
        120::numeric(12,2),
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Unna Bennardo',
        'https://serious-behalf.org',
        330.466,
        '01:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Callisto93@email.it',
        '+397714538986',
        '["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        9,
        134::numeric(12,2),
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Cristiana Carbon',
        'http://warm-refuge.org',
        307.261,
        '05:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Quarto.Sucameli@hotmail.com',
        '+398051050275',
        '["/static/images/425e8ee2-72c0-4156-b550-6e1d904663a2.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        9,
        49::numeric(12,2),
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Delinda Santarsiero',
        'http://dapper-wisteria.com',
        282.294,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Guenda81@yahoo.it',
        '+398125087845',
        '["/static/images/c983162f-6637-43d8-8c74-044279d45f87.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        5,
        61::numeric(12,2),
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Viscardo Vitiello',
        'http://definite-dashboard.net',
        310.884,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Ermes.Favara51@email.it',
        '+391177203173',
        '["/static/images/4d67edf5-5712-4e90-814c-c784442057c5.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        6,
        103::numeric(12,2),
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Evidio Milano',
        'https://possible-link.org',
        288.335,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Olivia_Marchini@yahoo.com',
        '+397197700525',
        '["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        4,
        81::numeric(12,2),
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Rina Trovato',
        'http://cooked-vol.org',
        331.576,
        '03:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Graciliano.Pirone@gmail.com',
        '+391647772702',
        '["/static/images/87ce0c23-8549-46fc-8538-103433b20a3c.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        10,
        81::numeric(12,2),
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Rodolfo Ianni',
        'http://envious-collectivization.org',
        296.093,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Baldomero.Cont@libero.it',
        '+395212394675',
        '["/static/images/c2613970-2a27-4a40-9cc5-fd2312ca4e60.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        1,
        110::numeric(12,2),
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Rosa Ruggeri',
        'https://capital-clearing.org',
        293.345,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Tirone_Trapani52@hotmail.com',
        '+399771638040',
        '["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        4,
        49::numeric(12,2),
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Colmanno Sergi',
        'https://faraway-inversion.it',
        266.162,
        '01:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Carolina_Orr@gmail.com',
        '+391677758433',
        '["/static/images/e9b41d5b-2e1b-4dbd-ac79-d0f63cb2ddc7.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        4,
        101::numeric(12,2),
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Romualdo Marangoni',
        'http://reasonable-uncle.com',
        289.451,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Virone.Concas14@yahoo.com',
        '+392750937604',
        '["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        7,
        78::numeric(12,2),
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Margherita Gori',
        'http://bright-lathe.net',
        268.94,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Abibo.Saccone@email.it',
        '+393399091734',
        '["/static/images/c983162f-6637-43d8-8c74-044279d45f87.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        8,
        120::numeric(12,2),
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Cherubino Guarnieri',
        'http://digital-restructuring.org',
        307.003,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Telemaco.Murgia@gmail.com',
        '+392979468585',
        '["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        4,
        103::numeric(12,2),
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Alceste Pece',
        'http://misguided-precedent.net',
        304.825,
        '05:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Ondina.Abbate@yahoo.it',
        '+396843693379',
        '["/static/images/425e8ee2-72c0-4156-b550-6e1d904663a2.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        7,
        147::numeric(12,2),
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Gaio Di Luca',
        'https://concrete-mixture.it',
        297.787,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Aimone42@email.it',
        '+398484684724',
        '["/static/images/87ce0c23-8549-46fc-8538-103433b20a3c.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        5,
        35::numeric(12,2),
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Marisa Mannino',
        'https://complex-athletics.net',
        262.55,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Aidano.Gori43@hotmail.com',
        '+398937328231',
        '["/static/images/425e8ee2-72c0-4156-b550-6e1d904663a2.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        2,
        64::numeric(12,2),
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Isabella Serafini',
        'https://gargantuan-encirclement.com',
        260.251,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Mercede3@hotmail.com',
        '+397015722903',
        '["/static/images/78948680-d691-4336-a553-7c89e39fe780.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        6,
        103::numeric(12,2),
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Antonia Bertolini',
        'https://irritating-equinox.it',
        274.143,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Ciriaco.Francesconi22@yahoo.com',
        '+390587835177',
        '["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        7,
        58::numeric(12,2),
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Antioco Germani',
        'http://blank-rating.org',
        320.265,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Famiano.Caputo@hotmail.com',
        '+391902047061',
        '["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        2,
        142::numeric(12,2),
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Sinfronio Paganelli',
        'https://roasted-boycott.net',
        278.185,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Benito25@libero.it',
        '+394474083781',
        '["/static/images/87ce0c23-8549-46fc-8538-103433b20a3c.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        3,
        124::numeric(12,2),
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Ing. Smeralda Manfredi',
        'http://sparse-switchboard.it',
        321.147,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Vincenzo_Bonifazi@gmail.com',
        '+393921737473',
        '["/static/images/e9b41d5b-2e1b-4dbd-ac79-d0f63cb2ddc7.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        3,
        105::numeric(12,2),
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Asimodeo Martina',
        'http://lavish-cartoon.net',
        296.338,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Aurelia55@hotmail.com',
        '+393160498201',
        '["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        5,
        102::numeric(12,2),
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Rubiano Pierini',
        'http://trustworthy-baker.it',
        339.941,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Robaldo_Fusco@gmail.com',
        '+397869763203',
        '["/static/images/e9b41d5b-2e1b-4dbd-ac79-d0f63cb2ddc7.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        7,
        135::numeric(12,2),
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Marana Cammisa',
        'http://fluid-charlatan.it',
        292.139,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Uberto.Maniscalco95@yahoo.com',
        '+397235284633',
        '["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        10,
        82::numeric(12,2),
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Ing. Saffo Terzo',
        'http://monstrous-estate.org',
        274.862,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Smeralda_Dolce@yahoo.it',
        '+395064004260',
        '["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        9,
        94::numeric(12,2),
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Quinziano Baldi',
        'https://outlying-gap.it',
        319.176,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Isidoro88@email.it',
        '+394790265704',
        '["/static/images/b16ffd6b-749a-41fe-a316-2dbe73e0b56e.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        10,
        128::numeric(12,2),
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Alda Grossi',
        'https://intelligent-tick.net',
        300.433,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Lucio84@gmail.com',
        '+390267273562',
        '["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        9,
        54::numeric(12,2),
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Paola Canova',
        'https://strong-ancestor.org',
        328.622,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Gaudino29@libero.it',
        '+399321110933',
        '["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        7,
        84::numeric(12,2),
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Cointa Malagoli',
        'https://relieved-dynamo.org',
        261.861,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Elvezio.Leone@libero.it',
        '+397781626769',
        '["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        5,
        106::numeric(12,2),
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Concetto Gambino',
        'http://closed-activist.it',
        336.243,
        '01:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Gionata88@gmail.com',
        '+396808934063',
        '["/static/images/87ce0c23-8549-46fc-8538-103433b20a3c.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        1,
        97::numeric(12,2),
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Annibale Mazzotti',
        'http://overdue-clerk.it',
        291.485,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Leonilda89@yahoo.com',
        '+393630233034',
        '["/static/images/36bdeba2-0744-4db0-85d3-4ce367c3faf8.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        2,
        37::numeric(12,2),
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Davino Pellegrino',
        'https://clear-cut-anterior.net',
        293.878,
        '03:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Marina_DAnna50@gmail.com',
        '+392648542125',
        '["/static/images/87ce0c23-8549-46fc-8538-103433b20a3c.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        4,
        122::numeric(12,2),
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Dr. Durante Cosentino',
        'http://unconscious-sage.net',
        324.364,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Lucia82@hotmail.com',
        '+399415732972',
        '["/static/images/36bdeba2-0744-4db0-85d3-4ce367c3faf8.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        1,
        40::numeric(12,2),
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Barbara Andrisani',
        'https://awesome-arithmetic.com',
        283.309,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Berengario54@gmail.com',
        '+392920747407',
        '["/static/images/36bdeba2-0744-4db0-85d3-4ce367c3faf8.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        4,
        144::numeric(12,2),
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Cassiano Huber',
        'https://aching-monument.com',
        314.961,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Marisa_Todaro@hotmail.com',
        '+390565533721',
        '["/static/images/4d67edf5-5712-4e90-814c-c784442057c5.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        3,
        82::numeric(12,2),
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Cosima D''Andrea',
        'https://unacceptable-classic.com',
        295.466,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Gaglioffo.Spada0@libero.it',
        '+399012868960',
        '["/static/images/8b792b0e-5416-45af-abbc-286a77a5d644.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        6,
        78::numeric(12,2),
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Saturniano Romani',
        'https://black-and-white-memory.org',
        288.885,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Annibale39@libero.it',
        '+395965544468',
        '["/static/images/c2613970-2a27-4a40-9cc5-fd2312ca4e60.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        1,
        73::numeric(12,2),
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Rebecca Gulino',
        'http://giddy-flute.com',
        262.846,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Romola65@yahoo.it',
        '+394685652340',
        '["/static/images/c983162f-6637-43d8-8c74-044279d45f87.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        5,
        142::numeric(12,2),
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Veriana Ottaviano',
        'http://heavy-fanlight.net',
        322.826,
        '08:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Teodata.Raimondi@hotmail.com',
        '+395217204810',
        '["/static/images/8a8c2365-2d64-43f8-a221-b05bf5ffaa47.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        2,
        78::numeric(12,2),
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Gaio Pecoraro',
        'https://yellow-surgery.it',
        318.274,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Diodata.Bonomo32@yahoo.it',
        '+398235781968',
        '["/static/images/8b792b0e-5416-45af-abbc-286a77a5d644.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        2,
        82::numeric(12,2),
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Chiaffredo Pani',
        'https://giddy-ballot.com',
        320.463,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Marinetta13@yahoo.it',
        '+395613685293',
        '["/static/images/8b792b0e-5416-45af-abbc-286a77a5d644.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        8,
        66::numeric(12,2),
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Liliana Simone',
        'https://concrete-trustee.net',
        318.645,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Fausta_Ierardi95@yahoo.com',
        '+398203444966',
        '["/static/images/425e8ee2-72c0-4156-b550-6e1d904663a2.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        7,
        146::numeric(12,2),
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Alba Bini',
        'https://multicolored-anesthesiology.net',
        285.254,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Dione_Massaro25@yahoo.it',
        '+395205103623',
        '["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        6,
        39::numeric(12,2),
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Vivaldo Cabras',
        'https://lost-riding.org',
        301.698,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Gemma.Pala15@email.it',
        '+391127113241',
        '["/static/images/b16ffd6b-749a-41fe-a316-2dbe73e0b56e.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        2,
        114::numeric(12,2),
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Fiorenziano Petronio',
        'http://yearly-harvester.com',
        290.502,
        '08:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Efrem_Cesaretti@hotmail.com',
        '+399178896612',
        '["/static/images/d50d1121-5179-442a-adb4-c157bd9f3aba.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        7,
        36::numeric(12,2),
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Afro Delle Monache',
        'http://sparse-ocean.net',
        334.394,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Salomone93@gmail.com',
        '+393840935093',
        '["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        5,
        92::numeric(12,2),
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Porziano Cavallini',
        'http://grumpy-diesel.com',
        318.504,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Ivo_Paolicelli44@hotmail.com',
        '+392863993462',
        '["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        7,
        89::numeric(12,2),
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Dr. Gumesindo Peroni',
        'https://thorny-avenue.com',
        290.225,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Dante_Alessandrini48@yahoo.com',
        '+392087605258',
        '["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        7,
        97::numeric(12,2),
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Famiano Moroni',
        'http://failing-coordination.org',
        293.664,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Colombo_Ippolito49@hotmail.com',
        '+391794949698',
        '["/static/images/80fb26b5-ade4-4113-9748-53a4749e1411.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        5,
        87::numeric(12,2),
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Eloisa Palla',
        'https://noisy-temper.it',
        327.207,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Adrione.DeGiorgi@yahoo.com',
        '+393923788695',
        '["/static/images/e9b41d5b-2e1b-4dbd-ac79-d0f63cb2ddc7.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        5,
        144::numeric(12,2),
        'Wittener Hütte',
        'Germany',
        'Emma Ferraiuolo',
        'http://nippy-cucumber.net',
        271.012,
        '03:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Cristiana_Macchia61@hotmail.com',
        '+397601663159',
        '["/static/images/80fb26b5-ade4-4113-9748-53a4749e1411.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        5,
        139::numeric(12,2),
        'Hochjoch-Hospiz',
        'Austria',
        'Alda Carlino',
        'http://hard-muscat.com',
        328.465,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Alceo_Soro@email.it',
        '+398190608312',
        '["/static/images/80fb26b5-ade4-4113-9748-53a4749e1411.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        8,
        40::numeric(12,2),
        'Meilerhütte',
        'Germany',
        'Diamante Perin',
        'https://careless-glider.it',
        267.729,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Ismaele_Burgio@gmail.com',
        '+392491764281',
        '["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        7,
        50::numeric(12,2),
        'Gaudeamushütte',
        'Austria',
        'Nicodemo Liverani',
        'https://tremendous-broccoli.it',
        331.034,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Franco91@gmail.com',
        '+396387594870',
        '["/static/images/01ca1313-f573-4144-a2dd-b4be8426d956.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        9,
        58::numeric(12,2),
        'Rheydter Hütte',
        'Germany',
        'Apollina Pintus',
        'http://gross-earth.it',
        332.782,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Giacinta.Salvadori9@email.it',
        '+394705549761',
        '["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        8,
        86::numeric(12,2),
        'Sektionshütte Krippen',
        'Germany',
        'Carmen Di Domenico',
        'http://clear-forte.org',
        291.951,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Fabio.Moscato65@email.it',
        '+397923666661',
        '["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        10,
        56::numeric(12,2),
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Orlando Pellicano',
        'http://dual-fix.org',
        284.056,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Rainaldo_Maltese@libero.it',
        '+397794883585',
        '["/static/images/80fb26b5-ade4-4113-9748-53a4749e1411.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        3,
        57::numeric(12,2),
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Postumio De Giorgio',
        'http://incompatible-lighting.com',
        277.383,
        '03:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Lamberto77@gmail.com',
        '+398304420353',
        '["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        3,
        42::numeric(12,2),
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Aniello Cantagallo',
        'https://outgoing-screenwriting.com',
        316.961,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Rosalinda_DArgenio@libero.it',
        '+396386535079',
        '["/static/images/43900d12-7f53-4110-a6b7-772e716dbc60.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        5,
        39::numeric(12,2),
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Dr. Betta Andreoli',
        'http://majestic-sushi.it',
        286.674,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Gallicano.Cipolla@gmail.com',
        '+392022060190',
        '["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        2,
        144::numeric(12,2),
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Rainelda Gervasi',
        'http://cautious-redhead.org',
        300.786,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Serviliano_Cottone@email.it',
        '+391779586979',
        '["/static/images/78948680-d691-4336-a553-7c89e39fe780.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        1,
        42::numeric(12,2),
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Dagoberto Baldassarre',
        'https://inferior-gunpowder.org',
        288.16,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Silvana.Porcari80@email.it',
        '+394994010481',
        '["/static/images/78948680-d691-4336-a553-7c89e39fe780.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        3,
        96::numeric(12,2),
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Ave Pezzella',
        'http://shocking-waveform.net',
        282.466,
        '08:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Fernando.Paola@email.it',
        '+393359457670',
        '["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        3,
        108::numeric(12,2),
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Natalina Borghi',
        'https://jaded-bongo.org',
        304.945,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Cassiopea.Riccio@email.it',
        '+397905947710',
        '["/static/images/aa925b5a-c2a8-4e11-b7a4-c3cb23edb638.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        10,
        72::numeric(12,2),
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Cora Gagliardi',
        'https://great-academics.net',
        324.465,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Isidora98@yahoo.com',
        '+397369451902',
        '["/static/images/1dde1d2f-e97e-4247-8480-72a7085c93cb.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        5,
        66::numeric(12,2),
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Arduino Capone',
        'http://distant-pot.org',
        268.827,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Brunilde18@gmail.com',
        '+397514685049',
        '["/static/images/d107a330-c003-449b-bac4-2ea46d6d380c.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        6,
        53::numeric(12,2),
        'Dobra voda',
        'Suvobor, Serbia',
        'Vito Franzoni',
        'https://fresh-crotch.it',
        330.164,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Marta.Gigliotti@yahoo.com',
        '+398415238989',
        '["/static/images/36bdeba2-0744-4db0-85d3-4ce367c3faf8.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        1,
        106::numeric(12,2),
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Onesto Silvestrini',
        'http://stupid-dragster.com',
        331.775,
        '02:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Anatolia_Carrozzo15@hotmail.com',
        '+399674225289',
        '["/static/images/d50d1121-5179-442a-adb4-c157bd9f3aba.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        4,
        107::numeric(12,2),
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Carmela Canova',
        'http://lanky-growth.com',
        319.266,
        '03:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Romualdo.Passarelli@gmail.com',
        '+399802717702',
        '["/static/images/0033a9a1-ae3b-44b0-8c1d-cf1685b96f98.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/13000e2e-e50e-408a-8c90-c713e62df92a.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg","/static/images/ef15ddac-c669-4f41-a1dd-f2b711429bab.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        5,
        76::numeric(12,2),
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Fiordaliso Cappiello',
        'https://past-use.com',
        315.782,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Bino_Petronio11@hotmail.com',
        '+397731577088',
        '["/static/images/4d67edf5-5712-4e90-814c-c784442057c5.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/ffb44c11-5f34-4cd5-9393-595aafafafc3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        3,
        101::numeric(12,2),
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Zanita Graziani',
        'https://rash-vineyard.com',
        308.04,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Fidenzio79@libero.it',
        '+395983003331',
        '["/static/images/69988409-508f-4aa4-a567-a1feb5c8429e.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/e86393d7-72cc-4455-8e00-dcecbcbc9375.jpg","/static/images/022e164b-cb32-4b4e-8312-a34e883e309b.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        9,
        47::numeric(12,2),
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Natalina Zanatta',
        'https://merry-testing.net',
        279.03,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Vasco.Pirrone32@yahoo.com',
        '+397502462015',
        '["/static/images/8a8c2365-2d64-43f8-a221-b05bf5ffaa47.jpg","/static/images/d8f2b907-85d4-4195-9752-6762b2b5301e.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/3fef069c-d482-4d0f-9470-0d689161951c.jpg","/static/images/9ae46d82-37fa-4fae-92ab-3b46dda2903b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        10,
        110::numeric(12,2),
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Aiace Barbarulo',
        'http://insistent-lookout.com',
        333.521,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Demetria_Dionisi70@hotmail.com',
        '+393267029969',
        '["/static/images/b16ffd6b-749a-41fe-a316-2dbe73e0b56e.jpg","/static/images/a8c1fe33-ffeb-4555-a925-7b747fe30387.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        3,
        140::numeric(12,2),
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Gioia Tasso',
        'https://astonishing-midline.net',
        278.16,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Eustorgio_Ferroni45@email.it',
        '+394279268223',
        '["/static/images/c2613970-2a27-4a40-9cc5-fd2312ca4e60.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg","/static/images/377c45b2-3d10-4132-a98d-2c3646cddbb9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        8,
        141::numeric(12,2),
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Violante Zappalà',
        'https://alive-revitalisation.it',
        338.157,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Lorena_Pintus84@gmail.com',
        '+393007705372',
        '["/static/images/78948680-d691-4336-a553-7c89e39fe780.jpg","/static/images/6c7965b3-62c5-49cc-8635-5a0a54199150.jpg","/static/images/43c9d8a0-8993-4792-9176-f96b0097963f.jpg","/static/images/9485d4cb-95f1-4006-878d-ddcc02937f91.jpg","/static/images/fda8a922-6935-4b34-a30a-110eab05b59d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        3,
        106::numeric(12,2),
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Dott. Marciano Ledda',
        'http://klutzy-rainy.net',
        305.835,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Mercede_Valenza@libero.it',
        '+396409572071',
        '["/static/images/87ce0c23-8549-46fc-8538-103433b20a3c.jpg","/static/images/36c94691-ea58-493a-951c-b1fa25a2a95b.jpg","/static/images/ad677cd2-2821-44b0-83b8-b8b22d151f7c.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        8,
        114::numeric(12,2),
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Elda Carlucci',
        'http://legal-backburn.com',
        337.997,
        '03:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Riccarda.Cipollaro50@yahoo.com',
        '+395220368758',
        '["/static/images/b16ffd6b-749a-41fe-a316-2dbe73e0b56e.jpg","/static/images/0e20eeba-8465-42a9-830b-76d46097be90.jpg","/static/images/0e428711-f5c4-48cf-97e0-419cd8fe2824.jpg","/static/images/d4e9e432-30b1-43e8-9fd6-5c753513d8b4.jpg","/static/images/96e281f8-728a-4614-b473-fa4133d82952.jpg"]'::jsonb
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '61 Via Aristotele, Benedetti terme, Italy',
        'Benedetti terme',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        73,
        '1 Strada Biccari, Quarto Fabiana a mare, Italy',
        'Quarto Fabiana a mare',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        292,
        '0 Borgo Zabedeo, Polese lido, Italy',
        'Polese lido',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        79,
        '2 Borgo Viti, Lorusso ligure, Italy',
        'Lorusso ligure',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        260,
        '63 Contrada Brunilde, Quarto Serafina, Italy',
        'Quarto Serafina',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        275,
        '666 Rotonda Marelli, Settimo Euridice ligure, Italy',
        'Settimo Euridice ligure',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        293,
        '4 Borgo Di Gennaro, Settimo Venera umbro, Italy',
        'Settimo Venera umbro',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        227,
        '709 Strada Rufina, Crespignano lido, Italy',
        'Crespignano lido',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        173,
        '879 Rotonda Argo, San Annamaria lido, Italy',
        'San Annamaria lido',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        248,
        '2 Incrocio Doda, Bruschi calabro, Italy',
        'Bruschi calabro',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        255,
        '14 Contrada Ledda, San Amando, Italy',
        'San Amando',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        283,
        '2 Borgo Privitera, Borgo Ginevra, Italy',
        'Borgo Ginevra',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        207,
        '16 Via Taziano, Borgo Antimo del friuli, Italy',
        'Borgo Antimo del friuli',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        99,
        '6 Piazza Gaglioffo, Giovanni umbro, Italy',
        'Giovanni umbro',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        153,
        '81 Rotonda Pio, Quarto Callisto salentino, Italy',
        'Quarto Callisto salentino',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        147,
        '0 Incrocio Natalia, Settimo Amone, Italy',
        'Settimo Amone',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        118,
        '799 Strada Biagetti, Nicolini salentino, Italy',
        'Nicolini salentino',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        51,
        '7 Piazza Calligaris, San Leonzio del friuli, Italy',
        'San Leonzio del friuli',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        121,
        '4 Piazza Elisabetta, Di Marino lido, Italy',
        'Di Marino lido',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        235,
        '4 Via Sviturno, Gatto laziale, Italy',
        'Gatto laziale',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        107,
        '248 Rotonda Nobili, San Ermenegarda calabro, Italy',
        'San Ermenegarda calabro',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        228,
        '589 Rotonda Placida, Fichera sardo, Italy',
        'Fichera sardo',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '53 Strada Latini, San Ombretta umbro, Italy',
        'San Ombretta umbro',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        111,
        '84 Rotonda Sapiente, Miceli nell''emilia, Italy',
        'Miceli nell''emilia',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        64,
        '441 Strada Morra, Malagoli veneto, Italy',
        'Malagoli veneto',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        41,
        '130 Via Calpurnia, Settimo Grazia, Italy',
        'Settimo Grazia',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        56,
        '8 Via Cipolletta, Quarto Aleandro a mare, Italy',
        'Quarto Aleandro a mare',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        273,
        '07 Piazza Anastasia, San Flora, Italy',
        'San Flora',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        28,
        '16 Rotonda Palladio, Luzzi salentino, Italy',
        'Luzzi salentino',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        168,
        '685 Strada Catarsi, Carlotti terme, Italy',
        'Carlotti terme',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        236,
        '22 Contrada Ruberto, Venturelli calabro, Italy',
        'Venturelli calabro',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        27,
        '18 Borgo Catarsi, Quarto Ascanio, Italy',
        'Quarto Ascanio',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        39,
        '4 Via D''Amico, Quarto Anita, Italy',
        'Quarto Anita',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '3 Piazza Ataleo, Ranucci veneto, Italy',
        'Ranucci veneto',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        192,
        '54 Incrocio Bernardi, San Emmerico terme, Italy',
        'San Emmerico terme',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        217,
        '5 Strada Spiga, Erardo umbro, Italy',
        'Erardo umbro',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        34,
        '0 Via Liberata, Priscilla umbro, Italy',
        'Priscilla umbro',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        291,
        '1 Piazza Beretta, Borgo Ventura, Italy',
        'Borgo Ventura',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        217,
        '116 Contrada Agostina, Niceto a mare, Italy',
        'Niceto a mare',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        265,
        '085 Borgo Berardi, Rocca sardo, Italy',
        'Rocca sardo',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '3 Borgo Giordano, Colombano terme, Italy',
        'Colombano terme',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        176,
        '60 Incrocio Bernabei, Borgo Emilia laziale, Italy',
        'Borgo Emilia laziale',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        278,
        '106 Piazza Tallone, Filice sardo, Italy',
        'Filice sardo',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        40,
        '06 Incrocio Torrisi, Bonomi lido, Italy',
        'Bonomi lido',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        211,
        '674 Via Boni, Cozzolino terme, Italy',
        'Cozzolino terme',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        207,
        '494 Borgo Maggio, Catena lido, Italy',
        'Catena lido',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        282,
        '0 Piazza Costanza, Fabio nell''emilia, Italy',
        'Fabio nell''emilia',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        98,
        '1 Borgo Novello, Borgo Mennone, Italy',
        'Borgo Mennone',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        65,
        '31 Piazza Patriarca, Belotti del friuli, Italy',
        'Belotti del friuli',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        118,
        '73 Piazza Romano, Teodoto ligure, Italy',
        'Teodoto ligure',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        232,
        '440 Via Francesconi, Morabito lido, Italy',
        'Morabito lido',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '1 Contrada Urso, Settimo Adria, Italy',
        'Settimo Adria',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        76,
        '277 Strada Cremona, Castellani nell''emilia, Italy',
        'Castellani nell''emilia',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '0 Strada Edda, Quarto Emiliano terme, Italy',
        'Quarto Emiliano terme',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        214,
        '7 Borgo Ischirione, Cozzolino ligure, Italy',
        'Cozzolino ligure',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        26,
        '1 Rotonda Davide, Borgo Basileo sardo, Italy',
        'Borgo Basileo sardo',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        300,
        '3 Rotonda Terenzio, San Gerino terme, Italy',
        'San Gerino terme',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        90,
        '9 Via Geronzio, Gustavo sardo, Italy',
        'Gustavo sardo',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        297,
        '52 Via Alessia, Loretta veneto, Italy',
        'Loretta veneto',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        234,
        '771 Incrocio Cimmino, San Leopoldo ligure, Italy',
        'San Leopoldo ligure',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        90,
        '3 Incrocio Pica, Delfina lido, Italy',
        'Delfina lido',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        207,
        '35 Strada Cornelia, Clara del friuli, Italy',
        'Clara del friuli',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        36,
        '35 Contrada Rosamunda, Settimo Gallicano, Italy',
        'Settimo Gallicano',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        109,
        '8 Rotonda Milella, Borgo Lieto, Italy',
        'Borgo Lieto',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        161,
        '88 Contrada Verulo, Quarto Vinebaldo lido, Italy',
        'Quarto Vinebaldo lido',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        152,
        '1 Piazza Tonini, Quarto Severino salentino, Italy',
        'Quarto Severino salentino',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        152,
        '76 Piazza Papini, San Bino, Italy',
        'San Bino',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        180,
        '0 Borgo Filice, Baldovino salentino, Italy',
        'Baldovino salentino',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        223,
        '92 Incrocio Fiorentini, Ulfo laziale, Italy',
        'Ulfo laziale',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '328 Via Salvatore, Sesto Gerolamo, Italy',
        'Sesto Gerolamo',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        96,
        '51 Incrocio Fusco, Ulfo calabro, Italy',
        'Ulfo calabro',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        239,
        '15 Contrada Criscenti, Sesto Siro, Italy',
        'Sesto Siro',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        209,
        '1 Borgo D''Ippolito, Valentino nell''emilia, Italy',
        'Valentino nell''emilia',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        59,
        '7 Borgo Claudia, Sesto Noemi terme, Italy',
        'Sesto Noemi terme',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        239,
        '835 Piazza De Sanctis, Settimo Sabele, Italy',
        'Settimo Sabele',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        47,
        '032 Contrada Ansaldo, Ilaria a mare, Italy',
        'Ilaria a mare',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        258,
        '271 Incrocio Rea, Settimo Teodosio calabro, Italy',
        'Settimo Teodosio calabro',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        140,
        '1 Rotonda Proserpina, Tufano sardo, Italy',
        'Tufano sardo',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        82,
        '285 Rotonda Lorusso, Settimo Ladislao, Italy',
        'Settimo Ladislao',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        123,
        '73 Strada Aleramo, Neopolo a mare, Italy',
        'Neopolo a mare',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        89,
        '600 Rotonda Praticò, Quarto Apuleio a mare, Italy',
        'Quarto Apuleio a mare',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        73,
        '84 Contrada Malatesta, Scrofani ligure, Italy',
        'Scrofani ligure',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        229,
        '402 Via Audace, Borgo Albina sardo, Italy',
        'Borgo Albina sardo',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        211,
        '9 Piazza Loredana, Criscenti terme, Italy',
        'Criscenti terme',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        60,
        '184 Borgo Ombretta, Borrelli a mare, Italy',
        'Borrelli a mare',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        208,
        '971 Via Lucidi, Borgo Noemi, Italy',
        'Borgo Noemi',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        256,
        '089 Strada Albino, Quarto Giliola, Italy',
        'Quarto Giliola',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        205,
        '00 Via Socrate, Borgo Gedeone sardo, Italy',
        'Borgo Gedeone sardo',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        48,
        '7 Rotonda Cozzani, Settimo Sarbello calabro, Italy',
        'Settimo Sarbello calabro',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        35,
        '5 Piazza Guarino, Carola salentino, Italy',
        'Carola salentino',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        268,
        '660 Via Grato, Settimo Tibaldo, Italy',
        'Settimo Tibaldo',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        101,
        '25 Contrada Telesca, Settimo Rosario veneto, Italy',
        'Settimo Rosario veneto',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        61,
        '514 Contrada Antonacci, Grieco a mare, Italy',
        'Grieco a mare',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        62,
        '366 Borgo Danio, Borgo Galdino laziale, Italy',
        'Borgo Galdino laziale',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        262,
        '25 Strada Cerrato, Ubertino sardo, Italy',
        'Ubertino sardo',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        242,
        '311 Rotonda Tolomeo, Settimo Degna, Italy',
        'Settimo Degna',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        291,
        '39 Rotonda D''Urso, Elpidio umbro, Italy',
        'Elpidio umbro',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        195,
        '4 Contrada Natalia, Algiso sardo, Italy',
        'Algiso sardo',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        62,
        '47 Borgo Zappia, Settimo Ascanio veneto, Italy',
        'Settimo Ascanio veneto',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        226,
        '1 Rotonda Gianmaria, Archimede salentino, Italy',
        'Archimede salentino',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        241,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        93,
        '32 Contrada Miotto, Valerio umbro, Italy',
        'Valerio umbro',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        224,
        '911 Incrocio Deiana, Mancino del friuli, Italy',
        'Mancino del friuli',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        300,
        '515 Via Denti, Aiello a mare, Italy',
        'Aiello a mare',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        201,
        '7 Rotonda Pacini, Ramella salentino, Italy',
        'Ramella salentino',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        87,
        '7 Contrada Carponio, Sesto Averardo sardo, Italy',
        'Sesto Averardo sardo',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        254,
        '8 Piazza Allegretti, Borgo Aida, Italy',
        'Borgo Aida',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        270,
        '9 Strada Agrippa, Scala calabro, Italy',
        'Scala calabro',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        106,
        '6 Via Venezia, Sandra ligure, Italy',
        'Sandra ligure',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        160,
        '328 Borgo Caselli, Girardi sardo, Italy',
        'Girardi sardo',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        293,
        '5 Via Osvaldo, San Ponziano, Italy',
        'San Ponziano',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        200,
        '6 Via Sannino, Quarto Orlando umbro, Italy',
        'Quarto Orlando umbro',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        273,
        '5 Rotonda Emiliana, Carlini nell''emilia, Italy',
        'Carlini nell''emilia',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        72,
        '76 Incrocio Celso, San Leonia veneto, Italy',
        'San Leonia veneto',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        242,
        '150 Piazza Nicol�, San Godiva, Italy',
        'San Godiva',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        225,
        '94 Strada Pellegrino, Carminati terme, Italy',
        'Carminati terme',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        103,
        '448 Rotonda Tomassoni, Omar laziale, Italy',
        'Omar laziale',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        31,
        '2 Incrocio Coniglio, Sesto Luisa, Italy',
        'Sesto Luisa',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        39,
        '74 Piazza Renna, Settimo Eligio, Italy',
        'Settimo Eligio',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        128,
        '78 Contrada Raffa, Quarto Liberto laziale, Italy',
        'Quarto Liberto laziale',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        290,
        '784 Via Chiara, San Abdone lido, Italy',
        'San Abdone lido',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        137,
        '702 Rotonda Bianchetti, Carlini ligure, Italy',
        'Carlini ligure',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        225,
        '69 Strada Clemente, Settimo Urbano terme, Italy',
        'Settimo Urbano terme',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        33,
        '77 Via Gualtiero, Lecca calabro, Italy',
        'Lecca calabro',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        113,
        '79 Strada Vindonio, San Athos, Italy',
        'San Athos',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        294,
        '18 Rotonda Venustiano, Ermenegarda ligure, Italy',
        'Ermenegarda ligure',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '578 Rotonda Sabatini, Sechi laziale, Italy',
        'Sechi laziale',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        169,
        '8 Via Cuzia, Damiana ligure, Italy',
        'Damiana ligure',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        47,
        '11 Incrocio Favara, Letizia del friuli, Italy',
        'Letizia del friuli',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '6 Borgo Petrelli, Settimo Gondulfo lido, Italy',
        'Settimo Gondulfo lido',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '016 Piazza Ascione, Sanfilippo nell''emilia, Italy',
        'Sanfilippo nell''emilia',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        292,
        '40 Piazza Marcella, Settimo Licia, Italy',
        'Settimo Licia',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        129,
        '6 Rotonda Pedone, Settimo Sisto, Italy',
        'Settimo Sisto',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        104,
        '36 Borgo Mannino, Carlini terme, Italy',
        'Carlini terme',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        189,
        '468 Piazza Romeo, Borgo Pierangelo terme, Italy',
        'Borgo Pierangelo terme',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        79,
        '326 Borgo Mele, Loriana sardo, Italy',
        'Loriana sardo',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '46 Borgo Triolo, Settimo Lea lido, Italy',
        'Settimo Lea lido',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '303 Rotonda Capizzi, Vidone laziale, Italy',
        'Vidone laziale',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        273,
        '4 Incrocio Ardito, Sesto Ponziano, Italy',
        'Sesto Ponziano',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '205 Via Fulvia, Bardomiano ligure, Italy',
        'Bardomiano ligure',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        197,
        '361 Contrada Oderico, Libero salentino, Italy',
        'Libero salentino',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        263,
        '5 Strada Sabino, Quarto Loretta salentino, Italy',
        'Quarto Loretta salentino',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        156,
        '068 Borgo Valerio, Borgo Telica, Italy',
        'Borgo Telica',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        235,
        '08 Rotonda Felice, Amalia veneto, Italy',
        'Amalia veneto',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        275,
        '058 Piazza Anna, Settimo Rossana a mare, Italy',
        'Settimo Rossana a mare',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        101,
        '1 Strada Aleandro, Sesto Benvenuto, Italy',
        'Sesto Benvenuto',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        284,
        '07 Borgo Aloisio, Sesto Luna veneto, Italy',
        'Sesto Luna veneto',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        199,
        '1 Rotonda Catellani, Colombo a mare, Italy',
        'Colombo a mare',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        67,
        '746 Contrada Masciandaro, Nicezio umbro, Italy',
        'Nicezio umbro',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        251,
        '920 Strada Pariggiano, Ione calabro, Italy',
        'Ione calabro',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        125,
        '60 Via Carolina, Ghita salentino, Italy',
        'Ghita salentino',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        297,
        '234 Rotonda Valentina, Parmenio nell''emilia, Italy',
        'Parmenio nell''emilia',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        83,
        '68 Rotonda Adelaide, Settimo Orsolina, Italy',
        'Settimo Orsolina',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        281,
        '727 Rotonda Rosalinda, Catalano nell''emilia, Italy',
        'Catalano nell''emilia',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        182,
        '49 Borgo Venusto, San Elsa, Italy',
        'San Elsa',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        269,
        '693 Incrocio Eloisa, Borgo Esterina umbro, Italy',
        'Borgo Esterina umbro',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        279,
        '1 Incrocio Salemme, Quarto Diamante terme, Italy',
        'Quarto Diamante terme',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        177,
        '563 Piazza Bianc, Sosteneo del friuli, Italy',
        'Sosteneo del friuli',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        266,
        '260 Piazza Innocenza, Sesto Galileo umbro, Italy',
        'Sesto Galileo umbro',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        213,
        '317 Contrada Federico, Settimo Augusto, Italy',
        'Settimo Augusto',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        263,
        '5 Contrada Geronzio, Gaudenzia nell''emilia, Italy',
        'Gaudenzia nell''emilia',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        111,
        '46 Incrocio Neoterio, Salvatori a mare, Italy',
        'Salvatori a mare',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        177,
        '65 Borgo Orietta, Pellegrino a mare, Italy',
        'Pellegrino a mare',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        71,
        '04 Borgo Maggiani, Indelicato terme, Italy',
        'Indelicato terme',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        167,
        '423 Piazza Sanna, Silvano salentino, Italy',
        'Silvano salentino',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '7 Contrada Auberto, Venera ligure, Italy',
        'Venera ligure',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        93,
        '6 Piazza Sansone, Gabriella veneto, Italy',
        'Gabriella veneto',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        118,
        '104 Rotonda Carollo, San Coriolano, Italy',
        'San Coriolano',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        77,
        '802 Incrocio Raneri, Marta terme, Italy',
        'Marta terme',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        204,
        '33 Contrada Manicone, Borgo Arabella, Italy',
        'Borgo Arabella',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        59,
        '487 Via Abbrescia, Quarto Astrid, Italy',
        'Quarto Astrid',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        284,
        '612 Rotonda Lamacchia, Quarto Vulmaro, Italy',
        'Quarto Vulmaro',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        222,
        '90 Via Bertani, Lucia veneto, Italy',
        'Lucia veneto',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        181,
        '0 Contrada Salom�, Borgo Vittorio, Italy',
        'Borgo Vittorio',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        78,
        '8 Borgo Giuliana, Borgo Priamo, Italy',
        'Borgo Priamo',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        58,
        '8 Contrada Manetti, Bacco a mare, Italy',
        'Bacco a mare',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        239,
        '8 Via Patruno, Flaviano nell''emilia, Italy',
        'Flaviano nell''emilia',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        71,
        '699 Strada Noto, Piera laziale, Italy',
        'Piera laziale',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        215,
        '530 Borgo Romana, San Attilio, Italy',
        'San Attilio',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        222,
        '4 Piazza Vodingo, Sesto Fulberto calabro, Italy',
        'Sesto Fulberto calabro',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        37,
        '16 Incrocio Glenda, Caggiano calabro, Italy',
        'Caggiano calabro',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        85,
        '345 Incrocio Cipriani, Quarto Alfonso lido, Italy',
        'Quarto Alfonso lido',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '79 Contrada Palmieri, Loffredo lido, Italy',
        'Loffredo lido',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        263,
        '3 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        62,
        '413 Incrocio Felicia, Ludovico terme, Italy',
        'Ludovico terme',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        79,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        78,
        '0 Piazza Luce, Liberatore veneto, Italy',
        'Liberatore veneto',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        98,
        '9 Contrada Democrito, Settimo Federica, Italy',
        'Settimo Federica',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        60,
        '104 Strada Soccorsi, Arcadio umbro, Italy',
        'Arcadio umbro',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        236,
        '58 Rotonda De Col, Zenone veneto, Italy',
        'Zenone veneto',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        71,
        '041 Piazza Urso, Settimo Vincenza nell''emilia, Italy',
        'Settimo Vincenza nell''emilia',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        103,
        '42 Rotonda Teodolinda, Fulvia laziale, Italy',
        'Fulvia laziale',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        148,
        '6 Contrada Claudio, Sesto Euseo, Italy',
        'Sesto Euseo',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        254,
        '88 Borgo Gentile, Davino lido, Italy',
        'Davino lido',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        285,
        '0 Incrocio Durante, Sesto Donatello, Italy',
        'Sesto Donatello',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        289,
        '997 Piazza Neri, Cara laziale, Italy',
        'Cara laziale',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        277,
        '04 Strada Ercolano, Borgo Atanasio laziale, Italy',
        'Borgo Atanasio laziale',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        187,
        '476 Borgo Cecchetti, Silvana ligure, Italy',
        'Silvana ligure',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        227,
        '38 Piazza Borrelli, Distefano ligure, Italy',
        'Distefano ligure',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        155,
        '5 Borgo Zuliani, Raide veneto, Italy',
        'Raide veneto',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        272,
        '594 Strada Beniamino, Sesto Amelia veneto, Italy',
        'Sesto Amelia veneto',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        294,
        '840 Contrada Fermiano, Betta veneto, Italy',
        'Betta veneto',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '767 Contrada Vanna, Alessio nell''emilia, Italy',
        'Alessio nell''emilia',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        38,
        '938 Rotonda Liberati, Lidia salentino, Italy',
        'Lidia salentino',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        177,
        '81 Strada Vivaldo, Settimo Eufemia terme, Italy',
        'Settimo Eufemia terme',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        263,
        '71 Incrocio Erminio, Beniamina nell''emilia, Italy',
        'Beniamina nell''emilia',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        269,
        '748 Piazza Gaia, San Nadia umbro, Italy',
        'San Nadia umbro',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        277,
        '71 Via Manicone, San Lapo salentino, Italy',
        'San Lapo salentino',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        265,
        '9 Strada Privitera, Settimo Leda sardo, Italy',
        'Settimo Leda sardo',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        51,
        '2 Strada Palumbo, Settimo Lauriano, Italy',
        'Settimo Lauriano',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        221,
        '25 Rotonda Novella, Sesto Natalina salentino, Italy',
        'Sesto Natalina salentino',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        123,
        '984 Rotonda Molinaro, Settimo Venceslao, Italy',
        'Settimo Venceslao',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '30 Via Scorza, Viviano laziale, Italy',
        'Viviano laziale',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        294,
        '336 Contrada Schillaci, Babini del friuli, Italy',
        'Babini del friuli',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        41,
        '347 Via Rosario, Quarto Baldassarre ligure, Italy',
        'Quarto Baldassarre ligure',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        102,
        '485 Strada Monica, Settimo Sidonia, Italy',
        'Settimo Sidonia',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        180,
        '26 Strada Cammarata, Settimo Galdino, Italy',
        'Settimo Galdino',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        131,
        '966 Via Demetrio, Del Vecchio a mare, Italy',
        'Del Vecchio a mare',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        157,
        '5 Piazza Petrelli, Fiorenza ligure, Italy',
        'Fiorenza ligure',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        141,
        '2 Borgo Lavecchia, San Raimondo nell''emilia, Italy',
        'San Raimondo nell''emilia',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        140,
        '6 Rotonda Santo, San Apollinare del friuli, Italy',
        'San Apollinare del friuli',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '38 Rotonda Mosca, Molinari nell''emilia, Italy',
        'Molinari nell''emilia',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        219,
        '80 Piazza Damico, Silenzi ligure, Italy',
        'Silenzi ligure',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        165,
        '64 Rotonda Lotito, Settimo Severa ligure, Italy',
        'Settimo Severa ligure',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        170,
        '534 Rotonda Nicotra, Iorio a mare, Italy',
        'Iorio a mare',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        213,
        '0 Via Manfredi, Giadero salentino, Italy',
        'Giadero salentino',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        67,
        '3 Incrocio Rocco, Settimo Altea, Italy',
        'Settimo Altea',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        60,
        '33 Incrocio Lugli, Quarto Silverio, Italy',
        'Quarto Silverio',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        100,
        '7 Contrada Boris, Clarenzio sardo, Italy',
        'Clarenzio sardo',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        187,
        '9 Rotonda Barra, Quarto Cleo a mare, Italy',
        'Quarto Cleo a mare',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        204,
        '1 Rotonda Villa, Quarto Marilena laziale, Italy',
        'Quarto Marilena laziale',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        228,
        '57 Borgo Giobbe, Sesto Augusto ligure, Italy',
        'Sesto Augusto ligure',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        286,
        '7 Borgo Flora, Sesto Calcedonio sardo, Italy',
        'Sesto Calcedonio sardo',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        121,
        '90 Borgo Florina, Loreto umbro, Italy',
        'Loreto umbro',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        41,
        '3 Contrada Piero, Ciotola ligure, Italy',
        'Ciotola ligure',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        41,
        '9 Rotonda Viviana, Quarto Semiramide calabro, Italy',
        'Quarto Semiramide calabro',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        274,
        '331 Incrocio No�, Bozzi a mare, Italy',
        'Bozzi a mare',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        166,
        '4 Incrocio Berenice, Sesto Galeazzo nell''emilia, Italy',
        'Sesto Galeazzo nell''emilia',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        82,
        '20 Strada Mareta, Letizia terme, Italy',
        'Letizia terme',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        88,
        '334 Strada Ludano, Maida del friuli, Italy',
        'Maida del friuli',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        147,
        '3 Incrocio Alfonso, Sesto Nostriano nell''emilia, Italy',
        'Sesto Nostriano nell''emilia',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        217,
        '622 Via Evelina, Sesto Ermes, Italy',
        'Sesto Ermes',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        107,
        '227 Strada Belli, Settimo Rosalinda calabro, Italy',
        'Settimo Rosalinda calabro',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        222,
        '947 Piazza Boschi, Pozzi nell''emilia, Italy',
        'Pozzi nell''emilia',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        74,
        '41 Strada Zani, Settimo Napoleone, Italy',
        'Settimo Napoleone',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        186,
        '02 Borgo Grimaldo, Narseo sardo, Italy',
        'Narseo sardo',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        140,
        '245 Incrocio Narciso, Ventimiglia salentino, Italy',
        'Ventimiglia salentino',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        287,
        '55 Borgo Alboino, Borgo Doda, Italy',
        'Borgo Doda',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        275,
        '5 Incrocio Di Domenico, Borgo Nicarete, Italy',
        'Borgo Nicarete',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '65 Piazza Daniele, San Ottone, Italy',
        'San Ottone',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        121,
        '82 Borgo Papapietro, San Goffredo, Italy',
        'San Goffredo',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        69,
        '72 Borgo Iginio, Modesto umbro, Italy',
        'Modesto umbro',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        238,
        '71 Borgo Pozzi, Borgo Lea, Italy',
        'Borgo Lea',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        28,
        '48 Piazza Manno, Massa laziale, Italy',
        'Massa laziale',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        162,
        '8 Via Agnese, Sesto Euseo, Italy',
        'Sesto Euseo',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        244,
        '750 Via Martorana, Testa lido, Italy',
        'Testa lido',
        'Italy',
        'Brindisi',
        ''
      );
    
  