--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$2A8zS8PpFpKUyaAlJpgsx.11KKXzJb08Gt2pq/0EHGOXojY2lnGlC',
    'Antonio',
    'Battipaglia',
    2,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$LRMiB6LpVXDglh80HtXpW.KFmnlxZu4/MRlnEM99/NE1Z4fJpWm0i',
    'Erfan',
    'Gholami',
    4,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$cNgHjgkrJUhaFc7ESXHQMeCv5eZE/aMEdJp6lMlN5N3fngscaKuHm',
    'Laura',
    'Zurru',
    5,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$qSYnqVEscI2PG9Al2wv4JOuhGoHko4B99lCLv7gHhjHShkMJ1A5Sy',
    'German',
    'Gorodnev',
    0,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$zT1NnqSVj8Tzq9zNM6.Mx.qL/XgotmdRgiBwshGzolQKyul8MIssK',
    'Vincenzo',
    'Sagristano',
    3,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    6,
    'francesco@friend.it',
    '$2b$10$bel6eUcsi2CTpQwk4DQ8vecUtxYOcBA.vkWyAv0kTOfsxwUm83KN6',
    'Francesco',
    'Grande',
    1,
    true,
    true
  );
  

      CREATE OR REPLACE FUNCTION public.insert_hike(
        user_id integer,
        title varchar,
        difficulty integer,
        gpx_path varchar,
        country varchar,
        region varchar,
        province varchar,
        city varchar,
        length numeric(12,2),
        ascent numeric(12,2),
        expected_time integer,
        description varchar,
        pictures jsonb,
        start_point jsonb,
        end_point jsonb,
        reference_points jsonb
      )  RETURNS VOID AS
      $func$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'name')::varchar,
            (ref->>'address')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hike"(
        2,
        'Amprimo',
        2,
        '/static/gpx/Amprimo.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        9300,
        481.1,
        80,
        'Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.',
        '["/static/images/3.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.165559804,"lat":45.102780737}'::jsonb,
        '{"name":"End Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.14299586,"lat":45.099887898}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":7.164360252,"lat":45.102912389,"altitude":1256.852},{"name":"Ref Point 2","address":"","lon":7.158207147,"lat":45.102886551,"altitude":1283.605}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello Chateau Beaulard - Cotolivier - Vazon',
        1,
        '/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Beaulard',
        8700,
        583.7,
        200,
        'Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.',
        '["/static/images/2.jpg"]'::jsonb,
        '{"name":"Start Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.772358,"lat":45.03205}'::jsonb,
        '{"name":"End Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.77234,"lat":45.032238}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'borgata ruà a cima di crosa',
        1,
        '/static/gpx/Borgata Ruà-Cima di Crosa (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Sampeyre',
        5387.070533803441,
        955.0963319999998,
        150,
        'Raggiungi la partenza del Sentiero per la Cima di Crosa impostando sul navigatore “Borgata Ruà – Becetto“.

Parcheggiata la macchina a Borgata Ruà (o se impossibilitati a trovare un parcheggio anche a Becetto, allungando di 10 minuti il giro), si prende il sentiero sulla sinistra, nei pressi di una cartina (INDICAZIONI CIMA DI CROSA).',
        '["/static/images/46.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia","lon":7.201825,"lat":44.596613}'::jsonb,
        '{"name":"End Point","address":"Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia","lon":7.177367,"lat":44.615185}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Colle della Gianna da Pian della Regina',
        2,
        '/static/gpx/Colle Della Gianna (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        3622.3230077193216,
        865.2000000000003,
        130,
        'Colle della Gianna at an altitude of approximately 2530m connects the Po Valley to the Pellice Valley allowing you to reach the Barbara Lowrie refuge, an ideal base for multi-day crossings.

It is advisable to carefully consult the weather forecasts especially for these areas frequently subject to very thick fog.

Being at moderately high altitudes in spring there is the possibility of finding tongues of snow that could make the ascent more difficult.',
        '["/static/images/37.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia","lon":7.114553963765502,"lat":44.70202149823308}'::jsonb,
        '{"name":"End Point","address":"Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia","lon":7.103742817416787,"lat":44.722054582089186}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Hike Zicher',
        3,
        '/static/gpx/Hike_Zicher (2).gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Craveggio',
        3221.31231047859,
        712.936152,
        120,
        'Lungo l’itinerario non è garantita la piena copertura telefonica
In periodo estivo, la parte finale può essere molto esposta al sole e richiedere fatica.
In condizioni di vento forte, è preferibile non proseguire
E’ possibile sviluppare un itinerario ad anello scendendo dal versante nord della montagna in direzione Bocchetta Sant’Antonio (ma attenzione ad un passaggio su rocce, soprattutto se ghiacciate).',
        '["/static/images/29.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia","lon":8.534505,"lat":46.147128}'::jsonb,
        '{"name":"End Point","address":"Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia","lon":8.534103,"lat":46.163437}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Usseaux Altro',
        2,
        '/static/gpx/Laghi_Albergian.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Usseaux',
        15636.670195666402,
        1366.7991943359375,
        150,
        'The flowering of Eriofori along the shores of the lake between July and August is interesting, making it very suggestive.',
        '["/static/images/40.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025457266718149,"lat":45.0393102876842}'::jsonb,
        '{"name":"End Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025509485974908,"lat":45.039591416716576}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Usseaux Altro',
        3,
        '/static/gpx/Laghi_Albergiani.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Usseaux',
        15636.670195666402,
        1366.7991943359375,
        150,
        'Itinerario vario e panoramico, non presenta particolari difficoltà ma per la lunghezza, il dislivello, la mancanza di punti di appoggio e la necessità di una certa capacità di orientamento su sentieri non sempre evidenti (specialmente per la variante in discesa) è consigliato a escursionisti allenati e esperti.',
        '["/static/images/42.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025457266718149,"lat":45.0393102876842}'::jsonb,
        '{"name":"End Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025509485974908,"lat":45.039591416716576}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago Bianco',
        2,
        '/static/gpx/Lago Bianco.gpx',
        'Francia',
        'Auvergne-Rhone-Alpes',
        'Savoia',
        'Val-Cenis',
        8100,
        101.9,
        210,
        'Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.

La diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.

La Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.

Si può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.',
        '["/static/images/1.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945681,"lat":45.223814}'::jsonb,
        '{"name":"End Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945581,"lat":45.224058}'::jsonb,
        '[{"name":"fountain","address":"","lon":6.940291,"lat":45.222543,"altitude":2027},{"name":"Peak","address":"","lon":6.937204,"lat":45.215867,"altitude":2131}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Lago dei 7 colori (lago gignoux)',
        2,
        '/static/gpx/Lago dei 7 colori (lago gignoux) (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Claviere',
        21358.82545547226,
        1087.900000000002,
        170,
        'Parcheggia a Claviere e dirigiti verso la strada comunale Valle Gimont che, dopo poco, si fa sterrata.

Lascia alla tua destra i cartelli che indicano il Lago Gignoux e prosegui risalendo le piste da sci.

Giunto a Sagna Longa noterai che la zona è di interesse sciistico, infatti ci sono numerosi arrivi di seggiovia. Segui le indicazioni per Colle Bercia, attraversa una chiesetta, dei caseggiati in pietra e prosegui per il largo sentiero.

L’intero percorso si sviluppa circondato dai bellissimi Monti della Luna ed è caratterizzato da una dolce e semicostante salita su terreno sterrato a tratti ghiaioso.

Superato il Colle Bercia continua sull’ampia carreggiata che ti conduce ad un valico nel quale noterai particolari conformazioni rocciose e una punta (Cima Saurel 2451 mt). Tieniti sul sentiero basso e supera il valico, che segna anche il confine con la Francia, dopo il quale troverai il lago immerso in una conca.',
        '["/static/images/51.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia","lon":6.749585,"lat":44.938467}'::jsonb,
        '{"name":"End Point","address":"Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia","lon":6.749585,"lat":44.938467}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago d''Afframont 1986 m',
        2,
        '/static/gpx/Lago di Afframont 1986 m.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Balme',
        4024.727690039548,
        810.8999999999994,
        120,
        'Una volta parcheggiata la macchina dirigiti verso il villaggio Albaron. Poco dopo i caseggiati ti troverai di fronte ad un impianto di risalita dismesso, a sinistra troverai un campetto da calcio, proprio dopo il campetto si intravedono i primi cartelli con le indicazioni per il Lago di Afframont. Il sentiero da seguire è il 213, ma lungo il tragitto troverai solo bandiere bianco/rosse e cartelli di legno che indicano la destinazione.

Si sale l’ex pista da sci e ci si addentra nel bosco. Il primo tratto rimane ombreggiato, mentre inizia a farsi sentire la salita. Ad un certo punto ci si affianca ad un ruscello, il Rio di Afframont, che scorre sulla sinistra e si supera con facilità in prossimità dei caseggiati in pietra (attenzione nei periodi di pioggia perché potrebbe essere impraticabile).',
        '["/static/images/52.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia","lon":7.223873427137733,"lat":45.30158649198711}'::jsonb,
        '{"name":"End Point","address":"Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia","lon":7.238771421834827,"lat":45.292359441518784}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Briccas da Borgata Brich 20/02/21',
        2,
        '/static/gpx/Monte Briccas da Brich (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        7580.49492167635,
        1049.2599999999993,
        110,
        'After leaving the car, we continue along the road, first paved and then dirt.

In case of little snow or high temperatures it is possible to cover the first 150m in altitude without snowshoes.

As soon as we hit the first snow, we put on our snowshoes and set off on a well-defined path that crosses a wood.

After having left the last huts behind us, we turn right towards the North/East near a GTA trail sign painted on a boulder.

From here, after the last bush, an enormous, very wide slope opens up before us which culminates right at our peak',
        '["/static/images/35.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia","lon":7.159385243430734,"lat":44.70842678099871}'::jsonb,
        '{"name":"End Point","address":"Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia","lon":7.158207753673196,"lat":44.708156045526266}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Monte Ferra Con Marco e Daniel',
        3,
        '/static/gpx/Monte Ferra (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cuneo',
        11664.786185753126,
        1472.7999999999993,
        150,
        'Fondamentali i bastoncini specialmente nella discesa dal Monte Ferra al lago Reisassa.

Unico punto di appoggio è il rifugio Melezè ad inizio itinerario (consigliamo di contattare direttamente la struttura per verificare giorni e orari di apertura)',
        '["/static/images/28.jpg"]'::jsonb,
        '{"name":"Start Point","address":"SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia","lon":6.982689192518592,"lat":44.57425086759031}'::jsonb,
        '{"name":"End Point","address":"SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia","lon":6.982647031545639,"lat":44.574263943359256}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Crissolo a Ghincia',
        2,
        '/static/gpx/Monte Granè (2).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        6229.073301997005,
        1024.7599999999993,
        200,
        'The Path to Monte Granè is a suggestive walk with a splendid view of Monviso (3841 m) and Viso Mozzo (3019 m).

Leave the car in the car park and continue to the left of the sports field where a splendid path immersed in the woods appears before us and after about 1.5 km you come to the dirt road which in summer leads to the Black Eagle refuge.

Continuing on the latter and having reached the refuge, continue along the Crissolo slopes to the end of the ski-lift where, just above the Ghincia Pastour hut, we will find a statue of the Madonna to indicate the end of the path to Monte Granè.

The return takes place along the same route as the outward journey.',
        '["/static/images/36.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.151954518631101,"lat":44.70016373321414}'::jsonb,
        '{"name":"End Point","address":"Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.121506668627262,"lat":44.688729643821716}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Montr Pigna da Prea',
        2,
        '/static/gpx/Monte Pigna Da Prea (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Roccaforte Mondovì',
        6588.816640728274,
        936.79,
        150,
        'Posteggiata la macchina nel parcheggio sotto l’abitato di Prea ci dirigiamo lungo la strada asfaltata situata sotto il cimitero, lasciandocelo sulla destra.

Appena incontriamo la prima neve possiamo allacciare le ciaspole e proseguire fino alla borgata di Sant’Anna di Prea. (Nei mesi invernali, con nevicate nella norma, la strada viene pulita fino al parcheggio quindi si può iniziare ad indossare le ciaspole fin da subito).

Subito dopo il cartello, all’ingresso di Sant’Anna di Prea, sulla destra vi è un magnifico sentiero immerso nel bosco che permette di tagliare la borgata accorciando la salita di circa 1 km.

Incrociando nuovamente la strada principale e percorrendo circa 3 km si giunge alla Baita Monte Pigna situata a metà degli impianti di Lurisia.',
        '["/static/images/47.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Pigna - Gardiola, Chiusa di Pesio, Cuneo, Piemonte, 12088, Italia","lon":7.738071503117681,"lat":44.27760533988476}'::jsonb,
        '{"name":"End Point","address":"","lon":7.702411115169525,"lat":44.25919541157782}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pian della Regina - Laghi del Monviso',
        2,
        '/static/gpx/Pian della Regina - Laghi del Monviso (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        10065.934631649065,
        842.6999999999998,
        130,
        'The excursion can start near the Po, parking the car in one of the many spaces available. Once you have crossed the stream, follow via Ruata.

To get your bearings in Crissolo, we suggest following the signs for "La Capanna" and ignoring the various detours on the left that follow the ski lifts. Before reaching the restaurant, you finally take the road, following the signs for Monte Tivoli.

The path climbs up into the wood (splendid during the autumn season) and crosses the Sbarme stream.',
        '["/static/images/32.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.117767,"lat":44.700645}'::jsonb,
        '{"name":"End Point","address":"Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.117535,"lat":44.700759}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Fenestrelle Escursionismo',
        2,
        '/static/gpx/Rif. Selleries.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        7281.87058844728,
        504.40087890625,
        120,
        'Itinerario di medio sviluppo con ampio panorama verso la Val Chisone.

Attenzione nella stagione invernale: la zona soggetta a valanghe in caso di abbondanti precipitazioni nevose, specialmente nella conca che precede il rifugio.

Informarsi sempre sullo stato della neve presso i gestori del rifugio o l’ufficio turistico di Fenestrelle.',
        '["/static/images/43.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia","lon":7.0737862307578325,"lat":45.03657284192741}'::jsonb,
        '{"name":"End Point","address":"Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia","lon":7.120104543864727,"lat":45.047753965482116}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Meira Garneri da Sampeyre',
        0,
        '/static/gpx/Rifugio Meira Garneri da Sampeyre (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Sampeyre',
        4156.23862253066,
        850.7600000000003,
        150,
        'Lascia l’auto nel parcheggio della seggiovia di Sampeyre.

Lasciato il parcheggio saliamo subito a destra degli impianti di risalita, dove alcuni cartelli rossi ci segnalano il sentiero attraverso il bosco.

Prendendo rapidamente quota, alla fine del primo tratto di boscoso, raggiungiamo la frazione Sodani dove possiamo osservare la bella chiesa affrescata.

Usciti dalla borgata proseguiamo nuovamente lungo il sentiero circondati da larici, faggi, betulle e dopo alcune deviazione, sempre ben segnalate, usciamo in una splendida radura.

Saliamo gli ultimi 200m a lato della pista o volendo possiamo proseguire più a destra incrociando la strada carrozzabile che nel periodo estivo porta al rifugio.',
        '["/static/images/45.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia","lon":7.180788516998291,"lat":44.57619898952544}'::jsonb,
        '{"name":"End Point","address":"Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia","lon":7.155619841068983,"lat":44.55683704465628}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per ROCCA PATANUA',
        2,
        '/static/gpx/Rocca Patanua da Prarotto (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Condove',
        4388.161778983409,
        923.6238601720527,
        200,
        'Itinerario interamente rivolto a Sud che normalmente si libera dalla neve già a inizio primavera.

(l’itinerario è stato svolto in periodo invernale, seguito scarsa e quasi totalmente assente copertura nevosa).',
        '["/static/images/28.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Alpe Tulivit, Condove, Torino, Piemonte, Italia","lon":7.237061262130737,"lat":45.14908790588379}'::jsonb,
        '{"name":"End Point","address":"Alpe Tulivit, Condove, Torino, Piemonte, Italia","lon":7.219639476388693,"lat":45.17825868912041}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Cima Durand-Colle Bauzano-Artesina',
        3,
        '/static/gpx/Senriero per Anello cima Durand, Colle Bauzano, Artesina (1) (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Artesina',
        8085.211186643268,
        829.1299999999999,
        150,
        'Lasciata la macchina nello spazioso parcheggio di Artesina o nei posteggi vicino al bar Tana del Lupo, saliamo sulle piste dove possiamo subito infilare le ciaspole.

Procediamo per circa 400m sull’ampio sentiero in direzione Ovest (a destra) e dopo alcuni tornanti troviamo un bivio (a sinistra vi è la stradina che percorreremo al ritorno) dove proseguiamo sulla destra (sentiero F02) dirigendoci verso la Celletta, punto panoramico sulla valle Ellero.

Percorriamo il sentiero per Serra della Turra che ci porta prima a passare sotto la seggiovia e poi ad un pianoro dove troviamo la Baita della Turra, tappa ideale per un eventuale break o colazione.',
        '["/static/images/48.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia","lon":7.755467472597957,"lat":44.24691265448928}'::jsonb,
        '{"name":"End Point","address":"Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia","lon":7.754717627540231,"lat":44.246627166867256}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Quintino Sella e Viso Mozzo',
        1,
        '/static/gpx/Sentiero per Rifugio Quintino Sella e Viso Mozzo.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        9039.751801123071,
        1090.660000000001,
        120,
        'The path does not present any difficulty, in case of rain, however, the climb is not recommended as the route is entirely on stony ground.

From up there you have a privileged view of a large part of the Monviso chain and the close distance to the Re di pietra is unique.',
        '["/static/images/31.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia","lon":7.094606207683682,"lat":44.70125044696033}'::jsonb,
        '{"name":"End Point","address":"Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia","lon":7.109863618388772,"lat":44.66575786471367}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Ss659 a Ss6591',
        3,
        '/static/gpx/Sentiero per Rupe del Gesso - CIASPOLE.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Formazzo',
        16969.02550810036,
        984.23046875,
        120,
        'Take the A26 motorway towards Gravellona Toce and follow it to the end. From there stay on the SS33 del Sempione passing Domodossola. At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls. There are unpaved parking lots just before the Centro Fondo Riale.',
        '["/static/images/38.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia","lon":8.41653149574995,"lat":46.41965291462839}'::jsonb,
        '{"name":"End Point","address":"Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia","lon":8.41653149574995,"lat":46.41965291462839}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Albogno-Pieve Margineta Mater',
        2,
        '/static/gpx/albogno-pieve-margineta-mater-27-8-21.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Albogno',
        11301.8785751773,
        1381.6880000000006,
        140,
        'Escursione senza molte difficoltà ideale per il periodo primaverile e autunnale. 
Dopo circa 2 ore di bosco si esce su delle creste molto panoramiche e semplici, il ritorno purtroppo viene fatto su un sentiero poco segnato sulla parte iniziale e ma man mano che si scende compiano sia segni e gli ometti.',
        '["/static/images/11.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia","lon":8.421405,"lat":46.139077}'::jsonb,
        '{"name":"End Point","address":"Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia","lon":8.421395,"lat":46.139111}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Alte Langhe Settentrionali - Cossano Belbo',
        2,
        '/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cossano Belbo',
        5400,
        913.6,
        200,
        'Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.
Si svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.
Si imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.
Inizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.
Percorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. 
Seguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. 
Si procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante',
        '["/static/images/4.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199049,"lat":44.670379}'::jsonb,
        '{"name":"End Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199052,"lat":44.670377}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":8.214142,"lat":44.674545,"altitude":482.526},{"name":"Ref Point 2","address":"","lon":8.197792,"lat":44.668772,"altitude":242.585}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello per il Monte Freidour (PERLEVIEDELMONDO)',
        2,
        '/static/gpx/anello monte freidour (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'San Pietro Val Lemina',
        8503.263605697935,
        558.511400000002,
        150,
        'At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls.',
        '["/static/images/39.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia","lon":7.284098,"lat":44.96472}'::jsonb,
        '{"name":"End Point","address":"Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia","lon":7.284125,"lat":44.964785}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Anello Pieve di Ledro-Biacesa di Ledro-Rifugio Nino Pernici',
        2,
        '/static/gpx/anello-pieve-di-ledro-biacesa-di-ledro-rifugio-nino-pernici.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        42458.63040670248,
        23175.26399999994,
        320,
        'Anello sui monti a nord-est del Lago di Ledro, percorso in 3 giorni andando con molta calma, percorribile anche in 2. 
Alcuni tratti della prima metà del percorso sono attrezzati con scale e corde.',
        '["/static/images/14.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.73147,"lat":45.882851}'::jsonb,
        '{"name":"End Point","address":"Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731364,"lat":45.882702}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Anello sui colli imolesi: Dozza - Pieve S. Andrea',
        2,
        '/static/gpx/anello-sui-colli-imolesi-dozza-pieve-s-andrea-valsellustra-s.gpx',
        'Italia',
        'Emilia-Romagna',
        'Bologna',
        'Dozza',
        19320.58160760896,
        666.374,
        210,
        'Crossing the provincial road you can see the first of the various signs of the Camino di San Antonio that we will find along the way. We cross and begin a slow but constant climb alongside the fields, which will lead us to a beautiful panoramic view of the surrounding valleys. Paying attention to the crossroads, we continue until we cross the paved road again. In reality there is very little traffic... with a decent view of the Vena del Gesso Romagnola we arrive at the delightful village of Pieve Sant''Andrea (worth a quick detour), to then resume our journey. Be careful not to follow the path of Sant''Antonio, we descend rapidly (shortly after we find the Sorgente delle Accarisie on our left, already existing in Roman times) until we reach the small hamlet of Valsellustra. Here too we cross the road and follow the paved via delle Ville uphill to arrive at a first panoramic point over the surrounding gullies.',
        '["/static/images/21.jpg"]'::jsonb,
        '{"name":"Start Point","address":"5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia","lon":11.632106,"lat":44.359936}'::jsonb,
        '{"name":"End Point","address":"5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia","lon":11.63228,"lat":44.359936}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Campione Pieve Campione',
        2,
        '/static/gpx/campione-pieve-campione.gpx',
        'Italia',
        'Lombardia',
        'Brescia',
        'Campione del Garda',
        10764.501653316338,
        1852.4639999999995,
        300,
        'Campione Pieve Campione',
        '["/static/images/17.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia","lon":10.749084,"lat":45.752875}'::jsonb,
        '{"name":"End Point","address":"Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia","lon":10.749743,"lat":45.757881}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Casalfiumanese (BO) - Pieve di Sant''Andrea',
        2,
        '/static/gpx/casalfiumanese-bo-pieve-di-santandrea.gpx',
        'Italia',
        'Emilia-Romagna',
        'Bologna',
        'Casal Fiumese',
        15650.261397546863,
        838.3309999999993,
        210,
        'Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don''t die from the heat and the clouds filter the sun''s rays and allow you to better enjoy the landscapes',
        '["/static/images/24.jpg"]'::jsonb,
        '{"name":"Start Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616255,"lat":44.29726}'::jsonb,
        '{"name":"End Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616326,"lat":44.297235}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Casalfiumanese (BO) - Pieve di Sant''Andrea',
        2,
        '/static/gpx/casalfiumanese-bo-pieve.gpx',
        'Italia',
        'Emilia-romagna',
        'Bologna',
        'CasalFiumese',
        15650.261397546863,
        838.3309999999993,
        210,
        'Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don''t die from the heat and the clouds filter the sun''s rays and allow you to better enjoy the landscapes',
        '["/static/images/25.jpg"]'::jsonb,
        '{"name":"Start Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616255,"lat":44.29726}'::jsonb,
        '{"name":"End Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616326,"lat":44.297235}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Cavriana pieve- Volta mantovana chiesetta Madonna dei Marchi',
        1,
        '/static/gpx/cavriana-pieve-volta-mantovana-chiesetta-madonna-dei-marchi.gpx',
        'Italia',
        'Lombardia',
        'Mantova',
        'Cavriana',
        17987.27359307591,
        651.414999999999,
        150,
        'Bellissima passeggiata con displivello',
        '["/static/images/13.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia","lon":10.613546,"lat":45.347279}'::jsonb,
        '{"name":"End Point","address":"Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia","lon":10.614472,"lat":45.347241}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":10.625996,"lat":45.345584,"altitude":130.117},{"name":"Ref Point 2","address":"","lon":10.633173,"lat":45.34138,"altitude":139.742},{"name":"Fontain","address":"","lon":10.647482,"lat":45.332552,"altitude":107.319}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per CIMA CIANTIPLAGNA',
        2,
        '/static/gpx/ciantiplagna.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Meana di Susa',
        5474.279781243261,
        791.5095210000009,
        140,
        'The route is safe and within everyone''s reach, even though you reach a relatively high altitude... for this reason it is good to take into account sudden changes in the weather (wind, rain, thick fog).

Due to the total absence of shading, I recommend sunscreen cream and adequate water supply.

In late spring it is still possible to find accumulations of snow which can make the ascent difficult, especially in the final stretch towards the summit.

For cheese lovers, I highly recommend a stop at the Pian dell''Alpe bergeria...',
        '["/static/images/41.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Cima Ciantiplagna, Strada militare del Colle dell''Assietta, Bergerie dell''Assietta, Usseaux, Torino, Piemonte, Italia","lon":7.053414,"lat":45.071918}'::jsonb,
        '{"name":"End Point","address":"Cima Ciantiplagna, Strada militare del Colle dell''Assietta, Bergerie dell''Assietta, Usseaux, Torino, Piemonte, Italia","lon":7.012962,"lat":45.072133}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Voltino a Pieve di Tremosine e ritorno',
        2,
        '/static/gpx/da-voltino-a-pieve-di-tremosine-e-ritorno.gpx',
        'Italia',
        'Lombardia',
        'Brescia',
        'Tremosine sul Garda',
        6588.816640728274,
        936.79,
        120,
        'Fa quasi paura ad avvicinarsi alla ringhiera. 
Vicino alla postazione panoramica presso il bar ristorante che ho fotografato, c''è l''inizio del sentiero per la discesa al Porto di Tremosine.C''è scritto che è consigliato per escursionisti esperti.',
        '["/static/images/15.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia","lon":10.764297,"lat":45.782504}'::jsonb,
        '{"name":"End Point","address":"Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia","lon":10.763028,"lat":45.782797}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Dalla chiesa romanica di San Pietro di Fenestrella alla abba...',
        2,
        '/static/gpx/dalla-chiesa-romanica-di-san-pietro-di-fenestrella-alla-abba.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Albugnano',
        13691.922955982358,
        584.9190000000001,
        150,
        'Chiesa di San Pietro de Fenestrella: 
La chiesa è situata nel cimitero di Albugnano. 
Essa ha affinità compositive con la Canonica di santa Maria di Vezzolano e deriverebbe il suo nome ,secondo alcuni,dalla insolita presenza di tre finestre nell’abside,secondo altri, sarebbe stata così denominata perchè situata nello stretto colle (una gola) compreso tra il rilievo collinare di Albugnano e il rilievo ove sorge il cimitero: 
Una specie di finestra aperta sulla valle sottostante.',
        '["/static/images/27.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia","lon":7.97125,"lat":45.077934}'::jsonb,
        '{"name":"End Point","address":"Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia","lon":7.971227,"lat":45.077991}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Gulo - Pieve Vergonte',
        1,
        '/static/gpx/gulo-pieve-vergonte.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Santa Maria',
        14496.863954985321,
        832.3479999999993,
        90,
        'Gulo - Pieve Vergonte',
        '["/static/images/9.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia","lon":8.248234,"lat":45.997598}'::jsonb,
        '{"name":"End Point","address":"Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia","lon":8.264287,"lat":46.004814}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Il giro del Montorfano: la chiesa romanica, il borgo e la ve...',
        2,
        '/static/gpx/il-giro-del-montorfano-la-chiesa-romanica-il-borgo-e-la-vett.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Bracchio',
        9623.856463002363,
        697.1199999999999,
        210,
        'Il giro del Montorfano: la chiesa romanica, il borgo e la vetta',
        '["/static/images/10.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia","lon":8.448922,"lat":45.960306}'::jsonb,
        '{"name":"End Point","address":"Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia","lon":8.448922,"lat":45.960306}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'La chiesa romanica di S. Vittore(anello Montemagno--Viarigi)',
        3,
        '/static/gpx/la-chiesa-romanica-di-s-vittoreanello-montemagno-viarigi.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montemagno',
        12572.716765417841,
        341.5519999999999,
        210,
        'Il percorso si svolge prevalentemente su sterrata. 
Esso non ha segnaletica ad eccezione dell’ultimo tratto (due km. circa) da località Madonna del Gombo fino a Montemagno. 
In questo tratto si incontra la segnaletica del sentiero n.507 della Regione Piemonte.',
        '["/static/images/6.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia","lon":8.323294,"lat":44.983183}'::jsonb,
        '{"name":"End Point","address":"Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia","lon":8.323553,"lat":44.983388}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'La pieve romanica di Piesenzana e la valle delle tartufaie',
        2,
        '/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montechiaro d''Asti',
        6500,
        78,
        225,
        'Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. 
Circa 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. 
In regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. 
A Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). 
Contemporaneamente i ristoranti della zona propongono piatti a base di tartufi',
        '["/static/images/5.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.113224,"lat":45.007605}'::jsonb,
        '{"name":"End Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.11358,"lat":45.007557}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Le Paludi di Ostiglia Oasi del Busatello Sermide e Pieve',
        3,
        '/static/gpx/le-paludi-di-ostiglia-oasi-del-busatello-sermide-e-pieve-di-.gpx',
        'Italia',
        'Lombardia',
        'Mantova',
        'Pieve di Coriano',
        12572.716765417841,
        341.5519999999999,
        255,
        'La tradizione afferma che la chiesa fu costruita nel 1082, per volere di Matilde di Canossa. Questa attribuzione risale al 1612 nella Historia ecclesiastica di Mantova dove il Donesmondi attribuisce l''edificazione della chiesa a Matilde, assieme ad altre chiese del territorio. 
Il Donesmondi affermò questa data riprendendo l''iscrizione da una lapide presente sulla facciata della pieve, visibile ancora oggi, dove sta scritto "D.O.M. ET B. MARIAE V. IN COELUM ASSUMPTAE ERECTA A.D. 1082 A CONNTISSA MATHILDE". Secondo un''analisi storica questa lapide non può essere ritenuta originale dell''XI secolo, ma risale al cinquecento. L''ipotesi è che questa iscrizione si stata realizzata durante il restauro del 1538. 
Storicamente, quindi, non ci sono documenti che attestano una data certa di costruzione della chiesa, ma sulla base degli elementi architettonici si può affermare che la pieve venne eretta nell''XI secolo. 
La chiesa è in stile romanico, costruita in laterizio ed è composta da tre navat',
        '["/static/images/7.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia","lon":11.106454,"lat":45.035438}'::jsonb,
        '{"name":"End Point","address":"Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia","lon":11.106576,"lat":45.03596}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":11.109236,"lat":45.044962,"altitude":22.75},{"name":"Ref Point 2","address":"","lon":11.155368,"lat":45.034617,"altitude":35.551}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per il MONTE CUCETTO',
        2,
        '/static/gpx/monte cucetto.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Dubbione',
        2150.3010767004043,
        586.4262699999999,
        120,
        'Escursione Facile e, nella parte alta, molto panoramica; la cima offre una buona panoramica dei rilievi tra bassa Val Chisone e Val Sangone.

Lasciata l’auto, il sentiero parte in corrispondenza del tornante ed entra nel bosco in direzione Nord-Ovest; al primo bivio, proseguire dritto e seguire le indicazioni per “Cucetto”; il sentiero inizia a guadagnare quota abbastanza rapidamente e costantemente, sempre nel bosco.

Dopo una serie di tornantini la vegetazione inizierà a diradarsi e si inizierà a scorgere un bel panorama con il Monviso in bella mostra (se il meteo lo permette).',
        '["/static/images/50.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Pralamar, Pinasca, Torino, Piemonte, 10063, Italia","lon":7.243299,"lat":44.961979}'::jsonb,
        '{"name":"End Point","address":"Pralamar, Pinasca, Torino, Piemonte, 10063, Italia","lon":7.240229,"lat":44.977112}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per il MONTE MURETTO',
        2,
        '/static/gpx/monte muretto.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Torino',
        2127.346730436805,
        277.51812700000005,
        200,
        'È presente un unico punto acqua nel luogo del parcheggio (fontana). Nella stessa piazzetta, al momento della recensione, è sempre aperto nei weekend un singolare bar allestito dentro un vecchio furgone.

Per chi cammina con bimbi e soprattutto cani, attenzione in primavera alla presenza di processionarie.',
        '["/static/images/44.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia","lon":7.31544,"lat":44.918242}'::jsonb,
        '{"name":"End Point","address":"Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia","lon":7.309893,"lat":44.929433}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pieve di Ledro - Monte Cocca',
        1,
        '/static/gpx/pieve-di-ledro-monte-cocca.gpx',
        'Italia',
        'Trentino Alto Adige',
        'Provincia di Trento',
        'Pieve di Ledro',
        8627.552532528542,
        1018.0050000000002,
        70,
        'Very challenging, but worth it! The view from the top is gorgeous! For the descent it is better to use sticks, or repeat the same route as the climb.',
        '["/static/images/20.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.730931,"lat":45.889379}'::jsonb,
        '{"name":"End Point","address":"Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731044,"lat":45.889397}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pieve S. Stefano a Pian delle Capanne',
        2,
        '/static/gpx/pieve-s-stefano-a-pian-delle-capanne.gpx',
        'Italia',
        'Toscana',
        'Arezzo',
        'Pieve Santo Stefano',
        22430.396794868582,
        1004.4300000000019,
        150,
        'Causa pioggia e terreno scivoloso preso la 1º variante fino al passo Viamaggio poi proseguito ancora per la 2º variante. 
Bisogna calcolare circa 4 km in più.',
        '["/static/images/23.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Poggiolino delle Viole, Castellare, Pieve Santo Stefano, Arezzo, Toscana, 52036, Italia","lon":12.039528,"lat":43.670638}'::jsonb,
        '{"name":"End Point","address":"Bike Help, Pian della Capanna, Pieve Santo Stefano, Arezzo, Toscana, Italia","lon":12.150503,"lat":43.651402}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Piverone - Anello IV - “Via Romanica al Gesiun”',
        1,
        '/static/gpx/piverone-anello-iv-via-romanica-al-gesiun.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Pieverone',
        4857.311515489554,
        94.22999999999996,
        60,
        'Piverone - Anello IV - “Via Romanica al Gesiun”',
        '["/static/images/8.jpg"]'::jsonb,
        '{"name":"Start Point","address":"26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia","lon":8.00725,"lat":45.44783}'::jsonb,
        '{"name":"End Point","address":"26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia","lon":8.00696,"lat":45.44779}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Plois - Pieve d''Alpago',
        2,
        '/static/gpx/plois-pieve-dalpago.gpx',
        'Italia',
        'Veneto',
        'Belluno',
        'Pieve d''Alpegno',
        6588.816640728274,
        936.79,
        320,
        'percorso è tranquillamente percorribile',
        '["/static/images/19.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Municipio, Via Roma, Torres, Tignes, Pieve d''Alpago, Alpago, Belluno, Veneto, 32010, Italia","lon":12.360272,"lat":46.175025}'::jsonb,
        '{"name":"End Point","address":"Municipio, Via Roma, Torres, Tignes, Pieve d''Alpago, Alpago, Belluno, Veneto, 32010, Italia","lon":12.352636,"lat":46.167926}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Galassi, forcella del ghiacciaio, Rifugio Antelao',
        2,
        '/static/gpx/rifugio-galassi-forcella-del-ghiacciaio-rifugio-antelao-piev.gpx',
        'Italia',
        'Veneto',
        'Belluno',
        'Belluno',
        6588.816640728274,
        936.79,
        200,
        'Quinta giornata Alta via N°4
Rifugio Galassi, forcella del ghiacciaio, Rifugio Antelao, Pieve di Cadore.',
        '["/static/images/18.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia","lon":12.261855,"lat":46.470487}'::jsonb,
        '{"name":"End Point","address":"Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia","lon":12.364278,"lat":46.426071}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Riva del Garda - Pieve di Ledro - Panchina',
        3,
        '/static/gpx/riva-del-garda-pieve-di-ledro-panchina.gpx',
        'Italia',
        'Trentino Alto Adige',
        'Provincia di Trento',
        'Sant''Alessandro',
        8085.211186643268,
        829.1299999999999,
        135,
        'Riva del Garda - Pieve di Ledro - Panchina',
        '["/static/images/16.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.853195,"lat":45.882925}'::jsonb,
        '{"name":"End Point","address":"Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731102,"lat":45.88923}'::jsonb,
        '[{"name":"Peak","address":"","lon":10.853195,"lat":45.882925,"altitude":67.085},{"name":"Lake","address":"","lon":10.764528,"lat":45.873764,"altitude":712.069}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sovicille delle Meraviglie - Villa Cetinale - Scala Santa',
        2,
        '/static/gpx/sovicille-delle-meraviglie-villa-cetinale-scala-santa-e-romi.gpx',
        'Italia',
        'Toscana',
        'Siena',
        'Sovicille',
        19553.110970430764,
        1298.215999999996,
        210,
        'Suggestivo anello con visita della pieve di Pernina e del parco di Villa Cetinale/Castello di Celsa aperti in occasione dell''evento Sovicille delle Meraviglie ottobre 2021',
        '["/static/images/26.jpg"]'::jsonb,
        '{"name":"Start Point","address":"4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia","lon":11.228176,"lat":43.279339}'::jsonb,
        '{"name":"End Point","address":"4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia","lon":11.228044,"lat":43.279294}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'BERGERIE DI VALLONCRO’',
        3,
        '/static/gpx/vallone di massello (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Massello',
        5304.03695311155,
        958.8864720000013,
        150,
        'Open and shade-free environment: remember sunscreen; if the walk is too long, the plateau at the base of the waterfall still offers various possibilities for pleasant picnics.',
        '["/static/images/30.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia","lon":7.031857,"lat":44.964905}'::jsonb,
        '{"name":"End Point","address":"Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia","lon":6.997145,"lat":44.978063}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Ville Disunite - Anello Ghibullo - Villa Pasolini.',
        2,
        '/static/gpx/ville-disunite-anello-ghibullo-villa-pasolini-torre-albicini.gpx',
        'Italia',
        'Emilia-Romagna',
        'Ravenna',
        'Lognana',
        22696.477033711653,
        236.7130000000004,
        110,
        'The first stretch is entirely on the right bank of the Ronco, on the Via Romea Germanica. Then you enter the territory to go towards the center of the journey, the area of ​​San Pietro in Trento where, within two kilometres, you come across a medieval tower, a 9th century parish church with a fantastic crypt, the ruins of a large villa and a perfectly healthy 16th century villa.',
        '["/static/images/23.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia","lon":12.138685,"lat":44.343306}'::jsonb,
        '{"name":"End Point","address":"Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia","lon":12.139573,"lat":44.343643}'::jsonb,
        NULL
      );
    
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2),
        working_time_start time without time zone,
        working_time_end time without time zone,
        email varchar,
        phone_number varchar,
        pictures jsonb,
        description varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber",
      "pictures",
      "description"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number,
      pictures,
      description
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        1,
        120::numeric(12,2),
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Sig. Giuseppina Campisi',
        'http://understated-truth.org',
        277.714,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Iona_Palmisano@hotmail.com',
        '+394288553615',
        '["/static/images/94072c68-40d4-4987-9b04-538fd16420d2.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg"]'::jsonb,
        'Quam corrupti recusandae cumque error beatae ducimus consectetur.
Deserunt beatae unde voluptas tempore.
Quibusdam ab atque totam eum.
Nesciunt fuga impedit numquam quod accusantium.
Repellat molestiae ipsum doloremque neque inventore doloremque accusantium animi deserunt.'
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        7,
        57::numeric(12,2),
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Guenda Forlani',
        'https://firsthand-hill.com',
        323.169,
        '05:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Mimma.Demurtas14@email.it',
        '+397370757749',
        '["/static/images/0d76968e-1a08-415d-aaa7-0b7edaa1aef0.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]'::jsonb,
        'Similique ipsum autem libero pariatur quisquam eum numquam sapiente.
Facilis ad officia quidem eum perspiciatis mollitia possimus.
Voluptas quidem modi.
Accusamus inventore accusantium laborum facere assumenda sed adipisci.'
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        10,
        114::numeric(12,2),
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Umile Luise',
        'https://damaged-trowel.com',
        320.774,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Natalina15@yahoo.it',
        '+391213199796',
        '["/static/images/94072c68-40d4-4987-9b04-538fd16420d2.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg"]'::jsonb,
        'Magni consequatur ex.
Sint sint exercitationem aliquid voluptate voluptates.
Repellat dolorum esse dolor provident.
Ullam a magnam provident laboriosam fugit.'
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        5,
        110::numeric(12,2),
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Efrem Mazzoleno',
        'https://greedy-lady.it',
        328.128,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Ermes63@yahoo.it',
        '+393219150027',
        '["/static/images/cc09fac1-266b-4032-9864-7e652f27929c.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg"]'::jsonb,
        'Magni inventore voluptatum rem vitae vitae labore enim consequuntur delectus.
Magnam amet labore tempora suscipit ea.
Suscipit quia ex.
Aut deserunt corrupti ut nam animi.
Sit exercitationem ipsum alias occaecati voluptatem.'
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        9,
        104::numeric(12,2),
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Gervasio Dell''Amico',
        'http://appropriate-surfboard.com',
        276.522,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Mirocleto_Liuzzi@email.it',
        '+395436001957',
        '["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg"]'::jsonb,
        'Autem asperiores distinctio perspiciatis ut et sapiente voluptas explicabo aspernatur.
Error nobis itaque.
Tenetur repellat dolorum reiciendis velit laboriosam quasi tempore a.
Enim suscipit quo consequuntur doloribus fuga commodi ab.'
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        3,
        49::numeric(12,2),
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Arabella Nicolosi',
        'http://abandoned-fascia.org',
        303.227,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Amerigo_Recchia@yahoo.it',
        '+392461790988',
        '["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]'::jsonb,
        'Nulla culpa officia reprehenderit eveniet.
Ea eius accusantium.'
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        4,
        147::numeric(12,2),
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Capitolina Carlucci',
        'http://torn-gloom.com',
        299.153,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Walter_Quaranta@yahoo.com',
        '+394035010454',
        '["/static/images/8765fd5b-1e43-4aa4-b7d3-1e21c02555d6.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg"]'::jsonb,
        'Explicabo fugiat debitis.
Sapiente voluptate vero dolor at consectetur recusandae.'
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        6,
        117::numeric(12,2),
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Veriana Rinaldi',
        'https://fantastic-gemsbok.net',
        314.475,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Amanzio_Morini@yahoo.com',
        '+397601805945',
        '["/static/images/b6a44f8c-a9ac-4f1b-84cb-41910e38cc6e.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg"]'::jsonb,
        'Molestiae sint vitae dolorum officiis omnis reiciendis et ullam.
At consectetur suscipit error sapiente explicabo quod sint debitis.
Quis laborum fugiat.
Non cumque illo.
Exercitationem nulla nemo officiis sint veniam non dicta.'
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        8,
        75::numeric(12,2),
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Sigfrido Paci',
        'http://actual-crib.com',
        315.193,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Valerico1@hotmail.com',
        '+392534092387',
        '["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg"]'::jsonb,
        'Aperiam reprehenderit eos explicabo at inventore.
Quisquam sit molestias earum minima repellendus minima quas non.
Ducimus aspernatur et adipisci officia alias sapiente iste illo autem.
Itaque nulla possimus ducimus nam facilis porro illo dolorum sapiente.
Quo iste commodi.'
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        10,
        61::numeric(12,2),
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Aldo Serpa',
        'http://criminal-airplane.org',
        280.241,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Otello_Caggiano66@yahoo.it',
        '+395850396582',
        '["/static/images/1c178114-d7fd-414a-9eef-1a1cac332f83.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg"]'::jsonb,
        'Delectus similique incidunt ex necessitatibus consequatur recusandae iusto autem.
Corrupti officia fugit vel blanditiis enim dolore itaque iusto sequi.
At provident alias inventore officiis commodi asperiores.
Aperiam molestiae distinctio.
At ratione nobis.'
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        9,
        66::numeric(12,2),
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Gilberto Vitiello',
        'http://visible-merchandise.org',
        290.825,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Carmen_DiGaetano2@yahoo.it',
        '+398446716366',
        '["/static/images/36742880-4fbc-4208-a6b6-3ec7290c112d.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]'::jsonb,
        'Suscipit nihil non nulla.
Dolore reiciendis optio.
Eum voluptatibus odio odit veniam.'
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        4,
        43::numeric(12,2),
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Bartolomeo Massari',
        'https://expensive-intentionality.org',
        285.444,
        '07:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Veronica_Ferranti78@gmail.com',
        '+394733297563',
        '["/static/images/9156aa5a-9192-446f-9f5e-7fe51ffbf7c6.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg"]'::jsonb,
        'Officiis deserunt tempore recusandae minus ipsa provident exercitationem.
Temporibus quia excepturi quo dignissimos odit iure natus.
Dignissimos cumque dignissimos eaque quisquam tempore harum veritatis et corporis.'
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        3,
        55::numeric(12,2),
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Ildebrando Novelli',
        'https://worst-genre.org',
        318.401,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Zelinda59@gmail.com',
        '+395679757529',
        '["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]'::jsonb,
        'Laudantium non mollitia dolor exercitationem.
Asperiores soluta debitis modi repudiandae accusantium minus dolores.'
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        7,
        145::numeric(12,2),
        'Vernagthütte',
        'Austria',
        'Aronne Benvenuti',
        'http://black-and-white-cornet.org',
        274.501,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Umile17@yahoo.it',
        '+390039091970',
        '["/static/images/b6a44f8c-a9ac-4f1b-84cb-41910e38cc6e.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg"]'::jsonb,
        'Nisi quidem aspernatur provident reiciendis temporibus alias.
Iusto fugit voluptatibus.
Quis odio aperiam est expedita nisi nisi quos.'
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        5,
        63::numeric(12,2),
        'Wormser Hütte',
        'Austria',
        'Nadia Sanna',
        'https://portly-digit.net',
        324.472,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Casimiro83@yahoo.it',
        '+393889384785',
        '["/static/images/380dce13-b063-4641-bbf2-173987d94f64.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg"]'::jsonb,
        'Quas quibusdam voluptas aliquam praesentium minima necessitatibus iusto unde modi.
Quis ea officiis cumque reiciendis corporis ut expedita.
Non maxime explicabo minima repellat eum molestias.
Cumque officia aliquid enim distinctio inventore.'
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        4,
        51::numeric(12,2),
        'Biberacher Hütte',
        'Austria',
        'Galatea Mazzini',
        'http://passionate-mainland.net',
        324.706,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Elia.Florio@yahoo.it',
        '+394520211766',
        '["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg"]'::jsonb,
        'Recusandae odit laboriosam veritatis natus distinctio.
Repudiandae eaque explicabo maiores.
Quasi ab labore.
Eum error repellat esse molestiae ad consectetur unde illo.'
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        2,
        80::numeric(12,2),
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Unna Soro',
        'http://warmhearted-input.net',
        336.663,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Tea93@yahoo.it',
        '+391282905021',
        '["/static/images/71595344-e22a-4095-9bca-112353382c7c.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg"]'::jsonb,
        'Atque nam sunt dolorum odio nisi.
Tenetur laborum cum aperiam explicabo pariatur at sequi.
Aut corporis impedit dolore voluptatem nemo iure animi maxime.'
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        3,
        96::numeric(12,2),
        'Hochwaldhütte',
        'Germany',
        'Amauri Mercuri',
        'https://defenseless-spark.net',
        306.091,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Ermenegilda13@gmail.com',
        '+391933476222',
        '["/static/images/0d76968e-1a08-415d-aaa7-0b7edaa1aef0.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg"]'::jsonb,
        'Impedit architecto harum itaque optio cupiditate ipsa.
Recusandae provident mollitia aperiam quod ut.
Quia ex magnam blanditiis.'
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        5,
        39::numeric(12,2),
        'Kölner Eifelhütte',
        'Germany',
        'Sandra Vichi',
        'http://key-accomplishment.com',
        271.035,
        '07:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Clemente.Perugini@gmail.com',
        '+393676323547',
        '["/static/images/fbcdf907-68c2-4ed1-999a-81601551aa5d.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg"]'::jsonb,
        'Enim sint in harum alias recusandae nulla illo praesentium.
Suscipit ex blanditiis ipsam laborum reprehenderit laudantium.
Quo explicabo rerum rerum consequuntur vero debitis officia minus ducimus.
Laborum cupiditate laudantium delectus officiis iste impedit ex.'
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        8,
        45::numeric(12,2),
        'Madrisahütte',
        'Austria',
        'Graziella Cocco',
        'https://right-equity.it',
        281.191,
        '08:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Gordiano.Cavalieri@hotmail.com',
        '+391224323172',
        '["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg"]'::jsonb,
        'Quasi inventore autem fugit iure itaque dolorum fugiat quo sequi.
Perspiciatis quidem ea quaerat commodi laboriosam consectetur itaque.
Non soluta quam qui esse earum.
Veritatis laborum laboriosam.'
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        3,
        46::numeric(12,2),
        'Dresdner Hütte',
        'Austria',
        'Babila Bevilacqua',
        'https://front-tunnel.net',
        267.332,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Agesilao_Ranucci@email.it',
        '+399003743167',
        '["/static/images/b6a44f8c-a9ac-4f1b-84cb-41910e38cc6e.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg"]'::jsonb,
        'A cumque ducimus aliquid saepe blanditiis explicabo eum quaerat.
Beatae consectetur sit ipsa nam accusamus.
Sequi aperiam dolorum occaecati molestiae corporis omnis.'
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        3,
        97::numeric(12,2),
        'Fiderepasshütte',
        'Germany',
        'Aureliano Micco',
        'http://junior-wrecker.com',
        313.564,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Apollo.Saccone@hotmail.com',
        '+397854963922',
        '["/static/images/3f6d2aea-9d16-4208-84e9-d54ed4d72045.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]'::jsonb,
        'Sequi ad quae consequatur sequi voluptatum quos aperiam quaerat.
Odio consequatur ut similique.
A quibusdam esse.
Eum asperiores rerum corporis facilis.
Distinctio et quam reprehenderit esse fugit.'
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        2,
        82::numeric(12,2),
        'Göppinger Hütte',
        'Austria',
        'Giuliano Di Lascio',
        'https://unsung-favor.net',
        267.565,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Birino_Santarsiero@email.it',
        '+399219795847',
        '["/static/images/cc09fac1-266b-4032-9864-7e652f27929c.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg"]'::jsonb,
        'Id ea mollitia occaecati corporis commodi.
Laboriosam nulla quo delectus.'
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        2,
        69::numeric(12,2),
        'Oberzalimhütte',
        'Austria',
        'Sibilla Malavasi',
        'http://jaded-defeat.org',
        273.611,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Letizia_Ciulla@libero.it',
        '+396708820610',
        '["/static/images/fbcdf907-68c2-4ed1-999a-81601551aa5d.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg"]'::jsonb,
        'Ipsum consequatur magni dignissimos magnam assumenda labore facere.
Inventore quae natus fuga libero praesentium.'
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        3,
        136::numeric(12,2),
        'Rastkogelhütte',
        'Austria',
        'Cuzia Orlandi',
        'https://aromatic-doctorate.net',
        313.939,
        '04:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Clorinda_Scopece28@email.it',
        '+399184708049',
        '["/static/images/380dce13-b063-4641-bbf2-173987d94f64.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg"]'::jsonb,
        'Voluptas eveniet distinctio.
Illum quam animi excepturi doloremque dolorem.
Nulla quod sequi.
Quod officia voluptate harum nobis rerum.'
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        5,
        102::numeric(12,2),
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Sonia Blanc',
        'https://yellowish-jelly.org',
        279.07,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Narseo75@yahoo.com',
        '+397367188396',
        '["/static/images/36742880-4fbc-4208-a6b6-3ec7290c112d.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg"]'::jsonb,
        'Itaque quisquam excepturi quaerat iste soluta atque velit.
Fuga atque consequatur minus similique sed placeat laudantium praesentium.
Iste mollitia corrupti tenetur fuga rerum.
Mollitia placeat sint neque commodi suscipit.'
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        1,
        106::numeric(12,2),
        'Kaltenberghütte',
        'Austria',
        'Ambrosiano De Fazio',
        'https://thin-paramedic.it',
        270.761,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Giona23@gmail.com',
        '+399792520789',
        '["/static/images/b6a44f8c-a9ac-4f1b-84cb-41910e38cc6e.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg"]'::jsonb,
        'Magni dolores nemo accusamus ipsa aperiam aliquid cumque.
Iusto reiciendis sunt sint doloremque laborum accusamus.
Porro suscipit facere sequi.
Nulla eveniet nemo modi maiores iure.'
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        10,
        146::numeric(12,2),
        'Schweinfurter Hütte',
        'Austria',
        'Albano Puca',
        'http://bountiful-valley.com',
        331.926,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Galeazzo_Talarico@yahoo.com',
        '+398508383856',
        '["/static/images/b6a44f8c-a9ac-4f1b-84cb-41910e38cc6e.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg"]'::jsonb,
        'Dicta quaerat rem recusandae neque consequuntur cumque ipsum quaerat.
Corrupti maiores incidunt quod.
Amet voluptatem vero veniam.
Inventore nemo sint facilis necessitatibus adipisci deleniti alias.
Saepe velit porro incidunt tempora excepturi.'
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        5,
        125::numeric(12,2),
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Dulina Mancini',
        'https://inexperienced-faith.org',
        306.909,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Antonio_Latorre@email.it',
        '+397114293377',
        '["/static/images/fbcdf907-68c2-4ed1-999a-81601551aa5d.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg"]'::jsonb,
        'Aliquam corrupti vel quisquam.
Necessitatibus corporis accusamus.
Nesciunt blanditiis sit illum unde magni expedita maxime.
Non corrupti rem quidem quia at ut.
Eos corporis mollitia magnam ducimus quos voluptates voluptatem fugit doloremque.'
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        9,
        149::numeric(12,2),
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Luana Piccinini',
        'https://artistic-robe.net',
        270.04,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Maria21@hotmail.com',
        '+398889443602',
        '["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg"]'::jsonb,
        'Ratione nobis dignissimos sunt iure dolorum vel libero nesciunt.
Expedita eos aliquid illo mollitia.
Iure at error.
Id explicabo quas pariatur omnis veritatis fugiat.
Quo fugit iste odit suscipit.'
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        3,
        124::numeric(12,2),
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Sabina Bergamasco',
        'https://yellow-pentagon.net',
        333.442,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Amore_Buonomo@yahoo.com',
        '+395170340788',
        '["/static/images/729d360a-2e24-4b59-869a-1086080537d7.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]'::jsonb,
        'Voluptates dolorum saepe reprehenderit laudantium hic eaque nemo voluptatem accusantium.
Tempora quod in minus vitae eligendi.
Quia excepturi quam.
Voluptatibus aut corporis quo in ut repellendus consequuntur.'
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        1,
        126::numeric(12,2),
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Ing. Felicia Paolicelli',
        'https://advanced-vibration.net',
        309.264,
        '03:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Luciana_Ferracuti@email.it',
        '+392990001669',
        '["/static/images/8765fd5b-1e43-4aa4-b7d3-1e21c02555d6.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg"]'::jsonb,
        'Quibusdam nihil cumque ex.
Est assumenda placeat pariatur nesciunt ex.
Ipsa veniam quia laboriosam.
Quam reiciendis culpa sit commodi.
Possimus voluptatibus culpa laudantium cumque cupiditate ratione alias.'
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        2,
        101::numeric(12,2),
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Medoro Cerri',
        'http://gracious-incidence.net',
        316.214,
        '01:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Ionne68@email.it',
        '+392328755300',
        '["/static/images/fbeba133-9be3-4029-a690-3c1f0d35db2c.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]'::jsonb,
        'Accusantium quaerat animi id distinctio repellat unde ipsam possimus maiores.
Quas animi ex doloribus placeat ipsa repellendus possimus accusamus.'
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        8,
        126::numeric(12,2),
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Dott. Verano La Porta',
        'http://stale-premeditation.org',
        323.798,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Betta.Melillo@hotmail.com',
        '+398929733939',
        '["/static/images/729d360a-2e24-4b59-869a-1086080537d7.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]'::jsonb,
        'Enim ducimus eius explicabo alias.
Excepturi voluptatum reiciendis voluptate dicta facere nihil natus eius.'
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        10,
        69::numeric(12,2),
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Elvino Vitale',
        'http://brilliant-infrastructure.net',
        277.929,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Tiberio39@yahoo.it',
        '+399109259816',
        '["/static/images/71595344-e22a-4095-9bca-112353382c7c.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg"]'::jsonb,
        'Reprehenderit adipisci enim repellat hic animi necessitatibus quas.
Placeat alias nesciunt.
Nobis eos vero sed aliquid ipsa a aliquam ex et.
Facilis cupiditate delectus nihil deleniti.
Illo quasi iure delectus corrupti modi perspiciatis ullam nisi iste.'
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        7,
        50::numeric(12,2),
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Soave Chiacchio',
        'https://grizzled-website.org',
        299.652,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Evelina.DiDomenico22@gmail.com',
        '+392357774403',
        '["/static/images/e6b68bd4-d913-4dcb-ab5a-364d13775e8d.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg"]'::jsonb,
        'Aspernatur aut unde ducimus.
Tempora dolorem perferendis.
Perferendis ducimus asperiores laboriosam quod.
Soluta quod aliquam harum quos enim velit modi.'
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        6,
        90::numeric(12,2),
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Dr. Placida Di Tullio',
        'https://aching-weight.net',
        267.96,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Gualtiero.Maresca4@libero.it',
        '+392814059202',
        '["/static/images/1c178114-d7fd-414a-9eef-1a1cac332f83.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg"]'::jsonb,
        'Velit eum porro a cupiditate.
Sed ex suscipit nam cum.'
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        6,
        43::numeric(12,2),
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Silvestro Latorre',
        'http://graceful-arena.org',
        304.99,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Cecilio76@yahoo.com',
        '+395549613019',
        '["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg"]'::jsonb,
        'Quaerat error cum eum quod fuga consequatur.
Quaerat explicabo alias accusamus aspernatur doloremque.
Facilis ullam recusandae vero iste numquam provident.'
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        9,
        93::numeric(12,2),
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Adelberto Liuzzi',
        'https://fluid-emerald.it',
        321.368,
        '09:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Martino_DiFelice@yahoo.com',
        '+392933905939',
        '["/static/images/36742880-4fbc-4208-a6b6-3ec7290c112d.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg"]'::jsonb,
        'Fugit sequi expedita atque cumque.
Repudiandae nostrum minus.'
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        4,
        91::numeric(12,2),
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Claudia Grasso',
        'http://wobbly-trader.net',
        278.811,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Palatino_Chirico@yahoo.com',
        '+391996148989',
        '["/static/images/b6a44f8c-a9ac-4f1b-84cb-41910e38cc6e.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg"]'::jsonb,
        'Quaerat ducimus sequi architecto et facilis.
Nulla omnis inventore atque.
Laborum enim excepturi recusandae neque ad.
Reprehenderit occaecati esse sequi delectus assumenda blanditiis ipsa ea.'
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        3,
        81::numeric(12,2),
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Acacio Prato',
        'https://bitter-trench.com',
        261.204,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Dina_LoPinto@gmail.com',
        '+396152830375',
        '["/static/images/3f6d2aea-9d16-4208-84e9-d54ed4d72045.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]'::jsonb,
        'Modi facere facilis cumque quo mollitia.
Sapiente inventore minima dolor optio sapiente quaerat excepturi nobis.
Ullam vitae ut unde minus amet ad.
Numquam sapiente corporis dicta vero eum accusamus vel.
Asperiores odio recusandae recusandae nihil nulla temporibus unde sequi error.'
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        7,
        65::numeric(12,2),
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Minerva Antonacci',
        'http://organic-river.org',
        337.041,
        '07:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Maria_Chiodi@yahoo.it',
        '+390932012816',
        '["/static/images/36742880-4fbc-4208-a6b6-3ec7290c112d.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg"]'::jsonb,
        'Aliquid quasi quasi nihil voluptates.
Nulla quae eveniet a ex.'
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        4,
        45::numeric(12,2),
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Ing. Ausilio Ramella',
        'https://zesty-hydroxyl.net',
        269.288,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Libero16@gmail.com',
        '+396442796913',
        '["/static/images/71595344-e22a-4095-9bca-112353382c7c.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg"]'::jsonb,
        'Quod corporis iure.
Delectus atque quo perspiciatis quia sed.
Architecto non at sequi necessitatibus odit doloremque.'
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        5,
        83::numeric(12,2),
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Sisto Orlando',
        'http://defensive-share.net',
        286.413,
        '03:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Gianpietro.Capizzi28@hotmail.com',
        '+393592493410',
        '["/static/images/0d76968e-1a08-415d-aaa7-0b7edaa1aef0.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg"]'::jsonb,
        'Porro perspiciatis odio dicta.
Tenetur mollitia dolorum eius id nihil occaecati illum repellat totam.
Illo molestiae velit labore.'
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        3,
        115::numeric(12,2),
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Nazario Gerace',
        'https://sturdy-lever.net',
        322.339,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Galatea.Tonelli84@libero.it',
        '+399251087879',
        '["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]'::jsonb,
        'Atque sunt architecto dolore odio.
Laboriosam ratione odit consectetur dolorem voluptatum nam sequi veritatis.
Nesciunt asperiores vitae rerum voluptates quod asperiores.
Ipsam nisi nobis quasi inventore.'
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        5,
        120::numeric(12,2),
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Dr. Valeriana Amato',
        'https://proud-ophthalmologist.net',
        266.426,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Bonifacio20@hotmail.com',
        '+396703639826',
        '["/static/images/729d360a-2e24-4b59-869a-1086080537d7.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg"]'::jsonb,
        'Harum officiis assumenda numquam.
Eos aut dolorum adipisci ut.'
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        7,
        42::numeric(12,2),
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Alfonso Cecchini',
        'http://idiotic-staircase.net',
        292.719,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Bastiano_Rallo@gmail.com',
        '+392994707206',
        '["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg"]'::jsonb,
        'Molestiae quas mollitia rem.
Iure atque officiis fugiat accusamus.
Itaque facere vero nobis aliquid dignissimos hic.
Necessitatibus sequi voluptas fuga maxime enim.'
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        8,
        91::numeric(12,2),
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Domenica Cannella',
        'http://animated-guideline.org',
        336.4,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Rainelda5@email.it',
        '+399877560972',
        '["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg"]'::jsonb,
        'Minima excepturi quia commodi ratione ipsa iste laborum vero commodi.
Similique quod consequatur.
Ullam quod pariatur.
Veritatis alias doloremque cupiditate non vitae.'
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        9,
        67::numeric(12,2),
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Enecone De Cristofaro',
        'https://international-rooster.net',
        325.818,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Igor.Caporaso33@libero.it',
        '+391841078655',
        '["/static/images/94072c68-40d4-4987-9b04-538fd16420d2.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]'::jsonb,
        'Ullam occaecati repellat et temporibus est illum.
Aperiam distinctio doloribus laboriosam pariatur aut labore harum reiciendis accusamus.
Totam fugiat impedit harum a.
Esse quod quibusdam quaerat.'
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        4,
        57::numeric(12,2),
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Giambattista Piga',
        'http://beautiful-change.org',
        309.215,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Adrione_Reale28@yahoo.it',
        '+390082039914',
        '["/static/images/36742880-4fbc-4208-a6b6-3ec7290c112d.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]'::jsonb,
        'Accusantium magnam odio quam.
Dolores occaecati ducimus facere corrupti id maxime velit soluta vitae.
At odit expedita sapiente veritatis saepe quas eos quam.
Dolores explicabo quam reiciendis modi odit blanditiis dolore.'
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        10,
        59::numeric(12,2),
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Sostrato Vailati',
        'https://buttery-cymbal.net',
        296.554,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Sapiente77@hotmail.com',
        '+396678121121',
        '["/static/images/831a8347-cb69-4cd2-909e-73c60f704db3.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg"]'::jsonb,
        'Aspernatur magni et beatae earum harum nam natus maiores vero.
Voluptatum praesentium quas dolor dolorum quibusdam ipsam dignissimos.
Consequatur veritatis eveniet.'
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        2,
        82::numeric(12,2),
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Adrione Zanella',
        'http://exemplary-bit.com',
        281.201,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Fernando99@hotmail.com',
        '+390343160829',
        '["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]'::jsonb,
        'Fugit vitae corporis quod voluptates laudantium repellat dolorem eius.
Voluptatem hic maiores qui vitae doloremque nobis quidem.
Ea tempore nesciunt nihil iusto.
Delectus adipisci accusantium fugiat.
Ratione in ratione velit consectetur nulla.'
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        7,
        131::numeric(12,2),
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Eliana Antonucci',
        'http://silly-grassland.it',
        299.601,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Costanza20@email.it',
        '+395728512617',
        '["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]'::jsonb,
        'Vero voluptates alias blanditiis quae minima fugiat saepe ad sint.
Ad eveniet odio animi recusandae dignissimos nihil ipsa ad totam.'
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        10,
        56::numeric(12,2),
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Gedeone Rubino',
        'https://valuable-impropriety.org',
        320.814,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Eliano71@yahoo.it',
        '+398293556642',
        '["/static/images/36742880-4fbc-4208-a6b6-3ec7290c112d.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg"]'::jsonb,
        'Unde alias voluptate eos.
Quibusdam magnam officia provident neque asperiores aspernatur repudiandae reiciendis.
Deleniti eaque sequi eveniet rem deleniti reprehenderit.'
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        8,
        79::numeric(12,2),
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Giada Quarta',
        'https://excitable-fiesta.net',
        290.727,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Alessio.Massimi@email.it',
        '+393527098996',
        '["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg"]'::jsonb,
        'Cum magni natus deleniti a tenetur.
Recusandae voluptatibus laborum eaque quod est distinctio repellat hic.
Cumque reprehenderit qui.
Neque modi omnis voluptatem temporibus laboriosam animi distinctio beatae nostrum.
Illum corporis excepturi cumque dicta.'
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        10,
        46::numeric(12,2),
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Sig. Guiscardo Barbagallo',
        'https://unhappy-screenwriting.com',
        282.568,
        '01:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Teodoro_Ranieri@yahoo.com',
        '+395817024924',
        '["/static/images/71595344-e22a-4095-9bca-112353382c7c.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]'::jsonb,
        'Praesentium aliquid omnis fugiat alias labore deserunt.
Nam alias harum similique facilis a nemo.
Aliquam veniam rerum odio.'
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        10,
        146::numeric(12,2),
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Ing. Venusto Principato',
        'http://truthful-indigence.it',
        288.362,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Fabiola42@hotmail.com',
        '+399640456768',
        '["/static/images/1c178114-d7fd-414a-9eef-1a1cac332f83.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg"]'::jsonb,
        'Eius impedit facere nulla consequuntur eaque porro.
Cumque assumenda maiores quo.'
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        2,
        102::numeric(12,2),
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Francesco Ferranti',
        'https://essential-essence.net',
        276.911,
        '08:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Letterio_DiLiberto@libero.it',
        '+391653431168',
        '["/static/images/fbeba133-9be3-4029-a690-3c1f0d35db2c.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg"]'::jsonb,
        'Odio laborum architecto delectus odio voluptatibus consequuntur vero.
Blanditiis tempora saepe deleniti.
Quas temporibus placeat quam rerum tempora dolores illo adipisci.'
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        3,
        59::numeric(12,2),
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Antonella Spadoni',
        'http://miserable-try.com',
        312.907,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Elda_Gianni@yahoo.it',
        '+397225528247',
        '["/static/images/0d76968e-1a08-415d-aaa7-0b7edaa1aef0.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg"]'::jsonb,
        'Animi illo corrupti explicabo tempore quos natus.
Illo occaecati suscipit molestiae doloremque illo nisi sapiente.
Praesentium dolor quidem sequi magnam quas eius quas aliquid architecto.'
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        10,
        59::numeric(12,2),
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Cronida Biondi',
        'http://angelic-min.org',
        322.628,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Evidio.Petralia17@libero.it',
        '+396912763737',
        '["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg"]'::jsonb,
        'Recusandae eos doloremque possimus dolor in eius sunt corrupti.
Ad nulla quod placeat sed illum.'
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        8,
        75::numeric(12,2),
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Dott. Vezio Iuliano',
        'http://wan-bull.com',
        302.752,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Antonio.DeBonis@yahoo.com',
        '+391627698790',
        '["/static/images/831a8347-cb69-4cd2-909e-73c60f704db3.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]'::jsonb,
        'Doloribus laboriosam perspiciatis quis quidem.
Nostrum quis quia itaque quisquam vero quos aliquam in aperiam.
Distinctio iusto deleniti officia eligendi voluptas consequuntur laboriosam accusantium.'
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        2,
        103::numeric(12,2),
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Antonio Platania',
        'https://interesting-lymphocyte.org',
        299.416,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Norina89@libero.it',
        '+393193509855',
        '["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg"]'::jsonb,
        'Illo repellendus id deserunt eos neque expedita distinctio architecto facere.
Molestias sapiente quas quod earum quod molestias.'
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        6,
        126::numeric(12,2),
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Dr. Marcello Bisio',
        'https://required-pegboard.it',
        320.437,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Alfonsa.Evangelista@libero.it',
        '+399733759315',
        '["/static/images/fbcdf907-68c2-4ed1-999a-81601551aa5d.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg"]'::jsonb,
        'Excepturi a id repudiandae eligendi minima qui laborum aut quos.
Enim ipsa ex suscipit sed.
Provident necessitatibus alias nesciunt nesciunt iure nisi voluptatum.
Quasi optio deleniti illum ipsa sit aspernatur.'
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        7,
        82::numeric(12,2),
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Gianmario Nanni',
        'https://hot-morsel.net',
        301.377,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Mirco.Frigerio@hotmail.com',
        '+393417935220',
        '["/static/images/380dce13-b063-4641-bbf2-173987d94f64.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg"]'::jsonb,
        'Repellat ea dolorum voluptatibus veniam.
Sunt possimus a quo in.
Fuga consequuntur doloribus placeat.'
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        8,
        100::numeric(12,2),
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Postumio Fantozzi',
        'https://menacing-impact.com',
        272.653,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Leonio.Iacovino0@gmail.com',
        '+399664121546',
        '["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg"]'::jsonb,
        'Libero corrupti consectetur nulla hic eaque quam.
Nisi saepe non corrupti vero a distinctio expedita officia.'
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        2,
        35::numeric(12,2),
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Cunegonda Mattei',
        'https://acceptable-board.net',
        283.678,
        '09:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Cleofe.Oggiano@gmail.com',
        '+393999311810',
        '["/static/images/9156aa5a-9192-446f-9f5e-7fe51ffbf7c6.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]'::jsonb,
        'Nihil dolorum corrupti accusantium magni nulla alias laborum harum libero.
Earum deserunt ab fuga recusandae hic minus corrupti.
Nobis nulla culpa qui.
Vitae quis sapiente.'
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        9,
        58::numeric(12,2),
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Rainelda Campana',
        'http://vain-hotdog.net',
        291.154,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Settimio.Iacovino@hotmail.com',
        '+393935547156',
        '["/static/images/cc09fac1-266b-4032-9864-7e652f27929c.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg"]'::jsonb,
        'Vero cum incidunt.
Deserunt laudantium suscipit enim praesentium voluptatum omnis quidem totam pariatur.
Vero quis voluptas iste perferendis qui atque iste quis esse.
Eos nulla rerum voluptatibus possimus quisquam ullam commodi assumenda iure.
Blanditiis culpa quis dolore hic debitis cupiditate.'
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        8,
        86::numeric(12,2),
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Sefora Ceccarini',
        'http://shrill-noodle.net',
        314.741,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Geronzio.Villani@yahoo.it',
        '+391131553895',
        '["/static/images/729d360a-2e24-4b59-869a-1086080537d7.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]'::jsonb,
        'Quam quibusdam dignissimos harum quia ut ea illo nulla.
Debitis corrupti iusto voluptatem quam earum.
Molestias neque earum distinctio unde facilis adipisci quod perferendis atque.'
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        6,
        85::numeric(12,2),
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Marzia Toscano',
        'https://wide-eyed-kidney.net',
        325.284,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Zenone.Ambrosino@libero.it',
        '+398262442241',
        '["/static/images/94072c68-40d4-4987-9b04-538fd16420d2.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg"]'::jsonb,
        'Libero asperiores aperiam natus.
Similique modi at veritatis sunt repellat maxime nihil repudiandae corporis.
Magni id tenetur amet tempore.
Exercitationem modi porro.'
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        3,
        107::numeric(12,2),
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Mirta Cappello',
        'http://bountiful-proof-reader.net',
        308.065,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Adriana48@yahoo.it',
        '+399546044257',
        '["/static/images/71595344-e22a-4095-9bca-112353382c7c.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg"]'::jsonb,
        'Asperiores quo minima ad accusamus.
Voluptatibus incidunt aspernatur sed.
Ad nesciunt maiores aut repudiandae est blanditiis tempore consequatur.'
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        10,
        79::numeric(12,2),
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Alvise Spadaro',
        'http://edible-coverage.net',
        291.773,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Ghita_Musumeci@yahoo.com',
        '+393295971063',
        '["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg"]'::jsonb,
        'Possimus natus porro officiis.
Error pariatur earum id.
Magni aliquid adipisci fuga vero cumque quas.
Occaecati unde quisquam maiores quibusdam assumenda perferendis iste officiis distinctio.'
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        3,
        130::numeric(12,2),
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Amore Santangelo',
        'http://elderly-genius.it',
        324.556,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Erasmo98@gmail.com',
        '+397859138996',
        '["/static/images/84c2223b-e884-43a7-a5e4-3f4cc417f6ba.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg"]'::jsonb,
        'Repudiandae perferendis omnis sunt ipsum ab et eos.
Autem cumque exercitationem error quas nam corporis.
Libero dolorum enim nam quos occaecati molestiae provident recusandae.'
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        5,
        84::numeric(12,2),
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Iona Cremonesi',
        'http://studious-knee.com',
        269.587,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Gerolamo.Ferrara@yahoo.com',
        '+390622664254',
        '["/static/images/9156aa5a-9192-446f-9f5e-7fe51ffbf7c6.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]'::jsonb,
        'Saepe cupiditate minima minus id consequuntur harum doloremque.
Sapiente facere exercitationem necessitatibus necessitatibus ut esse quo voluptatem nihil.'
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        3,
        144::numeric(12,2),
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Benedetto Simula',
        'https://parched-match.net',
        330.392,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Landolfo.Perrini59@yahoo.it',
        '+396401895714',
        '["/static/images/e6b68bd4-d913-4dcb-ab5a-364d13775e8d.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg"]'::jsonb,
        'Omnis perferendis non minus pariatur reiciendis qui dolorum sequi quas.
Distinctio placeat ipsam dolorum veritatis rerum eos cupiditate suscipit.
Assumenda nam ex iure sapiente quidem harum.
Incidunt amet nostrum atque facere quibusdam blanditiis.'
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        10,
        132::numeric(12,2),
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Adriano Visani',
        'http://worst-atm.com',
        322.904,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Diocleziano_Boscaino14@yahoo.com',
        '+390228088721',
        '["/static/images/94072c68-40d4-4987-9b04-538fd16420d2.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg"]'::jsonb,
        'Nam recusandae vero ea.
Magni facilis vitae sequi molestias nemo aspernatur perferendis.
Eius natus nulla hic placeat delectus cumque sint voluptatem.
Iusto fugit soluta ipsa molestiae alias necessitatibus quibusdam dolores.
Tempore magni debitis.'
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        7,
        56::numeric(12,2),
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Dott. Diletta Di Tommaso',
        'http://witty-cloak.org',
        274.208,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Zeno_Antonini96@yahoo.com',
        '+399100736152',
        '["/static/images/9156aa5a-9192-446f-9f5e-7fe51ffbf7c6.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg"]'::jsonb,
        'Repudiandae aliquid labore veritatis totam ea ad temporibus quae.
Quasi nulla doloribus.
Recusandae ad ipsum debitis cupiditate qui repudiandae.'
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        6,
        123::numeric(12,2),
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Guendalina Vallone',
        'http://content-intent.net',
        293.644,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Aristide_Amoruso91@yahoo.com',
        '+394273379238',
        '["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg"]'::jsonb,
        'Quia quisquam asperiores accusantium architecto repellat aliquam dolorem et.
Consequuntur dignissimos laboriosam cupiditate quaerat vero.
Ullam officiis necessitatibus vel quasi.'
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        3,
        36::numeric(12,2),
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Godeberta Abbate',
        'https://oblong-uplift.net',
        279.611,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Calpurnia_Salerno94@hotmail.com',
        '+396528359519',
        '["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg"]'::jsonb,
        'Officiis fugiat sed expedita unde maxime esse earum voluptatibus.
Ipsum tempora architecto velit.
Ab possimus nulla voluptate mollitia.
Dolorem aut quis pariatur quam vero modi.'
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        6,
        92::numeric(12,2),
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Acrisio Foti',
        'https://rotten-tabernacle.org',
        279.226,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Spano_Gasparini@yahoo.it',
        '+392920263043',
        '["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg"]'::jsonb,
        'Quidem doloribus eum.
Suscipit quisquam eum at.'
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        3,
        148::numeric(12,2),
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Ondina Brunetti',
        'https://windy-dinosaur.it',
        305.132,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Nicodemo.Corsi@hotmail.com',
        '+395444883638',
        '["/static/images/b6a44f8c-a9ac-4f1b-84cb-41910e38cc6e.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]'::jsonb,
        'Veniam facilis sequi.
Odit debitis sint excepturi saepe iste possimus.'
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        4,
        55::numeric(12,2),
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Narseo Agostini',
        'http://unhealthy-harmonica.net',
        315.644,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Leonio31@libero.it',
        '+390430054273',
        '["/static/images/fbcdf907-68c2-4ed1-999a-81601551aa5d.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]'::jsonb,
        'Dolorum quaerat repudiandae quas voluptate quod ipsam tenetur debitis illum.
Aut dignissimos est.
Nesciunt vel quidem sapiente.
Aliquid ab saepe adipisci omnis sunt aut pariatur perspiciatis.'
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        4,
        92::numeric(12,2),
        'Wittener Hütte',
        'Germany',
        'Ezio Cioffi',
        'http://alarmed-puggle.org',
        323.335,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Adelaide.Todaro@gmail.com',
        '+390099702386',
        '["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg"]'::jsonb,
        'Facilis veniam occaecati est inventore earum consequatur suscipit illo accusamus.
Amet doloribus officiis inventore.
Delectus ab saepe dolores id velit fugiat adipisci.
Nihil quasi perspiciatis quia placeat.'
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        8,
        91::numeric(12,2),
        'Hochjoch-Hospiz',
        'Austria',
        'Menodora Saponaro',
        'https://honorable-kick.com',
        296.464,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Fiore.Picco@hotmail.com',
        '+399287867236',
        '["/static/images/729d360a-2e24-4b59-869a-1086080537d7.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg"]'::jsonb,
        'Expedita commodi eaque molestias sapiente similique eum rerum.
Ex reiciendis laborum adipisci expedita nam.'
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        2,
        90::numeric(12,2),
        'Meilerhütte',
        'Germany',
        'Devota Nicolosi',
        'https://spicy-roundabout.net',
        313.948,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Mennone_DelPrete40@yahoo.com',
        '+396326012548',
        '["/static/images/fbeba133-9be3-4029-a690-3c1f0d35db2c.jpg","/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg"]'::jsonb,
        'Accusamus veritatis pariatur dolores.
Odit esse cupiditate exercitationem ipsa enim beatae.
Fuga aliquid a quos veritatis.'
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        5,
        138::numeric(12,2),
        'Gaudeamushütte',
        'Austria',
        'Valter Malagoli',
        'http://helpful-sanctuary.net',
        315.888,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Olimpio21@gmail.com',
        '+390395828803',
        '["/static/images/84c2223b-e884-43a7-a5e4-3f4cc417f6ba.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]'::jsonb,
        'Blanditiis aut aspernatur similique officia.
Inventore similique dolor eligendi explicabo mollitia architecto voluptate dolorem.'
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        6,
        42::numeric(12,2),
        'Rheydter Hütte',
        'Germany',
        'Zenobio Turco',
        'http://hilarious-alphabet.org',
        286.772,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Liberio.Bellotti@email.it',
        '+395891804954',
        '["/static/images/fbeba133-9be3-4029-a690-3c1f0d35db2c.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg"]'::jsonb,
        'Doloribus architecto illum error.
Debitis odit provident laboriosam repudiandae expedita voluptatem molestiae rerum.
Consequatur officia eum ducimus deleniti modi illo iusto eveniet.'
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        4,
        75::numeric(12,2),
        'Sektionshütte Krippen',
        'Germany',
        'Democrito Nanni',
        'http://traumatic-tailbud.it',
        294.874,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Venere_Giorgio47@yahoo.com',
        '+399149883882',
        '["/static/images/380dce13-b063-4641-bbf2-173987d94f64.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg"]'::jsonb,
        'Incidunt nisi magni dignissimos.
Animi ipsum suscipit aliquam a omnis.
Quae recusandae dignissimos in id laborum doloribus quia.
Quas aperiam nobis sed vero possimus laboriosam sint quisquam.'
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        10,
        56::numeric(12,2),
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Ramiro Santo',
        'http://kindly-carnation.org',
        302.874,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Abele62@libero.it',
        '+392320867083',
        '["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg"]'::jsonb,
        'Eius quod laudantium ab voluptate deleniti quaerat est magni mollitia.
Placeat repellat aliquam error.
Autem commodi fugit dicta cupiditate eveniet tempore omnis ipsa.
Modi dolores nihil veritatis non natus.'
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        5,
        118::numeric(12,2),
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Alfreda Gianni',
        'https://yellow-jazz.net',
        268.24,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Vilfredo_Catellani52@yahoo.com',
        '+392111055683',
        '["/static/images/1c178114-d7fd-414a-9eef-1a1cac332f83.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]'::jsonb,
        'Tenetur autem quasi alias.
Perspiciatis harum voluptatem similique.
In minus dicta harum veniam recusandae.'
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        2,
        72::numeric(12,2),
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Gianmario Schifano',
        'https://bare-snowstorm.it',
        300.602,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Esuperio4@email.it',
        '+390191909666',
        '["/static/images/1c178114-d7fd-414a-9eef-1a1cac332f83.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg"]'::jsonb,
        'Culpa debitis officia deleniti iusto fugiat itaque.
Cum a accusamus aliquam.
Quas fugiat molestias natus iure iste vitae asperiores numquam maiores.
Totam pariatur voluptas in.'
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        4,
        137::numeric(12,2),
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Annunziata Andrisani',
        'https://hollow-paperback.net',
        277.929,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Querano.LaRosa3@gmail.com',
        '+399115893400',
        '["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg"]'::jsonb,
        'Temporibus aut neque consequuntur.
Sunt sed minus quam reprehenderit quas neque vitae quae.'
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        10,
        105::numeric(12,2),
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Dr. Azzurra Flacco',
        'https://cruel-snowstorm.net',
        318.847,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Namazio9@gmail.com',
        '+395660392410',
        '["/static/images/cc09fac1-266b-4032-9864-7e652f27929c.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg"]'::jsonb,
        'Doloribus sapiente quisquam aut cumque illum nam rerum totam quia.
Pariatur minus perspiciatis dolor sit molestias adipisci pariatur quibusdam placeat.'
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        5,
        137::numeric(12,2),
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Nazario Rea',
        'https://stained-press.net',
        323.104,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Salomone_DAvino@yahoo.it',
        '+397395873025',
        '["/static/images/9156aa5a-9192-446f-9f5e-7fe51ffbf7c6.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg"]'::jsonb,
        'Porro hic dolore labore velit aperiam similique.
Ut nemo cupiditate qui corrupti tempore dolores tenetur laudantium.'
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        2,
        93::numeric(12,2),
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Tecla Feliziani',
        'http://curly-eavesdropper.net',
        331.455,
        '03:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Rosamunda.Polizzi@gmail.com',
        '+395396747319',
        '["/static/images/71595344-e22a-4095-9bca-112353382c7c.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]'::jsonb,
        'Omnis eius laboriosam officia.
Voluptates omnis repellat tempore incidunt doloremque.
Pariatur sunt assumenda.'
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        2,
        131::numeric(12,2),
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Adriano Ventimiglia',
        'https://adept-usage.net',
        323.471,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Venceslao72@hotmail.com',
        '+390451591752',
        '["/static/images/cc09fac1-266b-4032-9864-7e652f27929c.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg"]'::jsonb,
        'Molestias doloremque veniam.
A sed voluptatibus corporis dolor officia fuga quas doloribus libero.
Nam amet natus quae.
Iure excepturi facere saepe vel aliquid.'
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        8,
        148::numeric(12,2),
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Gaudenzia Bertani',
        'http://neat-sexuality.net',
        303.678,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Ugolino17@gmail.com',
        '+396869101684',
        '["/static/images/1c178114-d7fd-414a-9eef-1a1cac332f83.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]'::jsonb,
        'Doloribus ullam cupiditate.
Veritatis esse alias neque.'
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        4,
        114::numeric(12,2),
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Amelia Aiello',
        'http://keen-postage.com',
        314.652,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Eliana.Amato12@libero.it',
        '+398462693649',
        '["/static/images/831a8347-cb69-4cd2-909e-73c60f704db3.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]'::jsonb,
        'Totam quas reprehenderit.
Reiciendis amet velit autem quia amet sunt iste nemo.
Possimus rerum harum ea unde.
Vitae nam commodi inventore tempore.
Iste architecto perferendis placeat ut eius possimus ratione.'
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        8,
        115::numeric(12,2),
        'Dobra voda',
        'Suvobor, Serbia',
        'Sibilla Biagi',
        'http://fumbling-cemetery.net',
        323.647,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Parmenio.Spadoni73@libero.it',
        '+396907078740',
        '["/static/images/3f6d2aea-9d16-4208-84e9-d54ed4d72045.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg","/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg"]'::jsonb,
        'Deleniti officiis vel illum consequuntur ducimus.
Sapiente mollitia itaque occaecati reprehenderit deleniti vitae nulla neque.'
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        9,
        115::numeric(12,2),
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Marana Bressan',
        'https://practical-wrestler.com',
        301.944,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Carola_Campana14@libero.it',
        '+395887566671',
        '["/static/images/36742880-4fbc-4208-a6b6-3ec7290c112d.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg"]'::jsonb,
        'Officiis dignissimos voluptatibus itaque dicta placeat nihil commodi corrupti laboriosam.
Ipsum perspiciatis cupiditate debitis minima.
Harum fuga laborum molestiae doloremque libero nam ipsam molestias nobis.'
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        4,
        63::numeric(12,2),
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Consolata Betti',
        'http://admired-thrill.org',
        275.441,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Danio11@hotmail.com',
        '+390443948691',
        '["/static/images/380dce13-b063-4641-bbf2-173987d94f64.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg","/static/images/fe974833-d199-4930-a743-101adf12d243.jpg","/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg"]'::jsonb,
        'Nam omnis aspernatur blanditiis architecto odit quos doloremque.
Nam eos beatae labore voluptas minima sed.
Velit saepe cum nam magnam.'
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        4,
        131::numeric(12,2),
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Crocefisso De Luca',
        'https://satisfied-kitten.it',
        321.501,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Cleandro42@yahoo.it',
        '+393253876375',
        '["/static/images/71595344-e22a-4095-9bca-112353382c7c.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg"]'::jsonb,
        'Laboriosam iure est incidunt.
A quod perferendis accusantium corrupti perspiciatis quia porro consequatur perferendis.
Quidem nostrum quis dignissimos molestias a dolorum.
Voluptates voluptatibus alias libero tenetur nisi eligendi fuga possimus.
Sapiente enim repellendus nisi.'
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        3,
        134::numeric(12,2),
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Brando Lo Giudice',
        'http://downright-vintner.org',
        274.157,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Amalia0@yahoo.com',
        '+396808293122',
        '["/static/images/1c178114-d7fd-414a-9eef-1a1cac332f83.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg"]'::jsonb,
        'Pariatur est iure quod expedita quae.
Debitis iusto odit facere odio cumque ab dicta dolorem.
Consequatur sint placeat dolorem ipsam quam veniam.'
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        9,
        89::numeric(12,2),
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Dott. Gedeone Tralli',
        'https://afraid-borrowing.it',
        282.67,
        '04:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Emiliano_Mosti31@libero.it',
        '+397398692334',
        '["/static/images/0d76968e-1a08-415d-aaa7-0b7edaa1aef0.jpg","/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg"]'::jsonb,
        'Pariatur nesciunt alias architecto tenetur.
Facere eveniet temporibus nam.
Odio praesentium dolores cumque odio nisi modi.
Dolorem voluptatibus sapiente ad dolore quod perferendis neque.'
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        10,
        149::numeric(12,2),
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Nazzareno Turchi',
        'https://robust-encirclement.org',
        273.569,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Alberta74@yahoo.it',
        '+392343964724',
        '["/static/images/fbcdf907-68c2-4ed1-999a-81601551aa5d.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg"]'::jsonb,
        'Veritatis sequi ut earum.
Non laboriosam nisi libero dolor magnam qui voluptas.
Praesentium quaerat voluptate quibusdam eos delectus sunt harum quae sit.
Animi praesentium voluptas fugit quia vitae officia.'
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        10,
        69::numeric(12,2),
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Elia Demurtas',
        'http://charming-coach.com',
        283.099,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Antonella.Natale@hotmail.com',
        '+397452420567',
        '["/static/images/8765fd5b-1e43-4aa4-b7d3-1e21c02555d6.jpg","/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]'::jsonb,
        'Labore eius quo incidunt adipisci eius.
Et consectetur accusantium in eveniet impedit ipsam quo aliquam.
Optio vero sed reiciendis veniam.
Cumque sint facilis illum odio esse beatae modi nam.
Totam pariatur atque necessitatibus quidem deserunt veniam perspiciatis porro numquam.'
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        2,
        104::numeric(12,2),
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Soccorso Crescenzi',
        'https://menacing-sailing.com',
        315.481,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Savino_Zuliani85@hotmail.com',
        '+394021262887',
        '["/static/images/0d76968e-1a08-415d-aaa7-0b7edaa1aef0.jpg","/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg","/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg"]'::jsonb,
        'Delectus nisi aspernatur error.
Occaecati consectetur delectus.
Architecto libero aliquam.'
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        10,
        116::numeric(12,2),
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Lucio Sorrentino',
        'http://colorless-linseed.com',
        272.418,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Odorico_Traverso@yahoo.it',
        '+394108858621',
        '["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg","/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg","/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg","/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg","/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg"]'::jsonb,
        'Officia commodi a perferendis est corrupti tempore enim nisi earum.
Totam quibusdam odio rerum consectetur facilis fugiat natus.
Commodi quis animi recusandae pariatur quia.'
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        4,
        127::numeric(12,2),
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Fulgenzio Zappacosta',
        'https://abandoned-android.net',
        320.981,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Valter_Paris@hotmail.com',
        '+396816250544',
        '["/static/images/831a8347-cb69-4cd2-909e-73c60f704db3.jpg","/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg","/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg","/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg","/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg"]'::jsonb,
        'Dignissimos ea facere laboriosam optio odio.
Quia commodi ipsum nostrum iste omnis ab sit nihil.
Odit ratione esse odit eaque cum quisquam qui incidunt.
Expedita eius modi saepe.
Sapiente voluptate fugiat repellendus.'
      );
    
  

      CREATE OR REPLACE FUNCTION public.insert_hut_worker(
        hwid integer,
        email varchar,
        password varchar,
        first_name varchar,
        last_name varchar,
        role integer,
        hut_id integer,
        approved boolean
      ) RETURNS VOID AS
      $func$
      DECLARE
        user_id integer;
      BEGIN
      INSERT INTO "public"."users" (
        "id",
        "email",
        "password",
        "firstName",
        "lastName",
        "role",
        "verified",
        "approved"
      ) VALUES(
        hwid, email, password, first_name, last_name, role, true, approved
      ) returning id into user_id;

      INSERT INTO "public"."hut-worker" (
        "userId",
        "hutId"
      ) VALUES ( user_id, hut_id);
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hut_worker"(
        7,
        'hutWorker0@gmail.com',
        '$2b$10$GZcJRxk1KtlU3wCWfjnlGuwZQ8iB5fUaXI0PggKMpde24Ndbg7cH6',
        'Gherardo',
        'Papapietro',
        4,
        1,
        true
      );
    

      select public."insert_hut_worker"(
        8,
        'hutWorker1@gmail.com',
        '$2b$10$8iOJYgqRkCsi5BlZGPTuguuj/KOEPKqkqivJXRGnI2n4nJrvvbMnW',
        'Pantaleone',
        'Paradiso',
        4,
        2,
        false
      );
    

      select public."insert_hut_worker"(
        9,
        'hutWorker2@gmail.com',
        '$2b$10$mIEqFOHRWbho4CKGbP5vnOCiXT1bFS2IgqLR7Yfzs26K/Pwi.u95K',
        'Luciana',
        'Soldati',
        4,
        3,
        true
      );
    

      select public."insert_hut_worker"(
        10,
        'hutWorker3@gmail.com',
        '$2b$10$aRevCMhnyurbMY4cOGrXcuuypXBTIS9wTQYwBfUZwMgHprBfx9yPC',
        'Almiro',
        'Rinaldi',
        4,
        4,
        false
      );
    

      select public."insert_hut_worker"(
        11,
        'hutWorker4@gmail.com',
        '$2b$10$Q8JGIHgJvhPBKs2I/WKz.OcwbnSpTa7mO1HpGPSb2DKAdfCfKZ7Na',
        'Adalgiso',
        'Catalano',
        4,
        5,
        true
      );
    

      select public."insert_hut_worker"(
        12,
        'hutWorker5@gmail.com',
        '$2b$10$qxKykdI.qnyYTyoYCC3IFOpGYVd4StvEY5HQWQVP5lEJ62a63Egl2',
        'Ausilia',
        'Nobili',
        4,
        6,
        false
      );
    

      select public."insert_hut_worker"(
        13,
        'hutWorker6@gmail.com',
        '$2b$10$pSoAvyEkPX7H/ctxtJwWiOUpwrzyCg2khCRHT1/Ulo93d92a/d6Nu',
        'Doriano',
        'Farina',
        4,
        7,
        true
      );
    

      select public."insert_hut_worker"(
        14,
        'hutWorker7@gmail.com',
        '$2b$10$2QAanr5synevdi/kzwncC.r9LgtYakgOz8MEsl2oDiae0UGD/4Pqa',
        'Ildefonso',
        'Pozzi',
        4,
        8,
        false
      );
    

      select public."insert_hut_worker"(
        15,
        'hutWorker8@gmail.com',
        '$2b$10$bHkEGNHXiDUorMcVDFQR6Ohg9fMwvv08c1MoRFwHickYal/V5P4Ta',
        'Edvige',
        'Sammartino',
        4,
        9,
        true
      );
    

      select public."insert_hut_worker"(
        16,
        'hutWorker9@gmail.com',
        '$2b$10$PlOalGfnXVFC.zUD19ZrNeM5eKiTUtU81uy3ojXHOlxjAYG/IskX6',
        'Pomponio',
        'Castagna',
        4,
        10,
        false
      );
    

      select public."insert_hut_worker"(
        17,
        'hutWorker10@gmail.com',
        '$2b$10$GHM2e5/gS8aA90OMDaitEuOABKZk3quSzKhY9bJbT0PEeSdvqoT86',
        'Palladia',
        'Favara',
        4,
        11,
        true
      );
    

      select public."insert_hut_worker"(
        18,
        'hutWorker11@gmail.com',
        '$2b$10$56LNVxRRBnlZg1UmhPb.zek.oGaxfVGPor9ysOF3IBtzGyytLHZZm',
        'Romero',
        'Testa',
        4,
        12,
        false
      );
    

      select public."insert_hut_worker"(
        19,
        'hutWorker12@gmail.com',
        '$2b$10$m0cAPP9FyuSm5bgVHoN1R.ZGKzr.s1978o1NeCcCz0xDNqNjlABUu',
        'Semiramide',
        'Cavalli',
        4,
        13,
        true
      );
    

      select public."insert_hut_worker"(
        20,
        'hutWorker13@gmail.com',
        '$2b$10$MxFqthoVIZP7Iu/Ff.ny1u7wf6JCFxWXh6QLFVwEDrDpUc/iL5n1K',
        'Debora',
        'Di Tommaso',
        4,
        14,
        false
      );
    

      select public."insert_hut_worker"(
        21,
        'hutWorker14@gmail.com',
        '$2b$10$hqPcOwh5IXeW47Np8VEtZ.lxiPvGjXduOQkfgYUGdWC1xRWWbTfmO',
        'Acrisio',
        'Di Pasquale',
        4,
        15,
        true
      );
    

      select public."insert_hut_worker"(
        22,
        'hutWorker15@gmail.com',
        '$2b$10$2euQ2X4VsAJoHQrLE1MmieM0axu/Kv4TbRNj.uz1oj6NXRyeDwqMi',
        'Deodata',
        'Bernardini',
        4,
        16,
        false
      );
    

      select public."insert_hut_worker"(
        23,
        'hutWorker16@gmail.com',
        '$2b$10$3lJqVjA3zolK9W1rx1gabehKLt54n6DLQs3fs.pds76WNtle6XUy6',
        'Santina',
        'Bovolenta',
        4,
        17,
        true
      );
    

      select public."insert_hut_worker"(
        24,
        'hutWorker17@gmail.com',
        '$2b$10$e9vV/486KtjdwNZpXdeT/.n8A8xb8hyu81lI.9g26G4VQCTPDkO7G',
        'Postumio',
        'Buzzi',
        4,
        18,
        false
      );
    

      select public."insert_hut_worker"(
        25,
        'hutWorker18@gmail.com',
        '$2b$10$PmnnKj/ZgL7961H8sM7l2.JEI0s14Rd0zneGssLbiP1Yy6T4zv27G',
        'Coreno',
        'Saracino',
        4,
        19,
        true
      );
    

      select public."insert_hut_worker"(
        26,
        'hutWorker19@gmail.com',
        '$2b$10$YktrgNqF3xyWNytFYN6Za..w3JkkLEZah3gZ3qbjzV7nMqx5//Bpq',
        'Genesia',
        'La Porta',
        4,
        20,
        false
      );
    

      select public."insert_hut_worker"(
        27,
        'hutWorker20@gmail.com',
        '$2b$10$r9lk4rKUa.g29.wXUwwnS.kequur34ZS1Z2TBBxvon6qnljEsvNrW',
        'Adria',
        'Falbo',
        4,
        21,
        true
      );
    

      select public."insert_hut_worker"(
        28,
        'hutWorker21@gmail.com',
        '$2b$10$.1nouSmAKfe6OYfIRCAOaOlJLppqCZGv4yjcnw6KE/Rk0KmWUBh7u',
        'Onorata',
        'Rondoni',
        4,
        22,
        false
      );
    

      select public."insert_hut_worker"(
        29,
        'hutWorker22@gmail.com',
        '$2b$10$C9o.JCffaYMVorY/1VgtruDct/wAucwYAvsFn2nTsHLNaFLxphnja',
        'Dacio',
        'Penna',
        4,
        23,
        true
      );
    

      select public."insert_hut_worker"(
        30,
        'hutWorker23@gmail.com',
        '$2b$10$HHNwI.Zps57vP0J9m9bwNeNpVfZC0rq13ZOVB5dFe7m3ABlelBCXK',
        'Vladimiro',
        'Fiorucci',
        4,
        24,
        false
      );
    

      select public."insert_hut_worker"(
        31,
        'hutWorker24@gmail.com',
        '$2b$10$pHx1X.NOyi5/bI56G.tQ/uuiuodlLpM/ajpZ1cKiV3guBrSosS8He',
        'Marcella',
        'Minniti',
        4,
        25,
        true
      );
    

      select public."insert_hut_worker"(
        32,
        'hutWorker25@gmail.com',
        '$2b$10$qLve7bRo9ZuX6eYi9G0Lu.kkbg3qXispqPQl1dbUxddQP9xPb3WC2',
        'Amina',
        'Sucameli',
        4,
        26,
        false
      );
    

      select public."insert_hut_worker"(
        33,
        'hutWorker26@gmail.com',
        '$2b$10$IJG6zJEFPPfG6ntI/PDHGOL8zcT6qDEG8w8Q4lr2X1mQNFHpeNvKa',
        'Adria',
        'Bernardini',
        4,
        27,
        true
      );
    

      select public."insert_hut_worker"(
        34,
        'hutWorker27@gmail.com',
        '$2b$10$Ptzc5OIhzcTzWlye7J9tEuTJjvH/emGUiNOZjaTBbwAkTcOmbxGAS',
        'Ricario',
        'Buongiorno',
        4,
        28,
        false
      );
    

      select public."insert_hut_worker"(
        35,
        'hutWorker28@gmail.com',
        '$2b$10$kO4fMI3vTgZ/pw5QZUO3uO5F5nuOqKtsBSIFnbw7yvi5qcOzDC3W6',
        'Baldomero',
        'Simeoli',
        4,
        29,
        true
      );
    

      select public."insert_hut_worker"(
        36,
        'hutWorker29@gmail.com',
        '$2b$10$8rP1peFVlRL0VJXS3wxYnOv6n34yQJ6.LyLK.smVuSmdiPKqY5M9W',
        'Gabino',
        'Tassi',
        4,
        30,
        false
      );
    

      select public."insert_hut_worker"(
        37,
        'hutWorker30@gmail.com',
        '$2b$10$lJbDo1UT0pEM7YJVxo80e.rnBDU35o6Jw/Jb5j.7xuI..RIaqkq1O',
        'Irma',
        'Errante',
        4,
        31,
        true
      );
    

      select public."insert_hut_worker"(
        38,
        'hutWorker31@gmail.com',
        '$2b$10$jOeqKoU0Ym1tpdYFcoDw5epqcIW3yHuAERpp0AY698w7stFBA38J2',
        'Ermelinda',
        'Farella',
        4,
        32,
        false
      );
    

      select public."insert_hut_worker"(
        39,
        'hutWorker32@gmail.com',
        '$2b$10$opL6CtWhZGNK.2mjVKaB9uLK/2kqbqgKTlyl9yaMV.bvgdFzPEW16',
        'Eutalio',
        'Amico',
        4,
        33,
        true
      );
    

      select public."insert_hut_worker"(
        40,
        'hutWorker33@gmail.com',
        '$2b$10$xK5anhBnk0pWYztSAQtRzeBl4zgLVRGkHtNdKUq0A3JPuojDt4lDO',
        'Brunilde',
        'Giovannelli',
        4,
        34,
        false
      );
    

      select public."insert_hut_worker"(
        41,
        'hutWorker34@gmail.com',
        '$2b$10$ZHok6PJfXTUquuHJXSBCHeSZDBNy/X9GmcgpCKfH9O0Cg7yEpmi0G',
        'Reginaldo',
        'Boscolo',
        4,
        35,
        true
      );
    

      select public."insert_hut_worker"(
        42,
        'hutWorker35@gmail.com',
        '$2b$10$o7IscPQ0QHfuMLufCEr7vu962IljBMUXApxkzbE/zUvBeV9Ugwgli',
        'Tea',
        'Montalto',
        4,
        36,
        false
      );
    

      select public."insert_hut_worker"(
        43,
        'hutWorker36@gmail.com',
        '$2b$10$jpblk4hbexbMkas9LfsKJeybkkpKTpdWGfvLvwOjj0emHLGkHCe5i',
        'Dulina',
        'Garifo',
        4,
        37,
        true
      );
    

      select public."insert_hut_worker"(
        44,
        'hutWorker37@gmail.com',
        '$2b$10$Mjpyg9iy32FF6zoPc1St7O.I6TO0NZ0yD81I7XcgjcPJWA0uZcaqu',
        'Ersilia',
        'Di Domenico',
        4,
        38,
        false
      );
    

      select public."insert_hut_worker"(
        45,
        'hutWorker38@gmail.com',
        '$2b$10$3Q1dIm3IwcBU7.CbYDxvX.wqiCjynHAiCmgxunwVIV/J9G.KaY/DC',
        'Abenzio',
        'Congiu',
        4,
        39,
        true
      );
    

      select public."insert_hut_worker"(
        46,
        'hutWorker39@gmail.com',
        '$2b$10$clp6sK55y2xWZHvgEkpPrOLHup0hnzmyyPVpB0BsPFvAJvgZE1E9K',
        'Lucio',
        'Kofler',
        4,
        40,
        false
      );
    

      select public."insert_hut_worker"(
        47,
        'hutWorker40@gmail.com',
        '$2b$10$eHhIVA9IFWi0rhtd1.XrAONOqe4mepMpgk0asqWwB4soahWQUBSmy',
        'Tarcisio',
        'Parisi',
        4,
        41,
        true
      );
    

      select public."insert_hut_worker"(
        48,
        'hutWorker41@gmail.com',
        '$2b$10$wuxQ2PEHb9GMHJycKxIB0egDC0aFW6NAKP.LbOAFrHCmJBdUE.MN6',
        'Simone',
        'Albanese',
        4,
        42,
        false
      );
    

      select public."insert_hut_worker"(
        49,
        'hutWorker42@gmail.com',
        '$2b$10$.bnQY6YRagcpMw1YaxpuQ.yJDWbwlvpgSatRRKScIhhBpxq5PAGQO',
        'Romualdo',
        'Battaglia',
        4,
        43,
        true
      );
    

      select public."insert_hut_worker"(
        50,
        'hutWorker43@gmail.com',
        '$2b$10$1tsWkNilnjvp0F4V0ZLQqeaf8lg2LYkIzYiYayvWN1HH5F8TQeBh2',
        'Erardo',
        'Baldassarre',
        4,
        44,
        false
      );
    

      select public."insert_hut_worker"(
        51,
        'hutWorker44@gmail.com',
        '$2b$10$J62W1HubnIYuoASv09rcgesi/e4A20QoQJfhihQMLOoAYHqAWXbj6',
        'Desiderata',
        'Battistini',
        4,
        45,
        true
      );
    

      select public."insert_hut_worker"(
        52,
        'hutWorker45@gmail.com',
        '$2b$10$7MXEj2M/RIZH0irYu7PqbufQDWkAvlyGGj4D7fAIBYQPjO51PdS6K',
        'Teodolinda',
        'Fantozzi',
        4,
        46,
        false
      );
    

      select public."insert_hut_worker"(
        53,
        'hutWorker46@gmail.com',
        '$2b$10$db4e3.fP8r/GRZCy/dH/lOWIb2DEJ4ach37HTvL7ANSTdeyE.u68y',
        'Alessia',
        'Salerno',
        4,
        47,
        true
      );
    

      select public."insert_hut_worker"(
        54,
        'hutWorker47@gmail.com',
        '$2b$10$MKXEd0Q6ErKbqByor94gvuZNXPrpNQLORseYR2rQ10N/rPsWQzEPe',
        'Rolfo',
        'Spagnuolo',
        4,
        48,
        false
      );
    

      select public."insert_hut_worker"(
        55,
        'hutWorker48@gmail.com',
        '$2b$10$y.fAmjbcTMibtjqkpxuwjuf1wpxfuAwulCbkfj/S0aVGCVg4Lkb1i',
        'Alberto',
        'Tomaselli',
        4,
        49,
        true
      );
    

      select public."insert_hut_worker"(
        56,
        'hutWorker49@gmail.com',
        '$2b$10$fr/Svemcsi/bVTLMi49Cwu6epeckP0ZgBt71o9el6Atv/npF.JZoG',
        'Donatella',
        'Venturelli',
        4,
        50,
        false
      );
    

      select public."insert_hut_worker"(
        57,
        'hutWorker50@gmail.com',
        '$2b$10$ZVM4Y84ixXjZbGPI18O7POvPVADp6PKuuFAQYB757MNLbCkx73pqq',
        'Abbondanzio',
        'Lari',
        4,
        51,
        true
      );
    

      select public."insert_hut_worker"(
        58,
        'hutWorker51@gmail.com',
        '$2b$10$gefLbBWOYYyE.DRULrUf0.ASHV135a.Y8zI/dn5G7.NFg6fBkvgx.',
        'Zosima',
        'Ratti',
        4,
        52,
        false
      );
    

      select public."insert_hut_worker"(
        59,
        'hutWorker52@gmail.com',
        '$2b$10$LMxXJuKiixiRjkIKwhM3MO0TlfD0cCi8lyKEL/0yZlgADdI3tP7.C',
        'Sandro',
        'Zamboni',
        4,
        53,
        true
      );
    

      select public."insert_hut_worker"(
        60,
        'hutWorker53@gmail.com',
        '$2b$10$dGr.Q.K9LEBfiPdULsaLiOgp5vbn2Arzq6wJSrcXw0y6eZ5koP.ei',
        'Semplicio',
        'Graziani',
        4,
        54,
        false
      );
    

      select public."insert_hut_worker"(
        61,
        'hutWorker54@gmail.com',
        '$2b$10$snnxGKwKyVBIAS9L7vhe/uzns5XKAR6WiN3yE1MJQHkzN7t4n1aF6',
        'Rosamunda',
        'Di Francesco',
        4,
        55,
        true
      );
    

      select public."insert_hut_worker"(
        62,
        'hutWorker55@gmail.com',
        '$2b$10$LWl6zTN0XZ6/oJf4xmlV8e0WrFdpGtth7WPcJEh4Tq3skAuHIs3ti',
        'Ilenia',
        'Barra',
        4,
        56,
        false
      );
    

      select public."insert_hut_worker"(
        63,
        'hutWorker56@gmail.com',
        '$2b$10$U1Y5igLARMmh.8XeMHxVceNI011oLqWk1HED1eHXFAKU/s4ZuSguy',
        'Ferdinando',
        'Dal Farra',
        4,
        57,
        true
      );
    

      select public."insert_hut_worker"(
        64,
        'hutWorker57@gmail.com',
        '$2b$10$od4vEe1o0n5ZzefDAdyno.X504aLR.TBS0lEAyBDf1VpLo9/7uz7q',
        'Agenore',
        'Liccardo',
        4,
        58,
        false
      );
    

      select public."insert_hut_worker"(
        65,
        'hutWorker58@gmail.com',
        '$2b$10$fP3dvyVD47lTjs/1Pd3UX.c1fbGpozqxt6SVWUQQlCSDgr9paCk9y',
        'Sansone',
        'Ippolito',
        4,
        59,
        true
      );
    

      select public."insert_hut_worker"(
        66,
        'hutWorker59@gmail.com',
        '$2b$10$pwNnnu1JiElKB1kS/Bg2MOmtyZUbfUbHCMP0xbhbWeWwt9AyRW44a',
        'Cuzia',
        'Marrone',
        4,
        60,
        false
      );
    

      select public."insert_hut_worker"(
        67,
        'hutWorker60@gmail.com',
        '$2b$10$QaCP8vetoZl1EoQSA7969eqQmpk7Zph3RVbtnwZMgsr7usX5p/Zcy',
        'Elide',
        'Capitani',
        4,
        61,
        true
      );
    

      select public."insert_hut_worker"(
        68,
        'hutWorker61@gmail.com',
        '$2b$10$3usQipqKq7lXTOT.o/DmXetCdB4t6gMmGewxXUaNbnD5Tq0a44L.O',
        'Marita',
        'Ancona',
        4,
        62,
        false
      );
    

      select public."insert_hut_worker"(
        69,
        'hutWorker62@gmail.com',
        '$2b$10$2NrZjvpIzBOFyweTnHR2reeXuZDAmuOyiN6duYCvXOUkLN7bZ78wu',
        'Santo',
        'Casadei',
        4,
        63,
        true
      );
    

      select public."insert_hut_worker"(
        70,
        'hutWorker63@gmail.com',
        '$2b$10$CXWXXmvofo4wgbYWJSoHteMXq1eKPJ0P9x3yMwuDbW20eaeJKq4nm',
        'Siria',
        'Sanna',
        4,
        64,
        false
      );
    

      select public."insert_hut_worker"(
        71,
        'hutWorker64@gmail.com',
        '$2b$10$SV2F.7AHUleOPucUlHW1KeP4V43koz8nblp2CUSQH9RsX2axT.Qwa',
        'Aida',
        'Scorza',
        4,
        65,
        true
      );
    

      select public."insert_hut_worker"(
        72,
        'hutWorker65@gmail.com',
        '$2b$10$VEGnrTVkJgJ3EFpW/9yD3e9SNW1sqQmkejfa21Mv4TNT5BM/DlQaW',
        'Gregorio',
        'Sebastiani',
        4,
        66,
        false
      );
    

      select public."insert_hut_worker"(
        73,
        'hutWorker66@gmail.com',
        '$2b$10$Szg0WRx4j7NeawS.ozDR6eaWE0NpazHhACsxMGGV9HCPHrbHSEs2a',
        'Orsola',
        'Franzoni',
        4,
        67,
        true
      );
    

      select public."insert_hut_worker"(
        74,
        'hutWorker67@gmail.com',
        '$2b$10$3HnswvGUfmrfnfnRI8/nBujAVlJIEBN3zXvEpw3S/GlqMIwjbgfuu',
        'Vinebaldo',
        'Acquaviva',
        4,
        68,
        false
      );
    

      select public."insert_hut_worker"(
        75,
        'hutWorker68@gmail.com',
        '$2b$10$hybhxerU.QMFjdAP9Rvat.s0mtamk30MEei.0Z2QrlJP3f78CzRLa',
        'Guenda',
        'Cecere',
        4,
        69,
        true
      );
    

      select public."insert_hut_worker"(
        76,
        'hutWorker69@gmail.com',
        '$2b$10$ilO3gi4NcO/lNjRNFGkN3.gB2jxnjKz.CCSJmG5TE3WItEz7NfEJm',
        'Norina',
        'Chiavacci',
        4,
        70,
        false
      );
    

      select public."insert_hut_worker"(
        77,
        'hutWorker70@gmail.com',
        '$2b$10$HLYMoomRLywOAGSXslxghO4UaKfF804yQaWw9jt2mwtT/D.NOf3.q',
        'Anita',
        'Ambrosio',
        4,
        71,
        true
      );
    

      select public."insert_hut_worker"(
        78,
        'hutWorker71@gmail.com',
        '$2b$10$VDN2jw0E7zYdTUNxOMwJ2eMeO4D9Wlw1kY/b9e0hJp8BwvL.P95rO',
        'Enrica',
        'Casu',
        4,
        72,
        false
      );
    

      select public."insert_hut_worker"(
        79,
        'hutWorker72@gmail.com',
        '$2b$10$k4rrAPQWZ4rJkbec6bwJOOe2ZC6beH1NXMKNS/gcyhjnVlxdFoJVO',
        'Amintore',
        'Pittalis',
        4,
        73,
        true
      );
    

      select public."insert_hut_worker"(
        80,
        'hutWorker73@gmail.com',
        '$2b$10$pUN6/nWWqFYRgNyUTb5E8.J.4gmpsMnmeaSuWbLxeD3ED/.N9NSw6',
        'Goffredo',
        'Peroni',
        4,
        74,
        false
      );
    

      select public."insert_hut_worker"(
        81,
        'hutWorker74@gmail.com',
        '$2b$10$BjO4cO9HGmdj77p.aNLV6ehhzdu0umsu0QnyKBCuViiBapra28Qpm',
        'Polidoro',
        'Genchi',
        4,
        75,
        true
      );
    

      select public."insert_hut_worker"(
        82,
        'hutWorker75@gmail.com',
        '$2b$10$0LDbDxNBfVXe8T75X0dBHeUAnxa73ANmTC33lRip0CRkV4qtkGPG.',
        'Morena',
        'Bongiovanni',
        4,
        76,
        false
      );
    

      select public."insert_hut_worker"(
        83,
        'hutWorker76@gmail.com',
        '$2b$10$pEwptKY/Cn4B/x9M0f1c6e.QGkt8iMWG61OlxUMFRDosVlHFco64m',
        'Moira',
        'Cirelli',
        4,
        77,
        true
      );
    

      select public."insert_hut_worker"(
        84,
        'hutWorker77@gmail.com',
        '$2b$10$74obwZueE7v8qbzIBzt2qOMUb9dPS/2m.HUsbD47Pv.Fm8Udxaesq',
        'Arturo',
        'Boi',
        4,
        78,
        false
      );
    

      select public."insert_hut_worker"(
        85,
        'hutWorker78@gmail.com',
        '$2b$10$EOZF6dk4fc4wXRqiNqW53urzoLyJUONMBFMlbl1dahOUY5NxJPZ7i',
        'Scolastica',
        'Carminati',
        4,
        79,
        true
      );
    

      select public."insert_hut_worker"(
        86,
        'hutWorker79@gmail.com',
        '$2b$10$dwjcpADjnWiK33beEkBepuBkcbOfiv9kC2w1DNuYwSUa3Ra6N4o2C',
        'Carmen',
        'Polito',
        4,
        80,
        false
      );
    

      select public."insert_hut_worker"(
        87,
        'hutWorker80@gmail.com',
        '$2b$10$eFM6lE3/eDPmXXqmZyN0xudMkt0FOiv/Y1wZzh956fqY.rBbhgSue',
        'Germano',
        'Cattani',
        4,
        81,
        true
      );
    

      select public."insert_hut_worker"(
        88,
        'hutWorker81@gmail.com',
        '$2b$10$okvDvvF1KA8XFtuLoOnIpe1V1mJ58ex5QO/R9X8KwTukxnpX9DAU2',
        'Onofrio',
        'Pratesi',
        4,
        82,
        false
      );
    

      select public."insert_hut_worker"(
        89,
        'hutWorker82@gmail.com',
        '$2b$10$MPmWkDOMwS.geG/L4.sfluGaThXT5kE/9nMn7UM8gQUZEcCnrDCR6',
        'Raffaele',
        'Mecca',
        4,
        83,
        true
      );
    

      select public."insert_hut_worker"(
        90,
        'hutWorker83@gmail.com',
        '$2b$10$gmm2bVaaP6/tkPxuHHQwxOseg11ZvQADxUwc6HNojyFCaiBs/2CzW',
        'Giuditta',
        'Scopece',
        4,
        84,
        false
      );
    

      select public."insert_hut_worker"(
        91,
        'hutWorker84@gmail.com',
        '$2b$10$G5YH5K9JGg4c4p.Nqv5chu8vi0H/g27lQldkKW9Zz6.xcL4qNkb3W',
        'Rosanna',
        'Forconi',
        4,
        85,
        true
      );
    

      select public."insert_hut_worker"(
        92,
        'hutWorker85@gmail.com',
        '$2b$10$xOnpFS25zczaRJ2N18g0z.t2jvau3yrUfoBe6aLLNRUYBET39m7gG',
        'Eva',
        'Russo',
        4,
        86,
        false
      );
    

      select public."insert_hut_worker"(
        93,
        'hutWorker86@gmail.com',
        '$2b$10$2SAIqNv6oUtl3KzVGxISuuGvjbstZjPvy3kGsQKvlRKOaHCnudZ1S',
        'Mariano',
        'Granato',
        4,
        87,
        true
      );
    

      select public."insert_hut_worker"(
        94,
        'hutWorker87@gmail.com',
        '$2b$10$cZ2QEHyVkVApRiu8n/DrtOLPU0ua.3mjr3Pp.gbgr3PEHOt7jL.Oi',
        'Vladimiro',
        'Calabrese',
        4,
        88,
        false
      );
    

      select public."insert_hut_worker"(
        95,
        'hutWorker88@gmail.com',
        '$2b$10$LR4.HaHEgcYqnJc77w/B6uy1Fj5wee0bzc20wVRfOvZJQcN9EMyTK',
        'Geltrude',
        'Sabia',
        4,
        89,
        true
      );
    

      select public."insert_hut_worker"(
        96,
        'hutWorker89@gmail.com',
        '$2b$10$2nrAVW7vkOg/Yw8M1vESCepm76WpvPPO3Zv13n8lXzk93m0IhLCnK',
        'Gualberto',
        'De Bonis',
        4,
        90,
        false
      );
    

      select public."insert_hut_worker"(
        97,
        'hutWorker90@gmail.com',
        '$2b$10$q7uxEi92lXtOXyLbajkujeFoG8akAgneuit3gN2gq7RZ14rFFIsCy',
        'Deodata',
        'Bressan',
        4,
        91,
        true
      );
    

      select public."insert_hut_worker"(
        98,
        'hutWorker91@gmail.com',
        '$2b$10$mUykz7PZDG8or7F8OGUIBObxEDxBVQ.5GArmu/Jd5.yzoFrGbqFgO',
        'Omero',
        'Ferro',
        4,
        92,
        false
      );
    

      select public."insert_hut_worker"(
        99,
        'hutWorker92@gmail.com',
        '$2b$10$TqGxvlnzaLeoD239uphbtevXeV.jSd0xbanHFC0NxocICnvD/hcVW',
        'Ermenegilda',
        'Mura',
        4,
        93,
        true
      );
    

      select public."insert_hut_worker"(
        100,
        'hutWorker93@gmail.com',
        '$2b$10$zzhN922DYJ.CBtvIQMNBR.uiaO91E9GQKSF.GNPyUdwowNVom3/gi',
        'Severa',
        'Maugeri',
        4,
        94,
        false
      );
    

      select public."insert_hut_worker"(
        101,
        'hutWorker94@gmail.com',
        '$2b$10$GRqOT/JFFtSJZT75ZQiBK.voukT3/VRG2jf7aaE2sk5AKncaKSdq6',
        'Cosima',
        'Pizzuti',
        4,
        95,
        true
      );
    

      select public."insert_hut_worker"(
        102,
        'hutWorker95@gmail.com',
        '$2b$10$.TEhM11bxlGQmJdIql.pCe0z3GSPN3gluxIpZQSacYFZCrHAYGFdO',
        'Ruperto',
        'Balestra',
        4,
        96,
        false
      );
    

      select public."insert_hut_worker"(
        103,
        'hutWorker96@gmail.com',
        '$2b$10$2H5IjZarM03FTCR6Kt68ouDNHJL3xX1VXZmpZZ2EtLWyoUtbzqUTq',
        'Vespasiano',
        'Di Martino',
        4,
        97,
        true
      );
    

      select public."insert_hut_worker"(
        104,
        'hutWorker97@gmail.com',
        '$2b$10$WN7C4Zk7ZYJhUPxnhgGUkur8uH4MmJn6TQO24uib7nKq3wlWYm8vu',
        'Giacobbe',
        'Passarelli',
        4,
        98,
        false
      );
    

      select public."insert_hut_worker"(
        105,
        'hutWorker98@gmail.com',
        '$2b$10$T5i1dvAcibPtuS4fGshFF.ZWZt76K2wiKSbXOxT/SHVEMwo2v6wje',
        'Tolomeo',
        'Gusmeroli',
        4,
        99,
        true
      );
    

      select public."insert_hut_worker"(
        106,
        'hutWorker99@gmail.com',
        '$2b$10$qamx8mKTRY7ZedUgDwYEx.YmkefHoFA/3TrxpDJNJy3konxSZD7ju',
        'Filomena',
        'Gioacchini',
        4,
        100,
        false
      );
    

      select public."insert_hut_worker"(
        107,
        'hutWorker100@gmail.com',
        '$2b$10$zgJ5qUMF8OxYm.wCBt0bIu2ZckGAMt47jVvutTkpO7lW98g07UwLy',
        'Cleandro',
        'Spanu',
        4,
        101,
        true
      );
    

      select public."insert_hut_worker"(
        108,
        'hutWorker101@gmail.com',
        '$2b$10$z3WoI6pBVLfhPSXBfBC01uZqwVxfwlo2uOrYwlvaYWEJ9YmtCtli6',
        'Filippo',
        'Fiorentino',
        4,
        102,
        false
      );
    

      select public."insert_hut_worker"(
        109,
        'hutWorker102@gmail.com',
        '$2b$10$dGpamwsN7QhsPNwz2mmUD.k4usy4XA.6HqSYKtb26daK216SD6uC6',
        'Sidonio',
        'Margiotta',
        4,
        103,
        true
      );
    

      select public."insert_hut_worker"(
        110,
        'hutWorker103@gmail.com',
        '$2b$10$s926u71J5qEMojmT2mrYfeHLmtGLRFz/2/v5fmrT5xzyth3aBVGyy',
        'Lucia',
        'Iotti',
        4,
        104,
        false
      );
    

      select public."insert_hut_worker"(
        111,
        'hutWorker104@gmail.com',
        '$2b$10$P/TbxMEdb2wXEpfkd5WS5OZsJbZD3UQdL3SYeMhP4oG4UuasKeyAO',
        'Isacco',
        'Del Gaudio',
        4,
        105,
        true
      );
    

      select public."insert_hut_worker"(
        112,
        'hutWorker105@gmail.com',
        '$2b$10$NBoW4gkei.NXuIAFiusX5.Hc6W5kT5seHz.alzOhEr2OVtUb9E31i',
        'Giuditta',
        'Casadio',
        4,
        106,
        false
      );
    

      select public."insert_hut_worker"(
        113,
        'hutWorker106@gmail.com',
        '$2b$10$z6HFm49.lIHC3Fya2HT1Z.2GYIwf.X5B30cYxb7p1y3I52NDUWHu2',
        'Zenaide',
        'Pedrotti',
        4,
        107,
        true
      );
    

      select public."insert_hut_worker"(
        114,
        'hutWorker107@gmail.com',
        '$2b$10$V9D/Tvai/Qcq4/V0c3UzT.ULBdDZ/e9ssrN3ExZjrWsROxUqMRt3y',
        'Valeriana',
        'Lombardi',
        4,
        108,
        false
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '71 Strada Corsi, Quarto Batilda calabro, Italy',
        'Quarto Batilda calabro',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        169,
        '20 Borgo Spadaro, Borgo Ranolfo, Italy',
        'Borgo Ranolfo',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        299,
        '563 Borgo Fiammetta, Osmondo laziale, Italy',
        'Osmondo laziale',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        119,
        '0 Piazza Corti, Borgo Calogero del friuli, Italy',
        'Borgo Calogero del friuli',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        39,
        '385 Via Ione, Borgo Cristiano, Italy',
        'Borgo Cristiano',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        63,
        '08 Contrada Sanna, Quarto Luana, Italy',
        'Quarto Luana',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        54,
        '143 Rotonda Laurentino, Pircher a mare, Italy',
        'Pircher a mare',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        166,
        '54 Rotonda Serena, Giaccio sardo, Italy',
        'Giaccio sardo',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        155,
        '6 Incrocio Mauro, Butera ligure, Italy',
        'Butera ligure',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        98,
        '41 Rotonda Ermenegildo, Borgo Ulfo nell''emilia, Italy',
        'Borgo Ulfo nell''emilia',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        70,
        '6 Piazza Adalberto, Quarto Gionata, Italy',
        'Quarto Gionata',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        154,
        '997 Rotonda Marchetti, Borgo Elisa lido, Italy',
        'Borgo Elisa lido',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        38,
        '80 Incrocio Carini, Cerise sardo, Italy',
        'Cerise sardo',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        64,
        '120 Via Catania, Volpe del friuli, Italy',
        'Volpe del friuli',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        31,
        '103 Borgo Germana, Settimo Pammachio del friuli, Italy',
        'Settimo Pammachio del friuli',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        149,
        '9 Incrocio Trasea, Caserta nell''emilia, Italy',
        'Caserta nell''emilia',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        64,
        '89 Rotonda Pavan, Borgo Efisio, Italy',
        'Borgo Efisio',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        173,
        '484 Contrada Accardo, Sesto Bastiano salentino, Italy',
        'Sesto Bastiano salentino',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        73,
        '21 Rotonda Viale, Caiazza laziale, Italy',
        'Caiazza laziale',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        144,
        '497 Borgo Oggiano, Albano calabro, Italy',
        'Albano calabro',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        113,
        '93 Via Tornatore, Quarto Maurizio, Italy',
        'Quarto Maurizio',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        287,
        '9 Via Renzo, Sesto Ninfa, Italy',
        'Sesto Ninfa',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '767 Via Carini, Trasea laziale, Italy',
        'Trasea laziale',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        39,
        '940 Strada Adalfredo, Borgo Ottilia, Italy',
        'Borgo Ottilia',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        197,
        '231 Borgo Mazzotti, Borgo Floriana, Italy',
        'Borgo Floriana',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        158,
        '840 Rotonda Benigna, Sacchetti del friuli, Italy',
        'Sacchetti del friuli',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        274,
        '845 Incrocio Evangelisti, Settimo Fiorenziano, Italy',
        'Settimo Fiorenziano',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        248,
        '416 Piazza Frau, Antonella laziale, Italy',
        'Antonella laziale',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        95,
        '952 Contrada Desogus, Sesto Platone nell''emilia, Italy',
        'Sesto Platone nell''emilia',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        31,
        '3 Incrocio Pirrone, Vittore umbro, Italy',
        'Vittore umbro',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        148,
        '6 Piazza Lipari, Borgo Plutarco, Italy',
        'Borgo Plutarco',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        162,
        '3 Borgo Edvige, San Nestore terme, Italy',
        'San Nestore terme',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        83,
        '6 Incrocio Nestore, Borgo Vincenzo umbro, Italy',
        'Borgo Vincenzo umbro',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '76 Incrocio Gianni, Quarto Goffredo, Italy',
        'Quarto Goffredo',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        92,
        '8 Borgo Cucciniello, Settimo Smeralda, Italy',
        'Settimo Smeralda',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        208,
        '4 Incrocio Cozzani, Sesto Pancrazio terme, Italy',
        'Sesto Pancrazio terme',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        260,
        '222 Borgo Di Marzio, Silvestro veneto, Italy',
        'Silvestro veneto',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        248,
        '25 Contrada Cirilla, Benvenuti ligure, Italy',
        'Benvenuti ligure',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        270,
        '5 Borgo Monaci, Settimo Flaviana calabro, Italy',
        'Settimo Flaviana calabro',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        197,
        '798 Piazza Luongo, Asterio a mare, Italy',
        'Asterio a mare',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '46 Via Cavalli, Fernanda lido, Italy',
        'Fernanda lido',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        275,
        '6 Rotonda Verano, Riccio sardo, Italy',
        'Riccio sardo',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        56,
        '36 Incrocio Messalina, Delle Monache del friuli, Italy',
        'Delle Monache del friuli',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        217,
        '800 Borgo Cristiano, Valente veneto, Italy',
        'Valente veneto',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        240,
        '0 Borgo Torquato, Eva veneto, Italy',
        'Eva veneto',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        191,
        '110 Strada Zedda, Quarto Veronica, Italy',
        'Quarto Veronica',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        90,
        '52 Piazza Rosario, Fabiano lido, Italy',
        'Fabiano lido',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        117,
        '8 Incrocio Giusti, Onesto ligure, Italy',
        'Onesto ligure',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        273,
        '432 Incrocio Candela, Bianchini laziale, Italy',
        'Bianchini laziale',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        211,
        '998 Via Moira, Borgo Ettore del friuli, Italy',
        'Borgo Ettore del friuli',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        201,
        '1 Borgo Serapione, Settimo Solocone, Italy',
        'Settimo Solocone',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '77 Piazza Spiga, Quarto Guenda terme, Italy',
        'Quarto Guenda terme',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        126,
        '7 Piazza Elaide, Veridiana del friuli, Italy',
        'Veridiana del friuli',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '623 Borgo Uguccione, Gustavo ligure, Italy',
        'Gustavo ligure',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        128,
        '82 Strada Cerri, Borgo Alcibiade, Italy',
        'Borgo Alcibiade',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        227,
        '44 Rotonda Cavriani, Borgo Bonifacio veneto, Italy',
        'Borgo Bonifacio veneto',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        208,
        '33 Rotonda Cerrani, Quarto Gilberto lido, Italy',
        'Quarto Gilberto lido',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        251,
        '07 Borgo Polese, Settimo Prudenzia, Italy',
        'Settimo Prudenzia',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        74,
        '18 Incrocio Prudenzio, Lelia umbro, Italy',
        'Lelia umbro',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        59,
        '9 Rotonda Bertolini, Sesto Scolastica, Italy',
        'Sesto Scolastica',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        137,
        '16 Contrada Loreti, Leo veneto, Italy',
        'Leo veneto',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        283,
        '489 Contrada Mariotti, Lori lido, Italy',
        'Lori lido',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        120,
        '595 Via Stabile, Quarto Iolanda nell''emilia, Italy',
        'Quarto Iolanda nell''emilia',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        64,
        '55 Borgo Sepe, Gianmarco nell''emilia, Italy',
        'Gianmarco nell''emilia',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        131,
        '29 Via Flavio, Quarto Debora, Italy',
        'Quarto Debora',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        143,
        '585 Rotonda Boris, Amintore a mare, Italy',
        'Amintore a mare',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        135,
        '11 Contrada Granà, Biancheri ligure, Italy',
        'Biancheri ligure',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        263,
        '92 Contrada Fulgenzio, Emiliana ligure, Italy',
        'Emiliana ligure',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        48,
        '99 Piazza Doro, Matranga laziale, Italy',
        'Matranga laziale',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '912 Via Gigliotti, Borgo Fidenziano, Italy',
        'Borgo Fidenziano',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        47,
        '73 Strada Gedeone, Anselmo lido, Italy',
        'Anselmo lido',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        263,
        '6 Incrocio Salvucci, San Uriele terme, Italy',
        'San Uriele terme',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        265,
        '89 Contrada De Sanctis, Selvaggia umbro, Italy',
        'Selvaggia umbro',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        74,
        '69 Borgo Gertrude, Ampelio del friuli, Italy',
        'Ampelio del friuli',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        93,
        '59 Piazza Belvisi, Borgo Godeberta umbro, Italy',
        'Borgo Godeberta umbro',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        146,
        '080 Piazza Duilio, San Aleardo nell''emilia, Italy',
        'San Aleardo nell''emilia',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        27,
        '8 Contrada Anselmo, Quarto Matroniano, Italy',
        'Quarto Matroniano',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        72,
        '679 Strada Marchesan, Cesare salentino, Italy',
        'Cesare salentino',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        176,
        '9 Incrocio Adelfo, Borgo Uberto del friuli, Italy',
        'Borgo Uberto del friuli',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        94,
        '80 Borgo Teogene, San Gionata, Italy',
        'San Gionata',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        114,
        '67 Borgo Villani, Borgo Fiore, Italy',
        'Borgo Fiore',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        269,
        '083 Rotonda Averardo, Fernando del friuli, Italy',
        'Fernando del friuli',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        96,
        '258 Via Vidone, Politi a mare, Italy',
        'Politi a mare',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        170,
        '54 Via Fulberto, Amatore ligure, Italy',
        'Amatore ligure',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        228,
        '350 Incrocio Spadafora, Di Francesco salentino, Italy',
        'Di Francesco salentino',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        222,
        '25 Borgo Eleonora, Quarto Nadia del friuli, Italy',
        'Quarto Nadia del friuli',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        300,
        '3 Rotonda Onorio, San Maura terme, Italy',
        'San Maura terme',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        270,
        '763 Strada Paolo, Quarto Fosco, Italy',
        'Quarto Fosco',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        75,
        '138 Contrada Ivanoe, Sesto Matroniano, Italy',
        'Sesto Matroniano',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        116,
        '748 Piazza Indelicato, Frigerio salentino, Italy',
        'Frigerio salentino',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        70,
        '7 Borgo Corsi, Pellegrino lido, Italy',
        'Pellegrino lido',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        203,
        '24 Borgo Gusmeroli, Borgo Clodomiro, Italy',
        'Borgo Clodomiro',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        28,
        '463 Via Doda, San Tazio salentino, Italy',
        'San Tazio salentino',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        72,
        '7 Piazza Marano, Torresi terme, Italy',
        'Torresi terme',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        150,
        '000 Strada Ulpiano, Quarto Alessio ligure, Italy',
        'Quarto Alessio ligure',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        160,
        '84 Piazza Tina, Omar a mare, Italy',
        'Omar a mare',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        137,
        '04 Rotonda Pasini, Sesto Orsola, Italy',
        'Sesto Orsola',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        26,
        '11 Contrada Sempronio, Desdemona terme, Italy',
        'Desdemona terme',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        291,
        '3 Borgo Sigismondo, Settimo Rosalinda umbro, Italy',
        'Settimo Rosalinda umbro',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        208,
        '1 Via Paolo, Sesto Piergiorgio salentino, Italy',
        'Sesto Piergiorgio salentino',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        110,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        258,
        '110 Rotonda Procopio, Narciso laziale, Italy',
        'Narciso laziale',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        180,
        '397 Borgo Narsete, Peleo calabro, Italy',
        'Peleo calabro',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        26,
        '35 Rotonda Scalise, Sesto Rolfo, Italy',
        'Sesto Rolfo',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        187,
        '30 Piazza Consiglio, Sesto Graziano salentino, Italy',
        'Sesto Graziano salentino',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        178,
        '888 Via Medugno, Settimo Costante del friuli, Italy',
        'Settimo Costante del friuli',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        190,
        '107 Incrocio Pecora, Sesto Bardomiano, Italy',
        'Sesto Bardomiano',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        185,
        '3 Incrocio Boschetti, Lai umbro, Italy',
        'Lai umbro',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        63,
        '42 Rotonda Vulpiano, Settimo Almiro veneto, Italy',
        'Settimo Almiro veneto',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        81,
        '980 Incrocio Raniero, Borgo Stiriaco, Italy',
        'Borgo Stiriaco',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        37,
        '54 Piazza Grandi, San Radolfo sardo, Italy',
        'San Radolfo sardo',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        45,
        '087 Strada Saccone, Sesto Ivan, Italy',
        'Sesto Ivan',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        89,
        '950 Via Barbiero, Di Lecce lido, Italy',
        'Di Lecce lido',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        143,
        '828 Incrocio Virginio, Sibilla terme, Italy',
        'Sibilla terme',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        104,
        '66 Incrocio Paolo, Rocco calabro, Italy',
        'Rocco calabro',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        74,
        '0 Strada Calabrese, Murgia salentino, Italy',
        'Murgia salentino',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        130,
        '2 Rotonda Guiberto, San Fabio calabro, Italy',
        'San Fabio calabro',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        224,
        '732 Borgo Chiara, San Luminosa terme, Italy',
        'San Luminosa terme',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        233,
        '915 Via Romina, Sesto Arduino, Italy',
        'Sesto Arduino',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        69,
        '1 Incrocio Ippoliti, Auro terme, Italy',
        'Auro terme',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        136,
        '116 Via Vascotto, Quarto Vivaldo laziale, Italy',
        'Quarto Vivaldo laziale',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        266,
        '420 Borgo Grimaldi, Sesto Luciana umbro, Italy',
        'Sesto Luciana umbro',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        119,
        '677 Via Lentini, Borgo Amando, Italy',
        'Borgo Amando',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        149,
        '168 Via Mazzi, Gavino laziale, Italy',
        'Gavino laziale',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        230,
        '38 Rotonda Bove, Settimo Geminiano lido, Italy',
        'Settimo Geminiano lido',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        66,
        '414 Contrada Carrozza, Quarto Nina terme, Italy',
        'Quarto Nina terme',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '31 Borgo Violante, San Adelfo sardo, Italy',
        'San Adelfo sardo',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        35,
        '17 Via Sebastiano, Di Marzio nell''emilia, Italy',
        'Di Marzio nell''emilia',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        231,
        '664 Via Carletti, Adolfo a mare, Italy',
        'Adolfo a mare',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '679 Via Costanza, Settimo Addolorata, Italy',
        'Settimo Addolorata',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '65 Rotonda Isacco, Settimo Telchide, Italy',
        'Settimo Telchide',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        26,
        '45 Piazza Pastore, Romolo salentino, Italy',
        'Romolo salentino',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        104,
        '60 Incrocio Alceo, Di Giovanni sardo, Italy',
        'Di Giovanni sardo',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        176,
        '929 Contrada Matilde, Bellomo lido, Italy',
        'Bellomo lido',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        54,
        '50 Strada Urso, Lelia ligure, Italy',
        'Lelia ligure',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        100,
        '157 Incrocio Lieto, Settimo Girardo lido, Italy',
        'Settimo Girardo lido',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '9 Incrocio Fausto, San Orlando sardo, Italy',
        'San Orlando sardo',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '61 Piazza Blanc, Quarto Aleramo umbro, Italy',
        'Quarto Aleramo umbro',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        103,
        '0 Borgo Annagrazia, Sesto Auro terme, Italy',
        'Sesto Auro terme',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '434 Strada Cicchetti, San Artemisa, Italy',
        'San Artemisa',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        97,
        '5 Borgo Alberico, Luchetti sardo, Italy',
        'Luchetti sardo',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        37,
        '983 Contrada Bertaccini, Quarto Ulfa, Italy',
        'Quarto Ulfa',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        128,
        '38 Borgo Orfeo, Gerasimo sardo, Italy',
        'Gerasimo sardo',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        118,
        '9 Strada Fadda, Ausiliatrice salentino, Italy',
        'Ausiliatrice salentino',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        45,
        '24 Via Sammartino, Quarto Callisto nell''emilia, Italy',
        'Quarto Callisto nell''emilia',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        126,
        '67 Piazza Davoli, Cecchetti terme, Italy',
        'Cecchetti terme',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        246,
        '630 Piazza Donata, Borgo Platone, Italy',
        'Borgo Platone',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        153,
        '253 Borgo Ranieri, De Marco laziale, Italy',
        'De Marco laziale',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        168,
        '38 Piazza Iorio, Carloni del friuli, Italy',
        'Carloni del friuli',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        212,
        '7 Borgo Caricari, Settimo Prudenzio sardo, Italy',
        'Settimo Prudenzio sardo',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        277,
        '27 Borgo Famiano, Settimo Emmerico laziale, Italy',
        'Settimo Emmerico laziale',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        48,
        '02 Incrocio Remo, Settimo Luminosa, Italy',
        'Settimo Luminosa',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        208,
        '8 Incrocio Velio, Litterio umbro, Italy',
        'Litterio umbro',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        139,
        '6 Via Sviturno, Settimo Eufebio umbro, Italy',
        'Settimo Eufebio umbro',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        155,
        '531 Contrada Menconi, Quarto Consolata sardo, Italy',
        'Quarto Consolata sardo',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        48,
        '028 Via Oderico, Borgo Eleuterio, Italy',
        'Borgo Eleuterio',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        191,
        '148 Rotonda Alessandra, Cleopatra nell''emilia, Italy',
        'Cleopatra nell''emilia',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        77,
        '45 Via Cataldi, San Carlo, Italy',
        'San Carlo',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        260,
        '29 Strada Orenzio, Quarto Porzia, Italy',
        'Quarto Porzia',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        272,
        '9 Piazza Nappi, Baldassarre ligure, Italy',
        'Baldassarre ligure',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        179,
        '34 Piazza Urbano, Quarto Candida terme, Italy',
        'Quarto Candida terme',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        124,
        '290 Incrocio Bologna, Borgo Furio, Italy',
        'Borgo Furio',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        78,
        '4 Incrocio Balestra, Miglio lido, Italy',
        'Miglio lido',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        138,
        '922 Strada Butera, Coreno salentino, Italy',
        'Coreno salentino',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        223,
        '1 Incrocio Giorgia, Tacconi del friuli, Italy',
        'Tacconi del friuli',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '68 Borgo Giovanna, San Edvige umbro, Italy',
        'San Edvige umbro',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        226,
        '11 Incrocio Corazza, Sesto Casto, Italy',
        'Sesto Casto',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        270,
        '59 Contrada Ciani, San Zabina veneto, Italy',
        'San Zabina veneto',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        246,
        '52 Strada Rollo, Lo Bianco calabro, Italy',
        'Lo Bianco calabro',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        180,
        '1 Piazza Ancilla, Settimo Rufo, Italy',
        'Settimo Rufo',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        279,
        '84 Via Crea, Pani laziale, Italy',
        'Pani laziale',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        297,
        '608 Piazza Beniamino, Borgo Gianpaolo, Italy',
        'Borgo Gianpaolo',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        271,
        '0 Piazza Golinelli, San Sidonio, Italy',
        'San Sidonio',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        174,
        '85 Rotonda Corinna, San Virginio del friuli, Italy',
        'San Virginio del friuli',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        42,
        '95 Piazza Carrozza, Indro sardo, Italy',
        'Indro sardo',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        95,
        '42 Rotonda Ciuffreda, Fortugno ligure, Italy',
        'Fortugno ligure',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        111,
        '10 Rotonda Narciso, Preziosi lido, Italy',
        'Preziosi lido',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        192,
        '1 Strada Colangelo, San Mario, Italy',
        'San Mario',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        176,
        '5 Incrocio Aquino, Quarto Pacomio laziale, Italy',
        'Quarto Pacomio laziale',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        63,
        '6 Borgo Ester, Cusumano lido, Italy',
        'Cusumano lido',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        294,
        '8 Piazza Buongiorno, Quarto Barbara, Italy',
        'Quarto Barbara',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        275,
        '417 Strada Indro, Gigliola lido, Italy',
        'Gigliola lido',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '7 Borgo Parodi, Volpe nell''emilia, Italy',
        'Volpe nell''emilia',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        184,
        '95 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        75,
        '560 Rotonda Liverani, San Martina veneto, Italy',
        'San Martina veneto',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        295,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        102,
        '6 Piazza Enzo, Settimo Sofronia calabro, Italy',
        'Settimo Sofronia calabro',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        115,
        '560 Via Corazza, Venerando calabro, Italy',
        'Venerando calabro',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        230,
        '115 Piazza Indelicato, Quarto Bonaventura sardo, Italy',
        'Quarto Bonaventura sardo',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        273,
        '110 Contrada Icaro, San Manilio del friuli, Italy',
        'San Manilio del friuli',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        47,
        '079 Incrocio Destro, Grassi del friuli, Italy',
        'Grassi del friuli',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        209,
        '03 Contrada Gianpaolo, Marini salentino, Italy',
        'Marini salentino',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        223,
        '99 Via Ascanio, Sesto Annabella laziale, Italy',
        'Sesto Annabella laziale',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        244,
        '51 Contrada Perseo, San Zenone, Italy',
        'San Zenone',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        243,
        '0 Rotonda Quieta, Lazzari del friuli, Italy',
        'Lazzari del friuli',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        40,
        '5 Rotonda Taddei, Paterniano calabro, Italy',
        'Paterniano calabro',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        243,
        '195 Rotonda Martino, Leonida nell''emilia, Italy',
        'Leonida nell''emilia',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        217,
        '801 Contrada Satta, Glenda lido, Italy',
        'Glenda lido',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        251,
        '85 Contrada Raimondo, San Sviturno, Italy',
        'San Sviturno',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        126,
        '5 Rotonda Martina, Remigio umbro, Italy',
        'Remigio umbro',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        118,
        '96 Strada Delogu, Guida sardo, Italy',
        'Guida sardo',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        252,
        '78 Strada Carella, Sesto Furseo, Italy',
        'Sesto Furseo',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '47 Borgo Mario, Ulfo terme, Italy',
        'Ulfo terme',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        212,
        '10 Rotonda Capoccia, Settimo Flaviana umbro, Italy',
        'Settimo Flaviana umbro',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        84,
        '00 Strada Giulio, Sesto Scolastica laziale, Italy',
        'Sesto Scolastica laziale',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        39,
        '3 Contrada Pagliuca, San Iginio terme, Italy',
        'San Iginio terme',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        119,
        '6 Rotonda Maggiore, Pisciotta veneto, Italy',
        'Pisciotta veneto',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        227,
        '2 Borgo Casto, Serapione sardo, Italy',
        'Serapione sardo',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        121,
        '22 Borgo Agnese, Sesto Porziano lido, Italy',
        'Sesto Porziano lido',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        110,
        '62 Incrocio Radolfo, Schiavo calabro, Italy',
        'Schiavo calabro',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        269,
        '3 Piazza Lazzari, Sesto Lapo ligure, Italy',
        'Sesto Lapo ligure',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        109,
        '57 Contrada Fiorini, Manca a mare, Italy',
        'Manca a mare',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '05 Via Gagliano, Melchiorre veneto, Italy',
        'Melchiorre veneto',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        215,
        '9 Strada Signorelli, Mirella sardo, Italy',
        'Mirella sardo',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        194,
        '8 Borgo Elettra, Ghilardi terme, Italy',
        'Ghilardi terme',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        139,
        '72 Rotonda Malatesta, Sesto Alvise veneto, Italy',
        'Sesto Alvise veneto',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        213,
        '074 Via Boscaino, Cabras a mare, Italy',
        'Cabras a mare',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        286,
        '981 Strada Ariele, San Fiorenza laziale, Italy',
        'San Fiorenza laziale',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        157,
        '750 Rotonda Cavaliere, Borgo Demetrio ligure, Italy',
        'Borgo Demetrio ligure',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        84,
        '1 Piazza Giambattista, Michelucci del friuli, Italy',
        'Michelucci del friuli',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        297,
        '36 Incrocio Leonida, Gualtieri laziale, Italy',
        'Gualtieri laziale',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '150 Rotonda Cancellieri, Settimo Samanta sardo, Italy',
        'Settimo Samanta sardo',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        214,
        '07 Via Fabbricatore, Settimo Ampelio, Italy',
        'Settimo Ampelio',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        233,
        '98 Rotonda Luigi, Di Maro salentino, Italy',
        'Di Maro salentino',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        161,
        '8 Strada Siciliano, Godeberta ligure, Italy',
        'Godeberta ligure',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        166,
        '95 Strada Ciccarelli, Sesto Amerigo, Italy',
        'Sesto Amerigo',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        220,
        '26 Borgo Navarra, San Catullo, Italy',
        'San Catullo',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        253,
        '729 Rotonda Testa, Dolce ligure, Italy',
        'Dolce ligure',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        250,
        '315 Rotonda Piccione, Edda salentino, Italy',
        'Edda salentino',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        104,
        '525 Incrocio Pibiri, Simoni lido, Italy',
        'Simoni lido',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        269,
        '66 Strada Mantovani, Sesto Camilla, Italy',
        'Sesto Camilla',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        212,
        '099 Rotonda Mari, Demurtas sardo, Italy',
        'Demurtas sardo',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        298,
        '4 Incrocio Crea, Alamanno a mare, Italy',
        'Alamanno a mare',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        243,
        '0 Rotonda Chiacchio, Diana umbro, Italy',
        'Diana umbro',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        29,
        '0 Strada Nerea, Sesto Nina umbro, Italy',
        'Sesto Nina umbro',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        235,
        '19 Incrocio Santarelli, Sesto Cristoforo ligure, Italy',
        'Sesto Cristoforo ligure',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        143,
        '6 Piazza Santarelli, Barbato nell''emilia, Italy',
        'Barbato nell''emilia',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        61,
        '78 Rotonda Bonazzi, Olivi umbro, Italy',
        'Olivi umbro',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        74,
        '36 Contrada Grange, Quarto Cristaldo, Italy',
        'Quarto Cristaldo',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        233,
        '00 Via Malaspina, San Alcide, Italy',
        'San Alcide',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        184,
        '6 Via Bertolini, Oliviero salentino, Italy',
        'Oliviero salentino',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        77,
        '14 Piazza Serena, Quarto Venusto umbro, Italy',
        'Quarto Venusto umbro',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        80,
        '957 Via Abenzio, Boni veneto, Italy',
        'Boni veneto',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        183,
        '9 Piazza Panetta, Quarto Desdemona veneto, Italy',
        'Quarto Desdemona veneto',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        101,
        '0 Incrocio Dario, Brigandì sardo, Italy',
        'Brigandì sardo',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        237,
        '547 Contrada Ismaele, Sesto Evangelina, Italy',
        'Sesto Evangelina',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        139,
        '07 Borgo Fischetti, Sesto Giustiniano umbro, Italy',
        'Sesto Giustiniano umbro',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        114,
        '157 Via Ciulla, Saffiro a mare, Italy',
        'Saffiro a mare',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        286,
        '476 Via Corrado, Settimo Giusta, Italy',
        'Settimo Giusta',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '473 Strada Medardo, Gianotti sardo, Italy',
        'Gianotti sardo',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        275,
        '5 Incrocio Zanon, Egisto nell''emilia, Italy',
        'Egisto nell''emilia',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        48,
        '8 Via Gioele, Dafne salentino, Italy',
        'Dafne salentino',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        124,
        '02 Incrocio Graziella, San Riccarda salentino, Italy',
        'San Riccarda salentino',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        231,
        '396 Piazza Edilberto, Quarto Icilio, Italy',
        'Quarto Icilio',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        263,
        '022 Piazza Sosteneo, San Elita a mare, Italy',
        'San Elita a mare',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        238,
        '167 Borgo Isidoro, Sesto Fabiana, Italy',
        'Sesto Fabiana',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    
  