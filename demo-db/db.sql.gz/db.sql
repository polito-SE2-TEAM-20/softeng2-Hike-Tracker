--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: insert_hut(integer, double precision, double precision, integer, numeric, character varying, character varying, character varying, character varying, numeric, time without time zone, time without time zone, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut(user_id integer, lat double precision, lon double precision, number_of_beds integer, price numeric, title character varying, address character varying, owner_name character varying, website character varying, elevation numeric, workingtimestart time without time zone, workingtimeend time without time zone, email character varying, phonenumber character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation
    );
    END
    $$;


--
-- Name: insert_parking_lot(integer, double precision, double precision, character varying, integer, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_parking_lot(user_id integer, lat double precision, lon double precision, name character varying, max_cars integer, address character varying, city character varying, country character varying, region character varying, province character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2)
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country, condition, cause, pictures) FROM stdin;
\.


--
-- Data for Name: hut-worker; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."hut-worker" ("userId", "hutId") FROM stdin;
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website, elevation, pictures, description, "workingTimeStart", "workingTimeEnd", "phoneNumber", email) FROM stdin;
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
1	1	72	2	Italy	Prato		Govoni ligure
2	2	158	2	Italy	Lecce		Liborio del friuli
3	3	224	2	Italy	Bolzano		Cesaretti nell'emilia
4	4	260	2	Italy	Lodi		Sesto Monaldo
5	5	273	2	Italy	Oristano		Fiordaliso terme
6	6	38	2	Italy	Firenze		Calabrese umbro
7	7	189	2	Italy	Genova		Antelmo umbro
8	8	104	2	Italy	Varese		Settimo Bonifacio umbro
9	9	47	2	Italy	Novara		Borgo Manuele terme
10	10	121	2	Italy	Lecce		Barletta laziale
11	11	214	2	Italy	Sassari		Sesto Alamanno
12	12	87	2	Italy	Massa-Carrara		Ruggiero nell'emilia
13	13	59	2	Italy	Arezzo		Biagio ligure
14	14	28	2	Italy	Pordenone		Settimo Rinaldo calabro
15	15	176	2	Italy	Medio Campidano		Asella a mare
16	16	174	2	Italy	L'Aquila		Cora ligure
17	17	255	2	Italy	Campobasso		Alcibiade del friuli
18	18	285	2	Italy	Padova		Borgo Iride
19	19	109	2	Italy	Pesaro e Urbino		San Ada nell'emilia
20	20	194	2	Italy	Benevento		Quarto Pia
21	21	99	2	Italy	Verona		Settimo Ippolito
22	22	284	2	Italy	Lecce		Sesto Arduino
23	23	6	2	Italy	Aosta		Gigli salentino
24	24	118	2	Italy	Savona		Sesto Giorgia
25	25	89	2	Italy	Lecce		Sesto Clemente ligure
26	26	175	2	Italy	Livorno		San Orlando calabro
27	27	156	2	Italy	Benevento		Zordan ligure
28	28	264	2	Italy	Treviso		Agape calabro
29	29	91	2	Italy	Pistoia		Maffeo sardo
30	30	32	2	Italy	Como		Borgo Ambra calabro
31	31	48	2	Italy	Arezzo		Settimo Fernanda
32	32	123	2	Italy	Bologna		Borgo Tulliano
33	33	213	2	Italy	Ogliastra		Concordio del friuli
34	34	5	2	Italy	Bergamo		Gautiero sardo
35	35	229	2	Italy	Alessandria		De Rosa sardo
36	36	135	2	Italy	Prato		Finotti nell'emilia
37	37	126	2	Italy	Trieste		San Cosimo umbro
38	38	278	2	Italy	Benevento		Settimo Anacleto
39	39	239	2	Italy	Sondrio		Santarsia terme
40	40	232	2	Italy	Oristano		De Martino laziale
41	41	20	2	Italy	Torino		Borgo Tiziana nell'emilia
42	42	151	2	Italy	Reggio Emilia		Quarto Climaco lido
43	43	230	2	Italy	Rovigo		Doriano del friuli
44	44	286	2	Italy	Novara		Quarto Valfrido
45	45	89	2	Italy	Ravenna		Gatta lido
46	46	65	2	Italy	Potenza		Zabedeo calabro
47	47	167	2	Italy	Torino		San Aiace calabro
48	48	67	2	Italy	Brescia		Piga lido
49	49	282	2	Italy	Lecco		Sesto Virginia salentino
50	50	152	2	Italy	Barletta-Andria-Trani		Lombardi nell'emilia
51	51	242	2	Italy	Caserta		Donato nell'emilia
52	52	11	2	Italy	Fermo		Telesca salentino
53	53	148	2	Italy	Pescara		San Eufronio sardo
54	54	8	2	Italy	Trento		Settimo Cassio
55	55	221	2	Italy	Mantova		Innocente nell'emilia
56	56	271	2	Italy	Parma		Tagliabue del friuli
57	57	126	2	Italy	Matera		Pellicanò terme
58	58	224	2	Italy	Bergamo		Rocchi salentino
59	59	245	2	Italy	Forlì-Cesena		Sesto Unna laziale
60	60	54	2	Italy	Palermo		Gianluca a mare
61	61	274	2	Italy	Arezzo		Quarto Paola terme
62	62	97	2	Italy	Livorno		Mautone salentino
63	63	193	2	Italy	Latina		Denaro calabro
64	64	52	2	Italy	Caltanissetta		Evaristo terme
65	65	44	2	Italy	Brindisi		San Atanasio ligure
66	66	267	2	Italy	Brindisi		Ferranti lido
67	67	114	2	Italy	Brindisi		Sesto Gundelinda
68	68	241	2	Italy	Teramo		San Doda
69	69	163	2	Italy	Caltanissetta		Pappalardo lido
70	70	15	2	Italy	Vicenza		Amanda ligure
71	71	172	2	Italy	Latina		Lorenzini a mare
72	72	45	2	Italy	Ferrara		Virone calabro
73	73	78	2	Italy	Campobasso		Quarto Irene
74	74	52	2	Italy	Bologna		Aris veneto
75	75	222	2	Italy	Lecco		Settimo Piersilvio calabro
76	76	232	2	Italy	Rimini		Simeti salentino
77	77	286	2	Italy	Cremona		Murru ligure
78	78	183	2	Italy	Palermo		San Alberico del friuli
79	79	78	2	Italy	Vibo Valentia		Albano a mare
80	80	290	2	Italy	Belluno		Settimo Mina
81	81	45	2	Italy	Catanzaro		Bernardi calabro
82	82	229	2	Italy	La Spezia		Didimo terme
83	83	156	2	Italy	Udine		Ione laziale
84	84	229	2	Italy	Genova		Sesto Indro
85	85	272	2	Italy	Arezzo		Allegretti salentino
86	86	103	2	Italy	Cosenza		Borgo Zaira
87	87	188	2	Italy	Catanzaro		Sesto Alarico
88	88	272	2	Italy	Pisa		Almiro a mare
89	89	123	2	Italy	Foggia		Sesto Climaco
90	90	211	2	Italy	Enna		Famiano nell'emilia
91	91	145	2	Italy	Trento		Erberto laziale
92	92	291	2	Italy	Viterbo		Diana calabro
93	93	215	2	Italy	Siena		Quarto Eugenia
94	94	187	2	Italy	Ogliastra		Quarto Quartilla del friuli
95	95	216	2	Italy	Massa-Carrara		Feliciano lido
96	96	219	2	Italy	Foggia		Demetrio laziale
97	97	173	2	Italy	Enna		Sesto Romano terme
98	98	119	2	Italy	Isernia		San Ludovica
99	99	129	2	Italy	Cuneo		Cicala sardo
100	100	286	2	Italy	La Spezia		Borgo Danio
101	101	87	2	Italy	Livorno		Roma
102	102	105	2	Italy	Varese		Schettino umbro
103	103	154	2	Italy	Agrigento		Giraudo nell'emilia
104	104	55	2	Italy	Arezzo		Giustra umbro
105	105	245	2	Italy	Lucca		Musso del friuli
106	106	237	2	Italy	Chieti		Lazzarini veneto
107	107	187	2	Italy	Palermo		Borgo Eusebio terme
108	108	297	2	Italy	Cremona		Eufebio calabro
109	109	124	2	Italy	Pordenone		Eva ligure
110	110	118	2	Italy	Benevento		De Luca sardo
111	111	30	2	Italy	Sassari		Sesto Giusto
112	112	108	2	Italy	Modena		Pozzi salentino
113	113	212	2	Italy	Siena		San Galdino
114	114	60	2	Italy	Imperia		Mario veneto
115	115	36	2	Italy	Vicenza		Maio lido
116	116	170	2	Italy	Firenze		Salierno umbro
117	117	159	2	Italy	Salerno		Dora sardo
118	118	125	2	Italy	Vicenza		Crespignano calabro
119	119	74	2	Italy	Vicenza		San Saturniano sardo
120	120	65	2	Italy	Reggio Calabria		Adalberta laziale
121	121	123	2	Italy	Belluno		Pavone a mare
122	122	213	2	Italy	Gorizia		Epifani salentino
123	123	97	2	Italy	Pordenone		Viliberto umbro
124	124	257	2	Italy	Ancona		Sara veneto
125	125	215	2	Italy	Trapani		Borgo Asdrubale laziale
126	126	272	2	Italy	Fermo		Tammaro umbro
127	127	1	2	Italy	Sassari		Rampazzo laziale
128	128	155	2	Italy	Enna		Torrisi lido
129	129	161	2	Italy	Arezzo		San Isa sardo
130	130	1	2	Italy	Ascoli Piceno		Sesto Acacio calabro
131	131	1	2	Italy	Barletta-Andria-Trani		Diamante lido
132	132	251	2	Italy	Frosinone		Quarto Adamo
133	133	34	2	Italy	Perugia		San Lidania
134	134	293	2	Italy	Trento		Settimo Gianmaria salentino
135	135	291	2	Italy	Ogliastra		Sesto Messalina
136	136	196	2	Italy	Cuneo		Bertolussi lido
137	137	1	2	Italy	Perugia		Settimo Delfina
138	138	1	2	Italy	La Spezia		San Romola
139	139	274	2	Italy	Novara		Benvenuti a mare
140	140	1	2	Italy	Frosinone		Sesto Nestore
141	141	294	2	Italy	Ferrara		Borgo Ferruccio
142	142	142	2	Italy	Catania		Monticelli del friuli
143	143	58	2	Italy	Ferrara		Bernabei lido
144	144	185	2	Italy	Arezzo		Quarto Ildegarda
145	145	259	2	Italy	Perugia		Matarazzo lido
146	146	286	2	Italy	Avellino		Borgo Innocenzo ligure
147	147	218	2	Italy	Vibo Valentia		Curci sardo
148	148	79	2	Italy	Foggia		San Gilda
149	149	183	2	Italy	Udine		De Carolis umbro
150	150	233	2	Italy	Asti		Cristiana lido
151	151	257	2	Italy	Verona		Amato umbro
152	152	271	2	Italy	Bari		Sesto Aristeo veneto
153	153	192	2	Italy	Piacenza		Sesto Saffiro
154	154	241	2	Italy	Oristano		Borgo Eufebio lido
155	155	133	2	Italy	Mantova		Medugno umbro
156	156	116	2	Italy	Trieste		Eloisa veneto
157	157	125	2	Italy	Novara		Papini a mare
158	158	117	2	Italy	Trieste		San Glenda lido
159	159	176	2	Italy	Ravenna		Corazza salentino
160	160	58	2	Italy	Catanzaro		Borgo Bruno
161	161	86	2	Italy	Padova		Boschi veneto
162	162	84	2	Italy	Vercelli		Borgo Namazio
163	163	132	2	Italy	Brindisi		San Adriano
164	164	300	2	Italy	Chieti		San Zetico
165	165	95	2	Italy	Livorno		Sesto Ermete lido
166	166	30	2	Italy	Catania		Quarto Godeberta del friuli
167	167	68	2	Italy	Piacenza		Emma a mare
168	168	44	2	Italy	Avellino		Moscato terme
169	169	260	2	Italy	Caltanissetta		Di Fiore del friuli
170	170	272	2	Italy	Pavia		Marciano terme
171	171	196	2	Italy	Gorizia		Annamaria terme
172	172	121	2	Italy	Vibo Valentia		San Paola
173	173	30	2	Italy	Medio Campidano		Bordoni veneto
174	174	47	2	Italy	Avellino		Beltrame lido
175	175	269	2	Italy	Udine		Settimo Respicio
176	176	95	2	Italy	Trieste		San Neopolo
177	177	158	2	Italy	Trieste		Galdino nell'emilia
178	178	182	2	Italy	Taranto		Quarto Dorotea laziale
179	179	120	2	Italy	Genova		Silvestro terme
180	180	225	2	Italy	Venezia		Clara veneto
181	181	274	2	Italy	Aosta		De Col a mare
182	182	206	2	Italy	Crotone		Sesto Ursicio umbro
183	183	6	2	Italy	Lodi		Lorena salentino
184	184	177	2	Italy	Caserta		Lendinara
185	185	64	2	Italy	Trapani		Quarto Alfio lido
186	186	226	2	Italy	Potenza		Napoli
187	187	137	2	Italy	Asti		Settimo Richelmo
188	188	83	2	Italy	Pavia		Ballarin laziale
189	189	211	2	Italy	Siena		Prete nell'emilia
190	190	78	2	Italy	Pescara		Mautone umbro
191	191	59	2	Italy	Padova		Settimo Adalfredo
192	192	116	2	Italy	Sassari		Borgo Galeazzo
193	193	111	2	Italy	Rimini		Vitalico nell'emilia
194	194	102	2	Italy	Terni		Sigismondo lido
195	195	294	2	Italy	Belluno		Settimo Everardo
196	196	28	2	Italy	Grosseto		Ugolini sardo
197	197	34	2	Italy	Ragusa		Borgo Minervino umbro
198	198	101	2	Italy	Teramo		Fernanda sardo
199	199	225	2	Italy	Belluno		Godeberta lido
200	200	245	2	Italy	Biella		Terenzi salentino
201	201	273	2	Italy	Oristano		San Prassede terme
202	202	96	2	Italy	Catania		Flacco umbro
203	203	410	2	Italy	Modena		Iannello veneto
204	204	192	2	Italy	Catanzaro		Settimo Vinfrido
205	205	119	2	Italy	Gorizia		Foschi veneto
206	206	247	2	Italy	Rimini		Bonanni lido
207	207	122	2	Italy	Aosta		Moreno laziale
208	208	282	2	Italy	Rieti		Amanda sardo
209	209	226	2	Italy	Biella		Sottile nell'emilia
210	210	277	2	Italy	Latina		Loreto veneto
211	211	224	2	Italy	Teramo		Sesto Gastone
212	212	131	2	Italy	Pescara		Borgo Grazia
213	213	9	2	Italy	Lodi		Settimo Orsino del friuli
214	214	143	2	Italy	Salerno		Torrisi laziale
215	215	199	2	Italy	Biella		Santo laziale
216	216	33	2	Italy	Forlì-Cesena		Amadori del friuli
217	217	286	2	Italy	Vicenza		Zappia sardo
218	218	273	2	Italy	Campobasso		Settimo Turi
219	219	155	2	Italy	Bolzano		Veronese salentino
220	220	92	2	Italy	Oristano		Ivano veneto
221	221	104	2	Italy	Siracusa		Borgo Ermenegarda
222	222	3	2	Italy	Matera		Borgo Filiberto
223	223	83	2	Italy	Modena		Settimo Gillo veneto
224	224	286	2	Italy	Napoli		Sesto Vala salentino
225	225	54	2	Italy	Rieti		Quarto Mirta
226	226	96	2	Italy	Foggia		Settimo Tullia nell'emilia
227	227	163	2	Italy	Torino		Palumbo veneto
228	228	207	2	Italy	Biella		Settimo Ludovica
229	229	266	2	Italy	Teramo		Di Iorio lido
230	230	132	2	Italy	Frosinone		Borgo Raimondo
231	231	94	2	Italy	Macerata		Chiaravalle sardo
232	232	191	2	Italy	Ascoli Piceno		Sesto Gianpietro laziale
233	233	187	2	Italy	Ancona		Quarto Telemaco salentino
234	234	223	2	Italy	Pesaro e Urbino		Marrazzo ligure
235	235	243	2	Italy	La Spezia		Sesto Libero
236	236	97	2	Italy	Savona		Santoro laziale
237	237	257	2	Italy	Nuoro		Marani del friuli
238	238	270	2	Italy	Monza e della Brianza		Sisto sardo
239	239	105	2	Italy	Aosta		Zambon a mare
240	240	90	2	Italy	Avellino		Borgo Fosco
241	241	140	2	Italy	Viterbo		Aza terme
242	242	25	2	Italy	Bologna		San Sostrato
243	243	168	2	Italy	Parma		Quarto Noemi
244	244	123	2	Italy	Salerno		San Elsa
245	245	212	2	Italy	Genova		Settimo Selene del friuli
246	246	28	2	Italy	Alessandria		Quarto Cleopatra salentino
247	247	139	2	Italy	Vicenza		Licitra ligure
248	248	94	2	Italy	Novara		Settimo Bassiano ligure
249	249	127	2	Italy	Cosenza		Saffo ligure
250	250	9	2	Italy	Savona		Settimo Vodingo
251	251	152	2	Italy	Caserta		Sesto Ursino
252	252	130	2	Italy	Fermo		Fratello a mare
253	253	228	2	Italy	Forlì-Cesena		Tarsilla a mare
254	254	235	2	Italy	Cremona		Sesto Edilberto a mare
255	255	65	2	Italy	Piacenza		Quarto Leopardo lido
256	256	278	2	Italy	Napoli		Gianotti a mare
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address, altitude) FROM stdin;
1	0	0101000020E6100000AD3BCC4D8A7D2840CBDF185D39124640		0 Via Dacio, Govoni ligure, Italy	\N
2	0	0101000020E6100000AF5E454607602340EDF2AD0FEB6B4440		418 Rotonda Romanini, Liborio del friuli, Italy	\N
3	0	0101000020E610000050BA3EBD63AA2840D5DBB0B7DE294640		679 Borgo Pastorino, Cesaretti nell'emilia, Italy	\N
4	0	0101000020E6100000E7204322C8042640F6AEE6A507F54540		261 Rotonda Duccio, Sesto Monaldo, Italy	\N
5	0	0101000020E61000009F11B6E919B02140ABAC12D154364640		25 Rotonda Vitale, Fiordaliso terme, Italy	\N
6	0	0101000020E61000009EBFBFF7ED2224402DAAEA8ABEE84640		0 Contrada Dina, Calabrese umbro, Italy	\N
7	0	0101000020E6100000FF209221C76E274017844DF8002D4640		785 Strada Mancio, Antelmo umbro, Italy	\N
8	0	0101000020E6100000C2B28817FA8E2340D5809C8B1AB04640		732 Rotonda Corrado, Settimo Bonifacio umbro, Italy	\N
9	0	0101000020E6100000107BFC3960762540600A6A53D0274740		06 Strada Riparbelli, Borgo Manuele terme, Italy	\N
10	0	0101000020E6100000CF5AC0BAE0462B40B9ED314745E34640		5 Borgo Chessari, Barletta laziale, Italy	\N
11	0	0101000020E610000048B42E7FCFC525403379B93E620B4740		767 Strada Bartolucci, Sesto Alamanno, Italy	\N
12	0	0101000020E6100000E066F16261B42A4084E85AC52CF04640		15 Via D'Orazio, Ruggiero nell'emilia, Italy	\N
13	0	0101000020E610000021263CFC90E62840C604EBEEF0074640		590 Incrocio Favero, Biagio ligure, Italy	\N
14	0	0101000020E6100000CFB81567B161274070CFF3A78DA74640		05 Via Simula, Settimo Rinaldo calabro, Italy	\N
15	0	0101000020E6100000C1F979F8D76F224054F0CAE48AB04640		64 Piazza Giovanna, Asella a mare, Italy	\N
16	0	0101000020E61000008248D0A975782B40741200D2EDC94640		1 Piazza Iannone, Cora ligure, Italy	\N
17	0	0101000020E6100000918B208436172940630E828E564E4540		02 Borgo Carli, Alcibiade del friuli, Italy	\N
18	0	0101000020E610000023484A1F5F572240D37CDF09072C4640		5 Strada Castiello, Borgo Iride, Italy	\N
19	0	0101000020E6100000A09339F130542140F7DBE8ADCB384740		952 Borgo Cirino, San Ada nell'emilia, Italy	\N
20	0	0101000020E6100000068A0E37967A2540DB1FDE29D3664540		43 Contrada Raniolo, Quarto Pia, Italy	\N
21	0	0101000020E6100000CF59B09EA4CE2640F18288D4B4434740		55 Incrocio Tesauro, Settimo Ippolito, Italy	\N
22	0	0101000020E6100000C153C8957A5A26407541D8840FE14640		257 Borgo Talarico, Sesto Arduino, Italy	\N
23	0	0101000020E61000008577B988EF302140BAD3426E2B3D4740		1 Rotonda Favre, Gigli salentino, Italy	\N
24	0	0101000020E6100000589643E6259E2540B49487E013DD4540		7 Piazza Babila, Sesto Giorgia, Italy	\N
25	0	0101000020E6100000249E4720B9702840B1F84D61A5124640		36 Rotonda Alberti, Sesto Clemente ligure, Italy	\N
26	0	0101000020E61000008B89CDC7B55926407EB4EED57D084740		80 Contrada Baroni, San Orlando calabro, Italy	\N
27	0	0101000020E6100000D8B969334EEB27402CF8C84164804540		7 Piazza Galeazzo, Zordan ligure, Italy	\N
28	0	0101000020E610000061D394AEAAD4204012A6835039FC4640		0 Strada Cabras, Agape calabro, Italy	\N
29	0	0101000020E6100000B53C6AA741AC27408F0134A550B84640		271 Rotonda Garimberto, Maffeo sardo, Italy	\N
30	0	0101000020E6100000F78CE9AE91D52240ED48F59D5FE54640		09 Strada Leda, Borgo Ambra calabro, Italy	\N
31	0	0101000020E6100000626DE75663902B4097FA1E9A1ED44640		58 Contrada Magnani, Settimo Fernanda, Italy	\N
32	0	0101000020E6100000FFF9C78C011B2640DD706946501E4740		73 Contrada Marina, Borgo Tulliano, Italy	\N
33	0	0101000020E61000009C363EEEB67E2740BC2363B5F9BA4640		48 Incrocio Zarina, Concordio del friuli, Italy	\N
34	0	0101000020E61000008A9466F3387C1E402B31CF4A5AE74640		0 Via Gasparini, Gautiero sardo, Italy	\N
35	0	0101000020E6100000F22895F084D22A404082870E26ED4440		38 Piazza Appia, De Rosa sardo, Italy	\N
36	0	0101000020E61000007E1D386744712240C878399105CC4640		186 Via Corbiniano, Finotti nell'emilia, Italy	\N
37	0	0101000020E610000020D84C1993812240A475AFEEB30D4740		50 Piazza Vulpiano, San Cosimo umbro, Italy	\N
38	0	0101000020E6100000242136FD7E2E26406E2AF7A7F91A4740		34 Borgo Amanda, Settimo Anacleto, Italy	\N
39	0	0101000020E6100000485E8C37E8B927408860C1A2C7CA4640		641 Rotonda Soro, Santarsia terme, Italy	\N
40	0	0101000020E61000005E961BB1BB751E407379BD4571EF4640		9 Rotonda Caradonna, De Martino laziale, Italy	\N
41	0	0101000020E6100000BE2ABC708CED2340366964A1E7DD4640		24 Incrocio Giliola, Borgo Tiziana nell'emilia, Italy	\N
42	0	0101000020E610000053B4722F302B2540E4DC26DC2B4D4740		5 Incrocio Benini, Quarto Climaco lido, Italy	\N
43	0	0101000020E61000009A97C3EE3B32254052B241CB5F574640		3 Contrada Ponti, Doriano del friuli, Italy	\N
44	0	0101000020E6100000622D3E05C0782840F70BD17C29DE4640		833 Piazza Menegatti, Quarto Valfrido, Italy	\N
45	0	0101000020E6100000B05758703F782440773A4668BAB84640		8 Strada Bartolomeo, Gatta lido, Italy	\N
46	0	0101000020E610000011D20957F63B2640E6B8AEF3CA084740		3 Incrocio Mansueto, Zabedeo calabro, Italy	\N
47	0	0101000020E61000004704E3E0D2692C408514F2F741A74640		712 Rotonda Giacomelli, San Aiace calabro, Italy	\N
48	0	0101000020E61000002F0ACC54D2C8264038FE9F1E36CA4640		583 Strada Grossi, Piga lido, Italy	\N
49	0	0101000020E610000046E80C31035E29405A46EA3D95E54640		0 Strada De Rosa, Sesto Virginia salentino, Italy	\N
50	0	0101000020E6100000E4F90CA8376B2340ABA3F496BC5E4440		549 Rotonda Dante, Lombardi nell'emilia, Italy	\N
51	0	0101000020E6100000967DB2BD71ED26406F7319EDA7C14640		153 Incrocio Caracciolo, Donato nell'emilia, Italy	\N
52	0	0101000020E6100000FC68DDABFB5427401073EE1B04334740		389 Strada Ermenegarda, Telesca salentino, Italy	\N
53	0	0101000020E610000069965F611C5B2540B52792F991CA4540		57 Borgo Margherita, San Eufronio sardo, Italy	\N
54	0	0101000020E6100000B4C6455ACF692740D8C523A765B04640		89 Piazza Piersilvio, Settimo Cassio, Italy	\N
55	0	0101000020E61000003B843B61D3CC1E40935742D202D44640		455 Contrada Ferrario, Innocente nell'emilia, Italy	\N
56	0	0101000020E6100000C03FA54A9455284094347F4C6BE54640		255 Strada Guglielmo, Tagliabue del friuli, Italy	\N
57	0	0101000020E610000003FBF900EEEB1E40FA6184F068EE4640		23 Piazza Abbondio, Pellicanò terme, Italy	\N
58	0	0101000020E610000007681140209E2640B177352F3D9D4640		3 Via Pamela, Rocchi salentino, Italy	\N
59	0	0101000020E6100000525F96766AFE23402A7C6C81F3EE4640		681 Borgo Latini, Sesto Unna laziale, Italy	\N
60	0	0101000020E61000007319EDA7B5EF1E400B1060EC18EC4640		8 Borgo Romano, Gianluca a mare, Italy	\N
61	0	0101000020E6100000F86B578DCA1A284015E06014A9B14640		09 Incrocio Edelberga, Quarto Paola terme, Italy	\N
62	0	0101000020E6100000D634947FD2A12740811A081390584540		018 Via Bartolomeo, Mautone salentino, Italy	\N
63	0	0101000020E61000009D63E53C08EA2640B7FB0BF3D4DC4540		338 Strada Ginevra, Denaro calabro, Italy	\N
64	0	0101000020E6100000EA0E18DAEF9B2B40948444DAC6764640		08 Strada Mulè, Evaristo terme, Italy	\N
65	0	0101000020E610000014BCD7FFEFC62640BA66F2CD36DE4640		5 Borgo Sala, San Atanasio ligure, Italy	\N
66	0	0101000020E610000009168733BFBE27405D4E098849354540		4 Piazza Di Paola, Ferranti lido, Italy	\N
67	0	0101000020E6100000462AE7E6763A2940ABB8CC446CE14440		917 Rotonda Gianpaolo, Sesto Gundelinda, Italy	\N
68	0	0101000020E610000075EED176A7F62640A7F97486F3B24640		35 Strada Gonerio, San Doda, Italy	\N
69	0	0101000020E6100000F9A23D5E48F727405789C3E3ECE04640		2 Borgo Bonaventura, Pappalardo lido, Italy	\N
70	0	0101000020E6100000731A587D64FD294065FED13769E64540		3 Via Vezzoli, Amanda ligure, Italy	\N
71	0	0101000020E6100000ABC5F18D322421407D1FB3582FFA4640		8 Via Piersilvio, Lorenzini a mare, Italy	\N
72	0	0101000020E610000035D252793B0228403A79ECC26AEA4640		56 Incrocio Criscione, Virone calabro, Italy	\N
73	0	0101000020E6100000DD730580CFD02640F16261889CD44640		2 Strada Marziali, Quarto Irene, Italy	\N
74	0	0101000020E61000006531564046E12040530E1C8645E74640		3 Incrocio Caretti, Aris veneto, Italy	\N
75	0	0101000020E610000026B8A2DE9D5E2740311A434AFDDC4640		6 Piazza Matteucci, Settimo Piersilvio calabro, Italy	\N
76	0	0101000020E61000000A5BFD22B27524407121EA99B95B4640		8 Borgo Tolu, Simeti salentino, Italy	\N
77	0	0101000020E6100000C132DBBA40CE2240D0EFFB372F274740		98 Incrocio Eusebia, Murru ligure, Italy	\N
78	0	0101000020E6100000CA558737C6B91F40EB79ED88F9BD4640		88 Borgo Tomei, San Alberico del friuli, Italy	\N
79	0	0101000020E61000006AEE320DD4F324401D098F9147B14640		169 Strada Lucilla, Albano a mare, Italy	\N
80	0	0101000020E610000044053D8A291B2140F0FACC599F5A4440		926 Incrocio Casella, Settimo Mina, Italy	\N
81	0	0101000020E61000002B1D07B9E6212040F08C11E4FBF04640		4 Via Rotundo, Bernardi calabro, Italy	\N
82	0	0101000020E61000007BEDE3B21BB727403464E190B2DD4640		53 Borgo Giuliano, Didimo terme, Italy	\N
83	0	0101000020E6100000D8E9ACBB1EE91F40A0A932E774D04640		60 Piazza Paterniano, Ione laziale, Italy	\N
84	0	0101000020E61000009C8136DEC21B294063731FCA61894540		459 Contrada Albanese, Sesto Indro, Italy	\N
85	0	0101000020E6100000E3B08FA91680204076A0F3BF01E94640		39 Strada Angeletti, Allegretti salentino, Italy	\N
86	0	0101000020E6100000EE6EAF16E9832340C6F0225D7DCC4640		7 Strada Ulfo, Borgo Zaira, Italy	\N
87	0	0101000020E6100000D81D41E037B02140C2F1214D61C54440		21 Piazza Tedde, Sesto Alarico, Italy	\N
88	0	0101000020E6100000A807BB174E80284061BC8B9C2AD94640		0 Via Semprini, Almiro a mare, Italy	\N
89	0	0101000020E6100000FD18CE9085A322406C9CA80073DB4640		73 Rotonda Ruggiero, Sesto Climaco, Italy	\N
90	0	0101000020E6100000E39F635122672540E113A1C7DEDE4640		44 Rotonda Tufo, Famiano nell'emilia, Italy	\N
91	0	0101000020E610000098231A93B47928409916500361674640		008 Contrada Gualberto, Erberto laziale, Italy	\N
92	0	0101000020E6100000ABBCD3539A032740A544B7031AEF4640		6 Borgo Erasmo, Diana calabro, Italy	\N
93	0	0101000020E61000001E424B0D239B2440D8D1DD1A7DA04640		77 Borgo Aiello, Quarto Eugenia, Italy	\N
94	0	0101000020E6100000CF2CAE96E0891F405EB642FDD3234640		351 Contrada Barone, Quarto Quartilla del friuli, Italy	\N
95	0	0101000020E6100000D7BDBACF96BC254007205AD020C34640		7 Strada Barbara, Feliciano lido, Italy	\N
96	0	0101000020E6100000C96BCABA24832740A97E4A3A6FE54640		8 Borgo Elmo, Demetrio laziale, Italy	\N
97	0	0101000020E6100000A8DAB80F8AC32940DF67017F9D1A4540		8 Borgo Aquilino, Sesto Romano terme, Italy	\N
98	0	0101000020E6100000C272DFC556972640A4271BC528D24640		15 Contrada Adriana, San Ludovica, Italy	\N
99	0	0101000020E61000005F306E5974411E40EC3F21F1E13A4740		338 Strada Muziano, Cicala sardo, Italy	\N
100	0	0101000020E61000006C109CE9142628401760C4E347124740		050 Strada Celeste, Borgo Danio, Italy	\N
101	0	0101000020E610000044EC0214D9FD284012AC600AC5EE4440		120 Via Cristoforo Colombo, Roma, Italy	\N
102	0	0101000020E6100000B0FECF61BEF827406DFD99E6C2F24640		3 Borgo Panico, Schettino umbro, Italy	\N
103	0	0101000020E6100000EBB76576CCAF26407B8FE9BFBD424640		07 Piazza Efrem, Giraudo nell'emilia, Italy	\N
104	0	0101000020E6100000D6479682247220407379BD4571084740		8 Piazza Placida, Giustra umbro, Italy	\N
105	0	0101000020E610000097900F7A36872040AB251DE560074740		028 Incrocio Cirillo, Musso del friuli, Italy	\N
106	0	0101000020E61000000DABD3DC65C22740D32F116F9DE34640		82 Via Barreca, Lazzarini veneto, Italy	\N
107	0	0101000020E61000009FEE97AA0FCF27402834FF9E0E024740		53 Piazza Albino, Borgo Eusebio terme, Italy	\N
108	0	0101000020E6100000E417B90265622C40EFC0A50815E24440		56 Incrocio Furno, Eufebio calabro, Italy	\N
109	0	0101000020E6100000B2463D44A37B2540F3C011EEDF764540		18 Incrocio Delogu, Eva ligure, Italy	\N
110	0	0101000020E6100000B6B0B84956A326409DC2A5BE87334740		916 Borgo Pedrazzini, De Luca sardo, Italy	\N
111	0	0101000020E6100000D56C2FB319AD2840823C16365EC04640		751 Strada Gavino, Sesto Giusto, Italy	\N
112	0	0101000020E610000076583C5002EE1E40E0CCF9731BE14640		325 Piazza Ciacio, Pozzi salentino, Italy	\N
113	0	0101000020E6100000470EC7A98CC52840B6A73F564BE04640		28 Borgo Amabile, San Galdino, Italy	\N
114	0	0101000020E61000004DC00A4B97B91F4005C1E3DBBBF84540		7 Rotonda Morena, Mario veneto, Italy	\N
115	0	0101000020E610000059EB7A585E182740106D1162780E4640		201 Incrocio Bino, Maio lido, Italy	\N
116	0	0101000020E610000051D9B0A6B2581F4089B7CEBF5DE14640		497 Incrocio Murtas, Salierno umbro, Italy	\N
117	0	0101000020E6100000AD7603BB504F27406049A8CFC4374640		47 Contrada Adrione, Dora sardo, Italy	\N
118	0	0101000020E61000004692C5A28EF72640D32934B511794640		19 Via Pierluigi, Crespignano calabro, Italy	\N
119	0	0101000020E6100000068B790C45182740C3CB1D47BD774640		3 Strada Respicio, San Saturniano sardo, Italy	\N
120	0	0101000020E61000005CC0159A35C620401880A1A245F44640		096 Strada Eleuterio, Adalberta laziale, Italy	\N
121	0	0101000020E6100000FA2D9512DD7227409453967C47234640		7 Incrocio Beltrame, Pavone a mare, Italy	\N
122	0	0101000020E61000008ECD8E54DFA12B403562C1583A2D4540		58 Incrocio Eva, Epifani salentino, Italy	\N
123	0	0101000020E610000020651FBF127F254034C06092257F4640		9 Borgo Bartolomea, Viliberto umbro, Italy	\N
124	0	0101000020E610000064BB31F3D36E22404F401361C3C24640		7 Via La Torre, Sara veneto, Italy	\N
125	0	0101000020E6100000D160AEA0C47E2240E41824D813C04640		514 Borgo Manzo, Borgo Asdrubale laziale, Italy	\N
126	0	0101000020E61000006FD8B628B3B91E40086465EA64D64640		9 Via Novella, Tammaro umbro, Italy	\N
127	0	0101000020E610000016CDB9CAC93E2140BC0E8B074A744640		467 Via Marino, Rampazzo laziale, Italy	\N
128	0	0101000020E6100000B4064A65E54A274026DAFA8E86E14640		08 Incrocio Bassiano, Torrisi lido, Italy	\N
129	0	0101000020E61000000736F80CF26822405273034F6B9C4640		95 Strada Flacco, San Isa sardo, Italy	\N
130	0	0101000020E6100000DF6124C511412140D11CFE3FF3744640		5 Incrocio Scuderi, Sesto Acacio calabro, Italy	\N
131	0	0101000020E610000077ED77CD50412140CB243493B9744640		082 Borgo Selvaggia, Diamante lido, Italy	\N
132	0	0101000020E61000002E008DD2A5032D406B5CA4F55C204540		4 Strada Adalgiso, Quarto Adamo, Italy	\N
133	0	0101000020E61000004ED367075C6F1F403A57941282D64640		743 Strada Susanna, San Lidania, Italy	\N
134	0	0101000020E61000006405BF0D316E1F409F07D22060D24640		512 Borgo Fiorella, Settimo Gianmaria salentino, Italy	\N
135	0	0101000020E61000006F4BE482334C2740A928A8F287304640		5 Strada Oliviero, Sesto Messalina, Italy	\N
136	0	0101000020E61000005BC52CC59F522B40DB68A5B50EFA4640		458 Contrada Euclide, Bertolussi lido, Italy	\N
137	0	0101000020E61000000D5F155E383A21402BCC310F4F724640		43 Borgo Pacifico, Settimo Delfina, Italy	\N
138	0	0101000020E6100000E04158326C5D2140821C9430D3704640		6 Piazza Valerio, San Romola, Italy	\N
139	0	0101000020E6100000C1F979F8D7071F404EFA319C21CD4640		25 Piazza Santo, Benvenuti a mare, Italy	\N
140	0	0101000020E61000000C97B0917F3921404C9C267D6B734640		916 Borgo Moro, Sesto Nestore, Italy	\N
141	0	0101000020E6100000EFA18ED838742840FA10AF46D1764640		41 Strada Enea, Borgo Ferruccio, Italy	\N
142	0	0101000020E6100000B032BF3F4AC11E4019CD25B094D54640		86 Piazza Valenti, Monticelli del friuli, Italy	\N
143	0	0101000020E610000039FBB9579CA829401D9C3EF152FC4440		533 Via Usai, Bernabei lido, Italy	\N
144	0	0101000020E6100000440E5BC4C1F71E4071033E3F8C7E4640		9 Piazza Tranquillo, Quarto Ildegarda, Italy	\N
145	0	0101000020E6100000C69EE2DD36D82B400B8AD5D5D3E84640		90 Via Baldo, Matarazzo lido, Italy	\N
146	0	0101000020E6100000888961E2EA131F4040E7244A31CD4640		123 Incrocio Andrisani, Borgo Innocenzo ligure, Italy	\N
147	0	0101000020E6100000E8F86871C6D81E40E7EBE86E8DD84640		21 Contrada Maresca, Curci sardo, Italy	\N
148	0	0101000020E610000024BF34FBF2301F405FCE6C57E8CB4640		08 Borgo Severa, San Gilda, Italy	\N
149	0	0101000020E61000000242902859C7254075988AE832F64540		75 Borgo Principato, De Carolis umbro, Italy	\N
150	0	0101000020E61000005CEC5113D8AF1E405650ACAE9ED84640		691 Borgo Tarantino, Cristiana lido, Italy	\N
151	0	0101000020E6100000A6A84423E9E41E40BF20336145E14640		502 Via Ventura, Amato umbro, Italy	\N
152	0	0101000020E6100000F07A7AB6582B2740B1ADFAB726234640		20 Strada Valente, Sesto Aristeo veneto, Italy	\N
153	0	0101000020E61000002252D32EA6C91E404392B47636E94640		6 Rotonda Palla, Sesto Saffiro, Italy	\N
154	0	0101000020E61000000BC336983C2C27405262D7F676234640		19 Strada Pugliese, Borgo Eufebio lido, Italy	\N
155	0	0101000020E61000004F722C94F1E8264075F2D885D5064740		9 Via Giordano, Medugno umbro, Italy	\N
156	0	0101000020E61000005C8BBBE6FA8F26407A4F8AFB343B4740		88 Contrada Venusta, Eloisa veneto, Italy	\N
157	0	0101000020E61000007B9054956C0B28407BB5487FD4974640		914 Strada Cristiano, Papini a mare, Italy	\N
158	0	0101000020E6100000BE52F1DA00B72B40D21D1F8887274540		274 Piazza Giuliano, San Glenda lido, Italy	\N
159	0	0101000020E6100000A732D6485C052740FDD8243FE2394640		306 Piazza Affinito, Corazza salentino, Italy	\N
160	0	0101000020E6100000AD94545C0B4D2240EE885462E8B94640		2 Incrocio Manilio, Borgo Bruno, Italy	\N
161	0	0101000020E6100000333097F9B3641F40983BE93356DF4640		79 Incrocio Caccamo, Boschi veneto, Italy	\N
162	0	0101000020E61000002B8AB2124E762740C1EA234B41314640		5 Contrada Sostene, Borgo Namazio, Italy	\N
163	0	0101000020E6100000905F8951219022403E5695229E864640		420 Borgo Serafina, San Adriano, Italy	\N
164	0	0101000020E610000096C1621E43E92640E580B80611044740		95 Rotonda Gerolamo, San Zetico, Italy	\N
165	0	0101000020E61000007090B52B99842B40E461461DC27E4640		729 Incrocio Aimone, Sesto Ermete lido, Italy	\N
166	0	0101000020E610000084B1CFAD219A26406BDECC43010E4740		380 Piazza Amendola, Quarto Godeberta del friuli, Italy	\N
167	0	0101000020E6100000CC1D47BDF13F2240A5A31CCC26824640		82 Incrocio Fioretti, Emma a mare, Italy	\N
168	0	0101000020E610000048E58123DCFF26407F7E294D94084740		85 Via Di Bari, Moscato terme, Italy	\N
169	0	0101000020E61000006B5A73918C1625409D7C1FB358204740		28 Borgo Alarico, Di Fiore del friuli, Italy	\N
170	0	0101000020E6100000204F818241C01E40068B1E53D2D34640		8 Rotonda Moriconi, Marciano terme, Italy	\N
171	0	0101000020E6100000C0CBB161F2931E40B859BC5818D34640		2 Rotonda Gerardo, Annamaria terme, Italy	\N
172	0	0101000020E610000070DA4246F68B2C40A79C8AAFD1364740		739 Via Napolitano, San Paola, Italy	\N
173	0	0101000020E6100000A9D5FC9D92882C4058FBE02131384740		2 Incrocio Liberati, Bordoni veneto, Italy	\N
174	0	0101000020E6100000F74A0FF91DD1274067DC8AB3D8024740		88 Via Perra, Beltrame lido, Italy	\N
175	0	0101000020E61000004221A7542EE52C40A39BB3F457164740		977 Incrocio Desiderio, Settimo Respicio, Italy	\N
176	0	0101000020E6100000D3D7987C586422408E7CB9AA47A84640		7 Strada Passarelli, San Neopolo, Italy	\N
177	0	0101000020E610000008CDAE7B2B8A2440E646EC6EF9664540		90 Strada Riparbelli, Galdino nell'emilia, Italy	\N
178	0	0101000020E610000081EB8A19E1CD26408A4457D8C2194640		72 Contrada Stefania, Quarto Dorotea laziale, Italy	\N
179	0	0101000020E6100000B4CA4C69FD5122404A95CDC1D8134540		770 Via Amalia, Silvestro terme, Italy	\N
180	0	0101000020E6100000E4BD6A65C267264033260EEA6CBC4640		776 Strada Tumino, Clara veneto, Italy	\N
181	0	0101000020E610000071C0536DDCD325406C312E0BDCB14640		95 Contrada Egidio, De Col a mare, Italy	\N
182	0	0101000020E6100000B368F0ADFEEA2540D42AFA4333B54640		1 Strada Quirino, Sesto Ursicio umbro, Italy	\N
183	0	0101000020E61000005B2CA0AB08EA2740DE454E15422C4740		1 Piazza Gilberto, Lorena salentino, Italy	\N
184	0	0101000020E61000009703988D2933274052EC0D63778A4640		271 Via Monte Grappa, Lendinara, Italy	\N
185	0	0101000020E61000005389FC44AF582940E7D2AEF83CCA4640		1 Rotonda Gerasimo, Quarto Alfio lido, Italy	\N
186	0	0101000020E61000000236D6B441802C4025D5D237C46B4440		44 Via dei Greci, Napoli, Italy	\N
187	0	0101000020E610000073220BE24DBC2740A1E4C40DAE2D4740		078 Incrocio Tarsilla, Settimo Richelmo, Italy	\N
188	0	0101000020E610000046B1DCD26AB02540072E45A808074740		5 Contrada Carlo, Ballarin laziale, Italy	\N
189	0	0101000020E6100000B17E7DBE77992240C0F858B043504440		1 Incrocio Puggioni, Prete nell'emilia, Italy	\N
190	0	0101000020E6100000EC3026FDBD2C27403B6AF1CE46024740		69 Borgo D'Amico, Mautone umbro, Italy	\N
191	0	0101000020E6100000996EC8F5A5712B40C576F700DD3C4740		4 Via Adriano, Settimo Adalfredo, Italy	\N
192	0	0101000020E6100000AA5DB818A8F922406B0DA5F622154440		63 Piazza Di Tommaso, Borgo Galeazzo, Italy	\N
193	0	0101000020E610000034B10AE58E682040CFC941BFA57A4440		07 Piazza Faraone, Vitalico nell'emilia, Italy	\N
194	0	0101000020E610000008D04AB5AABC2140800F5EBBB4374640		36 Incrocio Dacio, Sigismondo lido, Italy	\N
195	0	0101000020E6100000B35DA10F967D2D408F49905BDD324740		8 Incrocio Goffredo, Settimo Everardo, Italy	\N
196	0	0101000020E6100000852348A5D8C12840842458C114E24540		6 Borgo Idea, Ugolini sardo, Italy	\N
197	0	0101000020E6100000BF5076E915252B40EA398EC4703B4740		742 Contrada Bindi, Borgo Minervino umbro, Italy	\N
198	0	0101000020E6100000B956D6917EDA2B40DF707A72A8054540		70 Incrocio Ardito, Fernanda sardo, Italy	\N
199	0	0101000020E61000007889A02067742340DE2A3EF493CE4640		5 Strada Gianpiero, Godeberta lido, Italy	\N
200	0	0101000020E6100000235399BDC70C254059CFFF6101ED4540		999 Piazza Cordioli, Terenzi salentino, Italy	\N
201	0	0101000020E610000027F33405D7392640E75E16C90D2C4740		1 Incrocio Corbiniano, San Prassede terme, Italy	\N
202	0	0101000020E61000001C15EE4BECAC2A40DD11A9C4D02E4540		5 Piazza Angelini, Flacco umbro, Italy	\N
203	0	0101000020E6100000C1D4850E70E722408E6D63FDB0594540		766 Piazza Loris, Iannello veneto, Italy	\N
204	0	0101000020E6100000E5BA849E28A826407E7D63BE723F4640		4 Strada Aristotele, Settimo Vinfrido, Italy	\N
205	0	0101000020E610000055B1E72109D11F4018CFA0A17FB14640		78 Strada Ottaviani, Foschi veneto, Italy	\N
206	0	0101000020E61000007DEFCA89D18E2640DB0B16985F354540		482 Rotonda Liberato, Bonanni lido, Italy	\N
207	0	0101000020E6100000BB6D9516E41D244002678412C1A94640		211 Piazza Casale, Moreno laziale, Italy	\N
208	0	0101000020E6100000F67AF7C77BB52740FA449E245D4F4740		34 Incrocio Soro, Amanda sardo, Italy	\N
209	0	0101000020E6100000DE68119BD960294098E8E225EEFB4440		4 Incrocio Ricario, Sottile nell'emilia, Italy	\N
210	0	0101000020E61000007ED3AA4CE7E52340C9CC052E8F254640		704 Rotonda Ivo, Loreto veneto, Italy	\N
211	0	0101000020E61000004EDF217B732E2240D3F4D901D7214540		17 Incrocio Pio, Sesto Gastone, Italy	\N
212	0	0101000020E61000004377A45588CA264008951348E43C4640		3 Incrocio Violi, Borgo Grazia, Italy	\N
213	0	0101000020E610000072593B40E6692840252D4B2A09EC4440		730 Strada Prospera, Settimo Orsino del friuli, Italy	\N
214	0	0101000020E610000023E7B3F281D7214072C8618B38C84640		16 Incrocio De Carolis, Torrisi laziale, Italy	\N
215	0	0101000020E61000000C84AE8E2D752740A4897780272E4640		11 Rotonda Longobardi, Santo laziale, Italy	\N
216	0	0101000020E6100000A63C5F58A33326408C811A63CCED4540		9 Contrada Clemenzia, Amadori del friuli, Italy	\N
217	0	0101000020E6100000CC0C1B65FD922840A42C8DA905C14640		494 Strada Pintus, Zappia sardo, Italy	\N
218	0	0101000020E61000007332CC64933F2740FEDDF1DC31254640		722 Borgo Angelucci, Settimo Turi, Italy	\N
219	0	0101000020E610000032D758784D462240743F4C67CC0B4740		4 Rotonda Lanteri, Veronese salentino, Italy	\N
220	0	0101000020E61000002B16BF29ACC825401AB6775787864540		20 Strada Daniele, Ivano veneto, Italy	\N
221	0	0101000020E6100000FE00B562C9B62A4032CFA51364D94440		62 Borgo Attila, Borgo Ermenegarda, Italy	\N
222	0	0101000020E61000002AD890C9F3362640A3C629DFD80F4640		8 Via Silvana, Borgo Filiberto, Italy	\N
223	0	0101000020E610000098F0958AD7422540F3DD52735E994640		4 Contrada Assunta, Settimo Gillo veneto, Italy	\N
224	0	0101000020E6100000451B36806D772640B99BF1C7FE074740		5 Via Vecchi, Sesto Vala salentino, Italy	\N
225	0	0101000020E61000008948A8740B9027402B7D321015F14540		48 Strada Folco, Quarto Mirta, Italy	\N
226	0	0101000020E6100000484B8A3496612B40F1F44A5986DF4640		17 Incrocio Palombo, Settimo Tullia nell'emilia, Italy	\N
227	0	0101000020E610000006240626DCE0264059631A97BBDC4640		7 Via Ragone, Palumbo veneto, Italy	\N
228	0	0101000020E61000001A62067470422640EF6BC94F4FBD4540		9 Via Annagrazia, Settimo Ludovica, Italy	\N
229	0	0101000020E6100000F0F1536694F425402F5D77A9C7134640		628 Contrada Ugo, Di Iorio lido, Italy	\N
230	0	0101000020E6100000A5DAA7E3317F2240E75E16C90DEF4640		77 Via Torchio, Borgo Raimondo, Italy	\N
231	0	0101000020E6100000D12E956D967D2C40126C5CFFAE6D4440		5 Incrocio Raide, Chiaravalle sardo, Italy	\N
232	0	0101000020E6100000DD6CBDF0941F27409F515F3BBDDA4640		088 Piazza Demetrio, Sesto Gianpietro laziale, Italy	\N
233	0	0101000020E610000096EA025E66002640FA4E82ED16F44540		0 Rotonda Ruperto, Quarto Telemaco salentino, Italy	\N
234	0	0101000020E61000009DDE20B5E43C25407F83F6EAE39D4540		464 Piazza Sala, Marrazzo ligure, Italy	\N
235	0	0101000020E6100000016E162F168E2340861BF0F9614A4440		79 Borgo Attilano, Sesto Libero, Italy	\N
236	0	0101000020E61000009F32480BE1EA20405C8A50114CDA4640		81 Incrocio Giachi, Santoro laziale, Italy	\N
237	0	0101000020E6100000618841052C422B400938DFE3A78E4640		2 Piazza Bassi, Marani del friuli, Italy	\N
238	0	0101000020E6100000160F94803D132140276BD44334E04640		3 Borgo Cardinali, Sisto sardo, Italy	\N
239	0	0101000020E610000097A13BD22A4C25401A80B2CE9DD44540		951 Contrada Perseo, Zambon a mare, Italy	\N
240	0	0101000020E6100000AD904D4DDD3827405B632BC313B14540		6 Via Giannotti, Borgo Fosco, Italy	\N
241	0	0101000020E610000071E82D1EDEEB2C405F93DA30AF824440		0 Via Parente, Aza terme, Italy	\N
242	0	0101000020E6100000DA48C8F6109B1F40EE2AFFB5176E4640		217 Incrocio Lucarini, San Sostrato, Italy	\N
243	0	0101000020E61000004D028A4798F02740C38366D7BD264640		098 Via Sartori, Quarto Noemi, Italy	\N
244	0	0101000020E6100000BCB77DEAB38A2C404EF04DD3676E4440		650 Contrada Damaso, San Elsa, Italy	\N
245	0	0101000020E6100000CBC80F4BB93126404793E6EA22FD4640		0 Contrada Puccio, Settimo Selene del friuli, Italy	\N
246	0	0101000020E6100000A68E9FD7E925284065677682A2C64640		58 Via Petronio, Quarto Cleopatra salentino, Italy	\N
247	0	0101000020E6100000407562C55F5D294091FC773359C24640		60 Borgo Gondulfo, Licitra ligure, Italy	\N
248	0	0101000020E6100000CF328B506C4D244070D63B37C8184640		068 Contrada Vannini, Settimo Bassiano ligure, Italy	\N
249	0	0101000020E61000007E6E0D11DC1122409453967C47EB4640		620 Via Diamante, Saffo ligure, Italy	\N
250	0	0101000020E610000043A44BA4D989204072A8DF85ADD34640		697 Via Cappelli, Settimo Vodingo, Italy	\N
251	0	0101000020E61000004371C79BFC022C404AF5F81807254540		8 Borgo Silvia, Sesto Ursino, Italy	\N
252	0	0101000020E61000009EA74B10BFA422400292FAFC41944440		96 Borgo Lelia, Fratello a mare, Italy	\N
253	0	0101000020E61000000D88B59D5B012C40CF70B9B024144540		1 Strada Berto, Tarsilla a mare, Italy	\N
254	0	0101000020E610000059935D1F8CFE26407E6DA23B2D3B4640		9 Borgo Candida, Sesto Edilberto a mare, Italy	\N
255	0	0101000020E6100000D50451F7010829403B736AC2510D4640		7 Strada Eriberto, Quarto Leopardo lido, Italy	\N
256	0	0101000020E6100000CD6152D735012740D65F6523C6394640		3 Contrada Camillo, Gianotti a mare, Italy	\N
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hike_track_points ("userHikeId", index, "pointId", datetime) FROM stdin;
\.


--
-- Data for Name: user_hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes (id, "userId", "hikeId", "startedAt", "updatedAt", "finishedAt", "psTotalKms", "psHighestAltitude", "psAltitudeRange", "psTotalTimeMinutes", "psAverageSpeed", "psAverageVerticalAscentSpeed") FROM stdin;
\.


--
-- Data for Name: user_hikes_track_points_user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes_track_points_user_hike_track_points ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash", approved, preferences) FROM stdin;
2	$2b$10$eAo5.D7ruzTqe3dSDxlhb.u4opQDU331RRUKzdtoV6SvhXNFhQp0q	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N	f	\N
4	$2b$10$EjJR3tc5oj7PVtnos91Rn.oMq3hmWF.LHwClbV4P.6bsKY2ohMkEi	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N	f	\N
5	$2b$10$SLegIgxBauK0IMF8Ft3ze.GEN4weq/hFXkgIFmqca8QNVh50Ydqqq	Laura	Zurru	5	laura@emergency.it	\N	t	\N	f	\N
1	$2b$10$nY72JGgULjvfl0rtsbWk6.CplV14R4vyR23JfZAEThlBy5H/wzHzq	German	Gorodnev	0	german@hiker.it	\N	t	\N	f	\N
3	$2b$10$Ak8WoFHMy.9hPwnZjHOQ1.t5Qp0mu6d8ivaQrlp2NXBdJbQC2lPZy	vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N	f	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 1, false);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 1, false);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 256, true);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 256, true);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_hikes_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

