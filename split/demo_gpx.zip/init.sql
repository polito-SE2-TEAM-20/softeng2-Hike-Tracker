--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: hike_points PK_7fc686c35c52228d8494a7c4947; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_7fc686c35c52228d8494a7c4947" PRIMARY KEY ("hikeId", "pointId");


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$AFzx6MUxAQsDFZ/3ZRAzT.sRjcSUcW6CIl9wLVFG0jUt/HpbPNu.y',
    'Antonio',
    'Battipaglia',
    2,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$djdjOAwinolLHtg7z4uP.OFXTByc6RUzBcLkcARUWznXtFejE8rvy',
    'Erfan',
    'Gholami',
    4,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$.hLdfGDCtM2rNcDfF1.e1e4TT.irQQT8S2XnJ23CXeR7wChTFNyam',
    'Laura',
    'Zurru',
    5,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$XXTXAkgzbQpEGKG353mi4uuPJRDRvOoXGgJ2kYcesDWDHxNu2hEfG',
    'German',
    'Gorodnev',
    0,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$tJ6KO3zGmBMrX7Pdcp8pZehfNc/vtoFapFbqzPN3oO4JNLjzO8FTe',
    'vincenzo',
    'Sagristano',
    3,
    true
  );
  

      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Airline Trail - Detour',
        1,
        '/static/gpx/001_Airline_Trail___Detour.gpx',
        'USA',
        'Parma',
        '',
        'Alivernini ligure',
        3.3,
        15.4,
        476,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Airline Trail',
        2,
        '/static/gpx/002_Airline_Trail.gpx',
        'USA',
        'Firenze',
        '',
        'Lelli lido',
        3.7,
        18.9,
        1308,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Colchester Railroad',
        0,
        '/static/gpx/003_Colchester_Railroad.gpx',
        'USA',
        'Sassari',
        '',
        'Borgo Bassilla salentino',
        9.2,
        28.6,
        1500,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Willimantic Flower Bridge',
        2,
        '/static/gpx/004_Willimantic_Flower_Bridge.gpx',
        'USA',
        'Pistoia',
        '',
        'Quarto Alberta nell''emilia',
        1.8,
        19.2,
        345,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Willimantic Pedestrian Bridge',
        2,
        '/static/gpx/005_Willimantic_Pedestrian_Bridge.gpx',
        'USA',
        'Caserta',
        '',
        'San Ileana',
        1.2,
        9,
        240,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Two Sister''S Preserve Loop Trail',
        2,
        '/static/gpx/006_Two_Sister_S_Preserve_Loop_Trail.gpx',
        'USA',
        'Novara',
        '',
        'Pace sardo',
        5.3,
        29.5,
        576,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Putnam River Trail',
        0,
        '/static/gpx/007_Putnam_River_Trail.gpx',
        'USA',
        'Teramo',
        '',
        'Settimo Deodato',
        3.4,
        24.5,
        975,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Airline Trail Bypass',
        2,
        '/static/gpx/008_Airline_Trail_Bypass.gpx',
        'USA',
        'Carbonia-Iglesias',
        '',
        'Macchia salentino',
        2.1,
        18.4,
        663,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Indian Neck',
        2,
        '/static/gpx/009_Indian_Neck.gpx',
        'USA',
        'Viterbo',
        '',
        'Sesto Melissa calabro',
        5.5,
        8.4,
        17010,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Stony Creek',
        0,
        '/static/gpx/010_Stony_Creek.gpx',
        'USA',
        'Campobasso',
        '',
        'Tabita calabro',
        3.6,
        15,
        13464,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quarry-Westwoods',
        2,
        '/static/gpx/011_Quarry_Westwoods.gpx',
        'USA',
        'Vicenza',
        '',
        'Sesto Ulstano salentino',
        7.6,
        20.7,
        10680,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Short Beach',
        2,
        '/static/gpx/012_Short_Beach.gpx',
        'USA',
        'Fermo',
        '',
        'Quarto Anatolia sardo',
        8.7,
        18.4,
        21855,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Charter Oak Greenway',
        1,
        '/static/gpx/013_Charter_Oak_Greenway.gpx',
        'USA',
        'Olbia-Tempio',
        '',
        'Santarossa ligure',
        1.6,
        5.1,
        210,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bissell Greenway',
        0,
        '/static/gpx/014_Bissell_Greenway.gpx',
        'USA',
        'Teramo',
        '',
        'Sesto Eufrasia laziale',
        2.4,
        12.2,
        1050,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Riverfront Trail System',
        2,
        '/static/gpx/015_Riverfront_Trail_System.gpx',
        'USA',
        'Catanzaro',
        '',
        'Occhipinti del friuli',
        2.1,
        13.2,
        364,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Millers Pond Park Trail',
        2,
        '/static/gpx/016_Millers_Pond_Park_Trail.gpx',
        'USA',
        'Lecce',
        '',
        'Sesto Speranza',
        4.2,
        13.2,
        675,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattabesett Trail',
        2,
        '/static/gpx/017_Mattabesett_Trail.gpx',
        'USA',
        'Pordenone',
        '',
        'Tiberio salentino',
        1.5,
        12.4,
        440,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Jefferson Park Trail',
        2,
        '/static/gpx/018_Jefferson_Park_Trail.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Cola umbro',
        0.7,
        27.7,
        195,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Cockaponset Trail',
        2,
        '/static/gpx/019_Cockaponset_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'Quarto Goffredo',
        0.8,
        19.3,
        98,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mt. Nebo Park',
        1,
        '/static/gpx/020_Mt__Nebo_Park.gpx',
        'USA',
        'Imperia',
        '',
        'Quarto Melezio laziale',
        3.9,
        7.3,
        374,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        ' ',
        2,
        '/static/gpx/021__.gpx',
        'USA',
        'Verbano-Cusio-Ossola',
        '',
        'De Lorenzo terme',
        1.6,
        12.9,
        156,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Proposed Trail',
        2,
        '/static/gpx/022_Proposed_Trail.gpx',
        'USA',
        'Ravenna',
        '',
        'Grosso sardo',
        0.7,
        16.4,
        154,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Blinnshed Ridge Trail',
        2,
        '/static/gpx/023_Blinnshed_Ridge_Trail.gpx',
        'USA',
        'Caltanissetta',
        '',
        'Quarto Evasio',
        1.8,
        15.6,
        240,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Neck River Trail',
        2,
        '/static/gpx/024_Neck_River_Trail.gpx',
        'USA',
        'Asti',
        '',
        'Bertolussi terme',
        4.8,
        18.1,
        910,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Unnamed Trail',
        2,
        '/static/gpx/025_Unnamed_Trail.gpx',
        'USA',
        'Trento',
        '',
        'Iginia del friuli',
        1.4,
        22.5,
        143,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Oil Mill Brook Trail',
        2,
        '/static/gpx/026_Oil_Mill_Brook_Trail.gpx',
        'USA',
        'Latina',
        '',
        'Borgo Diamante laziale',
        0.7,
        9.2,
        165,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chatfield Trail',
        2,
        '/static/gpx/027_Chatfield_Trail.gpx',
        'USA',
        'Livorno',
        '',
        'Rufino laziale',
        1.3,
        8.9,
        170,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Unamed Trail',
        2,
        '/static/gpx/028_Unamed_Trail.gpx',
        'USA',
        'La Spezia',
        '',
        'Borgo Letterio salentino',
        1.3,
        10.2,
        637,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Lost Pond Trail',
        2,
        '/static/gpx/029_Lost_Pond_Trail.gpx',
        'USA',
        'Pordenone',
        '',
        'Borgo Niceforo sardo',
        3.6,
        10.1,
        540,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ccc Camp Hadley Trail',
        2,
        '/static/gpx/030_Ccc_Camp_Hadley_Trail.gpx',
        'USA',
        'Firenze',
        '',
        'Sesto Oddone',
        1.4,
        11.3,
        110,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Double Loop Trail',
        2,
        '/static/gpx/031_Double_Loop_Trail.gpx',
        'USA',
        'Bergamo',
        '',
        'Curci umbro',
        0.7,
        9.9,
        60,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Over Brook Trail',
        2,
        '/static/gpx/032_Over_Brook_Trail.gpx',
        'USA',
        'Siracusa',
        '',
        'Centofanti umbro',
        1,
        20.5,
        28,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Cockaponset Forest Trail',
        2,
        '/static/gpx/033_Cockaponset_Forest_Trail.gpx',
        'USA',
        'Milano',
        '',
        'San Giorgio laziale',
        0.9,
        20.6,
        45,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pattaconk Trail',
        2,
        '/static/gpx/034_Pattaconk_Trail.gpx',
        'USA',
        'Brescia',
        '',
        'Settimo Socrate',
        1,
        16.2,
        55,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Westwoods Forest Trail',
        2,
        '/static/gpx/035_Westwoods_Forest_Trail.gpx',
        'USA',
        'Roma',
        '',
        'Sonia veneto',
        2.6,
        26.7,
        429,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Blinnshed Loop Trail',
        2,
        '/static/gpx/036_Blinnshed_Loop_Trail.gpx',
        'USA',
        'Potenza',
        '',
        'Bedini terme',
        4.1,
        20,
        868,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Unnamed Tsail',
        2,
        '/static/gpx/037_Unnamed_Tsail.gpx',
        'USA',
        'Foggia',
        '',
        'Daniele veneto',
        3.4,
        9.7,
        675,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Messerschmidt Wma Trail',
        0,
        '/static/gpx/038_Messerschmidt_Wma_Trail.gpx',
        'USA',
        'Caserta',
        '',
        'San Valfredo ligure',
        2.1,
        12.6,
        264,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Westwoods Nature Trail',
        2,
        '/static/gpx/039_Westwoods_Nature_Trail.gpx',
        'USA',
        'Napoli',
        '',
        'Gulino lido',
        3.9,
        17.9,
        455,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Enduro',
        2,
        '/static/gpx/040_Enduro.gpx',
        'USA',
        'Asti',
        '',
        'Borgo Ermete',
        1.6,
        11.2,
        144,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Land Trust Trail',
        2,
        '/static/gpx/041_Land_Trust_Trail.gpx',
        'USA',
        'Modena',
        '',
        'Borgo Ludovica',
        2,
        28.2,
        225,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Beaver Brook Park Trail',
        2,
        '/static/gpx/042_Beaver_Brook_Park_Trail.gpx',
        'USA',
        'Caserta',
        '',
        'Olivieri veneto',
        0.9,
        29.9,
        28,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Housatonic Forest Trail',
        0,
        '/static/gpx/043_Housatonic_Forest_Trail.gpx',
        'USA',
        'Roma',
        '',
        'Antonia calabro',
        1.4,
        20.3,
        140,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Farmington Canal Trail',
        0,
        '/static/gpx/044_Farmington_Canal_Trail.gpx',
        'USA',
        'Caserta',
        '',
        'Erminia nell''emilia',
        9.9,
        17.8,
        1430,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Beckley Furnace Park Path',
        1,
        '/static/gpx/045_Beckley_Furnace_Park_Path.gpx',
        'USA',
        'Napoli',
        '',
        'Emilia laziale',
        1,
        14.4,
        90,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Farmington River Trail',
        2,
        '/static/gpx/046_Farmington_River_Trail.gpx',
        'USA',
        'Pescara',
        '',
        'Pandolfi salentino',
        1.1,
        18.9,
        372,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Farminton Canal Trail',
        2,
        '/static/gpx/047_Farminton_Canal_Trail.gpx',
        'USA',
        'Bologna',
        '',
        'Borgo Armando',
        5.6,
        18.9,
        610,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Farminton River Trail',
        2,
        '/static/gpx/048_Farminton_River_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'Arcangeli umbro',
        0.6,
        12,
        36,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hop River Trail',
        1,
        '/static/gpx/049_Hop_River_Trail.gpx',
        'USA',
        'Lodi',
        '',
        'Quarto Candida',
        10,
        10.7,
        6150,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hoprivertrail - Detouraround316',
        1,
        '/static/gpx/050_Hoprivertrail___Detouraround316.gpx',
        'USA',
        'Cagliari',
        '',
        'Settimo Rosalinda salentino',
        0.8,
        20.4,
        170,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hop River Trail - Long Hill Rd.',
        0,
        '/static/gpx/051_Hop_River_Trail___Long_Hill_Rd_.gpx',
        'USA',
        'Crotone',
        '',
        'Di Rocco salentino',
        1,
        19.3,
        70,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hop River Trail - Rockville Spur',
        0,
        '/static/gpx/052_Hop_River_Trail___Rockville_Spur.gpx',
        'USA',
        'Pesaro e Urbino',
        '',
        'Sesto Elogio lido',
        1.4,
        22.9,
        180,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Housatonic Rail Trail',
        2,
        '/static/gpx/053_Housatonic_Rail_Trail.gpx',
        'USA',
        'Vercelli',
        '',
        'Cerrato ligure',
        3.5,
        24.2,
        468,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Middletown Bikeway',
        1,
        '/static/gpx/054_Middletown_Bikeway.gpx',
        'USA',
        'Benevento',
        '',
        'Settimo Acario',
        3.1,
        24.1,
        1680,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattabesett Trolley Trail',
        2,
        '/static/gpx/055_Mattabesett_Trolley_Trail.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Guastella del friuli',
        2.2,
        26.9,
        840,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Moosup Valley State Park Trail',
        1,
        '/static/gpx/056_Moosup_Valley_State_Park_Trail.gpx',
        'USA',
        'Siracusa',
        '',
        'Verulo veneto',
        0.9,
        24.1,
        273,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinnebaug River Trail',
        0,
        '/static/gpx/057_Quinnebaug_River_Trail.gpx',
        'USA',
        'Enna',
        '',
        'Fulvia del friuli',
        1,
        5.9,
        66,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tracey Road Trail',
        2,
        '/static/gpx/058_Tracey_Road_Trail.gpx',
        'USA',
        'Gorizia',
        '',
        'Quarto Abdone',
        1,
        18.5,
        105,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Trolley Trail',
        1,
        '/static/gpx/059_Trolley_Trail.gpx',
        'USA',
        'Campobasso',
        '',
        'Stabile lido',
        1.6,
        13.2,
        280,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinnebaug Hatchery Trail',
        2,
        '/static/gpx/060_Quinnebaug_Hatchery_Trail.gpx',
        'USA',
        'Taranto',
        '',
        'Ascanio calabro',
        1.3,
        18.4,
        154,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hopeville Park Trail',
        2,
        '/static/gpx/061_Hopeville_Park_Trail.gpx',
        'USA',
        'Treviso',
        '',
        'Settimo Napoleone nell''emilia',
        1.4,
        24.9,
        240,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hopeville Park Path',
        2,
        '/static/gpx/062_Hopeville_Park_Path.gpx',
        'USA',
        'Venezia',
        '',
        'Venturelli a mare',
        0.8,
        16.3,
        50,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic Trail',
        2,
        '/static/gpx/063_Nehantic_Trail.gpx',
        'USA',
        'Belluno',
        '',
        'Di Somma calabro',
        1,
        20.7,
        42,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Camp Columbia Trail',
        1,
        '/static/gpx/064_Camp_Columbia_Trail.gpx',
        'USA',
        'Brescia',
        '',
        'Paganelli veneto',
        1.3,
        14.2,
        126,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shelton Land Trust Trail',
        0,
        '/static/gpx/065_Shelton_Land_Trust_Trail.gpx',
        'USA',
        'Prato',
        '',
        'Settimo Elsa',
        0.6,
        6.9,
        77,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Dinosaur Park Sidewalk',
        0,
        '/static/gpx/066_Dinosaur_Park_Sidewalk.gpx',
        'USA',
        'Crotone',
        '',
        'Asterio calabro',
        0.8,
        24.2,
        55,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Dinosaur Park Trail',
        0,
        '/static/gpx/067_Dinosaur_Park_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Borgo Lea umbro',
        1,
        7.3,
        24,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Access Road',
        1,
        '/static/gpx/068_Access_Road.gpx',
        'USA',
        'Venezia',
        '',
        'Anatolia salentino',
        0.9,
        7.6,
        75,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Day Pond Park Path',
        1,
        '/static/gpx/069_Day_Pond_Park_Path.gpx',
        'USA',
        'Benevento',
        '',
        'Settimo Miranda',
        1.4,
        21,
        231,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Day Pond Park Trail',
        0,
        '/static/gpx/070_Day_Pond_Park_Trail.gpx',
        'USA',
        'Caltanissetta',
        '',
        'Sesto Colomba veneto',
        1.3,
        28.8,
        624,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Salmon River Trail',
        0,
        '/static/gpx/071_Salmon_River_Trail.gpx',
        'USA',
        'Avellino',
        '',
        'Desiderato veneto',
        7.3,
        17.3,
        2338,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Salmon River Trial',
        0,
        '/static/gpx/072_Salmon_River_Trial.gpx',
        'USA',
        'Caltanissetta',
        '',
        'Borgo Esterina sardo',
        2.8,
        19.8,
        1370,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Dennis Hill Park Trail',
        0,
        '/static/gpx/073_Dennis_Hill_Park_Trail.gpx',
        'USA',
        'Catania',
        '',
        'Settimo Audace',
        2.2,
        10.8,
        264,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Railroad Trail',
        1,
        '/static/gpx/074_Railroad_Trail.gpx',
        'USA',
        'Imperia',
        '',
        'Borgo Basileo',
        1.3,
        13.4,
        104,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Gillette Castle Trail',
        0,
        '/static/gpx/075_Gillette_Castle_Trail.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Vissia del friuli',
        0.8,
        24.8,
        65,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kent Falls Park Path',
        1,
        '/static/gpx/076_Kent_Falls_Park_Path.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Cornelio sardo',
        1,
        5.2,
        30,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kent Falls Park Trail',
        2,
        '/static/gpx/077_Kent_Falls_Park_Trail.gpx',
        'USA',
        'Latina',
        '',
        'Pennestrì a mare',
        0.9,
        18.2,
        99,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Lovers Leap Park Trail',
        2,
        '/static/gpx/078_Lovers_Leap_Park_Trail.gpx',
        'USA',
        'Caserta',
        '',
        'Siriano terme',
        0.9,
        21.8,
        36,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Enders Forest Trail',
        2,
        '/static/gpx/079_Enders_Forest_Trail.gpx',
        'USA',
        'Firenze',
        '',
        'Eligibile a mare',
        1.2,
        24.9,
        77,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Gay City Park Path',
        1,
        '/static/gpx/080_Gay_City_Park_Path.gpx',
        'USA',
        'Bergamo',
        '',
        'Errera a mare',
        1.3,
        11.4,
        154,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Gay City Park Trail',
        1,
        '/static/gpx/081_Gay_City_Park_Trail.gpx',
        'USA',
        'Bergamo',
        '',
        'Sesto Vittoriano',
        1.9,
        18.2,
        345,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Split Rock Trail',
        1,
        '/static/gpx/082_Split_Rock_Trail.gpx',
        'USA',
        'Sassari',
        '',
        'Gloria lido',
        9.9,
        15.6,
        1320,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Gillette Castle Path',
        2,
        '/static/gpx/083_Gillette_Castle_Path.gpx',
        'USA',
        'Sassari',
        '',
        'Alboino a mare',
        0.6,
        17.7,
        26,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Great Pond Forest Trail',
        1,
        '/static/gpx/084_Great_Pond_Forest_Trail.gpx',
        'USA',
        'Parma',
        '',
        'San Gineto',
        1,
        18.6,
        285,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Haddam Meadows Park Trail',
        2,
        '/static/gpx/085_Haddam_Meadows_Park_Trail.gpx',
        'USA',
        'Lecce',
        '',
        'Quarto Casto',
        1.2,
        20.2,
        450,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Haley Farm Park Trail',
        0,
        '/static/gpx/086_Haley_Farm_Park_Trail.gpx',
        'USA',
        'Latina',
        '',
        'San Claudio sardo',
        0.6,
        18.1,
        36,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hammonasset Park Path',
        2,
        '/static/gpx/087_Hammonasset_Park_Path.gpx',
        'USA',
        'Pisa',
        '',
        'Borgo Maffeo',
        0.8,
        13.6,
        60,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nature Trail',
        2,
        '/static/gpx/088_Nature_Trail.gpx',
        'USA',
        'Cagliari',
        '',
        'San Eutalio',
        0.9,
        28.8,
        260,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hammonasset Bike Path',
        2,
        '/static/gpx/089_Hammonasset_Bike_Path.gpx',
        'USA',
        'Isernia',
        '',
        'Giunta sardo',
        0.8,
        11.3,
        36,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hammonasset Park Boardwalk',
        0,
        '/static/gpx/090_Hammonasset_Park_Boardwalk.gpx',
        'USA',
        'Belluno',
        '',
        'Quarto Rolando laziale',
        0.7,
        19.6,
        28,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Meigs Point Jetty',
        0,
        '/static/gpx/091_Meigs_Point_Jetty.gpx',
        'USA',
        'Medio Campidano',
        '',
        'Venerando veneto',
        0.8,
        20,
        104,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Willard Island Nature Trail',
        2,
        '/static/gpx/092_Willard_Island_Nature_Trail.gpx',
        'USA',
        'Savona',
        '',
        'Lo Presti veneto',
        2,
        27,
        375,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Moraine Nature Trail',
        1,
        '/static/gpx/093_Moraine_Nature_Trail.gpx',
        'USA',
        'Nuoro',
        '',
        'Simeoli salentino',
        1.6,
        16.5,
        390,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Haystack Park Trail',
        2,
        '/static/gpx/094_Haystack_Park_Trail.gpx',
        'USA',
        'Belluno',
        '',
        'Tammaro umbro',
        2.2,
        29.5,
        228,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Higganum Reservoir Park Trail',
        2,
        '/static/gpx/095_Higganum_Reservoir_Park_Trail.gpx',
        'USA',
        'Carbonia-Iglesias',
        '',
        'Tumbarello a mare',
        1.3,
        28.8,
        150,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Appalachian Trail',
        2,
        '/static/gpx/096_Appalachian_Trail.gpx',
        'USA',
        'Novara',
        '',
        'Liguori del friuli',
        2.7,
        18.9,
        455,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mohawk Trail',
        0,
        '/static/gpx/097_Mohawk_Trail.gpx',
        'USA',
        'Livorno',
        '',
        'San Aniello sardo',
        1.8,
        28.5,
        351,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pine Knob Loop',
        2,
        '/static/gpx/098_Pine_Knob_Loop.gpx',
        'USA',
        'Udine',
        '',
        'Tarso veneto',
        1,
        8.5,
        108,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Appalachian/Pine Knob Loop',
        2,
        '/static/gpx/099_Appalachian_Pine_Knob_Loop.gpx',
        'USA',
        'Bergamo',
        '',
        'Settimo Mimma',
        8.2,
        22.6,
        2568,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'White Mountain Trail',
        0,
        '/static/gpx/100_White_Mountain_Trail.gpx',
        'USA',
        'Cuneo',
        '',
        'Severi ligure',
        1,
        15.9,
        320,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'River Trail',
        1,
        '/static/gpx/101_River_Trail.gpx',
        'USA',
        'Pescara',
        '',
        'Falzone sardo',
        0.9,
        16.9,
        104,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hurd Park Trail',
        0,
        '/static/gpx/102_Hurd_Park_Trail.gpx',
        'USA',
        'Pordenone',
        '',
        'Sesto Ettore laziale',
        1.1,
        24.9,
        140,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hurd Park Path',
        0,
        '/static/gpx/103_Hurd_Park_Path.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Sesto Maccabeo',
        1.4,
        20.4,
        117,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Paugussett Trail',
        0,
        '/static/gpx/104_Paugussett_Trail.gpx',
        'USA',
        'Catanzaro',
        '',
        'Quarto Diodata lido',
        3.5,
        5.1,
        385,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Waterfall Trail',
        0,
        '/static/gpx/105_Waterfall_Trail.gpx',
        'USA',
        'Bolzano',
        '',
        'Debora umbro',
        0.6,
        7.4,
        84,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Paugussett Trail Connector',
        0,
        '/static/gpx/106_Paugussett_Trail_Connector.gpx',
        'USA',
        'Palermo',
        '',
        'Settimo Proserpina umbro',
        2.5,
        19.1,
        345,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Minetto Park Trail',
        1,
        '/static/gpx/107_Minetto_Park_Trail.gpx',
        'USA',
        'Imperia',
        '',
        'De Angelis lido',
        1.4,
        6.2,
        108,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Coincident Macedonia Brook Rd',
        2,
        '/static/gpx/108_Coincident_Macedonia_Brook_Rd.gpx',
        'USA',
        'Cremona',
        '',
        'D''Ippolito terme',
        0.8,
        11.5,
        24,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Coincident Weber Road',
        1,
        '/static/gpx/109_Coincident_Weber_Road.gpx',
        'USA',
        'Rieti',
        '',
        'Cecchi veneto',
        1.8,
        6.8,
        297,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Macedonia Ridge Trail',
        2,
        '/static/gpx/110_Macedonia_Ridge_Trail.gpx',
        'USA',
        'Cagliari',
        '',
        'Sesto Veridiana sardo',
        8.9,
        28.4,
        5558,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Cobble Mountain Trail',
        2,
        '/static/gpx/111_Cobble_Mountain_Trail.gpx',
        'USA',
        'Rimini',
        '',
        'Sesto Elimena',
        4.7,
        7.7,
        1464,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shenipsit Trail',
        2,
        '/static/gpx/112_Shenipsit_Trail.gpx',
        'USA',
        'Belluno',
        '',
        'Florina sardo',
        3.5,
        16.8,
        910,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Meshomasic Forest Trail',
        2,
        '/static/gpx/113_Meshomasic_Forest_Trail.gpx',
        'USA',
        'Firenze',
        '',
        'Candida veneto',
        1.3,
        19.7,
        130,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Crest Trail',
        0,
        '/static/gpx/114_Crest_Trail.gpx',
        'USA',
        'Monza e della Brianza',
        '',
        'Paolucci salentino',
        2.1,
        15.1,
        1260,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Campground Trail',
        0,
        '/static/gpx/115_Campground_Trail.gpx',
        'USA',
        'Udine',
        '',
        'Quarto Fidenziano del friuli',
        2.9,
        24.4,
        312,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Brook Trail',
        2,
        '/static/gpx/116_Brook_Trail.gpx',
        'USA',
        'Cuneo',
        '',
        'Nico calabro',
        4.3,
        29.7,
        816,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kettletown Park Trail',
        1,
        '/static/gpx/117_Kettletown_Park_Trail.gpx',
        'USA',
        'Palermo',
        '',
        'Quarto Paolo',
        0.7,
        29.4,
        50,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'North Ridge Trail',
        0,
        '/static/gpx/118_North_Ridge_Trail.gpx',
        'USA',
        'Ferrara',
        '',
        'Cacciapuoti calabro',
        0.8,
        20.1,
        180,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'North Ridge Loop Trail',
        1,
        '/static/gpx/119_North_Ridge_Loop_Trail.gpx',
        'USA',
        'Lucca',
        '',
        'Biasci umbro',
        8.4,
        9,
        1551,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Miller Brook Connector Trail',
        1,
        '/static/gpx/120_Miller_Brook_Connector_Trail.gpx',
        'USA',
        'Enna',
        '',
        'Landolfo umbro',
        1.1,
        25.2,
        96,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Miller Trail',
        0,
        '/static/gpx/121_Miller_Trail.gpx',
        'USA',
        'Brindisi',
        '',
        'Sesto Lisandro nell''emilia',
        8.8,
        11.1,
        1960,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Miller Trail Spur',
        1,
        '/static/gpx/122_Miller_Trail_Spur.gpx',
        'USA',
        'Siracusa',
        '',
        'Borgo Giacinta',
        2.1,
        12.4,
        270,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pomperaug Trail',
        2,
        '/static/gpx/123_Pomperaug_Trail.gpx',
        'USA',
        'Piacenza',
        '',
        'Capoccia del friuli',
        3.2,
        23.8,
        420,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Brook Trail Access',
        2,
        '/static/gpx/124_Brook_Trail_Access.gpx',
        'USA',
        'Brindisi',
        '',
        'Marinetta umbro',
        0.6,
        11.8,
        30,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Waramaug Lake Park Trail',
        1,
        '/static/gpx/125_Waramaug_Lake_Park_Trail.gpx',
        'USA',
        'Enna',
        '',
        'Borgo Marino',
        3.5,
        26.9,
        540,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Well Groomed Trail',
        1,
        '/static/gpx/126_Well_Groomed_Trail.gpx',
        'USA',
        'Cagliari',
        '',
        'Aurora del friuli',
        0.7,
        7.7,
        110,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mashamoquet Brook Park Trail',
        1,
        '/static/gpx/127_Mashamoquet_Brook_Park_Trail.gpx',
        'USA',
        'Cagliari',
        '',
        'Quarto Giuseppe',
        1.8,
        14.8,
        630,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shenipsit Trail Spur',
        0,
        '/static/gpx/128_Shenipsit_Trail_Spur.gpx',
        'USA',
        'Catanzaro',
        '',
        'Settimo Ildegarda',
        1,
        24.7,
        104,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shenipsit',
        0,
        '/static/gpx/129_Shenipsit.gpx',
        'USA',
        'Vibo Valentia',
        '',
        'San Zenebio',
        2.6,
        13,
        396,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nassahegon Forest Trail',
        1,
        '/static/gpx/130_Nassahegon_Forest_Trail.gpx',
        'USA',
        'Massa-Carrara',
        '',
        'Guerriero veneto',
        1,
        11.9,
        30,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tunxis Trail',
        2,
        '/static/gpx/131_Tunxis_Trail.gpx',
        'USA',
        'Arezzo',
        '',
        'Spanò umbro',
        1,
        27.1,
        26,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Black Spruce Bog Trail',
        1,
        '/static/gpx/132_Black_Spruce_Bog_Trail.gpx',
        'USA',
        'Pavia',
        '',
        'Iannucci ligure',
        2.1,
        28.5,
        594,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mohawk Forest Trail',
        2,
        '/static/gpx/133_Mohawk_Forest_Trail.gpx',
        'USA',
        'Rieti',
        '',
        'San Aldo',
        4.9,
        16.3,
        720,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ethan Allen Youth Trail',
        2,
        '/static/gpx/134_Ethan_Allen_Youth_Trail.gpx',
        'USA',
        'Treviso',
        '',
        'Settimo Mancio lido',
        1.5,
        19.4,
        165,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Punch Brook Trail',
        2,
        '/static/gpx/135_Punch_Brook_Trail.gpx',
        'USA',
        'Taranto',
        '',
        'San Simeone del friuli',
        1.2,
        27,
        120,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Red Cedar Lake Trail',
        2,
        '/static/gpx/136_Red_Cedar_Lake_Trail.gpx',
        'USA',
        'Rieti',
        '',
        'Gioconda sardo',
        2,
        13.8,
        728,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Under Mountain Trail',
        2,
        '/static/gpx/137_Under_Mountain_Trail.gpx',
        'USA',
        'Napoli',
        '',
        'San Romolo',
        0.8,
        13.6,
        50,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mount Tom Trail',
        2,
        '/static/gpx/138_Mount_Tom_Trail.gpx',
        'USA',
        'Padova',
        '',
        'Surano laziale',
        4.3,
        28.5,
        840,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Naugatuck Trail',
        0,
        '/static/gpx/139_Naugatuck_Trail.gpx',
        'USA',
        'Novara',
        '',
        'Sesto Sansone',
        5.5,
        18.7,
        616,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic Forest Trail',
        2,
        '/static/gpx/140_Nehantic_Forest_Trail.gpx',
        'USA',
        'Modena',
        '',
        'San Gosto a mare',
        2.9,
        17.4,
        403,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Naugatuck Forest Trail',
        1,
        '/static/gpx/141_Naugatuck_Forest_Trail.gpx',
        'USA',
        'Lodi',
        '',
        'Norma ligure',
        1.8,
        20.2,
        754,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Naugatuck Spur',
        2,
        '/static/gpx/142_Naugatuck_Spur.gpx',
        'USA',
        'Macerata',
        '',
        'Vascotto laziale',
        1.6,
        9.6,
        240,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Whitemore Trail',
        2,
        '/static/gpx/143_Whitemore_Trail.gpx',
        'USA',
        'Treviso',
        '',
        'Protasio salentino',
        3.9,
        6.1,
        910,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinnipiac Trail',
        2,
        '/static/gpx/144_Quinnipiac_Trail.gpx',
        'USA',
        'Ferrara',
        '',
        'Colmanno nell''emilia',
        4.8,
        22.8,
        1232,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic Forest Trai',
        0,
        '/static/gpx/145_Nehantic_Forest_Trai.gpx',
        'USA',
        'Caltanissetta',
        '',
        'Onorio sardo',
        1.6,
        10.3,
        132,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nepaug Forest Trail',
        2,
        '/static/gpx/146_Nepaug_Forest_Trail.gpx',
        'USA',
        'Pavia',
        '',
        'Settimo Timoteo ligure',
        1,
        25.7,
        52,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Naugatuck',
        1,
        '/static/gpx/147_Naugatuck.gpx',
        'USA',
        'Macerata',
        '',
        'Adalgiso umbro',
        3.6,
        27.4,
        370,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nyantaquit Trail',
        2,
        '/static/gpx/148_Nyantaquit_Trail.gpx',
        'USA',
        'Ancona',
        '',
        'Sesto Cristoforo',
        8.7,
        5.5,
        979,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tipping Rock Loop Trail',
        1,
        '/static/gpx/149_Tipping_Rock_Loop_Trail.gpx',
        'USA',
        'Brindisi',
        '',
        'Settimo Ildebrando laziale',
        2.2,
        20.1,
        198,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Valley Outlook Trail',
        1,
        '/static/gpx/150_Valley_Outlook_Trail.gpx',
        'USA',
        'Trento',
        '',
        'Baldo a mare',
        1.2,
        13,
        225,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shelter 4 Loop Trail',
        1,
        '/static/gpx/151_Shelter_4_Loop_Trail.gpx',
        'USA',
        'Rieti',
        '',
        'Donato umbro',
        1.1,
        24.7,
        273,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Osbornedale Park Trail',
        0,
        '/static/gpx/152_Osbornedale_Park_Trail.gpx',
        'USA',
        'Brindisi',
        '',
        'San Fazio',
        0.7,
        9.5,
        135,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Unnamed',
        0,
        '/static/gpx/153_Unnamed.gpx',
        'USA',
        'Sondrio',
        '',
        'Borgo Deodato calabro',
        0.8,
        25.6,
        135,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Paugnut Forest Trail',
        0,
        '/static/gpx/154_Paugnut_Forest_Trail.gpx',
        'USA',
        'Mantova',
        '',
        'Ragusa a mare',
        0.6,
        18.1,
        48,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Charles L Pack Trail',
        1,
        '/static/gpx/155_Charles_L_Pack_Trail.gpx',
        'USA',
        'Rieti',
        '',
        'Borgo Piersilvio calabro',
        1.8,
        23.6,
        360,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Peoples Forest Trail',
        1,
        '/static/gpx/156_Peoples_Forest_Trail.gpx',
        'USA',
        'Crotone',
        '',
        'Settimo Vittore',
        2.5,
        28.9,
        260,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Putnam Memorial Trail',
        2,
        '/static/gpx/157_Putnam_Memorial_Trail.gpx',
        'USA',
        'Potenza',
        '',
        'San Noemi veneto',
        0.7,
        27.4,
        182,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Platt Hill Park Trail',
        0,
        '/static/gpx/158_Platt_Hill_Park_Trail.gpx',
        'USA',
        'Enna',
        '',
        'Amone veneto',
        1.7,
        7.4,
        300,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Metacomet Trail',
        1,
        '/static/gpx/159_Metacomet_Trail.gpx',
        'USA',
        'Trento',
        '',
        'Sesto Iginio',
        0.7,
        13.9,
        50,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Metacomet Trail Bypass',
        1,
        '/static/gpx/160_Metacomet_Trail_Bypass.gpx',
        'USA',
        'Lodi',
        '',
        'Quarto Italo',
        0.9,
        20.4,
        84,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Penwood Park Trail',
        0,
        '/static/gpx/161_Penwood_Park_Trail.gpx',
        'USA',
        'Terni',
        '',
        'Pedrazzini calabro',
        8.4,
        5.5,
        2106,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quadick Park Path',
        0,
        '/static/gpx/162_Quadick_Park_Path.gpx',
        'USA',
        'Imperia',
        '',
        'Borgo Elaide ligure',
        0.7,
        10.2,
        90,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quadick Red Trail',
        0,
        '/static/gpx/163_Quadick_Red_Trail.gpx',
        'USA',
        'Cuneo',
        '',
        'Ivo veneto',
        3.7,
        13.7,
        686,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pootatuck Forest Trail',
        2,
        '/static/gpx/164_Pootatuck_Forest_Trail.gpx',
        'USA',
        'Imperia',
        '',
        'Sesto Fernanda',
        3.1,
        13.8,
        793,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'River Highland Park Trail',
        0,
        '/static/gpx/165_River_Highland_Park_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'Settimo Bonaldo umbro',
        0.7,
        23.7,
        156,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tunxis',
        2,
        '/static/gpx/166_Tunxis.gpx',
        'USA',
        'Udine',
        '',
        'Lorusso ligure',
        0.6,
        10.1,
        52,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Old Furnace Trail',
        1,
        '/static/gpx/167_Old_Furnace_Trail.gpx',
        'USA',
        'Trapani',
        '',
        'San Nives',
        0.8,
        14.3,
        182,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Old Furnace Park Trail',
        1,
        '/static/gpx/168_Old_Furnace_Park_Trail.gpx',
        'USA',
        'Catanzaro',
        '',
        'Sesto Amelia',
        1.5,
        27.7,
        132,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kestral Trail',
        1,
        '/static/gpx/169_Kestral_Trail.gpx',
        'USA',
        'Brindisi',
        '',
        'Quarto Eufebio terme',
        3.7,
        14.4,
        444,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Warbler Trail',
        1,
        '/static/gpx/170_Warbler_Trail.gpx',
        'USA',
        'Rieti',
        '',
        'Quarto Efrem salentino',
        2.5,
        6.6,
        870,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Muir Trail',
        2,
        '/static/gpx/171_Muir_Trail.gpx',
        'USA',
        'Chieti',
        '',
        'Adelina terme',
        8.6,
        18.7,
        1116,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shadow Pond Nature Trail',
        1,
        '/static/gpx/172_Shadow_Pond_Nature_Trail.gpx',
        'USA',
        'Bolzano',
        '',
        'Sesto Nadia calabro',
        1.4,
        23.9,
        364,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Jesse Gerard Trail',
        1,
        '/static/gpx/173_Jesse_Gerard_Trail.gpx',
        'USA',
        'Campobasso',
        '',
        'Carlino lido',
        1.2,
        24,
        555,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Robert Ross Trail',
        0,
        '/static/gpx/174_Robert_Ross_Trail.gpx',
        'USA',
        'Trieste',
        '',
        'San Fatima lido',
        5.1,
        28.5,
        1131,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Agnes Bowen Trail',
        1,
        '/static/gpx/175_Agnes_Bowen_Trail.gpx',
        'USA',
        'Reggio Calabria',
        '',
        'San Olimpio',
        0.9,
        8.5,
        33,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Elliot Bronson Trail',
        1,
        '/static/gpx/176_Elliot_Bronson_Trail.gpx',
        'USA',
        'Pescara',
        '',
        'San Pierluigi salentino',
        1.9,
        21.5,
        255,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Walt Landgraf Trail',
        2,
        '/static/gpx/177_Walt_Landgraf_Trail.gpx',
        'USA',
        'Fermo',
        '',
        'Borgo Lorella',
        5.1,
        24.1,
        741,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Squantz Pond Park Trail',
        1,
        '/static/gpx/178_Squantz_Pond_Park_Trail.gpx',
        'USA',
        'Rovigo',
        '',
        'Franzè del friuli',
        0.6,
        12.3,
        30,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Putnam Memorial Museum Trail',
        1,
        '/static/gpx/179_Putnam_Memorial_Museum_Trail.gpx',
        'USA',
        'Lodi',
        '',
        'Borgo Vezio terme',
        0.5,
        21.5,
        33,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinnipiac Park Trail',
        0,
        '/static/gpx/180_Quinnipiac_Park_Trail.gpx',
        'USA',
        'Ravenna',
        '',
        'San Fabiola',
        0.7,
        19,
        45,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Boardwalk',
        2,
        '/static/gpx/181_Boardwalk.gpx',
        'USA',
        'Vibo Valentia',
        '',
        'Settimo Respicio',
        0.7,
        14.2,
        77,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rocky Neck Park Sidewalk',
        2,
        '/static/gpx/182_Rocky_Neck_Park_Sidewalk.gpx',
        'USA',
        'Trento',
        '',
        'Quarto Raniero',
        1,
        10.3,
        28,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rocky Neck Park Path',
        1,
        '/static/gpx/183_Rocky_Neck_Park_Path.gpx',
        'USA',
        'Chieti',
        '',
        'San Vincenza terme',
        0.8,
        6.2,
        120,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rocky Neck Park Trail',
        0,
        '/static/gpx/184_Rocky_Neck_Park_Trail.gpx',
        'USA',
        'Biella',
        '',
        'Quarto Sante umbro',
        7.5,
        7.3,
        1020,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rope Swing',
        1,
        '/static/gpx/185_Rope_Swing.gpx',
        'USA',
        'L''Aquila',
        '',
        'Settimo Prassede',
        3.4,
        24.9,
        690,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sherwood Island Park Path',
        0,
        '/static/gpx/186_Sherwood_Island_Park_Path.gpx',
        'USA',
        'Reggio Calabria',
        '',
        'Settimo Cleo veneto',
        1,
        13.4,
        65,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sleeping Giant Park Trail',
        1,
        '/static/gpx/187_Sleeping_Giant_Park_Trail.gpx',
        'USA',
        'Milano',
        '',
        'Sesto Leonilda lido',
        2.6,
        19.6,
        270,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sherwood Island Nature Trail',
        0,
        '/static/gpx/188_Sherwood_Island_Nature_Trail.gpx',
        'USA',
        'Bolzano',
        '',
        'Borgo Secondiano',
        0.6,
        18.9,
        80,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sleeping Giant Park Path',
        2,
        '/static/gpx/189_Sleeping_Giant_Park_Path.gpx',
        'USA',
        'Ragusa',
        '',
        'Borgo Bambina terme',
        0.6,
        6.9,
        30,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tower Trail',
        0,
        '/static/gpx/190_Tower_Trail.gpx',
        'USA',
        'Roma',
        '',
        'San Auberto',
        1.3,
        28.5,
        180,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinnipiac Trail Spur',
        1,
        '/static/gpx/191_Quinnipiac_Trail_Spur.gpx',
        'USA',
        'Sondrio',
        '',
        'Spadoni del friuli',
        1,
        11.1,
        210,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Southford Falls Park Trail',
        0,
        '/static/gpx/192_Southford_Falls_Park_Trail.gpx',
        'USA',
        'Teramo',
        '',
        'Borgo Sabina',
        1.7,
        6.6,
        132,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tunxis Forest Trail',
        1,
        '/static/gpx/193_Tunxis_Forest_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Alano a mare',
        0.8,
        26.8,
        80,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sleeping Giant Trail',
        2,
        '/static/gpx/194_Sleeping_Giant_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'Totaro umbro',
        1.4,
        14.9,
        473,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Stratton Brook Park Path',
        2,
        '/static/gpx/195_Stratton_Brook_Park_Path.gpx',
        'USA',
        'Imperia',
        '',
        'Borgo Guglielmo',
        1.3,
        14.4,
        144,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bike Trail',
        2,
        '/static/gpx/196_Bike_Trail.gpx',
        'USA',
        'Bolzano',
        '',
        'Alida laziale',
        2.1,
        22.8,
        187,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Stratton Brook Park Trail',
        2,
        '/static/gpx/197_Stratton_Brook_Park_Trail.gpx',
        'USA',
        'Cuneo',
        '',
        'Settimo Parmenio',
        0.7,
        6.1,
        182,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Simsbury Park Trail',
        0,
        '/static/gpx/198_Simsbury_Park_Trail.gpx',
        'USA',
        'Salerno',
        '',
        'Paolicelli sardo',
        1.5,
        22.6,
        170,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Wolcott Trail',
        1,
        '/static/gpx/199_Wolcott_Trail.gpx',
        'USA',
        'Udine',
        '',
        'Lezzi del friuli',
        1,
        21.2,
        180,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Madden Fyler Pond Trail',
        0,
        '/static/gpx/200_Madden_Fyler_Pond_Trail.gpx',
        'USA',
        'Palermo',
        '',
        'San Venerando',
        6,
        13.2,
        1170,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sunny Brook Park Trail',
        0,
        '/static/gpx/201_Sunny_Brook_Park_Trail.gpx',
        'USA',
        'Pescara',
        '',
        'Cristiana lido',
        5.8,
        8.6,
        900,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Fadoir Spring Trail',
        0,
        '/static/gpx/202_Fadoir_Spring_Trail.gpx',
        'USA',
        'Siracusa',
        '',
        'Sesto Lazzaro',
        1.7,
        17.6,
        165,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Fadoir Trail',
        1,
        '/static/gpx/203_Fadoir_Trail.gpx',
        'USA',
        'Verbano-Cusio-Ossola',
        '',
        'Sesto Raimondo lido',
        0.8,
        20.4,
        70,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Walnut Mountain Trail',
        1,
        '/static/gpx/204_Walnut_Mountain_Trail.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Settimo Bonaldo veneto',
        4.1,
        14.3,
        611,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Wolcott',
        2,
        '/static/gpx/205_Wolcott.gpx',
        'USA',
        'Alessandria',
        '',
        'Addari lido',
        0.8,
        16.9,
        22,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Old Metacomet Trail',
        1,
        '/static/gpx/206_Old_Metacomet_Trail.gpx',
        'USA',
        'Aosta',
        '',
        'Pipitone sardo',
        2.9,
        28.8,
        1665,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Talcott Mountain Park Trail',
        2,
        '/static/gpx/207_Talcott_Mountain_Park_Trail.gpx',
        'USA',
        'Aosta',
        '',
        'Sesto Maffeo',
        3.1,
        8.5,
        880,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Falls Brook Trail',
        1,
        '/static/gpx/208_Falls_Brook_Trail.gpx',
        'USA',
        'Pisa',
        '',
        'Franco del friuli',
        3.4,
        28.1,
        2060,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Whittemore Glen Trail',
        2,
        '/static/gpx/209_Whittemore_Glen_Trail.gpx',
        'USA',
        'Novara',
        '',
        'Bortot del friuli',
        0.9,
        15.9,
        105,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Wharton Brook Park Trail',
        0,
        '/static/gpx/210_Wharton_Brook_Park_Trail.gpx',
        'USA',
        'Novara',
        '',
        'Stefania sardo',
        0.9,
        19,
        88,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Larkin Bridle Trail',
        2,
        '/static/gpx/211_Larkin_Bridle_Trail.gpx',
        'USA',
        'Crotone',
        '',
        'San Ester del friuli',
        3.2,
        12.7,
        6810,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bluff Point Bike Path',
        2,
        '/static/gpx/212_Bluff_Point_Bike_Path.gpx',
        'USA',
        'Arezzo',
        '',
        'Quarto Alvaro',
        0.8,
        22.6,
        252,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bluff Point Trail',
        1,
        '/static/gpx/213_Bluff_Point_Trail.gpx',
        'USA',
        'Trento',
        '',
        'Sesto Antonello',
        0.7,
        8.9,
        112,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hrt - Main Street Spur',
        0,
        '/static/gpx/214_Hrt___Main_Street_Spur.gpx',
        'USA',
        'Teramo',
        '',
        'Eros terme',
        0.8,
        6.2,
        228,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Laurel Brook Trail',
        2,
        '/static/gpx/215_Laurel_Brook_Trail.gpx',
        'USA',
        'Salerno',
        '',
        'San Dina calabro',
        3.9,
        26.5,
        780,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Wadsworth Falls Park Trail',
        2,
        '/static/gpx/216_Wadsworth_Falls_Park_Trail.gpx',
        'USA',
        'Foggia',
        '',
        'Prospera veneto',
        0.6,
        11.4,
        77,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'White Birch Trail',
        2,
        '/static/gpx/217_White_Birch_Trail.gpx',
        'USA',
        'Campobasso',
        '',
        'Gentili lido',
        0.8,
        25.8,
        154,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Red Cedar Trail',
        2,
        '/static/gpx/218_Red_Cedar_Trail.gpx',
        'USA',
        'Caserta',
        '',
        'Athos terme',
        3.7,
        20.5,
        429,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Little Falls Trail',
        2,
        '/static/gpx/219_Little_Falls_Trail.gpx',
        'USA',
        'Verona',
        '',
        'Sesto Oscar lido',
        4.6,
        11.2,
        624,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Deer Trail',
        2,
        '/static/gpx/220_Deer_Trail.gpx',
        'USA',
        'L''Aquila',
        '',
        'Avola salentino',
        2.3,
        5.4,
        231,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rockfall Land Trust Trail',
        2,
        '/static/gpx/221_Rockfall_Land_Trust_Trail.gpx',
        'USA',
        'Bolzano',
        '',
        'Errera ligure',
        0.7,
        13.1,
        210,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bridge Trail',
        2,
        '/static/gpx/222_Bridge_Trail.gpx',
        'USA',
        'Ragusa',
        '',
        'Salustio a mare',
        1.4,
        13.9,
        182,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Main Trail',
        2,
        '/static/gpx/223_Main_Trail.gpx',
        'USA',
        'Matera',
        '',
        'Perin umbro',
        1,
        20.6,
        40,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'American Legion Forest Trail',
        2,
        '/static/gpx/224_American_Legion_Forest_Trail.gpx',
        'USA',
        'Foggia',
        '',
        'San Selvaggia',
        0.8,
        14.1,
        165,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Turkey Vultures Ledges Trail',
        2,
        '/static/gpx/225_Turkey_Vultures_Ledges_Trail.gpx',
        'USA',
        'Lecco',
        '',
        'Doda terme',
        5.2,
        15.2,
        1185,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Henry R Buck Trail',
        2,
        '/static/gpx/226_Henry_R_Buck_Trail.gpx',
        'USA',
        'Piacenza',
        '',
        'Quarto Santo a mare',
        5.4,
        25.1,
        5148,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mashapaug Pond View Trail',
        2,
        '/static/gpx/227_Mashapaug_Pond_View_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'Quarto Valeria',
        1.5,
        22.4,
        140,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bigelow Hollow Park Trail',
        2,
        '/static/gpx/228_Bigelow_Hollow_Park_Trail.gpx',
        'USA',
        'Medio Campidano',
        '',
        'Fulberto sardo',
        2,
        21.8,
        260,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Breakneck Pond View Trail',
        2,
        '/static/gpx/229_Breakneck_Pond_View_Trail.gpx',
        'USA',
        'Pordenone',
        '',
        'Settimo Vanda del friuli',
        5.1,
        29.2,
        2398,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'East Ridge Trail',
        2,
        '/static/gpx/230_East_Ridge_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'D''Amato terme',
        1.2,
        9.4,
        176,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bigelow Pond Loop Trail',
        2,
        '/static/gpx/231_Bigelow_Pond_Loop_Trail.gpx',
        'USA',
        'Teramo',
        '',
        'Amelia umbro',
        4.6,
        13,
        700,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ridge Trail',
        2,
        '/static/gpx/232_Ridge_Trail.gpx',
        'USA',
        'Enna',
        '',
        'Franchini calabro',
        1,
        26.5,
        84,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nipmuck Trail',
        2,
        '/static/gpx/233_Nipmuck_Trail.gpx',
        'USA',
        'Perugia',
        '',
        'Provenzano a mare',
        3.9,
        6.3,
        611,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattatuck Trail',
        2,
        '/static/gpx/234_Mattatuck_Trail.gpx',
        'USA',
        'Messina',
        '',
        'Laurentino del friuli',
        1,
        13.9,
        143,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Black Rock Park Trail',
        2,
        '/static/gpx/235_Black_Rock_Park_Trail.gpx',
        'USA',
        'Bologna',
        '',
        'Abibo lido',
        0.6,
        18.2,
        48,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Poquonnock River Walk',
        1,
        '/static/gpx/236_Poquonnock_River_Walk.gpx',
        'USA',
        'Sondrio',
        '',
        'Gasser del friuli',
        3.6,
        8.6,
        600,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kempf & Shenipsit Trail',
        0,
        '/static/gpx/237_Kempf___Shenipsit_Trail.gpx',
        'USA',
        'Campobasso',
        '',
        'Altea a mare',
        0.9,
        15,
        350,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kempf Trail',
        1,
        '/static/gpx/238_Kempf_Trail.gpx',
        'USA',
        'La Spezia',
        '',
        'San Agape laziale',
        1.1,
        14.3,
        168,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Railroad Bed',
        1,
        '/static/gpx/239_Railroad_Bed.gpx',
        'USA',
        'Medio Campidano',
        '',
        'Natale laziale',
        0.8,
        22.2,
        26,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mohegan Trail',
        1,
        '/static/gpx/240_Mohegan_Trail.gpx',
        'USA',
        'Benevento',
        '',
        'Esuperio a mare',
        1.1,
        26.6,
        98,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Burr Pond Park Trail',
        1,
        '/static/gpx/241_Burr_Pond_Park_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'Baldini nell''emilia',
        1.9,
        27.3,
        140,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Burr Pond Park Path',
        2,
        '/static/gpx/242_Burr_Pond_Park_Path.gpx',
        'USA',
        'Cosenza',
        '',
        'Pisu nell''emilia',
        0.5,
        27.6,
        60,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Campbell Falls Trail',
        0,
        '/static/gpx/243_Campbell_Falls_Trail.gpx',
        'USA',
        'Alessandria',
        '',
        'Sesto Gentile',
        0.8,
        29.4,
        100,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Deep Woods Trail',
        2,
        '/static/gpx/244_Deep_Woods_Trail.gpx',
        'USA',
        'Roma',
        '',
        'San Gilda umbro',
        1.3,
        19,
        450,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chimney Trail',
        2,
        '/static/gpx/245_Chimney_Trail.gpx',
        'USA',
        'Cremona',
        '',
        'Sesto Appia',
        6,
        10.4,
        1274,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chimney Connector Trail',
        2,
        '/static/gpx/246_Chimney_Connector_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'Settimo Tosco nell''emilia',
        1.1,
        15.8,
        299,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'East Woods Trail',
        2,
        '/static/gpx/247_East_Woods_Trail.gpx',
        'USA',
        'Lucca',
        '',
        'Ave del friuli',
        2.2,
        7.7,
        600,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'East Woods Connector Trail',
        2,
        '/static/gpx/248_East_Woods_Connector_Trail.gpx',
        'USA',
        'Cuneo',
        '',
        'Abbrescia laziale',
        1.7,
        24.2,
        180,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Covered Bridge Connector Trail',
        2,
        '/static/gpx/249_Covered_Bridge_Connector_Trail.gpx',
        'USA',
        'Milano',
        '',
        'Bartolomei del friuli',
        0.6,
        14.5,
        44,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Covered Bridge Trail',
        2,
        '/static/gpx/250_Covered_Bridge_Trail.gpx',
        'USA',
        'Viterbo',
        '',
        'Mauro umbro',
        1.2,
        12.2,
        518,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Lookout Trail',
        2,
        '/static/gpx/251_Lookout_Trail.gpx',
        'USA',
        'Salerno',
        '',
        'Quarto Birino veneto',
        8,
        9.4,
        1131,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chatfield Hollow Park Trail',
        2,
        '/static/gpx/252_Chatfield_Hollow_Park_Trail.gpx',
        'USA',
        'Rieti',
        '',
        'Asterio salentino',
        0.9,
        11.1,
        50,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Lookout Spur Trail',
        2,
        '/static/gpx/253_Lookout_Spur_Trail.gpx',
        'USA',
        'Caserta',
        '',
        'Lippolis umbro',
        0.9,
        13.1,
        144,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chimney Spur Trail',
        2,
        '/static/gpx/254_Chimney_Spur_Trail.gpx',
        'USA',
        'Pescara',
        '',
        'Minniti salentino',
        2.2,
        24.5,
        319,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Deep Woods Access Trail',
        2,
        '/static/gpx/255_Deep_Woods_Access_Trail.gpx',
        'USA',
        'Savona',
        '',
        'Di Carlo calabro',
        1,
        26.7,
        70,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'West Crest Trail',
        2,
        '/static/gpx/256_West_Crest_Trail.gpx',
        'USA',
        'Potenza',
        '',
        'Borgo Beniamina',
        4.1,
        14.8,
        429,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chatfield Park Path',
        2,
        '/static/gpx/257_Chatfield_Park_Path.gpx',
        'USA',
        'Prato',
        '',
        'Quarto Corrado',
        0.8,
        24.2,
        196,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pond Trail',
        2,
        '/static/gpx/258_Pond_Trail.gpx',
        'USA',
        'Lecce',
        '',
        'Cherubini veneto',
        6.9,
        19.5,
        3345,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Paul F Wildermann',
        0,
        '/static/gpx/259_Paul_F_Wildermann.gpx',
        'USA',
        'Frosinone',
        '',
        'Borgo Odorico',
        0.6,
        23.9,
        105,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Cockaponset Forest Path',
        2,
        '/static/gpx/260_Cockaponset_Forest_Path.gpx',
        'USA',
        'Catanzaro',
        '',
        'Cardinale a mare',
        0.9,
        24.8,
        60,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kay Fullerton Trail',
        2,
        '/static/gpx/261_Kay_Fullerton_Trail.gpx',
        'USA',
        'Agrigento',
        '',
        'Sesto Otello',
        0.8,
        28.7,
        56,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinimay Trail',
        0,
        '/static/gpx/262_Quinimay_Trail.gpx',
        'USA',
        'Biella',
        '',
        'Sesto Fiammetta',
        4.7,
        28.5,
        855,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Cowboy Way Trail',
        2,
        '/static/gpx/263_Cowboy_Way_Trail.gpx',
        'USA',
        'Venezia',
        '',
        'Cornelio salentino',
        2.2,
        29.8,
        330,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Muck Rock Road Trail',
        2,
        '/static/gpx/264_Muck_Rock_Road_Trail.gpx',
        'USA',
        'Messina',
        '',
        'Borgo Savina',
        3.3,
        21.8,
        996,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Weber Road Trail',
        2,
        '/static/gpx/265_Weber_Road_Trail.gpx',
        'USA',
        'Como',
        '',
        'San Eufemia',
        2.2,
        12,
        322,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Beechnut Bog Trail',
        2,
        '/static/gpx/266_Beechnut_Bog_Trail.gpx',
        'USA',
        'Caltanissetta',
        '',
        'Settimo Antigone terme',
        0.9,
        10,
        112,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Wood Road Trail',
        2,
        '/static/gpx/267_Wood_Road_Trail.gpx',
        'USA',
        'Avellino',
        '',
        'Settimo Mercurio',
        1.3,
        13.2,
        154,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bumpy Hill Road Trail',
        2,
        '/static/gpx/268_Bumpy_Hill_Road_Trail.gpx',
        'USA',
        'Campobasso',
        '',
        'Rosalia salentino',
        1.5,
        13.3,
        120,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kristens Way Trail',
        2,
        '/static/gpx/269_Kristens_Way_Trail.gpx',
        'USA',
        'Napoli',
        '',
        'Sesto Tommaso',
        4.3,
        23.2,
        720,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Messerschmidt Lane Trail',
        2,
        '/static/gpx/270_Messerschmidt_Lane_Trail.gpx',
        'USA',
        'Piacenza',
        '',
        'Giove lido',
        0.7,
        15.4,
        66,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tower Hill Connector Trail',
        2,
        '/static/gpx/271_Tower_Hill_Connector_Trail.gpx',
        'USA',
        'Genova',
        '',
        'Geremia ligure',
        4.4,
        28.1,
        720,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattabesset Trail',
        2,
        '/static/gpx/272_Mattabesset_Trail.gpx',
        'USA',
        'Taranto',
        '',
        'Borgo Zetico',
        8,
        16,
        1806,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattabasset Trail',
        2,
        '/static/gpx/273_Mattabasset_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'Ferrero a mare',
        1.4,
        17.7,
        140,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Old Mattebesset Trail',
        2,
        '/static/gpx/274_Old_Mattebesset_Trail.gpx',
        'USA',
        'Palermo',
        '',
        'Erberto sardo',
        7.9,
        27.4,
        1770,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Huntington Park Trail',
        2,
        '/static/gpx/275_Huntington_Park_Trail.gpx',
        'USA',
        'Firenze',
        '',
        'Sesto Delia',
        1.7,
        18.7,
        588,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Huntington Ridge Trail',
        2,
        '/static/gpx/276_Huntington_Ridge_Trail.gpx',
        'USA',
        'Napoli',
        '',
        'Masucci nell''emilia',
        7,
        8.4,
        1050,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Aspetuck Valley Trail',
        2,
        '/static/gpx/277_Aspetuck_Valley_Trail.gpx',
        'USA',
        'Siena',
        '',
        'Settimo Archippo',
        1.3,
        5.7,
        300,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Vista Trail',
        2,
        '/static/gpx/278_Vista_Trail.gpx',
        'USA',
        'Lucca',
        '',
        'San Annunziata',
        1.4,
        5,
        168,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Devils Hopyard Park Trail',
        2,
        '/static/gpx/279_Devils_Hopyard_Park_Trail.gpx',
        'USA',
        'Pavia',
        '',
        'Borgo Desiderio',
        0.8,
        26.5,
        108,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Witch Hazel/Millington Trail',
        2,
        '/static/gpx/280_Witch_Hazel_Millington_Trail.gpx',
        'USA',
        'Catanzaro',
        '',
        'Meo calabro',
        2.1,
        27.7,
        392,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Millington Trail',
        2,
        '/static/gpx/281_Millington_Trail.gpx',
        'USA',
        'Mantova',
        '',
        'Borgo Radolfo',
        2.1,
        8.7,
        351,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Loop Trail',
        2,
        '/static/gpx/282_Loop_Trail.gpx',
        'USA',
        'Vibo Valentia',
        '',
        'Sesto Mercurio',
        0.8,
        26.1,
        300,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Witch Hazel Trail',
        2,
        '/static/gpx/283_Witch_Hazel_Trail.gpx',
        'USA',
        'Cagliari',
        '',
        'Settimo Vittoriano sardo',
        6.4,
        9.4,
        1596,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Woodcutters Trail',
        2,
        '/static/gpx/284_Woodcutters_Trail.gpx',
        'USA',
        'Milano',
        '',
        'Quarto Sara',
        8,
        21.4,
        800,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chapman Falls Trail',
        2,
        '/static/gpx/285_Chapman_Falls_Trail.gpx',
        'USA',
        'Ravenna',
        '',
        'Luigi lido',
        1.5,
        21.3,
        165,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Devils Oven Spur Trail',
        2,
        '/static/gpx/286_Devils_Oven_Spur_Trail.gpx',
        'USA',
        'Gorizia',
        '',
        'San Aristide',
        0.7,
        20.7,
        110,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Maxs Trail',
        2,
        '/static/gpx/287_Maxs_Trail.gpx',
        'USA',
        'Bolzano',
        '',
        'Borgo Alfreda',
        9.1,
        14.3,
        2453,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Machimoodus Park Trail',
        2,
        '/static/gpx/288_Machimoodus_Park_Trail.gpx',
        'USA',
        'Mantova',
        '',
        'San Orlando',
        1.1,
        17.4,
        78,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Fishermans Trail',
        0,
        '/static/gpx/289_Fishermans_Trail.gpx',
        'USA',
        'Pordenone',
        '',
        'Liuzzi salentino',
        1.4,
        22.2,
        130,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ccc Trail',
        2,
        '/static/gpx/290_Ccc_Trail.gpx',
        'USA',
        'Reggio Calabria',
        '',
        'San Alcina calabro',
        2.3,
        18.5,
        2882,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Natchaug Trail',
        2,
        '/static/gpx/291_Natchaug_Trail.gpx',
        'USA',
        'Matera',
        '',
        'Borgo Ermilo',
        5.2,
        10.9,
        924,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Natchaug Forest Trail',
        2,
        '/static/gpx/292_Natchaug_Forest_Trail.gpx',
        'USA',
        'Venezia',
        '',
        'Borgo Giocondo lido',
        0.6,
        13.2,
        60,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Goodwin Forest Trail',
        2,
        '/static/gpx/293_Goodwin_Forest_Trail.gpx',
        'USA',
        'Teramo',
        '',
        'Sesto Pacifico',
        1.4,
        12.6,
        375,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pine Acres Pond Trail',
        2,
        '/static/gpx/294_Pine_Acres_Pond_Trail.gpx',
        'USA',
        'Prato',
        '',
        'Cataldo ligure',
        4.4,
        27.9,
        645,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Brown Hill Pond Trail',
        2,
        '/static/gpx/295_Brown_Hill_Pond_Trail.gpx',
        'USA',
        'Savona',
        '',
        'San Frontiniano terme',
        1.4,
        12.4,
        252,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Yellow White Loop Trail',
        2,
        '/static/gpx/296_Yellow_White_Loop_Trail.gpx',
        'USA',
        'Torino',
        '',
        'San Remondo lido',
        1.9,
        8.7,
        247,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Red Yellow Connector Trail',
        2,
        '/static/gpx/297_Red_Yellow_Connector_Trail.gpx',
        'USA',
        'Ragusa',
        '',
        'Sesto Ultimo',
        3.1,
        26.2,
        975,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Governor''S Island Trail',
        2,
        '/static/gpx/298_Governor_S_Island_Trail.gpx',
        'USA',
        'Como',
        '',
        'Borgo Querano',
        6.3,
        13.4,
        1188,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Goodwin Foresttrail',
        2,
        '/static/gpx/299_Goodwin_Foresttrail.gpx',
        'USA',
        'Varese',
        '',
        'Argo calabro',
        0.7,
        25.8,
        156,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Forest Discovery Trail',
        2,
        '/static/gpx/300_Forest_Discovery_Trail.gpx',
        'USA',
        'Olbia-Tempio',
        '',
        'Consolata calabro',
        1,
        8.1,
        187,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Goodwin Heritage Trail',
        2,
        '/static/gpx/301_Goodwin_Heritage_Trail.gpx',
        'USA',
        'Salerno',
        '',
        'Bartolo umbro',
        0.6,
        24.7,
        70,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Crest',
        2,
        '/static/gpx/302_Crest.gpx',
        'USA',
        'Oristano',
        '',
        'Quarto Alceste calabro',
        4,
        15.4,
        418,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mansfield Hollow Park Trail',
        0,
        '/static/gpx/303_Mansfield_Hollow_Park_Trail.gpx',
        'USA',
        'Sondrio',
        '',
        'Quarto Carmela sardo',
        8.8,
        27.2,
        880,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nipmuck Trail - East Branch',
        2,
        '/static/gpx/304_Nipmuck_Trail___East_Branch.gpx',
        'USA',
        'Verona',
        '',
        'Antea calabro',
        3.1,
        8.7,
        374,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nipmuck Alternate',
        0,
        '/static/gpx/305_Nipmuck_Alternate.gpx',
        'USA',
        'Salerno',
        '',
        'Viviana veneto',
        7.4,
        26.7,
        1925,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mashamoquet Brook Nature Trail',
        1,
        '/static/gpx/306_Mashamoquet_Brook_Nature_Trail.gpx',
        'USA',
        'Rieti',
        '',
        'Quarto Elita',
        0.8,
        24.7,
        50,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nipmuck Forest Trail',
        2,
        '/static/gpx/307_Nipmuck_Forest_Trail.gpx',
        'USA',
        'Pavia',
        '',
        'Niceforo salentino',
        2,
        13.4,
        210,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Morey Pond Trail',
        2,
        '/static/gpx/308_Morey_Pond_Trail.gpx',
        'USA',
        'Mantova',
        '',
        'San Fatima',
        0.9,
        26.8,
        120,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nipmuck Foreat Trail',
        2,
        '/static/gpx/309_Nipmuck_Foreat_Trail.gpx',
        'USA',
        'Ravenna',
        '',
        'Feliciano nell''emilia',
        1.9,
        5.1,
        247,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pharisee Rock Trail',
        2,
        '/static/gpx/310_Pharisee_Rock_Trail.gpx',
        'USA',
        'Rieti',
        '',
        'Carlucci a mare',
        3.1,
        28.4,
        649,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug Forest Trail',
        2,
        '/static/gpx/311_Pachaug_Forest_Trail.gpx',
        'USA',
        'Biella',
        '',
        'Manca lido',
        1.4,
        11,
        280,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug Trail',
        2,
        '/static/gpx/312_Pachaug_Trail.gpx',
        'USA',
        'Brescia',
        '',
        'Carbon sardo',
        4.1,
        7.3,
        480,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Canonicus Trail',
        2,
        '/static/gpx/313_Canonicus_Trail.gpx',
        'USA',
        'Napoli',
        '',
        'Settimo Beata',
        4.4,
        17.1,
        790,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug',
        2,
        '/static/gpx/314_Pachaug.gpx',
        'USA',
        'Vibo Valentia',
        '',
        'Pecora laziale',
        0.8,
        23.9,
        28,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Laurel Loop Trail',
        2,
        '/static/gpx/315_Laurel_Loop_Trail.gpx',
        'USA',
        'Reggio Emilia',
        '',
        'Turchi umbro',
        2.5,
        15.8,
        500,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug/Nehantic Connector',
        2,
        '/static/gpx/316_Pachaug_Nehantic_Connector.gpx',
        'USA',
        'Catania',
        '',
        'Loiacono laziale',
        1.1,
        26.2,
        108,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug/Tippecansett Connector',
        2,
        '/static/gpx/317_Pachaug_Tippecansett_Connector.gpx',
        'USA',
        'Fermo',
        '',
        'Borgo Massimo',
        2.6,
        28.5,
        406,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic/Pachaug Connector',
        2,
        '/static/gpx/318_Nehantic_Pachaug_Connector.gpx',
        'USA',
        'Sassari',
        '',
        'Manica calabro',
        1.9,
        23.9,
        270,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinebaug/Pachaug Connector',
        2,
        '/static/gpx/319_Quinebaug_Pachaug_Connector.gpx',
        'USA',
        'Modena',
        '',
        'Giandomenico umbro',
        4.9,
        19.7,
        1534,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinebaug Trail',
        2,
        '/static/gpx/320_Quinebaug_Trail.gpx',
        'USA',
        'Cosenza',
        '',
        'San Demetrio',
        0.7,
        12.6,
        56,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug/Narragansett Connector',
        2,
        '/static/gpx/321_Pachaug_Narragansett_Connector.gpx',
        'USA',
        'Pavia',
        '',
        'Guerriero salentino',
        2.5,
        22.6,
        1027,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Narragansett Trail',
        2,
        '/static/gpx/322_Narragansett_Trail.gpx',
        'USA',
        'Arezzo',
        '',
        'Sesto Carla',
        0.8,
        21.3,
        90,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Green Falls Loop Trail',
        2,
        '/static/gpx/323_Green_Falls_Loop_Trail.gpx',
        'USA',
        'Lecco',
        '',
        'Settimo Giacobbe',
        2.8,
        7.9,
        1027,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Green Falls Water Access Trail',
        2,
        '/static/gpx/324_Green_Falls_Water_Access_Trail.gpx',
        'USA',
        'Potenza',
        '',
        'Giovannetti del friuli',
        0.8,
        6.9,
        121,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Freeman Trail',
        2,
        '/static/gpx/325_Freeman_Trail.gpx',
        'USA',
        'Ragusa',
        '',
        'Vulmaro a mare',
        0.9,
        14.4,
        70,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tippecansett Trail',
        2,
        '/static/gpx/326_Tippecansett_Trail.gpx',
        'USA',
        'Matera',
        '',
        'Zoe sardo',
        4.1,
        13.3,
        507,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tippecansett/Freeman Trail',
        2,
        '/static/gpx/327_Tippecansett_Freeman_Trail.gpx',
        'USA',
        'Pistoia',
        '',
        'Santangelo salentino',
        1.8,
        26.3,
        210,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Green Falls Pond Trail',
        1,
        '/static/gpx/328_Green_Falls_Pond_Trail.gpx',
        'USA',
        'Asti',
        '',
        'Borgo Lidio terme',
        2,
        20.3,
        273,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic/Pachaug Trail',
        2,
        '/static/gpx/329_Nehantic_Pachaug_Trail.gpx',
        'USA',
        'Teramo',
        '',
        'Addis lido',
        2.8,
        13.3,
        350,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Phillips Pond Spur Trail',
        2,
        '/static/gpx/330_Phillips_Pond_Spur_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Chiacchio sardo',
        2.8,
        25.2,
        705,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinebaug/Nehantic Connector',
        2,
        '/static/gpx/331_Quinebaug_Nehantic_Connector.gpx',
        'USA',
        'Roma',
        '',
        'Quarto Fiore',
        1.1,
        14.6,
        120,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic/Quinebaug Connector',
        2,
        '/static/gpx/332_Nehantic_Quinebaug_Connector.gpx',
        'USA',
        'Lecco',
        '',
        'San Tranquillo ligure',
        1.8,
        21.5,
        154,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Patagansett Trail',
        2,
        '/static/gpx/333_Patagansett_Trail.gpx',
        'USA',
        'Pordenone',
        '',
        'Tiziana nell''emilia',
        0.9,
        27.1,
        84,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Paugussett Forest Trail',
        2,
        '/static/gpx/334_Paugussett_Forest_Trail.gpx',
        'USA',
        'Avellino',
        '',
        'San Orlando',
        4.9,
        10.8,
        590,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Zoar Trail',
        2,
        '/static/gpx/335_Zoar_Trail.gpx',
        'USA',
        'Taranto',
        '',
        'Bonanni umbro',
        0.7,
        15.4,
        120,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Lillinonah Trail',
        2,
        '/static/gpx/336_Lillinonah_Trail.gpx',
        'USA',
        'Teramo',
        '',
        'Pennestrì laziale',
        0.9,
        22,
        392,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Zoar Trail (Old)',
        2,
        '/static/gpx/337_Zoar_Trail__Old_.gpx',
        'USA',
        'Asti',
        '',
        'Moretto lido',
        2.1,
        27.7,
        408,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Upper Gussy Trail',
        0,
        '/static/gpx/338_Upper_Gussy_Trail.gpx',
        'USA',
        'Olbia-Tempio',
        '',
        'San Fernanda',
        5.4,
        24.4,
        588,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pierrepont Park Trail',
        2,
        '/static/gpx/339_Pierrepont_Park_Trail.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Borgo Addolorata',
        1.9,
        17.9,
        377,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shenipsit Forest Trail',
        2,
        '/static/gpx/340_Shenipsit_Forest_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'Quarto Cunegonda umbro',
        1.8,
        6.5,
        195,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quary Trail',
        2,
        '/static/gpx/341_Quary_Trail.gpx',
        'USA',
        'Monza e della Brianza',
        '',
        'Borgo Perseo calabro',
        3.9,
        27.8,
        602,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shenipsit Forest Road',
        2,
        '/static/gpx/342_Shenipsit_Forest_Road.gpx',
        'USA',
        'Firenze',
        '',
        'Paradiso sardo',
        3.8,
        14.7,
        476,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Topsmead Forest Trail',
        2,
        '/static/gpx/343_Topsmead_Forest_Trail.gpx',
        'USA',
        'Reggio Calabria',
        '',
        'Barbarigo terme',
        0.6,
        24.1,
        28,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Edith M Chase Ecology Trail',
        2,
        '/static/gpx/344_Edith_M_Chase_Ecology_Trail.gpx',
        'USA',
        'Lucca',
        '',
        'Quarto Rinaldo',
        6.4,
        8.2,
        2025,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bernard H Stairs Trail',
        2,
        '/static/gpx/345_Bernard_H_Stairs_Trail.gpx',
        'USA',
        'Sondrio',
        '',
        'San Terenzio',
        2.7,
        15.1,
        1190,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'West Rock Park Trail',
        2,
        '/static/gpx/346_West_Rock_Park_Trail.gpx',
        'USA',
        'Biella',
        '',
        'Borgo Lara terme',
        4.2,
        15,
        672,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'West Rock Summit Trail',
        2,
        '/static/gpx/347_West_Rock_Summit_Trail.gpx',
        'USA',
        'Brescia',
        '',
        'San Cleo salentino',
        7,
        9.7,
        972,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Regicides Trail',
        2,
        '/static/gpx/348_Regicides_Trail.gpx',
        'USA',
        'Lecce',
        '',
        'Gianpietro salentino',
        2,
        18.3,
        2364,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sanford Feeder Trail',
        0,
        '/static/gpx/349_Sanford_Feeder_Trail.gpx',
        'USA',
        'Pordenone',
        '',
        'D''Urso salentino',
        3.7,
        14.8,
        1859,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'North Summit Trail',
        2,
        '/static/gpx/350_North_Summit_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Genna ligure',
        5,
        26.7,
        2532,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Westville Feeder Trail',
        2,
        '/static/gpx/351_Westville_Feeder_Trail.gpx',
        'USA',
        'Brescia',
        '',
        'San Guiberto calabro',
        3.4,
        13.2,
        476,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'West Rock Park Road',
        2,
        '/static/gpx/352_West_Rock_Park_Road.gpx',
        'USA',
        'Caltanissetta',
        '',
        'San Amando calabro',
        1.7,
        19.7,
        209,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bennetts Pond Trail',
        2,
        '/static/gpx/353_Bennetts_Pond_Trail.gpx',
        'USA',
        'Macerata',
        '',
        'Ermenegilda veneto',
        2,
        29.6,
        455,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ives Trail',
        0,
        '/static/gpx/354_Ives_Trail.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Settimo Ombretta',
        4.2,
        28.8,
        539,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ridgefield Open Space Trail',
        0,
        '/static/gpx/355_Ridgefield_Open_Space_Trail.gpx',
        'USA',
        'Avellino',
        '',
        'Borgo Genesia lido',
        4.3,
        29.9,
        564,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'George Dudley Seymour Park Trail',
        1,
        '/static/gpx/356_George_Dudley_Seymour_Park_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'Simeoni lido',
        0.6,
        5.3,
        72,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Grta',
        2,
        '/static/gpx/357_Grta.gpx',
        'USA',
        'Udine',
        '',
        'Egle salentino',
        0.9,
        23.4,
        52,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mohegan Forest Trail',
        1,
        '/static/gpx/358_Mohegan_Forest_Trail.gpx',
        'USA',
        'Caserta',
        '',
        'Quarto Alberta a mare',
        1.3,
        12.3,
        140,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mount Bushnell Trail',
        1,
        '/static/gpx/359_Mount_Bushnell_Trail.gpx',
        'USA',
        'Sassari',
        '',
        'Eva lido',
        9.7,
        20.9,
        1806,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nye Holman Trail',
        2,
        '/static/gpx/360_Nye_Holman_Trail.gpx',
        'USA',
        'Vercelli',
        '',
        'Fiorenzo nell''emilia',
        1.2,
        15.8,
        266,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Al''S Trail',
        2,
        '/static/gpx/361_Al_S_Trail.gpx',
        'USA',
        'Pescara',
        '',
        'Borgo Fidenziano calabro',
        1.1,
        13.1,
        165,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Salt Rock State Park Trail',
        2,
        '/static/gpx/362_Salt_Rock_State_Park_Trail.gpx',
        'USA',
        'Udine',
        '',
        'Borgo Gastone',
        2.4,
        16,
        684,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Scantic River Trail',
        0,
        '/static/gpx/363_Scantic_River_Trail.gpx',
        'USA',
        'Aosta',
        '',
        'Minerva del friuli',
        1.1,
        10.6,
        225,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Scantic River Park Trail',
        0,
        '/static/gpx/364_Scantic_River_Park_Trail.gpx',
        'USA',
        'L''Aquila',
        '',
        'Settimo Amando a mare',
        0.6,
        30,
        112,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Scantic Park Access',
        2,
        '/static/gpx/365_Scantic_Park_Access.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Sesto Giusta ligure',
        0.5,
        28.3,
        55,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sunrise Park Trail',
        0,
        '/static/gpx/366_Sunrise_Park_Trail.gpx',
        'USA',
        'Benevento',
        '',
        'Regolo del friuli',
        0.8,
        9.1,
        221,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kitchel Trail',
        1,
        '/static/gpx/367_Kitchel_Trail.gpx',
        'USA',
        'Fermo',
        '',
        'Quarto Eligio',
        7.5,
        18.3,
        1782,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Old Driveway',
        2,
        '/static/gpx/368_Old_Driveway.gpx',
        'USA',
        'Palermo',
        '',
        'Fabiano veneto',
        1.3,
        18.1,
        168,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kitchel',
        1,
        '/static/gpx/369_Kitchel.gpx',
        'USA',
        'Agrigento',
        '',
        'Venturini a mare',
        1.2,
        5.5,
        182,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Driveway',
        2,
        '/static/gpx/370_Driveway.gpx',
        'USA',
        'Lodi',
        '',
        'Campanile ligure',
        0.6,
        5.5,
        140,
        ''
      );
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2)
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        1,
        70,
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Dott. Fidenziano Garifo',
        'http://husky-divan.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        2,
        77,
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Domenico Casagrande',
        'http://legitimate-span.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        8,
        63,
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Ing. Andrea Monni',
        'http://cheery-crush.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        2,
        60,
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Raide Provenzano',
        'https://eager-canoe.net',
        null
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        10,
        131,
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Remo Di Michele',
        'http://proud-commodity.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        7,
        99,
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Cristiano D''Angelo',
        'https://icky-conscience.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        3,
        63,
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Fosca Sevi',
        'https://yearly-ladle.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        5,
        46,
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Orsolina Carrara',
        'http://hoarse-velocity.it',
        null
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        2,
        102,
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Federico Pacifico',
        'http://supportive-ecclesia.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        2,
        43,
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Ivanoe Fortunato',
        'https://ultimate-petition.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        2,
        126,
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Simeone Floris',
        'https://visible-dragonfruit.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        7,
        120,
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Ladislao Mariotti',
        'https://admirable-mailer.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        6,
        92,
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Querano Zanotti',
        'https://impractical-nod.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        10,
        62,
        'Vernagthütte',
        'Austria',
        'Ella Verme',
        'http://snoopy-noodle.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        8,
        96,
        'Wormser Hütte',
        'Austria',
        'Dott. Daria Belvisi',
        'http://pointed-ectodermal.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        7,
        128,
        'Biberacher Hütte',
        'Austria',
        'Ing. Carmelo Prisco',
        'https://real-doubling.net',
        null
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        5,
        124,
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Elpidio Lana',
        'https://trifling-release.net',
        null
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        8,
        120,
        'Hochwaldhütte',
        'Germany',
        'Baldovino Milani',
        'https://remarkable-sigh.com',
        null
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        2,
        49,
        'Kölner Eifelhütte',
        'Germany',
        'Tea Marinucci',
        'https://slimy-airplane.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        10,
        37,
        'Madrisahütte',
        'Austria',
        'Nicodemo Lotti',
        'https://best-jaguar.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        8,
        100,
        'Dresdner Hütte',
        'Austria',
        'Sig. Ottilia Giordano',
        'http://outlying-carriage.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        9,
        55,
        'Fiderepasshütte',
        'Germany',
        'Ada Serena',
        'https://equatorial-accordion.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        5,
        35,
        'Göppinger Hütte',
        'Austria',
        'Dr. Alvaro Meo',
        'http://glistening-rock.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        9,
        61,
        'Oberzalimhütte',
        'Austria',
        'Aloisio Buzzi',
        'http://grouchy-debris.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        10,
        75,
        'Rastkogelhütte',
        'Austria',
        'Crispino Aramini',
        'http://ethical-shame.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        1,
        148,
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Erminia Bandini',
        'http://flamboyant-entree.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        4,
        72,
        'Kaltenberghütte',
        'Austria',
        'Chiaffredo Nota',
        'http://lined-giant.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        5,
        105,
        'Schweinfurter Hütte',
        'Austria',
        'Giada Catellani',
        'https://experienced-musculature.net',
        null
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        4,
        53,
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Wanda Allegretti',
        'https://dangerous-beret.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        3,
        135,
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Bice Licciardello',
        'https://pink-permission.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        7,
        64,
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Melchiorre Paolino',
        'https://jittery-paint.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        2,
        129,
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Benvenuta Beltrame',
        'http://fake-fashion.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        9,
        130,
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Taziano Girone',
        'https://united-lacquerware.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        3,
        66,
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Polissena Iorio',
        'http://fair-shoreline.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        4,
        106,
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Cleofe Polito',
        'https://any-synonym.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        10,
        101,
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Gianluigi Iacolare',
        'http://pristine-territory.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        6,
        56,
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Cirillo Mosti',
        'http://quiet-husband.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        8,
        99,
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Alfonsa Pratesi',
        'https://worse-cobbler.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        2,
        56,
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Ing. Benigna Padovan',
        'http://treasured-orientation.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        4,
        36,
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Virginia Zago',
        'http://aromatic-brushfire.org',
        null
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        3,
        39,
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Sarbello Puglisi',
        'http://quaint-eclipse.org',
        null
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        7,
        39,
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Dr. Ulderico Manca',
        'https://delicious-outback.net',
        null
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        10,
        53,
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Giuliana Pozzi',
        'https://rash-perfume.com',
        null
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        10,
        121,
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Cunegonda Rosselli',
        'http://pungent-casement.net',
        null
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        10,
        76,
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Azeglio Mazzaro',
        'http://heavy-ideal.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        6,
        136,
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Porfirio Martinelli',
        'https://noisy-burglar.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        9,
        82,
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Aurora Rosi',
        'https://dramatic-suppression.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        1,
        89,
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Sabato Furlan',
        'http://whirlwind-good.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        2,
        40,
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Evasio De Bonis',
        'https://lovable-coal.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        6,
        69,
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Mirella De Maio',
        'http://vigilant-marble.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        1,
        128,
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Daria Sodano',
        'https://buzzing-saucer.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        8,
        100,
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Zetico La Torre',
        'http://experienced-voice.net',
        null
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        7,
        65,
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Olga Tonini',
        'http://bare-burrow.net',
        null
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        2,
        48,
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Gandolfo Sorbello',
        'https://baggy-pantsuit.it',
        null
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        5,
        76,
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Gonzaga Bergamasco',
        'http://uncomfortable-yellow.net',
        null
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        10,
        128,
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Massima Di Liberto',
        'http://impolite-homonym.it',
        null
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        5,
        104,
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Eligio Parise',
        'http://faint-ceramic.net',
        null
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        3,
        139,
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Angela Albanese',
        'http://yellow-divide.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        6,
        57,
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Liboria Rossi',
        'http://lustrous-corn.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        2,
        102,
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Sig. Calpurnia Giuffrida',
        'https://harmful-top.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        7,
        94,
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Donatella Spinelli',
        'https://biodegradable-gang.org',
        null
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        4,
        47,
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Mansueto Talarico',
        'https://idle-running.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        3,
        72,
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Foca Moscato',
        'http://genuine-lawmaker.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        7,
        85,
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Ing. Nicezio Mariotti',
        'http://bright-implement.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        4,
        38,
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Melania Zappia',
        'http://whole-brief.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        8,
        107,
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Giasone Zambuto',
        'http://nervous-primary.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        3,
        147,
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Bonaventura Ceccarini',
        'http://astonishing-dollar.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        6,
        90,
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Nicea La Rocca',
        'http://general-numismatist.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        6,
        51,
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Sabrina Santarelli',
        'https://intentional-patrimony.net',
        null
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        1,
        106,
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Sig. Giuditta Spanu',
        'https://quick-foodstuffs.net',
        null
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        5,
        106,
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Ovidio Lisi',
        'http://deficient-malice.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        4,
        144,
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Dr. Narsete Angelini',
        'https://sweet-ballot.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        1,
        120,
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Berengario Di Domenico',
        'http://elastic-employment.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        1,
        120,
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Paride Iacono',
        'http://angry-downfall.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        6,
        116,
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Rolfo Pasqua',
        'http://exemplary-classmate.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        9,
        107,
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Nunziata Cuzzocrea',
        'http://fantastic-vitamin.net',
        null
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        8,
        83,
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Morena Perotti',
        'http://fortunate-sprout.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        1,
        134,
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Bonavita Varriale',
        'https://joint-touch.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        5,
        44,
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Babila Masucci',
        'http://livid-vanadyl.com',
        null
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        3,
        35,
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Dr. Ambra Mori',
        'http://private-genius.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        5,
        120,
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Telchide Ravaioli',
        'https://alert-oval.org',
        null
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        6,
        35,
        'Wittener Hütte',
        'Germany',
        'Temistocle Pece',
        'https://comfortable-resist.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        10,
        35,
        'Hochjoch-Hospiz',
        'Austria',
        'Aleardo Pantano',
        'http://flat-thermals.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        5,
        124,
        'Meilerhütte',
        'Germany',
        'Martino Latorre',
        'http://far-off-collection.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        7,
        97,
        'Gaudeamushütte',
        'Austria',
        'Maria Candido',
        'http://small-perch.com',
        null
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        9,
        149,
        'Rheydter Hütte',
        'Germany',
        'Alma Paonessa',
        'http://focused-professional.it',
        null
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        1,
        89,
        'Sektionshütte Krippen',
        'Germany',
        'Rosamunda Procopio',
        'https://thankful-still.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        2,
        118,
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Benvenuta Mazzola',
        'https://cruel-shadow.net',
        null
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        9,
        60,
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Pierluigi Cozzani',
        'https://advanced-preserves.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        6,
        67,
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Albrico Sapienza',
        'https://neighboring-land.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        10,
        146,
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Apollinare Leoncini',
        'http://creative-square.it',
        null
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        7,
        82,
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Fedora Fini',
        'https://repulsive-imitation.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        10,
        127,
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Teodoto Caporaso',
        'http://grizzled-wrestler.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        1,
        81,
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Cecilio Dal Farra',
        'https://delectable-major-league.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        5,
        146,
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Godiva Cancelliere',
        'https://suspicious-celebration.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        4,
        36,
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Napoleone Capone',
        'https://strange-joy.net',
        null
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        10,
        86,
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Amalia Silvestrini',
        'http://infamous-plight.net',
        null
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        8,
        128,
        'Dobra voda',
        'Suvobor, Serbia',
        'Turibio Torresi',
        'https://limping-nutrition.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        5,
        81,
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Giuseppina Pili',
        'http://damaged-employee.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        3,
        66,
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Dr. Mauro Salamone',
        'https://unequaled-instrument.org',
        null
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        2,
        129,
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Coriolano Chilà',
        'http://juicy-downgrade.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        6,
        69,
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Eufebio Viola',
        'https://raw-agreement.net',
        null
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        6,
        98,
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Dr. Ticone Ottonello',
        'https://mealy-sentiment.org',
        null
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        6,
        138,
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Varo Di Pede',
        'http://slim-stiletto.it',
        null
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        6,
        134,
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Costanza Franzoni',
        'https://colorful-lady.net',
        null
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        7,
        113,
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Laurentino Coccia',
        'http://agonizing-nonconformist.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        3,
        144,
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Primo Zappacosta',
        'https://skinny-prosecution.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        2,
        125,
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Armida Bellucci',
        'http://hefty-bubble.net',
        null
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '58 Rotonda Greppi, Sesto Crescente sardo, Italy',
        'Sesto Crescente sardo',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        115,
        '9 Via Gianluigi, Gioia terme, Italy',
        'Gioia terme',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        71,
        '4 Borgo Rubino, Mamante terme, Italy',
        'Mamante terme',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        119,
        '7 Piazza Bevilacqua, Orio terme, Italy',
        'Orio terme',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        46,
        '2 Borgo Quiteria, Quarto Albrico, Italy',
        'Quarto Albrico',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        47,
        '748 Via Brunetti, Evola salentino, Italy',
        'Evola salentino',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        165,
        '708 Borgo Adelaide, Gino nell''emilia, Italy',
        'Gino nell''emilia',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        119,
        '7 Rotonda Balistreri, Settimo Nino, Italy',
        'Settimo Nino',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        84,
        '810 Borgo Parmenio, Borgo Alceste, Italy',
        'Borgo Alceste',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        214,
        '0 Strada Selene, Quarto Gianpaolo, Italy',
        'Quarto Gianpaolo',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        159,
        '358 Piazza Natali, Rauso umbro, Italy',
        'Rauso umbro',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        231,
        '772 Borgo D''Avino, Toti ligure, Italy',
        'Toti ligure',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        131,
        '17 Piazza Tumino, Falbo lido, Italy',
        'Falbo lido',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        192,
        '75 Rotonda Melania, Giambattista calabro, Italy',
        'Giambattista calabro',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        175,
        '8 Piazza Asaro, Settimo Marana lido, Italy',
        'Settimo Marana lido',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        168,
        '35 Incrocio Fiammetta, Filipponi lido, Italy',
        'Filipponi lido',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        187,
        '58 Rotonda Matera, Sesto Godiva veneto, Italy',
        'Sesto Godiva veneto',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        289,
        '432 Via Surano, Sesto Efrem, Italy',
        'Sesto Efrem',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        222,
        '409 Via Di Iorio, Selene ligure, Italy',
        'Selene ligure',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        117,
        '6 Piazza Sofia, Borgo Giuseppa del friuli, Italy',
        'Borgo Giuseppa del friuli',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        190,
        '62 Piazza Teodoro, Metello ligure, Italy',
        'Metello ligure',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        247,
        '5 Via Claudio, Esuperio sardo, Italy',
        'Esuperio sardo',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '1 Contrada Licata, Lana calabro, Italy',
        'Lana calabro',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        176,
        '4 Contrada Filomeno, Valenti laziale, Italy',
        'Valenti laziale',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        92,
        '82 Borgo Grimaldo, Quarto Birino del friuli, Italy',
        'Quarto Birino del friuli',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        29,
        '96 Rotonda Erasmo, Sesto Landolfo, Italy',
        'Sesto Landolfo',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        188,
        '69 Via Acario, Borgo Amaranto, Italy',
        'Borgo Amaranto',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        286,
        '418 Borgo Di Blasi, Abbondio veneto, Italy',
        'Abbondio veneto',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        180,
        '1 Strada Silvano, Concas calabro, Italy',
        'Concas calabro',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        70,
        '679 Via Biagetti, Settimo Porzia, Italy',
        'Settimo Porzia',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        54,
        '40 Rotonda Catania, Sesto Savina terme, Italy',
        'Sesto Savina terme',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        139,
        '09 Rotonda Isotta, Pizzitola ligure, Italy',
        'Pizzitola ligure',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        116,
        '256 Borgo Azelio, Fabrizi a mare, Italy',
        'Fabrizi a mare',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '5 Rotonda Mancuso, Settimo Tiziano, Italy',
        'Settimo Tiziano',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        289,
        '144 Borgo Leale, Borgo Pia salentino, Italy',
        'Borgo Pia salentino',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        224,
        '94 Strada Marchetto, Urdino calabro, Italy',
        'Urdino calabro',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        284,
        '74 Piazza Fulgenzio, Eligibile laziale, Italy',
        'Eligibile laziale',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        257,
        '74 Rotonda Castellani, Quarto Gandolfo sardo, Italy',
        'Quarto Gandolfo sardo',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        85,
        '7 Contrada Ester, Egisto calabro, Italy',
        'Egisto calabro',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        258,
        '905 Borgo Di Francesco, Ladislao laziale, Italy',
        'Ladislao laziale',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '271 Via Muratore, Quarto Costantino, Italy',
        'Quarto Costantino',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        285,
        '8 Incrocio Danio, Orazio umbro, Italy',
        'Orazio umbro',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        300,
        '38 Incrocio Mazzini, Cangiano umbro, Italy',
        'Cangiano umbro',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        77,
        '291 Rotonda Merli, Quarto Quintilio nell''emilia, Italy',
        'Quarto Quintilio nell''emilia',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        149,
        '5 Rotonda Drago, San Evandro, Italy',
        'San Evandro',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        239,
        '699 Borgo Tufano, Rolando veneto, Italy',
        'Rolando veneto',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        290,
        '8 Via Cerrani, Sesto Taziano lido, Italy',
        'Sesto Taziano lido',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        113,
        '3 Rotonda Natale, Quarto Dione, Italy',
        'Quarto Dione',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        246,
        '00 Piazza Gioacchino, Settimo Agapito veneto, Italy',
        'Settimo Agapito veneto',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        231,
        '5 Contrada Ippocrate, Sesto Regolo laziale, Italy',
        'Sesto Regolo laziale',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        30,
        '33 Incrocio Manna, Dina sardo, Italy',
        'Dina sardo',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '3 Via Puccio, Settimo Roberto sardo, Italy',
        'Settimo Roberto sardo',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        239,
        '2 Via Rolfo, Quarto Pusicio calabro, Italy',
        'Quarto Pusicio calabro',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '958 Piazza Affinito, Evodio nell''emilia, Italy',
        'Evodio nell''emilia',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        151,
        '3 Borgo Furseo, Ambrosini sardo, Italy',
        'Ambrosini sardo',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        149,
        '1 Borgo Norina, Annabella lido, Italy',
        'Annabella lido',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        296,
        '878 Incrocio Ermenegilda, Piccoli nell''emilia, Italy',
        'Piccoli nell''emilia',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        261,
        '22 Contrada Caccamo, Sinopoli veneto, Italy',
        'Sinopoli veneto',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        33,
        '63 Borgo Capogna, Coreno lido, Italy',
        'Coreno lido',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        148,
        '4 Borgo Aureliano, Spano a mare, Italy',
        'Spano a mare',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        67,
        '5 Piazza Quaglia, Lenzi a mare, Italy',
        'Lenzi a mare',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        244,
        '79 Incrocio Maruta, Benvenuti lido, Italy',
        'Benvenuti lido',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        284,
        '27 Via Elita, Restivo ligure, Italy',
        'Restivo ligure',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        99,
        '38 Borgo Mori, Emilio nell''emilia, Italy',
        'Emilio nell''emilia',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        210,
        '0 Contrada Scotti, Quarto Ilda ligure, Italy',
        'Quarto Ilda ligure',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        93,
        '490 Incrocio Giosuele, Borgo Frido salentino, Italy',
        'Borgo Frido salentino',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        72,
        '5 Via Tancredi, San Fortunato, Italy',
        'San Fortunato',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        130,
        '0 Piazza Crescenzia, Patrizia veneto, Italy',
        'Patrizia veneto',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        66,
        '78 Rotonda Annamaria, Belli a mare, Italy',
        'Belli a mare',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '8 Via Melitina, Settimo Lisandro laziale, Italy',
        'Settimo Lisandro laziale',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        168,
        '98 Via Boi, Borgo Marinella veneto, Italy',
        'Borgo Marinella veneto',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        291,
        '7 Strada Benedetto, Settimo Damocle, Italy',
        'Settimo Damocle',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        253,
        '004 Piazza Montesano, Palmisano terme, Italy',
        'Palmisano terme',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        180,
        '899 Contrada Zenone, Eliodoro del friuli, Italy',
        'Eliodoro del friuli',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        161,
        '869 Rotonda Delogu, Braia veneto, Italy',
        'Braia veneto',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        190,
        '90 Incrocio Brando, Rutilo calabro, Italy',
        'Rutilo calabro',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        253,
        '72 Borgo Zefiro, Settimo Pollione nell''emilia, Italy',
        'Settimo Pollione nell''emilia',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        213,
        '7 Incrocio Barnaba, Crispino sardo, Italy',
        'Crispino sardo',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        110,
        '277 Via Pasquale, Olinda veneto, Italy',
        'Olinda veneto',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        109,
        '33 Rotonda Altieri, Leopardo terme, Italy',
        'Leopardo terme',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        263,
        '3 Rotonda Floriana, Quarto Everardo salentino, Italy',
        'Quarto Everardo salentino',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        198,
        '80 Rotonda Puglisi, San Quintiliano, Italy',
        'San Quintiliano',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        260,
        '33 Rotonda Spadoni, Vanna veneto, Italy',
        'Vanna veneto',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        53,
        '910 Borgo Sabazio, Bartolomeo ligure, Italy',
        'Bartolomeo ligure',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        197,
        '3 Piazza Morgana, Sesto Aleandro, Italy',
        'Sesto Aleandro',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        33,
        '7 Strada Benigno, Settimo Alcide laziale, Italy',
        'Settimo Alcide laziale',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        35,
        '08 Rotonda Pipitone, Bosco laziale, Italy',
        'Bosco laziale',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        268,
        '765 Contrada Santarsia, Borgo Olimpio, Italy',
        'Borgo Olimpio',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        129,
        '1 Rotonda Rambaldi, Elifio laziale, Italy',
        'Elifio laziale',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        179,
        '73 Contrada Melissa, Riccardi terme, Italy',
        'Riccardi terme',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        264,
        '491 Strada Abramio, Bonanno calabro, Italy',
        'Bonanno calabro',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        86,
        '79 Rotonda Amata, Borgo Cleonico, Italy',
        'Borgo Cleonico',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        183,
        '97 Borgo Ruotolo, Modesto lido, Italy',
        'Modesto lido',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        194,
        '863 Contrada Arcibaldo, Sireno salentino, Italy',
        'Sireno salentino',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        206,
        '5 Strada Reginaldo, Borgo Platone, Italy',
        'Borgo Platone',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        277,
        '9 Contrada Venustiano, Borgo Verena ligure, Italy',
        'Borgo Verena ligure',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        122,
        '295 Strada Marinucci, Sesto Aronne ligure, Italy',
        'Sesto Aronne ligure',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        130,
        '016 Via Liboria, Quarto Nicezio, Italy',
        'Quarto Nicezio',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        102,
        '15 Piazza Gosto, Borgo Verdiana, Italy',
        'Borgo Verdiana',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        95,
        '5 Piazza D''Amico, Sesto Zefiro, Italy',
        'Sesto Zefiro',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        212,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        225,
        '594 Borgo Casali, Lucarini nell''emilia, Italy',
        'Lucarini nell''emilia',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        98,
        '842 Borgo Faraone, Tedde sardo, Italy',
        'Tedde sardo',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        277,
        '5 Borgo Sparacino, Borgo Bruto laziale, Italy',
        'Borgo Bruto laziale',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        205,
        '127 Piazza Gianni, Quarto Guido, Italy',
        'Quarto Guido',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        154,
        '467 Contrada Gumesindo, Cacciapuoti umbro, Italy',
        'Cacciapuoti umbro',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        294,
        '38 Via Evandro, Erico veneto, Italy',
        'Erico veneto',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        235,
        '14 Borgo La Monaca, Sesto Aurelia, Italy',
        'Sesto Aurelia',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        86,
        '242 Borgo Bortolo, Lautone lido, Italy',
        'Lautone lido',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        255,
        '95 Rotonda Igino, Nava umbro, Italy',
        'Nava umbro',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        262,
        '51 Piazza Lo Bianco, Rampazzo salentino, Italy',
        'Rampazzo salentino',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        135,
        '140 Incrocio Otilia, Sesto Cleandro a mare, Italy',
        'Sesto Cleandro a mare',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        233,
        '054 Incrocio Remigio, Iorio del friuli, Italy',
        'Iorio del friuli',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        234,
        '0 Piazza Carriero, Sidonia lido, Italy',
        'Sidonia lido',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        101,
        '2 Contrada Zanella, Settimo Flavia, Italy',
        'Settimo Flavia',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        84,
        '93 Strada Di Costanzo, Quarto Melissa, Italy',
        'Quarto Melissa',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        216,
        '319 Strada Laura, Benvenuto terme, Italy',
        'Benvenuto terme',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        92,
        '1 Strada Ciro, Sesto Olga calabro, Italy',
        'Sesto Olga calabro',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        87,
        '921 Contrada Macrì, San Gualberto sardo, Italy',
        'San Gualberto sardo',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        187,
        '75 Via Giocondo, Settimo Bardomiano nell''emilia, Italy',
        'Settimo Bardomiano nell''emilia',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        256,
        '23 Borgo Migliore, Criscenti veneto, Italy',
        'Criscenti veneto',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        123,
        '7 Piazza Beltrame, Settimo Viliana, Italy',
        'Settimo Viliana',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        204,
        '486 Rotonda Ianni, Melezio ligure, Italy',
        'Melezio ligure',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        152,
        '99 Incrocio Vincenza, San Aida laziale, Italy',
        'San Aida laziale',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        266,
        '70 Strada Pavone, San Diocleziano laziale, Italy',
        'San Diocleziano laziale',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        136,
        '009 Incrocio Gerolamo, Giorgio laziale, Italy',
        'Giorgio laziale',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '04 Incrocio Morini, Borgo Geronzio sardo, Italy',
        'Borgo Geronzio sardo',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        86,
        '58 Rotonda Ildegarda, Quarto Pippo, Italy',
        'Quarto Pippo',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        33,
        '22 Contrada Nerea, Quarto Ada, Italy',
        'Quarto Ada',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '4 Piazza Edilberto, Sesto Francesca, Italy',
        'Sesto Francesca',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '2 Piazza Di Natale, Leoni salentino, Italy',
        'Leoni salentino',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        85,
        '604 Rotonda Celeste, Calligaris salentino, Italy',
        'Calligaris salentino',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        223,
        '166 Rotonda Alviero, Dante laziale, Italy',
        'Dante laziale',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        137,
        '87 Incrocio Bernardini, San Orchidea umbro, Italy',
        'San Orchidea umbro',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        77,
        '1 Via Valsecchi, Borgo Manetto sardo, Italy',
        'Borgo Manetto sardo',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        131,
        '10 Contrada De Napoli, Bionaz nell''emilia, Italy',
        'Bionaz nell''emilia',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '9 Piazza Egle, Sesto Irene, Italy',
        'Sesto Irene',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '968 Via Narciso, Cinelli del friuli, Italy',
        'Cinelli del friuli',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        82,
        '928 Incrocio Pantaleo, Mazzoleno nell''emilia, Italy',
        'Mazzoleno nell''emilia',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '838 Piazza Igino, Zaccaro terme, Italy',
        'Zaccaro terme',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        129,
        '9 Via Argiolas, Folco salentino, Italy',
        'Folco salentino',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        233,
        '011 Borgo Mazzoleno, Sesto Isidoro, Italy',
        'Sesto Isidoro',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        27,
        '09 Incrocio Leoncini, Porfirio laziale, Italy',
        'Porfirio laziale',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        58,
        '453 Borgo Torquato, Garifo calabro, Italy',
        'Garifo calabro',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        296,
        '793 Incrocio Basile, Sesto Alboino salentino, Italy',
        'Sesto Alboino salentino',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        153,
        '8 Via Salvi, Sesto Angela, Italy',
        'Sesto Angela',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        232,
        '7 Via La Rosa, Borgo Gennaro, Italy',
        'Borgo Gennaro',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        142,
        '0 Incrocio Manica, Settimo Stiliano umbro, Italy',
        'Settimo Stiliano umbro',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        61,
        '1 Via Franchi, Duccio laziale, Italy',
        'Duccio laziale',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        54,
        '04 Contrada Olivieri, Bini del friuli, Italy',
        'Bini del friuli',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        221,
        '137 Contrada Quinziano, Livio lido, Italy',
        'Livio lido',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        106,
        '80 Piazza Bardo, De Bona laziale, Italy',
        'De Bona laziale',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        200,
        '153 Strada Saia, Quarto Cloe nell''emilia, Italy',
        'Quarto Cloe nell''emilia',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        101,
        '65 Via Castiglioni, Settimo Aloisio veneto, Italy',
        'Settimo Aloisio veneto',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        209,
        '0 Incrocio Afro, Borgo Coriolano laziale, Italy',
        'Borgo Coriolano laziale',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        298,
        '095 Incrocio Gianuario, Artemisa lido, Italy',
        'Artemisa lido',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        249,
        '4 Contrada Andrisani, Sesto Gioacchina nell''emilia, Italy',
        'Sesto Gioacchina nell''emilia',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        168,
        '423 Via Guiberto, Pesaresi lido, Italy',
        'Pesaresi lido',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        51,
        '02 Via Tarquinia, Ivetta calabro, Italy',
        'Ivetta calabro',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        35,
        '73 Strada Surace, Di Gaetano veneto, Italy',
        'Di Gaetano veneto',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        152,
        '964 Rotonda Moser, Quarto Tammaro, Italy',
        'Quarto Tammaro',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        43,
        '64 Incrocio Gianmarco, Delle Monache umbro, Italy',
        'Delle Monache umbro',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        100,
        '8 Piazza Recchia, Sesto Aimone, Italy',
        'Sesto Aimone',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        206,
        '496 Strada Antioco, Sesto Foca sardo, Italy',
        'Sesto Foca sardo',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        144,
        '87 Piazza Mario, Quarto Verena veneto, Italy',
        'Quarto Verena veneto',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '1 Contrada Sosteneo, Di Luca umbro, Italy',
        'Di Luca umbro',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        218,
        '2 Rotonda Cesaretti, Pierro ligure, Italy',
        'Pierro ligure',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        42,
        '1 Borgo Sostene, Cappelli lido, Italy',
        'Cappelli lido',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        37,
        '962 Strada Moffa, Borgo Alamanno del friuli, Italy',
        'Borgo Alamanno del friuli',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        113,
        '21 Contrada Tralli, Ines umbro, Italy',
        'Ines umbro',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        254,
        '40 Contrada Giovanna, Emiliano nell''emilia, Italy',
        'Emiliano nell''emilia',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        258,
        '100 Incrocio Saracino, Bacco terme, Italy',
        'Bacco terme',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        133,
        '55 Strada Letterio, Settimo Ermanno salentino, Italy',
        'Settimo Ermanno salentino',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        155,
        '9 Contrada Edilberto, Settimo Rino salentino, Italy',
        'Settimo Rino salentino',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        137,
        '8 Via Bindi, Quarto Liberato, Italy',
        'Quarto Liberato',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        242,
        '5 Borgo Adamo, Borgo Elaide, Italy',
        'Borgo Elaide',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        224,
        '821 Rotonda Di Salvo, Sesto Penelope del friuli, Italy',
        'Sesto Penelope del friuli',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        138,
        '5 Strada Cortesi, Niccolai lido, Italy',
        'Niccolai lido',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        275,
        '19 Piazza Furno, Alessia a mare, Italy',
        'Alessia a mare',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        111,
        '0 Incrocio Damiano, Turco umbro, Italy',
        'Turco umbro',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        106,
        '5 Contrada Grazia, Eufrasia veneto, Italy',
        'Eufrasia veneto',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        85,
        '495 Borgo Pianigiani, Bassiano umbro, Italy',
        'Bassiano umbro',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '469 Borgo Nicoletti, Carbon terme, Italy',
        'Carbon terme',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        265,
        '029 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        181,
        '76 Incrocio Egger, Quarto Lamberto, Italy',
        'Quarto Lamberto',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        295,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        69,
        '744 Piazza Ragusa, Quarto Teodata del friuli, Italy',
        'Quarto Teodata del friuli',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        240,
        '80 Borgo Brigandì, Quarto Benedetto, Italy',
        'Quarto Benedetto',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        212,
        '378 Strada Ulfo, Alice del friuli, Italy',
        'Alice del friuli',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        241,
        '50 Incrocio Cerrani, Settimo Fiorenzo del friuli, Italy',
        'Settimo Fiorenzo del friuli',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        143,
        '567 Rotonda Pivetta, Pizzitola calabro, Italy',
        'Pizzitola calabro',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        244,
        '19 Piazza Romeo, Settimo Ariosto a mare, Italy',
        'Settimo Ariosto a mare',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        249,
        '066 Rotonda Regolo, Marciano veneto, Italy',
        'Marciano veneto',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        187,
        '7 Piazza Smeralda, San Fabiana calabro, Italy',
        'San Fabiana calabro',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        291,
        '71 Piazza Lorena, Sesto Amanzio, Italy',
        'Sesto Amanzio',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        98,
        '6 Piazza Sibilla, Ferrario ligure, Italy',
        'Ferrario ligure',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        121,
        '28 Rotonda Ruotolo, San Ulrico laziale, Italy',
        'San Ulrico laziale',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        171,
        '6 Borgo Paradiso, Quarto Fatima lido, Italy',
        'Quarto Fatima lido',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        101,
        '33 Borgo Zuliani, Settimo Ippocrate, Italy',
        'Settimo Ippocrate',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        292,
        '9 Strada Odilia, Giannelli a mare, Italy',
        'Giannelli a mare',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        158,
        '30 Rotonda Lana, San Alice, Italy',
        'San Alice',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        41,
        '95 Piazza Renda, Borgo Gottardo, Italy',
        'Borgo Gottardo',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '81 Via Marrone, Sesto Iris calabro, Italy',
        'Sesto Iris calabro',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        73,
        '19 Piazza Moreno, Siro lido, Italy',
        'Siro lido',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        171,
        '53 Piazza Maurizi, San Adelasia umbro, Italy',
        'San Adelasia umbro',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        233,
        '20 Via Puddu, Settimo Ermenegilda, Italy',
        'Settimo Ermenegilda',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        141,
        '7 Strada Algiso, Quarto Lucia, Italy',
        'Quarto Lucia',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        266,
        '4 Rotonda Barsotti, Edvige umbro, Italy',
        'Edvige umbro',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        60,
        '13 Borgo Fadda, Perri lido, Italy',
        'Perri lido',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        98,
        '66 Piazza Micheletti, Sesto Astrid, Italy',
        'Sesto Astrid',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        185,
        '0 Via Leonardo, Bassiano del friuli, Italy',
        'Bassiano del friuli',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        222,
        '2 Borgo Maio, Lattanzi terme, Italy',
        'Lattanzi terme',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '6 Rotonda Otilia, Settimo Indro veneto, Italy',
        'Settimo Indro veneto',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        118,
        '2 Piazza Pezzi, Settimo Federico ligure, Italy',
        'Settimo Federico ligure',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        283,
        '505 Via Grossi, Manuela lido, Italy',
        'Manuela lido',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        30,
        '7 Via Fatima, San Macario, Italy',
        'San Macario',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        57,
        '412 Strada Miceli, Paolo umbro, Italy',
        'Paolo umbro',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        291,
        '623 Piazza Fiorenza, Onorino del friuli, Italy',
        'Onorino del friuli',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        43,
        '270 Via Di Tullio, Diodoro umbro, Italy',
        'Diodoro umbro',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        128,
        '97 Contrada Virgilio, Volpe sardo, Italy',
        'Volpe sardo',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        240,
        '06 Borgo Orazio, Sesto Lidio sardo, Italy',
        'Sesto Lidio sardo',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '96 Via Gualtiero, Basile laziale, Italy',
        'Basile laziale',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        214,
        '11 Piazza Noemi, Sesto Rosa ligure, Italy',
        'Sesto Rosa ligure',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        225,
        '774 Borgo Anna, Gagliardi nell''emilia, Italy',
        'Gagliardi nell''emilia',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        208,
        '94 Via Samona, San Fiorenza, Italy',
        'San Fiorenza',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        291,
        '73 Rotonda Luisa, Sesto Salustio nell''emilia, Italy',
        'Sesto Salustio nell''emilia',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        192,
        '8 Incrocio Betti, Borgo Telica veneto, Italy',
        'Borgo Telica veneto',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        260,
        '35 Strada Carina, Rossetti del friuli, Italy',
        'Rossetti del friuli',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        275,
        '13 Incrocio Donda, Maruta umbro, Italy',
        'Maruta umbro',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        65,
        '28 Strada Giorgia, Galluzzo veneto, Italy',
        'Galluzzo veneto',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        294,
        '8 Rotonda Ragusa, Quarto Varo sardo, Italy',
        'Quarto Varo sardo',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        186,
        '384 Via Luchetti, Cosimo sardo, Italy',
        'Cosimo sardo',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        295,
        '8 Piazza Argimiro, Quarto Gaspare, Italy',
        'Quarto Gaspare',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        281,
        '9 Incrocio Leonardi, Borgo Rossana, Italy',
        'Borgo Rossana',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        200,
        '31 Via Campisi, Quarto Alarico terme, Italy',
        'Quarto Alarico terme',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        76,
        '868 Contrada Tarso, San Azelia, Italy',
        'San Azelia',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        103,
        '58 Strada Decimo, Valeria lido, Italy',
        'Valeria lido',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        241,
        '6 Rotonda Mazzotti, San Gallicano, Italy',
        'San Gallicano',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        161,
        '0 Contrada Isabella, Adalrico nell''emilia, Italy',
        'Adalrico nell''emilia',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        165,
        '181 Incrocio Aristotele, Damiana a mare, Italy',
        'Damiana a mare',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        224,
        '0 Rotonda Tito, Casano laziale, Italy',
        'Casano laziale',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        54,
        '072 Incrocio Abbrescia, Selvaggia terme, Italy',
        'Selvaggia terme',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        139,
        '16 Contrada Borrelli, Tomasi a mare, Italy',
        'Tomasi a mare',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        131,
        '766 Via Ammoscato, San Berenice terme, Italy',
        'San Berenice terme',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        59,
        '80 Borgo Bozzo, Borgo Guelfo calabro, Italy',
        'Borgo Guelfo calabro',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        46,
        '88 Strada Acquadro, Basilia a mare, Italy',
        'Basilia a mare',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        257,
        '32 Via Lai, Samona nell''emilia, Italy',
        'Samona nell''emilia',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        54,
        '78 Via Marcianò, Boffa lido, Italy',
        'Boffa lido',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        70,
        '2 Incrocio D''Errico, Farella laziale, Italy',
        'Farella laziale',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '4 Contrada Schiavone, Quarto Goffredo, Italy',
        'Quarto Goffredo',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        30,
        '80 Contrada Ausilia, San Nino ligure, Italy',
        'San Nino ligure',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        193,
        '06 Via Gumesindo, Petrelli a mare, Italy',
        'Petrelli a mare',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        37,
        '012 Contrada Colmanno, Astrid veneto, Italy',
        'Astrid veneto',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        113,
        '025 Borgo Valeriana, Mariano calabro, Italy',
        'Mariano calabro',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        145,
        '1 Borgo Surace, Borgo Verulo umbro, Italy',
        'Borgo Verulo umbro',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        145,
        '6 Contrada Spadaro, Settimo Everardo ligure, Italy',
        'Settimo Everardo ligure',
        'Italy',
        'Novara',
        ''
      );
    
  