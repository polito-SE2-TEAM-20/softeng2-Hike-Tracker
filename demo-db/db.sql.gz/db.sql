--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: insert_hike(integer, character varying, integer, character varying, character varying, character varying, character varying, character varying, numeric, numeric, integer, character varying, jsonb, jsonb, jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hike(user_id integer, title character varying, difficulty integer, gpx_path character varying, country character varying, region character varying, province character varying, city character varying, length numeric, ascent numeric, expected_time integer, description character varying, pictures jsonb, start_point jsonb, end_point jsonb, reference_points jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $$;


--
-- Name: insert_hut(integer, double precision, double precision, integer, numeric, character varying, character varying, character varying, character varying, numeric, time without time zone, time without time zone, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut(user_id integer, lat double precision, lon double precision, number_of_beds integer, price numeric, title character varying, address character varying, owner_name character varying, website character varying, elevation numeric, working_time_start time without time zone, working_time_end time without time zone, email character varying, phone_number character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number
    );
    END
    $$;


--
-- Name: insert_parking_lot(integer, double precision, double precision, character varying, integer, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_parking_lot(user_id integer, lat double precision, lon double precision, name character varying, max_cars integer, address character varying, city character varying, country character varying, region character varying, province character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: code-hike; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."code-hike" (code, "userHikeId") FROM stdin;
\.


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
1	1	0	5
1	2	100000	6
1	3	1	3
1	4	2	3
2	5	0	5
2	6	100000	6
3	7	0	5
3	8	100000	6
3	9	1	3
3	10	2	3
4	11	0	5
4	12	100000	6
4	13	1	3
4	14	2	3
5	15	0	5
5	16	100000	6
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country, condition, cause, pictures, "weatherStatus", "weatherDescription") FROM stdin;
1	2	1.20	80	24.30	2	Amprimo	Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.	/static/gpx/Amprimo.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/3.jpg"]	0	
2	2	10.70	200	23.20	1	Anello Chateau Beaulard - Cotolivier - Vazon	Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.	/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx	0.00	Piemonte	Torino	Beaulard	Italia	0		["/static/images/2.jpg"]	0	
3	2	10.80	210	19.20	2	Lago Bianco	Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.\n\nLa diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.\n\nLa Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.\n\nSi può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.	/static/gpx/Lago Bianco.gpx	0.00	Auvergne-Rhone-Alpes	Savoia	Val-Cenis	Francia	0		["/static/images/1.jpg"]	0	
4	2	5.70	200	7.10	2	Alte Langhe Settentrionali - Cossano Belbo	Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.\nSi svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.\nSi imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.\nInizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.\nPercorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. \nSeguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. \nSi procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante	/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx	0.00	Piemonte	Cuneo	Cossano Belbo	Italia	0		["/static/images/4.jpg"]	0	
5	2	3.90	225	27.60	2	La pieve romanica di Piesenzana e la valle delle tartufaie	Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. \nCirca 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. \nIn regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. \nA Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). \nContemporaneamente i ristoranti della zona propongono piatti a base di tartufi	/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx	0.00	Piemonte	Asti	Montechiaro d'Asti	Italia	0		["/static/images/5.jpg"]	0	
\.


--
-- Data for Name: hut-worker; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."hut-worker" ("userId", "hutId") FROM stdin;
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website, elevation, pictures, description, "workingTimeStart", "workingTimeEnd", "phoneNumber", email) FROM stdin;
1	17	3	118.00	Edmund-Graf-Hütte	2	Icaro Cini	http://pink-fowl.org	321.14	[]		06:00:00	12:00:00	+390740717241	Otello_Brigand36@email.it
2	18	10	58.00	Dr.Hernaus-Stöckl	2	Oriana Giacalone	http://spry-drink.com	325.21	[]		03:00:00	11:00:00	+398389343473	Beltramo_Scherini@gmail.com
3	19	8	133.00	Amstettner Hütte	2	Grazia Delfino	http://enraged-pinot.org	323.10	[]		08:00:00	16:00:00	+391428766841	Giusta_Foglia@yahoo.it
4	20	1	71.00	Hochleckenhaus	2	Eliseo Salierno	https://crazy-witch.net	308.48	[]		02:00:00	13:00:00	+398261847902	Gildo.Ortenzi@gmail.com
5	21	5	115.00	Kampthalerhütte	2	Calogera Proietti	https://unruly-sweat.it	305.62	[]		01:00:00	11:00:00	+398317732550	Odidone.Palazzolo@yahoo.it
6	22	5	64.00	Lambacher Hütte	2	Sisto Mazzeo	https://selfish-piss.it	325.58	[]		09:00:00	16:00:00	+399073869680	Menodora28@gmail.com
7	23	2	97.00	Lustenauer Hütte	2	Iris Pugliese	http://neglected-expert.net	260.53	[]		04:00:00	13:00:00	+399676956035	Ferdinando84@gmail.com
8	24	7	142.00	Gablonzer Hütte	2	Gerolamo Bonazzi	http://considerate-midline.com	331.18	[]		05:00:00	16:00:00	+390295345851	Rachele.Benvenuti2@gmail.com
9	25	3	85.00	Katafygio «Flampouri»	2	Benigna Fois	https://whispered-accuracy.it	318.53	[]		03:00:00	15:00:00	+393568582903	Manuela.Martelli24@gmail.com
10	26	5	142.00	Simonyhütte	2	Dott. Benigna Di Santo	http://excellent-climate.net	294.71	[]		03:00:00	14:00:00	+397934199404	Tizio_Ferrario74@yahoo.it
11	27	1	130.00	Vinzenz-Tollinger-Hütte	2	Dott. Remo Di Martino	https://unwelcome-syndicate.org	332.63	[]		05:00:00	13:00:00	+393971165301	Beniamino_Errico94@libero.it
12	28	6	149.00	Ottokar-Kernstock-Haus	2	Raide Mecca	http://steel-picnic.net	299.82	[]		09:00:00	22:00:00	+398073642905	Brando_Mazzaro41@yahoo.it
13	29	7	100.00	Reisseckhütte	2	Metrofane Marchesi	http://limited-step-son.it	265.85	[]		03:00:00	11:00:00	+399483837788	Gianpiero_DiFranco3@hotmail.com
14	30	6	123.00	Vernagthütte	2	Orchidea Militello	http://subtle-consumer.it	301.65	[]		04:00:00	16:00:00	+393758384714	Alberto.Zambon38@gmail.com
15	31	10	123.00	Wormser Hütte	2	Rosalinda Citro	http://relieved-layer.org	272.62	[]		06:00:00	16:00:00	+399143193859	Umile.Licciardello22@hotmail.com
16	32	8	46.00	Biberacher Hütte	2	Brancaleone D'Aleo	https://speedy-supplier.org	275.45	[]		04:00:00	18:00:00	+397909667650	Zosimo_Pavan@gmail.com
17	33	1	41.00	Katafygio «1777»	2	Valerico Toti	https://big-hearted-profit.it	269.72	[]		09:00:00	15:00:00	+394111214683	Bruno84@libero.it
18	34	10	110.00	Hochwaldhütte	2	Settimio Romanini	https://free-shower.org	311.32	[]		03:00:00	16:00:00	+390613065582	Candida_Scalia@yahoo.com
19	35	8	115.00	Kölner Eifelhütte	2	Ombretta Tolomeo	http://flickering-compulsion.org	306.06	[]		04:00:00	21:00:00	+394896991133	Lorenzo.DiFiore30@hotmail.com
20	36	1	86.00	Madrisahütte	2	Erenia Nardi	https://unfinished-inclusion.com	328.97	[]		05:00:00	17:00:00	+397916383521	Aureliano.DiFranco80@gmail.com
21	37	7	88.00	Dresdner Hütte	2	Damiano Rondoni	http://scared-priest.com	275.07	[]		08:00:00	22:00:00	+395575945928	Ferdinando.Scano@gmail.com
22	38	4	66.00	Fiderepasshütte	2	Brunilde Marino	https://that-hydroxyl.it	299.76	[]		05:00:00	15:00:00	+393634558219	Sabina48@hotmail.com
23	39	7	84.00	Göppinger Hütte	2	Nicla Fabrizi	http://stupendous-sock.com	299.39	[]		06:00:00	21:00:00	+395447379580	Otilia_Epifani@email.it
24	40	10	145.00	Oberzalimhütte	2	Roberta Palombi	http://colorless-exception.net	309.41	[]		06:00:00	20:00:00	+399836801319	Ambra_Giordano57@yahoo.it
25	41	6	73.00	Rastkogelhütte	2	Ubaldo De Col	https://oily-blend.com	317.42	[]		02:00:00	10:00:00	+398831516922	Agata_Latorre16@email.it
26	42	10	74.00	Ansbacher Skihütte im Allgäu	2	Dafne Vincenzi	http://unwitting-wiring.org	295.88	[]		04:00:00	22:00:00	+396985667151	Costanza3@email.it
27	43	2	96.00	Kaltenberghütte	2	Marino Manzi	https://deep-celery.org	317.78	[]		04:00:00	21:00:00	+397630071431	Bonavita_Perilli25@libero.it
28	44	5	120.00	Schweinfurter Hütte	2	Secondiano Di Iorio	https://pretty-sausage.org	326.12	[]		03:00:00	18:00:00	+395334037944	Ildegarda_Biondi7@libero.it
29	45	1	137.00	Katafygio «Vardousion»	2	Rosamunda Marcelli	http://bowed-monastery.it	281.09	[]		03:00:00	20:00:00	+390342820321	Giordano89@hotmail.com
30	46	10	40.00	Kocbekov dom na Korošici	2	Gottardo Menozzi	https://subdued-option.net	304.64	[]		08:00:00	15:00:00	+390294137354	Donna4@hotmail.com
31	47	6	106.00	Planinski dom Rašiške cete na Rašici	2	Guiscardo Marzocchi	http://conscious-brass.com	272.42	[]		05:00:00	19:00:00	+390817462428	Diodoro96@yahoo.it
32	48	5	50.00	Prešernova koca na Stolu	2	Galileo Cecchini	https://kind-attendant.net	300.32	[]		07:00:00	21:00:00	+392174052147	Evremondo.Passuello59@email.it
33	49	4	92.00	Planinski dom na Mrzlici	2	Menelao Viscò	https://grounded-wrench.com	274.16	[]		02:00:00	21:00:00	+399765562752	Agostina_Ceccarini@yahoo.com
34	50	1	104.00	Koca na Planini nad Vrhniko	2	Orazio Boschi	https://heavenly-journalist.com	317.88	[]		09:00:00	15:00:00	+393729571483	Iris.Liverani@libero.it
35	51	5	43.00	Zavetišce gorske straže na Jelencih	2	Verena Liguori	http://steel-convection.com	279.33	[]		01:00:00	13:00:00	+396285412537	Pardo76@yahoo.com
36	52	5	66.00	Planinski dom na Gori	2	Pompeo Piras	https://dear-presume.org	263.38	[]		07:00:00	18:00:00	+391762054577	Stefano.Vierin59@yahoo.com
37	53	6	67.00	Bregarjevo zavetišce na planini Viševnik	2	Dott. Beniamino Bordoni	https://menacing-weird.com	278.10	[]		05:00:00	22:00:00	+391896206982	Miriam_Corona94@yahoo.it
38	54	1	150.00	Koca pod Bogatinom	2	Ursino Masi	https://plush-beaver.net	264.03	[]		03:00:00	22:00:00	+391593616186	Brando28@yahoo.com
39	55	8	134.00	Pogacnikov dom na Kriških podih	2	Scolastica Campoli	http://hot-excursion.it	292.87	[]		09:00:00	20:00:00	+395289613356	Procopio55@hotmail.com
40	56	6	94.00	Dom na Smrekovcu	2	Debora Bellomo	https://infatuated-dolman.net	271.87	[]		09:00:00	19:00:00	+390065855305	Barsimeo23@gmail.com
41	57	10	69.00	Refuge Du Chatelleret	2	Sig. Clemenzia Contini	http://costly-disposer.it	331.70	[]		03:00:00	19:00:00	+392268976876	Pammachio_Bortolin@hotmail.com
42	58	2	112.00	Refuge De Chalance	2	Luce Martini	https://precious-integrity.net	301.99	[]		06:00:00	18:00:00	+391855618474	Amico.Scarano@yahoo.com
43	59	2	145.00	Refuge Des Bans	2	Virginia Sepe	https://realistic-opportunity.it	311.06	[]		05:00:00	12:00:00	+393194286890	Oderico_Torchio@yahoo.com
44	60	10	46.00	Refuge De Pombie	2	Cesario Mattioli	https://squiggly-fraud.org	291.80	[]		07:00:00	19:00:00	+396244170618	Diocleziano_Padovan@yahoo.it
45	61	8	44.00	Refuge De Larribet	2	Bonavita Guidotti	http://frizzy-blossom.it	295.43	[]		07:00:00	13:00:00	+390794326038	Calogera_Gasparini94@libero.it
46	62	7	115.00	Refuge Du Mont Pourri	2	Marta Bortot	https://forked-bread.com	310.49	[]		03:00:00	11:00:00	+390705472823	Lidio_Carrozzo@libero.it
47	63	3	137.00	Refuge De La Dent D?Oche	2	Stiriaco Santangelo	https://huge-sink.com	314.02	[]		09:00:00	22:00:00	+393737894962	Catena74@libero.it
48	64	5	38.00	Bergseehütte SAC	2	Ausiliatrice Di Gaetano	https://well-informed-suck.it	321.93	[]		01:00:00	14:00:00	+393492770869	Rufino.Narcisi45@libero.it
49	65	8	141.00	Bivouac au Col de la Dent Blanche CAS	2	Eufemia Loreto	https://corny-marble.org	315.17	[]		02:00:00	19:00:00	+394079013402	Filomeno96@yahoo.it
50	66	7	36.00	Salbitschijenbiwak SAC	2	Diodata Tassi	https://doting-swell.net	329.75	[]		04:00:00	10:00:00	+391435942977	Tizio.Massari41@gmail.com
51	67	10	120.00	Spannorthütte SAC	2	Dr. Taide Tallarico	http://hospitable-mantel.net	320.75	[]		02:00:00	08:00:00	+396697860802	Isabella.Saladino@gmail.com
52	68	8	73.00	Cabane Arpitettaz CAS	2	Girolamo Casella	http://royal-patentee.org	330.06	[]		07:00:00	15:00:00	+398968128847	Nunzio.Caputo@libero.it
53	69	5	148.00	Refugio De Lizara	2	Luminosa Adragna	https://ecstatic-cord.net	327.48	[]		01:00:00	13:00:00	+397075957313	Gumesindo10@gmail.com
54	70	2	55.00	Albergue De Montfalcó	2	Ing. Natalina Madonna	http://reflecting-discharge.it	321.40	[]		09:00:00	16:00:00	+390175881182	Luminosa_Giovinazzo@libero.it
55	71	9	101.00	El Molonillo/Peña Partida	2	Ermete Stanzione	https://decimal-spaghetti.net	327.84	[]		05:00:00	22:00:00	+398551603718	Angelo.Favero@hotmail.com
56	72	9	146.00	La Campiñuela	2	Elisabetta Luise	https://hideous-tie.com	330.65	[]		01:00:00	11:00:00	+397260148149	Lucia.Drago@yahoo.com
57	73	9	103.00	Titov Vrv	2	Furseo Pastorino	https://precious-sprinter.it	307.23	[]		01:00:00	10:00:00	+393762656650	Geronimo_Ambrosio@yahoo.com
58	74	2	108.00	Rifugio Franchetti	2	Mia Fornara	http://firsthand-rabbit.com	265.23	[]		02:00:00	13:00:00	+392749322646	Casilda69@yahoo.it
59	75	6	92.00	Rifugio Semenza	2	Sergio Siracusa	https://tubby-code.com	296.84	[]		04:00:00	14:00:00	+391793640252	Isotta_Lari@hotmail.com
60	76	10	39.00	Rifugio Città di Mortara 	2	Melania Laezza	https://conventional-nylon.net	317.90	[]		05:00:00	16:00:00	+392290719699	Ermelinda.Pardini@libero.it
61	77	3	61.00	Rifugio Andolla	2	Giuliano Salemme	https://solid-subconscious.net	336.48	[]		06:00:00	19:00:00	+392671020001	Unna.Violante92@yahoo.com
62	78	6	77.00	Rifugio Forte dei Marmi	2	Loredana Conti	http://prestigious-sweat.org	324.12	[]		08:00:00	19:00:00	+392242655784	Romualdo_DAlessandro@hotmail.com
63	79	7	118.00	Rifugio Berti	2	Dr. Gigliola Vuillermoz	http://chubby-pressure.it	271.37	[]		09:00:00	19:00:00	+394889647053	Remo_Gruppuso57@libero.it
64	80	9	146.00	Rifugio Premuda	2	Dott. Crescenzia Terlizzi	https://adept-larva.com	266.49	[]		06:00:00	19:00:00	+396824507180	Donatella_Gioacchini@yahoo.it
65	81	2	97.00	Rifugio Elisa	2	Ido Monaci	http://purple-chalet.com	310.86	[]		03:00:00	23:00:00	+398876141139	Siriano42@libero.it
66	82	4	107.00	Rifugio CAI Saronno	2	Alcina Marcon	https://musty-creation.org	326.84	[]		07:00:00	16:00:00	+398470509116	Ricario39@hotmail.com
67	83	4	84.00	Rifugio Picco Ivigna	2	Dott. Filomena Egger	https://forceful-commotion.org	275.78	[]		03:00:00	15:00:00	+397692555345	Assunto.Viviani@email.it
68	84	4	124.00	Rifugio Toesca	2	Gaudino Mollica	http://proper-position.org	332.27	[]		05:00:00	19:00:00	+394271887222	Federico30@gmail.com
69	85	6	44.00	Rifugio Al Cedo	2	Mina Donati	http://wee-vegetable.org	276.47	[]		01:00:00	21:00:00	+390339125135	Samanta10@hotmail.com
70	86	2	114.00	Capanna Gnifetti	2	Davino Palla	http://full-fairy.com	294.58	[]		07:00:00	17:00:00	+394438933021	Tesifonte39@yahoo.com
71	87	4	118.00	Rifugio Aosta	2	Gottardo Mottola	https://agreeable-glider.net	299.13	[]		06:00:00	12:00:00	+398353508568	Novella75@gmail.com
72	88	9	89.00	Rifugio Cevedale	2	Amata Palombo	https://lavish-stonework.org	285.55	[]		08:00:00	17:00:00	+391351697958	Crispino_Toti85@gmail.com
73	89	7	71.00	Rifugio Ponti	2	Adriana De Bonis	https://vigorous-charm.it	298.84	[]		09:00:00	18:00:00	+399610853178	Maggiorino.Spizzirri@yahoo.com
74	90	3	49.00	Rifugio XII Apostoli	2	Aldo Musella	https://slight-schnitzel.it	265.67	[]		08:00:00	15:00:00	+397810636255	Osvaldo93@yahoo.it
75	91	8	106.00	Rifugio Elisabetta Soldini	2	Atanasia Briano	http://direct-canopy.net	270.80	[]		04:00:00	17:00:00	+391111777904	Venusta_Valente51@hotmail.com
76	92	5	53.00	Rifugio Denza	2	Asella Di Battista	https://old-fashioned-citrus.it	277.24	[]		06:00:00	13:00:00	+390447697886	Matteo23@yahoo.com
77	93	8	59.00	Rifugio Fonte Tavoloni 	2	Dott. Dino Melis	https://knotty-mass.com	269.24	[]		01:00:00	10:00:00	+396754628213	Agenore92@hotmail.com
78	94	8	126.00	Rifugio Carducci	2	Sinesio Di Maio	http://arctic-designer.net	307.49	[]		07:00:00	21:00:00	+396868243719	Vera_Leoncini@email.it
79	95	8	123.00	Rifugio Bindesi	2	Dr. Lorella Fiorentini	https://weepy-landscape.net	312.88	[]		06:00:00	20:00:00	+394391258278	Romola54@hotmail.com
80	96	2	103.00	Mountain hut Miroslav Hirtz	2	Angelica Mazzeo	https://pitiful-holiday.org	338.92	[]		04:00:00	20:00:00	+396520604759	Cosma.Campisi83@yahoo.it
81	97	2	96.00	Koca na Blegošu	2	Samuele Ferroni	https://parallel-relay.net	268.16	[]		08:00:00	23:00:00	+399251589420	Gervasio75@yahoo.it
82	98	8	76.00	Wittener Hütte	2	Diogene Bongiorno	http://milky-envelope.com	309.05	[]		08:00:00	14:00:00	+397282208994	Michelangelo71@hotmail.com
83	99	4	111.00	Hochjoch-Hospiz	2	Valeria Lupo	http://handy-food.com	339.22	[]		02:00:00	15:00:00	+397938098927	Esmeralda.Ferrigno65@yahoo.com
84	100	6	59.00	Meilerhütte	2	Concetta Palazzo	https://close-causal.net	296.03	[]		06:00:00	16:00:00	+396099512753	Loreno46@hotmail.com
85	101	3	70.00	Gaudeamushütte	2	Angelo Pianese	http://perky-strategy.it	294.31	[]		03:00:00	18:00:00	+398666015931	Vissia24@hotmail.com
86	102	2	45.00	Rheydter Hütte	2	Gabriele Addari	http://soupy-thunderstorm.org	314.96	[]		08:00:00	14:00:00	+397829524050	Solange_Simula@libero.it
87	103	6	53.00	Sektionshütte Krippen	2	Oronzo Botta	https://treasured-gazelle.org	318.22	[]		07:00:00	21:00:00	+390640222012	Miriam_Gran@yahoo.com
88	104	3	147.00	Neunkirchner Hütte	2	Ilda Dominici	https://ultimate-bucket.com	280.69	[]		08:00:00	17:00:00	+394623480174	Doda.Masi@yahoo.it
89	105	6	92.00	Refugio De Riglos	2	Generoso Cerri	http://queasy-living.com	271.77	[]		09:00:00	16:00:00	+399088016469	Rodrigo_Fedele@email.it
90	106	9	91.00	Salbithütte SAC	2	Liberato Cusumano	https://acidic-tablecloth.net	335.55	[]		08:00:00	14:00:00	+392255035440	Sabrina98@email.it
91	107	5	63.00	Finsteraarhornhütte SAC	2	Mimma De Maria	https://filthy-microlending.net	317.10	[]		07:00:00	15:00:00	+394189869410	Neri_Simula16@yahoo.it
92	108	8	65.00	Cabane des Vignettes CAS	2	Natalia Ciani	http://cooked-phenomenon.org	339.52	[]		04:00:00	18:00:00	+396157884131	Esuperio_Federico23@hotmail.com
93	109	9	82.00	Glecksteinhütte SAC	2	Ing. Nerea Matranga	http://outlying-forever.net	287.59	[]		03:00:00	20:00:00	+395374586457	Nino_Benetti@hotmail.com
94	110	3	35.00	Länta-Hütte SAC	2	Cristiana Iandolo	https://naughty-spandex.it	301.16	[]		04:00:00	20:00:00	+394419292649	Tibaldo.Parise80@libero.it
95	111	3	36.00	Monte-Leone-Hütte SAC	2	Barbarigo Gemma	https://musty-precipitation.org	310.53	[]		02:00:00	19:00:00	+395044474619	Antimo.Borrelli41@email.it
96	112	8	74.00	Ringelspitzhütte SAC	2	Sig. Bassilla Perrone	https://green-orange.org	325.20	[]		05:00:00	15:00:00	+399720338324	Bonaventura.Mingarelli78@gmail.com
97	113	5	75.00	Na poljanama Maljen	2	Gelsomina Terlizzi	http://knowledgeable-inflation.com	272.52	[]		06:00:00	23:00:00	+398168558462	Aresio.Masi@yahoo.com
98	114	7	72.00	Dobra voda	2	Dino Lori	http://glum-spelt.com	326.22	[]		01:00:00	15:00:00	+394574806982	Palladia8@libero.it
99	115	7	35.00	Ivanova hiža	2	Dr. Roberto D'Ambrosio	https://great-snail.net	279.68	[]		08:00:00	15:00:00	+394502272648	Armida.Gianni79@hotmail.com
100	116	2	145.00	Glavica	2	Beniamino Pagliuca	http://elderly-priority.net	300.45	[]		05:00:00	14:00:00	+394888782984	Loriana.Iacono@hotmail.com
101	117	4	50.00	Trpošnjik	2	Deodato Concas	https://granular-downstairs.org	291.25	[]		02:00:00	10:00:00	+398320747305	Eliana34@yahoo.com
102	118	9	100.00	Bitorajka	2	Generosa Gervasi	https://dutiful-mochi.org	292.30	[]		09:00:00	19:00:00	+394780173483	Graciliano_Stanzione@yahoo.com
103	119	5	69.00	Zlatko Prgin	2	Stanislao Celentano	http://moral-bran.net	329.26	[]		06:00:00	16:00:00	+394286106864	Dante_Serena38@yahoo.com
104	120	8	117.00	Prpa	2	Gilda Sorce	http://interesting-week.com	331.72	[]		04:00:00	17:00:00	+396460454011	Filomena52@yahoo.com
105	121	6	68.00	Ždrilo	2	Erico Caiazza	https://extroverted-vet.net	271.18	[]		04:00:00	17:00:00	+395755897991	Tizio_Olivi60@email.it
106	122	10	119.00	Miroslav Hirtz	2	Severa Marinucci	https://ajar-noodle.org	315.72	[]		06:00:00	14:00:00	+396471445709	Zaira.Taormina28@yahoo.com
107	123	4	72.00	Jezerce	2	Proserpina Vella	https://enchanted-table.net	302.96	[]		01:00:00	14:00:00	+398567479505	Egizia.DiLiberto@libero.it
108	124	5	86.00	Ivica Sudnik	2	Sig. Quinziano Cara	http://amazing-practitioner.org	301.09	[]		02:00:00	15:00:00	+390507867407	Rufino81@yahoo.com
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
1	125	72	2	Italy	Lucca		Ofelia laziale
2	126	65	2	Italy	Varese		Sesto Amina
3	127	278	2	Italy	Verona		Enrico terme
4	128	99	2	Italy	Verbano-Cusio-Ossola		Borgo Natalia
5	129	29	2	Italy	Pesaro e Urbino		San Dino sardo
6	130	47	2	Italy	Massa-Carrara		Landi salentino
7	131	191	2	Italy	Barletta-Andria-Trani		Elifio calabro
8	132	149	2	Italy	Crotone		Fumagalli nell'emilia
9	133	281	2	Italy	Messina		Scrofani calabro
10	134	56	2	Italy	Grosseto		Borgo Nilde del friuli
11	135	297	2	Italy	Viterbo		Settimio terme
12	136	39	2	Italy	Bergamo		Sesto Adelasia
13	137	272	2	Italy	Massa-Carrara		Settimo Loretta
14	138	158	2	Italy	Cremona		Cerrani laziale
15	139	126	2	Italy	Teramo		Settimo Abramo
16	140	77	2	Italy	Vibo Valentia		Borgo Giona umbro
17	141	273	2	Italy	Avellino		Sesto Scolastica veneto
18	142	188	2	Italy	Pisa		Sesto Valter terme
19	143	294	2	Italy	Piacenza		Quarto Adina
20	144	248	2	Italy	Taranto		Ultimo calabro
21	145	234	2	Italy	Carbonia-Iglesias		Maggi terme
22	146	212	2	Italy	Piacenza		Settimo Norberto
23	147	6	2	Italy	L'Aquila		Settimo Diodata
24	148	298	2	Italy	Messina		San Viliana laziale
25	149	25	2	Italy	Trento		Settimo Regina
26	150	137	2	Italy	Reggio Emilia		Cingolani umbro
27	151	83	2	Italy	Firenze		San Alano del friuli
28	152	164	2	Italy	Catania		Borgo Elisabetta salentino
29	153	124	2	Italy	Brescia		Quarto Ruperto salentino
30	154	284	2	Italy	Foggia		Di Blasi umbro
31	155	90	2	Italy	Crotone		San Filomena
32	156	150	2	Italy	Cremona		Borgo Beltramo
33	157	226	2	Italy	Vicenza		Borgo Gianpietro a mare
34	158	5	2	Italy	Reggio Calabria		Margiotta del friuli
35	159	292	2	Italy	Forlì-Cesena		Vitalico veneto
36	160	75	2	Italy	Rovigo		San Abramio del friuli
37	161	176	2	Italy	Modena		San Cora
38	162	157	2	Italy	Verbano-Cusio-Ossola		Poggi nell'emilia
39	163	141	2	Italy	Ragusa		Balducci terme
40	164	83	2	Italy	Rimini		Caiazzo laziale
41	165	20	2	Italy	Roma		Velio a mare
42	166	128	2	Italy	Benevento		Quarto Agnese salentino
43	167	58	2	Italy	Latina		Pellegrino sardo
44	168	282	2	Italy	Pesaro e Urbino		Gatto veneto
45	169	51	2	Italy	Genova		Pardo ligure
46	170	25	2	Italy	Trento		Settimo Onofrio
47	171	141	2	Italy	Rovigo		Settimo Liboria a mare
48	172	161	2	Italy	Caserta		Borgo Taziano
49	173	165	2	Italy	Ravenna		Gustavo lido
50	174	30	2	Italy	Genova		Settimo Ulstano
51	175	29	2	Italy	Bolzano		Settimo Paciano
52	176	11	2	Italy	Oristano		Raffaele calabro
53	177	241	2	Italy	Ancona		Quirino umbro
54	178	8	2	Italy	Pistoia		Bassiano umbro
55	179	36	2	Italy	Reggio Emilia		Achille a mare
56	180	188	2	Italy	Trento		Quarto Ermenegarda
57	181	181	2	Italy	Massa-Carrara		Settimo Giorgio nell'emilia
58	182	247	2	Italy	Fermo		Marciano a mare
59	183	174	2	Italy	Livorno		Piva salentino
60	184	152	2	Italy	Salerno		Casilda lido
61	185	123	2	Italy	Vicenza		Quarto Benigna
62	186	73	2	Italy	Imperia		Settimo Ermenegarda ligure
63	187	181	2	Italy	Firenze		Borgo Menardo
64	188	260	2	Italy	Oristano		Polidori terme
65	189	165	2	Italy	Oristano		Andrea nell'emilia
66	190	94	2	Italy	Pescara		Quarto Lucrezia
67	191	164	2	Italy	Enna		San Flaminia
68	192	48	2	Italy	Prato		San Degna
69	193	30	2	Italy	Ogliastra		Borgo Marinetta calabro
70	194	15	2	Italy	Matera		Loreno salentino
71	195	25	2	Italy	Pisa		Valter calabro
72	196	257	2	Italy	Chieti		Sesto Aurelia umbro
73	197	124	2	Italy	Ragusa		Criscenti nell'emilia
74	198	30	2	Italy	Bari		San Rubiano
75	199	252	2	Italy	Brindisi		Borgo Manuela
76	200	204	2	Italy	Olbia-Tempio		Annabella calabro
77	201	103	2	Italy	Forlì-Cesena		Sesto Gioacchina sardo
78	202	214	2	Italy	Taranto		Borgo Amina
79	203	111	2	Italy	Macerata		Albino nell'emilia
80	204	179	2	Italy	Prato		Borgo Damaso veneto
81	205	113	2	Italy	Bergamo		Borgo Vittore
82	206	260	2	Italy	Prato		Castagna ligure
83	207	269	2	Italy	Rovigo		Quarto Pollione terme
84	208	99	2	Italy	Aosta		Correale a mare
85	209	52	2	Italy	Vicenza		San Evelina
86	210	227	2	Italy	Pavia		Zabedeo del friuli
87	211	233	2	Italy	Chieti		Demurtas lido
88	212	240	2	Italy	Campobasso		Immacolata a mare
89	213	180	2	Italy	Venezia		Sesto Siro laziale
90	214	47	2	Italy	Catania		Elettra sardo
91	215	175	2	Italy	Teramo		Borgo Mirella
92	216	40	2	Italy	Bari		Roberti ligure
93	217	55	2	Italy	Teramo		Elsa salentino
94	218	92	2	Italy	Viterbo		Settimo Costante
95	219	235	2	Italy	Lecce		Borgo Edilberto a mare
96	220	55	2	Italy	Foggia		Quarto Gesualdo veneto
97	221	149	2	Italy	Fermo		Cosma umbro
98	222	206	2	Italy	Pordenone		Tornatore terme
99	223	102	2	Italy	Matera		Vittoriano veneto
100	224	53	2	Italy	Sassari		Borgo Amanda ligure
101	225	158	2	Italy	Venezia		Roma
102	226	139	2	Italy	Napoli		Nicea laziale
103	227	233	2	Italy	Pisa		San Giuda
104	228	186	2	Italy	Rimini		De Cicco lido
105	229	37	2	Italy	Ogliastra		Borgo Otilia
106	230	69	2	Italy	Aosta		Sesto Delia sardo
107	231	209	2	Italy	Pistoia		Borgo Simona nell'emilia
108	232	286	2	Italy	Treviso		Narseo calabro
109	233	188	2	Italy	Reggio Emilia		Castiello sardo
110	234	55	2	Italy	Vibo Valentia		Flaviana nell'emilia
111	235	180	2	Italy	Massa-Carrara		Graziani a mare
112	236	104	2	Italy	Rieti		Casimiro lido
113	237	179	2	Italy	Imperia		Cardella veneto
114	238	251	2	Italy	Pesaro e Urbino		Icaro umbro
115	239	98	2	Italy	Modena		Settimo Liberto
116	240	265	2	Italy	Ragusa		Sesto Gineto calabro
117	241	135	2	Italy	Milano		San Saturnino
118	242	228	2	Italy	Isernia		Sesto Cuzia
119	243	228	2	Italy	Enna		Borgo Sabele
120	244	170	2	Italy	Cuneo		Peroni nell'emilia
121	245	176	2	Italy	Bergamo		Virginio sardo
122	246	47	2	Italy	Cagliari		Barbagallo ligure
123	247	234	2	Italy	Genova		Sestito ligure
124	248	125	2	Italy	Cagliari		Palla sardo
125	249	178	2	Italy	Ascoli Piceno		Lodovica ligure
126	250	42	2	Italy	Cremona		Cavallari calabro
127	251	1	2	Italy	Venezia		Severa sardo
128	252	291	2	Italy	Asti		San Enzo sardo
129	253	215	2	Italy	Vercelli		Damaso umbro
130	254	1	2	Italy	Ascoli Piceno		Alcino ligure
131	255	1	2	Italy	Vibo Valentia		San Rosita
132	256	29	2	Italy	Massa-Carrara		Pacini veneto
133	257	222	2	Italy	Bolzano		Marcello terme
134	258	118	2	Italy	Potenza		Sesto Acilio
135	259	158	2	Italy	Prato		San Ottaviano
136	260	102	2	Italy	Benevento		Bonazzi calabro
137	261	1	2	Italy	Reggio Emilia		Settimo Adalgiso
138	262	1	2	Italy	Gorizia		Sorbello del friuli
139	263	43	2	Italy	Rieti		Quarto Asimodeo
140	264	1	2	Italy	Verona		Borgo Maida
141	265	100	2	Italy	Matera		Settimo Raimondo
142	266	215	2	Italy	Pavia		Contini nell'emilia
143	267	91	2	Italy	Lodi		Gamberini calabro
144	268	29	2	Italy	Savona		Quarto Ovidio
145	269	158	2	Italy	Verona		Valentino terme
146	270	240	2	Italy	Pistoia		Vitale calabro
147	271	268	2	Italy	Grosseto		Ortensia ligure
148	272	138	2	Italy	Udine		Eufebio sardo
149	273	241	2	Italy	Biella		Sesto Oderico laziale
150	274	60	2	Italy	Alessandria		Puccio umbro
151	275	261	2	Italy	Piacenza		Sesto Mimma
152	276	174	2	Italy	Verona		Borgo Ludovico
153	277	211	2	Italy	Catania		Borgo Adone
154	278	102	2	Italy	Roma		Sesto Laurentino sardo
155	279	56	2	Italy	Verona		Quarto Gregorio calabro
156	280	29	2	Italy	Ogliastra		San Melania
157	281	184	2	Italy	Latina		Sesto Galatea salentino
158	282	92	2	Italy	Lucca		San Prudenzio
159	283	190	2	Italy	Monza e della Brianza		San Gigliola
160	284	72	2	Italy	Verona		Settimo Pacomio lido
161	285	151	2	Italy	Ravenna		Cavallaro laziale
162	286	92	2	Italy	Lucca		Marrone veneto
163	287	296	2	Italy	Pesaro e Urbino		Adalfredo laziale
164	288	292	2	Italy	Taranto		Carriero nell'emilia
165	289	44	2	Italy	Benevento		Spadafora terme
166	290	30	2	Italy	Verbano-Cusio-Ossola		Lorena calabro
167	291	124	2	Italy	Milano		Settimo Agesilao
168	292	116	2	Italy	Massa-Carrara		Tolomeo sardo
169	293	178	2	Italy	Parma		Di Maria lido
170	294	191	2	Italy	Avellino		Tagliaferri veneto
171	295	248	2	Italy	Lodi		Ortensia nell'emilia
172	296	106	2	Italy	Prato		Borgo Genziano
173	297	210	2	Italy	Potenza		Sesto Gianpaolo lido
174	298	271	2	Italy	Brescia		Quarto Achille salentino
175	299	232	2	Italy	Pescara		Sesto Eberardo
176	300	213	2	Italy	Avellino		Settimo Saturniano
177	301	250	2	Italy	Modena		Settimo Ella sardo
178	302	102	2	Italy	Pesaro e Urbino		Borelli lido
179	303	42	2	Italy	Enna		Sesto Letterio laziale
180	304	283	2	Italy	Messina		Sesto Delfina salentino
181	305	63	2	Italy	Alessandria		Quarto Consolata
182	306	200	2	Italy	Matera		Sesto Daniele umbro
183	307	6	2	Italy	Ferrara		Angelini laziale
184	308	254	2	Italy	Siena		Lendinara
185	309	174	2	Italy	Torino		Quarto Teodolinda salentino
186	310	198	2	Italy	Sondrio		Napoli
187	311	79	2	Italy	Milano		Settimo Saturniano
188	312	234	2	Italy	Lodi		Gioventino terme
189	313	222	2	Italy	Frosinone		Luchini nell'emilia
190	314	92	2	Italy	Ancona		Gamper calabro
191	315	66	2	Italy	Trieste		Cherubino sardo
192	316	162	2	Italy	Venezia		Quarto Davide
193	317	29	2	Italy	Modena		Sesto Aureliano
194	318	245	2	Italy	Como		Costa terme
195	319	41	2	Italy	Firenze		Borgo Galileo
196	320	114	2	Italy	Cosenza		Settimo Livino veneto
197	321	250	2	Italy	Pesaro e Urbino		Lazzarini laziale
198	322	287	2	Italy	Lucca		Rolfo terme
199	323	114	2	Italy	Benevento		Sesto Abbondanzio
200	324	246	2	Italy	Ancona		Bonanni laziale
201	325	41	2	Italy	Olbia-Tempio		Settimo Amos
202	326	171	2	Italy	Latina		Borgo Bernadetta
203	327	410	2	Italy	Benevento		Asdrubale ligure
204	328	190	2	Italy	Aosta		Sesto Settimo veneto
205	329	59	2	Italy	Verona		San Giorgio calabro
206	330	270	2	Italy	Piacenza		Quarto Brigida laziale
207	331	182	2	Italy	Avellino		Termine calabro
208	332	158	2	Italy	Piacenza		Scarpellini veneto
209	333	130	2	Italy	Sassari		Pamela sardo
210	334	228	2	Italy	Massa-Carrara		Settimo Eutalio
211	335	33	2	Italy	Siena		Ippoliti a mare
212	336	85	2	Italy	Catania		Euseo umbro
213	337	9	2	Italy	Bologna		Quarto Rodrigo
214	338	249	2	Italy	Siena		Mattia laziale
215	339	149	2	Italy	Lucca		Sesto Edoardo ligure
216	340	203	2	Italy	Pordenone		Sesto Rocco
217	341	193	2	Italy	Napoli		Atzeni ligure
218	342	218	2	Italy	Pescara		Santamaria nell'emilia
219	343	172	2	Italy	Lucca		Quarto Zefiro
220	344	203	2	Italy	Parma		Elifio calabro
221	345	232	2	Italy	Terni		Borgo Fausta
222	346	3	2	Italy	Foggia		Gabrielli ligure
223	347	94	2	Italy	Trapani		Tosi salentino
224	348	201	2	Italy	Biella		San Eberardo
225	349	159	2	Italy	Grosseto		Telica salentino
226	350	222	2	Italy	Lucca		Settimo Efrem
227	351	50	2	Italy	Prato		Di Bella umbro
228	352	173	2	Italy	Viterbo		Settimo Simone ligure
229	353	200	2	Italy	Vercelli		Zappia terme
230	354	148	2	Italy	Campobasso		Aurelia sardo
231	355	286	2	Italy	Napoli		Sesto Lorenzo
232	356	91	2	Italy	Barletta-Andria-Trani		Borgo Ombretta lido
233	357	176	2	Italy	Vibo Valentia		Sesto Bernardo lido
234	358	294	2	Italy	Bologna		Fabrizio lido
235	359	254	2	Italy	Fermo		Adone sardo
236	360	231	2	Italy	Grosseto		Sesto Manlio umbro
237	361	150	2	Italy	Palermo		Foca calabro
238	362	114	2	Italy	Isernia		Quarto Gioberto
239	363	117	2	Italy	Ravenna		Cellini del friuli
240	364	294	2	Italy	Salerno		Iannone nell'emilia
241	365	141	2	Italy	Pesaro e Urbino		Quarto Amauri
242	366	239	2	Italy	Isernia		Rigoni nell'emilia
243	367	190	2	Italy	Udine		Settimo Gildo
244	368	300	2	Italy	Aosta		Quarto Taziano del friuli
245	369	124	2	Italy	Medio Campidano		Puglisi salentino
246	370	264	2	Italy	Reggio Emilia		Leonio laziale
247	371	273	2	Italy	Grosseto		Borgo Belina
248	372	247	2	Italy	Lecce		Sesto Salvatore ligure
249	373	278	2	Italy	La Spezia		Pavone ligure
250	374	9	2	Italy	Reggio Calabria		Torrisi veneto
251	375	197	2	Italy	Ancona		Borgo Agazio
252	376	199	2	Italy	Latina		Valeri del friuli
253	377	97	2	Italy	Rieti		Sesto Serena sardo
254	378	129	2	Italy	Macerata		San Riccarda sardo
255	379	116	2	Italy	Rieti		San Ezechiele sardo
256	380	27	2	Italy	Cuneo		Santucci veneto
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address, altitude) FROM stdin;
1	0	0101000020E610000043D95E8288A91C40720950EB278D4640	Start Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
2	0	0101000020E610000051A7B8816D921C408D966B20C98C4640	End Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
3	0	0101000020E6100000C668CC0D4EA81C40DA8DB03B2C8D4640		Ref Point 1	1256.85
4	0	0101000020E6100000116FE90D01A21C4022DFF1622B8D4640		Ref Point 2	1283.61
5	0	0101000020E61000004337FB03E5161B401CEBE2361A844640	Start Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
6	0	0101000020E61000001092054CE0161B401FD8F15F20844640	End Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
7	0	0101000020E610000058CB9D9960C81B408731E9EFA59C4640	Start Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
8	0	0101000020E61000003BE0BA6246C81B401E34BBEEAD9C4640	End Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
9	0	0101000020E61000007EE4D6A4DBC21B40147AFD497C9C4640		fountain	2027.00
10	0	0101000020E6100000B7B8C667B2BF1B4090A4A487A19B4640		Peak	2131.00
11	0	0101000020E61000005F9A22C0E96520406C76A4FACE554640	Start Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
12	0	0101000020E61000002368CC24EA652040CC7EDDE9CE554640	End Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
13	0	0101000020E61000006B662D05A46D20401557957D57564640		Ref Point 1	482.53
14	0	0101000020E610000024D236FE44652040813D26529A554640		Ref Point 2	242.59
15	0	0101000020E61000009F3E027FF83920409E245D33F9804640	Start Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
16	0	0101000020E610000099F56228273A20408DEDB5A0F7804640	End Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
17	0	0101000020E61000002D64979723B62440C66F2527958D4740	Edmund-Graf-Hütte	6574 Pettneu am Arlberg, Tyrol, Austria	\N
18	0	0101000020E6100000455BF9D0380E2A4056DBD4F478794740	Dr.Hernaus-Stöckl	9020 Klagenfurt, Kärnten, Austria	\N
19	0	0101000020E61000003AD4CD22968A2D406DAF4FF575F14740	Amstettner Hütte	3340 Waidhofen an der Ybbs, Niederösterreich, Austria	\N
20	0	0101000020E61000003470C88518362B404F23C0A11DEA4740	Hochleckenhaus	4853 Steinbach am Attersee, Oberösterreich, Austria	\N
21	0	0101000020E6100000745CA7EA5C3230400E95C9F10B114840	Kampthalerhütte	2384 Breitenfurt bei Wien, Niederösterreich, Austria	\N
22	0	0101000020E610000059E5350827672B402FB2862AC2D34740	Lambacher Hütte	4822 Bad Goisern, Oberösterreich, Austria	\N
23	0	0101000020E610000019FDD2643FA62340662869A087B24740	Lustenauer Hütte	6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria	\N
24	0	0101000020E610000036849931B0F52A4014BD78F039C44740	Gablonzer Hütte	4825 Gosau-Hintertal, Oberösterreich, Austria	\N
25	0	0101000020E6100000202F5A3629BF3740D489BAC5B2144340	Katafygio «Flampouri»	136 72 Acharnes, Attica region, Greece	\N
26	0	0101000020E6100000103E4BA24D3F2B40F731169C1AC04740	Simonyhütte	4830 Hallstatt, Oberösterreich, Austria	\N
27	0	0101000020E610000033190145D5182740BF9048EBDFA04740	Vinzenz-Tollinger-Hütte	6060 Hall in Tirol, Tyrol, Austria	\N
28	0	0101000020E61000001F1E0B5901B82E4091BFCBF1EAB34740	Ottokar-Kernstock-Haus	8600 Bruck an der Mur, Steiermark, Austria	\N
29	0	0101000020E610000018E4FB977DBF2A40D6A3B4422D754740	Reisseckhütte	9814 Mühldorf, Mölltal, Kärnten, Austria	\N
30	0	0101000020E61000007B116DC7D4A52540C0401020436D4740	Vernagthütte	Austria	\N
31	0	0101000020E6100000286211C30EF323407EC9C6832D884740	Wormser Hütte	Austria	\N
32	0	0101000020E6100000999CDA19A60E24406CD097DEFEA04740	Biberacher Hütte	Austria	\N
33	0	0101000020E610000007BC276AC4133740DDF934DDA1A84440	Katafygio «1777»	620 55 Kerkini, Central Macedonia region, Greece	\N
34	0	0101000020E6100000D5AF743E3C0B2A40E6E786A6EC704840	Hochwaldhütte	Germany	\N
35	0	0101000020E6100000C2FBAA5CA8EC19408FC536A968544940	Kölner Eifelhütte	Germany	\N
36	0	0101000020E6100000323CF6B358D223401763601DC7794740	Madrisahütte	Austria	\N
37	0	0101000020E6100000313F373465472640CDC98B4CC07F4740	Dresdner Hütte	Austria	\N
38	0	0101000020E6100000CDCCCCCCCC6C24403E07962364A84740	Fiderepasshütte	Germany	\N
39	0	0101000020E6100000B727486C77172440A9DDAF027C9B4740	Göppinger Hütte	Austria	\N
40	0	0101000020E6100000A379008BFC622340C7629B54348A4740	Oberzalimhütte	Austria	\N
41	0	0101000020E610000013B70A62A0932740B3B45373B99D4740	Rastkogelhütte	Austria	\N
42	0	0101000020E61000009D2D20B41E0E2440D54F49E70DC24740	Ansbacher Skihütte im Allgäu	Germany	\N
43	0	0101000020E610000009E066F16249244097E13FDD408F4740	Kaltenberghütte	Austria	\N
44	0	0101000020E61000000AD7A3703D0A2640E277D32D3B944740	Schweinfurter Hütte	Austria	\N
45	0	0101000020E61000006DC438245A213640DA172BC5E9574340	Katafygio «Vardousion»	330 53 Delphi, Central Greece region, Greece	\N
46	0	0101000020E6100000630F270F8F472D40336D62F5852D4740	Kocbekov dom na Korošici	3334 Luče, Mozirje, Slovenia	\N
47	0	0101000020E6100000D1F5D08072062D40D25C9F20CE114740	Planinski dom Rašiške cete na Rašici	1211 Ljubljana, Šmartno, Slovenia	\N
48	0	0101000020E6100000F70F966F85592C40971550C935374740	Prešernova koca na Stolu	4274 Žirovnica, Slovenia	\N
49	0	0101000020E6100000AA5C8F5FCB372E408E6CD71919184740	Planinski dom na Mrzlici	3302 Griže, Slovenia	\N
50	0	0101000020E6100000651A4D2EC6802C40577A6D3656FC4640	Koca na Planini nad Vrhniko	1360 Vrhnika, Slovenia	\N
51	0	0101000020E6100000245DF94DDD322C4077DAB7E6D0144740	Zavetišce gorske straže na Jelencih	0, -, Slovenia	\N
52	0	0101000020E6100000313F3734656F2E406F7F2E1A32264740	Planinski dom na Gori	Šentjungert, 3310 Žalec, Slovenia	\N
53	0	0101000020E610000098F2E7FC90A22B40C7CBA2C928274740	Bregarjevo zavetišce na planini Viševnik	4265 Bohinjsko jezero, Slovenia	\N
54	0	0101000020E610000091860959CC862B401635F33FD4244740	Koca pod Bogatinom	4265 Bohinjsko jezero, Slovenia	\N
55	0	0101000020E6100000678B3942E5992B40007F639573334740	Pogacnikov dom na Kriških podih	5232 Soca, Slovenia	\N
56	0	0101000020E610000008F580BBE4CC2D402A9C0F95E7344740	Dom na Smrekovcu	3325 Šoštanj, Slovenia	\N
57	0	0101000020E610000073F6CE68AB32194060E811A3E77C4640	Refuge Du Chatelleret	38520 Saint Christophe En Oisans, Isère, France	\N
58	0	0101000020E610000084622B685AF218408177F2E9B16B4640	Refuge De Chalance	5800 La Chapelle En Valgaudemar, Hautes-Alpes, France	\N
59	0	0101000020E6100000963D096CCE711940AE7FD767CE6A4640	Refuge Des Bans	5290 Vallouise, Hautes-Alpes, France	\N
60	0	0101000020E6100000DEAB5626FC52DBBFAED689CBF16A4540	Refuge De Pombie	65400 Laruns, Pyrénées-Atlantiques, France	\N
61	0	0101000020E6100000A69C2FF65E7CD2BFA9F92AF9D86D4540	Refuge De Larribet	65400 Arrens, Marsous, Hautes-Pyrénées, France	\N
62	0	0101000020E61000009CA6CF0EB84E1B401232906797C34640	Refuge Du Mont Pourri	73210 Peisey Nancroix, Savoie, France	\N
63	0	0101000020E6100000C712D6C6D8E91A40BF81C98D222D4740	Refuge De La Dent D?Oche	74500 Bernex, Haute-Savoie, France	\N
64	0	0101000020E6100000BEBDCA2243F820405620D41E27544740	Bergseehütte SAC	Uri, Switzerland	\N
65	0	0101000020E6100000CDD5732CA96D1E40F591820D5C054740	Bivouac au Col de la Dent Blanche CAS	Wallis, Switzerland	\N
66	0	0101000020E610000060F1FE571F0C2140D6BA5B328C564740	Salbitschijenbiwak SAC	Uri, Switzerland	\N
67	0	0101000020E610000084EAC5BE53052140F224048A5C664740	Spannorthütte SAC	Uri, Switzerland	\N
68	0	0101000020E6100000827FB24EBCB71E406113E452EB0C4740	Cabane Arpitettaz CAS	Wallis, Switzerland	\N
69	0	0101000020E61000008A75AA7CCF48E4BF588BF447BD614540	Refugio De Lizara	22730, Aragón, Spain	\N
70	0	0101000020E6100000AE56C01909F8E43F58DB5E1CA6064540	Albergue De Montfalcó	22585 Tolva, Aragón, Spain	\N
71	0	0101000020E61000000A4CFFBF1E610AC08B780953B6904240	El Molonillo/Peña Partida	18160 Güejar Sierra, Andalucía, Spain	\N
72	0	0101000020E610000029110100A92D0AC0F39F054F27844240	La Campiñuela	18417 Trévelez, Andalucía, Spain	\N
73	0	0101000020E61000008E79782A3BCC3440BEAE152301FF4440	Titov Vrv	Tetovo, Municipality of Tetovo, North Macedonia	\N
74	0	0101000020E6100000A2EC2DE57C212B40C7F143A5113D4540	Rifugio Franchetti	Pietracamela, Abruzzo, Italy	\N
75	0	0101000020E610000052E2299ABDFA2840518B1C7D27114740	Rifugio Semenza	Tambre, Veneto, Italy	\N
76	0	0101000020E6100000A197F67244A31F40313D06D094EE4640	Rifugio Città di Mortara 	Alagna Valsesia, Piemonte, Italy	\N
77	0	0101000020E61000006E39F29B1D242040AB1ED555260C4740	Rifugio Andolla	Antrona Schieranico, Piemonte, Italy	\N
78	0	0101000020E61000000AD80E46ECAB2440B70BCD751AFF4540	Rifugio Forte dei Marmi	Stazzema, Toscana, Italy	\N
79	0	0101000020E6100000A88B14CAC2CF284038D66AB4C1504740	Rifugio Berti	Comelico Superiore, Veneto, Italy	\N
80	0	0101000020E610000071B43E4052BB2B406FE70CD649CF4640	Rifugio Premuda	San Dorligo della Valle, Friuli Venezia Giulia, Italy	\N
81	0	0101000020E61000006CCF2C0950C32240191BBAD91FF84640	Rifugio Elisa	Mandello del Lario, Lombardia, Italy	\N
82	0	0101000020E6100000A5BDC11726B31F40F90FE9B7AFFB4640	Rifugio CAI Saronno	Macugnaga, Piemonte, Italy	\N
83	0	0101000020E610000098DD9387857A2640A930B610E4584740	Rifugio Picco Ivigna	Scena, Trentino Alto Adige, Italy	\N
84	0	0101000020E61000003AE97DE36B8F1C404AEF1B5F7B8A4640	Rifugio Toesca	Bussoleno, Piemonte, Italy	\N
85	0	0101000020E6100000A913D044D8E02040382D78D1570C4740	Rifugio Al Cedo	Santa Maria Maggiore, Piemonte, Italy	\N
86	0	0101000020E6100000449D5ECE11661F4009ED8B3A29F34640	Capanna Gnifetti	Gressoney La Trinitè, Valle d?Aosta, Italy	\N
87	0	0101000020E6100000B8AE9811DE3E1E403A048E041AFC4640	Rifugio Aosta	Bionaz, Valle d?Aosta, Italy	\N
88	0	0101000020E6100000BBB31B22135525408EA8F523EA374740	Rifugio Cevedale	Pejo, Trentino Alto Adige, Italy	\N
89	0	0101000020E61000000D33349E08722340F0A485CB2A204740	Rifugio Ponti	Val Masino, Lombardia, Italy	\N
90	0	0101000020E6100000C46D7E0DD2B125405364085B47134740	Rifugio XII Apostoli	Stenico, Trentino Alto Adige, Italy	\N
91	0	0101000020E61000009F1C058882591B40DDD1FF722DE24640	Rifugio Elisabetta Soldini	Courmayeur, Valle d?Aosta, Italy	\N
92	0	0101000020E610000061D57994804F25409903A4C1291F4740	Rifugio Denza	Vermiglio, Trentino Alto Adige, Italy	\N
93	0	0101000020E61000000C1F115322F92A40338AE596560F4540	Rifugio Fonte Tavoloni 	Ovindoli, Abruzzo, Italy	\N
94	0	0101000020E610000037C2A2224EBF2840F2ED5D83BE4E4740	Rifugio Carducci	Auronzo di Cadore, Veneto, Italy	\N
95	0	0101000020E61000006FA53220D64E26400DE02D90A0044740	Rifugio Bindesi	Trento, Trentino Alto Adige, Italy	\N
96	0	0101000020E610000001C11C3D7ECB2D40C670D0B9365A4640	Mountain hut Miroslav Hirtz	53287 Jablanac, Ličko-senjska županija, Croatia	\N
97	0	0101000020E6100000398485EEED352C4098331D324C154740	Koca na Blegošu	4224 Gorenja vas, Slovenia	\N
98	0	0101000020E610000040F850A225BF1F400F441669E2594940	Wittener Hütte	Germany	\N
99	0	0101000020E610000000FDBE7FF3AA25409A99999999694740	Hochjoch-Hospiz	Austria	\N
100	0	0101000020E6100000D7A02FBDFD412640CDCCCCCCCCB44740	Meilerhütte	Germany	\N
101	0	0101000020E610000050C422861DA628406E85B01A4BC64740	Gaudeamushütte	Austria	\N
102	0	0101000020E6100000179CC1DF2F961940D5EB1681B15C4940	Rheydter Hütte	Germany	\N
103	0	0101000020E6100000FB66518EB8562C4057E883656C744940	Sektionshütte Krippen	Germany	\N
104	0	0101000020E61000001F7A839D234C2C40B45EF68814A34740	Neunkirchner Hütte	2620 Neunkirchen, Steiermark, Austria	\N
105	0	0101000020E61000009CE379FC2043E7BF8FC536A9682C4540	Refugio De Riglos	22808, Aragón, Spain	\N
106	0	0101000020E6100000563D4FC4941A2140EBB308E997564740	Salbithütte SAC	Uri, Switzerland	\N
107	0	0101000020E61000001D55C855B23A2040B8EB64DCCE424740	Finsteraarhornhütte SAC	Wallis, Switzerland	\N
108	0	0101000020E6100000DEFD765E1AE71D4038777A52B2FE4640	Cabane des Vignettes CAS	Wallis, Switzerland	\N
109	0	0101000020E6100000E769EE0B84312040FBE19FAF02504740	Glecksteinhütte SAC	Bern, Switzerland	\N
110	0	0101000020E6100000752B5D3C5F152240D9971BDB51454740	Länta-Hütte SAC	Graubünden, Switzerland	\N
111	0	0101000020E610000055ADDEFA26292040BAB9F14860214740	Monte-Leone-Hütte SAC	Wallis, Switzerland	\N
112	0	0101000020E6100000557F0CE8F9C222408F373B25D26E4740	Ringelspitzhütte SAC	Graubünden, Switzerland	\N
113	0	0101000020E6100000A4AA09A2EE0334408E23D6E253104640	Na poljanama Maljen	Maljen, Serbia	\N
114	0	0101000020E6100000A9DE1AD82A313440C5E6E3DA50114640	Dobra voda	Suvobor, Serbia	\N
115	0	0101000020E61000007250C24CDBFF2E402D095053CBC64640	Ivanova hiža	Karlovac town environment, Karlovačka, Croatia	\N
116	0	0101000020E6100000C6DCB5847CC02F40C746205ED7EB4640	Glavica	Medvednica, City of Zagreb, Croatia	\N
117	0	0101000020E6100000FFEC478AC8B83040D3F6AFAC34BD4540	Trpošnjik	Mosor, Splitsko-dalmatinska, Croatia	\N
118	0	0101000020E6100000C217265305932D40C4CE143AAFA54640	Bitorajka	Bitoraj, Primorsko-goranska, Croatia	\N
119	0	0101000020E6100000AB09A2EE0360304006D847A7AE084640	Zlatko Prgin	Dinara, Šibensko-kninska, Croatia	\N
120	0	0101000020E6100000D3872EA86F492E405C8FC2F528444640	Prpa	Velebit, Ličko-senjska, Croatia	\N
121	0	0101000020E6100000787FBC57AD5C2E408BFD65F7E43D4640	Ždrilo	Velebit, Ličko-senjska, Croatia	\N
122	0	0101000020E610000086032159C0F42D40B21188D7F59B4640	Miroslav Hirtz	Velika Kapela, Primorsko-goranska, Croatia	\N
123	0	0101000020E6100000A31EA2D11DAC3140462575029AC04640	Jezerce	Papuk, Požeško-slavonska, Croatia	\N
124	0	0101000020E61000003EE8D9ACFA4C2F405F0CE544BBE24640	Ivica Sudnik	Samoborska gora, Zagrebačka, Croatia	\N
125	0	0101000020E6100000AD3BCC4D8A7D2840CBDF185D39124640		1 Strada Furseo, Ofelia laziale, Italy	\N
126	0	0101000020E6100000AF5E454607602340EDF2AD0FEB6B4440		901 Contrada Clarenzio, Sesto Amina, Italy	\N
127	0	0101000020E610000050BA3EBD63AA2840D5DBB0B7DE294640		1 Strada Calogera, Enrico terme, Italy	\N
128	0	0101000020E6100000E7204322C8042640F6AEE6A507F54540		1 Via Spagnolo, Borgo Natalia, Italy	\N
129	0	0101000020E61000009F11B6E919B02140ABAC12D154364640		9 Rotonda Scarano, San Dino sardo, Italy	\N
130	0	0101000020E61000009EBFBFF7ED2224402DAAEA8ABEE84640		4 Rotonda Noto, Landi salentino, Italy	\N
131	0	0101000020E6100000FF209221C76E274017844DF8002D4640		655 Rotonda Natale, Elifio calabro, Italy	\N
132	0	0101000020E6100000C2B28817FA8E2340D5809C8B1AB04640		3 Rotonda Maggio, Fumagalli nell'emilia, Italy	\N
133	0	0101000020E6100000107BFC3960762540600A6A53D0274740		635 Incrocio Palombi, Scrofani calabro, Italy	\N
134	0	0101000020E6100000CF5AC0BAE0462B40B9ED314745E34640		362 Piazza Ermete, Borgo Nilde del friuli, Italy	\N
135	0	0101000020E610000048B42E7FCFC525403379B93E620B4740		691 Via Valente, Settimio terme, Italy	\N
136	0	0101000020E6100000E066F16261B42A4084E85AC52CF04640		4 Rotonda Gandolfo, Sesto Adelasia, Italy	\N
137	0	0101000020E610000021263CFC90E62840C604EBEEF0074640		4 Via Silvano, Settimo Loretta, Italy	\N
138	0	0101000020E6100000CFB81567B161274070CFF3A78DA74640		4 Contrada Giuliana, Cerrani laziale, Italy	\N
139	0	0101000020E6100000C1F979F8D76F224054F0CAE48AB04640		311 Via Ponziano, Settimo Abramo, Italy	\N
140	0	0101000020E61000008248D0A975782B40741200D2EDC94640		2 Contrada Distefano, Borgo Giona umbro, Italy	\N
141	0	0101000020E6100000918B208436172940630E828E564E4540		4 Incrocio Smeralda, Sesto Scolastica veneto, Italy	\N
142	0	0101000020E610000023484A1F5F572240D37CDF09072C4640		065 Strada Archippo, Sesto Valter terme, Italy	\N
143	0	0101000020E6100000A09339F130542140F7DBE8ADCB384740		0 Piazza Magno, Quarto Adina, Italy	\N
144	0	0101000020E6100000068A0E37967A2540DB1FDE29D3664540		02 Strada Serafina, Ultimo calabro, Italy	\N
145	0	0101000020E6100000CF59B09EA4CE2640F18288D4B4434740		474 Rotonda Piazzolla, Maggi terme, Italy	\N
146	0	0101000020E6100000C153C8957A5A26407541D8840FE14640		15 Contrada Acrisio, Settimo Norberto, Italy	\N
147	0	0101000020E61000008577B988EF302140BAD3426E2B3D4740		5 Via Nardi, Settimo Diodata, Italy	\N
148	0	0101000020E6100000589643E6259E2540B49487E013DD4540		9 Strada Postumio, San Viliana laziale, Italy	\N
149	0	0101000020E6100000249E4720B9702840B1F84D61A5124640		927 Strada Irma, Settimo Regina, Italy	\N
150	0	0101000020E61000008B89CDC7B55926407EB4EED57D084740		12 Contrada Demontis, Cingolani umbro, Italy	\N
151	0	0101000020E6100000D8B969334EEB27402CF8C84164804540		9 Incrocio Bastiano, San Alano del friuli, Italy	\N
152	0	0101000020E610000061D394AEAAD4204012A6835039FC4640		47 Borgo Tiziano, Borgo Elisabetta salentino, Italy	\N
153	0	0101000020E6100000B53C6AA741AC27408F0134A550B84640		539 Piazza Carlino, Quarto Ruperto salentino, Italy	\N
154	0	0101000020E6100000F78CE9AE91D52240ED48F59D5FE54640		34 Via Sardella, Di Blasi umbro, Italy	\N
155	0	0101000020E6100000626DE75663902B4097FA1E9A1ED44640		6 Strada Padula, San Filomena, Italy	\N
156	0	0101000020E6100000FFF9C78C011B2640DD706946501E4740		942 Contrada Visconti, Borgo Beltramo, Italy	\N
157	0	0101000020E61000009C363EEEB67E2740BC2363B5F9BA4640		6 Contrada Pintus, Borgo Gianpietro a mare, Italy	\N
158	0	0101000020E61000008A9466F3387C1E402B31CF4A5AE74640		4 Via Ausiliatrice, Margiotta del friuli, Italy	\N
159	0	0101000020E6100000F22895F084D22A404082870E26ED4440		36 Rotonda Mazzoleno, Vitalico veneto, Italy	\N
160	0	0101000020E61000007E1D386744712240C878399105CC4640		998 Incrocio Di Girolamo, San Abramio del friuli, Italy	\N
161	0	0101000020E610000020D84C1993812240A475AFEEB30D4740		017 Borgo Loddo, San Cora, Italy	\N
162	0	0101000020E6100000242136FD7E2E26406E2AF7A7F91A4740		75 Rotonda D'Errico, Poggi nell'emilia, Italy	\N
163	0	0101000020E6100000485E8C37E8B927408860C1A2C7CA4640		4 Via Felici, Balducci terme, Italy	\N
164	0	0101000020E61000005E961BB1BB751E407379BD4571EF4640		7 Piazza Mario, Caiazzo laziale, Italy	\N
165	0	0101000020E6100000BE2ABC708CED2340366964A1E7DD4640		738 Via Elena, Velio a mare, Italy	\N
166	0	0101000020E610000053B4722F302B2540E4DC26DC2B4D4740		199 Borgo Bosco, Quarto Agnese salentino, Italy	\N
167	0	0101000020E61000009A97C3EE3B32254052B241CB5F574640		601 Contrada Teodoro, Pellegrino sardo, Italy	\N
168	0	0101000020E6100000622D3E05C0782840F70BD17C29DE4640		30 Incrocio Pietro, Gatto veneto, Italy	\N
169	0	0101000020E6100000B05758703F782440773A4668BAB84640		353 Rotonda Turchi, Pardo ligure, Italy	\N
170	0	0101000020E610000011D20957F63B2640E6B8AEF3CA084740		71 Piazza Polidoro, Settimo Onofrio, Italy	\N
171	0	0101000020E61000004704E3E0D2692C408514F2F741A74640		385 Via Falzone, Settimo Liboria a mare, Italy	\N
172	0	0101000020E61000002F0ACC54D2C8264038FE9F1E36CA4640		6 Borgo Vitale, Borgo Taziano, Italy	\N
173	0	0101000020E610000046E80C31035E29405A46EA3D95E54640		5 Piazza Goffredo, Gustavo lido, Italy	\N
174	0	0101000020E6100000E4F90CA8376B2340ABA3F496BC5E4440		4 Strada Tristano, Settimo Ulstano, Italy	\N
175	0	0101000020E6100000967DB2BD71ED26406F7319EDA7C14640		564 Strada Galeazzi, Settimo Paciano, Italy	\N
176	0	0101000020E6100000FC68DDABFB5427401073EE1B04334740		303 Incrocio Rosmunda, Raffaele calabro, Italy	\N
177	0	0101000020E610000069965F611C5B2540B52792F991CA4540		20 Incrocio Visconti, Quirino umbro, Italy	\N
178	0	0101000020E6100000B4C6455ACF692740D8C523A765B04640		008 Contrada Ferraro, Bassiano umbro, Italy	\N
179	0	0101000020E61000003B843B61D3CC1E40935742D202D44640		94 Piazza Talarico, Achille a mare, Italy	\N
180	0	0101000020E6100000C03FA54A9455284094347F4C6BE54640		92 Rotonda Diana, Quarto Ermenegarda, Italy	\N
181	0	0101000020E610000003FBF900EEEB1E40FA6184F068EE4640		384 Contrada Editta, Settimo Giorgio nell'emilia, Italy	\N
182	0	0101000020E610000007681140209E2640B177352F3D9D4640		0 Incrocio Fuscolo, Marciano a mare, Italy	\N
183	0	0101000020E6100000525F96766AFE23402A7C6C81F3EE4640		2 Strada Candida, Piva salentino, Italy	\N
184	0	0101000020E61000007319EDA7B5EF1E400B1060EC18EC4640		417 Via Zumbo, Casilda lido, Italy	\N
185	0	0101000020E6100000F86B578DCA1A284015E06014A9B14640		6 Strada Reale, Quarto Benigna, Italy	\N
186	0	0101000020E6100000D634947FD2A12740811A081390584540		0 Via Di Fiore, Settimo Ermenegarda ligure, Italy	\N
187	0	0101000020E61000009D63E53C08EA2640B7FB0BF3D4DC4540		867 Piazza Cesare, Borgo Menardo, Italy	\N
188	0	0101000020E6100000EA0E18DAEF9B2B40948444DAC6764640		7 Borgo Loretta, Polidori terme, Italy	\N
189	0	0101000020E610000014BCD7FFEFC62640BA66F2CD36DE4640		12 Borgo Caino, Andrea nell'emilia, Italy	\N
190	0	0101000020E610000009168733BFBE27405D4E098849354540		984 Strada Gianluca, Quarto Lucrezia, Italy	\N
191	0	0101000020E6100000462AE7E6763A2940ABB8CC446CE14440		869 Borgo Paride, San Flaminia, Italy	\N
192	0	0101000020E610000075EED176A7F62640A7F97486F3B24640		58 Via Pozzo, San Degna, Italy	\N
193	0	0101000020E6100000F9A23D5E48F727405789C3E3ECE04640		14 Piazza Gioia, Borgo Marinetta calabro, Italy	\N
194	0	0101000020E6100000731A587D64FD294065FED13769E64540		6 Borgo Leonida, Loreno salentino, Italy	\N
195	0	0101000020E6100000ABC5F18D322421407D1FB3582FFA4640		28 Rotonda Lara, Valter calabro, Italy	\N
196	0	0101000020E610000035D252793B0228403A79ECC26AEA4640		128 Incrocio Edda, Sesto Aurelia umbro, Italy	\N
197	0	0101000020E6100000DD730580CFD02640F16261889CD44640		60 Rotonda Di Marino, Criscenti nell'emilia, Italy	\N
198	0	0101000020E61000006531564046E12040530E1C8645E74640		65 Piazza Patriarca, San Rubiano, Italy	\N
199	0	0101000020E610000026B8A2DE9D5E2740311A434AFDDC4640		9 Contrada Dianora, Borgo Manuela, Italy	\N
200	0	0101000020E61000000A5BFD22B27524407121EA99B95B4640		18 Rotonda Sigismondo, Annabella calabro, Italy	\N
201	0	0101000020E6100000C132DBBA40CE2240D0EFFB372F274740		636 Borgo Pasqua, Sesto Gioacchina sardo, Italy	\N
202	0	0101000020E6100000CA558737C6B91F40EB79ED88F9BD4640		86 Strada Menna, Borgo Amina, Italy	\N
203	0	0101000020E61000006AEE320DD4F324401D098F9147B14640		746 Via Cinzia, Albino nell'emilia, Italy	\N
204	0	0101000020E610000044053D8A291B2140F0FACC599F5A4440		6 Via Gondulfo, Borgo Damaso veneto, Italy	\N
205	0	0101000020E61000002B1D07B9E6212040F08C11E4FBF04640		633 Rotonda Cataldo, Borgo Vittore, Italy	\N
206	0	0101000020E61000007BEDE3B21BB727403464E190B2DD4640		20 Incrocio Crespi, Castagna ligure, Italy	\N
207	0	0101000020E6100000D8E9ACBB1EE91F40A0A932E774D04640		83 Borgo Beniamina, Quarto Pollione terme, Italy	\N
208	0	0101000020E61000009C8136DEC21B294063731FCA61894540		795 Rotonda Aprile, Correale a mare, Italy	\N
209	0	0101000020E6100000E3B08FA91680204076A0F3BF01E94640		48 Rotonda Passuello, San Evelina, Italy	\N
210	0	0101000020E6100000EE6EAF16E9832340C6F0225D7DCC4640		1 Piazza Azeglio, Zabedeo del friuli, Italy	\N
211	0	0101000020E6100000D81D41E037B02140C2F1214D61C54440		8 Piazza Divo, Demurtas lido, Italy	\N
212	0	0101000020E6100000A807BB174E80284061BC8B9C2AD94640		46 Rotonda Lidania, Immacolata a mare, Italy	\N
213	0	0101000020E6100000FD18CE9085A322406C9CA80073DB4640		2 Strada Vitalico, Sesto Siro laziale, Italy	\N
214	0	0101000020E6100000E39F635122672540E113A1C7DEDE4640		6 Contrada Esmeralda, Elettra sardo, Italy	\N
215	0	0101000020E610000098231A93B47928409916500361674640		998 Contrada Pastorino, Borgo Mirella, Italy	\N
216	0	0101000020E6100000ABBCD3539A032740A544B7031AEF4640		783 Incrocio Sabatini, Roberti ligure, Italy	\N
217	0	0101000020E61000001E424B0D239B2440D8D1DD1A7DA04640		91 Incrocio Privitera, Elsa salentino, Italy	\N
218	0	0101000020E6100000CF2CAE96E0891F405EB642FDD3234640		195 Contrada Nicoletta, Settimo Costante, Italy	\N
219	0	0101000020E6100000D7BDBACF96BC254007205AD020C34640		2 Via Savini, Borgo Edilberto a mare, Italy	\N
220	0	0101000020E6100000C96BCABA24832740A97E4A3A6FE54640		744 Borgo Bianco, Quarto Gesualdo veneto, Italy	\N
221	0	0101000020E6100000A8DAB80F8AC32940DF67017F9D1A4540		7 Incrocio Ferrini, Cosma umbro, Italy	\N
222	0	0101000020E6100000C272DFC556972640A4271BC528D24640		26 Contrada Gianni, Tornatore terme, Italy	\N
223	0	0101000020E61000005F306E5974411E40EC3F21F1E13A4740		322 Strada Costantino, Vittoriano veneto, Italy	\N
224	0	0101000020E61000006C109CE9142628401760C4E347124740		9 Borgo Bonaldo, Borgo Amanda ligure, Italy	\N
225	0	0101000020E610000044EC0214D9FD284012AC600AC5EE4440		120 Via Cristoforo Colombo, Roma, Italy	\N
226	0	0101000020E6100000B0FECF61BEF827406DFD99E6C2F24640		5 Strada Clemente, Nicea laziale, Italy	\N
227	0	0101000020E6100000EBB76576CCAF26407B8FE9BFBD424640		96 Contrada Giacinta, San Giuda, Italy	\N
228	0	0101000020E6100000D6479682247220407379BD4571084740		1 Via Ferdinando, De Cicco lido, Italy	\N
229	0	0101000020E610000097900F7A36872040AB251DE560074740		08 Incrocio Alberico, Borgo Otilia, Italy	\N
230	0	0101000020E61000000DABD3DC65C22740D32F116F9DE34640		1 Strada Giandomenico, Sesto Delia sardo, Italy	\N
231	0	0101000020E61000009FEE97AA0FCF27402834FF9E0E024740		28 Strada Sigfrido, Borgo Simona nell'emilia, Italy	\N
232	0	0101000020E6100000E417B90265622C40EFC0A50815E24440		414 Via Orlandi, Narseo calabro, Italy	\N
233	0	0101000020E6100000B2463D44A37B2540F3C011EEDF764540		438 Strada Menardo, Castiello sardo, Italy	\N
234	0	0101000020E6100000B6B0B84956A326409DC2A5BE87334740		5 Contrada Castiglioni, Flaviana nell'emilia, Italy	\N
235	0	0101000020E6100000D56C2FB319AD2840823C16365EC04640		7 Contrada Baldassarre, Graziani a mare, Italy	\N
236	0	0101000020E610000076583C5002EE1E40E0CCF9731BE14640		498 Rotonda Ermenegildo, Casimiro lido, Italy	\N
237	0	0101000020E6100000470EC7A98CC52840B6A73F564BE04640		19 Via Di Luca, Cardella veneto, Italy	\N
238	0	0101000020E61000004DC00A4B97B91F4005C1E3DBBBF84540		39 Piazza Sarbello, Icaro umbro, Italy	\N
239	0	0101000020E610000059EB7A585E182740106D1162780E4640		66 Borgo Privitera, Settimo Liberto, Italy	\N
240	0	0101000020E610000051D9B0A6B2581F4089B7CEBF5DE14640		015 Via Chiacchio, Sesto Gineto calabro, Italy	\N
241	0	0101000020E6100000AD7603BB504F27406049A8CFC4374640		76 Rotonda Aronne, San Saturnino, Italy	\N
242	0	0101000020E61000004692C5A28EF72640D32934B511794640		553 Piazza Semprini, Sesto Cuzia, Italy	\N
243	0	0101000020E6100000068B790C45182740C3CB1D47BD774640		55 Contrada Di Francesco, Borgo Sabele, Italy	\N
244	0	0101000020E61000005CC0159A35C620401880A1A245F44640		72 Contrada Artemisa, Peroni nell'emilia, Italy	\N
245	0	0101000020E6100000FA2D9512DD7227409453967C47234640		53 Piazza Rollo, Virginio sardo, Italy	\N
246	0	0101000020E61000008ECD8E54DFA12B403562C1583A2D4540		6 Via Elimena, Barbagallo ligure, Italy	\N
247	0	0101000020E610000020651FBF127F254034C06092257F4640		85 Borgo Di Biase, Sestito ligure, Italy	\N
248	0	0101000020E610000064BB31F3D36E22404F401361C3C24640		515 Via Cioffi, Palla sardo, Italy	\N
249	0	0101000020E6100000D160AEA0C47E2240E41824D813C04640		692 Strada Casadei, Lodovica ligure, Italy	\N
250	0	0101000020E61000006FD8B628B3B91E40086465EA64D64640		077 Strada Aniello, Cavallari calabro, Italy	\N
251	0	0101000020E610000016CDB9CAC93E2140BC0E8B074A744640		8 Strada Fermo, Severa sardo, Italy	\N
252	0	0101000020E6100000B4064A65E54A274026DAFA8E86E14640		74 Strada Murru, San Enzo sardo, Italy	\N
253	0	0101000020E61000000736F80CF26822405273034F6B9C4640		424 Borgo Lucarini, Damaso umbro, Italy	\N
254	0	0101000020E6100000DF6124C511412140D11CFE3FF3744640		277 Incrocio Procopio, Alcino ligure, Italy	\N
255	0	0101000020E610000077ED77CD50412140CB243493B9744640		4 Borgo Adele, San Rosita, Italy	\N
256	0	0101000020E61000002E008DD2A5032D406B5CA4F55C204540		2 Strada Petrone, Pacini veneto, Italy	\N
257	0	0101000020E61000004ED367075C6F1F403A57941282D64640		701 Borgo Baldomero, Marcello terme, Italy	\N
258	0	0101000020E61000006405BF0D316E1F409F07D22060D24640		1 Contrada Ernesto, Sesto Acilio, Italy	\N
259	0	0101000020E61000006F4BE482334C2740A928A8F287304640		504 Borgo Fulberto, San Ottaviano, Italy	\N
260	0	0101000020E61000005BC52CC59F522B40DB68A5B50EFA4640		41 Borgo Cola, Bonazzi calabro, Italy	\N
261	0	0101000020E61000000D5F155E383A21402BCC310F4F724640		204 Incrocio Cosimo, Settimo Adalgiso, Italy	\N
262	0	0101000020E6100000E04158326C5D2140821C9430D3704640		199 Borgo Iside, Sorbello del friuli, Italy	\N
263	0	0101000020E6100000C1F979F8D7071F404EFA319C21CD4640		46 Piazza Bernasconi, Quarto Asimodeo, Italy	\N
264	0	0101000020E61000000C97B0917F3921404C9C267D6B734640		4 Strada Belmonte, Borgo Maida, Italy	\N
265	0	0101000020E6100000EFA18ED838742840FA10AF46D1764640		5 Borgo Artemisa, Settimo Raimondo, Italy	\N
266	0	0101000020E6100000B032BF3F4AC11E4019CD25B094D54640		87 Rotonda Lombardini, Contini nell'emilia, Italy	\N
267	0	0101000020E610000039FBB9579CA829401D9C3EF152FC4440		19 Rotonda Plinio, Gamberini calabro, Italy	\N
268	0	0101000020E6100000440E5BC4C1F71E4071033E3F8C7E4640		1 Borgo Pillitteri, Quarto Ovidio, Italy	\N
269	0	0101000020E6100000C69EE2DD36D82B400B8AD5D5D3E84640		0 Incrocio Gerino, Valentino terme, Italy	\N
270	0	0101000020E6100000888961E2EA131F4040E7244A31CD4640		5 Borgo Trasea, Vitale calabro, Italy	\N
271	0	0101000020E6100000E8F86871C6D81E40E7EBE86E8DD84640		8 Rotonda Pammachio, Ortensia ligure, Italy	\N
272	0	0101000020E610000024BF34FBF2301F405FCE6C57E8CB4640		433 Contrada Russo, Eufebio sardo, Italy	\N
273	0	0101000020E61000000242902859C7254075988AE832F64540		9 Strada Pession, Sesto Oderico laziale, Italy	\N
274	0	0101000020E61000005CEC5113D8AF1E405650ACAE9ED84640		413 Incrocio Cavallini, Puccio umbro, Italy	\N
275	0	0101000020E6100000A6A84423E9E41E40BF20336145E14640		695 Via Bartolomei, Sesto Mimma, Italy	\N
276	0	0101000020E6100000F07A7AB6582B2740B1ADFAB726234640		65 Rotonda Giorgia, Borgo Ludovico, Italy	\N
277	0	0101000020E61000002252D32EA6C91E404392B47636E94640		3 Piazza Angeli, Borgo Adone, Italy	\N
278	0	0101000020E61000000BC336983C2C27405262D7F676234640		0 Contrada Bacci, Sesto Laurentino sardo, Italy	\N
279	0	0101000020E61000004F722C94F1E8264075F2D885D5064740		522 Borgo Attilano, Quarto Gregorio calabro, Italy	\N
280	0	0101000020E61000005C8BBBE6FA8F26407A4F8AFB343B4740		3 Rotonda Quaranta, San Melania, Italy	\N
281	0	0101000020E61000007B9054956C0B28407BB5487FD4974640		17 Via Rodiano, Sesto Galatea salentino, Italy	\N
282	0	0101000020E6100000BE52F1DA00B72B40D21D1F8887274540		9 Incrocio Giocondo, San Prudenzio, Italy	\N
283	0	0101000020E6100000A732D6485C052740FDD8243FE2394640		4 Borgo Aimone, San Gigliola, Italy	\N
284	0	0101000020E6100000AD94545C0B4D2240EE885462E8B94640		914 Contrada Teresi, Settimo Pacomio lido, Italy	\N
285	0	0101000020E6100000333097F9B3641F40983BE93356DF4640		9 Borgo Urdino, Cavallaro laziale, Italy	\N
286	0	0101000020E61000002B8AB2124E762740C1EA234B41314640		093 Piazza Buccheri, Marrone veneto, Italy	\N
287	0	0101000020E6100000905F8951219022403E5695229E864640		30 Strada Flaminia, Adalfredo laziale, Italy	\N
288	0	0101000020E610000096C1621E43E92640E580B80611044740		505 Contrada Motisi, Carriero nell'emilia, Italy	\N
289	0	0101000020E61000007090B52B99842B40E461461DC27E4640		0 Contrada Mottola, Spadafora terme, Italy	\N
290	0	0101000020E610000084B1CFAD219A26406BDECC43010E4740		3 Incrocio Ersilia, Lorena calabro, Italy	\N
291	0	0101000020E6100000CC1D47BDF13F2240A5A31CCC26824640		4 Incrocio Repetto, Settimo Agesilao, Italy	\N
292	0	0101000020E610000048E58123DCFF26407F7E294D94084740		5 Piazza Sabia, Tolomeo sardo, Italy	\N
293	0	0101000020E61000006B5A73918C1625409D7C1FB358204740		223 Borgo Malco, Di Maria lido, Italy	\N
294	0	0101000020E6100000204F818241C01E40068B1E53D2D34640		53 Piazza Mirco, Tagliaferri veneto, Italy	\N
295	0	0101000020E6100000C0CBB161F2931E40B859BC5818D34640		10 Rotonda Saturniano, Ortensia nell'emilia, Italy	\N
296	0	0101000020E610000070DA4246F68B2C40A79C8AAFD1364740		55 Rotonda Quintiliano, Borgo Genziano, Italy	\N
297	0	0101000020E6100000A9D5FC9D92882C4058FBE02131384740		64 Strada Coppola, Sesto Gianpaolo lido, Italy	\N
298	0	0101000020E6100000F74A0FF91DD1274067DC8AB3D8024740		1 Rotonda Puglisi, Quarto Achille salentino, Italy	\N
299	0	0101000020E61000004221A7542EE52C40A39BB3F457164740		22 Piazza Gaudino, Sesto Eberardo, Italy	\N
300	0	0101000020E6100000D3D7987C586422408E7CB9AA47A84640		65 Borgo Dianora, Settimo Saturniano, Italy	\N
301	0	0101000020E610000008CDAE7B2B8A2440E646EC6EF9664540		0 Via Fiorella, Settimo Ella sardo, Italy	\N
302	0	0101000020E610000081EB8A19E1CD26408A4457D8C2194640		9 Incrocio Perla, Borelli lido, Italy	\N
303	0	0101000020E6100000B4CA4C69FD5122404A95CDC1D8134540		886 Borgo Giliola, Sesto Letterio laziale, Italy	\N
304	0	0101000020E6100000E4BD6A65C267264033260EEA6CBC4640		6 Strada Gherardo, Sesto Delfina salentino, Italy	\N
305	0	0101000020E610000071C0536DDCD325406C312E0BDCB14640		35 Borgo Ataleo, Quarto Consolata, Italy	\N
306	0	0101000020E6100000B368F0ADFEEA2540D42AFA4333B54640		58 Rotonda Adina, Sesto Daniele umbro, Italy	\N
307	0	0101000020E61000005B2CA0AB08EA2740DE454E15422C4740		912 Strada Colomba, Angelini laziale, Italy	\N
308	0	0101000020E61000009703988D2933274052EC0D63778A4640		8 Via Monte Grappa, Lendinara, Italy	\N
309	0	0101000020E61000005389FC44AF582940E7D2AEF83CCA4640		41 Incrocio Panfilo, Quarto Teodolinda salentino, Italy	\N
310	0	0101000020E61000000236D6B441802C4025D5D237C46B4440		44 Via dei Greci, Napoli, Italy	\N
311	0	0101000020E610000073220BE24DBC2740A1E4C40DAE2D4740		4 Incrocio Settimo, Settimo Saturniano, Italy	\N
312	0	0101000020E610000046B1DCD26AB02540072E45A808074740		949 Strada Mercuri, Gioventino terme, Italy	\N
313	0	0101000020E6100000B17E7DBE77992240C0F858B043504440		31 Rotonda Satta, Luchini nell'emilia, Italy	\N
314	0	0101000020E6100000EC3026FDBD2C27403B6AF1CE46024740		1 Rotonda Di Marzio, Gamper calabro, Italy	\N
315	0	0101000020E6100000996EC8F5A5712B40C576F700DD3C4740		256 Piazza Sardina, Cherubino sardo, Italy	\N
316	0	0101000020E6100000AA5DB818A8F922406B0DA5F622154440		0 Incrocio Ippoliti, Quarto Davide, Italy	\N
317	0	0101000020E610000034B10AE58E682040CFC941BFA57A4440		899 Borgo Saul, Sesto Aureliano, Italy	\N
318	0	0101000020E610000008D04AB5AABC2140800F5EBBB4374640		67 Piazza Prudenzia, Costa terme, Italy	\N
319	0	0101000020E6100000B35DA10F967D2D408F49905BDD324740		085 Strada Elpidio, Borgo Galileo, Italy	\N
320	0	0101000020E6100000852348A5D8C12840842458C114E24540		6 Incrocio Alice, Settimo Livino veneto, Italy	\N
321	0	0101000020E6100000BF5076E915252B40EA398EC4703B4740		923 Strada Caccavo, Lazzarini laziale, Italy	\N
322	0	0101000020E6100000B956D6917EDA2B40DF707A72A8054540		7 Contrada Aristofane, Rolfo terme, Italy	\N
323	0	0101000020E61000007889A02067742340DE2A3EF493CE4640		49 Contrada Gemma, Sesto Abbondanzio, Italy	\N
324	0	0101000020E6100000235399BDC70C254059CFFF6101ED4540		169 Via Gianotti, Bonanni laziale, Italy	\N
325	0	0101000020E610000027F33405D7392640E75E16C90D2C4740		2 Contrada Chianese, Settimo Amos, Italy	\N
326	0	0101000020E61000001C15EE4BECAC2A40DD11A9C4D02E4540		1 Strada Vidiano, Borgo Bernadetta, Italy	\N
327	0	0101000020E6100000C1D4850E70E722408E6D63FDB0594540		78 Via Viscardo, Asdrubale ligure, Italy	\N
328	0	0101000020E6100000E5BA849E28A826407E7D63BE723F4640		8 Piazza Forgione, Sesto Settimo veneto, Italy	\N
329	0	0101000020E610000055B1E72109D11F4018CFA0A17FB14640		3 Via Graziani, San Giorgio calabro, Italy	\N
330	0	0101000020E61000007DEFCA89D18E2640DB0B16985F354540		131 Contrada Leonio, Quarto Brigida laziale, Italy	\N
331	0	0101000020E6100000BB6D9516E41D244002678412C1A94640		573 Via Adina, Termine calabro, Italy	\N
332	0	0101000020E6100000F67AF7C77BB52740FA449E245D4F4740		112 Strada Adolfo, Scarpellini veneto, Italy	\N
333	0	0101000020E6100000DE68119BD960294098E8E225EEFB4440		0 Borgo Tiano, Pamela sardo, Italy	\N
334	0	0101000020E61000007ED3AA4CE7E52340C9CC052E8F254640		820 Borgo Vizziello, Settimo Eutalio, Italy	\N
335	0	0101000020E61000004EDF217B732E2240D3F4D901D7214540		899 Contrada Mimma, Ippoliti a mare, Italy	\N
336	0	0101000020E61000004377A45588CA264008951348E43C4640		776 Incrocio Bernardini, Euseo umbro, Italy	\N
337	0	0101000020E610000072593B40E6692840252D4B2A09EC4440		4 Piazza Zeno, Quarto Rodrigo, Italy	\N
338	0	0101000020E610000023E7B3F281D7214072C8618B38C84640		660 Strada Menconi, Mattia laziale, Italy	\N
339	0	0101000020E61000000C84AE8E2D752740A4897780272E4640		999 Contrada Visentin, Sesto Edoardo ligure, Italy	\N
340	0	0101000020E6100000A63C5F58A33326408C811A63CCED4540		863 Via Ciaccio, Sesto Rocco, Italy	\N
341	0	0101000020E6100000CC0C1B65FD922840A42C8DA905C14640		02 Incrocio Elimena, Atzeni ligure, Italy	\N
342	0	0101000020E61000007332CC64933F2740FEDDF1DC31254640		028 Contrada Valente, Santamaria nell'emilia, Italy	\N
343	0	0101000020E610000032D758784D462240743F4C67CC0B4740		1 Rotonda Almerigo, Quarto Zefiro, Italy	\N
344	0	0101000020E61000002B16BF29ACC825401AB6775787864540		571 Contrada Durante, Elifio calabro, Italy	\N
345	0	0101000020E6100000FE00B562C9B62A4032CFA51364D94440		382 Borgo Pandolfi, Borgo Fausta, Italy	\N
346	0	0101000020E61000002AD890C9F3362640A3C629DFD80F4640		8 Via Gazzola, Gabrielli ligure, Italy	\N
347	0	0101000020E610000098F0958AD7422540F3DD52735E994640		257 Incrocio Galati, Tosi salentino, Italy	\N
348	0	0101000020E6100000451B36806D772640B99BF1C7FE074740		768 Borgo Pascarella, San Eberardo, Italy	\N
349	0	0101000020E61000008948A8740B9027402B7D321015F14540		541 Borgo Pircher, Telica salentino, Italy	\N
350	0	0101000020E6100000484B8A3496612B40F1F44A5986DF4640		115 Piazza Piacentini, Settimo Efrem, Italy	\N
351	0	0101000020E610000006240626DCE0264059631A97BBDC4640		75 Contrada Candido, Di Bella umbro, Italy	\N
352	0	0101000020E61000001A62067470422640EF6BC94F4FBD4540		015 Rotonda Grassi, Settimo Simone ligure, Italy	\N
353	0	0101000020E6100000F0F1536694F425402F5D77A9C7134640		47 Strada Gargiulo, Zappia terme, Italy	\N
354	0	0101000020E6100000A5DAA7E3317F2240E75E16C90DEF4640		2 Strada Cecchetti, Aurelia sardo, Italy	\N
355	0	0101000020E6100000D12E956D967D2C40126C5CFFAE6D4440		3 Via Tagliabue, Sesto Lorenzo, Italy	\N
356	0	0101000020E6100000DD6CBDF0941F27409F515F3BBDDA4640		10 Contrada Manfredo, Borgo Ombretta lido, Italy	\N
357	0	0101000020E610000096EA025E66002640FA4E82ED16F44540		5 Via Giada, Sesto Bernardo lido, Italy	\N
358	0	0101000020E61000009DDE20B5E43C25407F83F6EAE39D4540		9 Borgo Carolina, Fabrizio lido, Italy	\N
359	0	0101000020E6100000016E162F168E2340861BF0F9614A4440		431 Incrocio Lorella, Adone sardo, Italy	\N
360	0	0101000020E61000009F32480BE1EA20405C8A50114CDA4640		558 Strada Di Grezia, Sesto Manlio umbro, Italy	\N
361	0	0101000020E6100000618841052C422B400938DFE3A78E4640		0 Rotonda Porziano, Foca calabro, Italy	\N
362	0	0101000020E6100000160F94803D132140276BD44334E04640		7 Incrocio Calpurnia, Quarto Gioberto, Italy	\N
363	0	0101000020E610000097A13BD22A4C25401A80B2CE9DD44540		38 Rotonda Agostinelli, Cellini del friuli, Italy	\N
364	0	0101000020E6100000AD904D4DDD3827405B632BC313B14540		35 Rotonda Barbarossa, Iannone nell'emilia, Italy	\N
365	0	0101000020E610000071E82D1EDEEB2C405F93DA30AF824440		41 Incrocio Cleofe, Quarto Amauri, Italy	\N
366	0	0101000020E6100000DA48C8F6109B1F40EE2AFFB5176E4640		31 Contrada Sviturno, Rigoni nell'emilia, Italy	\N
367	0	0101000020E61000004D028A4798F02740C38366D7BD264640		57 Strada Forte, Settimo Gildo, Italy	\N
368	0	0101000020E6100000BCB77DEAB38A2C404EF04DD3676E4440		3 Via Zenone, Quarto Taziano del friuli, Italy	\N
369	0	0101000020E6100000CBC80F4BB93126404793E6EA22FD4640		361 Strada Suriano, Puglisi salentino, Italy	\N
370	0	0101000020E6100000A68E9FD7E925284065677682A2C64640		39 Borgo Desiderio, Leonio laziale, Italy	\N
371	0	0101000020E6100000407562C55F5D294091FC773359C24640		805 Piazza Corsini, Borgo Belina, Italy	\N
372	0	0101000020E6100000CF328B506C4D244070D63B37C8184640		7 Via Isidora, Sesto Salvatore ligure, Italy	\N
373	0	0101000020E61000007E6E0D11DC1122409453967C47EB4640		944 Contrada Albano, Pavone ligure, Italy	\N
374	0	0101000020E610000043A44BA4D989204072A8DF85ADD34640		81 Contrada Mottola, Torrisi veneto, Italy	\N
375	0	0101000020E61000004371C79BFC022C404AF5F81807254540		15 Contrada Artioli, Borgo Agazio, Italy	\N
376	0	0101000020E61000009EA74B10BFA422400292FAFC41944440		8 Piazza Castaldo, Valeri del friuli, Italy	\N
377	0	0101000020E61000000D88B59D5B012C40CF70B9B024144540		03 Strada Franzè, Sesto Serena sardo, Italy	\N
378	0	0101000020E610000059935D1F8CFE26407E6DA23B2D3B4640		1 Piazza Marco, San Riccarda sardo, Italy	\N
379	0	0101000020E6100000D50451F7010829403B736AC2510D4640		907 Contrada Lauri, San Ezechiele sardo, Italy	\N
380	0	0101000020E6100000CD6152D735012740D65F6523C6394640		0 Strada Dante, Santucci veneto, Italy	\N
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hike_track_points ("userHikeId", index, "pointId", datetime) FROM stdin;
\.


--
-- Data for Name: user_hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes (id, "userId", "hikeId", "startedAt", "updatedAt", "finishedAt", "psTotalKms", "psHighestAltitude", "psAltitudeRange", "psTotalTimeMinutes", "psAverageSpeed", "psAverageVerticalAscentSpeed", "maxElapsedTime", "weatherNotified", "unfinishedNotified") FROM stdin;
\.


--
-- Data for Name: user_hikes_track_points_user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes_track_points_user_hike_track_points ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash", approved, preferences, "plannedHikes") FROM stdin;
2	$2b$10$RYnvthmz69nV/99YLqX4jOwa8yG.o2INmQtr2HJcd6oZzJjKnl/ny	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N	t	\N	\N
4	$2b$10$BBOh1E92pUN1SDdJQOosgeNlJ7FFneNMr5LjKnK3p8vbIWhTEZssq	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N	t	\N	\N
5	$2b$10$0.XL/Z43yV7cRve576WBnuv4LU9LU3yFvNzvbb1yo6TIjWynY8NYW	Laura	Zurru	5	laura@emergency.it	\N	t	\N	t	\N	\N
1	$2b$10$YrDvgyN7S0C1xnL.aDcC3u/3M0ngFk4EN5hFKiuCbC9sEvPBPbVxe	German	Gorodnev	0	german@hiker.it	\N	t	\N	t	\N	\N
3	$2b$10$TuXve46Gdk9wwmFuE0Hr6.8SG8zYkv/DcdihnhWP8iA0Z3Rr1J0wG	vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N	t	\N	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 5, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 108, true);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 256, true);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 380, true);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_hikes_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

