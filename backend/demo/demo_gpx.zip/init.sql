--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: hike_points PK_7fc686c35c52228d8494a7c4947; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_7fc686c35c52228d8494a7c4947" PRIMARY KEY ("hikeId", "pointId");


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$bloKlwXLTZ42etmO5z26w.X2LA0zniZngeVh3txijsXu5ZB1wgmfm',
    'Antonio',
    'Battipaglia',
    2,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$m5y6t7V2Ino/NFZ59odvVOR0UaNhpSyri1gep1U.hh9X3REGxKwWm',
    'Erfan',
    'Gholami',
    4,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$5gwaIuNySzHzX/8YSiHmfOGjoeqsyH6kR2FnvML0I784dswwbTWMm',
    'Laura',
    'Zurru',
    5,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$NBofoYe54MoueUIEQfT9vu7Xci3TSfDMm/GE/9PNOPUTdM5Sxnh9W',
    'German',
    'Gorodnev',
    0,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$ZbAPLOemQVY/LN9zfB2fMeRbV6XZj3wOI2b1Xef6Dhubl3/HcDKW6',
    'vincenzo',
    'Sagristano',
    3,
    true
  );
  

      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Airline Trail - Detour',
        1,
        '/static/gpx/001_Airline_Trail___Detour.gpx',
        'USA',
        'Asti',
        '',
        'De Salvo lido',
        1,
        24.8,
        15.19,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Airline Trail',
        2,
        '/static/gpx/002_Airline_Trail.gpx',
        'USA',
        'Trapani',
        '',
        'Borgo Eriberto lido',
        1.3,
        10.3,
        17.727,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Colchester Railroad',
        0,
        '/static/gpx/003_Colchester_Railroad.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Sesto Gautiero veneto',
        0.8,
        22.6,
        12.03,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Two Sister''S Preserve Loop Trail',
        2,
        '/static/gpx/004_Two_Sister_S_Preserve_Loop_Trail.gpx',
        'USA',
        'Carbonia-Iglesias',
        '',
        'Iacopone a mare',
        1,
        15.3,
        15.385,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Putnam River Trail',
        0,
        '/static/gpx/005_Putnam_River_Trail.gpx',
        'USA',
        'Lecce',
        '',
        'San Flaviana terme',
        1.2,
        15.1,
        17.349,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Airline Trail Bypass',
        2,
        '/static/gpx/006_Airline_Trail_Bypass.gpx',
        'USA',
        'Cagliari',
        '',
        'Sesto Armando',
        1.1,
        17.1,
        14.537,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Indian Neck',
        2,
        '/static/gpx/007_Indian_Neck.gpx',
        'USA',
        'Terni',
        '',
        'San Iole calabro',
        2.6,
        11.6,
        42.276,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Stony Creek',
        0,
        '/static/gpx/008_Stony_Creek.gpx',
        'USA',
        'Avellino',
        '',
        'Postiglione nell''emilia',
        3.2,
        24.7,
        40,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quarry-Westwoods',
        2,
        '/static/gpx/009_Quarry_Westwoods.gpx',
        'USA',
        'Belluno',
        '',
        'San Giove',
        7.7,
        18,
        101.094,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Short Beach',
        1,
        '/static/gpx/010_Short_Beach.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Eloisa laziale',
        3,
        6.6,
        36.885,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Charter Oak Greenway',
        0,
        '/static/gpx/011_Charter_Oak_Greenway.gpx',
        'USA',
        'Belluno',
        '',
        'Alda umbro',
        0.7,
        28.7,
        11.57,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bissell Greenway',
        2,
        '/static/gpx/012_Bissell_Greenway.gpx',
        'USA',
        'Cremona',
        '',
        'San Severo',
        1,
        8.3,
        13.216,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Riverfront Trail System',
        2,
        '/static/gpx/013_Riverfront_Trail_System.gpx',
        'USA',
        'Ascoli Piceno',
        '',
        'Magno nell''emilia',
        1.2,
        11.1,
        14.575,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Millers Pond Park Trail',
        2,
        '/static/gpx/014_Millers_Pond_Park_Trail.gpx',
        'USA',
        'Bergamo',
        '',
        'Leonilda del friuli',
        0.8,
        24.7,
        11.06,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattabesett Trail',
        2,
        '/static/gpx/015_Mattabesett_Trail.gpx',
        'USA',
        'Bergamo',
        '',
        'Borgo Mariano salentino',
        0.9,
        27.7,
        14.477,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Jefferson Park Trail',
        2,
        '/static/gpx/016_Jefferson_Park_Trail.gpx',
        'USA',
        'Enna',
        '',
        'Quarto Eusebia sardo',
        0.8,
        29.6,
        9.816,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mt. Nebo Park',
        1,
        '/static/gpx/017_Mt__Nebo_Park.gpx',
        'USA',
        'Brescia',
        '',
        'Coletta a mare',
        1.4,
        9.8,
        17.834,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        ' ',
        2,
        '/static/gpx/018__.gpx',
        'USA',
        'Savona',
        '',
        'Toti lido',
        1.2,
        26.9,
        18.701,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Blinnshed Ridge Trail',
        2,
        '/static/gpx/019_Blinnshed_Ridge_Trail.gpx',
        'USA',
        'Alessandria',
        '',
        'Borgo Violante',
        1.3,
        11.5,
        18.795,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Neck River Trail',
        2,
        '/static/gpx/020_Neck_River_Trail.gpx',
        'USA',
        'Bolzano',
        '',
        'Consolata ligure',
        0.6,
        8.9,
        7.287,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Oil Mill Brook Trail',
        2,
        '/static/gpx/021_Oil_Mill_Brook_Trail.gpx',
        'USA',
        'Massa-Carrara',
        '',
        'Faraci salentino',
        1.5,
        14.4,
        25.14,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chatfield Trail',
        2,
        '/static/gpx/022_Chatfield_Trail.gpx',
        'USA',
        'Pistoia',
        '',
        'Nicarete a mare',
        0.8,
        24.4,
        9.776,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Unamed Trail',
        2,
        '/static/gpx/023_Unamed_Trail.gpx',
        'USA',
        'Crotone',
        '',
        'Sergio veneto',
        1.5,
        5.3,
        20.882,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Unnamed Trail',
        2,
        '/static/gpx/024_Unnamed_Trail.gpx',
        'USA',
        'Reggio Emilia',
        '',
        'Agapito lido',
        0.9,
        18,
        14.555,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Lost Pond Trail',
        2,
        '/static/gpx/025_Lost_Pond_Trail.gpx',
        'USA',
        'Pordenone',
        '',
        'Brunetti laziale',
        1,
        17.7,
        13.825,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ccc Camp Hadley Trail',
        2,
        '/static/gpx/026_Ccc_Camp_Hadley_Trail.gpx',
        'USA',
        'Caltanissetta',
        '',
        'Borgo Fulvia',
        1.2,
        9.5,
        18.136,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Double Loop Trail',
        2,
        '/static/gpx/027_Double_Loop_Trail.gpx',
        'USA',
        'Lucca',
        '',
        'Ponziano terme',
        0.7,
        16.8,
        11.57,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Cockaponset Forest Trail',
        2,
        '/static/gpx/028_Cockaponset_Forest_Trail.gpx',
        'USA',
        'Cagliari',
        '',
        'Spadafora ligure',
        1.4,
        29.9,
        21.99,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Westwoods Forest Trail',
        2,
        '/static/gpx/029_Westwoods_Forest_Trail.gpx',
        'USA',
        'Treviso',
        '',
        'Borgo Agapito salentino',
        1.4,
        7.1,
        20.488,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Over Brook Trail',
        2,
        '/static/gpx/030_Over_Brook_Trail.gpx',
        'USA',
        'Torino',
        '',
        'Settimo Stiliano',
        1.3,
        16.3,
        20.58,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Blinnshed Loop Trail',
        2,
        '/static/gpx/031_Blinnshed_Loop_Trail.gpx',
        'USA',
        'Trieste',
        '',
        'Indelicato terme',
        1.5,
        27.3,
        24.523,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Unnamed Tsail',
        2,
        '/static/gpx/032_Unnamed_Tsail.gpx',
        'USA',
        'Matera',
        '',
        'Sassi calabro',
        1.1,
        25.6,
        15.865,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Messerschmidt Wma Trail',
        2,
        '/static/gpx/033_Messerschmidt_Wma_Trail.gpx',
        'USA',
        'Pordenone',
        '',
        'Settimo Luce',
        1.5,
        29.7,
        21.687,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Westwoods Nature Trail',
        2,
        '/static/gpx/034_Westwoods_Nature_Trail.gpx',
        'USA',
        'Vercelli',
        '',
        'Borgo Fausto',
        1,
        14,
        12.579,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Housatonic Forest Trail',
        1,
        '/static/gpx/035_Housatonic_Forest_Trail.gpx',
        'USA',
        'Rovigo',
        '',
        'Evangelista sardo',
        0.5,
        22.4,
        7.792,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Farmington Canal Trail',
        0,
        '/static/gpx/036_Farmington_Canal_Trail.gpx',
        'USA',
        'Teramo',
        '',
        'San Tecla laziale',
        1.1,
        27.9,
        15.068,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Farmington River Trail',
        0,
        '/static/gpx/037_Farmington_River_Trail.gpx',
        'USA',
        'Alessandria',
        '',
        'Guido salentino',
        1.2,
        28.8,
        16.514,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Farminton Canal Trail',
        2,
        '/static/gpx/038_Farminton_Canal_Trail.gpx',
        'USA',
        'Asti',
        '',
        'Sesto Tiziana',
        1.1,
        17.2,
        18.436,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hop River Trail',
        1,
        '/static/gpx/039_Hop_River_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Quarto Virginio lido',
        4.1,
        29.6,
        62.916,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Housatonic Rail Trail',
        1,
        '/static/gpx/040_Housatonic_Rail_Trail.gpx',
        'USA',
        'Genova',
        '',
        'Sesto Piero calabro',
        1.3,
        13.6,
        16.116,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Middletown Bikeway',
        1,
        '/static/gpx/041_Middletown_Bikeway.gpx',
        'USA',
        'Bari',
        '',
        'Mori a mare',
        1.4,
        11.3,
        22.281,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattabesett Trolley Trail',
        2,
        '/static/gpx/042_Mattabesett_Trolley_Trail.gpx',
        'USA',
        'Udine',
        '',
        'Fernanda veneto',
        1,
        10.8,
        17.143,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Moosup Valley State Park Trail',
        2,
        '/static/gpx/043_Moosup_Valley_State_Park_Trail.gpx',
        'USA',
        'Savona',
        '',
        'Sesto Ermanno ligure',
        0.7,
        21.2,
        9.438,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinnebaug River Trail',
        1,
        '/static/gpx/044_Quinnebaug_River_Trail.gpx',
        'USA',
        'Gorizia',
        '',
        'Settimo Alberto terme',
        1.1,
        6,
        17.507,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinnebaug Hatchery Trail',
        2,
        '/static/gpx/045_Quinnebaug_Hatchery_Trail.gpx',
        'USA',
        'Ferrara',
        '',
        'San Alfredo del friuli',
        1.9,
        30,
        24.783,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Trolley Trail',
        2,
        '/static/gpx/046_Trolley_Trail.gpx',
        'USA',
        'Olbia-Tempio',
        '',
        'Settimo Ventura',
        1.2,
        12.5,
        16.59,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hopeville Park Trail',
        2,
        '/static/gpx/047_Hopeville_Park_Trail.gpx',
        'USA',
        'Agrigento',
        '',
        'Salerno salentino',
        1.2,
        25.7,
        15.126,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic Trail',
        2,
        '/static/gpx/048_Nehantic_Trail.gpx',
        'USA',
        'Bari',
        '',
        'San Quarto',
        1.5,
        20.7,
        21.583,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Camp Columbia Trail',
        0,
        '/static/gpx/049_Camp_Columbia_Trail.gpx',
        'USA',
        'Treviso',
        '',
        'Settimo Arturo',
        1,
        5.5,
        13.129,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Dinosaur Park Trail',
        2,
        '/static/gpx/050_Dinosaur_Park_Trail.gpx',
        'USA',
        'Fermo',
        '',
        'Quarto Orietta lido',
        0.6,
        24.1,
        9.449,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Day Pond Park Trail',
        1,
        '/static/gpx/051_Day_Pond_Park_Trail.gpx',
        'USA',
        'Vicenza',
        '',
        'Borgo Prisca lido',
        0.8,
        5.8,
        9.959,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Salmon River Trail',
        1,
        '/static/gpx/052_Salmon_River_Trail.gpx',
        'USA',
        'Siracusa',
        '',
        'Magda nell''emilia',
        2,
        23.1,
        29.925,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Salmon River Trial',
        2,
        '/static/gpx/053_Salmon_River_Trial.gpx',
        'USA',
        'Cagliari',
        '',
        'Iolanda veneto',
        1,
        22.1,
        14.528,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Dennis Hill Park Trail',
        0,
        '/static/gpx/054_Dennis_Hill_Park_Trail.gpx',
        'USA',
        'Alessandria',
        '',
        'Bruno laziale',
        1.1,
        15.9,
        16.837,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kent Falls Park Trail',
        0,
        '/static/gpx/055_Kent_Falls_Park_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'San Cassio del friuli',
        0.7,
        13.4,
        9.251,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Enders Forest Trail',
        1,
        '/static/gpx/056_Enders_Forest_Trail.gpx',
        'USA',
        'Medio Campidano',
        '',
        'Borgo Filomena',
        1.5,
        5.1,
        20.595,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Gay City Park Trail',
        2,
        '/static/gpx/057_Gay_City_Park_Trail.gpx',
        'USA',
        'Pistoia',
        '',
        'Liverani lido',
        0.9,
        20.3,
        12.273,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Split Rock Trail',
        0,
        '/static/gpx/058_Split_Rock_Trail.gpx',
        'USA',
        'Bologna',
        '',
        'Quarto Liberata',
        1.3,
        12,
        16.957,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Gillette Castle Trail',
        1,
        '/static/gpx/059_Gillette_Castle_Trail.gpx',
        'USA',
        'Pistoia',
        '',
        'Sesto Macaria',
        1.5,
        15.3,
        18.987,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Great Pond Forest Trail',
        0,
        '/static/gpx/060_Great_Pond_Forest_Trail.gpx',
        'USA',
        'Siracusa',
        '',
        'Sesto Nina',
        1.3,
        12.3,
        21.311,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Haddam Meadows Park Trail',
        0,
        '/static/gpx/061_Haddam_Meadows_Park_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Ludano a mare',
        1.2,
        7,
        17.778,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Haley Farm Park Trail',
        1,
        '/static/gpx/062_Haley_Farm_Park_Trail.gpx',
        'USA',
        'Ferrara',
        '',
        'San Romola',
        0.6,
        11.7,
        9.184,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nature Trail',
        0,
        '/static/gpx/063_Nature_Trail.gpx',
        'USA',
        'L''Aquila',
        '',
        'Concetto nell''emilia',
        1.1,
        18.7,
        16.709,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hammonasset Bike Path',
        0,
        '/static/gpx/064_Hammonasset_Bike_Path.gpx',
        'USA',
        'Lecce',
        '',
        'Abelardo nell''emilia',
        1.3,
        17.4,
        19.898,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hammonasset Park Boardwalk',
        0,
        '/static/gpx/065_Hammonasset_Park_Boardwalk.gpx',
        'USA',
        'Alessandria',
        '',
        'San Cleopatra',
        1,
        11.8,
        12.097,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Willard Island Nature Trail',
        0,
        '/static/gpx/066_Willard_Island_Nature_Trail.gpx',
        'USA',
        'Rimini',
        '',
        'Patroclo umbro',
        0.8,
        13.9,
        11.009,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Moraine Nature Trail',
        0,
        '/static/gpx/067_Moraine_Nature_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Gino sardo',
        0.6,
        26.5,
        9.574,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Haystack Park Trail',
        2,
        '/static/gpx/068_Haystack_Park_Trail.gpx',
        'USA',
        'Messina',
        '',
        'Sacchet sardo',
        0.5,
        22.2,
        7.692,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Higganum Reservoir Park Trail',
        1,
        '/static/gpx/069_Higganum_Reservoir_Park_Trail.gpx',
        'USA',
        'Piacenza',
        '',
        'Settimo Aniello umbro',
        0.9,
        29.8,
        11.514,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Appalachian Trail',
        2,
        '/static/gpx/070_Appalachian_Trail.gpx',
        'USA',
        'Palermo',
        '',
        'Silvia laziale',
        0.9,
        23.3,
        14.595,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mohawk Trail',
        2,
        '/static/gpx/071_Mohawk_Trail.gpx',
        'USA',
        'Milano',
        '',
        'Lucrezia salentino',
        1,
        6.1,
        14.423,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pine Knob Loop',
        1,
        '/static/gpx/072_Pine_Knob_Loop.gpx',
        'USA',
        'Crotone',
        '',
        'Monitore salentino',
        1.5,
        24,
        20.93,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Appalachian/Pine Knob Loop',
        0,
        '/static/gpx/073_Appalachian_Pine_Knob_Loop.gpx',
        'USA',
        'Brindisi',
        '',
        'Settimo Liliana',
        2.6,
        8.2,
        32.5,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'White Mountain Trail',
        1,
        '/static/gpx/074_White_Mountain_Trail.gpx',
        'USA',
        'Aosta',
        '',
        'Ilda veneto',
        1.5,
        13,
        21.845,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'River Trail',
        1,
        '/static/gpx/075_River_Trail.gpx',
        'USA',
        'Bologna',
        '',
        'Francesco nell''emilia',
        1.4,
        10.5,
        23.729,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hurd Park Trail',
        1,
        '/static/gpx/076_Hurd_Park_Trail.gpx',
        'USA',
        'Rimini',
        '',
        'Bartolini laziale',
        0.6,
        15.5,
        7.243,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Paugussett Trail',
        2,
        '/static/gpx/077_Paugussett_Trail.gpx',
        'USA',
        'Fermo',
        '',
        'Borgo Cirano',
        1.2,
        25.8,
        19.835,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Waterfall Trail',
        2,
        '/static/gpx/078_Waterfall_Trail.gpx',
        'USA',
        'Bologna',
        '',
        'Settimo Maffeo lido',
        1.1,
        28.7,
        18.487,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Proposed Trail',
        0,
        '/static/gpx/079_Proposed_Trail.gpx',
        'USA',
        'Avellino',
        '',
        'Carlo veneto',
        1.4,
        14.5,
        19.952,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Coincident Weber Road',
        2,
        '/static/gpx/080_Coincident_Weber_Road.gpx',
        'USA',
        'Parma',
        '',
        'Settimo Genesia',
        0.8,
        7.9,
        12.06,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Macedonia Ridge Trail',
        2,
        '/static/gpx/081_Macedonia_Ridge_Trail.gpx',
        'USA',
        'Bologna',
        '',
        'Vaccaro laziale',
        4.3,
        12.7,
        58.904,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Cobble Mountain Trail',
        1,
        '/static/gpx/082_Cobble_Mountain_Trail.gpx',
        'USA',
        'Nuoro',
        '',
        'Roberti sardo',
        0.8,
        12,
        10.367,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shenipsit Trail',
        0,
        '/static/gpx/083_Shenipsit_Trail.gpx',
        'USA',
        'Messina',
        '',
        'San Demetria',
        1.2,
        28.2,
        20.339,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Meshomasic Forest Trail',
        1,
        '/static/gpx/084_Meshomasic_Forest_Trail.gpx',
        'USA',
        'Pescara',
        '',
        'Trevisan sardo',
        1,
        23.4,
        13.761,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Crest Trail',
        0,
        '/static/gpx/085_Crest_Trail.gpx',
        'USA',
        'Frosinone',
        '',
        'Borgo Aniceto',
        1.6,
        9,
        26.966,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Campground Trail',
        1,
        '/static/gpx/086_Campground_Trail.gpx',
        'USA',
        'Bolzano',
        '',
        'San Flaviano',
        0.7,
        12.4,
        11.966,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Brook Trail',
        2,
        '/static/gpx/087_Brook_Trail.gpx',
        'USA',
        'Ravenna',
        '',
        'Borgo Gioia',
        0.9,
        10.7,
        12.245,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'North Ridge Loop Trail',
        2,
        '/static/gpx/088_North_Ridge_Loop_Trail.gpx',
        'USA',
        'Pesaro e Urbino',
        '',
        'Vincenzo del friuli',
        0.6,
        24.8,
        7.287,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'North Ridge Trail',
        2,
        '/static/gpx/089_North_Ridge_Trail.gpx',
        'USA',
        'Cagliari',
        '',
        'San Ida calabro',
        1.5,
        19.3,
        20.225,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Miller Trail',
        0,
        '/static/gpx/090_Miller_Trail.gpx',
        'USA',
        'Rovigo',
        '',
        'Marian laziale',
        0.6,
        10.5,
        8.612,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Miller Trail Spur',
        0,
        '/static/gpx/091_Miller_Trail_Spur.gpx',
        'USA',
        'Pistoia',
        '',
        'Settimo Scolastica',
        1.4,
        6.5,
        21.266,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pomperaug Trail',
        2,
        '/static/gpx/092_Pomperaug_Trail.gpx',
        'USA',
        'L''Aquila',
        '',
        'Moras laziale',
        0.5,
        6.4,
        6.726,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Waramaug Lake Park Trail',
        1,
        '/static/gpx/093_Waramaug_Lake_Park_Trail.gpx',
        'USA',
        'Lecce',
        '',
        'Alba terme',
        0.6,
        11.3,
        9.73,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Lovers Leap Park Trail',
        0,
        '/static/gpx/094_Lovers_Leap_Park_Trail.gpx',
        'USA',
        'Teramo',
        '',
        'Settimo Simone veneto',
        0.9,
        7.5,
        14.439,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mashamoquet Brook Park Trail',
        0,
        '/static/gpx/095_Mashamoquet_Brook_Park_Trail.gpx',
        'USA',
        'Pesaro e Urbino',
        '',
        'Manno laziale',
        1.5,
        23.2,
        18.595,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shenipsit',
        2,
        '/static/gpx/096_Shenipsit.gpx',
        'USA',
        'Livorno',
        '',
        'Como salentino',
        1.4,
        22,
        17.248,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nassahegon Forest Trail',
        0,
        '/static/gpx/097_Nassahegon_Forest_Trail.gpx',
        'USA',
        'Bologna',
        '',
        'Cinelli laziale',
        1.3,
        27.7,
        17.068,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Black Spruce Bog Trail',
        1,
        '/static/gpx/098_Black_Spruce_Bog_Trail.gpx',
        'USA',
        'Palermo',
        '',
        'Borgo Otilia',
        1.4,
        6,
        17.61,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mohawk Forest Trail',
        2,
        '/static/gpx/099_Mohawk_Forest_Trail.gpx',
        'USA',
        'Vibo Valentia',
        '',
        'Borgo Cornelia',
        1.5,
        11,
        22.556,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ethan Allen Youth Trail',
        2,
        '/static/gpx/100_Ethan_Allen_Youth_Trail.gpx',
        'USA',
        'Gorizia',
        '',
        'Sesto Muziano salentino',
        0.8,
        18,
        13.151,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Punch Brook Trail',
        1,
        '/static/gpx/101_Punch_Brook_Trail.gpx',
        'USA',
        'Crotone',
        '',
        'Quarto Silvio',
        1.5,
        16.4,
        18.256,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tunxis Trail',
        1,
        '/static/gpx/102_Tunxis_Trail.gpx',
        'USA',
        'Vibo Valentia',
        '',
        'Sesto Davide',
        1,
        29.3,
        13.043,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Red Cedar Lake Trail',
        0,
        '/static/gpx/103_Red_Cedar_Lake_Trail.gpx',
        'USA',
        'Parma',
        '',
        'Ferro calabro',
        0.8,
        5.3,
        12.903,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Under Mountain Trail',
        0,
        '/static/gpx/104_Under_Mountain_Trail.gpx',
        'USA',
        'Sassari',
        '',
        'Sesto Gisella del friuli',
        1.7,
        10.7,
        23.666,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mount Tom Trail',
        2,
        '/static/gpx/105_Mount_Tom_Trail.gpx',
        'USA',
        'Cremona',
        '',
        'Piermarco lido',
        1.4,
        25.2,
        17.797,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Naugatuck Trail',
        0,
        '/static/gpx/106_Naugatuck_Trail.gpx',
        'USA',
        'Rieti',
        '',
        'Settimo Pietro calabro',
        0.5,
        11,
        6.865,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic Forest Trail',
        2,
        '/static/gpx/107_Nehantic_Forest_Trail.gpx',
        'USA',
        'Perugia',
        '',
        'Settimo Rolando',
        1.4,
        14.9,
        17.355,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Naugatuck Forest Trail',
        0,
        '/static/gpx/108_Naugatuck_Forest_Trail.gpx',
        'USA',
        'Nuoro',
        '',
        'Ducci laziale',
        1.4,
        22,
        19.266,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Whitemore Trail',
        0,
        '/static/gpx/109_Whitemore_Trail.gpx',
        'USA',
        'Perugia',
        '',
        'Leonardo laziale',
        1.1,
        21.5,
        13.28,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinnipiac Trail',
        1,
        '/static/gpx/110_Quinnipiac_Trail.gpx',
        'USA',
        'Rovigo',
        '',
        'Settimo Silvana',
        1.6,
        24.8,
        21.918,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic Forest Trai',
        0,
        '/static/gpx/111_Nehantic_Forest_Trai.gpx',
        'USA',
        'Carbonia-Iglesias',
        '',
        'Colella ligure',
        0.9,
        17.7,
        13.075,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nepaug Forest Trail',
        2,
        '/static/gpx/112_Nepaug_Forest_Trail.gpx',
        'USA',
        'Lucca',
        '',
        'Settimo Fosco veneto',
        1.3,
        23.5,
        15.984,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Naugatuck',
        0,
        '/static/gpx/113_Naugatuck.gpx',
        'USA',
        'Modena',
        '',
        'Quarto Macaria nell''emilia',
        1.4,
        6.1,
        20.896,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nyantaquit Trail',
        1,
        '/static/gpx/114_Nyantaquit_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Tedeschi veneto',
        1.1,
        18.3,
        18.644,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tipping Rock Loop Trail',
        2,
        '/static/gpx/115_Tipping_Rock_Loop_Trail.gpx',
        'USA',
        'Savona',
        '',
        'Marcianò veneto',
        1.5,
        23.8,
        18.868,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Valley Outlook Trail',
        0,
        '/static/gpx/116_Valley_Outlook_Trail.gpx',
        'USA',
        'Carbonia-Iglesias',
        '',
        'Quarto Mercurio nell''emilia',
        0.7,
        26.6,
        11.798,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shelter 4 Loop Trail',
        1,
        '/static/gpx/117_Shelter_4_Loop_Trail.gpx',
        'USA',
        'Enna',
        '',
        'Settimo Ildebrando',
        1.5,
        15,
        18,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Paugnut Forest Trail',
        1,
        '/static/gpx/118_Paugnut_Forest_Trail.gpx',
        'USA',
        'Caserta',
        '',
        'Borgo Florina',
        1.4,
        15.7,
        17.91,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Charles L Pack Trail',
        0,
        '/static/gpx/119_Charles_L_Pack_Trail.gpx',
        'USA',
        'Pesaro e Urbino',
        '',
        'Vecchi salentino',
        1.5,
        7.2,
        18.789,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Peoples Forest Trail',
        0,
        '/static/gpx/120_Peoples_Forest_Trail.gpx',
        'USA',
        'Firenze',
        '',
        'Quarto Eberardo veneto',
        1.4,
        20.5,
        22.581,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Penwood Park Trail',
        1,
        '/static/gpx/121_Penwood_Park_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'Sesto Concordio sardo',
        2.6,
        27.8,
        37.41,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quadick Red Trail',
        0,
        '/static/gpx/122_Quadick_Red_Trail.gpx',
        'USA',
        'Chieti',
        '',
        'Quarto Crescenzio terme',
        1.4,
        20.6,
        18.584,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pootatuck Forest Trail',
        1,
        '/static/gpx/123_Pootatuck_Forest_Trail.gpx',
        'USA',
        'Bari',
        '',
        'Sesto Deanna',
        1.5,
        15.4,
        20.134,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'River Highland Park Trail',
        0,
        '/static/gpx/124_River_Highland_Park_Trail.gpx',
        'USA',
        'Rimini',
        '',
        'Borgo Iorio veneto',
        1.3,
        9.5,
        15.663,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tunxis',
        1,
        '/static/gpx/125_Tunxis.gpx',
        'USA',
        'Varese',
        '',
        'Capuano salentino',
        1,
        29.1,
        12.903,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Osbornedale Park Trail',
        0,
        '/static/gpx/126_Osbornedale_Park_Trail.gpx',
        'USA',
        'Modena',
        '',
        'Borgo Egizia',
        0.9,
        23.8,
        13.235,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Old Furnace Park Trail',
        2,
        '/static/gpx/127_Old_Furnace_Park_Trail.gpx',
        'USA',
        'Pesaro e Urbino',
        '',
        'Casini lido',
        1.3,
        29.6,
        21.91,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Old Furnace Trail',
        1,
        '/static/gpx/128_Old_Furnace_Trail.gpx',
        'USA',
        'Bolzano',
        '',
        'Borgo Demetrio',
        1.1,
        22.5,
        13.442,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kestral Trail',
        1,
        '/static/gpx/129_Kestral_Trail.gpx',
        'USA',
        'Chieti',
        '',
        'De Rosa lido',
        0.9,
        29,
        15.254,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Warbler Trail',
        0,
        '/static/gpx/130_Warbler_Trail.gpx',
        'USA',
        'Trento',
        '',
        'Corrado calabro',
        1.5,
        25.6,
        20.27,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Muir Trail',
        2,
        '/static/gpx/131_Muir_Trail.gpx',
        'USA',
        'Catanzaro',
        '',
        'Quarto Orsino calabro',
        1.7,
        14.7,
        24.818,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Unnamed',
        2,
        '/static/gpx/132_Unnamed.gpx',
        'USA',
        'Rimini',
        '',
        'San Aza',
        0.5,
        11.3,
        6.148,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shadow Pond Nature Trail',
        1,
        '/static/gpx/133_Shadow_Pond_Nature_Trail.gpx',
        'USA',
        'Salerno',
        '',
        'Kofler ligure',
        1.2,
        7.1,
        20.225,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Metacomet Trail',
        1,
        '/static/gpx/134_Metacomet_Trail.gpx',
        'USA',
        'Arezzo',
        '',
        'San Eva veneto',
        0.8,
        22.3,
        12.732,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Metacomet Trail Bypass',
        0,
        '/static/gpx/135_Metacomet_Trail_Bypass.gpx',
        'USA',
        'Parma',
        '',
        'Sesto Maurizio',
        1.3,
        11.9,
        19.165,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Jesse Gerard Trail',
        2,
        '/static/gpx/136_Jesse_Gerard_Trail.gpx',
        'USA',
        'Caltanissetta',
        '',
        'Di Luca sardo',
        1.4,
        13.7,
        20.388,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Robert Ross Trail',
        1,
        '/static/gpx/137_Robert_Ross_Trail.gpx',
        'USA',
        'Pavia',
        '',
        'Sesto Mina',
        1,
        27.7,
        16.304,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Agnes Bowen Trail',
        1,
        '/static/gpx/138_Agnes_Bowen_Trail.gpx',
        'USA',
        'Lucca',
        '',
        'Goffredo ligure',
        1.3,
        25,
        18.705,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Elliot Bronson Trail',
        1,
        '/static/gpx/139_Elliot_Bronson_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'Iovino sardo',
        0.8,
        12.1,
        11.538,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Walt Landgraf Trail',
        0,
        '/static/gpx/140_Walt_Landgraf_Trail.gpx',
        'USA',
        'Macerata',
        '',
        'Borgo Lorella',
        0.8,
        14.9,
        13.483,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Platt Hill Park Trail',
        2,
        '/static/gpx/141_Platt_Hill_Park_Trail.gpx',
        'USA',
        'Piacenza',
        '',
        'Giannini sardo',
        1.2,
        11.6,
        17.433,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quadick Park Path',
        2,
        '/static/gpx/142_Quadick_Park_Path.gpx',
        'USA',
        'Potenza',
        '',
        'Belotti salentino',
        1.2,
        14.2,
        15.859,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rocky Neck Park Sidewalk',
        2,
        '/static/gpx/143_Rocky_Neck_Park_Sidewalk.gpx',
        'USA',
        'Pistoia',
        '',
        'San Tiziana salentino',
        0.8,
        24,
        10.762,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rocky Neck Park Path',
        0,
        '/static/gpx/144_Rocky_Neck_Park_Path.gpx',
        'USA',
        'Olbia-Tempio',
        '',
        'Pascucci calabro',
        1.4,
        6.1,
        17.32,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rocky Neck Park Trail',
        1,
        '/static/gpx/145_Rocky_Neck_Park_Trail.gpx',
        'USA',
        'Udine',
        '',
        'Speranza laziale',
        1.2,
        23.9,
        15.789,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rope Swing',
        0,
        '/static/gpx/146_Rope_Swing.gpx',
        'USA',
        'Caserta',
        '',
        'Piersilvio veneto',
        1,
        11,
        13.393,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sleeping Giant Park Trail',
        2,
        '/static/gpx/147_Sleeping_Giant_Park_Trail.gpx',
        'USA',
        'Lucca',
        '',
        'Borgo Vito',
        1.3,
        24.5,
        18.932,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sherwood Island Park Path',
        0,
        '/static/gpx/148_Sherwood_Island_Park_Path.gpx',
        'USA',
        'Verbano-Cusio-Ossola',
        '',
        'La Rocca sardo',
        1.5,
        11.3,
        23.196,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sherwood Island Nature Trail',
        1,
        '/static/gpx/149_Sherwood_Island_Nature_Trail.gpx',
        'USA',
        'Pisa',
        '',
        'Arcadio ligure',
        1.4,
        21.4,
        17.355,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tower Trail',
        2,
        '/static/gpx/150_Tower_Trail.gpx',
        'USA',
        'Firenze',
        '',
        'Rita nell''emilia',
        1.4,
        20.2,
        18.834,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Southford Falls Park Trail',
        2,
        '/static/gpx/151_Southford_Falls_Park_Trail.gpx',
        'USA',
        'Salerno',
        '',
        'Borgo Giasone',
        1,
        6.2,
        14.052,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tunxis Forest Trail',
        2,
        '/static/gpx/152_Tunxis_Forest_Trail.gpx',
        'USA',
        'Asti',
        '',
        'Celli calabro',
        0.7,
        25.6,
        10.422,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sleeping Giant Trail',
        0,
        '/static/gpx/153_Sleeping_Giant_Trail.gpx',
        'USA',
        'Trieste',
        '',
        'Bonagiunta lido',
        1.2,
        29.7,
        15.859,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Squantz Pond Park Trail',
        1,
        '/static/gpx/154_Squantz_Pond_Park_Trail.gpx',
        'USA',
        'Pesaro e Urbino',
        '',
        'Settimo Cataldo',
        1.3,
        12.4,
        19.403,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Simsbury Park Trail',
        2,
        '/static/gpx/155_Simsbury_Park_Trail.gpx',
        'USA',
        'Ravenna',
        '',
        'Loris lido',
        1.5,
        20.5,
        19.027,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Stratton Brook Park Trail',
        0,
        '/static/gpx/156_Stratton_Brook_Park_Trail.gpx',
        'USA',
        'Aosta',
        '',
        'Cristiano terme',
        1.1,
        28.1,
        14.163,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Stratton Brook Park Path',
        1,
        '/static/gpx/157_Stratton_Brook_Park_Path.gpx',
        'USA',
        'Asti',
        '',
        'Quirino ligure',
        1.1,
        29.5,
        18.384,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Madden Fyler Pond Trail',
        1,
        '/static/gpx/158_Madden_Fyler_Pond_Trail.gpx',
        'USA',
        'Roma',
        '',
        'Quarto Giordano',
        1.5,
        20.1,
        24.259,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sunny Brook Park Trail',
        2,
        '/static/gpx/159_Sunny_Brook_Park_Trail.gpx',
        'USA',
        'Carbonia-Iglesias',
        '',
        'Cancelliere ligure',
        0.7,
        17,
        9.354,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Wolcott Trail',
        1,
        '/static/gpx/160_Wolcott_Trail.gpx',
        'USA',
        'Roma',
        '',
        'Sesto Norma ligure',
        0.6,
        25.2,
        8.09,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Fadoir Spring Trail',
        1,
        '/static/gpx/161_Fadoir_Spring_Trail.gpx',
        'USA',
        'Rovigo',
        '',
        'Tanzi terme',
        1.2,
        9.6,
        20.339,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Fadoir Trail',
        1,
        '/static/gpx/162_Fadoir_Trail.gpx',
        'USA',
        'Treviso',
        '',
        'Giraudo salentino',
        1.4,
        21.6,
        23.932,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Walnut Mountain Trail',
        1,
        '/static/gpx/163_Walnut_Mountain_Trail.gpx',
        'USA',
        'Ravenna',
        '',
        'Quarto Valente umbro',
        1.1,
        24.6,
        17.742,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Old Metacomet Trail',
        0,
        '/static/gpx/164_Old_Metacomet_Trail.gpx',
        'USA',
        'Bologna',
        '',
        'Borgo Euseo laziale',
        1.6,
        22.5,
        19.958,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Talcott Mountain Park Trail',
        1,
        '/static/gpx/165_Talcott_Mountain_Park_Trail.gpx',
        'USA',
        'Livorno',
        '',
        'Settimo Renata nell''emilia',
        1.5,
        20.3,
        18.405,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Falls Brook Trail',
        2,
        '/static/gpx/166_Falls_Brook_Trail.gpx',
        'USA',
        'Carbonia-Iglesias',
        '',
        'Quarto Iginia',
        2.6,
        25.8,
        41.6,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Whittemore Glen Trail',
        2,
        '/static/gpx/167_Whittemore_Glen_Trail.gpx',
        'USA',
        'Parma',
        '',
        'Abbondanzio umbro',
        1,
        9.6,
        13.575,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Wharton Brook Park Trail',
        2,
        '/static/gpx/168_Wharton_Brook_Park_Trail.gpx',
        'USA',
        'Pavia',
        '',
        'Garavaglia laziale',
        0.6,
        26.1,
        8.09,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Larkin Bridle Trail',
        1,
        '/static/gpx/169_Larkin_Bridle_Trail.gpx',
        'USA',
        'Crotone',
        '',
        'Aris a mare',
        9.2,
        11.8,
        112.424,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bluff Point Bike Path',
        1,
        '/static/gpx/170_Bluff_Point_Bike_Path.gpx',
        'USA',
        'Terni',
        '',
        'San Menelao laziale',
        0.7,
        6.3,
        9.929,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bluff Point Trail',
        2,
        '/static/gpx/171_Bluff_Point_Trail.gpx',
        'USA',
        'Macerata',
        '',
        'Genesio veneto',
        1.3,
        13.3,
        17.489,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Laurel Brook Trail',
        2,
        '/static/gpx/172_Laurel_Brook_Trail.gpx',
        'USA',
        'Asti',
        '',
        'Osvaldo veneto',
        1.5,
        7.8,
        24.194,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Red Cedar Trail',
        2,
        '/static/gpx/173_Red_Cedar_Trail.gpx',
        'USA',
        'Ascoli Piceno',
        '',
        'Tedeschi umbro',
        1.1,
        17.1,
        17.694,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'White Birch Trail',
        2,
        '/static/gpx/174_White_Birch_Trail.gpx',
        'USA',
        'Reggio Emilia',
        '',
        'Iezzi terme',
        1.3,
        16.1,
        17.031,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Little Falls Trail',
        2,
        '/static/gpx/175_Little_Falls_Trail.gpx',
        'USA',
        'Macerata',
        '',
        'Italo calabro',
        0.8,
        16.3,
        10.191,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Wadsworth Falls Park Trail',
        2,
        '/static/gpx/176_Wadsworth_Falls_Park_Trail.gpx',
        'USA',
        'Catanzaro',
        '',
        'Sesto Amatore',
        1.9,
        29.5,
        24.359,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rockfall Land Trust Trail',
        2,
        '/static/gpx/177_Rockfall_Land_Trust_Trail.gpx',
        'USA',
        'Caltanissetta',
        '',
        'Borgo Graziella lido',
        1.5,
        14.5,
        25.281,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Deer Trail',
        2,
        '/static/gpx/178_Deer_Trail.gpx',
        'USA',
        'Treviso',
        '',
        'Dini terme',
        1.4,
        16.6,
        19.905,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Turkey Vultures Ledges Trail',
        2,
        '/static/gpx/179_Turkey_Vultures_Ledges_Trail.gpx',
        'USA',
        'Udine',
        '',
        'Ferreri calabro',
        1.2,
        10.8,
        18.997,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'American Legion Forest Trail',
        2,
        '/static/gpx/180_American_Legion_Forest_Trail.gpx',
        'USA',
        'Novara',
        '',
        'Giustra terme',
        1.1,
        25.7,
        16.837,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Henry R Buck Trail',
        2,
        '/static/gpx/181_Henry_R_Buck_Trail.gpx',
        'USA',
        'Nuoro',
        '',
        'Settimo Settimo',
        3.1,
        6,
        41.892,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Breakneck Pond View Trail',
        2,
        '/static/gpx/182_Breakneck_Pond_View_Trail.gpx',
        'USA',
        'Biella',
        '',
        'Motta terme',
        1.8,
        17.3,
        24.161,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bigelow Pond Loop Trail',
        2,
        '/static/gpx/183_Bigelow_Pond_Loop_Trail.gpx',
        'USA',
        'Pordenone',
        '',
        'Settimo Gemma',
        0.7,
        6.2,
        10.319,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mashapaug Pond View Trail',
        2,
        '/static/gpx/184_Mashapaug_Pond_View_Trail.gpx',
        'USA',
        'Lecce',
        '',
        'Sesto Augusto salentino',
        4.8,
        19.7,
        58.656,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ridge Trail',
        2,
        '/static/gpx/185_Ridge_Trail.gpx',
        'USA',
        'Pavia',
        '',
        'Tazio a mare',
        1,
        6.5,
        12.195,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nipmuck Trail',
        2,
        '/static/gpx/186_Nipmuck_Trail.gpx',
        'USA',
        'Enna',
        '',
        'San Ampelio',
        0.9,
        21.1,
        12.558,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'East Ridge Trail',
        2,
        '/static/gpx/187_East_Ridge_Trail.gpx',
        'USA',
        'Parma',
        '',
        'Rapuano umbro',
        2,
        18.8,
        26.258,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattatuck Trail',
        2,
        '/static/gpx/188_Mattatuck_Trail.gpx',
        'USA',
        'Modena',
        '',
        'Ostuni laziale',
        0.9,
        19.6,
        15.297,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Black Rock Park Trail',
        2,
        '/static/gpx/189_Black_Rock_Park_Trail.gpx',
        'USA',
        'Bari',
        '',
        'Tranquillo terme',
        1.4,
        19.3,
        23.596,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Poquonnock River Walk',
        2,
        '/static/gpx/190_Poquonnock_River_Walk.gpx',
        'USA',
        'Chieti',
        '',
        'Settimo Daciano',
        1.2,
        11.4,
        19.149,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kempf & Shenipsit Trail',
        2,
        '/static/gpx/191_Kempf___Shenipsit_Trail.gpx',
        'USA',
        'Piacenza',
        '',
        'Dolce laziale',
        1.2,
        30,
        15.652,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mohegan Trail',
        0,
        '/static/gpx/192_Mohegan_Trail.gpx',
        'USA',
        'Catanzaro',
        '',
        'Quarto Marciano',
        0.6,
        10.3,
        7.407,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kempf Trail',
        1,
        '/static/gpx/193_Kempf_Trail.gpx',
        'USA',
        'Mantova',
        '',
        'Borgo Auberto',
        1.4,
        28.4,
        21.32,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Burr Pond Park Trail',
        0,
        '/static/gpx/194_Burr_Pond_Park_Trail.gpx',
        'USA',
        'Monza e della Brianza',
        '',
        'Borgo Guido del friuli',
        0.8,
        11.2,
        12.121,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Burr Pond Park Path',
        2,
        '/static/gpx/195_Burr_Pond_Park_Path.gpx',
        'USA',
        'Savona',
        '',
        'Campana nell''emilia',
        0.6,
        24.6,
        9.449,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Campbell Falls Trail',
        0,
        '/static/gpx/196_Campbell_Falls_Trail.gpx',
        'USA',
        'Verbano-Cusio-Ossola',
        '',
        'Tesifonte laziale',
        0.7,
        21.5,
        9.929,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Deep Woods Trail',
        2,
        '/static/gpx/197_Deep_Woods_Trail.gpx',
        'USA',
        'Torino',
        '',
        'Quarto Basileo nell''emilia',
        1.2,
        16.2,
        16.901,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chimney Trail',
        2,
        '/static/gpx/198_Chimney_Trail.gpx',
        'USA',
        'Caserta',
        '',
        'Tosco del friuli',
        0.9,
        23.2,
        11.868,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'East Woods Trail',
        2,
        '/static/gpx/199_East_Woods_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'Borgo Eutalia salentino',
        1.4,
        18.9,
        21.99,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'East Woods Connector Trail',
        2,
        '/static/gpx/200_East_Woods_Connector_Trail.gpx',
        'USA',
        'Asti',
        '',
        'Bianchetti umbro',
        0.5,
        5.4,
        6.961,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Covered Bridge Trail',
        2,
        '/static/gpx/201_Covered_Bridge_Trail.gpx',
        'USA',
        'Cagliari',
        '',
        'Basilio a mare',
        0.7,
        15.3,
        9.767,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Lookout Trail',
        2,
        '/static/gpx/202_Lookout_Trail.gpx',
        'USA',
        'Verbano-Cusio-Ossola',
        '',
        'Nazzaro nell''emilia',
        1.6,
        14.5,
        19.835,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chimney Spur Trail',
        2,
        '/static/gpx/203_Chimney_Spur_Trail.gpx',
        'USA',
        'Lodi',
        '',
        'Ferraris salentino',
        0.9,
        26,
        12.587,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'West Crest Trail',
        2,
        '/static/gpx/204_West_Crest_Trail.gpx',
        'USA',
        'Lecco',
        '',
        'Quarto Egisto sardo',
        1.1,
        9.9,
        15.64,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pond Trail',
        2,
        '/static/gpx/205_Pond_Trail.gpx',
        'USA',
        'Caserta',
        '',
        'Viscardo lido',
        3.2,
        18.3,
        42.478,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chatfield Hollow Park Trail',
        2,
        '/static/gpx/206_Chatfield_Hollow_Park_Trail.gpx',
        'USA',
        'Prato',
        '',
        'Settimo Afro sardo',
        1.3,
        28.5,
        22.034,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Paul F Wildermann',
        0,
        '/static/gpx/207_Paul_F_Wildermann.gpx',
        'USA',
        'Piacenza',
        '',
        'Isidora sardo',
        1.2,
        28,
        18.09,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pattaconk Trail',
        2,
        '/static/gpx/208_Pattaconk_Trail.gpx',
        'USA',
        'Vicenza',
        '',
        'Porzia sardo',
        1.5,
        22.9,
        18.367,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Cockaponset Trail',
        2,
        '/static/gpx/209_Cockaponset_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'Settimo Adelfo',
        0.6,
        11.1,
        9.474,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinimay Trail',
        1,
        '/static/gpx/210_Quinimay_Trail.gpx',
        'USA',
        'Varese',
        '',
        'Peaquin calabro',
        0.6,
        21.8,
        7.438,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kay Fullerton Trail',
        2,
        '/static/gpx/211_Kay_Fullerton_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'San Teobaldo nell''emilia',
        1.4,
        25,
        16.97,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Cowboy Way Trail',
        2,
        '/static/gpx/212_Cowboy_Way_Trail.gpx',
        'USA',
        'Pescara',
        '',
        'Eleuterio nell''emilia',
        1.1,
        24.3,
        15.457,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Muck Rock Road Trail',
        2,
        '/static/gpx/213_Muck_Rock_Road_Trail.gpx',
        'USA',
        'Trieste',
        '',
        'Settimo Rosmunda laziale',
        1.4,
        28.4,
        22.951,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Weber Road Trail',
        2,
        '/static/gpx/214_Weber_Road_Trail.gpx',
        'USA',
        'Terni',
        '',
        'Sesto Polidoro',
        1.5,
        10.7,
        22.843,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Wood Road Trail',
        2,
        '/static/gpx/215_Wood_Road_Trail.gpx',
        'USA',
        'La Spezia',
        '',
        'Illidio sardo',
        1.1,
        24.9,
        17.984,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Beechnut Bog Trail',
        2,
        '/static/gpx/216_Beechnut_Bog_Trail.gpx',
        'USA',
        'Siracusa',
        '',
        'Morabito lido',
        1.4,
        9.4,
        17.647,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bumpy Hill Road Trail',
        2,
        '/static/gpx/217_Bumpy_Hill_Road_Trail.gpx',
        'USA',
        'Chieti',
        '',
        'Settimo Sansone',
        1.3,
        8.2,
        20.8,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kristens Way Trail',
        2,
        '/static/gpx/218_Kristens_Way_Trail.gpx',
        'USA',
        'Fermo',
        '',
        'Quarto Argo lido',
        1,
        17.6,
        13.216,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Messerschmidt Lane Trail',
        2,
        '/static/gpx/219_Messerschmidt_Lane_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'Borgo Quiteria salentino',
        0.8,
        14.5,
        13.333,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tower Hill Connector Trail',
        2,
        '/static/gpx/220_Tower_Hill_Connector_Trail.gpx',
        'USA',
        'Cuneo',
        '',
        'Quarto Casto',
        1.4,
        19.1,
        19.355,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattabesset Trail',
        2,
        '/static/gpx/221_Mattabesset_Trail.gpx',
        'USA',
        'Modena',
        '',
        'Adrione umbro',
        0.6,
        10.8,
        7.692,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattabasset Trail',
        2,
        '/static/gpx/222_Mattabasset_Trail.gpx',
        'USA',
        'Roma',
        '',
        'Di Somma umbro',
        1.1,
        25,
        14.072,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Old Mattebesset Trail',
        2,
        '/static/gpx/223_Old_Mattebesset_Trail.gpx',
        'USA',
        'Novara',
        '',
        'Sesto Lisa umbro',
        1,
        20.2,
        14.019,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Huntington Park Trail',
        2,
        '/static/gpx/224_Huntington_Park_Trail.gpx',
        'USA',
        'Rimini',
        '',
        'Delfino umbro',
        1.1,
        19.3,
        13.387,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Huntington Ridge Trail',
        2,
        '/static/gpx/225_Huntington_Ridge_Trail.gpx',
        'USA',
        'Avellino',
        '',
        'Settimo Loreno lido',
        1,
        10.3,
        15,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Aspetuck Valley Trail',
        2,
        '/static/gpx/226_Aspetuck_Valley_Trail.gpx',
        'USA',
        'Cosenza',
        '',
        'Croce salentino',
        0.7,
        16.5,
        8.607,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Vista Trail',
        2,
        '/static/gpx/227_Vista_Trail.gpx',
        'USA',
        'Imperia',
        '',
        'Denti laziale',
        1.3,
        7.1,
        17.105,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Witch Hazel/Millington Trail',
        2,
        '/static/gpx/228_Witch_Hazel_Millington_Trail.gpx',
        'USA',
        'Modena',
        '',
        'Quarto Indro ligure',
        1.2,
        8.6,
        17.433,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Millington Trail',
        2,
        '/static/gpx/229_Millington_Trail.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Sesto Lisa salentino',
        1.3,
        8.5,
        18.31,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Witch Hazel Trail',
        2,
        '/static/gpx/230_Witch_Hazel_Trail.gpx',
        'USA',
        'Benevento',
        '',
        'Cara nell''emilia',
        0.9,
        15.2,
        11.02,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Woodcutters Trail',
        2,
        '/static/gpx/231_Woodcutters_Trail.gpx',
        'USA',
        'Brindisi',
        '',
        'Settimo Abelardo salentino',
        0.8,
        14.3,
        11.06,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Devils Hopyard Park Trail',
        2,
        '/static/gpx/232_Devils_Hopyard_Park_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Benvenuta nell''emilia',
        1.4,
        11.3,
        20.639,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Loop Trail',
        2,
        '/static/gpx/233_Loop_Trail.gpx',
        'USA',
        'Vercelli',
        '',
        'Borgo Milo a mare',
        1.5,
        11,
        21.028,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Maxs Trail',
        2,
        '/static/gpx/234_Maxs_Trail.gpx',
        'USA',
        'Verbano-Cusio-Ossola',
        '',
        'Rossini lido',
        1.4,
        26.7,
        24,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Machimoodus Park Trail',
        1,
        '/static/gpx/235_Machimoodus_Park_Trail.gpx',
        'USA',
        'Sassari',
        '',
        'Quarto Mariella',
        1,
        27.7,
        14.888,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Fishermans Trail',
        1,
        '/static/gpx/236_Fishermans_Trail.gpx',
        'USA',
        'Salerno',
        '',
        'San Emilio salentino',
        1,
        22.1,
        13.825,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ccc Trail',
        2,
        '/static/gpx/237_Ccc_Trail.gpx',
        'USA',
        'Roma',
        '',
        'Sesto Lelia',
        3.7,
        15.5,
        49.554,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Natchaug Trail',
        2,
        '/static/gpx/238_Natchaug_Trail.gpx',
        'USA',
        'Piacenza',
        '',
        'San Morena veneto',
        0.7,
        12.5,
        10.606,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Natchaug Forest Trail',
        2,
        '/static/gpx/239_Natchaug_Forest_Trail.gpx',
        'USA',
        'Massa-Carrara',
        '',
        'Toti terme',
        0.6,
        20.2,
        9.254,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Goodwin Forest Trail',
        2,
        '/static/gpx/240_Goodwin_Forest_Trail.gpx',
        'USA',
        'Latina',
        '',
        'Colmanno a mare',
        1.2,
        5.5,
        18.605,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pine Acres Pond Trail',
        2,
        '/static/gpx/241_Pine_Acres_Pond_Trail.gpx',
        'USA',
        'Pistoia',
        '',
        'San Mercede salentino',
        0.5,
        11.9,
        6.865,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Brown Hill Pond Trail',
        2,
        '/static/gpx/242_Brown_Hill_Pond_Trail.gpx',
        'USA',
        'Foggia',
        '',
        'Quarto Gennaro salentino',
        0.7,
        13.8,
        11.053,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Red Yellow Connector Trail',
        2,
        '/static/gpx/243_Red_Yellow_Connector_Trail.gpx',
        'USA',
        'Bologna',
        '',
        'Erico sardo',
        1.5,
        9.8,
        20.089,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Yellow White Loop Trail',
        2,
        '/static/gpx/244_Yellow_White_Loop_Trail.gpx',
        'USA',
        'Brindisi',
        '',
        'Privato laziale',
        1.1,
        9.2,
        14.072,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Governor''S Island Trail',
        2,
        '/static/gpx/245_Governor_S_Island_Trail.gpx',
        'USA',
        'Trento',
        '',
        'San Ciro',
        1.2,
        21.1,
        14.724,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Goodwin Heritage Trail',
        0,
        '/static/gpx/246_Goodwin_Heritage_Trail.gpx',
        'USA',
        'Benevento',
        '',
        'Settimo Sirio',
        1.2,
        17,
        18.701,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Forest Discovery Trail',
        1,
        '/static/gpx/247_Forest_Discovery_Trail.gpx',
        'USA',
        'Lecce',
        '',
        'Borgo Innocente',
        0.8,
        12.7,
        11.111,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Crest',
        2,
        '/static/gpx/248_Crest.gpx',
        'USA',
        'Lecce',
        '',
        'San Casilda del friuli',
        1.2,
        8.4,
        16.327,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Miller Brook Connector Trail',
        0,
        '/static/gpx/249_Miller_Brook_Connector_Trail.gpx',
        'USA',
        'Lucca',
        '',
        'Vittori veneto',
        1.4,
        12.7,
        21.538,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mansfield Hollow Park Trail',
        0,
        '/static/gpx/250_Mansfield_Hollow_Park_Trail.gpx',
        'USA',
        'Ravenna',
        '',
        'Sesto Osvaldo nell''emilia',
        1.7,
        14.9,
        20.606,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nipmuck Trail - East Branch',
        0,
        '/static/gpx/251_Nipmuck_Trail___East_Branch.gpx',
        'USA',
        'Vicenza',
        '',
        'Paolo laziale',
        0.9,
        19.8,
        12.19,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nipmuck Alternate',
        0,
        '/static/gpx/252_Nipmuck_Alternate.gpx',
        'USA',
        'Perugia',
        '',
        'Borgo Diamante',
        0.9,
        22.8,
        11.066,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mashamoquet Brook Nature Trail',
        0,
        '/static/gpx/253_Mashamoquet_Brook_Nature_Trail.gpx',
        'USA',
        'Trieste',
        '',
        'Ruberto ligure',
        0.8,
        25.3,
        10.435,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nipmuck Forest Trail',
        2,
        '/static/gpx/254_Nipmuck_Forest_Trail.gpx',
        'USA',
        'Taranto',
        '',
        'Quarto Evaristo',
        1.8,
        24.4,
        22.689,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Morey Pond Trail',
        2,
        '/static/gpx/255_Morey_Pond_Trail.gpx',
        'USA',
        'Caltanissetta',
        '',
        'Leopardi veneto',
        0.6,
        5.4,
        8.036,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pharisee Rock Trail',
        2,
        '/static/gpx/256_Pharisee_Rock_Trail.gpx',
        'USA',
        'Cosenza',
        '',
        'Borgo Virginio a mare',
        1.1,
        26.2,
        16.019,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug Forest Trail',
        2,
        '/static/gpx/257_Pachaug_Forest_Trail.gpx',
        'USA',
        'Reggio Emilia',
        '',
        'Quarto Dora laziale',
        0.8,
        5.4,
        10.435,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug Trail',
        2,
        '/static/gpx/258_Pachaug_Trail.gpx',
        'USA',
        'Taranto',
        '',
        'Milena a mare',
        1.1,
        7.2,
        18.539,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Canonicus Trail',
        2,
        '/static/gpx/259_Canonicus_Trail.gpx',
        'USA',
        'Modena',
        '',
        'Greco salentino',
        0.6,
        25.4,
        7.912,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Laurel Loop Trail',
        2,
        '/static/gpx/260_Laurel_Loop_Trail.gpx',
        'USA',
        'Alessandria',
        '',
        'Sesto Gioia veneto',
        1.1,
        22.9,
        16.837,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug/Nehantic Connector',
        2,
        '/static/gpx/261_Pachaug_Nehantic_Connector.gpx',
        'USA',
        'Taranto',
        '',
        'Schirru terme',
        1.5,
        23,
        19.19,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug/Tippecansett Connector',
        2,
        '/static/gpx/262_Pachaug_Tippecansett_Connector.gpx',
        'USA',
        'Ascoli Piceno',
        '',
        'Romano salentino',
        0.5,
        16.4,
        6.682,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic/Pachaug Connector',
        2,
        '/static/gpx/263_Nehantic_Pachaug_Connector.gpx',
        'USA',
        'Verbano-Cusio-Ossola',
        '',
        'Settimo Fiorenza',
        0.6,
        28.6,
        8.411,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinebaug/Pachaug Connector',
        2,
        '/static/gpx/264_Quinebaug_Pachaug_Connector.gpx',
        'USA',
        'Matera',
        '',
        'Pavan umbro',
        1,
        16.6,
        15.424,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinebaug Trail',
        2,
        '/static/gpx/265_Quinebaug_Trail.gpx',
        'USA',
        'Medio Campidano',
        '',
        'Sesto Barsimeo calabro',
        1.4,
        9.8,
        20.588,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug/Narragansett Connector',
        2,
        '/static/gpx/266_Pachaug_Narragansett_Connector.gpx',
        'USA',
        'Cosenza',
        '',
        'Bambina del friuli',
        0.7,
        26.6,
        11.765,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Green Falls Loop Trail',
        2,
        '/static/gpx/267_Green_Falls_Loop_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Bibiano a mare',
        1.2,
        29.7,
        19.672,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Narragansett Trail',
        2,
        '/static/gpx/268_Narragansett_Trail.gpx',
        'USA',
        'Genova',
        '',
        'Ovidio veneto',
        1.4,
        30,
        19.091,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Freeman Trail',
        2,
        '/static/gpx/269_Freeman_Trail.gpx',
        'USA',
        'Nuoro',
        '',
        'Bonazzi sardo',
        1.5,
        11.8,
        18.109,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tippecansett Trail',
        2,
        '/static/gpx/270_Tippecansett_Trail.gpx',
        'USA',
        'Udine',
        '',
        'San Rutilo',
        1.2,
        12.2,
        14.876,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Green Falls Water Access Trail',
        2,
        '/static/gpx/271_Green_Falls_Water_Access_Trail.gpx',
        'USA',
        'Latina',
        '',
        'Martucci lido',
        1.1,
        11.5,
        18.132,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic/Pachaug Trail',
        2,
        '/static/gpx/272_Nehantic_Pachaug_Trail.gpx',
        'USA',
        'Pavia',
        '',
        'Sesto Archimede',
        1,
        7.2,
        12.766,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Phillips Pond Spur Trail',
        2,
        '/static/gpx/273_Phillips_Pond_Spur_Trail.gpx',
        'USA',
        'Oristano',
        '',
        'Borgo Palatino',
        1.4,
        14.2,
        18.584,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Paugussett Forest Trail',
        2,
        '/static/gpx/274_Paugussett_Forest_Trail.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Galluzzo sardo',
        0.8,
        24.5,
        10.367,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Zoar Trail',
        2,
        '/static/gpx/275_Zoar_Trail.gpx',
        'USA',
        'Avellino',
        '',
        'Settimo Crescenzio',
        1,
        27.2,
        16.667,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Lillinonah Trail',
        2,
        '/static/gpx/276_Lillinonah_Trail.gpx',
        'USA',
        'Cuneo',
        '',
        'Floriano del friuli',
        1.2,
        18.1,
        16.941,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Zoar Trail (Old)',
        2,
        '/static/gpx/277_Zoar_Trail__Old_.gpx',
        'USA',
        'Grosseto',
        '',
        'Borgo Giotto laziale',
        1.4,
        23.3,
        17.647,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Upper Gussy Trail',
        1,
        '/static/gpx/278_Upper_Gussy_Trail.gpx',
        'USA',
        'Firenze',
        '',
        'San Leonida lido',
        1.5,
        16.7,
        18,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pierrepont Park Trail',
        2,
        '/static/gpx/279_Pierrepont_Park_Trail.gpx',
        'USA',
        'Firenze',
        '',
        'Borgo Gentile',
        1.5,
        25.6,
        23.684,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shenipsit Forest Trail',
        2,
        '/static/gpx/280_Shenipsit_Forest_Trail.gpx',
        'USA',
        'Bari',
        '',
        'Borgo Serena nell''emilia',
        1.3,
        22.1,
        17.89,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quary Trail',
        2,
        '/static/gpx/281_Quary_Trail.gpx',
        'USA',
        'Monza e della Brianza',
        '',
        'Veridiana umbro',
        1.1,
        20.2,
        18.384,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shenipsit Forest Road',
        2,
        '/static/gpx/282_Shenipsit_Forest_Road.gpx',
        'USA',
        'Taranto',
        '',
        'De Sanctis salentino',
        1.2,
        22.4,
        15.721,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Edith M Chase Ecology Trail',
        2,
        '/static/gpx/283_Edith_M_Chase_Ecology_Trail.gpx',
        'USA',
        'Olbia-Tempio',
        '',
        'Crisafulli del friuli',
        1.2,
        28.1,
        19.835,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Topsmead Forest Trail',
        2,
        '/static/gpx/284_Topsmead_Forest_Trail.gpx',
        'USA',
        'Rieti',
        '',
        'Telchide sardo',
        1.4,
        5.8,
        22.46,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bernard H Stairs Trail',
        2,
        '/static/gpx/285_Bernard_H_Stairs_Trail.gpx',
        'USA',
        'Genova',
        '',
        'Settimo Giambattista',
        1,
        20,
        12.987,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'West Rock Park Trail',
        2,
        '/static/gpx/286_West_Rock_Park_Trail.gpx',
        'USA',
        'Crotone',
        '',
        'Settimo Prudenzio salentino',
        0.6,
        9.5,
        9.114,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'West Rock Summit Trail',
        2,
        '/static/gpx/287_West_Rock_Summit_Trail.gpx',
        'USA',
        'Aosta',
        '',
        'Varo umbro',
        1.1,
        24.5,
        14.865,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Regicides Trail',
        2,
        '/static/gpx/288_Regicides_Trail.gpx',
        'USA',
        'Massa-Carrara',
        '',
        'Borgo Cornelia del friuli',
        2.6,
        17.7,
        36.62,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sanford Feeder Trail',
        2,
        '/static/gpx/289_Sanford_Feeder_Trail.gpx',
        'USA',
        'Vibo Valentia',
        '',
        'Borgo Milena',
        1.1,
        16.7,
        15.714,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'North Summit Trail',
        2,
        '/static/gpx/290_North_Summit_Trail.gpx',
        'USA',
        'Imperia',
        '',
        'Settimo Quartilla',
        1.8,
        8,
        23.581,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Westville Feeder Trail',
        2,
        '/static/gpx/291_Westville_Feeder_Trail.gpx',
        'USA',
        'La Spezia',
        '',
        'Ulpiano terme',
        0.8,
        21.9,
        13.115,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'West Rock Park Road',
        2,
        '/static/gpx/292_West_Rock_Park_Road.gpx',
        'USA',
        'Cuneo',
        '',
        'Settimo Desiderio',
        0.8,
        18.1,
        12.435,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bennetts Pond Trail',
        2,
        '/static/gpx/293_Bennetts_Pond_Trail.gpx',
        'USA',
        'Varese',
        '',
        'Fabiano ligure',
        1,
        18.8,
        12.5,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ives Trail',
        0,
        '/static/gpx/294_Ives_Trail.gpx',
        'USA',
        'Lodi',
        '',
        'Cronida ligure',
        1,
        16.2,
        16.62,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ridgefield Open Space Trail',
        1,
        '/static/gpx/295_Ridgefield_Open_Space_Trail.gpx',
        'USA',
        'Viterbo',
        '',
        'Romeo calabro',
        1.1,
        25.7,
        15.981,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'George Dudley Seymour Park Trail',
        2,
        '/static/gpx/296_George_Dudley_Seymour_Park_Trail.gpx',
        'USA',
        'Frosinone',
        '',
        'Salvadori calabro',
        1,
        9,
        15.075,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Grta',
        1,
        '/static/gpx/297_Grta.gpx',
        'USA',
        'Vicenza',
        '',
        'Melillo lido',
        1,
        7.9,
        14.151,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mohegan Forest Trail',
        2,
        '/static/gpx/298_Mohegan_Forest_Trail.gpx',
        'USA',
        'Carbonia-Iglesias',
        '',
        'Quarto Alba',
        1.4,
        29.3,
        20.438,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mount Bushnell Trail',
        2,
        '/static/gpx/299_Mount_Bushnell_Trail.gpx',
        'USA',
        'Matera',
        '',
        'Rodolfo terme',
        0.5,
        13.1,
        7.538,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nye Holman Trail',
        2,
        '/static/gpx/300_Nye_Holman_Trail.gpx',
        'USA',
        'Chieti',
        '',
        'Remo laziale',
        1.6,
        17.4,
        24,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Al''S Trail',
        2,
        '/static/gpx/301_Al_S_Trail.gpx',
        'USA',
        'Parma',
        '',
        'San Furio',
        1.1,
        16.1,
        17.054,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Salt Rock State Park Trail',
        2,
        '/static/gpx/302_Salt_Rock_State_Park_Trail.gpx',
        'USA',
        'Cuneo',
        '',
        'San Giliola laziale',
        1.4,
        28.9,
        24,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Scantic River Trail',
        0,
        '/static/gpx/303_Scantic_River_Trail.gpx',
        'USA',
        'Brindisi',
        '',
        'Riccobono veneto',
        1.2,
        12.7,
        14.907,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Scantic River Park Trail',
        1,
        '/static/gpx/304_Scantic_River_Park_Trail.gpx',
        'USA',
        'Lodi',
        '',
        'Settimo Mauro',
        1,
        15.7,
        14.563,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Scantic Park Access',
        0,
        '/static/gpx/305_Scantic_Park_Access.gpx',
        'USA',
        'Genova',
        '',
        'Ermete nell''emilia',
        0.8,
        18.4,
        12.183,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sunrise Park Trail',
        0,
        '/static/gpx/306_Sunrise_Park_Trail.gpx',
        'USA',
        'Vercelli',
        '',
        'Sesto Pellegrino',
        1.1,
        25.4,
        15.529,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kitchel Trail',
        0,
        '/static/gpx/307_Kitchel_Trail.gpx',
        'USA',
        'Genova',
        '',
        'Settimo Domenico del friuli',
        1.3,
        11.8,
        20.968,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kitchel',
        0,
        '/static/gpx/308_Kitchel.gpx',
        'USA',
        'Oristano',
        '',
        'Settimo Michelangelo del friuli',
        1.3,
        21.7,
        18.396,
        ''
      );
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2)
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        4,
        52,
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Dott. Roberta Puggioni',
        'https://nocturnal-seal.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        8,
        43,
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Omar Senatore',
        'https://miserly-diaper.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        5,
        68,
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Alano Salierno',
        'https://essential-pleasure.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        5,
        138,
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Mauro Marongiu',
        'https://shameful-guest.com',
        null
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        10,
        68,
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Miriam Sbrana',
        'http://angelic-spat.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        1,
        96,
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Rosamunda Bellucci',
        'http://sugary-solvency.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        5,
        82,
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Dr. Appia Parente',
        'http://decimal-mutt.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        5,
        37,
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Sibilla De Salvo',
        'https://nutty-theft.org',
        null
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        2,
        130,
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Clelia Paladini',
        'http://empty-mall.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        10,
        83,
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Lapo Evola',
        'http://celebrated-red.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        8,
        72,
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Franco Grosso',
        'https://stiff-panty.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        2,
        146,
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Allegra Poli',
        'http://mature-reorganisation.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        1,
        94,
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Birino Di Marino',
        'http://surprised-hospitalization.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        4,
        44,
        'Vernagthütte',
        'Austria',
        'Ermilo Tuccillo',
        'https://youthful-chest.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        9,
        45,
        'Wormser Hütte',
        'Austria',
        'Nereo Rocchi',
        'https://corrupt-compassionate.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        2,
        111,
        'Biberacher Hütte',
        'Austria',
        'Letizia Favero',
        'http://lonely-wedding.com',
        null
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        2,
        48,
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Graziano Torresi',
        'http://overdue-area.com',
        null
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        8,
        140,
        'Hochwaldhütte',
        'Germany',
        'Orfeo Zaccaria',
        'http://loathsome-lunch.it',
        null
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        2,
        121,
        'Kölner Eifelhütte',
        'Germany',
        'Adalgiso Iaria',
        'https://definite-cap.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        6,
        107,
        'Madrisahütte',
        'Austria',
        'Iside Notaro',
        'https://starchy-mesenchyme.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        10,
        132,
        'Dresdner Hütte',
        'Austria',
        'Delfina Tomaselli',
        'http://impolite-influx.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        8,
        79,
        'Fiderepasshütte',
        'Germany',
        'Dr. Aurelia Ciccarelli',
        'http://speedy-stock-in-trade.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        2,
        42,
        'Göppinger Hütte',
        'Austria',
        'Giovanni Tasso',
        'https://flustered-deposit.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        9,
        90,
        'Oberzalimhütte',
        'Austria',
        'Adriano Riggi',
        'https://complete-poll.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        5,
        144,
        'Rastkogelhütte',
        'Austria',
        'Giove Orlando',
        'https://second-hand-court.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        8,
        55,
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Sig. Benigna Tallarico',
        'https://tired-kidney.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        1,
        108,
        'Kaltenberghütte',
        'Austria',
        'Leo Peaquin',
        'https://cool-harm.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        10,
        58,
        'Schweinfurter Hütte',
        'Austria',
        'Dionigi Giannotti',
        'http://distorted-limo.org',
        null
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        5,
        78,
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Carina Fonti',
        'http://mature-month.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        1,
        130,
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Garimberto Vailati',
        'http://hasty-extension.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        7,
        48,
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Vulmaro De Vita',
        'http://dense-presence.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        6,
        114,
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Gastone Mori',
        'https://eager-mozzarella.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        4,
        86,
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Postumio Callegari',
        'https://fatal-advance.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        7,
        148,
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Elvino Caccamo',
        'https://ignorant-meander.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        8,
        49,
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Celso Giuliano',
        'https://wide-eyed-cholesterol.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        1,
        59,
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Dr. Morena Cardini',
        'http://fake-kale.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        10,
        67,
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Severa Lupi',
        'https://charming-nonconformist.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        10,
        38,
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Anselmo Botta',
        'http://dental-pride.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        3,
        101,
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Privato Rodigari',
        'https://ready-belly.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        6,
        137,
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Cunegonda Destro',
        'http://thoughtful-tone.org',
        null
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        4,
        92,
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Brigitta Leoncini',
        'https://gracious-flint.com',
        null
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        5,
        132,
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Berardo Pece',
        'http://bumpy-nit.org',
        null
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        1,
        90,
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Asterio Franzè',
        'https://icky-variable.it',
        null
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        10,
        44,
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Ing. Corinna Scarano',
        'https://threadbare-alder.net',
        null
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        3,
        37,
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Isidora Da Rold',
        'https://rubbery-cloister.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        2,
        143,
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Ponzio Lari',
        'http://circular-civilization.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        5,
        122,
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Macaria Battisti',
        'https://lame-spiritual.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        8,
        55,
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Enecone Sottile',
        'https://afraid-orange.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        5,
        127,
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Liberata Macchi',
        'https://immaculate-effacement.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        6,
        119,
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Desdemona Salzano',
        'http://sunny-moai.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        2,
        117,
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Cordelia Mazzoleno',
        'http://flustered-lady.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        3,
        55,
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Dott. Francesca Fusaro',
        'http://creepy-apron.org',
        null
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        1,
        36,
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Giosuè Palmieri',
        'https://outlandish-value.org',
        null
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        1,
        76,
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Donna Ciaccio',
        'https://crowded-dimple.it',
        null
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        7,
        75,
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Fausto Giovinazzo',
        'https://tame-speculation.com',
        null
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        10,
        57,
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Elisa Maurizi',
        'https://hidden-privilege.com',
        null
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        9,
        79,
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Odetta Marinucci',
        'http://stylish-immigrant.it',
        null
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        9,
        60,
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Chiara Fabiano',
        'http://shameful-moustache.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        4,
        61,
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Ionne Dragoni',
        'http://icky-specialty.net',
        null
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        3,
        109,
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Marinella Loffredo',
        'https://yawning-jicama.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        9,
        124,
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Arnaldo Forgione',
        'https://unwelcome-equinox.net',
        null
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        8,
        62,
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Nestore Piazza',
        'https://petty-gallery.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        2,
        143,
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Claudio Palmisano',
        'http://substantial-aside.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        1,
        76,
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Alessia Meli',
        'https://pleased-postage.net',
        null
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        4,
        108,
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Vinebaldo Librizzi',
        'https://nifty-snowmobiling.net',
        null
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        5,
        108,
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Fedele Castellano',
        'http://plaintive-infinite.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        8,
        82,
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Napoleone Huber',
        'https://jaunty-sill.it',
        null
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        6,
        145,
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Lodovica Perri',
        'http://thirsty-daylight.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        4,
        88,
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Elita Cascone',
        'http://tall-pressroom.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        10,
        94,
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Maurilio Mercuri',
        'http://plump-heir.net',
        null
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        7,
        96,
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Dott. Beniamino Martini',
        'https://plush-minimum.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        7,
        50,
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Zoilo Martines',
        'https://ringed-promotion.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        6,
        129,
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Onorata Montemurro',
        'http://ragged-episode.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        2,
        56,
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Dr. Romano Casavecchia',
        'http://cluttered-sheath.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        5,
        94,
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Edoardo Moffa',
        'http://giant-insert.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        9,
        60,
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Concetta Gullì',
        'https://grounded-schooner.it',
        null
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        8,
        111,
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Diego Aceto',
        'https://nippy-woodwind.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        9,
        49,
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Fabio Ambrosini',
        'https://windy-stroke.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        8,
        113,
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Sidonia Michelucci',
        'http://excited-craftsman.org',
        null
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        10,
        60,
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Metrofane Guglielmi',
        'http://bustling-ranger.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        10,
        83,
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Nazzareno Vicini',
        'http://mixed-tempo.net',
        null
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        6,
        60,
        'Wittener Hütte',
        'Germany',
        'Letizia Pascarella',
        'http://excellent-rhyme.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        3,
        105,
        'Hochjoch-Hospiz',
        'Austria',
        'Lucio Bellomo',
        'http://creative-crib.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        9,
        120,
        'Meilerhütte',
        'Germany',
        'Dott. Allegra Petrucci',
        'http://flustered-individual.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        4,
        50,
        'Gaudeamushütte',
        'Austria',
        'Pantaleo Gusmeroli',
        'http://frilly-barium.it',
        null
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        8,
        106,
        'Rheydter Hütte',
        'Germany',
        'Iago Paonessa',
        'https://shy-hypothermia.com',
        null
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        7,
        149,
        'Sektionshütte Krippen',
        'Germany',
        'Melchiorre Minniti',
        'http://thin-self.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        3,
        61,
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Donatella Tagliaferri',
        'https://paltry-shred.com',
        null
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        4,
        46,
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Rainaldo Marelli',
        'https://normal-fondue.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        7,
        74,
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Semiramide Mair',
        'https://crisp-gland.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        10,
        140,
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Tiberio Nobili',
        'http://fabulous-genius.net',
        null
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        8,
        52,
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Gordiano Polito',
        'https://major-rib.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        7,
        141,
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Sigismondo Canepa',
        'http://motionless-wage.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        10,
        62,
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Durante Giorgi',
        'http://whirlwind-cape.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        9,
        117,
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Carola Catanzaro',
        'http://tight-slip.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        5,
        106,
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Ofelia Campisi',
        'https://joint-teller.net',
        null
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        10,
        43,
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Elvino Cammarata',
        'http://grounded-facet.net',
        null
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        6,
        94,
        'Dobra voda',
        'Suvobor, Serbia',
        'Ildebrando Marrone',
        'https://tan-victim.it',
        null
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        9,
        119,
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Sidonia Gatto',
        'http://french-size.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        7,
        134,
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Giulia Piazza',
        'https://bumpy-interject.net',
        null
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        3,
        38,
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Mirocleto La Porta',
        'http://anchored-architect.it',
        null
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        2,
        69,
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Zosimo Grande',
        'http://dangerous-put.org',
        null
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        6,
        131,
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Cleandro Esposito',
        'https://ultimate-potato.com',
        null
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        4,
        84,
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Celinia Maltese',
        'http://that-harmony.it',
        null
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        7,
        119,
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Dott. Natalina Cannella',
        'https://dapper-world.net',
        null
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        4,
        102,
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Ottilia Perna',
        'http://giddy-derivative.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        6,
        130,
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Gianmaria Cannas',
        'https://unpleasant-guinea.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        5,
        91,
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Eleonora D''Alessandro',
        'https://light-hub.com',
        null
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '79 Strada Nicea, Sesto Colombano salentino, Italy',
        'Sesto Colombano salentino',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        276,
        '665 Rotonda Esuperio, Borgo Sirio, Italy',
        'Borgo Sirio',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        174,
        '8 Borgo Huber, Settimo Reginaldo, Italy',
        'Settimo Reginaldo',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        286,
        '108 Strada Gullì, Ruggero salentino, Italy',
        'Ruggero salentino',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        77,
        '774 Contrada Desdemona, Quarto Monaldo terme, Italy',
        'Quarto Monaldo terme',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        256,
        '0 Via Ottilia, Castellana nell''emilia, Italy',
        'Castellana nell''emilia',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        54,
        '944 Piazza Vedasto, Quarto Grazia del friuli, Italy',
        'Quarto Grazia del friuli',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        147,
        '451 Contrada Vodingo, Granata del friuli, Italy',
        'Granata del friuli',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        160,
        '11 Piazza Schirru, Ventimiglia calabro, Italy',
        'Ventimiglia calabro',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        293,
        '99 Via Diodata, Sesto Basilio lido, Italy',
        'Sesto Basilio lido',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        146,
        '910 Via Pio, Borgo Erberto, Italy',
        'Borgo Erberto',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        203,
        '694 Borgo Di Maro, Settimo Ida, Italy',
        'Settimo Ida',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        120,
        '7 Piazza Giosuele, Quarto Giorgio, Italy',
        'Quarto Giorgio',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        87,
        '2 Via Antonio, Quarto Antelmo, Italy',
        'Quarto Antelmo',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        204,
        '08 Rotonda Senesio, Bresciani veneto, Italy',
        'Bresciani veneto',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        268,
        '515 Piazza Verecondo, Gigliola laziale, Italy',
        'Gigliola laziale',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        117,
        '76 Piazza Acrisio, Quarto Terzo calabro, Italy',
        'Quarto Terzo calabro',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        145,
        '871 Contrada Orlando, San Camillo, Italy',
        'San Camillo',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        130,
        '548 Strada Cerrato, Antonia a mare, Italy',
        'Antonia a mare',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        162,
        '68 Rotonda Teudosia, Borgo Iside laziale, Italy',
        'Borgo Iside laziale',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        190,
        '90 Strada Iside, San Roberto, Italy',
        'San Roberto',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        205,
        '50 Strada Falco, Vincenzo terme, Italy',
        'Vincenzo terme',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '9 Rotonda Barbarossa, Consolata salentino, Italy',
        'Consolata salentino',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        70,
        '6 Strada Feliziani, Pezzella calabro, Italy',
        'Pezzella calabro',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        129,
        '048 Strada Galeazzi, Gabriele laziale, Italy',
        'Gabriele laziale',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        286,
        '78 Strada Berardo, Settimo Ada lido, Italy',
        'Settimo Ada lido',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        197,
        '0 Rotonda Nicol�, Borgo Beniamino, Italy',
        'Borgo Beniamino',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        157,
        '8 Incrocio Piero, Mauro terme, Italy',
        'Mauro terme',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        194,
        '73 Incrocio Maida, San Ileana del friuli, Italy',
        'San Ileana del friuli',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        125,
        '163 Strada Ambrosini, Borgo Enecone ligure, Italy',
        'Borgo Enecone ligure',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        240,
        '754 Incrocio Messina, Ottaviano a mare, Italy',
        'Ottaviano a mare',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        292,
        '81 Via Tristano, Rizzi calabro, Italy',
        'Rizzi calabro',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        198,
        '15 Via Santilli, Settimo Vespasiano, Italy',
        'Settimo Vespasiano',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '2 Contrada Fidenzio, Quarto Pardo nell''emilia, Italy',
        'Quarto Pardo nell''emilia',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        253,
        '2 Contrada Ariele, San Ismaele, Italy',
        'San Ismaele',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        227,
        '13 Via Angeletti, Quarto Veronica terme, Italy',
        'Quarto Veronica terme',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        102,
        '04 Borgo Albina, Sesto Temistocle calabro, Italy',
        'Sesto Temistocle calabro',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        131,
        '50 Incrocio Clelia, Benedetti laziale, Italy',
        'Benedetti laziale',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        207,
        '595 Piazza Daria, Calcedonio sardo, Italy',
        'Calcedonio sardo',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        47,
        '933 Rotonda Altieri, Sesto Felicita del friuli, Italy',
        'Sesto Felicita del friuli',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '72 Piazza Traini, Settimo Cecilio nell''emilia, Italy',
        'Settimo Cecilio nell''emilia',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        227,
        '6 Incrocio Molinaro, Sesto Canziano salentino, Italy',
        'Sesto Canziano salentino',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        30,
        '84 Strada Pugliesi, Sesto Giasone, Italy',
        'Sesto Giasone',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        68,
        '1 Borgo Pucci, Diamante nell''emilia, Italy',
        'Diamante nell''emilia',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        119,
        '470 Borgo Sacco, San Edoardo, Italy',
        'San Edoardo',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        54,
        '5 Borgo Eufrasia, Sesto Abaco calabro, Italy',
        'Sesto Abaco calabro',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        268,
        '525 Rotonda Salvi, Prisco salentino, Italy',
        'Prisco salentino',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        47,
        '320 Strada Marangoni, Borgo Beronico calabro, Italy',
        'Borgo Beronico calabro',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        195,
        '855 Rotonda Apollonia, Settimo Zenebio, Italy',
        'Settimo Zenebio',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        270,
        '87 Incrocio Rea, Cingolani del friuli, Italy',
        'Cingolani del friuli',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        240,
        '035 Piazza Mazza, Telemaco nell''emilia, Italy',
        'Telemaco nell''emilia',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '2 Strada Gori, Sesto Liberata nell''emilia, Italy',
        'Sesto Liberata nell''emilia',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        185,
        '49 Via Gillo, Settimo Amabile, Italy',
        'Settimo Amabile',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '18 Strada Valentina, Borgo Maida, Italy',
        'Borgo Maida',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        289,
        '82 Incrocio Adelina, Filippi del friuli, Italy',
        'Filippi del friuli',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        228,
        '1 Rotonda Petralia, Sinfronio del friuli, Italy',
        'Sinfronio del friuli',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        280,
        '3 Via Quiteria, Borgo Aleardo, Italy',
        'Borgo Aleardo',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        208,
        '440 Via Salomone, Carolina calabro, Italy',
        'Carolina calabro',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        59,
        '368 Piazza Fiorini, Quarto Quintiliano umbro, Italy',
        'Quarto Quintiliano umbro',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        296,
        '3 Rotonda Mascolo, San Mancio terme, Italy',
        'San Mancio terme',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        47,
        '1 Rotonda Zaira, Borgo Giobbe, Italy',
        'Borgo Giobbe',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        275,
        '6 Via Emma, Sesto Amedeo lido, Italy',
        'Sesto Amedeo lido',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        43,
        '07 Contrada Mignogna, San Aldo terme, Italy',
        'San Aldo terme',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        88,
        '596 Incrocio Euseo, Saponaro ligure, Italy',
        'Saponaro ligure',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        33,
        '75 Piazza Vincenza, Settimo Beltramo sardo, Italy',
        'Settimo Beltramo sardo',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        291,
        '71 Piazza Ottavio, Selene nell''emilia, Italy',
        'Selene nell''emilia',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        136,
        '1 Contrada Ione, Settimo Monaldo, Italy',
        'Settimo Monaldo',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        238,
        '6 Contrada Fuoco, Quarto Calcedonio, Italy',
        'Quarto Calcedonio',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        278,
        '13 Borgo Spizzirri, San Gioventino, Italy',
        'San Gioventino',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '71 Via Doda, Ingrassia umbro, Italy',
        'Ingrassia umbro',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        87,
        '532 Strada Eleonora, Vespasiano umbro, Italy',
        'Vespasiano umbro',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        294,
        '360 Via Edmondo, Sesto Geltrude nell''emilia, Italy',
        'Sesto Geltrude nell''emilia',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        140,
        '923 Borgo Grieco, Settimo Antonello, Italy',
        'Settimo Antonello',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        184,
        '5 Rotonda Edilberto, Abbondanza umbro, Italy',
        'Abbondanza umbro',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        226,
        '16 Via Evaristo, Panetta ligure, Italy',
        'Panetta ligure',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        27,
        '8 Borgo Di Mauro, Iride sardo, Italy',
        'Iride sardo',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        238,
        '174 Borgo Bertelli, Volfango del friuli, Italy',
        'Volfango del friuli',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        43,
        '711 Strada Abaco, Borgo Adolfo calabro, Italy',
        'Borgo Adolfo calabro',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        178,
        '477 Strada Emidio, Borgo Gedeone, Italy',
        'Borgo Gedeone',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        270,
        '025 Incrocio Napoletano, Luigi veneto, Italy',
        'Luigi veneto',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        249,
        '1 Strada De Maio, Baraldi terme, Italy',
        'Baraldi terme',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        65,
        '36 Strada Filomeno, Furseo veneto, Italy',
        'Furseo veneto',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        129,
        '391 Piazza Cloe, Ducci ligure, Italy',
        'Ducci ligure',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        27,
        '44 Via Godiva, San Eraldo, Italy',
        'San Eraldo',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        68,
        '1 Incrocio Immacolato, Salvucci nell''emilia, Italy',
        'Salvucci nell''emilia',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        79,
        '3 Piazza Alfreda, Cascio nell''emilia, Italy',
        'Cascio nell''emilia',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        270,
        '518 Piazza Ventura, San Renzo, Italy',
        'San Renzo',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        114,
        '608 Strada Montanari, Puglisi nell''emilia, Italy',
        'Puglisi nell''emilia',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        52,
        '032 Strada Maffei, San Delinda del friuli, Italy',
        'San Delinda del friuli',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        221,
        '73 Contrada Moro, Borgo Giancarlo umbro, Italy',
        'Borgo Giancarlo umbro',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        129,
        '607 Rotonda Molteni, San Liberato, Italy',
        'San Liberato',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        96,
        '808 Piazza Manti, Sesto Teodosio, Italy',
        'Sesto Teodosio',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        145,
        '782 Via Ambra, Carli del friuli, Italy',
        'Carli del friuli',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        118,
        '09 Rotonda Vanessa, Adelmo salentino, Italy',
        'Adelmo salentino',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        39,
        '25 Borgo Girardi, Settimo Claudio, Italy',
        'Settimo Claudio',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        46,
        '52 Contrada Ortenzi, San Ippolito sardo, Italy',
        'San Ippolito sardo',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        216,
        '994 Incrocio Prisca, Bonazzi sardo, Italy',
        'Bonazzi sardo',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        48,
        '2 Piazza Avallone, Quarto Elifio calabro, Italy',
        'Quarto Elifio calabro',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        220,
        '18 Rotonda Lucia, Mattia veneto, Italy',
        'Mattia veneto',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        64,
        '06 Via Ragusa, Settimo Abramio, Italy',
        'Settimo Abramio',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        37,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        138,
        '0 Borgo Tommasi, Pivetta laziale, Italy',
        'Pivetta laziale',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        44,
        '343 Rotonda Eloisa, San Rita, Italy',
        'San Rita',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        76,
        '85 Incrocio Salzano, Borgo Romina veneto, Italy',
        'Borgo Romina veneto',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        197,
        '0 Borgo Idea, Sesto Salom�, Italy',
        'Sesto Salom�',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        58,
        '758 Borgo Orenzio, Palmira a mare, Italy',
        'Palmira a mare',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        152,
        '78 Piazza Allegretti, Concordio del friuli, Italy',
        'Concordio del friuli',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        278,
        '204 Piazza Ardito, San Zetico umbro, Italy',
        'San Zetico umbro',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        182,
        '128 Strada Poletti, Sesto Laura, Italy',
        'Sesto Laura',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        80,
        '8 Piazza Meloni, Sesto Veriana sardo, Italy',
        'Sesto Veriana sardo',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        103,
        '266 Via Abramio, Mancini calabro, Italy',
        'Mancini calabro',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        80,
        '739 Piazza Sabina, Romanini del friuli, Italy',
        'Romanini del friuli',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        172,
        '708 Borgo Benvenuti, Settimo Azzurra calabro, Italy',
        'Settimo Azzurra calabro',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        80,
        '543 Via Veneranda, Tolomeo terme, Italy',
        'Tolomeo terme',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        182,
        '56 Piazza Calanico, Sesto Severa nell''emilia, Italy',
        'Sesto Severa nell''emilia',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        258,
        '576 Strada Esa�, Pugliesi lido, Italy',
        'Pugliesi lido',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        89,
        '746 Contrada Ascione, Ermenegildo salentino, Italy',
        'Ermenegildo salentino',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        137,
        '06 Borgo Marita, Roberta terme, Italy',
        'Roberta terme',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        217,
        '347 Strada Dario, Borgo Carmela, Italy',
        'Borgo Carmela',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        236,
        '07 Piazza Castellano, Quarto Linda lido, Italy',
        'Quarto Linda lido',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        178,
        '7 Contrada Mazzotti, Rainelda laziale, Italy',
        'Rainelda laziale',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        267,
        '79 Rotonda Malco, Zeno umbro, Italy',
        'Zeno umbro',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        273,
        '0 Via Lo Iacono, San Penelope, Italy',
        'San Penelope',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        100,
        '862 Borgo Manicone, San Otello, Italy',
        'San Otello',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        163,
        '64 Rotonda Olga, Giorgia a mare, Italy',
        'Giorgia a mare',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        41,
        '82 Incrocio Pala, Sesto Alfonso, Italy',
        'Sesto Alfonso',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '122 Incrocio Marilena, San Folco umbro, Italy',
        'San Folco umbro',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        174,
        '659 Contrada Venusto, Rubiano sardo, Italy',
        'Rubiano sardo',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        155,
        '97 Strada Bacco, Castaldo laziale, Italy',
        'Castaldo laziale',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '14 Piazza Maffeo, Borgo Silvano del friuli, Italy',
        'Borgo Silvano del friuli',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '2 Contrada Pupolo, Siracusa umbro, Italy',
        'Siracusa umbro',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        199,
        '368 Incrocio Veronica, Fratello salentino, Italy',
        'Fratello salentino',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        194,
        '8 Incrocio Orsino, Sesto Maggiorino, Italy',
        'Sesto Maggiorino',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        278,
        '569 Strada Masiero, Morini del friuli, Italy',
        'Morini del friuli',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        54,
        '076 Strada Felicia, Elia laziale, Italy',
        'Elia laziale',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        235,
        '81 Borgo De Vita, Capoccia nell''emilia, Italy',
        'Capoccia nell''emilia',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '02 Incrocio Elmo, Ildegarda laziale, Italy',
        'Ildegarda laziale',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '28 Rotonda Bibiano, San Abdone del friuli, Italy',
        'San Abdone del friuli',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        31,
        '517 Borgo Pirone, Eros veneto, Italy',
        'Eros veneto',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '60 Contrada Carini, Quarto Misaele, Italy',
        'Quarto Misaele',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        69,
        '146 Contrada Vulmaro, Otello ligure, Italy',
        'Otello ligure',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        243,
        '168 Via Barbarigo, Paradiso del friuli, Italy',
        'Paradiso del friuli',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        62,
        '16 Borgo Cora, Quarto Fernando nell''emilia, Italy',
        'Quarto Fernando nell''emilia',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        208,
        '033 Rotonda Lucidi, Catanzaro lido, Italy',
        'Catanzaro lido',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        221,
        '07 Strada Claudia, Emanuele veneto, Italy',
        'Emanuele veneto',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        84,
        '9 Incrocio Teudosia, Settimo Cornelio, Italy',
        'Settimo Cornelio',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        137,
        '498 Contrada Marino, Pirone terme, Italy',
        'Pirone terme',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        270,
        '67 Incrocio Piscopo, Capogna ligure, Italy',
        'Capogna ligure',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        140,
        '046 Borgo Mamante, Settimo Gerasimo, Italy',
        'Settimo Gerasimo',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        89,
        '33 Strada Petrarca, Musso lido, Italy',
        'Musso lido',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        253,
        '289 Incrocio Evangelisti, Alma laziale, Italy',
        'Alma laziale',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        108,
        '187 Strada Cerullo, Sesto Antonio, Italy',
        'Sesto Antonio',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        234,
        '36 Contrada Bernardini, Borgo Rubiano, Italy',
        'Borgo Rubiano',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        286,
        '988 Piazza Palladino, Minelli del friuli, Italy',
        'Minelli del friuli',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        177,
        '00 Strada Garau, Quarto Alda, Italy',
        'Quarto Alda',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        281,
        '1 Rotonda Quaranta, Raniolo calabro, Italy',
        'Raniolo calabro',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        75,
        '87 Strada Alvaro, Settimo Saverio veneto, Italy',
        'Settimo Saverio veneto',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        281,
        '774 Incrocio Onorata, Sesto Alano, Italy',
        'Sesto Alano',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        277,
        '0 Via Campo, Consiglio veneto, Italy',
        'Consiglio veneto',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        136,
        '606 Contrada Battaglia, Rina veneto, Italy',
        'Rina veneto',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        184,
        '4 Rotonda Femina, San Adelmo laziale, Italy',
        'San Adelmo laziale',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        42,
        '895 Borgo Borrelli, Papapietro del friuli, Italy',
        'Papapietro del friuli',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        36,
        '5 Strada Forconi, Dionisia umbro, Italy',
        'Dionisia umbro',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        169,
        '0 Strada Calanico, Cardini a mare, Italy',
        'Cardini a mare',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        207,
        '26 Contrada Modica, Sesto Mara, Italy',
        'Sesto Mara',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '106 Contrada Lippolis, Settimo Primo, Italy',
        'Settimo Primo',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        153,
        '9 Rotonda Giovenzio, Lori ligure, Italy',
        'Lori ligure',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        63,
        '17 Incrocio Costante, Quarto Urbano, Italy',
        'Quarto Urbano',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        46,
        '85 Via Eros, Ausiliatrice lido, Italy',
        'Ausiliatrice lido',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        34,
        '5 Rotonda Masala, Settimo Sostrato, Italy',
        'Settimo Sostrato',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        109,
        '632 Contrada Serr, San Adele, Italy',
        'San Adele',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        80,
        '694 Piazza Felicita, Settimo Barbara, Italy',
        'Settimo Barbara',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        278,
        '02 Rotonda Cara, Carponio umbro, Italy',
        'Carponio umbro',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        141,
        '992 Incrocio Bino, Settimo Bartolomea laziale, Italy',
        'Settimo Bartolomea laziale',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        49,
        '8 Piazza Di Franco, Settimo Edelberga, Italy',
        'Settimo Edelberga',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        121,
        '7 Piazza Baldassarre, Longobardi del friuli, Italy',
        'Longobardi del friuli',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        239,
        '032 Contrada Zosimo, Vera laziale, Italy',
        'Vera laziale',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        224,
        '332 Piazza Benetti, Sesto Nazario, Italy',
        'Sesto Nazario',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        170,
        '48 Contrada Sinfronio, No� lido, Italy',
        'No� lido',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        60,
        '35 Incrocio Buccheri, Sesto Tranquillo, Italy',
        'Sesto Tranquillo',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        40,
        '9 Borgo Petrelli, Quarto Albrico calabro, Italy',
        'Quarto Albrico calabro',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        190,
        '670 Incrocio Di Marco, Zanon lido, Italy',
        'Zanon lido',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '601 Strada Rina, Sesto Ardito del friuli, Italy',
        'Sesto Ardito del friuli',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        279,
        '595 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        177,
        '736 Via Rufino, Borgo Emmerico lido, Italy',
        'Borgo Emmerico lido',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        95,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        63,
        '04 Rotonda Amoroso, Lara calabro, Italy',
        'Lara calabro',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        61,
        '0 Strada Ragusa, Quarto Costantino, Italy',
        'Quarto Costantino',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        129,
        '40 Borgo Esmeralda, Martino salentino, Italy',
        'Martino salentino',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        102,
        '6 Via Durante, Settimo Caino veneto, Italy',
        'Settimo Caino veneto',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        299,
        '57 Piazza Isabella, Settimo Polidoro lido, Italy',
        'Settimo Polidoro lido',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        220,
        '63 Incrocio Rinaldo, Quarto Uranio, Italy',
        'Quarto Uranio',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        178,
        '62 Borgo Umberto, Sesto Dario, Italy',
        'Sesto Dario',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        141,
        '8 Contrada Moroni, Liberio umbro, Italy',
        'Liberio umbro',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        176,
        '8 Via Pollina, Settimo Sonia, Italy',
        'Settimo Sonia',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        73,
        '63 Incrocio Saverio, Traini veneto, Italy',
        'Traini veneto',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        274,
        '538 Contrada Capitolina, Borgo Rutilo laziale, Italy',
        'Borgo Rutilo laziale',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        184,
        '3 Contrada Patrone, Teresa a mare, Italy',
        'Teresa a mare',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        264,
        '2 Piazza Ecclesio, Borgo Mariella, Italy',
        'Borgo Mariella',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        141,
        '7 Via Huber, Lazzaro del friuli, Italy',
        'Lazzaro del friuli',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        115,
        '86 Borgo Eufronio, Sesto Isidoro, Italy',
        'Sesto Isidoro',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        198,
        '093 Strada Vezio, Crisci a mare, Italy',
        'Crisci a mare',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '1 Borgo Lisa, Tarquini a mare, Italy',
        'Tarquini a mare',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        93,
        '9 Via Salvatore, Erardo umbro, Italy',
        'Erardo umbro',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        38,
        '405 Via Barretta, San Regina del friuli, Italy',
        'San Regina del friuli',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        145,
        '0 Strada Termine, Settimo Genesia, Italy',
        'Settimo Genesia',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        79,
        '09 Via Marchetto, Malavasi del friuli, Italy',
        'Malavasi del friuli',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        53,
        '0 Contrada Calabria, Famiano del friuli, Italy',
        'Famiano del friuli',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        114,
        '1 Via Acquadro, Borgo Ines, Italy',
        'Borgo Ines',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        165,
        '7 Strada Santinelli, Cavaliere calabro, Italy',
        'Cavaliere calabro',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        157,
        '27 Via Traverso, Ventura sardo, Italy',
        'Ventura sardo',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        225,
        '43 Strada Prassede, Sesto Prospero lido, Italy',
        'Sesto Prospero lido',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '78 Strada Cola, Stella ligure, Italy',
        'Stella ligure',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        97,
        '14 Incrocio Improta, Bianchi veneto, Italy',
        'Bianchi veneto',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        106,
        '558 Piazza Magno, Borgo Feliciano, Italy',
        'Borgo Feliciano',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        164,
        '055 Piazza Palmira, San Euclide, Italy',
        'San Euclide',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        208,
        '7 Contrada Callegari, San Mariella umbro, Italy',
        'San Mariella umbro',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        200,
        '61 Rotonda Oderico, Cataldo nell''emilia, Italy',
        'Cataldo nell''emilia',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        192,
        '1 Piazza Antonucci, Matranga ligure, Italy',
        'Matranga ligure',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        221,
        '9 Rotonda Tedesco, Felice del friuli, Italy',
        'Felice del friuli',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        111,
        '11 Piazza Fabiano, San Antelmo, Italy',
        'San Antelmo',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '5 Incrocio Carla, Settimo Galeazzo calabro, Italy',
        'Settimo Galeazzo calabro',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        204,
        '17 Strada Argimiro, Zappia lido, Italy',
        'Zappia lido',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        235,
        '93 Contrada Lena, Settimo Giusta sardo, Italy',
        'Settimo Giusta sardo',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        76,
        '274 Borgo Bertini, Quarto Dina veneto, Italy',
        'Quarto Dina veneto',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        26,
        '153 Strada Adriano, Quarto Irene, Italy',
        'Quarto Irene',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        125,
        '7 Piazza Cattaneo, Quarto Senofonte nell''emilia, Italy',
        'Quarto Senofonte nell''emilia',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        286,
        '02 Rotonda Italo, Quarto Ugolino terme, Italy',
        'Quarto Ugolino terme',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        200,
        '16 Incrocio De Bonis, Settimo Sabrina nell''emilia, Italy',
        'Settimo Sabrina nell''emilia',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        188,
        '2 Piazza Bedini, Santina calabro, Italy',
        'Santina calabro',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        299,
        '620 Contrada Giglio, Settimo Flavia terme, Italy',
        'Settimo Flavia terme',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        159,
        '1 Incrocio Marilena, Settimo Ciro, Italy',
        'Settimo Ciro',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        265,
        '981 Piazza Onofrio, Pastore terme, Italy',
        'Pastore terme',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        182,
        '175 Via Orazio, Borgo Priamo laziale, Italy',
        'Borgo Priamo laziale',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        33,
        '964 Rotonda Franchini, De Bona terme, Italy',
        'De Bona terme',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        177,
        '17 Incrocio Milan, Mattia veneto, Italy',
        'Mattia veneto',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        27,
        '636 Contrada Marzia, San Ianira umbro, Italy',
        'San Ianira umbro',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        194,
        '3 Incrocio Demurtas, Amone sardo, Italy',
        'Amone sardo',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        159,
        '63 Strada Gino, Settimo Ermenegilda, Italy',
        'Settimo Ermenegilda',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        192,
        '68 Strada Oliviera, Quarto Piera, Italy',
        'Quarto Piera',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        99,
        '6 Rotonda Cattaneo, Borgo Sabazio salentino, Italy',
        'Borgo Sabazio salentino',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        212,
        '6 Borgo Celeste, Sabele terme, Italy',
        'Sabele terme',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        50,
        '170 Via Cointa, Settimo Olga, Italy',
        'Settimo Olga',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        250,
        '76 Borgo Onorina, Socrate terme, Italy',
        'Socrate terme',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        281,
        '9 Incrocio Dione, Sandro sardo, Italy',
        'Sandro sardo',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        190,
        '3 Borgo Loredana, Gastone a mare, Italy',
        'Gastone a mare',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        242,
        '60 Rotonda Corrado, Gulino veneto, Italy',
        'Gulino veneto',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        123,
        '3 Strada Mosca, Sesto Rosa salentino, Italy',
        'Sesto Rosa salentino',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        147,
        '4 Via Druina, Tito ligure, Italy',
        'Tito ligure',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '0 Via Pellegrini, Borgo Fosca, Italy',
        'Borgo Fosca',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        52,
        '151 Incrocio Aristide, Fabiani a mare, Italy',
        'Fabiani a mare',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        55,
        '7 Piazza Rondoni, Sesto Nostriano a mare, Italy',
        'Sesto Nostriano a mare',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        41,
        '776 Strada Savoia, Gisella del friuli, Italy',
        'Gisella del friuli',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        161,
        '8 Piazza Sammartano, Deodato veneto, Italy',
        'Deodato veneto',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        156,
        '86 Contrada Metello, San Aresio, Italy',
        'San Aresio',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        156,
        '1 Piazza Reina, San Leontina laziale, Italy',
        'San Leontina laziale',
        'Italy',
        'Taranto',
        ''
      );
    
  