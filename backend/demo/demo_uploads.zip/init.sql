--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$L8sxX0iW3XOeZ98amx9y4u6k5L6wZ7/gWJTjvZuTjFGkvG08YhDUu',
    'Antonio',
    'Battipaglia',
    2,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$0bDYKHxgP6RafoD6nDs69.lyJ5UX3OWHJZeTbEPL6X/OnDbYTwsKe',
    'Erfan',
    'Gholami',
    4,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$EkArUU3WnaAF2mOsUAgLQOsKIs9Jgtl9KoFPsVScQUap3mqtRTGZe',
    'Laura',
    'Zurru',
    5,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$n.At0qJ8b.kkN25Nog03KOlrMOUFZiUwtxFHbawkHIExTAKnTi7OW',
    'German',
    'Gorodnev',
    0,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$a.Ifept8JrHDZYPpwb5.1e.NYGdWbVOBGSntq3Wbp4VgSTPELqAWW',
    'vincenzo',
    'Sagristano',
    3,
    true
  );
  

      CREATE OR REPLACE FUNCTION public.insert_hike(
        user_id integer,
        title varchar,
        difficulty integer,
        gpx_path varchar,
        country varchar,
        region varchar,
        province varchar,
        city varchar,
        length numeric(12,2),
        ascent numeric(12,2),
        expected_time integer,
        description varchar,
        pictures jsonb,
        start_point jsonb,
        end_point jsonb,
        reference_points jsonb
      )  RETURNS VOID AS
      $func$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hike"(
        2,
        'Amprimo',
        2,
        '/static/gpx/Amprimo.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        1.2,
        7.7,
        80,
        'Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.',
        '["/static/images/3.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.165559804,"lat":45.102780737}'::jsonb,
        '{"name":"End Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.14299586,"lat":45.099887898}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":7.164360252,"lat":45.102912389,"altitude":1256.852},{"name":"Ref Point 2","address":"","lon":7.158207147,"lat":45.102886551,"altitude":1283.605}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello Chateau Beaulard - Cotolivier - Vazon',
        1,
        '/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Beaulard',
        8,
        28.4,
        200,
        'Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.',
        '["/static/images/2.jpg"]'::jsonb,
        '{"name":"Start Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.772358,"lat":45.03205}'::jsonb,
        '{"name":"End Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.77234,"lat":45.032238}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago Bianco',
        2,
        '/static/gpx/Lago Bianco.gpx',
        'Francia',
        'Auvergne-Rhone-Alpes',
        'Savoia',
        'Val-Cenis',
        8,
        17.4,
        210,
        'Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.

La diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.

La Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.

Si può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.',
        '["/static/images/1.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945681,"lat":45.223814}'::jsonb,
        '{"name":"End Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945581,"lat":45.224058}'::jsonb,
        '[{"name":"fountain","address":"","lon":6.940291,"lat":45.222543,"altitude":2027},{"name":"Peak","address":"","lon":6.937204,"lat":45.215867,"altitude":2131}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Alte Langhe Settentrionali - Cossano Belbo',
        2,
        '/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cossano Belbo',
        1.3,
        17.4,
        200,
        'Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.
Si svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.
Si imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.
Inizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.
Percorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. 
Seguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. 
Si procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante',
        '["/static/images/4.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199049,"lat":44.670379}'::jsonb,
        '{"name":"End Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199052,"lat":44.670377}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":8.214142,"lat":44.674545,"altitude":482.526},{"name":"Ref Point 2","address":"","lon":8.197792,"lat":44.668772,"altitude":242.585}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'La pieve romanica di Piesenzana e la valle delle tartufaie',
        2,
        '/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montechiaro d''Asti',
        16.5,
        9.9,
        225,
        'Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. 
Circa 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. 
In regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. 
A Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). 
Contemporaneamente i ristoranti della zona propongono piatti a base di tartufi',
        '["/static/images/5.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.113224,"lat":45.007605}'::jsonb,
        '{"name":"End Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.11358,"lat":45.007557}'::jsonb,
        NULL
      );
    
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2),
        working_time_start time without time zone,
        working_time_end time without time zone,
        email varchar,
        phone_number varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        8,
        64::numeric(12,2),
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Diego Lana',
        'http://acrobatic-rate.org',
        279.161,
        '05:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Peleo_Zanon94@libero.it',
        '+396706422381'
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        10,
        109::numeric(12,2),
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Olimpia Caterino',
        'http://loyal-tintype.it',
        331.526,
        '08:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Astrid82@hotmail.com',
        '+395357659733'
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        7,
        45::numeric(12,2),
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Olindo Mercurio',
        'http://square-bump.org',
        307.696,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Elvia9@hotmail.com',
        '+395517710359'
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        2,
        137::numeric(12,2),
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Annagrazia Zollo',
        'http://revolving-river.it',
        297.713,
        '08:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Serafino.DiMichele@yahoo.it',
        '+398448275156'
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        7,
        129::numeric(12,2),
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Telica Signorini',
        'http://near-paragraph.org',
        324.916,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Domenica28@yahoo.it',
        '+391152596788'
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        3,
        56::numeric(12,2),
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Ing. Odetta Argenio',
        'https://victorious-heartache.net',
        274.327,
        '04:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Esa_Soldati@yahoo.it',
        '+397320968042'
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        4,
        74::numeric(12,2),
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Dr. Cantidio Olla',
        'https://palatable-intentionality.com',
        260.051,
        '06:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Gillo65@email.it',
        '+393183169577'
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        5,
        36::numeric(12,2),
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Achille Cenni',
        'https://spherical-genie.it',
        319.295,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Ivone_Miceli@yahoo.com',
        '+391572891880'
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        3,
        79::numeric(12,2),
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Ing. Surano Repetto',
        'http://stingy-standing.org',
        315.412,
        '02:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Muziano51@libero.it',
        '+396114084256'
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        1,
        105::numeric(12,2),
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Sostrato Berti',
        'https://definite-likelihood.org',
        267.972,
        '01:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Aurelia_Mariani16@gmail.com',
        '+396196552666'
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        10,
        71::numeric(12,2),
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Colomba Pellegrino',
        'https://illegal-departure.it',
        305.441,
        '02:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Colmazio_Sepe@yahoo.it',
        '+394073393483'
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        8,
        85::numeric(12,2),
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Viliana Senatore',
        'http://sour-gelatin.net',
        328.098,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Zenobia_Biagi@email.it',
        '+394189024194'
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        9,
        99::numeric(12,2),
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Mirella Miotto',
        'https://lone-liner.it',
        281.838,
        '01:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Albano.Canova@libero.it',
        '+396315156184'
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        3,
        92::numeric(12,2),
        'Vernagthütte',
        'Austria',
        'Acacio Farina',
        'http://first-number.it',
        339.154,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Orazio_Sacco@yahoo.com',
        '+398086596421'
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        7,
        81::numeric(12,2),
        'Wormser Hütte',
        'Austria',
        'Bibiana Leggio',
        'http://scented-admin.it',
        324.218,
        '03:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Erasmo_Tortorici@gmail.com',
        '+399155604256'
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        2,
        137::numeric(12,2),
        'Biberacher Hütte',
        'Austria',
        'Sig. Melezio Biagi',
        'https://carefree-nick.net',
        286.729,
        '01:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Silvio.Falbo@hotmail.com',
        '+396926803134'
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        3,
        124::numeric(12,2),
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Aldobrando Guastone',
        'http://disastrous-vacuum.it',
        330.239,
        '05:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Pollione_Procopio1@yahoo.it',
        '+398351759180'
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        9,
        140::numeric(12,2),
        'Hochwaldhütte',
        'Germany',
        'Berardo Manetti',
        'http://sane-litmus.com',
        281.8,
        '07:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Brigitta.Carboni@yahoo.it',
        '+398028393299'
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        1,
        89::numeric(12,2),
        'Kölner Eifelhütte',
        'Germany',
        'Dr. Minervina Carbone',
        'http://truthful-lesbian.com',
        313.89,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Socrate33@yahoo.it',
        '+390199041666'
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        5,
        83::numeric(12,2),
        'Madrisahütte',
        'Austria',
        'Cino Romeo',
        'https://playful-mussel.it',
        326.941,
        '07:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Abbondio_Biancheri@yahoo.com',
        '+392968216390'
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        3,
        114::numeric(12,2),
        'Dresdner Hütte',
        'Austria',
        'Loriana Albanese',
        'http://wilted-clover.com',
        323.809,
        '04:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Speranza16@libero.it',
        '+394955858711'
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        3,
        54::numeric(12,2),
        'Fiderepasshütte',
        'Germany',
        'Dr. Guendalina Rigoni',
        'https://infatuated-timber.net',
        305.079,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Edvige82@gmail.com',
        '+395207035595'
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        4,
        37::numeric(12,2),
        'Göppinger Hütte',
        'Austria',
        'Liberio Crisafulli',
        'https://dismal-sac.com',
        261.879,
        '01:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Bianca4@yahoo.com',
        '+391626212867'
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        3,
        120::numeric(12,2),
        'Oberzalimhütte',
        'Austria',
        'Abbondanzio Caccamo',
        'http://virtual-necklace.net',
        312.005,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Celinia.Bonanno@gmail.com',
        '+390716824054'
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        3,
        87::numeric(12,2),
        'Rastkogelhütte',
        'Austria',
        'Rutilo Malatesta',
        'https://upright-diver.net',
        314.094,
        '02:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Roberta_Messana@email.it',
        '+395541693038'
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        10,
        87::numeric(12,2),
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Guenda Marras',
        'http://fatal-badge.net',
        300.452,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Gianluigi.DiMatteo@yahoo.it',
        '+395907724543'
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        6,
        55::numeric(12,2),
        'Kaltenberghütte',
        'Austria',
        'Mariano Morra',
        'https://inconsequential-goodness.com',
        337.937,
        '08:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Selene.Manzi@yahoo.it',
        '+393124947992'
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        4,
        150::numeric(12,2),
        'Schweinfurter Hütte',
        'Austria',
        'Valerio Santilli',
        'https://authorized-cod.org',
        272.168,
        '01:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Ezechiele.Luise93@hotmail.com',
        '+398944131422'
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        8,
        65::numeric(12,2),
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Telica Mulas',
        'https://competent-pomelo.it',
        309.832,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Erberto_Comito@email.it',
        '+394096787440'
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        9,
        112::numeric(12,2),
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Verena Panetta',
        'https://prize-step-aunt.it',
        317.472,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Atanasia_Biondi8@libero.it',
        '+396678287545'
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        9,
        87::numeric(12,2),
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Rosanna Bergamini',
        'http://tinted-clerk.org',
        264.721,
        '01:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Agapito_DAlessio@yahoo.com',
        '+392660983061'
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        4,
        38::numeric(12,2),
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Dott. Alcina Giardini',
        'https://well-made-handicap.com',
        326.364,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Martina_Lotito28@email.it',
        '+396133919335'
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        5,
        45::numeric(12,2),
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Amanzio Lo Presti',
        'https://hilarious-grandmother.org',
        327.721,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Rosanna_Carboni@hotmail.com',
        '+396507344074'
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        10,
        61::numeric(12,2),
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Rolando Salvadori',
        'https://splendid-ocean.net',
        309.582,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Enrico.Raffa@yahoo.com',
        '+394850267875'
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        9,
        50::numeric(12,2),
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Gallicano Biggi',
        'https://soupy-ex-wife.net',
        301.557,
        '08:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Secondo56@yahoo.com',
        '+396870955315'
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        2,
        92::numeric(12,2),
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Azzurra De Angelis',
        'https://which-collapse.it',
        276.901,
        '05:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Federica.Manno63@gmail.com',
        '+394602576108'
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        8,
        145::numeric(12,2),
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Nives Ambrosino',
        'http://great-lieu.com',
        336.276,
        '03:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Aladino16@yahoo.it',
        '+393609185022'
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        7,
        72::numeric(12,2),
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Pupolo Giacalone',
        'http://spicy-vanity.it',
        332.61,
        '01:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Regolo2@yahoo.com',
        '+397702981526'
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        9,
        130::numeric(12,2),
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Cloe Napoletano',
        'http://definite-yoke.org',
        317.281,
        '02:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Alceste.Solinas77@gmail.com',
        '+394153809289'
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        6,
        107::numeric(12,2),
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Igino Recchia',
        'https://torn-doe.net',
        273.938,
        '03:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Tabita33@gmail.com',
        '+395199395252'
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        4,
        137::numeric(12,2),
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Cosma Corti',
        'http://slim-notice.net',
        322.861,
        '07:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Donata.Micillo97@email.it',
        '+393512968890'
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        4,
        55::numeric(12,2),
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Alma Buonomo',
        'https://primary-shaw.org',
        261.252,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Loreno_Pecoraro84@libero.it',
        '+396186150482'
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        10,
        84::numeric(12,2),
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Bibiana Contu',
        'http://key-biscuit.it',
        260.911,
        '01:00:00'::time without time zone,
        '07:00:00'::time without time zone,
        'Simonetta_Militello77@gmail.com',
        '+399437870906'
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        8,
        142::numeric(12,2),
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Eliodoro Aiello',
        'https://authorized-mist.com',
        283.213,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Isabella_Cecchi@gmail.com',
        '+394290542416'
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        10,
        102::numeric(12,2),
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Sig. Deodato Bertaccini',
        'http://fragrant-crowd.org',
        273.187,
        '05:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Fedro70@libero.it',
        '+396832119432'
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        4,
        74::numeric(12,2),
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Giorgia Sorrentino',
        'http://same-profile.net',
        291.603,
        '06:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Grato.Giovannelli7@gmail.com',
        '+390909356692'
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        10,
        120::numeric(12,2),
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Publio Medici',
        'http://quintessential-champagne.it',
        280.879,
        '03:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Liborio.Marian@libero.it',
        '+394401001227'
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        1,
        74::numeric(12,2),
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Zaccaria Bisconti',
        'http://insistent-grey.com',
        331.313,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Emmerico_Brignone95@hotmail.com',
        '+394369924357'
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        4,
        53::numeric(12,2),
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Gigliola Di Mauro',
        'https://thirsty-sensitivity.org',
        304.127,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Tancredi39@libero.it',
        '+399666169296'
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        1,
        56::numeric(12,2),
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Plinio Pacifico',
        'https://fair-blessing.org',
        320.799,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Serafina43@yahoo.it',
        '+394317741274'
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        2,
        82::numeric(12,2),
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Maddalena Sannino',
        'https://grimy-management.com',
        295.697,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Ornella_Scardino90@libero.it',
        '+399871867126'
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        10,
        133::numeric(12,2),
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Lea Monaci',
        'https://colossal-financing.org',
        310.714,
        '01:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Camelia.Macchi@yahoo.it',
        '+395261305712'
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        8,
        127::numeric(12,2),
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Luigi Ferrari',
        'https://soggy-lark.org',
        319.766,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Cherubino5@gmail.com',
        '+399466476181'
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        10,
        118::numeric(12,2),
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Igor Kofler',
        'https://sorrowful-square.com',
        329.633,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Antioco44@libero.it',
        '+394953096935'
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        9,
        149::numeric(12,2),
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Dr. Massima Donato',
        'https://tubby-shin.com',
        271.456,
        '07:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Moira12@yahoo.com',
        '+395465870873'
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        2,
        56::numeric(12,2),
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Marco Rosset',
        'https://distinct-lunch.com',
        291.617,
        '09:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Filippo_Caiazza64@yahoo.it',
        '+393602790172'
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        7,
        68::numeric(12,2),
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Michela Fusco',
        'http://miserable-comfort.org',
        306.973,
        '09:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Nestore94@hotmail.com',
        '+394874616212'
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        9,
        63::numeric(12,2),
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Dr. Bruto De Lorenzo',
        'http://upbeat-niche.com',
        266.098,
        '09:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Oscar.Cosentino@gmail.com',
        '+397209467557'
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        6,
        60::numeric(12,2),
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Catena Padula',
        'https://oblong-king.org',
        267.508,
        '05:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Vittore96@email.it',
        '+396151620958'
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        4,
        61::numeric(12,2),
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Dr. Valente Gangemi',
        'http://rundown-tenant.org',
        261.736,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Ursicio_Traini@libero.it',
        '+396143867627'
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        10,
        108::numeric(12,2),
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Ubaldo Micheletti',
        'http://yearly-hydraulics.com',
        294.053,
        '03:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Evidio80@yahoo.com',
        '+398952211722'
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        4,
        71::numeric(12,2),
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Sig. Angela Laezza',
        'https://impassioned-speedboat.org',
        290.65,
        '08:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Tesifonte_DeCicco46@yahoo.it',
        '+390927094554'
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        6,
        71::numeric(12,2),
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Giobbe Nucci',
        'http://offensive-fiberglass.org',
        320.667,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Gandolfo74@yahoo.it',
        '+391604466841'
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        5,
        142::numeric(12,2),
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Valente Damiani',
        'https://illustrious-critic.it',
        270.948,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Fiorenzo90@yahoo.com',
        '+391446722568'
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        3,
        60::numeric(12,2),
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Gemma Agresta',
        'http://profitable-interconnection.it',
        269.537,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Mafalda.Vianello35@yahoo.it',
        '+399735196178'
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        1,
        99::numeric(12,2),
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Sabazio Ciavarella',
        'http://scarce-vinyl.it',
        267.7,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Greta.Mori0@yahoo.com',
        '+398555862882'
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        8,
        57::numeric(12,2),
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Antonella Moretti',
        'https://dirty-patience.net',
        268.334,
        '04:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Tarquinia63@yahoo.it',
        '+393086835173'
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        7,
        79::numeric(12,2),
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Gioacchina Lucarini',
        'http://functional-casserole.com',
        272.39,
        '05:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Sofia.Brunetti@email.it',
        '+390813493558'
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        4,
        95::numeric(12,2),
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Dr. Melissa Granato',
        'http://kindly-planet.org',
        338.788,
        '03:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Settimo86@libero.it',
        '+398384362478'
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        2,
        42::numeric(12,2),
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Dr. Bindo Visconti',
        'http://buttery-cheque.com',
        328.278,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Enimia.LaMonica19@yahoo.com',
        '+395490091257'
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        7,
        124::numeric(12,2),
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Dott. Venerando Sodano',
        'https://dry-relief.com',
        305.7,
        '01:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Priscilla.Palombi@hotmail.com',
        '+393113530782'
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        9,
        53::numeric(12,2),
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Prudenzia Parrino',
        'http://open-blind.it',
        316.996,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Ulrico_Raimondi@libero.it',
        '+395752936355'
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        8,
        83::numeric(12,2),
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Macaria Martino',
        'https://amusing-affiliate.com',
        261.195,
        '01:00:00'::time without time zone,
        '09:00:00'::time without time zone,
        'Bibiano.Nesti39@yahoo.it',
        '+390959427633'
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        5,
        53::numeric(12,2),
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Primo Di Pasquale',
        'http://pure-care.org',
        311.956,
        '09:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Nazzaro.DiFranco@yahoo.com',
        '+395879620039'
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        2,
        129::numeric(12,2),
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Priamo Di Giuseppe',
        'http://far-off-hobby.it',
        262.831,
        '03:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Adalfredo.Schillaci@gmail.com',
        '+395502663311'
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        6,
        43::numeric(12,2),
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Marita Tomaselli',
        'http://concerned-blackbird.com',
        321.703,
        '06:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Siricio12@yahoo.it',
        '+392529538804'
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        6,
        51::numeric(12,2),
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Zanita Cruciata',
        'http://even-phenotype.com',
        316.34,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Eustorgio.Pession@email.it',
        '+394547353549'
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        4,
        58::numeric(12,2),
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Mario Galluzzo',
        'http://burdensome-cabana.com',
        269.668,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Regolo_Ramella61@libero.it',
        '+390663124290'
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        4,
        78::numeric(12,2),
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Guendalina Tralli',
        'http://jubilant-output.net',
        300.547,
        '02:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Eligio_Cardini@libero.it',
        '+399579042320'
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        10,
        64::numeric(12,2),
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Amelia Campanella',
        'https://svelte-pineapple.it',
        335.209,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Reginaldo44@hotmail.com',
        '+398306154616'
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        7,
        109::numeric(12,2),
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Lorella Bartolucci',
        'http://low-shorts.it',
        279.111,
        '04:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Viscardo33@gmail.com',
        '+392023504667'
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        3,
        130::numeric(12,2),
        'Wittener Hütte',
        'Germany',
        'Gionata D''Argenio',
        'http://easy-signup.com',
        288.194,
        '03:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Rosmunda36@yahoo.it',
        '+396412493309'
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        3,
        45::numeric(12,2),
        'Hochjoch-Hospiz',
        'Austria',
        'Elda Perri',
        'https://handy-search.net',
        320.415,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Geminiano.Porcari51@hotmail.com',
        '+395009026296'
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        5,
        56::numeric(12,2),
        'Meilerhütte',
        'Germany',
        'Senofonte Fiorini',
        'http://long-dynamite.it',
        305.839,
        '03:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Ciriaco57@gmail.com',
        '+391779602805'
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        6,
        128::numeric(12,2),
        'Gaudeamushütte',
        'Austria',
        'Donatella Liotta',
        'http://outlying-ring.org',
        278.55,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Marino25@email.it',
        '+393301767454'
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        5,
        69::numeric(12,2),
        'Rheydter Hütte',
        'Germany',
        'Liborio Valsecchi',
        'https://grandiose-adviser.com',
        308.451,
        '08:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Narseo.Rambaldi@gmail.com',
        '+399555444071'
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        5,
        134::numeric(12,2),
        'Sektionshütte Krippen',
        'Germany',
        'Taddeo Pagliuca',
        'https://playful-fountain.it',
        287.481,
        '04:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Bonifacio_Bove10@hotmail.com',
        '+390391460446'
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        3,
        46::numeric(12,2),
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Benvenuto Liccardo',
        'https://empty-gain.net',
        329.893,
        '06:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Remondo.Perrotta@yahoo.it',
        '+395367669003'
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        8,
        93::numeric(12,2),
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Antero Colombo',
        'https://powerless-gear.com',
        268.447,
        '03:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Agesilao.Pandolfi25@libero.it',
        '+393679949269'
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        5,
        65::numeric(12,2),
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Polissena Tassone',
        'http://infantile-lack.org',
        283.612,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Evidio_Santarelli@email.it',
        '+391269127711'
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        2,
        127::numeric(12,2),
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Donna Mangione',
        'http://another-sorrel.org',
        261.408,
        '08:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Eliano66@email.it',
        '+393031012630'
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        3,
        112::numeric(12,2),
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Uriele Mazzocchi',
        'http://accurate-fulfillment.com',
        275.279,
        '05:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Eva55@libero.it',
        '+392081485002'
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        3,
        125::numeric(12,2),
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Porziano Carletti',
        'http://thick-juice.org',
        287.978,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'No.Bressan41@gmail.com',
        '+391603648413'
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        1,
        47::numeric(12,2),
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Valeria Paganelli',
        'https://lone-shift.net',
        286.913,
        '02:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Ianira.Piccolo@libero.it',
        '+392786355672'
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        2,
        101::numeric(12,2),
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Gabriele Minelli',
        'https://famous-magazine.com',
        289.158,
        '09:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Clemenzia.Falcioni87@hotmail.com',
        '+391769922619'
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        5,
        75::numeric(12,2),
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Antonia Miglio',
        'http://solid-climb.org',
        308.784,
        '06:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Cantidio13@yahoo.com',
        '+391786356557'
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        4,
        143::numeric(12,2),
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Teresa Ferracuti',
        'https://ordinary-linen.com',
        289.987,
        '08:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Vincenzo_Renzi@email.it',
        '+392466521092'
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        9,
        44::numeric(12,2),
        'Dobra voda',
        'Suvobor, Serbia',
        'Ludovica Quinto',
        'https://profitable-neighbour.org',
        317.339,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Catullo_Mascolo@yahoo.com',
        '+392119410746'
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        1,
        122::numeric(12,2),
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Marzia Gaudiano',
        'https://false-suck.com',
        333.883,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Vilfredo40@yahoo.com',
        '+396371208124'
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        7,
        113::numeric(12,2),
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Antonella Cesaretti',
        'http://flowery-tenor.com',
        302,
        '01:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Narciso_Baldo@hotmail.com',
        '+390131173477'
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        6,
        70::numeric(12,2),
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Ulfa Ramella',
        'http://sleepy-enigma.org',
        290.346,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Aladino76@libero.it',
        '+394213280518'
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        1,
        82::numeric(12,2),
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Elisabetta Carella',
        'http://wonderful-centurion.com',
        298.14,
        '07:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Alessandro_DiDonato89@libero.it',
        '+395629882897'
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        4,
        70::numeric(12,2),
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Pollione Papapietro',
        'http://regal-silence.net',
        290.254,
        '05:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Arcibaldo70@hotmail.com',
        '+397373834090'
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        5,
        38::numeric(12,2),
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Olimpia Borgia',
        'https://busy-wrist.org',
        279.145,
        '04:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Averardo.Aprile47@libero.it',
        '+395987766692'
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        3,
        113::numeric(12,2),
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Massimo Trombetta',
        'http://proud-noise.com',
        294.868,
        '05:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Altea.Stella32@yahoo.it',
        '+396156890017'
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        7,
        130::numeric(12,2),
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Carla Toscano',
        'https://utilized-pillar.org',
        260.562,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Amauri72@email.it',
        '+391394568788'
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        9,
        69::numeric(12,2),
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Raimondo Cerutti',
        'http://open-pathway.net',
        335.573,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Settimo.Talarico50@gmail.com',
        '+397005973605'
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        2,
        106::numeric(12,2),
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Desiderata Baldacci',
        'http://serious-accordance.net',
        301.135,
        '01:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Uberto_Ancona42@hotmail.com',
        '+392799267394'
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '8 Piazza Orsino, Sesto Abibo laziale, Italy',
        'Sesto Abibo laziale',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        55,
        '2 Via Merola, Giuliana sardo, Italy',
        'Giuliana sardo',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        37,
        '59 Rotonda Vincenza, Sesto Remo umbro, Italy',
        'Sesto Remo umbro',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        211,
        '59 Contrada Pizzitola, Borgo Doriano, Italy',
        'Borgo Doriano',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        161,
        '04 Contrada Perego, Quarto Efrem, Italy',
        'Quarto Efrem',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        216,
        '0 Incrocio Lipari, Basilia nell''emilia, Italy',
        'Basilia nell''emilia',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        257,
        '4 Piazza Boccia, Settimo Ataleo, Italy',
        'Settimo Ataleo',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        98,
        '70 Contrada Elide, Borgo Samuele ligure, Italy',
        'Borgo Samuele ligure',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        236,
        '75 Strada Grande, Cleo sardo, Italy',
        'Cleo sardo',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        64,
        '63 Contrada Guido, Selene lido, Italy',
        'Selene lido',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        293,
        '6 Strada Ferroni, Settimo Amadeo ligure, Italy',
        'Settimo Amadeo ligure',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        117,
        '57 Via Aniceto, Rubino sardo, Italy',
        'Rubino sardo',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        87,
        '0 Borgo Ottonello, Quarto Terenzio veneto, Italy',
        'Quarto Terenzio veneto',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        243,
        '593 Incrocio Bertani, Vichi lido, Italy',
        'Vichi lido',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        259,
        '8 Via Angela, Ferrero lido, Italy',
        'Ferrero lido',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        287,
        '552 Borgo Scalia, Borgo Natale, Italy',
        'Borgo Natale',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        102,
        '03 Piazza Gangemi, Sesto Giulio, Italy',
        'Sesto Giulio',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        44,
        '340 Strada Carta, Settimo Gaudenzia sardo, Italy',
        'Settimo Gaudenzia sardo',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        253,
        '6 Incrocio Barillà, Bacci a mare, Italy',
        'Bacci a mare',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        90,
        '19 Rotonda Stefano, Demostene calabro, Italy',
        'Demostene calabro',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        31,
        '059 Via Zoe, Demontis del friuli, Italy',
        'Demontis del friuli',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        202,
        '8 Incrocio Timoteo, Artemisa umbro, Italy',
        'Artemisa umbro',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '04 Rotonda Gherardo, San Onesta, Italy',
        'San Onesta',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        70,
        '7 Borgo Papini, Settimo Teodoro, Italy',
        'Settimo Teodoro',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        289,
        '013 Incrocio Speranza, Settimo Magno, Italy',
        'Settimo Magno',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        184,
        '29 Via Marianna, Fleano calabro, Italy',
        'Fleano calabro',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        47,
        '563 Strada Sorbello, Sesto Cuniberto, Italy',
        'Sesto Cuniberto',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        184,
        '52 Borgo Aurelio, Ruggero lido, Italy',
        'Ruggero lido',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        51,
        '89 Via Nilde, Borgo Ausilia, Italy',
        'Borgo Ausilia',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        298,
        '978 Borgo Clemente, Gregori a mare, Italy',
        'Gregori a mare',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        76,
        '7 Contrada Mia, Colantuono salentino, Italy',
        'Colantuono salentino',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        126,
        '613 Rotonda Napoletano, Borgo Ionne, Italy',
        'Borgo Ionne',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        277,
        '04 Incrocio Gundelinda, Accardi lido, Italy',
        'Accardi lido',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '154 Incrocio Cordelia, Troisi veneto, Italy',
        'Troisi veneto',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        284,
        '535 Via Marcello, Settimo Acrisio, Italy',
        'Settimo Acrisio',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        63,
        '46 Via Silvia, Lazzari lido, Italy',
        'Lazzari lido',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        212,
        '9 Rotonda Fernanda, Quarto Sapiente nell''emilia, Italy',
        'Quarto Sapiente nell''emilia',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        257,
        '55 Borgo Alarico, Gaudenzio sardo, Italy',
        'Gaudenzio sardo',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        288,
        '61 Borgo Alfredo, Isidoro sardo, Italy',
        'Isidoro sardo',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        28,
        '687 Via Birino, Giacalone veneto, Italy',
        'Giacalone veneto',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '70 Borgo Cecchini, Borgo Uriele nell''emilia, Italy',
        'Borgo Uriele nell''emilia',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        179,
        '20 Piazza Ventura, Quarto Cassandra veneto, Italy',
        'Quarto Cassandra veneto',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        291,
        '0 Borgo Remondo, Quarto Norberto, Italy',
        'Quarto Norberto',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        162,
        '1 Borgo Carrozzo, Gatto calabro, Italy',
        'Gatto calabro',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        85,
        '1 Incrocio Campo, Quarto Urdino, Italy',
        'Quarto Urdino',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        201,
        '58 Contrada Cascone, Quarto Adelasia, Italy',
        'Quarto Adelasia',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        295,
        '7 Contrada Lino, Salemi a mare, Italy',
        'Salemi a mare',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        55,
        '3 Strada Tedde, Ferrando ligure, Italy',
        'Ferrando ligure',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        149,
        '82 Contrada Chiara, Sesto Reginaldo, Italy',
        'Sesto Reginaldo',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        279,
        '96 Incrocio Poggio, Borgo Agabio, Italy',
        'Borgo Agabio',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        209,
        '13 Piazza Pisu, De Lorenzo umbro, Italy',
        'De Lorenzo umbro',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '420 Rotonda Geremia, Quarto Tristano, Italy',
        'Quarto Tristano',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        180,
        '4 Rotonda Dulina, Calogero veneto, Italy',
        'Calogero veneto',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '8 Contrada Casali, Riccardo calabro, Italy',
        'Riccardo calabro',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        135,
        '081 Strada Benedetto, San Ilia, Italy',
        'San Ilia',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        185,
        '7 Rotonda Abbondanzio, Quarto Bertoldo umbro, Italy',
        'Quarto Bertoldo umbro',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        178,
        '2 Rotonda Ross, San Rino salentino, Italy',
        'San Rino salentino',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        101,
        '7 Piazza Gennaro, Borgo Ezio, Italy',
        'Borgo Ezio',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        138,
        '4 Rotonda Ferrarotti, Sesto Corrado calabro, Italy',
        'Sesto Corrado calabro',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        133,
        '39 Strada Toti, Quarto Canziano, Italy',
        'Quarto Canziano',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        274,
        '9 Strada Gualberto, San Lorenzo ligure, Italy',
        'San Lorenzo ligure',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        236,
        '190 Strada Ausilia, Bentivoglio laziale, Italy',
        'Bentivoglio laziale',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        187,
        '90 Borgo Pillitteri, Quarto Lucrezia, Italy',
        'Quarto Lucrezia',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        242,
        '33 Piazza Tavani, Settimo Roberta sardo, Italy',
        'Settimo Roberta sardo',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        183,
        '9 Borgo Pirrone, Sesto Aleandro laziale, Italy',
        'Sesto Aleandro laziale',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        49,
        '97 Via Palmazio, Borgo Vincenzo, Italy',
        'Borgo Vincenzo',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        193,
        '2 Incrocio Bardomiano, San Ido, Italy',
        'San Ido',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        180,
        '3 Strada Prisco, Quarto Elpidio nell''emilia, Italy',
        'Quarto Elpidio nell''emilia',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        76,
        '485 Borgo Brigida, Godeberta salentino, Italy',
        'Godeberta salentino',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '0 Incrocio Gaudenzio, Giglio ligure, Italy',
        'Giglio ligure',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        268,
        '5 Via Cristoforo, Di Bella lido, Italy',
        'Di Bella lido',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        236,
        '267 Contrada Ansovino, Lelli laziale, Italy',
        'Lelli laziale',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        230,
        '55 Strada Elita, Martelli laziale, Italy',
        'Martelli laziale',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        290,
        '693 Borgo Polifemo, Luchetti sardo, Italy',
        'Luchetti sardo',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        290,
        '5 Borgo Gianpietro, San Desiderata, Italy',
        'San Desiderata',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        263,
        '549 Rotonda Melanio, Clodomiro nell''emilia, Italy',
        'Clodomiro nell''emilia',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        81,
        '488 Via Caputo, Ulisse umbro, Italy',
        'Ulisse umbro',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        154,
        '4 Incrocio Palmazio, San Apollo, Italy',
        'San Apollo',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        115,
        '43 Contrada Righi, Quarto Abele, Italy',
        'Quarto Abele',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        95,
        '3 Incrocio Carmela, Sesto Paterniano, Italy',
        'Sesto Paterniano',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        161,
        '1 Piazza Venerio, Romana ligure, Italy',
        'Romana ligure',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        239,
        '524 Contrada Forte, Settimo Ivan, Italy',
        'Settimo Ivan',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        175,
        '031 Strada Alvaro, Costantin a mare, Italy',
        'Costantin a mare',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        162,
        '7 Borgo Anna, Eliana veneto, Italy',
        'Eliana veneto',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        236,
        '10 Via Tesi, Gherardo umbro, Italy',
        'Gherardo umbro',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        186,
        '247 Piazza Ferranti, Tabita laziale, Italy',
        'Tabita laziale',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        170,
        '076 Rotonda Liberato, Fioravanti umbro, Italy',
        'Fioravanti umbro',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        192,
        '849 Strada Bove, Di Tommaso calabro, Italy',
        'Di Tommaso calabro',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        215,
        '4 Strada Maggio, Sesto Paciano, Italy',
        'Sesto Paciano',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        225,
        '68 Incrocio Sebastiano, Bindi terme, Italy',
        'Bindi terme',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        237,
        '347 Strada Ferretti, Borgo Giovanni, Italy',
        'Borgo Giovanni',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        251,
        '59 Contrada Niceforo, Guido nell''emilia, Italy',
        'Guido nell''emilia',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        142,
        '92 Contrada Spizzirri, Licia nell''emilia, Italy',
        'Licia nell''emilia',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        204,
        '00 Strada Malizia, Sesto Urbano nell''emilia, Italy',
        'Sesto Urbano nell''emilia',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        73,
        '981 Incrocio Gruber, Palmisani nell''emilia, Italy',
        'Palmisani nell''emilia',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        233,
        '82 Piazza Donda, San Lorena, Italy',
        'San Lorena',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        112,
        '403 Piazza Gilda, Taziano laziale, Italy',
        'Taziano laziale',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        135,
        '840 Borgo Gabriele, Vivaldo a mare, Italy',
        'Vivaldo a mare',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        151,
        '27 Incrocio Sarti, Sesto Tulliano, Italy',
        'Sesto Tulliano',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        70,
        '2 Via Fadda, Settimo Urbano, Italy',
        'Settimo Urbano',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        121,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        130,
        '323 Strada Artemisa, Ricciardi nell''emilia, Italy',
        'Ricciardi nell''emilia',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        127,
        '0 Via Fidenzio, Rapisarda umbro, Italy',
        'Rapisarda umbro',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        291,
        '89 Strada Cuomo, Nerea terme, Italy',
        'Nerea terme',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        279,
        '7 Borgo Ondina, Tarso veneto, Italy',
        'Tarso veneto',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        57,
        '95 Incrocio Ancona, Sanfilippo salentino, Italy',
        'Sanfilippo salentino',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        291,
        '74 Rotonda Rigoni, Settimo Apollinare terme, Italy',
        'Settimo Apollinare terme',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        154,
        '4 Incrocio Corradi, San Decimo, Italy',
        'San Decimo',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        100,
        '9 Rotonda Re, Bresciani salentino, Italy',
        'Bresciani salentino',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        93,
        '20 Strada Abbondanzio, Cerri laziale, Italy',
        'Cerri laziale',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        109,
        '9 Piazza Milani, Borgo Raffaele umbro, Italy',
        'Borgo Raffaele umbro',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        299,
        '63 Via Belli, Quarto Arduino, Italy',
        'Quarto Arduino',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        42,
        '0 Strada Bacci, Borgo Abelardo a mare, Italy',
        'Borgo Abelardo a mare',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        110,
        '5 Piazza Fanara, Borgo Verulo, Italy',
        'Borgo Verulo',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        292,
        '7 Incrocio Fernanda, Settimo Demostene salentino, Italy',
        'Settimo Demostene salentino',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        80,
        '85 Borgo Fedro, Settimo Selvaggia, Italy',
        'Settimo Selvaggia',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        64,
        '88 Borgo Mancino, Borgo Lodovica, Italy',
        'Borgo Lodovica',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        126,
        '45 Rotonda Alcina, Giacinto calabro, Italy',
        'Giacinto calabro',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        258,
        '7 Strada Ventura, San Zama, Italy',
        'San Zama',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        163,
        '904 Strada Dante, Quarto Calogera, Italy',
        'Quarto Calogera',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        148,
        '9 Via Adalfredo, Sesto Gennaro lido, Italy',
        'Sesto Gennaro lido',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        275,
        '4 Incrocio Alessandrini, San Giovanni salentino, Italy',
        'San Giovanni salentino',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        84,
        '435 Borgo Casimira, Eginardo terme, Italy',
        'Eginardo terme',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        81,
        '41 Strada Abbondanzio, Cuzzocrea del friuli, Italy',
        'Cuzzocrea del friuli',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        289,
        '2 Piazza Cruciata, Sesto Alma, Italy',
        'Sesto Alma',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        224,
        '5 Piazza Iginia, Siri ligure, Italy',
        'Siri ligure',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '09 Incrocio Celi, Pecorella ligure, Italy',
        'Pecorella ligure',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        119,
        '122 Incrocio Parrinello, Quarto Pierangelo, Italy',
        'Quarto Pierangelo',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        278,
        '142 Piazza Polidori, Settimo Gaetano terme, Italy',
        'Settimo Gaetano terme',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '3 Contrada Gioia, San Gherardo, Italy',
        'San Gherardo',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '843 Piazza Costantini, Gianfranco sardo, Italy',
        'Gianfranco sardo',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        254,
        '7 Incrocio Fedro, Amato laziale, Italy',
        'Amato laziale',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        34,
        '01 Piazza Ermini, Placido laziale, Italy',
        'Placido laziale',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        58,
        '5 Borgo Tassi, San Folco del friuli, Italy',
        'San Folco del friuli',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        286,
        '583 Contrada De Vito, Rosset terme, Italy',
        'Rosset terme',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        172,
        '7 Strada Gregori, Quarto Enrico, Italy',
        'Quarto Enrico',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '62 Piazza Lieto, Quarto Gaglioffo, Italy',
        'Quarto Gaglioffo',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '151 Incrocio Fidenzio, Salvatore umbro, Italy',
        'Salvatore umbro',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        161,
        '184 Via Serviliano, Deodata calabro, Italy',
        'Deodata calabro',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '924 Borgo Divo, De Bonis del friuli, Italy',
        'De Bonis del friuli',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        128,
        '45 Borgo Gianpaolo, Petronilla sardo, Italy',
        'Petronilla sardo',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        257,
        '9 Incrocio Elena, Borgo Elogio umbro, Italy',
        'Borgo Elogio umbro',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        89,
        '3 Strada Maltese, Settimo Eustorgio, Italy',
        'Settimo Eustorgio',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        279,
        '84 Incrocio Franzè, Di Bella salentino, Italy',
        'Di Bella salentino',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        300,
        '0 Piazza Venerio, Raffaele salentino, Italy',
        'Raffaele salentino',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        261,
        '28 Borgo Acquistapace, Frau umbro, Italy',
        'Frau umbro',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        295,
        '04 Via Frontiniano, Ciccarelli ligure, Italy',
        'Ciccarelli ligure',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        278,
        '6 Borgo Cremona, Bernabei sardo, Italy',
        'Bernabei sardo',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        200,
        '40 Contrada Ludovico, Sesto Abele, Italy',
        'Sesto Abele',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        181,
        '33 Strada Maffeo, Mautone laziale, Italy',
        'Mautone laziale',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        144,
        '8 Incrocio Griselda, Borgo Adamo calabro, Italy',
        'Borgo Adamo calabro',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        66,
        '48 Strada Bedini, Adele umbro, Italy',
        'Adele umbro',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        136,
        '49 Rotonda Monteleone, Saturniano veneto, Italy',
        'Saturniano veneto',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        135,
        '3 Borgo Amico, Camilli ligure, Italy',
        'Camilli ligure',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        123,
        '404 Piazza Fabiano, Settimo Palmira, Italy',
        'Settimo Palmira',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        193,
        '346 Incrocio Gordiano, Valentino terme, Italy',
        'Valentino terme',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        289,
        '80 Piazza Migliaccio, Borgo Egeo terme, Italy',
        'Borgo Egeo terme',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        128,
        '0 Rotonda De Maio, Luongo del friuli, Italy',
        'Luongo del friuli',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        211,
        '43 Piazza Giuseppe, Bianco salentino, Italy',
        'Bianco salentino',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        214,
        '98 Piazza Debora, San Amaranto, Italy',
        'San Amaranto',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        249,
        '2 Rotonda Sveva, Cruciata terme, Italy',
        'Cruciata terme',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        77,
        '05 Via Misaele, Amabile ligure, Italy',
        'Amabile ligure',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        162,
        '21 Borgo Tullia, Settimo Bassilla, Italy',
        'Settimo Bassilla',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        118,
        '1 Contrada Lori, Bonazzi sardo, Italy',
        'Bonazzi sardo',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        188,
        '5 Contrada Pomponio, Sesto Ignazio del friuli, Italy',
        'Sesto Ignazio del friuli',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '99 Contrada D''Onofrio, Borgo Aronne, Italy',
        'Borgo Aronne',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        74,
        '82 Incrocio Zama, Di Michele del friuli, Italy',
        'Di Michele del friuli',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        233,
        '30 Piazza Sabino, Graziano calabro, Italy',
        'Graziano calabro',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        246,
        '9 Strada Trombetta, D''Anna del friuli, Italy',
        'D''Anna del friuli',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        130,
        '97 Via Pezzella, Settimo Sinesio terme, Italy',
        'Settimo Sinesio terme',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        284,
        '0 Borgo Abramo, Di Marino sardo, Italy',
        'Di Marino sardo',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        278,
        '28 Incrocio Rigoni, Francesco del friuli, Italy',
        'Francesco del friuli',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        96,
        '687 Piazza Cappello, Quarto Verecondo, Italy',
        'Quarto Verecondo',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        144,
        '600 Strada Gaudenzio, Lo Giudice sardo, Italy',
        'Lo Giudice sardo',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        114,
        '949 Via Franzè, Quarto Veneranda, Italy',
        'Quarto Veneranda',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        133,
        '85 Rotonda Fedele, Fabbro terme, Italy',
        'Fabbro terme',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        174,
        '85 Incrocio Loreno, Quarto Aristofane calabro, Italy',
        'Quarto Aristofane calabro',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        234,
        '902 Rotonda Camillo, Borgo Carla calabro, Italy',
        'Borgo Carla calabro',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        74,
        '710 Borgo Silvestrini, Borgo Gottardo, Italy',
        'Borgo Gottardo',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        185,
        '63 Contrada Ulpiano, Michela laziale, Italy',
        'Michela laziale',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        25,
        '22 Borgo Santori, Ermelinda a mare, Italy',
        'Ermelinda a mare',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        157,
        '90 Contrada Michela, Franzè laziale, Italy',
        'Franzè laziale',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '263 Via Auberto, Quarto Altea nell''emilia, Italy',
        'Quarto Altea nell''emilia',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        67,
        '77 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        242,
        '6 Piazza Ancona, San Mauro, Italy',
        'San Mauro',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        237,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        115,
        '69 Contrada De Maio, Settimo Delfina, Italy',
        'Settimo Delfina',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        214,
        '3 Incrocio Massa, Quarto Nicodemo laziale, Italy',
        'Quarto Nicodemo laziale',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        45,
        '45 Strada Gennaro, Leonida del friuli, Italy',
        'Leonida del friuli',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        209,
        '1 Piazza Matteo, Quarto Fiammetta, Italy',
        'Quarto Fiammetta',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        232,
        '7 Incrocio Leo, Sesto Carmela, Italy',
        'Sesto Carmela',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        124,
        '49 Piazza Monterosso, Sesto Dacio salentino, Italy',
        'Sesto Dacio salentino',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        289,
        '73 Strada Apollina, Rosanna calabro, Italy',
        'Rosanna calabro',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        79,
        '8 Contrada Simone, Borgo Ranolfo salentino, Italy',
        'Borgo Ranolfo salentino',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        125,
        '08 Contrada Valentina, Quarto Franco laziale, Italy',
        'Quarto Franco laziale',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        227,
        '07 Via Luana, Volpi a mare, Italy',
        'Volpi a mare',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        227,
        '7 Via Vanda, Fucci lido, Italy',
        'Fucci lido',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        217,
        '6 Via Annamaria, Ippolito nell''emilia, Italy',
        'Ippolito nell''emilia',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        146,
        '60 Contrada Ilenia, Borgo Bartolomeo, Italy',
        'Borgo Bartolomeo',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        282,
        '3 Borgo Liberati, Di Giovanni lido, Italy',
        'Di Giovanni lido',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        215,
        '37 Contrada Sini, Quarto Lisandro, Italy',
        'Quarto Lisandro',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        259,
        '86 Rotonda Manicone, Lauriano veneto, Italy',
        'Lauriano veneto',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '3 Via Sirio, Quarto Vladimiro a mare, Italy',
        'Quarto Vladimiro a mare',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        101,
        '9 Piazza Bonazzi, Borgo Filomeno, Italy',
        'Borgo Filomeno',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        78,
        '142 Contrada Ponzio, Da Rold umbro, Italy',
        'Da Rold umbro',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        176,
        '11 Piazza Calcedonio, Settimo Icilio, Italy',
        'Settimo Icilio',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        67,
        '244 Via Placido, Sanfilippo ligure, Italy',
        'Sanfilippo ligure',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        199,
        '7 Incrocio Del Bianco, Boris terme, Italy',
        'Boris terme',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        191,
        '359 Rotonda Ancilla, Quarto Riccardo, Italy',
        'Quarto Riccardo',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        97,
        '9 Strada Perrotta, Quarto Gerasimo, Italy',
        'Quarto Gerasimo',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        201,
        '6 Strada Artemisa, Quarto Marcello, Italy',
        'Quarto Marcello',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        43,
        '4 Via Fabbricatore, Quarto Loretta sardo, Italy',
        'Quarto Loretta sardo',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '1 Incrocio Adone, Sesto Democrito, Italy',
        'Sesto Democrito',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        55,
        '4 Piazza Carvelli, San Anatolia, Italy',
        'San Anatolia',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        26,
        '75 Via Munaro, Emilia terme, Italy',
        'Emilia terme',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        63,
        '643 Contrada Marras, Adalgiso lido, Italy',
        'Adalgiso lido',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        76,
        '6 Borgo Eraclide, Monaco veneto, Italy',
        'Monaco veneto',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        239,
        '1 Rotonda Vindonio, Iona ligure, Italy',
        'Iona ligure',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        209,
        '20 Borgo Filippo, Ninfa lido, Italy',
        'Ninfa lido',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        127,
        '63 Incrocio Bortoluzzi, Sesto Menardo calabro, Italy',
        'Sesto Menardo calabro',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        34,
        '70 Rotonda Marani, Quarto Iorio calabro, Italy',
        'Quarto Iorio calabro',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '69 Rotonda Ultimo, Zanella calabro, Italy',
        'Zanella calabro',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        117,
        '1 Borgo Imelda, Manno laziale, Italy',
        'Manno laziale',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        254,
        '95 Borgo Ragone, San Adina sardo, Italy',
        'San Adina sardo',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        154,
        '00 Rotonda Icaro, De Giorgio calabro, Italy',
        'De Giorgio calabro',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        46,
        '24 Incrocio Aidano, Catanzaro sardo, Italy',
        'Catanzaro sardo',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        263,
        '916 Via Emilia, Patrone lido, Italy',
        'Patrone lido',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        299,
        '799 Piazza Schiavi, Devota del friuli, Italy',
        'Devota del friuli',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        31,
        '3 Via Liberio, Quarto Amabile, Italy',
        'Quarto Amabile',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        152,
        '45 Piazza Bianchetti, Impellizzeri terme, Italy',
        'Impellizzeri terme',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        194,
        '846 Strada Iona, Quarto Leo, Italy',
        'Quarto Leo',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        168,
        '894 Via Vailati, Borgo Vinicio terme, Italy',
        'Borgo Vinicio terme',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        166,
        '78 Via Migliaccio, Ferro calabro, Italy',
        'Ferro calabro',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        221,
        '65 Incrocio Mastrogiacomo, San Onorino, Italy',
        'San Onorino',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        300,
        '924 Incrocio Marita, Elvia del friuli, Italy',
        'Elvia del friuli',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        150,
        '4 Rotonda Mirabella, Settimo Tesauro, Italy',
        'Settimo Tesauro',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        42,
        '899 Incrocio Ambrogio, Nunziata terme, Italy',
        'Nunziata terme',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        253,
        '08 Rotonda Arminio, Valentini calabro, Italy',
        'Valentini calabro',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        112,
        '06 Piazza Libero, Sesto Adriano a mare, Italy',
        'Sesto Adriano a mare',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        150,
        '7 Rotonda Indro, Loddo terme, Italy',
        'Loddo terme',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        165,
        '6 Rotonda Tomei, Demontis del friuli, Italy',
        'Demontis del friuli',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        273,
        '29 Rotonda Aloisio, Marchetti lido, Italy',
        'Marchetti lido',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        275,
        '618 Contrada Ambrosino, San Stiliano, Italy',
        'San Stiliano',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        96,
        '201 Incrocio Palombo, Sesto Piersilvio del friuli, Italy',
        'Sesto Piersilvio del friuli',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        225,
        '77 Borgo De Bonis, Bergamasco veneto, Italy',
        'Bergamasco veneto',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        45,
        '387 Borgo Ida, Pession veneto, Italy',
        'Pession veneto',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        109,
        '073 Contrada Pedrazzini, Borgo Archippo del friuli, Italy',
        'Borgo Archippo del friuli',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        146,
        '3 Via Gagliano, Astrid lido, Italy',
        'Astrid lido',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        292,
        '189 Contrada Capponi, Rosamunda salentino, Italy',
        'Rosamunda salentino',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '8 Via Flore, Visintin umbro, Italy',
        'Visintin umbro',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        199,
        '00 Incrocio Vulpiano, Quarto Nicol� nell''emilia, Italy',
        'Quarto Nicol� nell''emilia',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        251,
        '59 Rotonda Menozzi, Settimo Camilla lido, Italy',
        'Settimo Camilla lido',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        247,
        '88 Borgo Ansaldo, San Diego, Italy',
        'San Diego',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        197,
        '606 Via Glauco, Borgo Antonia, Italy',
        'Borgo Antonia',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        49,
        '4 Rotonda Fatima, Cusumano laziale, Italy',
        'Cusumano laziale',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        266,
        '0 Rotonda Ester, Bartoli veneto, Italy',
        'Bartoli veneto',
        'Italy',
        'Matera',
        ''
      );
    
  