--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$ai4UmthTbMezQ7M3gKHiIeskqyz.04SF5qOPMDImSE6/d4eHMSgPK',
    'Antonio',
    'Battipaglia',
    2,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$ygte8x6d4giliFTLg3GesONXESgr5c2hS5QsR4f/URjYEHvtG8qUe',
    'Erfan',
    'Gholami',
    4,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$EUp5LgYnTbcFo5RZom13cetqyX0nh1tjZwa5UQs.GNObCLfW/ssrq',
    'Laura',
    'Zurru',
    5,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$XE3LSytdq9hHGCm8jwTkBua9Myu2oWzO0yAOhCjeCoy/v5mf/Nyaa',
    'German',
    'Gorodnev',
    0,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$V9522.yIlsJjbixy/5PUB.8IZL1LGT/EwpbbErwJEN/p0Ps3HYW0u',
    'vincenzo',
    'Sagristano',
    3,
    true,
    true
  );
  

      CREATE OR REPLACE FUNCTION public.insert_hike(
        user_id integer,
        title varchar,
        difficulty integer,
        gpx_path varchar,
        country varchar,
        region varchar,
        province varchar,
        city varchar,
        length numeric(12,2),
        ascent numeric(12,2),
        expected_time integer,
        description varchar,
        pictures jsonb,
        start_point jsonb,
        end_point jsonb,
        reference_points jsonb
      )  RETURNS VOID AS
      $func$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hike"(
        2,
        'Amprimo',
        2,
        '/static/gpx/Amprimo.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        0.7,
        7.1,
        80,
        'Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.',
        '["/static/images/3.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.165559804,"lat":45.102780737}'::jsonb,
        '{"name":"End Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.14299586,"lat":45.099887898}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":7.164360252,"lat":45.102912389,"altitude":1256.852},{"name":"Ref Point 2","address":"","lon":7.158207147,"lat":45.102886551,"altitude":1283.605}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello Chateau Beaulard - Cotolivier - Vazon',
        1,
        '/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Beaulard',
        3.9,
        21.1,
        200,
        'Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.',
        '["/static/images/2.jpg"]'::jsonb,
        '{"name":"Start Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.772358,"lat":45.03205}'::jsonb,
        '{"name":"End Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.77234,"lat":45.032238}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago Bianco',
        2,
        '/static/gpx/Lago Bianco.gpx',
        'Francia',
        'Auvergne-Rhone-Alpes',
        'Savoia',
        'Val-Cenis',
        20.3,
        26.7,
        210,
        'Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.

La diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.

La Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.

Si può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.',
        '["/static/images/1.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945681,"lat":45.223814}'::jsonb,
        '{"name":"End Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945581,"lat":45.224058}'::jsonb,
        '[{"name":"fountain","address":"","lon":6.940291,"lat":45.222543,"altitude":2027},{"name":"Peak","address":"","lon":6.937204,"lat":45.215867,"altitude":2131}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Alte Langhe Settentrionali - Cossano Belbo',
        2,
        '/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cossano Belbo',
        6.3,
        28.8,
        200,
        'Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.
Si svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.
Si imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.
Inizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.
Percorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. 
Seguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. 
Si procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante',
        '["/static/images/4.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199049,"lat":44.670379}'::jsonb,
        '{"name":"End Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199052,"lat":44.670377}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":8.214142,"lat":44.674545,"altitude":482.526},{"name":"Ref Point 2","address":"","lon":8.197792,"lat":44.668772,"altitude":242.585}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'La pieve romanica di Piesenzana e la valle delle tartufaie',
        2,
        '/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montechiaro d''Asti',
        9.1,
        25.6,
        225,
        'Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. 
Circa 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. 
In regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. 
A Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). 
Contemporaneamente i ristoranti della zona propongono piatti a base di tartufi',
        '["/static/images/5.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.113224,"lat":45.007605}'::jsonb,
        '{"name":"End Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.11358,"lat":45.007557}'::jsonb,
        NULL
      );
    
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2),
        working_time_start time without time zone,
        working_time_end time without time zone,
        email varchar,
        phone_number varchar,
        pictures jsonb
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber",
      "pictures"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number,
      pictures
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        10,
        43::numeric(12,2),
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Fulvia Franceschi',
        'http://indelible-predecessor.net',
        290.189,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Lodovico_Ippolito96@libero.it',
        '+394289408814',
        '["/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg","/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg","/static/images/cdcd47a9-72e1-492a-9a85-787e0b7d181d.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        2,
        114::numeric(12,2),
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Manlio Mangano',
        'http://wary-doe.net',
        272.085,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Romina_Mercuri75@email.it',
        '+390161902583',
        '["/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg","/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        4,
        38::numeric(12,2),
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Veridiana Filippi',
        'http://scrawny-asterisk.it',
        299.655,
        '05:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Severo_Sartori@yahoo.it',
        '+399008176872',
        '["/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/a2c5761b-4ca4-45be-9a6f-a77de475fc43.jpg","/static/images/cdcd47a9-72e1-492a-9a85-787e0b7d181d.jpg","/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        2,
        138::numeric(12,2),
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Ilva Palla',
        'http://corrupt-cellar.org',
        321.911,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Salom94@libero.it',
        '+390754407102',
        '["/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        8,
        107::numeric(12,2),
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Gianmaria Forlani',
        'http://unripe-jury.it',
        283.417,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Alfonsa_Consiglio@gmail.com',
        '+397536729585',
        '["/static/images/8b47b9e0-494f-45f5-b233-36d6fb3cab34.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/b0550f26-408c-46a1-b27a-178373bf2725.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        9,
        126::numeric(12,2),
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Gineto Aquino',
        'http://frizzy-lycra.com',
        261.313,
        '08:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Adelmo.DErrico@libero.it',
        '+390300960119',
        '["/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg","/static/images/a2c5761b-4ca4-45be-9a6f-a77de475fc43.jpg","/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        6,
        53::numeric(12,2),
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Dr. Delinda Mollica',
        'http://lined-optimist.org',
        275.029,
        '04:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Tirone92@yahoo.it',
        '+399602926577',
        '["/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg","/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        3,
        142::numeric(12,2),
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Cornelio Staffieri',
        'http://spiffy-dickey.it',
        267.8,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Fleano.Romanini13@libero.it',
        '+393952367557',
        '["/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg","/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        8,
        62::numeric(12,2),
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Ulstano Grosso',
        'https://downright-go-kart.org',
        326.5,
        '04:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Paride.Ostuni64@yahoo.it',
        '+393925074440',
        '["/static/images/a2c5761b-4ca4-45be-9a6f-a77de475fc43.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        3,
        75::numeric(12,2),
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Danilo Iannucci',
        'http://growing-jailhouse.it',
        262.997,
        '07:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Paterniano73@gmail.com',
        '+393232758229',
        '["/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        3,
        45::numeric(12,2),
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Tarso Lugli',
        'https://legal-sensor.it',
        321.683,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Feliciano98@email.it',
        '+394279751726',
        '["/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg","/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg","/static/images/ec95ecdf-197e-4ec0-9c95-b94d8afe7e3c.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg","/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        1,
        122::numeric(12,2),
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Cora Anelli',
        'https://worst-complex.net',
        275.484,
        '03:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Ottavio89@hotmail.com',
        '+397027665696',
        '["/static/images/92b1d02c-6ba4-4f74-baa6-7ff816b3145a.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/8b47b9e0-494f-45f5-b233-36d6fb3cab34.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        7,
        121::numeric(12,2),
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Dr. Albrico Lucarelli',
        'http://bulky-nut.org',
        324.547,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Elisea_Stefani@hotmail.com',
        '+394442822392',
        '["/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        1,
        141::numeric(12,2),
        'Vernagthütte',
        'Austria',
        'Pusicio Siragusa',
        'http://lean-beanstalk.com',
        329.393,
        '09:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Desiderata73@email.it',
        '+390664954105',
        '["/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        8,
        50::numeric(12,2),
        'Wormser Hütte',
        'Austria',
        'Simona De Vito',
        'http://composed-canoe.org',
        338.117,
        '08:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Domiziano.Vannini81@gmail.com',
        '+391960645392',
        '["/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg","/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        4,
        91::numeric(12,2),
        'Biberacher Hütte',
        'Austria',
        'Magno Errico',
        'https://flickering-lot.net',
        286.153,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Alida_Miglio@libero.it',
        '+397720056060',
        '["/static/images/cdcd47a9-72e1-492a-9a85-787e0b7d181d.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        4,
        141::numeric(12,2),
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Ing. Donato Di Francesco',
        'http://boiling-manipulation.net',
        332.024,
        '08:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Leandro.Favara67@email.it',
        '+393092061616',
        '["/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/b0550f26-408c-46a1-b27a-178373bf2725.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        10,
        122::numeric(12,2),
        'Hochwaldhütte',
        'Germany',
        'Cupido De Biase',
        'https://frayed-trafficker.it',
        262.925,
        '08:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Empirio11@yahoo.it',
        '+390592981283',
        '["/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        1,
        97::numeric(12,2),
        'Kölner Eifelhütte',
        'Germany',
        'Dina Simeone',
        'https://ill-fated-path.org',
        261.359,
        '04:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Ella.Cavriani@hotmail.com',
        '+395743543547',
        '["/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg","/static/images/92b1d02c-6ba4-4f74-baa6-7ff816b3145a.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg","/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        10,
        87::numeric(12,2),
        'Madrisahütte',
        'Austria',
        'Furseo Spada',
        'https://modern-produce.it',
        281.682,
        '05:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Radolfo.Polizzi@libero.it',
        '+392038762277',
        '["/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        6,
        64::numeric(12,2),
        'Dresdner Hütte',
        'Austria',
        'Paola Franchi',
        'http://energetic-fulfillment.org',
        291.12,
        '03:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Ave.Pompili21@yahoo.com',
        '+394898799893',
        '["/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg","/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        1,
        114::numeric(12,2),
        'Fiderepasshütte',
        'Germany',
        'Riccardo De Angelis',
        'http://informal-ginger.it',
        289.703,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Gioele_Colucci@email.it',
        '+396396184460',
        '["/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/a2c5761b-4ca4-45be-9a6f-a77de475fc43.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        6,
        70::numeric(12,2),
        'Göppinger Hütte',
        'Austria',
        'Graziana Barra',
        'http://treasured-tram.net',
        307.93,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Elvezio12@gmail.com',
        '+399350389911',
        '["/static/images/a2c5761b-4ca4-45be-9a6f-a77de475fc43.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        3,
        87::numeric(12,2),
        'Oberzalimhütte',
        'Austria',
        'Dr. Natalina Giampaolo',
        'http://trusty-reflection.it',
        311.844,
        '04:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Ildegonda59@yahoo.com',
        '+398589000251',
        '["/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg","/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        6,
        117::numeric(12,2),
        'Rastkogelhütte',
        'Austria',
        'Cosimo Montagner',
        'https://timely-enthusiasm.org',
        321.106,
        '07:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Teodoro.Paolini@yahoo.it',
        '+394639880854',
        '["/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg","/static/images/8b47b9e0-494f-45f5-b233-36d6fb3cab34.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg","/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        1,
        146::numeric(12,2),
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Sandra Quarta',
        'https://hateful-specialist.it',
        261.13,
        '09:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Alarico_Lanza15@yahoo.com',
        '+393775532878',
        '["/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg","/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        1,
        104::numeric(12,2),
        'Kaltenberghütte',
        'Austria',
        'Venerio Semprini',
        'https://frigid-couch.org',
        337.41,
        '07:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Guido_Tammaro@hotmail.com',
        '+395432977503',
        '["/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg","/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        10,
        55::numeric(12,2),
        'Schweinfurter Hütte',
        'Austria',
        'Dorotea Zedda',
        'http://embarrassed-elixir.it',
        284.398,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Costanza35@gmail.com',
        '+396075716344',
        '["/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/8b47b9e0-494f-45f5-b233-36d6fb3cab34.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        6,
        100::numeric(12,2),
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Battista Boschi',
        'http://sad-counter.it',
        286.951,
        '01:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Zenaide_Capriotti35@email.it',
        '+390083642600',
        '["/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        2,
        66::numeric(12,2),
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Unna Gatti',
        'http://several-politician.net',
        335.704,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Leonardo.Fiorentino@hotmail.com',
        '+397069518785',
        '["/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        2,
        113::numeric(12,2),
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Mariella Cavallo',
        'https://clear-township.it',
        314.509,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Furseo_DiStefano14@gmail.com',
        '+394019836825',
        '["/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        7,
        35::numeric(12,2),
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Loretta Giannini',
        'http://tremendous-jazz.net',
        336.638,
        '01:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Evodio24@yahoo.com',
        '+393980476907',
        '["/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        4,
        115::numeric(12,2),
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Tosca Vuillermoz',
        'https://our-resale.it',
        315.553,
        '01:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Gosto.Fanara@yahoo.com',
        '+392715736200',
        '["/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg","/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        2,
        127::numeric(12,2),
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Lavinio Benetti',
        'https://hard-to-find-kayak.org',
        326.755,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Dodato.Donda@yahoo.it',
        '+397101575919',
        '["/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/92b1d02c-6ba4-4f74-baa6-7ff816b3145a.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        1,
        36::numeric(12,2),
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Ivan Genna',
        'https://bright-jackfruit.com',
        321.469,
        '07:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Santina_Tilotta41@yahoo.com',
        '+397134944589',
        '["/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg","/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        10,
        107::numeric(12,2),
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Alceste Farina',
        'http://huge-marimba.org',
        333.736,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Nicola.Luciano@hotmail.com',
        '+391039625031',
        '["/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        5,
        146::numeric(12,2),
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Dott. Volfango Ferilli',
        'http://conscious-presume.com',
        333.605,
        '04:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Antonio.Tomei@email.it',
        '+395707357054',
        '["/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/b0550f26-408c-46a1-b27a-178373bf2725.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        5,
        64::numeric(12,2),
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Zenaide Filippi',
        'http://wicked-video.it',
        265.605,
        '02:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Varo.Belmonte@yahoo.com',
        '+391465609918',
        '["/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg","/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        6,
        72::numeric(12,2),
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Abramio Palombi',
        'https://bumpy-shirt.it',
        266.729,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Niceto.Nicol@libero.it',
        '+390111119768',
        '["/static/images/a2c5761b-4ca4-45be-9a6f-a77de475fc43.jpg","/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg","/static/images/b0550f26-408c-46a1-b27a-178373bf2725.jpg","/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        2,
        53::numeric(12,2),
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Consolata Prato',
        'https://stale-clogs.com',
        266.884,
        '03:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Eleonora89@libero.it',
        '+398930839600',
        '["/static/images/92b1d02c-6ba4-4f74-baa6-7ff816b3145a.jpg","/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg","/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg","/static/images/ec95ecdf-197e-4ec0-9c95-b94d8afe7e3c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        8,
        149::numeric(12,2),
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Tarquinia Viola',
        'https://near-biosphere.org',
        332.98,
        '06:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Cuniberto76@libero.it',
        '+399903506806',
        '["/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/8b47b9e0-494f-45f5-b233-36d6fb3cab34.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        5,
        81::numeric(12,2),
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Dott. Cesario Antenucci',
        'http://weary-borrower.org',
        302.642,
        '07:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Domezio52@gmail.com',
        '+392238712697',
        '["/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg","/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/8b47b9e0-494f-45f5-b233-36d6fb3cab34.jpg","/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        5,
        134::numeric(12,2),
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Dr. Fernanda Bonomi',
        'http://tangible-globe.com',
        266.256,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Calogera.DiNatale@hotmail.com',
        '+394648077473',
        '["/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/92b1d02c-6ba4-4f74-baa6-7ff816b3145a.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        5,
        37::numeric(12,2),
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Ing. Egidio Moriconi',
        'https://handy-pineapple.org',
        279.952,
        '09:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Crocefisso13@email.it',
        '+390123376253',
        '["/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg","/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/8b47b9e0-494f-45f5-b233-36d6fb3cab34.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        3,
        40::numeric(12,2),
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Ionne Pasqua',
        'https://lucky-deviance.org',
        310.85,
        '09:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Temistocle51@email.it',
        '+392997989107',
        '["/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/b0550f26-408c-46a1-b27a-178373bf2725.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/cdcd47a9-72e1-492a-9a85-787e0b7d181d.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        9,
        150::numeric(12,2),
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Basileo Coccia',
        'http://euphoric-sport.org',
        260.17,
        '02:00:00'::time without time zone,
        '08:00:00'::time without time zone,
        'Diocleziano_Amici@email.it',
        '+397206216554',
        '["/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        9,
        109::numeric(12,2),
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Dott. Catena Cappelli',
        'https://mad-sheet.com',
        261.113,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Alda3@gmail.com',
        '+396224775163',
        '["/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg","/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/a2c5761b-4ca4-45be-9a6f-a77de475fc43.jpg","/static/images/b0550f26-408c-46a1-b27a-178373bf2725.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        8,
        42::numeric(12,2),
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Ecclesio Macrì',
        'https://zigzag-priority.org',
        302.84,
        '09:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Leonia_Campagna@libero.it',
        '+394313700010',
        '["/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        8,
        90::numeric(12,2),
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Loredana Nota',
        'https://agreeable-hashtag.org',
        317.616,
        '05:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Ottone.Magnani6@yahoo.com',
        '+391420255234',
        '["/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/ec95ecdf-197e-4ec0-9c95-b94d8afe7e3c.jpg","/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg","/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        8,
        140::numeric(12,2),
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Iole Barberis',
        'https://best-court.it',
        323.738,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Nicodemo.Patti10@gmail.com',
        '+396041114669',
        '["/static/images/92b1d02c-6ba4-4f74-baa6-7ff816b3145a.jpg","/static/images/ec95ecdf-197e-4ec0-9c95-b94d8afe7e3c.jpg","/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        9,
        118::numeric(12,2),
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Leontina Perin',
        'https://quirky-doughnut.org',
        301.985,
        '09:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Erenia51@email.it',
        '+398172897380',
        '["/static/images/8b47b9e0-494f-45f5-b233-36d6fb3cab34.jpg","/static/images/a2c5761b-4ca4-45be-9a6f-a77de475fc43.jpg","/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        4,
        128::numeric(12,2),
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Alessia Savoca',
        'https://spiteful-streetcar.com',
        306.529,
        '08:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Loredana.Boscolo@yahoo.it',
        '+398795784866',
        '["/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/cdcd47a9-72e1-492a-9a85-787e0b7d181d.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg","/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        3,
        62::numeric(12,2),
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Brigida Staffieri',
        'http://steel-spoon.it',
        309.106,
        '02:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Neopolo_Guido63@gmail.com',
        '+397557256509',
        '["/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg","/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg","/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        7,
        65::numeric(12,2),
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Duilio Berto',
        'https://favorite-cleaner.it',
        287.255,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Melezio.Vicari9@yahoo.com',
        '+395465342326',
        '["/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        7,
        125::numeric(12,2),
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Fiorenza Bozzo',
        'http://worried-plan.org',
        313.327,
        '01:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Silvano.Fioravanti@yahoo.com',
        '+392441390588',
        '["/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg","/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg","/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        6,
        133::numeric(12,2),
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Sig. Evandro Marras',
        'https://elaborate-capability.net',
        287.697,
        '08:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Agostino.Ragusa@email.it',
        '+396531995938',
        '["/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        7,
        147::numeric(12,2),
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Viviano Trapani',
        'http://idle-military.com',
        328.353,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Aiace.Tortorici30@gmail.com',
        '+393243390121',
        '["/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/8b47b9e0-494f-45f5-b233-36d6fb3cab34.jpg","/static/images/92b1d02c-6ba4-4f74-baa6-7ff816b3145a.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        5,
        91::numeric(12,2),
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Godeberta Bruschi',
        'http://rash-cafe.net',
        273.966,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Adelina.Orr13@email.it',
        '+393115232633',
        '["/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/92b1d02c-6ba4-4f74-baa6-7ff816b3145a.jpg","/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        1,
        110::numeric(12,2),
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Aidano Ross',
        'https://vengeful-bomber.org',
        292.568,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Ausilia28@hotmail.com',
        '+397825338976',
        '["/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg","/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        1,
        95::numeric(12,2),
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Albino Pini',
        'https://wobbly-point.com',
        281.507,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Dione3@yahoo.com',
        '+391546326959',
        '["/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/ec95ecdf-197e-4ec0-9c95-b94d8afe7e3c.jpg","/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg","/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        7,
        65::numeric(12,2),
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Alcide Anzalone',
        'http://strict-pinto.com',
        275.693,
        '06:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Sapiente_Brogi27@yahoo.com',
        '+391249376701',
        '["/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg","/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        8,
        107::numeric(12,2),
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Diomede Borrelli',
        'https://boring-exocrine.org',
        309.834,
        '08:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Olivia_Boschetti@email.it',
        '+397008892475',
        '["/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg","/static/images/a2c5761b-4ca4-45be-9a6f-a77de475fc43.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        2,
        100::numeric(12,2),
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Gianuario Pezzella',
        'http://old-hutch.net',
        328.678,
        '06:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Edgardo_DeBlasi@yahoo.com',
        '+397249801971',
        '["/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg","/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        1,
        138::numeric(12,2),
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Cointa Tripodi',
        'https://orderly-insolence.it',
        316.098,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Elisabetta.Tallarico54@hotmail.com',
        '+390373930482',
        '["/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg","/static/images/b0550f26-408c-46a1-b27a-178373bf2725.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        8,
        129::numeric(12,2),
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Eloisa Cortese',
        'http://close-memory.org',
        338.764,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Sarbello_Palazzo@gmail.com',
        '+397073161595',
        '["/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg","/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg","/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        3,
        147::numeric(12,2),
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Ing. Annabella Palla',
        'http://annual-cacao.com',
        285.955,
        '02:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Cristina34@hotmail.com',
        '+398511703081',
        '["/static/images/92b1d02c-6ba4-4f74-baa6-7ff816b3145a.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/a2c5761b-4ca4-45be-9a6f-a77de475fc43.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        6,
        132::numeric(12,2),
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Cinzia Iacolare',
        'https://ironclad-park.it',
        322.75,
        '08:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Geronzio.Bozzo@libero.it',
        '+399818650225',
        '["/static/images/b0550f26-408c-46a1-b27a-178373bf2725.jpg","/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg","/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/ec95ecdf-197e-4ec0-9c95-b94d8afe7e3c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        4,
        56::numeric(12,2),
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Prudenzia Zaccaro',
        'http://aged-bootee.it',
        263.744,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Ortensio.Ghilardi0@yahoo.com',
        '+398739346099',
        '["/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        3,
        66::numeric(12,2),
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Zarina Fiori',
        'http://pitiful-eurocentrism.it',
        322.658,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Brando_Cataldo@gmail.com',
        '+393743603686',
        '["/static/images/b0550f26-408c-46a1-b27a-178373bf2725.jpg","/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        9,
        93::numeric(12,2),
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Agamennone Privitera',
        'https://plump-apparel.net',
        273.819,
        '03:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Antonio_Palombo87@libero.it',
        '+394081837931',
        '["/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/92b1d02c-6ba4-4f74-baa6-7ff816b3145a.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        1,
        41::numeric(12,2),
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Angelica Palombo',
        'https://nonstop-vibrissae.it',
        333.576,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Eufemia96@yahoo.com',
        '+392638344806',
        '["/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        10,
        148::numeric(12,2),
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Sig. Zenobio Garau',
        'http://colorless-divalent.com',
        327.709,
        '01:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Rossana.Castaldo83@yahoo.com',
        '+397975918648',
        '["/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg","/static/images/ec95ecdf-197e-4ec0-9c95-b94d8afe7e3c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        1,
        135::numeric(12,2),
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Solocone Vicinanza',
        'http://kooky-guinea.it',
        320.384,
        '09:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Emanuele.Cini@gmail.com',
        '+394398221963',
        '["/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg","/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        9,
        66::numeric(12,2),
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Fedele D''Avino',
        'https://aged-mule.net',
        337.926,
        '06:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Luigia.Sassano79@yahoo.com',
        '+399322082137',
        '["/static/images/8b47b9e0-494f-45f5-b233-36d6fb3cab34.jpg","/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        9,
        49::numeric(12,2),
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Pantaleone Valente',
        'https://advanced-kill.net',
        266.201,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Aresio.Conforti@email.it',
        '+392417620816',
        '["/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg","/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        4,
        85::numeric(12,2),
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Sinesio Ortolani',
        'http://unsung-dock.org',
        282.814,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Gioconda_Cortesi@yahoo.com',
        '+393266387936',
        '["/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        9,
        51::numeric(12,2),
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Ing. Fiordaliso Luchini',
        'http://aggressive-guerrilla.net',
        280.39,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Iride70@yahoo.com',
        '+398341864827',
        '["/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/ec95ecdf-197e-4ec0-9c95-b94d8afe7e3c.jpg","/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/b0550f26-408c-46a1-b27a-178373bf2725.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        5,
        141::numeric(12,2),
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Franco Storti',
        'https://frugal-executive.com',
        261.83,
        '06:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Erasmo11@libero.it',
        '+395670524272',
        '["/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/b0550f26-408c-46a1-b27a-178373bf2725.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        1,
        115::numeric(12,2),
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Vezio Gatti',
        'http://celebrated-query.it',
        268.706,
        '04:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Eusebio_Zagaria@email.it',
        '+391419872212',
        '["/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg","/static/images/cdcd47a9-72e1-492a-9a85-787e0b7d181d.jpg","/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        8,
        145::numeric(12,2),
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Saul Giuliano',
        'https://chief-dialect.net',
        263.214,
        '04:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Amilcare47@email.it',
        '+397559750851',
        '["/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/ec95ecdf-197e-4ec0-9c95-b94d8afe7e3c.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        10,
        114::numeric(12,2),
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Dott. Saturniano Zotti',
        'https://terrible-oeuvre.org',
        322.307,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Ottavio.Federico58@gmail.com',
        '+399338239721',
        '["/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        4,
        147::numeric(12,2),
        'Wittener Hütte',
        'Germany',
        'Dott. Eliodoro Sacchetti',
        'https://frilly-button.com',
        338.652,
        '08:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Patrizio_Lai@email.it',
        '+398160170508',
        '["/static/images/ec95ecdf-197e-4ec0-9c95-b94d8afe7e3c.jpg","/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        3,
        66::numeric(12,2),
        'Hochjoch-Hospiz',
        'Austria',
        'Adalardo Tedde',
        'https://unwieldy-president.net',
        317.763,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Rebecca22@hotmail.com',
        '+392619459660',
        '["/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/92b1d02c-6ba4-4f74-baa6-7ff816b3145a.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        1,
        138::numeric(12,2),
        'Meilerhütte',
        'Germany',
        'Evangelina Romanini',
        'http://glass-anise.com',
        330.868,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Erico5@hotmail.com',
        '+395882919145',
        '["/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg","/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg","/static/images/cdcd47a9-72e1-492a-9a85-787e0b7d181d.jpg","/static/images/b0550f26-408c-46a1-b27a-178373bf2725.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        7,
        36::numeric(12,2),
        'Gaudeamushütte',
        'Austria',
        'Luisa Capecchi',
        'http://lumpy-mirror.org',
        271.985,
        '03:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Sico.Giuliano@libero.it',
        '+390396435422',
        '["/static/images/cdcd47a9-72e1-492a-9a85-787e0b7d181d.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/ec95ecdf-197e-4ec0-9c95-b94d8afe7e3c.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        3,
        47::numeric(12,2),
        'Rheydter Hütte',
        'Germany',
        'Guerrino Blanc',
        'http://melodic-tracksuit.net',
        325.216,
        '07:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Osanna18@email.it',
        '+391123786042',
        '["/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/cdcd47a9-72e1-492a-9a85-787e0b7d181d.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        2,
        118::numeric(12,2),
        'Sektionshütte Krippen',
        'Germany',
        'Cesario Piscitelli',
        'http://lasting-panties.com',
        339.942,
        '02:00:00'::time without time zone,
        '08:00:00'::time without time zone,
        'Fedro_Luconi72@hotmail.com',
        '+399304002397',
        '["/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg","/static/images/b0550f26-408c-46a1-b27a-178373bf2725.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        4,
        126::numeric(12,2),
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Guelfo Calò',
        'https://blaring-tone.com',
        338.472,
        '09:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Audace.Righi@libero.it',
        '+395105524213',
        '["/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        9,
        75::numeric(12,2),
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Sig. Valfredo Ammoscato',
        'https://palatable-documentary.it',
        335.868,
        '01:00:00'::time without time zone,
        '09:00:00'::time without time zone,
        'Carmen_Vianello@hotmail.com',
        '+390525209572',
        '["/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg","/static/images/8b47b9e0-494f-45f5-b233-36d6fb3cab34.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        8,
        148::numeric(12,2),
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Saffo Boscaino',
        'http://major-oatmeal.it',
        309.438,
        '02:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Geremia_Diana6@hotmail.com',
        '+395465148605',
        '["/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/5a013f47-609a-4d80-b192-ec6915511543.jpg","/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        9,
        53::numeric(12,2),
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Feliciano Costa',
        'http://rapid-stumbling.org',
        326.27,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Paciano90@email.it',
        '+394193647676',
        '["/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg","/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        6,
        146::numeric(12,2),
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Dr. Valter Nicolosi',
        'https://fresh-infancy.it',
        280.255,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Almiro_Fioretti6@libero.it',
        '+391265210634',
        '["/static/images/dd891dd9-5c93-46af-876c-e1bba91e35aa.jpg","/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        1,
        149::numeric(12,2),
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Zanita Vella',
        'https://wry-driver.it',
        264.236,
        '01:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Veriana63@yahoo.it',
        '+398646646133',
        '["/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        2,
        35::numeric(12,2),
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Antonia Venturelli',
        'https://flawed-boudoir.net',
        308.164,
        '03:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Venerando_Gandolfo@yahoo.it',
        '+398048067641',
        '["/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg","/static/images/a2c5761b-4ca4-45be-9a6f-a77de475fc43.jpg","/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        9,
        150::numeric(12,2),
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Fidenziano Baldini',
        'http://zany-ectodermal.net',
        264.81,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Paterniano_Alberti@hotmail.com',
        '+397648743143',
        '["/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/a2c5761b-4ca4-45be-9a6f-a77de475fc43.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/bd8f8569-d361-4b16-9f7a-bc7dea69cd1e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        6,
        116::numeric(12,2),
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Crocefisso Ciacio',
        'http://distorted-craftsman.org',
        315.598,
        '05:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Apollo_Solinas@yahoo.it',
        '+390827500527',
        '["/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg","/static/images/a2c5761b-4ca4-45be-9a6f-a77de475fc43.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        2,
        140::numeric(12,2),
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Godiva Paolini',
        'https://arctic-nickname.com',
        278.639,
        '07:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Cesario.Car88@email.it',
        '+390754094564',
        '["/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        10,
        71::numeric(12,2),
        'Dobra voda',
        'Suvobor, Serbia',
        'Astrid Meloni',
        'http://zesty-eicosanoid.net',
        331.858,
        '05:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Nicodemo.Puggioni31@email.it',
        '+399336904773',
        '["/static/images/ec95ecdf-197e-4ec0-9c95-b94d8afe7e3c.jpg","/static/images/8b47b9e0-494f-45f5-b233-36d6fb3cab34.jpg","/static/images/dbc5fd1a-08b4-4757-bc75-5e7888788140.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        9,
        121::numeric(12,2),
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Igor Lorusso',
        'http://fussy-dock.it',
        298.623,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Germana_Saladino@yahoo.com',
        '+395515907811',
        '["/static/images/4437254e-7bed-442a-a599-34e3e87a88a6.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/cdcd47a9-72e1-492a-9a85-787e0b7d181d.jpg","/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/92b1d02c-6ba4-4f74-baa6-7ff816b3145a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        9,
        61::numeric(12,2),
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Rosalia Zamboni',
        'https://slow-load.it',
        264.12,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Galileo93@yahoo.it',
        '+390114865712',
        '["/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg","/static/images/8b47b9e0-494f-45f5-b233-36d6fb3cab34.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        6,
        133::numeric(12,2),
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Arrigo Di Bari',
        'http://homely-smoking.org',
        265.603,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Parmenio23@email.it',
        '+399923850641',
        '["/static/images/ec95ecdf-197e-4ec0-9c95-b94d8afe7e3c.jpg","/static/images/8b47b9e0-494f-45f5-b233-36d6fb3cab34.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        7,
        137::numeric(12,2),
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Generosa Giovannini',
        'https://yawning-cooking.org',
        333.019,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Aldobrando_Saba@hotmail.com',
        '+397562140767',
        '["/static/images/f555a8bc-416c-479c-b1a7-35bbf8214dd9.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg","/static/images/cdcd47a9-72e1-492a-9a85-787e0b7d181d.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        5,
        150::numeric(12,2),
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Ofelia Paladini',
        'https://frivolous-coupon.it',
        267.984,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Gildo30@libero.it',
        '+397620110480',
        '["/static/images/7218cf89-6179-4522-a522-944eccddb63f.jpg","/static/images/87102a7d-4d97-428e-b15a-520d9fb55245.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/a2c5761b-4ca4-45be-9a6f-a77de475fc43.jpg","/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        5,
        112::numeric(12,2),
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Piera Barile',
        'http://normal-brain.org',
        308.396,
        '01:00:00'::time without time zone,
        '08:00:00'::time without time zone,
        'Ansovino.Ciccone41@libero.it',
        '+390100730772',
        '["/static/images/418386e5-6bcd-4ca9-9d1c-b92ba946b50e.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg","/static/images/5edcbdb6-067e-4be5-ac32-34718247ce0f.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        4,
        68::numeric(12,2),
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Sig. Ermenegilda Rizza',
        'http://altruistic-tolerant.com',
        281.618,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Tito_Raffa15@email.it',
        '+397491567946',
        '["/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg","/static/images/0ddfd671-b9ae-48b1-8ef1-02485787d3fe.jpg","/static/images/80653548-d40b-48f1-820c-b42d7a5c83d3.jpg","/static/images/53065fdf-43ac-475b-991a-c9cdd9b60bda.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        6,
        90::numeric(12,2),
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Gavino Cossu',
        'https://noxious-gaming.it',
        267.048,
        '02:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Lorenza56@hotmail.com',
        '+393166526905',
        '["/static/images/92b1d02c-6ba4-4f74-baa6-7ff816b3145a.jpg","/static/images/81f46c21-ba9a-4abf-b478-d0c390c50d9c.jpg","/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        3,
        37::numeric(12,2),
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Almerigo Pardini',
        'http://flawed-rudiment.com',
        275.945,
        '04:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Vinicio.Sucameli@email.it',
        '+397251878477',
        '["/static/images/68f7daeb-4583-48dc-b131-d1ba11f629e5.jpg","/static/images/dce21725-6d86-41e0-95b7-bcc9586e70cb.jpg","/static/images/e19e8360-0f26-4b48-bd8e-cbcfad4a126a.jpg","/static/images/f81d66b3-a130-42b1-9846-a8ebd47869f4.jpg","/static/images/9a9922a2-98b1-408e-964c-e7e6b016e197.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        3,
        82::numeric(12,2),
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Dr. Palladia Duca',
        'http://necessary-domain.com',
        287.517,
        '02:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Salvatore.Montalbano@email.it',
        '+397928111751',
        '["/static/images/1ce0f411-49ae-4076-8f50-669f6330bbb1.jpg","/static/images/d77aad8c-7d50-4d02-b09d-3ab77d93a433.jpg","/static/images/90658dc5-f95c-48c2-88ec-cde74d9d7ffa.jpg","/static/images/178b4886-b057-4165-9d4e-b55dba812635.jpg","/static/images/03cd0b45-626f-49b1-9dd9-fbd78229e43b.jpg"]'::jsonb
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '812 Piazza Capannolo, Settimo Giandomenico sardo, Italy',
        'Settimo Giandomenico sardo',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        237,
        '540 Incrocio De Filippis, San Leopardo lido, Italy',
        'San Leopardo lido',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        281,
        '2 Piazza Osvaldo, Borgo Amos laziale, Italy',
        'Borgo Amos laziale',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        94,
        '95 Contrada Vuillermoz, Dario ligure, Italy',
        'Dario ligure',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        135,
        '250 Incrocio Speranza, Agenore veneto, Italy',
        'Agenore veneto',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        239,
        '75 Borgo Spartaco, Sesto Ebe, Italy',
        'Sesto Ebe',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        75,
        '45 Via Annunziata, Borgo Eriberto laziale, Italy',
        'Borgo Eriberto laziale',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        244,
        '056 Borgo Mannino, Quarto Salvatore nell''emilia, Italy',
        'Quarto Salvatore nell''emilia',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        280,
        '3 Borgo Iside, Mazzarella a mare, Italy',
        'Mazzarella a mare',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        197,
        '207 Piazza Poli, Settimo Elvira, Italy',
        'Settimo Elvira',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        242,
        '9 Borgo Leo, Asimodeo laziale, Italy',
        'Asimodeo laziale',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        104,
        '318 Borgo Adelmo, Quarto Quintiliano terme, Italy',
        'Quarto Quintiliano terme',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        149,
        '4 Via Fiori, San Evidio, Italy',
        'San Evidio',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        264,
        '306 Incrocio Ermenegarda, Borgo Panfilo, Italy',
        'Borgo Panfilo',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        274,
        '008 Piazza Castaldi, Cruciata terme, Italy',
        'Cruciata terme',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        193,
        '62 Borgo Liberatore, Quarto Marinetta del friuli, Italy',
        'Quarto Marinetta del friuli',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        130,
        '14 Via Emiliana, San Colomba lido, Italy',
        'San Colomba lido',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        170,
        '257 Incrocio Biggi, Achille sardo, Italy',
        'Achille sardo',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        274,
        '275 Incrocio Agresta, Demontis veneto, Italy',
        'Demontis veneto',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        70,
        '586 Incrocio Eustosio, Artemisa laziale, Italy',
        'Artemisa laziale',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        112,
        '51 Incrocio Adone, San Geremia sardo, Italy',
        'San Geremia sardo',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        64,
        '078 Piazza Mariucci, Tiberti laziale, Italy',
        'Tiberti laziale',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '69 Rotonda Ercolano, Borgo Eugenio, Italy',
        'Borgo Eugenio',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        262,
        '7 Incrocio Baldassarre, Galluzzo terme, Italy',
        'Galluzzo terme',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        185,
        '0 Via Cremenzio, Quarto Duccio ligure, Italy',
        'Quarto Duccio ligure',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        29,
        '2 Incrocio Delfina, Sesto Arialdo, Italy',
        'Sesto Arialdo',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        119,
        '9 Rotonda Ildefonso, San Messalina calabro, Italy',
        'San Messalina calabro',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        148,
        '586 Borgo Agresta, San Michele laziale, Italy',
        'San Michele laziale',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        92,
        '49 Rotonda Cardella, Antonia laziale, Italy',
        'Antonia laziale',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        267,
        '116 Contrada Carosi, Sesto Porzia terme, Italy',
        'Sesto Porzia terme',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        298,
        '18 Rotonda Fazio, Settimo Vodingo nell''emilia, Italy',
        'Settimo Vodingo nell''emilia',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        210,
        '27 Incrocio De Napoli, Borgo Azelia salentino, Italy',
        'Borgo Azelia salentino',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        165,
        '58 Borgo Doda, Borgo Vedasto, Italy',
        'Borgo Vedasto',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '00 Via Viliberto, Desiderio umbro, Italy',
        'Desiderio umbro',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        196,
        '563 Borgo Cronida, Sesto Elda nell''emilia, Italy',
        'Sesto Elda nell''emilia',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        86,
        '28 Via Marolo, Amatore lido, Italy',
        'Amatore lido',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        189,
        '420 Contrada Lieto, Settimo Allegra lido, Italy',
        'Settimo Allegra lido',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        228,
        '718 Incrocio Anacleto, Quarto Aleandro, Italy',
        'Quarto Aleandro',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        275,
        '0 Borgo Corona, Quarto Incoronata, Italy',
        'Quarto Incoronata',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        123,
        '32 Borgo Matteucci, Borgo Santina veneto, Italy',
        'Borgo Santina veneto',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '684 Contrada Alice, Borgo Eros del friuli, Italy',
        'Borgo Eros del friuli',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        72,
        '45 Strada Venusta, Borgo Ave lido, Italy',
        'Borgo Ave lido',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        188,
        '26 Via Fleano, San Nicoletta veneto, Italy',
        'San Nicoletta veneto',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        30,
        '755 Incrocio Gori, Quarto Graziella laziale, Italy',
        'Quarto Graziella laziale',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        248,
        '354 Strada Critelli, Crispino a mare, Italy',
        'Crispino a mare',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        143,
        '8 Borgo Malatesta, San Serena, Italy',
        'San Serena',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        133,
        '921 Incrocio Volpi, Martina del friuli, Italy',
        'Martina del friuli',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        158,
        '3 Rotonda Ippoliti, Settimo Ippocrate, Italy',
        'Settimo Ippocrate',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        272,
        '00 Via Cadoni, Galatea terme, Italy',
        'Galatea terme',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        64,
        '2 Piazza Angelini, Martina lido, Italy',
        'Martina lido',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        286,
        '53 Borgo Gualtiero, Borgo Zena, Italy',
        'Borgo Zena',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '1 Piazza Da Rold, Vitale umbro, Italy',
        'Vitale umbro',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        105,
        '1 Via Saracino, Settimo Ippocrate, Italy',
        'Settimo Ippocrate',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '52 Rotonda Spagnolo, Sesto Dino laziale, Italy',
        'Sesto Dino laziale',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        300,
        '6 Borgo Lodovica, Settimo Michele, Italy',
        'Settimo Michele',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        146,
        '2 Piazza Canepa, Sesto Editta, Italy',
        'Sesto Editta',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        256,
        '4 Rotonda Giosuele, Capraro calabro, Italy',
        'Capraro calabro',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        107,
        '89 Strada Solinas, Abbondanza umbro, Italy',
        'Abbondanza umbro',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        208,
        '80 Strada Umberto, Quarto Odidone nell''emilia, Italy',
        'Quarto Odidone nell''emilia',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        140,
        '27 Rotonda Frezza, Sesto Protasio, Italy',
        'Sesto Protasio',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        291,
        '97 Contrada Luana, Corrao del friuli, Italy',
        'Corrao del friuli',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        300,
        '58 Borgo Leonio, Brigida terme, Italy',
        'Brigida terme',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        218,
        '12 Incrocio Didimo, Marconi nell''emilia, Italy',
        'Marconi nell''emilia',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        208,
        '43 Piazza Brando, San Innocenza, Italy',
        'San Innocenza',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        203,
        '57 Borgo Ione, Gaspari salentino, Italy',
        'Gaspari salentino',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        200,
        '77 Piazza Tarcisio, Pession umbro, Italy',
        'Pession umbro',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        274,
        '11 Contrada Paris, Sesto Melezio, Italy',
        'Sesto Melezio',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        219,
        '8 Strada Piersilvio, Antino nell''emilia, Italy',
        'Antino nell''emilia',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        273,
        '1 Rotonda Feliziani, Tomei terme, Italy',
        'Tomei terme',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '73 Strada Modesto, Ilda terme, Italy',
        'Ilda terme',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        31,
        '1 Incrocio Graziella, Settimo Landolfo, Italy',
        'Settimo Landolfo',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        235,
        '0 Incrocio Ferretti, Eligibile nell''emilia, Italy',
        'Eligibile nell''emilia',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        172,
        '7 Incrocio Mareta, San Unna, Italy',
        'San Unna',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        133,
        '456 Strada Gervasi, Settimo Beata umbro, Italy',
        'Settimo Beata umbro',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        35,
        '22 Piazza Bonetti, Borgo Armida, Italy',
        'Borgo Armida',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        89,
        '9 Strada Giorgi, Manuele veneto, Italy',
        'Manuele veneto',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        157,
        '7 Strada Casimiro, Ismaele salentino, Italy',
        'Ismaele salentino',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        186,
        '69 Strada Aristotele, Sepe sardo, Italy',
        'Sepe sardo',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        112,
        '2 Strada Nunziata, San Polidoro lido, Italy',
        'San Polidoro lido',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        139,
        '48 Strada Aristarco, Palazzo umbro, Italy',
        'Palazzo umbro',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        215,
        '5 Incrocio Magliocco, San Giulia calabro, Italy',
        'San Giulia calabro',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        152,
        '3 Borgo Grilli, Sesto Rodrigo, Italy',
        'Sesto Rodrigo',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        152,
        '69 Contrada Carmela, Marconi del friuli, Italy',
        'Marconi del friuli',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        223,
        '065 Rotonda Cristiana, Cannata terme, Italy',
        'Cannata terme',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        240,
        '145 Incrocio Ezio, San Gianpaolo, Italy',
        'San Gianpaolo',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        207,
        '65 Incrocio Ildefonso, Sesto Silvestro nell''emilia, Italy',
        'Sesto Silvestro nell''emilia',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        186,
        '004 Strada Menna, Papaleo del friuli, Italy',
        'Papaleo del friuli',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        125,
        '57 Contrada Signorini, Panetta salentino, Italy',
        'Panetta salentino',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        206,
        '319 Strada Fornara, Quarto Quintino, Italy',
        'Quarto Quintino',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        94,
        '8 Piazza Giordani, Settimo Mia, Italy',
        'Settimo Mia',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        163,
        '3 Via Coviello, Cattaneo lido, Italy',
        'Cattaneo lido',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        168,
        '01 Borgo Mattioli, Abibo ligure, Italy',
        'Abibo ligure',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        206,
        '9 Contrada Guendalina, Quarto Davide laziale, Italy',
        'Quarto Davide laziale',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        109,
        '9 Strada Esterina, San Elio, Italy',
        'San Elio',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        191,
        '60 Rotonda Giardina, Settimo Piero, Italy',
        'Settimo Piero',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        244,
        '771 Piazza De Luca, Sicuro laziale, Italy',
        'Sicuro laziale',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        264,
        '9 Rotonda Ventimiglia, Sesto Turi, Italy',
        'Sesto Turi',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        229,
        '468 Piazza Cavalli, Stella calabro, Italy',
        'Stella calabro',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        143,
        '6 Rotonda Brandi, Pollione salentino, Italy',
        'Pollione salentino',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        192,
        '4 Piazza Santarsia, Quarto Evangelina, Italy',
        'Quarto Evangelina',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        158,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        272,
        '22 Incrocio Orfeo, San Marita del friuli, Italy',
        'San Marita del friuli',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        60,
        '39 Incrocio Proserpina, Borgo Terzo umbro, Italy',
        'Borgo Terzo umbro',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        189,
        '7 Piazza Morabito, Micillo veneto, Italy',
        'Micillo veneto',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        243,
        '806 Borgo Eufemio, Sesto Verdiana laziale, Italy',
        'Sesto Verdiana laziale',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        253,
        '57 Piazza Rago, Quarto Bardomiano, Italy',
        'Quarto Bardomiano',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        201,
        '89 Via Tabita, Settimo Acilio, Italy',
        'Settimo Acilio',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        192,
        '0 Rotonda Maugeri, San Barsaba ligure, Italy',
        'San Barsaba ligure',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        157,
        '5 Via Paonessa, Braia lido, Italy',
        'Braia lido',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        236,
        '9 Borgo Oreste, Tirelli terme, Italy',
        'Tirelli terme',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        140,
        '9 Incrocio Ildegarda, Sesto Cantidio, Italy',
        'Sesto Cantidio',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        86,
        '1 Via Antino, Quarto Pomponio sardo, Italy',
        'Quarto Pomponio sardo',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        121,
        '8 Via Zabina, Cappelli laziale, Italy',
        'Cappelli laziale',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        205,
        '1 Incrocio Egle, Ermini lido, Italy',
        'Ermini lido',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        216,
        '550 Rotonda Perin, Pomponio veneto, Italy',
        'Pomponio veneto',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        282,
        '413 Piazza Mazzarella, Quarto Desiderata, Italy',
        'Quarto Desiderata',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        225,
        '538 Contrada Ionne, Quarto Prassede sardo, Italy',
        'Quarto Prassede sardo',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        280,
        '64 Contrada Gioconda, Sansone laziale, Italy',
        'Sansone laziale',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        96,
        '43 Via Lopez, Quarto Eracla nell''emilia, Italy',
        'Quarto Eracla nell''emilia',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        27,
        '90 Rotonda Viola, Settimo Argimiro nell''emilia, Italy',
        'Settimo Argimiro nell''emilia',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        243,
        '13 Incrocio Pacifici, Sesto Gaio calabro, Italy',
        'Sesto Gaio calabro',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        178,
        '3 Borgo Sicuro, Settimo Telemaco, Italy',
        'Settimo Telemaco',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        290,
        '554 Rotonda Sico, Settimo Greta, Italy',
        'Settimo Greta',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        176,
        '817 Strada Di Sarno, Magi veneto, Italy',
        'Magi veneto',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        141,
        '7 Incrocio Bruzzone, Stefania a mare, Italy',
        'Stefania a mare',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        266,
        '685 Incrocio Aristide, Borgo Gualberto, Italy',
        'Borgo Gualberto',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '03 Strada Mancio, Borgo Teodosio, Italy',
        'Borgo Teodosio',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        158,
        '80 Via Ercoli, Melillo a mare, Italy',
        'Melillo a mare',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        95,
        '1 Borgo Tornatore, San Auberto laziale, Italy',
        'San Auberto laziale',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '120 Piazza Gaio, Ofelia umbro, Italy',
        'Ofelia umbro',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '256 Rotonda Attilio, Evodio nell''emilia, Italy',
        'Evodio nell''emilia',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        176,
        '76 Via Perri, Sesto Alida, Italy',
        'Sesto Alida',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        78,
        '58 Rotonda Bertolfo, Quarto Solocone calabro, Italy',
        'Quarto Solocone calabro',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        76,
        '3 Borgo Azelio, Plutarco ligure, Italy',
        'Plutarco ligure',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        80,
        '214 Contrada Bongiovanni, Peleo veneto, Italy',
        'Peleo veneto',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        213,
        '181 Contrada Improta, Euclide laziale, Italy',
        'Euclide laziale',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '1 Incrocio Nerea, Settimo Antioco, Italy',
        'Settimo Antioco',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '5 Incrocio Gioia, San Edilberto, Italy',
        'San Edilberto',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        183,
        '401 Strada Clinio, Quarto Manilio, Italy',
        'Quarto Manilio',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '6 Borgo Oronzo, San Fabiola sardo, Italy',
        'San Fabiola sardo',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        236,
        '7 Via Misaele, San Maurizio salentino, Italy',
        'San Maurizio salentino',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        59,
        '60 Incrocio Ilia, Quarto Ester, Italy',
        'Quarto Ester',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        160,
        '18 Rotonda Sosteneo, Quarto Vincenzo laziale, Italy',
        'Quarto Vincenzo laziale',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        259,
        '71 Rotonda Mariotti, Venturini terme, Italy',
        'Venturini terme',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        83,
        '85 Rotonda Cesare, Dino del friuli, Italy',
        'Dino del friuli',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        281,
        '74 Via Pia, Borgo Orsolina ligure, Italy',
        'Borgo Orsolina ligure',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        236,
        '5 Via Polito, Biondi nell''emilia, Italy',
        'Biondi nell''emilia',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        294,
        '43 Piazza Fedro, Innocenzo veneto, Italy',
        'Innocenzo veneto',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        285,
        '0 Strada Poletti, Saporito laziale, Italy',
        'Saporito laziale',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        211,
        '3 Rotonda Emidio, Linda nell''emilia, Italy',
        'Linda nell''emilia',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        259,
        '25 Strada Denaro, San Ettore, Italy',
        'San Ettore',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        140,
        '00 Strada Bove, Mascia nell''emilia, Italy',
        'Mascia nell''emilia',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        46,
        '9 Strada Asella, San Viviana, Italy',
        'San Viviana',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        230,
        '5 Borgo Potenza, Marinetta calabro, Italy',
        'Marinetta calabro',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        279,
        '95 Contrada Senesio, Leo sardo, Italy',
        'Leo sardo',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        50,
        '86 Borgo Cuzia, Settimo Cremenzio laziale, Italy',
        'Settimo Cremenzio laziale',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        116,
        '76 Via Fidenziano, San Andromeda, Italy',
        'San Andromeda',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        36,
        '99 Contrada Bertolfo, Settimo Adalfredo laziale, Italy',
        'Settimo Adalfredo laziale',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        222,
        '6 Strada Prisco, Sesto Fatima terme, Italy',
        'Sesto Fatima terme',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        91,
        '351 Incrocio Euclide, Borgo Eberardo nell''emilia, Italy',
        'Borgo Eberardo nell''emilia',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        246,
        '7 Strada Amone, Camelia salentino, Italy',
        'Camelia salentino',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        55,
        '8 Contrada Carrus, San Beato salentino, Italy',
        'San Beato salentino',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        59,
        '7 Via Vasco, Massimiliano terme, Italy',
        'Massimiliano terme',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        64,
        '381 Rotonda Emanuele, Petrini a mare, Italy',
        'Petrini a mare',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        159,
        '4 Incrocio Adamo, Settimo Devota, Italy',
        'Settimo Devota',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '777 Borgo Rondinone, Quarto Asimodeo, Italy',
        'Quarto Asimodeo',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        152,
        '382 Borgo Sestito, Emiliana veneto, Italy',
        'Emiliana veneto',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        248,
        '2 Piazza Onorino, Leonardi umbro, Italy',
        'Leonardi umbro',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        123,
        '5 Piazza Gaia, Borgo Artemisa, Italy',
        'Borgo Artemisa',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        122,
        '73 Piazza Grazia, Settimo Salvatore, Italy',
        'Settimo Salvatore',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        200,
        '3 Borgo Vincenzo, Borgo Saturnino veneto, Italy',
        'Borgo Saturnino veneto',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        215,
        '55 Via Orlando, Sesto Vala, Italy',
        'Sesto Vala',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        188,
        '7 Piazza Manno, Mulè nell''emilia, Italy',
        'Mulè nell''emilia',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        113,
        '721 Piazza Silvio, Pennestrì lido, Italy',
        'Pennestrì lido',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        102,
        '7 Incrocio Marina, Borgo Manfredo umbro, Italy',
        'Borgo Manfredo umbro',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        283,
        '291 Via Marcovecchio, Amabile sardo, Italy',
        'Amabile sardo',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        130,
        '887 Piazza Ciuffetelli, Immacolata salentino, Italy',
        'Immacolata salentino',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        227,
        '958 Rotonda Melis, Quarto Erberto, Italy',
        'Quarto Erberto',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        171,
        '952 Piazza Zappalà, Pasqua ligure, Italy',
        'Pasqua ligure',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        141,
        '74 Incrocio Protasio, Ulstano del friuli, Italy',
        'Ulstano del friuli',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        62,
        '1 Contrada Pagliuca, Settimo Primo, Italy',
        'Settimo Primo',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        225,
        '746 Via Cozzi, Riccardo a mare, Italy',
        'Riccardo a mare',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '867 Rotonda Carlini, Quarto Caino umbro, Italy',
        'Quarto Caino umbro',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        294,
        '769 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        263,
        '5 Strada Palmira, Settimo Settimo terme, Italy',
        'Settimo Settimo terme',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        92,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        186,
        '102 Contrada Cupido, Egger sardo, Italy',
        'Egger sardo',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        171,
        '7 Strada Spadafora, Prisco umbro, Italy',
        'Prisco umbro',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        244,
        '13 Strada Estella, Evelina umbro, Italy',
        'Evelina umbro',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        134,
        '9 Contrada Grimaldi, Sacchet calabro, Italy',
        'Sacchet calabro',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        41,
        '093 Incrocio Catellani, Borgo Bonavita, Italy',
        'Borgo Bonavita',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        144,
        '749 Borgo Barbera, Settimo Marita laziale, Italy',
        'Settimo Marita laziale',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        229,
        '29 Strada Daniele, Estella sardo, Italy',
        'Estella sardo',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        238,
        '4 Contrada Perrone, Sesto Mareta del friuli, Italy',
        'Sesto Mareta del friuli',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        230,
        '033 Rotonda Barbagallo, Meneo ligure, Italy',
        'Meneo ligure',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        232,
        '012 Piazza Morgana, Settimo Nicezio laziale, Italy',
        'Settimo Nicezio laziale',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        135,
        '6 Contrada Berto, Alano laziale, Italy',
        'Alano laziale',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        73,
        '825 Rotonda Alceo, Olindo del friuli, Italy',
        'Olindo del friuli',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        226,
        '8 Borgo Caselli, Quarto Crespignano, Italy',
        'Quarto Crespignano',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        150,
        '66 Piazza Tirone, Pollione del friuli, Italy',
        'Pollione del friuli',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        185,
        '063 Contrada Calogero, Bellino calabro, Italy',
        'Bellino calabro',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        164,
        '37 Incrocio Pani, Borgo Amico umbro, Italy',
        'Borgo Amico umbro',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '45 Strada Crescenzia, San Antonio a mare, Italy',
        'San Antonio a mare',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        181,
        '2 Via Martino, Borgo Fabio nell''emilia, Italy',
        'Borgo Fabio nell''emilia',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        187,
        '2 Via Ginevra, Borgo Francesca laziale, Italy',
        'Borgo Francesca laziale',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        83,
        '03 Piazza Vitale, Borgo Luce salentino, Italy',
        'Borgo Luce salentino',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        298,
        '19 Rotonda Cardini, Borgo Venusta, Italy',
        'Borgo Venusta',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        160,
        '167 Incrocio Manfredi, Nocera a mare, Italy',
        'Nocera a mare',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        46,
        '548 Contrada Iodice, Davide lido, Italy',
        'Davide lido',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        70,
        '0 Contrada Pancrazio, Sesto Rina umbro, Italy',
        'Sesto Rina umbro',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        117,
        '20 Via Gillo, Settimo Ezio laziale, Italy',
        'Settimo Ezio laziale',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        126,
        '4 Contrada Zosima, Canepa umbro, Italy',
        'Canepa umbro',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '7 Contrada Fonda, Borgo Marinetta ligure, Italy',
        'Borgo Marinetta ligure',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        209,
        '89 Strada Di Pede, Sesto Gelsomina, Italy',
        'Sesto Gelsomina',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        218,
        '25 Via Grange, Filiberto lido, Italy',
        'Filiberto lido',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        41,
        '0 Borgo Belmonte, Teresi umbro, Italy',
        'Teresi umbro',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        48,
        '48 Borgo Amedeo, Settimo Fulgenzio sardo, Italy',
        'Settimo Fulgenzio sardo',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        153,
        '622 Piazza Lavinio, Borgo Onorio, Italy',
        'Borgo Onorio',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        53,
        '29 Rotonda Ireneo, Antea nell''emilia, Italy',
        'Antea nell''emilia',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        215,
        '5 Piazza Adalgiso, Mautone laziale, Italy',
        'Mautone laziale',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        279,
        '4 Rotonda Drago, Giordano ligure, Italy',
        'Giordano ligure',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '1 Piazza Fabiano, Geronzio a mare, Italy',
        'Geronzio a mare',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        44,
        '2 Incrocio Antonio, Sesto Divo calabro, Italy',
        'Sesto Divo calabro',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        240,
        '49 Via Giulio, Borgo Galileo sardo, Italy',
        'Borgo Galileo sardo',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        49,
        '48 Strada Brunilde, Quarto Eliana, Italy',
        'Quarto Eliana',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        156,
        '3 Borgo Susanna, Ubertino veneto, Italy',
        'Ubertino veneto',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        123,
        '936 Contrada Ermilo, Luminosa lido, Italy',
        'Luminosa lido',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        273,
        '69 Piazza Roberto, Quarto Aresio del friuli, Italy',
        'Quarto Aresio del friuli',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        273,
        '14 Piazza Gazzola, Oggiano lido, Italy',
        'Oggiano lido',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        190,
        '82 Rotonda Novelli, Quarto Nicarete, Italy',
        'Quarto Nicarete',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        114,
        '4 Borgo Beronico, Beltramo sardo, Italy',
        'Beltramo sardo',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        30,
        '379 Incrocio Pession, Borgo Orlando nell''emilia, Italy',
        'Borgo Orlando nell''emilia',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        175,
        '529 Strada Caputo, Battistini sardo, Italy',
        'Battistini sardo',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        257,
        '31 Rotonda Pardini, Quarto Godeberta ligure, Italy',
        'Quarto Godeberta ligure',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        117,
        '1 Via Ausilia, San Adriano a mare, Italy',
        'San Adriano a mare',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        200,
        '8 Borgo Cesare, Sesto Gineto lido, Italy',
        'Sesto Gineto lido',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        294,
        '85 Incrocio Concetto, Sesto Ausilio, Italy',
        'Sesto Ausilio',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        161,
        '3 Piazza Evandro, Fioretti salentino, Italy',
        'Fioretti salentino',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        58,
        '166 Via Calligaris, Settimo Oliviero, Italy',
        'Settimo Oliviero',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        240,
        '551 Contrada Giulio, Leone terme, Italy',
        'Leone terme',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        45,
        '251 Strada Marinetta, San Ugolina, Italy',
        'San Ugolina',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        87,
        '775 Contrada Vicari, Settimo Mirco nell''emilia, Italy',
        'Settimo Mirco nell''emilia',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        98,
        '05 Piazza Massaro, Petralia ligure, Italy',
        'Petralia ligure',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        213,
        '162 Borgo Fiorentini, Massimo ligure, Italy',
        'Massimo ligure',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        79,
        '0 Contrada Giacinta, San Malco ligure, Italy',
        'San Malco ligure',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        214,
        '763 Via Monitore, Sesto Desiderato terme, Italy',
        'Sesto Desiderato terme',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        201,
        '173 Strada Pio, Paoli laziale, Italy',
        'Paoli laziale',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        194,
        '52 Via Ludovica, Borgo Domenico, Italy',
        'Borgo Domenico',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        99,
        '8 Contrada Natali, Tufo salentino, Italy',
        'Tufo salentino',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '467 Borgo Stella, Visconti salentino, Italy',
        'Visconti salentino',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        144,
        '7 Incrocio Dutto, Settimo Nereo, Italy',
        'Settimo Nereo',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        244,
        '33 Borgo Bianco, Cirillo salentino, Italy',
        'Cirillo salentino',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        98,
        '954 Strada De Martino, Borgo Vilfredo veneto, Italy',
        'Borgo Vilfredo veneto',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        159,
        '759 Via Neoterio, Scardino lido, Italy',
        'Scardino lido',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        260,
        '3 Contrada Moffa, Sesto Valter, Italy',
        'Sesto Valter',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        185,
        '80 Rotonda Usai, San Elettra, Italy',
        'San Elettra',
        'Italy',
        'Benevento',
        ''
      );
    
  