--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: insert_hike(integer, character varying, integer, character varying, character varying, character varying, character varying, character varying, numeric, numeric, integer, character varying, jsonb, jsonb, jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hike(user_id integer, title character varying, difficulty integer, gpx_path character varying, country character varying, region character varying, province character varying, city character varying, length numeric, ascent numeric, expected_time integer, description character varying, pictures jsonb, start_point jsonb, end_point jsonb, reference_points jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $$;


--
-- Name: insert_hut(integer, double precision, double precision, integer, numeric, character varying, character varying, character varying, character varying, numeric, time without time zone, time without time zone, character varying, character varying, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut(user_id integer, lat double precision, lon double precision, number_of_beds integer, price numeric, title character varying, address character varying, owner_name character varying, website character varying, elevation numeric, working_time_start time without time zone, working_time_end time without time zone, email character varying, phone_number character varying, pictures jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber",
      "pictures"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number,
      pictures
    );
    END
    $$;


--
-- Name: insert_parking_lot(integer, double precision, double precision, character varying, integer, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_parking_lot(user_id integer, lat double precision, lon double precision, name character varying, max_cars integer, address character varying, city character varying, country character varying, region character varying, province character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: code-hike; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."code-hike" (code, "userHikeId") FROM stdin;
\.


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
1	1	0	5
1	2	100000	6
1	3	1	3
1	4	2	3
2	5	0	5
2	6	100000	6
3	7	0	5
3	8	100000	6
3	9	1	3
3	10	2	3
4	11	0	5
4	12	100000	6
4	13	1	3
4	14	2	3
5	15	0	5
5	16	100000	6
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country, condition, cause, pictures, "weatherStatus", "weatherDescription") FROM stdin;
1	2	0.90	80	20.20	2	Amprimo	Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.	/static/gpx/Amprimo.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/3.jpg"]	0	
2	2	20.20	200	23.40	1	Anello Chateau Beaulard - Cotolivier - Vazon	Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.	/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx	0.00	Piemonte	Torino	Beaulard	Italia	0		["/static/images/2.jpg"]	0	
3	2	17.00	210	18.20	2	Lago Bianco	Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.\n\nLa diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.\n\nLa Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.\n\nSi può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.	/static/gpx/Lago Bianco.gpx	0.00	Auvergne-Rhone-Alpes	Savoia	Val-Cenis	Francia	0		["/static/images/1.jpg"]	0	
4	2	6.10	200	11.90	2	Alte Langhe Settentrionali - Cossano Belbo	Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.\nSi svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.\nSi imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.\nInizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.\nPercorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. \nSeguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. \nSi procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante	/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx	0.00	Piemonte	Cuneo	Cossano Belbo	Italia	0		["/static/images/4.jpg"]	0	
5	2	5.50	225	16.60	2	La pieve romanica di Piesenzana e la valle delle tartufaie	Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. \nCirca 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. \nIn regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. \nA Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). \nContemporaneamente i ristoranti della zona propongono piatti a base di tartufi	/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx	0.00	Piemonte	Asti	Montechiaro d'Asti	Italia	0		["/static/images/5.jpg"]	0	
\.


--
-- Data for Name: hut-worker; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."hut-worker" ("userId", "hutId") FROM stdin;
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website, elevation, pictures, description, "workingTimeStart", "workingTimeEnd", "phoneNumber", email) FROM stdin;
1	17	4	60.00	Edmund-Graf-Hütte	2	Rina De Feo	http://rectangular-time.it	320.45	["/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/8385372b-a198-4990-bf79-485bf56a1a35.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg"]		07:00:00	13:00:00	+395754727792	Neoterio.Durante31@yahoo.it
2	18	3	64.00	Dr.Hernaus-Stöckl	2	Dott. Daniela Benedetto	http://responsible-complicity.com	281.31	["/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg", "/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg"]		03:00:00	19:00:00	+395238258097	Verecondo.Urso@email.it
3	19	6	107.00	Amstettner Hütte	2	Melchiade Ambrosio	https://lucky-matrix.com	286.21	["/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg", "/static/images/6a70264e-5cf3-4042-9132-6d5cf5700d45.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg"]		05:00:00	14:00:00	+397851329501	Gaetano.Bergamini@hotmail.com
4	20	7	103.00	Hochleckenhaus	2	Maurilio Visentin	http://slushy-divine.net	294.92	["/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/6a70264e-5cf3-4042-9132-6d5cf5700d45.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg"]		03:00:00	21:00:00	+391588115495	Zanita0@yahoo.com
5	21	9	64.00	Kampthalerhütte	2	Delia Cardini	https://grimy-phrasing.com	334.65	["/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg"]		02:00:00	15:00:00	+397807731607	Messalina_Moffa@email.it
6	22	6	75.00	Lambacher Hütte	2	Arianna Manna	https://monstrous-coincidence.net	324.71	["/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg", "/static/images/8385372b-a198-4990-bf79-485bf56a1a35.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg"]		07:00:00	15:00:00	+392455320499	Riccardo_Bonato@gmail.com
7	23	5	110.00	Lustenauer Hütte	2	Gianpiero Marinelli	http://failing-geology.com	279.74	["/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg", "/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg"]		04:00:00	22:00:00	+397945533604	Bassilla.Pacifico@libero.it
8	24	7	45.00	Gablonzer Hütte	2	Adelina Costantino	https://dead-cymbal.com	322.49	["/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/f65343eb-a44a-4c9c-8ce5-aceeca0ba28d.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg"]		04:00:00	22:00:00	+398506713269	Loris_Pasqua29@email.it
9	25	2	48.00	Katafygio «Flampouri»	2	Dr. Romana Venturi	http://tight-jump.org	332.80	["/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg"]		02:00:00	20:00:00	+394500151766	Guendalina70@yahoo.com
10	26	9	51.00	Simonyhütte	2	Mosè Ferraro	http://scaly-salmon.com	333.13	["/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg"]		09:00:00	21:00:00	+392817667345	Corbiniano.Gori@hotmail.com
11	27	8	37.00	Vinzenz-Tollinger-Hütte	2	Macario Nicastro	https://spiffy-mister.net	276.04	["/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg", "/static/images/50f14818-aa68-4b5e-be5f-22931483b170.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg", "/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg"]		02:00:00	22:00:00	+396274368812	Carmelo59@email.it
12	28	4	98.00	Ottokar-Kernstock-Haus	2	Dr. Serviliano Durante	https://damaged-curl.com	312.72	["/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg", "/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg"]		08:00:00	23:00:00	+391886927591	Adamo.LoGiudice@gmail.com
13	29	8	147.00	Reisseckhütte	2	Ing. Apollonia Bonini	https://sore-overheard.org	309.60	["/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg", "/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/8385372b-a198-4990-bf79-485bf56a1a35.jpg"]		01:00:00	16:00:00	+397491583206	Benigno58@yahoo.it
14	30	5	88.00	Vernagthütte	2	Ido Catanzaro	http://skeletal-tree.org	320.20	["/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg"]		07:00:00	18:00:00	+395261826458	Gaia_Bertolini19@email.it
15	31	8	95.00	Wormser Hütte	2	Antino Nanni	https://tedious-mapping.com	266.73	["/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg", "/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg"]		02:00:00	20:00:00	+398223739788	Ugo.Meli@gmail.com
16	32	10	70.00	Biberacher Hütte	2	Marcello Pisu	http://exciting-golf.net	306.57	["/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg", "/static/images/8385372b-a198-4990-bf79-485bf56a1a35.jpg", "/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg"]		05:00:00	21:00:00	+398711129992	Sandra_Pizzitola@libero.it
17	33	6	44.00	Katafygio «1777»	2	Giulitta Carletti	https://definitive-making.com	333.32	["/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg"]		01:00:00	15:00:00	+391400681708	Aurelio.Santoro24@hotmail.com
18	34	2	39.00	Hochwaldhütte	2	Norina Medugno	http://incompatible-song.org	314.62	["/static/images/fe22f025-5943-48ae-bb73-e90240e77a4b.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg", "/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg"]		03:00:00	20:00:00	+390723697529	Pio_Ragone54@yahoo.it
19	35	7	140.00	Kölner Eifelhütte	2	Adelaide Centofanti	http://reliable-scarecrow.it	280.70	["/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg"]		02:00:00	16:00:00	+392311245235	Brigitta_Casu@yahoo.it
20	36	5	104.00	Madrisahütte	2	Cassio Mastrogiacomo	http://specific-citizen.net	316.07	["/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg", "/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg", "/static/images/fe22f025-5943-48ae-bb73-e90240e77a4b.jpg"]		04:00:00	21:00:00	+396274006086	Romana.Scala@gmail.com
21	37	8	117.00	Dresdner Hütte	2	Vilfredo Mazzoleno	https://usable-stroke.org	336.69	["/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg"]		03:00:00	20:00:00	+399533594172	Cosimo50@yahoo.it
22	38	1	71.00	Fiderepasshütte	2	Brigida De Luca	http://obvious-quartz.net	328.42	["/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/f65343eb-a44a-4c9c-8ce5-aceeca0ba28d.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg"]		04:00:00	22:00:00	+393239309071	Ventura.Saba14@hotmail.com
23	39	2	93.00	Göppinger Hütte	2	Gerardo Mautone	http://appropriate-shack.it	269.93	["/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg", "/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg"]		09:00:00	17:00:00	+396644266363	Oronzo73@yahoo.it
24	40	5	142.00	Oberzalimhütte	2	Ruggero Carboni	https://unaware-brisket.com	288.69	["/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg"]		03:00:00	20:00:00	+395862992198	Clodomiro59@hotmail.com
25	41	2	77.00	Rastkogelhütte	2	Imelda Quaranta	https://sorrowful-stomach.org	306.83	["/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/f65343eb-a44a-4c9c-8ce5-aceeca0ba28d.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg"]		07:00:00	17:00:00	+398910194586	Perseo97@email.it
26	42	2	115.00	Ansbacher Skihütte im Allgäu	2	Pomponio Ross	http://outstanding-trout.com	320.40	["/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg"]		05:00:00	16:00:00	+392424545513	Abibo_Bianc@gmail.com
27	43	8	60.00	Kaltenberghütte	2	Athos Pianese	http://loathsome-immigrant.it	333.34	["/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg", "/static/images/fe22f025-5943-48ae-bb73-e90240e77a4b.jpg", "/static/images/50f14818-aa68-4b5e-be5f-22931483b170.jpg", "/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg"]		01:00:00	15:00:00	+399031396508	Telemaco_Visani@yahoo.it
28	44	8	139.00	Schweinfurter Hütte	2	Filiberto Simeone	https://thorny-connotation.net	321.45	["/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg"]		08:00:00	19:00:00	+393950275494	Agazio_Amoruso6@email.it
29	45	3	117.00	Katafygio «Vardousion»	2	Ambra Urso	http://alarming-blackboard.net	304.55	["/static/images/f65343eb-a44a-4c9c-8ce5-aceeca0ba28d.jpg", "/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg", "/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg", "/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg", "/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg"]		04:00:00	22:00:00	+392744598393	Flavio_DiSarno@email.it
30	46	8	44.00	Kocbekov dom na Korošici	2	Eros Cannella	http://incompatible-talking.net	304.88	["/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg", "/static/images/fe22f025-5943-48ae-bb73-e90240e77a4b.jpg", "/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg"]		05:00:00	21:00:00	+395722581104	Turibio.Bordoni93@email.it
31	47	6	110.00	Planinski dom Rašiške cete na Rašici	2	Teodolinda Fioravanti	http://mixed-photodiode.net	327.53	["/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg"]		04:00:00	16:00:00	+398954252696	Elda75@gmail.com
32	48	2	65.00	Prešernova koca na Stolu	2	Fatima Gennaro	https://pricey-marketplace.net	300.09	["/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg", "/static/images/6a70264e-5cf3-4042-9132-6d5cf5700d45.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg"]		08:00:00	16:00:00	+396344457682	Eusebio_Vicini@yahoo.it
33	49	1	147.00	Planinski dom na Mrzlici	2	Miranda Di Costanzo	http://joyous-multimedia.com	324.03	["/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg", "/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg"]		01:00:00	15:00:00	+398520694530	Icilio_Pisu@yahoo.it
34	50	3	126.00	Koca na Planini nad Vrhniko	2	Sidonia Vassallo	https://likely-composite.net	263.90	["/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg"]		01:00:00	21:00:00	+395940630457	Ticone79@libero.it
35	51	7	52.00	Zavetišce gorske straže na Jelencih	2	Giuseppa Calabria	http://cultured-receiver.org	307.79	["/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg"]		07:00:00	16:00:00	+391558885840	Isidora.DeAngelis66@email.it
36	52	9	146.00	Planinski dom na Gori	2	Bibiana Polimeno	http://upright-joint.org	269.37	["/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg"]		08:00:00	18:00:00	+397700078703	Liliana.Cara53@email.it
37	53	5	90.00	Bregarjevo zavetišce na planini Viševnik	2	Calpurnia Valentino	https://frivolous-politician.com	334.85	["/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/fe22f025-5943-48ae-bb73-e90240e77a4b.jpg", "/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg"]		03:00:00	20:00:00	+399191851212	Oreste.Ciccone@yahoo.it
38	54	8	132.00	Koca pod Bogatinom	2	Virginio Motta	https://growling-herbs.org	306.16	["/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg"]		03:00:00	10:00:00	+394031856995	Porziano_Marchesini10@gmail.com
39	55	3	63.00	Pogacnikov dom na Kriških podih	2	Arturo Marini	https://violent-gerbil.org	288.68	["/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg", "/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg"]		05:00:00	21:00:00	+396466794411	Genoveffa71@gmail.com
40	56	9	85.00	Dom na Smrekovcu	2	Protasio Raimondi	http://impressionable-associate.it	269.51	["/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg"]		03:00:00	19:00:00	+393054448149	Loreno_Pierro@yahoo.it
41	57	5	49.00	Refuge Du Chatelleret	2	Iginia Savini	http://poised-corporal.it	303.65	["/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg", "/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg", "/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg", "/static/images/8385372b-a198-4990-bf79-485bf56a1a35.jpg"]		06:00:00	19:00:00	+397330885743	Cristaldo.Mastropietro@hotmail.com
42	58	10	71.00	Refuge De Chalance	2	Vincenzo Bianchi	https://knotty-coconut.it	318.96	["/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/fe22f025-5943-48ae-bb73-e90240e77a4b.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg"]		06:00:00	17:00:00	+395671837560	Raniero.Principato@hotmail.com
43	59	8	50.00	Refuge Des Bans	2	Edilberto Napolitano	https://evil-dictator.org	260.41	["/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg", "/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg"]		02:00:00	09:00:00	+395361713848	Abbondio_Frau@hotmail.com
44	60	6	128.00	Refuge De Pombie	2	Elisabetta Pardini	http://dapper-opinion.com	263.08	["/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg", "/static/images/8385372b-a198-4990-bf79-485bf56a1a35.jpg", "/static/images/fe22f025-5943-48ae-bb73-e90240e77a4b.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg"]		05:00:00	11:00:00	+394274115427	Abele_Barile17@yahoo.com
45	61	8	87.00	Refuge De Larribet	2	Michele Zotti	http://troubled-essence.net	323.81	["/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg"]		09:00:00	23:00:00	+390371252005	Delia21@yahoo.it
46	62	7	110.00	Refuge Du Mont Pourri	2	Ing. Fabrizio Fornara	http://lively-foal.net	317.03	["/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg", "/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg"]		07:00:00	14:00:00	+390593239229	Ercolano_Nuzzo2@email.it
47	63	3	143.00	Refuge De La Dent D?Oche	2	Leonilda Salatiello	https://unsung-jet.net	300.49	["/static/images/50f14818-aa68-4b5e-be5f-22931483b170.jpg", "/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/f65343eb-a44a-4c9c-8ce5-aceeca0ba28d.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg"]		06:00:00	14:00:00	+397277756364	Dione_DiBari17@gmail.com
48	64	3	88.00	Bergseehütte SAC	2	Lia Coslovich	https://excellent-neonate.it	269.33	["/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg", "/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg"]		02:00:00	16:00:00	+394090048678	Olinda_Carlino39@yahoo.it
49	65	8	39.00	Bivouac au Col de la Dent Blanche CAS	2	Eleonora Carlucci	http://open-canvas.it	275.43	["/static/images/50f14818-aa68-4b5e-be5f-22931483b170.jpg", "/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg", "/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg"]		09:00:00	17:00:00	+393105044541	Delfino_Barbero@libero.it
50	66	3	141.00	Salbitschijenbiwak SAC	2	Dr. Azeglio Sassi	https://frivolous-utilisation.it	298.94	["/static/images/8385372b-a198-4990-bf79-485bf56a1a35.jpg", "/static/images/fe22f025-5943-48ae-bb73-e90240e77a4b.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg", "/static/images/50f14818-aa68-4b5e-be5f-22931483b170.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg"]		09:00:00	17:00:00	+393148519263	Eustosio.Pica@libero.it
51	67	6	68.00	Spannorthütte SAC	2	Sig. Viliana Petrucci	http://pricey-poster.net	327.75	["/static/images/50f14818-aa68-4b5e-be5f-22931483b170.jpg", "/static/images/6a70264e-5cf3-4042-9132-6d5cf5700d45.jpg", "/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg"]		09:00:00	22:00:00	+390251055986	Didimo68@gmail.com
52	68	9	146.00	Cabane Arpitettaz CAS	2	Teodoto Visentin	http://studious-explorer.com	270.74	["/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg", "/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/8385372b-a198-4990-bf79-485bf56a1a35.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg"]		07:00:00	22:00:00	+398524172465	Soccorso92@yahoo.it
53	69	8	145.00	Refugio De Lizara	2	Nerea Fanelli	http://different-quality.com	273.79	["/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg"]		09:00:00	20:00:00	+395646768126	Livia.Petito72@gmail.com
54	70	8	147.00	Albergue De Montfalcó	2	Giacobbe Potenza	https://belated-gold.net	267.21	["/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg", "/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg", "/static/images/f65343eb-a44a-4c9c-8ce5-aceeca0ba28d.jpg"]		08:00:00	15:00:00	+396995795466	Anita_Furlan60@yahoo.it
55	71	7	54.00	El Molonillo/Peña Partida	2	Lia Castelli	https://profitable-imbalance.it	309.30	["/static/images/8385372b-a198-4990-bf79-485bf56a1a35.jpg", "/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg"]		08:00:00	22:00:00	+397221157821	Palladio.Dalmasso@hotmail.com
56	72	2	117.00	La Campiñuela	2	Macaria Meli	https://vague-men.it	313.56	["/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/fe22f025-5943-48ae-bb73-e90240e77a4b.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg"]		03:00:00	19:00:00	+392040436138	Porzia91@gmail.com
57	73	9	129.00	Titov Vrv	2	Azzurra Cardinali	http://tricky-bamboo.it	339.95	["/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg", "/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg"]		03:00:00	18:00:00	+390438450334	Gennaro69@email.it
58	74	6	45.00	Rifugio Franchetti	2	Quintilio Serafino	http://immense-survival.com	334.50	["/static/images/f65343eb-a44a-4c9c-8ce5-aceeca0ba28d.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg", "/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg", "/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg"]		04:00:00	11:00:00	+396399529850	Beatrice.Menegatti@libero.it
59	75	10	61.00	Rifugio Semenza	2	Sig. Remo Mazzaro	http://unwilling-attack.it	263.32	["/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg", "/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/50f14818-aa68-4b5e-be5f-22931483b170.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg"]		05:00:00	14:00:00	+397699541374	Nicla65@email.it
60	76	2	41.00	Rifugio Città di Mortara 	2	Sirio Cancelliere	https://broken-sweatshop.org	337.42	["/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg", "/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg", "/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg", "/static/images/6a70264e-5cf3-4042-9132-6d5cf5700d45.jpg"]		05:00:00	19:00:00	+397176808310	Aleandro_Padovan@yahoo.com
61	77	7	102.00	Rifugio Andolla	2	Messalina Rosa	http://immaterial-wetland.org	280.69	["/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg", "/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg", "/static/images/50f14818-aa68-4b5e-be5f-22931483b170.jpg", "/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg"]		06:00:00	23:00:00	+397545922092	Demostene.Pacifici@yahoo.com
62	78	3	47.00	Rifugio Forte dei Marmi	2	Solange Iandolo	http://tricky-detail.com	333.12	["/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg", "/static/images/f65343eb-a44a-4c9c-8ce5-aceeca0ba28d.jpg", "/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg"]		09:00:00	19:00:00	+399451845650	Armando.DiGiacomo@yahoo.it
63	79	8	87.00	Rifugio Berti	2	Ing. Tiziana Pesce	https://wide-eyed-pencil.net	335.98	["/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/6a70264e-5cf3-4042-9132-6d5cf5700d45.jpg", "/static/images/fe22f025-5943-48ae-bb73-e90240e77a4b.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg"]		05:00:00	14:00:00	+399239004547	Fosco.Tilotta@email.it
64	80	10	96.00	Rifugio Premuda	2	Onorio Ratti	http://previous-kazoo.com	314.87	["/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg", "/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg"]		05:00:00	18:00:00	+399233150672	Petronilla_Guerriero8@email.it
65	81	1	110.00	Rifugio Elisa	2	Liana Borghi	https://genuine-attacker.org	296.34	["/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/fe22f025-5943-48ae-bb73-e90240e77a4b.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/f65343eb-a44a-4c9c-8ce5-aceeca0ba28d.jpg", "/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg"]		03:00:00	13:00:00	+390492761256	Simona_Scanu90@yahoo.it
66	82	1	44.00	Rifugio CAI Saronno	2	Oreste Salatiello	http://clear-bubble.com	330.27	["/static/images/50f14818-aa68-4b5e-be5f-22931483b170.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg"]		09:00:00	23:00:00	+392129081416	Zita_Moccia45@gmail.com
67	83	5	122.00	Rifugio Picco Ivigna	2	Baldovino Militello	http://amused-mesenchyme.org	315.87	["/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/6a70264e-5cf3-4042-9132-6d5cf5700d45.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg"]		05:00:00	23:00:00	+391924816828	Sostene81@gmail.com
68	84	8	117.00	Rifugio Toesca	2	Gioberto Verde	http://damp-woodshed.it	266.86	["/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/50f14818-aa68-4b5e-be5f-22931483b170.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg"]		06:00:00	12:00:00	+399267470603	Aristofane.Epifani@gmail.com
69	85	10	147.00	Rifugio Al Cedo	2	Dr. Corrado Adragna	http://sneaky-follower.net	317.93	["/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/50f14818-aa68-4b5e-be5f-22931483b170.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg"]		02:00:00	16:00:00	+395440829633	Leopardo.Marsili41@libero.it
70	86	7	90.00	Capanna Gnifetti	2	Flaviana Dolce	http://feline-ascend.com	300.58	["/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg"]		02:00:00	13:00:00	+391961262027	Ottilia.Cacciapuoti4@email.it
71	87	2	149.00	Rifugio Aosta	2	Ivano Marchesini	http://limited-mound.org	269.02	["/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg", "/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg", "/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg"]		07:00:00	20:00:00	+398690853254	Lucio21@gmail.com
72	88	10	96.00	Rifugio Cevedale	2	Dott. Ampelio Demurtas	https://automatic-layout.org	307.58	["/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg"]		04:00:00	20:00:00	+399679305673	Onorino_Cannata@yahoo.com
73	89	3	80.00	Rifugio Ponti	2	Asella Navarra	http://awful-meatball.net	273.65	["/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg"]		01:00:00	09:00:00	+398785291994	Cronida12@yahoo.com
74	90	3	118.00	Rifugio XII Apostoli	2	Fiammetta Biasci	https://treasured-eyeglasses.it	266.43	["/static/images/f65343eb-a44a-4c9c-8ce5-aceeca0ba28d.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg", "/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg", "/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg"]		05:00:00	22:00:00	+393228497675	Torquato34@yahoo.com
75	91	5	128.00	Rifugio Elisabetta Soldini	2	Rosalia Ciulla	https://forked-collapse.it	316.54	["/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg"]		02:00:00	13:00:00	+399471715082	Cecilio88@yahoo.com
76	92	5	144.00	Rifugio Denza	2	Adalberta Ferrarotti	https://secondary-dagger.org	294.64	["/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg"]		08:00:00	20:00:00	+396383664967	Eufemio68@yahoo.com
77	93	3	91.00	Rifugio Fonte Tavoloni 	2	Tullia De Marco	https://relieved-aunt.com	280.08	["/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg", "/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg"]		08:00:00	21:00:00	+392494044519	Archippo.Festuccia@hotmail.com
78	94	6	136.00	Rifugio Carducci	2	Antonella Avola	http://best-half-sister.org	316.69	["/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/6a70264e-5cf3-4042-9132-6d5cf5700d45.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg"]		02:00:00	15:00:00	+396418682546	Leopoldo_Palladino38@yahoo.com
79	95	2	109.00	Rifugio Bindesi	2	Angelica Valli	http://questionable-minion.net	280.03	["/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg", "/static/images/fe22f025-5943-48ae-bb73-e90240e77a4b.jpg", "/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg"]		02:00:00	11:00:00	+392930301334	Apuleio82@yahoo.com
80	96	8	81.00	Mountain hut Miroslav Hirtz	2	Orsola Eligibile	https://quick-phosphate.org	334.95	["/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg"]		02:00:00	22:00:00	+394114366530	Michela47@libero.it
81	97	6	91.00	Koca na Blegošu	2	Monitore Zennaro	http://cooked-hacienda.org	309.22	["/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg", "/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg"]		04:00:00	15:00:00	+399625611407	Tosco.Caputo@yahoo.com
82	98	1	87.00	Wittener Hütte	2	Cristina Riolo	http://glamorous-crazy.com	281.14	["/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg"]		08:00:00	20:00:00	+398167069025	Acario26@libero.it
83	99	8	101.00	Hochjoch-Hospiz	2	Edmondo Saba	https://humiliating-font.it	297.05	["/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg", "/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/6a70264e-5cf3-4042-9132-6d5cf5700d45.jpg"]		02:00:00	22:00:00	+390240604649	Nerea.Maggi@yahoo.it
84	100	5	73.00	Meilerhütte	2	Desiderata Bertolini	http://serene-meatball.com	328.40	["/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg"]		04:00:00	13:00:00	+396120647435	Isidora.Sechi33@yahoo.com
85	101	10	147.00	Gaudeamushütte	2	Telica Tammaro	http://worthwhile-waterfront.net	271.91	["/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg", "/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg"]		08:00:00	22:00:00	+395671674258	Ercolano_Cusimano26@yahoo.com
86	102	2	64.00	Rheydter Hütte	2	Dott. Vito Matta	https://political-productivity.com	261.52	["/static/images/8385372b-a198-4990-bf79-485bf56a1a35.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg", "/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg", "/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg"]		08:00:00	16:00:00	+391830946913	Clelia.Castelli@gmail.com
87	103	7	95.00	Sektionshütte Krippen	2	Romeo Manzi	https://cumbersome-polenta.com	306.96	["/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg"]		02:00:00	11:00:00	+398653087172	Secondiano.Costantino15@libero.it
88	104	4	121.00	Neunkirchner Hütte	2	Nicoletta Castiello	http://few-shearling.it	319.35	["/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg"]		07:00:00	20:00:00	+390471295509	Osvaldo_Huber@yahoo.it
89	105	3	125.00	Refugio De Riglos	2	Siricio Cardia	http://prize-member.org	311.39	["/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/8385372b-a198-4990-bf79-485bf56a1a35.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg"]		03:00:00	20:00:00	+396951264947	Odidone77@gmail.com
90	106	3	70.00	Salbithütte SAC	2	Balderico Martina	https://lonely-rheumatism.com	284.25	["/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg"]		03:00:00	11:00:00	+398912077268	Mancio92@yahoo.it
91	107	1	48.00	Finsteraarhornhütte SAC	2	Serviliano Campoli	https://smug-hour.org	285.72	["/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg"]		08:00:00	21:00:00	+391012498796	Giada_Vita@hotmail.com
92	108	6	85.00	Cabane des Vignettes CAS	2	Ettore Russo	https://cool-athletics.net	304.99	["/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/f65343eb-a44a-4c9c-8ce5-aceeca0ba28d.jpg"]		07:00:00	21:00:00	+396346619342	Bellino89@gmail.com
93	109	2	132.00	Glecksteinhütte SAC	2	Omar Surace	https://ripe-treasury.it	305.61	["/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg", "/static/images/fe22f025-5943-48ae-bb73-e90240e77a4b.jpg", "/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg"]		09:00:00	16:00:00	+392737872715	Senofonte54@libero.it
94	110	4	64.00	Länta-Hütte SAC	2	Sig. Mauro Agresta	https://noxious-burrito.net	324.53	["/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/8385372b-a198-4990-bf79-485bf56a1a35.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg"]		02:00:00	13:00:00	+395301641023	Iole.DiPasquale0@hotmail.com
95	111	8	63.00	Monte-Leone-Hütte SAC	2	Venere Macchi	https://adorable-menorah.org	261.53	["/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg", "/static/images/6a70264e-5cf3-4042-9132-6d5cf5700d45.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg"]		08:00:00	15:00:00	+396040524239	Fidenziano.Doronzo9@libero.it
96	112	9	57.00	Ringelspitzhütte SAC	2	Isabella Giuffrida	https://deadly-transparency.com	294.98	["/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg", "/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg", "/static/images/f65343eb-a44a-4c9c-8ce5-aceeca0ba28d.jpg", "/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg"]		07:00:00	21:00:00	+392809748786	Virgilio_Canino72@hotmail.com
97	113	9	138.00	Na poljanama Maljen	2	Azelia Ferluga	http://accurate-hip.com	292.46	["/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg", "/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg"]		01:00:00	16:00:00	+391137987163	Leonilda_Gervasi32@yahoo.com
98	114	6	109.00	Dobra voda	2	Delfino Degano	https://untried-atrium.it	290.95	["/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg", "/static/images/f65343eb-a44a-4c9c-8ce5-aceeca0ba28d.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg"]		09:00:00	20:00:00	+399556084010	Elimena14@gmail.com
99	115	9	77.00	Ivanova hiža	2	Silvana Croce	http://dense-commonsense.it	316.96	["/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/a3981850-c374-4df8-b4fa-fd0a45e792d9.jpg", "/static/images/50f14818-aa68-4b5e-be5f-22931483b170.jpg", "/static/images/6a70264e-5cf3-4042-9132-6d5cf5700d45.jpg"]		04:00:00	21:00:00	+392118409333	Piero.Montesano@hotmail.com
100	116	10	47.00	Glavica	2	Carla Izzi	http://delayed-hole.com	287.65	["/static/images/50f14818-aa68-4b5e-be5f-22931483b170.jpg", "/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg", "/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg", "/static/images/cc4a93ec-3d1f-417b-9461-19b9e6551baf.jpg", "/static/images/5ef4af60-2fd8-4e33-8ba3-1c9bae14ef40.jpg"]		09:00:00	17:00:00	+392799337710	Domenico.Bernasconi@yahoo.com
101	117	2	37.00	Trpošnjik	2	Ludovica Chimenti	http://focused-toad.net	274.41	["/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/1b64f961-0a54-4913-a68a-778f516656ab.jpg", "/static/images/738a6797-cfcd-43e5-ab47-bb313f8a6bb1.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg"]		08:00:00	16:00:00	+399807881095	Emiliana30@yahoo.it
102	118	1	134.00	Bitorajka	2	Concordio Nesti	https://rectangular-terrapin.it	272.18	["/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg", "/static/images/be3a6f67-2252-4d9c-a933-cfbcfea550a5.jpg"]		08:00:00	19:00:00	+399563932746	Ruggero98@email.it
103	119	6	73.00	Zlatko Prgin	2	Dr. Ondina Doria	https://kindly-shanty.net	336.12	["/static/images/6a70264e-5cf3-4042-9132-6d5cf5700d45.jpg", "/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg", "/static/images/dc743b27-eb1f-4826-847a-b7080facf86b.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/fe22f025-5943-48ae-bb73-e90240e77a4b.jpg"]		03:00:00	11:00:00	+395884393987	Mauro.Schirru@hotmail.com
104	120	7	98.00	Prpa	2	Pompeo De Vita	http://incomparable-editing.it	307.36	["/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/79e187b9-ce38-4035-9f0b-edaa80db43fb.jpg", "/static/images/8385372b-a198-4990-bf79-485bf56a1a35.jpg", "/static/images/b17c707b-c476-4422-80a0-294859ac6273.jpg", "/static/images/09b228a0-1092-4714-ada7-8ce52c095062.jpg"]		02:00:00	13:00:00	+396936500324	Zita_Tornatore75@libero.it
105	121	1	59.00	Ždrilo	2	Ortensio Mastropietro	https://lawful-broccoli.it	334.26	["/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/900ae2a9-9160-4b08-b23e-6b38cb53ad78.jpg", "/static/images/0e541f52-1406-436b-a551-b7f7d203e8ad.jpg", "/static/images/9ecd5b9c-fe42-4479-93b3-b0d2351263c2.jpg", "/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg"]		02:00:00	08:00:00	+399131900542	Quasimodo.Barsotti90@yahoo.com
106	122	9	55.00	Miroslav Hirtz	2	Deodato Verme	https://sour-seizure.net	311.38	["/static/images/f2ac0eef-8f2e-41ec-ae52-707ef5bbd95f.jpg", "/static/images/039f20a7-4adb-4ddb-9d86-b65e3a2f4a47.jpg", "/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/0d32e35b-f201-4b53-825b-43b27b9184bf.jpg", "/static/images/9ebc9431-a1b3-43df-8f7e-2c8ee819ec35.jpg"]		09:00:00	23:00:00	+395984435971	Elogio17@yahoo.com
107	123	6	52.00	Jezerce	2	Callisto Federico	http://posh-catalysis.com	264.74	["/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg", "/static/images/cc34b29d-ea3d-44e5-bd40-90dbf32cf51c.jpg", "/static/images/f65343eb-a44a-4c9c-8ce5-aceeca0ba28d.jpg", "/static/images/3b8aa0ec-e3bd-4a33-8b9e-819e05317198.jpg", "/static/images/68eaaebe-4859-464d-a7ba-9b5a3af4aaf1.jpg"]		02:00:00	22:00:00	+398250034060	Ninfa33@yahoo.it
108	124	10	106.00	Ivica Sudnik	2	Penelope Saccone	https://essential-scrambled.org	327.39	["/static/images/87477b17-d535-4a18-8da7-82cfa754b6cd.jpg", "/static/images/d093eb1d-29ff-4c08-a4c1-65e5b4fd9584.jpg", "/static/images/6ae26599-528c-4e00-8f8b-2336773d2d1b.jpg", "/static/images/e30c136c-6081-454c-b131-e39d5a6c0483.jpg", "/static/images/dc5e06dd-2cd6-473c-82e3-68ae5befaef0.jpg"]		07:00:00	15:00:00	+395587134092	Tolomeo.Gatta44@hotmail.com
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
1	125	72	2	Italy	Reggio Emilia		Benigna lido
2	126	109	2	Italy	Chieti		Settimo Fazio
3	127	63	2	Italy	Frosinone		Tomaselli veneto
4	128	288	2	Italy	Pistoia		Borgo Altea calabro
5	129	114	2	Italy	Isernia		Micillo ligure
6	130	258	2	Italy	Como		Settimo Agostina terme
7	131	93	2	Italy	Vicenza		Acilio umbro
8	132	83	2	Italy	Ogliastra		Sesto Piersilvio
9	133	51	2	Italy	Catania		Scolastica laziale
10	134	183	2	Italy	Vicenza		Pallotta calabro
11	135	211	2	Italy	Bari		Unna del friuli
12	136	186	2	Italy	Macerata		Erico ligure
13	137	57	2	Italy	Vercelli		Gautiero veneto
14	138	142	2	Italy	Padova		Ernesto veneto
15	139	291	2	Italy	Catanzaro		Borgo Violante
16	140	32	2	Italy	Barletta-Andria-Trani		San Gillo veneto
17	141	150	2	Italy	Benevento		Settimo Cherubino
18	142	65	2	Italy	Caserta		Francese del friuli
19	143	150	2	Italy	Grosseto		San Damocle ligure
20	144	265	2	Italy	Siena		Borgo Sabato
21	145	145	2	Italy	Rieti		Dionisio sardo
22	146	25	2	Italy	Terni		Settimo Clemenzia umbro
23	147	6	2	Italy	Carbonia-Iglesias		Giraudo veneto
24	148	40	2	Italy	Cuneo		Quarto Catullo laziale
25	149	67	2	Italy	Frosinone		Bassani sardo
26	150	232	2	Italy	Pisa		Mina salentino
27	151	69	2	Italy	Ogliastra		Sesto Davide sardo
28	152	270	2	Italy	Gorizia		San Zenobia a mare
29	153	131	2	Italy	Rimini		Quarto Balderico ligure
30	154	102	2	Italy	Verbano-Cusio-Ossola		Unna del friuli
31	155	176	2	Italy	Modena		San Asia veneto
32	156	73	2	Italy	Gorizia		Lovato ligure
33	157	229	2	Italy	Lodi		Sesto Rutilo lido
34	158	5	2	Italy	Palermo		Sesto Renato
35	159	32	2	Italy	Terni		Morrone terme
36	160	38	2	Italy	Sondrio		Borgo Ataleo
37	161	126	2	Italy	Biella		San Tabita salentino
38	162	82	2	Italy	Lecco		San Monica
39	163	300	2	Italy	Trapani		Sesto Temistocle sardo
40	164	278	2	Italy	Roma		Cittadino sardo
41	165	20	2	Italy	Nuoro		Sesto Veneranda calabro
42	166	127	2	Italy	Parma		Settimo Giotto
43	167	84	2	Italy	Catanzaro		Quarto Otilia umbro
44	168	88	2	Italy	Belluno		Settimo Menardo
45	169	37	2	Italy	Caserta		Quarto Desiderio nell'emilia
46	170	259	2	Italy	Mantova		San Nicodemo
47	171	174	2	Italy	Mantova		Romoaldo laziale
48	172	161	2	Italy	Trieste		Rago a mare
49	173	90	2	Italy	Perugia		Borgo Cristoforo
50	174	280	2	Italy	Belluno		Spizzirri veneto
51	175	42	2	Italy	Biella		Borgo Palladio
52	176	11	2	Italy	Verbano-Cusio-Ossola		Bino veneto
53	177	239	2	Italy	Cremona		Sesto Enimia lido
54	178	8	2	Italy	Sassari		Sansone laziale
55	179	236	2	Italy	Como		Quarto Delia lido
56	180	45	2	Italy	Pisa		San Guerrino
57	181	127	2	Italy	Catanzaro		Virginio laziale
58	182	268	2	Italy	Brescia		Sesto Vasco
59	183	270	2	Italy	Reggio Emilia		Borgo Romola
60	184	30	2	Italy	Torino		Benvenuti ligure
61	185	219	2	Italy	Benevento		Murolo sardo
62	186	276	2	Italy	Messina		Borgo Cosma terme
63	187	209	2	Italy	Napoli		Quarto Fidenzio
64	188	77	2	Italy	Campobasso		Quarto Adelgardo umbro
65	189	215	2	Italy	Catanzaro		Viviano calabro
66	190	198	2	Italy	Benevento		Pasini sardo
67	191	137	2	Italy	Reggio Calabria		Adamo nell'emilia
68	192	33	2	Italy	Lodi		Ermenegildo calabro
69	193	232	2	Italy	Ascoli Piceno		La Sala lido
70	194	15	2	Italy	Rovigo		Monica salentino
71	195	172	2	Italy	Genova		San Ulpiano umbro
72	196	281	2	Italy	Reggio Emilia		Settimo Ippocrate laziale
73	197	234	2	Italy	Ascoli Piceno		Quarto Leonia
74	198	135	2	Italy	Medio Campidano		Fleano del friuli
75	199	161	2	Italy	Rimini		Valerico laziale
76	200	186	2	Italy	Lecco		Varriale nell'emilia
77	201	110	2	Italy	Pavia		Settimo Orietta
78	202	288	2	Italy	Pisa		Pellegrini salentino
79	203	152	2	Italy	Bergamo		Sesto Tamara
80	204	159	2	Italy	Bolzano		Fiordaliso laziale
81	205	39	2	Italy	Ascoli Piceno		San Tiziano
82	206	295	2	Italy	Napoli		Sesto Secondina del friuli
83	207	220	2	Italy	Teramo		Quarto Ilaria calabro
84	208	27	2	Italy	Roma		Sesto Italia lido
85	209	295	2	Italy	Piacenza		San Isacco a mare
86	210	90	2	Italy	Reggio Calabria		Quasimodo nell'emilia
87	211	25	2	Italy	Crotone		Colella lido
88	212	247	2	Italy	Cagliari		Bianchini lido
89	213	171	2	Italy	Ancona		Sesto Apollonia
90	214	35	2	Italy	Benevento		Borgo Giulio
91	215	263	2	Italy	Foggia		Lippi del friuli
92	216	256	2	Italy	Savona		Carlotti a mare
93	217	109	2	Italy	Arezzo		Daidone umbro
94	218	46	2	Italy	Caserta		Quarto Italo del friuli
95	219	196	2	Italy	Salerno		San Averardo salentino
96	220	187	2	Italy	Verona		Rosalia ligure
97	221	268	2	Italy	Piacenza		Adalardo sardo
98	222	135	2	Italy	Trieste		Aiace lido
99	223	229	2	Italy	Palermo		Fernando lido
100	224	276	2	Italy	Pescara		Alberico terme
101	225	201	2	Italy	Enna		Roma
102	226	137	2	Italy	Sondrio		Eliano umbro
103	227	49	2	Italy	Foggia		Salvadori calabro
104	228	91	2	Italy	Enna		Gianotti a mare
105	229	210	2	Italy	Carbonia-Iglesias		Borgo Alina
106	230	247	2	Italy	Cremona		Sebastiana a mare
107	231	197	2	Italy	Pescara		Sesto Immacolato veneto
108	232	87	2	Italy	Rovigo		Proteo nell'emilia
109	233	293	2	Italy	Bergamo		Sesto Siro
110	234	189	2	Italy	Trapani		Borgo Nicola
111	235	120	2	Italy	Rovigo		Borgo Galatea
112	236	286	2	Italy	Trieste		San Catullo calabro
113	237	233	2	Italy	Novara		Leale veneto
114	238	134	2	Italy	Viterbo		Iride veneto
115	239	133	2	Italy	Campobasso		Quarto Gianni nell'emilia
116	240	157	2	Italy	Verona		Settimo Salom�
117	241	237	2	Italy	Bolzano		Pantano del friuli
118	242	59	2	Italy	Savona		Quarto Rossana
119	243	178	2	Italy	Prato		Biasci ligure
120	244	80	2	Italy	Barletta-Andria-Trani		San Alfreda
121	245	81	2	Italy	Benevento		Girardo calabro
122	246	90	2	Italy	Treviso		Pacifici calabro
123	247	132	2	Italy	Modena		Benigna lido
124	248	288	2	Italy	Firenze		Cecchi ligure
125	249	33	2	Italy	Oristano		Greco lido
126	250	258	2	Italy	Ancona		Savino a mare
127	251	1	2	Italy	Cremona		Sesto Casto nell'emilia
128	252	32	2	Italy	Oristano		Giacomelli sardo
129	253	116	2	Italy	Viterbo		Ambra lido
130	254	1	2	Italy	Lecco		San Tiziana ligure
131	255	1	2	Italy	Crotone		Giardini sardo
132	256	54	2	Italy	Massa-Carrara		San Attilio
133	257	259	2	Italy	Latina		Oggiano sardo
134	258	253	2	Italy	Chieti		Baldi salentino
135	259	34	2	Italy	Matera		Violi nell'emilia
136	260	147	2	Italy	Cremona		San Sabrina a mare
137	261	1	2	Italy	Fermo		Alcina lido
138	262	1	2	Italy	Potenza		Amedeo terme
139	263	203	2	Italy	Olbia-Tempio		San Giotto
140	264	1	2	Italy	La Spezia		Sesto Desiderato terme
141	265	131	2	Italy	Lecce		Quarto Lia
142	266	70	2	Italy	Reggio Calabria		Clemente calabro
143	267	47	2	Italy	Latina		Borgo Ilia terme
144	268	107	2	Italy	Pordenone		Settimo Serafino terme
145	269	258	2	Italy	Parma		Sesto Bertolfo a mare
146	270	196	2	Italy	Asti		Settimo Leontina calabro
147	271	279	2	Italy	Perugia		Dianora lido
148	272	70	2	Italy	Perugia		Loreno calabro
149	273	285	2	Italy	Latina		Settimo Cupido ligure
150	274	194	2	Italy	Sassari		Degna veneto
151	275	164	2	Italy	Ascoli Piceno		Borgo Cesario
152	276	73	2	Italy	La Spezia		Marzia sardo
153	277	47	2	Italy	Pordenone		Latini sardo
154	278	90	2	Italy	Salerno		Damiano calabro
155	279	291	2	Italy	Cuneo		Scrofani salentino
156	280	251	2	Italy	Asti		Quarto Ramiro nell'emilia
157	281	101	2	Italy	Messina		Orchidea umbro
158	282	235	2	Italy	Rovigo		Giove ligure
159	283	294	2	Italy	Ravenna		San Catena lido
160	284	64	2	Italy	Forlì-Cesena		Baldassarre salentino
161	285	172	2	Italy	Venezia		Rachele sardo
162	286	153	2	Italy	Brescia		Di Giovanni nell'emilia
163	287	187	2	Italy	Cuneo		Sesto Adelgardo
164	288	65	2	Italy	Vicenza		Borgo Gaspare terme
165	289	111	2	Italy	Fermo		Borgo Elvia a mare
166	290	30	2	Italy	Parma		Piccoli nell'emilia
167	291	203	2	Italy	Venezia		Quarto Valentino
168	292	284	2	Italy	Matera		Madonna nell'emilia
169	293	214	2	Italy	Gorizia		Sesto Lavinio veneto
170	294	27	2	Italy	Barletta-Andria-Trani		Panico lido
171	295	192	2	Italy	Lucca		Borgo Carlo
172	296	134	2	Italy	Cremona		Mautone calabro
173	297	300	2	Italy	Mantova		Gallicano a mare
174	298	64	2	Italy	Reggio Emilia		Macaria lido
175	299	201	2	Italy	Brindisi		Quarto Neopolo a mare
176	300	44	2	Italy	Roma		Lattanzi lido
177	301	219	2	Italy	Ascoli Piceno		Soro sardo
178	302	216	2	Italy	Reggio Calabria		Settimo Dagoberto
179	303	233	2	Italy	Novara		Fortugno lido
180	304	69	2	Italy	Modena		Maffeo lido
181	305	86	2	Italy	Brindisi		San Averardo laziale
182	306	69	2	Italy	Caltanissetta		Peleo calabro
183	307	6	2	Italy	Piacenza		Sesto Flavio a mare
184	308	245	2	Italy	Massa-Carrara		Lendinara
185	309	225	2	Italy	Chieti		Pollione a mare
186	310	124	2	Italy	Novara		Napoli
187	311	107	2	Italy	Reggio Calabria		Borgo Guiberto
188	312	80	2	Italy	Terni		Minervino salentino
189	313	56	2	Italy	Prato		Vicinanza umbro
190	314	143	2	Italy	Isernia		De Giorgio calabro
191	315	142	2	Italy	Cagliari		Elita laziale
192	316	200	2	Italy	Siracusa		San Michela
193	317	300	2	Italy	Cosenza		Eutalia salentino
194	318	181	2	Italy	Modena		Cittadino calabro
195	319	214	2	Italy	Agrigento		Mastropietro laziale
196	320	195	2	Italy	Trapani		Petrarca nell'emilia
197	321	129	2	Italy	Bologna		Sesto Iago ligure
198	322	257	2	Italy	Trento		Aiace lido
199	323	167	2	Italy	Roma		Settimo Valeriano
200	324	189	2	Italy	Caserta		Settimo Romero
201	325	158	2	Italy	Novara		San Silvia
202	326	118	2	Italy	Cremona		Settimo Ausiliatrice
203	327	410	2	Italy	Pordenone		Settimo Giliola
204	328	26	2	Italy	Avellino		Tarantino salentino
205	329	137	2	Italy	Potenza		Quarto Michela
206	330	223	2	Italy	Pavia		Settimo Damiano sardo
207	331	277	2	Italy	L'Aquila		Quarto Lucia ligure
208	332	102	2	Italy	Perugia		Genna ligure
209	333	68	2	Italy	Lodi		Borgo Mariella
210	334	208	2	Italy	Bari		Gioacchina ligure
211	335	230	2	Italy	Enna		Gumesindo laziale
212	336	82	2	Italy	Novara		Quarto Giotto veneto
213	337	9	2	Italy	Benevento		De Simone laziale
214	338	40	2	Italy	Isernia		Cipriano terme
215	339	128	2	Italy	Alessandria		Sesto Elita
216	340	146	2	Italy	Barletta-Andria-Trani		Settimo Egidio del friuli
217	341	270	2	Italy	Ancona		Adalberto lido
218	342	300	2	Italy	Torino		Lodovica umbro
219	343	115	2	Italy	Reggio Emilia		Alice umbro
220	344	256	2	Italy	Catania		Alma veneto
221	345	200	2	Italy	Brescia		Sesto Anita umbro
222	346	3	2	Italy	Alessandria		Grieco sardo
223	347	123	2	Italy	Campobasso		Bonavita a mare
224	348	212	2	Italy	Teramo		Natali lido
225	349	98	2	Italy	Reggio Emilia		Sesto Regolo
226	350	277	2	Italy	Campobasso		Almerigo a mare
227	351	156	2	Italy	Brindisi		Quarto Bardomiano terme
228	352	31	2	Italy	Brindisi		Settimo Milo
229	353	177	2	Italy	Ancona		Neopolo a mare
230	354	187	2	Italy	Belluno		San Desiderato
231	355	295	2	Italy	Aosta		Sesto Celinia
232	356	229	2	Italy	Bologna		Quarto Costante
233	357	125	2	Italy	Oristano		Settimo Tiziana
234	358	134	2	Italy	Agrigento		Sesto Idea
235	359	62	2	Italy	Ogliastra		San Olga ligure
236	360	195	2	Italy	Enna		Quarto Guerrino
237	361	163	2	Italy	Oristano		Quarto Calanico
238	362	209	2	Italy	Mantova		Giovanna lido
239	363	244	2	Italy	Savona		Surace terme
240	364	157	2	Italy	La Spezia		Di Gaetano terme
241	365	183	2	Italy	Trento		Sesto Bernardo
242	366	123	2	Italy	Ogliastra		Marcello veneto
243	367	106	2	Italy	Nuoro		Cleopatra laziale
244	368	277	2	Italy	Brescia		Beniamina umbro
245	369	60	2	Italy	Brindisi		Settimo Ferruccio del friuli
246	370	193	2	Italy	Prato		Borgo Rufo
247	371	240	2	Italy	La Spezia		Pesce del friuli
248	372	115	2	Italy	Palermo		Borgo Zosima
249	373	221	2	Italy	Lecco		Rucco salentino
250	374	9	2	Italy	Ferrara		Borgo Ecclesio a mare
251	375	219	2	Italy	Verbano-Cusio-Ossola		Sesto Guiscardo umbro
252	376	256	2	Italy	Cuneo		Cornelia lido
253	377	273	2	Italy	Messina		Aldo umbro
254	378	118	2	Italy	Venezia		Zanetti a mare
255	379	46	2	Italy	Perugia		Semiramide a mare
256	380	159	2	Italy	Carbonia-Iglesias		Sesto Colombo calabro
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address, altitude) FROM stdin;
1	0	0101000020E610000043D95E8288A91C40720950EB278D4640	Start Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
2	0	0101000020E610000051A7B8816D921C408D966B20C98C4640	End Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
3	0	0101000020E6100000C668CC0D4EA81C40DA8DB03B2C8D4640		Ref Point 1	1256.85
4	0	0101000020E6100000116FE90D01A21C4022DFF1622B8D4640		Ref Point 2	1283.61
5	0	0101000020E61000004337FB03E5161B401CEBE2361A844640	Start Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
6	0	0101000020E61000001092054CE0161B401FD8F15F20844640	End Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
7	0	0101000020E610000058CB9D9960C81B408731E9EFA59C4640	Start Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
8	0	0101000020E61000003BE0BA6246C81B401E34BBEEAD9C4640	End Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
9	0	0101000020E61000007EE4D6A4DBC21B40147AFD497C9C4640		fountain	2027.00
10	0	0101000020E6100000B7B8C667B2BF1B4090A4A487A19B4640		Peak	2131.00
11	0	0101000020E61000005F9A22C0E96520406C76A4FACE554640	Start Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
12	0	0101000020E61000002368CC24EA652040CC7EDDE9CE554640	End Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
13	0	0101000020E61000006B662D05A46D20401557957D57564640		Ref Point 1	482.53
14	0	0101000020E610000024D236FE44652040813D26529A554640		Ref Point 2	242.59
15	0	0101000020E61000009F3E027FF83920409E245D33F9804640	Start Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
16	0	0101000020E610000099F56228273A20408DEDB5A0F7804640	End Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
17	0	0101000020E61000002D64979723B62440C66F2527958D4740	Edmund-Graf-Hütte	6574 Pettneu am Arlberg, Tyrol, Austria	\N
18	0	0101000020E6100000455BF9D0380E2A4056DBD4F478794740	Dr.Hernaus-Stöckl	9020 Klagenfurt, Kärnten, Austria	\N
19	0	0101000020E61000003AD4CD22968A2D406DAF4FF575F14740	Amstettner Hütte	3340 Waidhofen an der Ybbs, Niederösterreich, Austria	\N
20	0	0101000020E61000003470C88518362B404F23C0A11DEA4740	Hochleckenhaus	4853 Steinbach am Attersee, Oberösterreich, Austria	\N
21	0	0101000020E6100000745CA7EA5C3230400E95C9F10B114840	Kampthalerhütte	2384 Breitenfurt bei Wien, Niederösterreich, Austria	\N
22	0	0101000020E610000059E5350827672B402FB2862AC2D34740	Lambacher Hütte	4822 Bad Goisern, Oberösterreich, Austria	\N
23	0	0101000020E610000019FDD2643FA62340662869A087B24740	Lustenauer Hütte	6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria	\N
24	0	0101000020E610000036849931B0F52A4014BD78F039C44740	Gablonzer Hütte	4825 Gosau-Hintertal, Oberösterreich, Austria	\N
25	0	0101000020E6100000202F5A3629BF3740D489BAC5B2144340	Katafygio «Flampouri»	136 72 Acharnes, Attica region, Greece	\N
26	0	0101000020E6100000103E4BA24D3F2B40F731169C1AC04740	Simonyhütte	4830 Hallstatt, Oberösterreich, Austria	\N
27	0	0101000020E610000033190145D5182740BF9048EBDFA04740	Vinzenz-Tollinger-Hütte	6060 Hall in Tirol, Tyrol, Austria	\N
28	0	0101000020E61000001F1E0B5901B82E4091BFCBF1EAB34740	Ottokar-Kernstock-Haus	8600 Bruck an der Mur, Steiermark, Austria	\N
29	0	0101000020E610000018E4FB977DBF2A40D6A3B4422D754740	Reisseckhütte	9814 Mühldorf, Mölltal, Kärnten, Austria	\N
30	0	0101000020E61000007B116DC7D4A52540C0401020436D4740	Vernagthütte	Austria	\N
31	0	0101000020E6100000286211C30EF323407EC9C6832D884740	Wormser Hütte	Austria	\N
32	0	0101000020E6100000999CDA19A60E24406CD097DEFEA04740	Biberacher Hütte	Austria	\N
33	0	0101000020E610000007BC276AC4133740DDF934DDA1A84440	Katafygio «1777»	620 55 Kerkini, Central Macedonia region, Greece	\N
34	0	0101000020E6100000D5AF743E3C0B2A40E6E786A6EC704840	Hochwaldhütte	Germany	\N
35	0	0101000020E6100000C2FBAA5CA8EC19408FC536A968544940	Kölner Eifelhütte	Germany	\N
36	0	0101000020E6100000323CF6B358D223401763601DC7794740	Madrisahütte	Austria	\N
37	0	0101000020E6100000313F373465472640CDC98B4CC07F4740	Dresdner Hütte	Austria	\N
38	0	0101000020E6100000CDCCCCCCCC6C24403E07962364A84740	Fiderepasshütte	Germany	\N
39	0	0101000020E6100000B727486C77172440A9DDAF027C9B4740	Göppinger Hütte	Austria	\N
40	0	0101000020E6100000A379008BFC622340C7629B54348A4740	Oberzalimhütte	Austria	\N
41	0	0101000020E610000013B70A62A0932740B3B45373B99D4740	Rastkogelhütte	Austria	\N
42	0	0101000020E61000009D2D20B41E0E2440D54F49E70DC24740	Ansbacher Skihütte im Allgäu	Germany	\N
43	0	0101000020E610000009E066F16249244097E13FDD408F4740	Kaltenberghütte	Austria	\N
44	0	0101000020E61000000AD7A3703D0A2640E277D32D3B944740	Schweinfurter Hütte	Austria	\N
45	0	0101000020E61000006DC438245A213640DA172BC5E9574340	Katafygio «Vardousion»	330 53 Delphi, Central Greece region, Greece	\N
46	0	0101000020E6100000630F270F8F472D40336D62F5852D4740	Kocbekov dom na Korošici	3334 Luče, Mozirje, Slovenia	\N
47	0	0101000020E6100000D1F5D08072062D40D25C9F20CE114740	Planinski dom Rašiške cete na Rašici	1211 Ljubljana, Šmartno, Slovenia	\N
48	0	0101000020E6100000F70F966F85592C40971550C935374740	Prešernova koca na Stolu	4274 Žirovnica, Slovenia	\N
49	0	0101000020E6100000AA5C8F5FCB372E408E6CD71919184740	Planinski dom na Mrzlici	3302 Griže, Slovenia	\N
50	0	0101000020E6100000651A4D2EC6802C40577A6D3656FC4640	Koca na Planini nad Vrhniko	1360 Vrhnika, Slovenia	\N
51	0	0101000020E6100000245DF94DDD322C4077DAB7E6D0144740	Zavetišce gorske straže na Jelencih	0, -, Slovenia	\N
52	0	0101000020E6100000313F3734656F2E406F7F2E1A32264740	Planinski dom na Gori	Šentjungert, 3310 Žalec, Slovenia	\N
53	0	0101000020E610000098F2E7FC90A22B40C7CBA2C928274740	Bregarjevo zavetišce na planini Viševnik	4265 Bohinjsko jezero, Slovenia	\N
54	0	0101000020E610000091860959CC862B401635F33FD4244740	Koca pod Bogatinom	4265 Bohinjsko jezero, Slovenia	\N
55	0	0101000020E6100000678B3942E5992B40007F639573334740	Pogacnikov dom na Kriških podih	5232 Soca, Slovenia	\N
56	0	0101000020E610000008F580BBE4CC2D402A9C0F95E7344740	Dom na Smrekovcu	3325 Šoštanj, Slovenia	\N
57	0	0101000020E610000073F6CE68AB32194060E811A3E77C4640	Refuge Du Chatelleret	38520 Saint Christophe En Oisans, Isère, France	\N
58	0	0101000020E610000084622B685AF218408177F2E9B16B4640	Refuge De Chalance	5800 La Chapelle En Valgaudemar, Hautes-Alpes, France	\N
59	0	0101000020E6100000963D096CCE711940AE7FD767CE6A4640	Refuge Des Bans	5290 Vallouise, Hautes-Alpes, France	\N
60	0	0101000020E6100000DEAB5626FC52DBBFAED689CBF16A4540	Refuge De Pombie	65400 Laruns, Pyrénées-Atlantiques, France	\N
61	0	0101000020E6100000A69C2FF65E7CD2BFA9F92AF9D86D4540	Refuge De Larribet	65400 Arrens, Marsous, Hautes-Pyrénées, France	\N
62	0	0101000020E61000009CA6CF0EB84E1B401232906797C34640	Refuge Du Mont Pourri	73210 Peisey Nancroix, Savoie, France	\N
63	0	0101000020E6100000C712D6C6D8E91A40BF81C98D222D4740	Refuge De La Dent D?Oche	74500 Bernex, Haute-Savoie, France	\N
64	0	0101000020E6100000BEBDCA2243F820405620D41E27544740	Bergseehütte SAC	Uri, Switzerland	\N
65	0	0101000020E6100000CDD5732CA96D1E40F591820D5C054740	Bivouac au Col de la Dent Blanche CAS	Wallis, Switzerland	\N
66	0	0101000020E610000060F1FE571F0C2140D6BA5B328C564740	Salbitschijenbiwak SAC	Uri, Switzerland	\N
67	0	0101000020E610000084EAC5BE53052140F224048A5C664740	Spannorthütte SAC	Uri, Switzerland	\N
68	0	0101000020E6100000827FB24EBCB71E406113E452EB0C4740	Cabane Arpitettaz CAS	Wallis, Switzerland	\N
69	0	0101000020E61000008A75AA7CCF48E4BF588BF447BD614540	Refugio De Lizara	22730, Aragón, Spain	\N
70	0	0101000020E6100000AE56C01909F8E43F58DB5E1CA6064540	Albergue De Montfalcó	22585 Tolva, Aragón, Spain	\N
71	0	0101000020E61000000A4CFFBF1E610AC08B780953B6904240	El Molonillo/Peña Partida	18160 Güejar Sierra, Andalucía, Spain	\N
72	0	0101000020E610000029110100A92D0AC0F39F054F27844240	La Campiñuela	18417 Trévelez, Andalucía, Spain	\N
73	0	0101000020E61000008E79782A3BCC3440BEAE152301FF4440	Titov Vrv	Tetovo, Municipality of Tetovo, North Macedonia	\N
74	0	0101000020E6100000A2EC2DE57C212B40C7F143A5113D4540	Rifugio Franchetti	Pietracamela, Abruzzo, Italy	\N
75	0	0101000020E610000052E2299ABDFA2840518B1C7D27114740	Rifugio Semenza	Tambre, Veneto, Italy	\N
76	0	0101000020E6100000A197F67244A31F40313D06D094EE4640	Rifugio Città di Mortara 	Alagna Valsesia, Piemonte, Italy	\N
77	0	0101000020E61000006E39F29B1D242040AB1ED555260C4740	Rifugio Andolla	Antrona Schieranico, Piemonte, Italy	\N
78	0	0101000020E61000000AD80E46ECAB2440B70BCD751AFF4540	Rifugio Forte dei Marmi	Stazzema, Toscana, Italy	\N
79	0	0101000020E6100000A88B14CAC2CF284038D66AB4C1504740	Rifugio Berti	Comelico Superiore, Veneto, Italy	\N
80	0	0101000020E610000071B43E4052BB2B406FE70CD649CF4640	Rifugio Premuda	San Dorligo della Valle, Friuli Venezia Giulia, Italy	\N
81	0	0101000020E61000006CCF2C0950C32240191BBAD91FF84640	Rifugio Elisa	Mandello del Lario, Lombardia, Italy	\N
82	0	0101000020E6100000A5BDC11726B31F40F90FE9B7AFFB4640	Rifugio CAI Saronno	Macugnaga, Piemonte, Italy	\N
83	0	0101000020E610000098DD9387857A2640A930B610E4584740	Rifugio Picco Ivigna	Scena, Trentino Alto Adige, Italy	\N
84	0	0101000020E61000003AE97DE36B8F1C404AEF1B5F7B8A4640	Rifugio Toesca	Bussoleno, Piemonte, Italy	\N
85	0	0101000020E6100000A913D044D8E02040382D78D1570C4740	Rifugio Al Cedo	Santa Maria Maggiore, Piemonte, Italy	\N
86	0	0101000020E6100000449D5ECE11661F4009ED8B3A29F34640	Capanna Gnifetti	Gressoney La Trinitè, Valle d?Aosta, Italy	\N
87	0	0101000020E6100000B8AE9811DE3E1E403A048E041AFC4640	Rifugio Aosta	Bionaz, Valle d?Aosta, Italy	\N
88	0	0101000020E6100000BBB31B22135525408EA8F523EA374740	Rifugio Cevedale	Pejo, Trentino Alto Adige, Italy	\N
89	0	0101000020E61000000D33349E08722340F0A485CB2A204740	Rifugio Ponti	Val Masino, Lombardia, Italy	\N
90	0	0101000020E6100000C46D7E0DD2B125405364085B47134740	Rifugio XII Apostoli	Stenico, Trentino Alto Adige, Italy	\N
91	0	0101000020E61000009F1C058882591B40DDD1FF722DE24640	Rifugio Elisabetta Soldini	Courmayeur, Valle d?Aosta, Italy	\N
92	0	0101000020E610000061D57994804F25409903A4C1291F4740	Rifugio Denza	Vermiglio, Trentino Alto Adige, Italy	\N
93	0	0101000020E61000000C1F115322F92A40338AE596560F4540	Rifugio Fonte Tavoloni 	Ovindoli, Abruzzo, Italy	\N
94	0	0101000020E610000037C2A2224EBF2840F2ED5D83BE4E4740	Rifugio Carducci	Auronzo di Cadore, Veneto, Italy	\N
95	0	0101000020E61000006FA53220D64E26400DE02D90A0044740	Rifugio Bindesi	Trento, Trentino Alto Adige, Italy	\N
96	0	0101000020E610000001C11C3D7ECB2D40C670D0B9365A4640	Mountain hut Miroslav Hirtz	53287 Jablanac, Ličko-senjska županija, Croatia	\N
97	0	0101000020E6100000398485EEED352C4098331D324C154740	Koca na Blegošu	4224 Gorenja vas, Slovenia	\N
98	0	0101000020E610000040F850A225BF1F400F441669E2594940	Wittener Hütte	Germany	\N
99	0	0101000020E610000000FDBE7FF3AA25409A99999999694740	Hochjoch-Hospiz	Austria	\N
100	0	0101000020E6100000D7A02FBDFD412640CDCCCCCCCCB44740	Meilerhütte	Germany	\N
101	0	0101000020E610000050C422861DA628406E85B01A4BC64740	Gaudeamushütte	Austria	\N
102	0	0101000020E6100000179CC1DF2F961940D5EB1681B15C4940	Rheydter Hütte	Germany	\N
103	0	0101000020E6100000FB66518EB8562C4057E883656C744940	Sektionshütte Krippen	Germany	\N
104	0	0101000020E61000001F7A839D234C2C40B45EF68814A34740	Neunkirchner Hütte	2620 Neunkirchen, Steiermark, Austria	\N
105	0	0101000020E61000009CE379FC2043E7BF8FC536A9682C4540	Refugio De Riglos	22808, Aragón, Spain	\N
106	0	0101000020E6100000563D4FC4941A2140EBB308E997564740	Salbithütte SAC	Uri, Switzerland	\N
107	0	0101000020E61000001D55C855B23A2040B8EB64DCCE424740	Finsteraarhornhütte SAC	Wallis, Switzerland	\N
108	0	0101000020E6100000DEFD765E1AE71D4038777A52B2FE4640	Cabane des Vignettes CAS	Wallis, Switzerland	\N
109	0	0101000020E6100000E769EE0B84312040FBE19FAF02504740	Glecksteinhütte SAC	Bern, Switzerland	\N
110	0	0101000020E6100000752B5D3C5F152240D9971BDB51454740	Länta-Hütte SAC	Graubünden, Switzerland	\N
111	0	0101000020E610000055ADDEFA26292040BAB9F14860214740	Monte-Leone-Hütte SAC	Wallis, Switzerland	\N
112	0	0101000020E6100000557F0CE8F9C222408F373B25D26E4740	Ringelspitzhütte SAC	Graubünden, Switzerland	\N
113	0	0101000020E6100000A4AA09A2EE0334408E23D6E253104640	Na poljanama Maljen	Maljen, Serbia	\N
114	0	0101000020E6100000A9DE1AD82A313440C5E6E3DA50114640	Dobra voda	Suvobor, Serbia	\N
115	0	0101000020E61000007250C24CDBFF2E402D095053CBC64640	Ivanova hiža	Karlovac town environment, Karlovačka, Croatia	\N
116	0	0101000020E6100000C6DCB5847CC02F40C746205ED7EB4640	Glavica	Medvednica, City of Zagreb, Croatia	\N
117	0	0101000020E6100000FFEC478AC8B83040D3F6AFAC34BD4540	Trpošnjik	Mosor, Splitsko-dalmatinska, Croatia	\N
118	0	0101000020E6100000C217265305932D40C4CE143AAFA54640	Bitorajka	Bitoraj, Primorsko-goranska, Croatia	\N
119	0	0101000020E6100000AB09A2EE0360304006D847A7AE084640	Zlatko Prgin	Dinara, Šibensko-kninska, Croatia	\N
120	0	0101000020E6100000D3872EA86F492E405C8FC2F528444640	Prpa	Velebit, Ličko-senjska, Croatia	\N
121	0	0101000020E6100000787FBC57AD5C2E408BFD65F7E43D4640	Ždrilo	Velebit, Ličko-senjska, Croatia	\N
122	0	0101000020E610000086032159C0F42D40B21188D7F59B4640	Miroslav Hirtz	Velika Kapela, Primorsko-goranska, Croatia	\N
123	0	0101000020E6100000A31EA2D11DAC3140462575029AC04640	Jezerce	Papuk, Požeško-slavonska, Croatia	\N
124	0	0101000020E61000003EE8D9ACFA4C2F405F0CE544BBE24640	Ivica Sudnik	Samoborska gora, Zagrebačka, Croatia	\N
125	0	0101000020E6100000AD3BCC4D8A7D2840CBDF185D39124640		76 Contrada Zito, Benigna lido, Italy	\N
126	0	0101000020E6100000AF5E454607602340EDF2AD0FEB6B4440		38 Strada Ildebrando, Settimo Fazio, Italy	\N
127	0	0101000020E610000050BA3EBD63AA2840D5DBB0B7DE294640		90 Rotonda Casano, Tomaselli veneto, Italy	\N
128	0	0101000020E6100000E7204322C8042640F6AEE6A507F54540		8 Via Adone, Borgo Altea calabro, Italy	\N
129	0	0101000020E61000009F11B6E919B02140ABAC12D154364640		856 Piazza Guglielmi, Micillo ligure, Italy	\N
130	0	0101000020E61000009EBFBFF7ED2224402DAAEA8ABEE84640		386 Rotonda Massimo, Settimo Agostina terme, Italy	\N
131	0	0101000020E6100000FF209221C76E274017844DF8002D4640		2 Contrada Lautone, Acilio umbro, Italy	\N
132	0	0101000020E6100000C2B28817FA8E2340D5809C8B1AB04640		6 Rotonda Marian, Sesto Piersilvio, Italy	\N
133	0	0101000020E6100000107BFC3960762540600A6A53D0274740		5 Strada Riccarda, Scolastica laziale, Italy	\N
134	0	0101000020E6100000CF5AC0BAE0462B40B9ED314745E34640		7 Via Tobia, Pallotta calabro, Italy	\N
135	0	0101000020E610000048B42E7FCFC525403379B93E620B4740		756 Contrada Zefiro, Unna del friuli, Italy	\N
136	0	0101000020E6100000E066F16261B42A4084E85AC52CF04640		69 Via Bonavita, Erico ligure, Italy	\N
137	0	0101000020E610000021263CFC90E62840C604EBEEF0074640		96 Contrada Grossi, Gautiero veneto, Italy	\N
138	0	0101000020E6100000CFB81567B161274070CFF3A78DA74640		508 Strada Zena, Ernesto veneto, Italy	\N
139	0	0101000020E6100000C1F979F8D76F224054F0CAE48AB04640		9 Borgo Angelucci, Borgo Violante, Italy	\N
140	0	0101000020E61000008248D0A975782B40741200D2EDC94640		698 Borgo Padula, San Gillo veneto, Italy	\N
141	0	0101000020E6100000918B208436172940630E828E564E4540		42 Contrada Vulpiano, Settimo Cherubino, Italy	\N
142	0	0101000020E610000023484A1F5F572240D37CDF09072C4640		23 Via Iacolare, Francese del friuli, Italy	\N
143	0	0101000020E6100000A09339F130542140F7DBE8ADCB384740		8 Via Panaro, San Damocle ligure, Italy	\N
144	0	0101000020E6100000068A0E37967A2540DB1FDE29D3664540		6 Piazza Cardini, Borgo Sabato, Italy	\N
145	0	0101000020E6100000CF59B09EA4CE2640F18288D4B4434740		8 Borgo Fabio, Dionisio sardo, Italy	\N
146	0	0101000020E6100000C153C8957A5A26407541D8840FE14640		87 Incrocio Cerise, Settimo Clemenzia umbro, Italy	\N
147	0	0101000020E61000008577B988EF302140BAD3426E2B3D4740		45 Rotonda Salerno, Giraudo veneto, Italy	\N
148	0	0101000020E6100000589643E6259E2540B49487E013DD4540		223 Borgo Doroteo, Quarto Catullo laziale, Italy	\N
149	0	0101000020E6100000249E4720B9702840B1F84D61A5124640		912 Strada Callisto, Bassani sardo, Italy	\N
150	0	0101000020E61000008B89CDC7B55926407EB4EED57D084740		38 Strada Simona, Mina salentino, Italy	\N
151	0	0101000020E6100000D8B969334EEB27402CF8C84164804540		607 Contrada Coppola, Sesto Davide sardo, Italy	\N
152	0	0101000020E610000061D394AEAAD4204012A6835039FC4640		32 Borgo Ingrassia, San Zenobia a mare, Italy	\N
153	0	0101000020E6100000B53C6AA741AC27408F0134A550B84640		003 Via Morrone, Quarto Balderico ligure, Italy	\N
154	0	0101000020E6100000F78CE9AE91D52240ED48F59D5FE54640		6 Borgo Iodice, Unna del friuli, Italy	\N
155	0	0101000020E6100000626DE75663902B4097FA1E9A1ED44640		2 Contrada Salemme, San Asia veneto, Italy	\N
156	0	0101000020E6100000FFF9C78C011B2640DD706946501E4740		895 Rotonda Semiramide, Lovato ligure, Italy	\N
157	0	0101000020E61000009C363EEEB67E2740BC2363B5F9BA4640		34 Contrada Pusicio, Sesto Rutilo lido, Italy	\N
158	0	0101000020E61000008A9466F3387C1E402B31CF4A5AE74640		7 Incrocio Rosario, Sesto Renato, Italy	\N
159	0	0101000020E6100000F22895F084D22A404082870E26ED4440		4 Rotonda Aristione, Morrone terme, Italy	\N
160	0	0101000020E61000007E1D386744712240C878399105CC4640		16 Rotonda Nigro, Borgo Ataleo, Italy	\N
161	0	0101000020E610000020D84C1993812240A475AFEEB30D4740		203 Contrada Grieco, San Tabita salentino, Italy	\N
162	0	0101000020E6100000242136FD7E2E26406E2AF7A7F91A4740		4 Borgo Margherita, San Monica, Italy	\N
163	0	0101000020E6100000485E8C37E8B927408860C1A2C7CA4640		57 Incrocio Onorata, Sesto Temistocle sardo, Italy	\N
164	0	0101000020E61000005E961BB1BB751E407379BD4571EF4640		93 Piazza Lorena, Cittadino sardo, Italy	\N
165	0	0101000020E6100000BE2ABC708CED2340366964A1E7DD4640		47 Borgo Boni, Sesto Veneranda calabro, Italy	\N
166	0	0101000020E610000053B4722F302B2540E4DC26DC2B4D4740		045 Piazza Graziani, Settimo Giotto, Italy	\N
167	0	0101000020E61000009A97C3EE3B32254052B241CB5F574640		3 Piazza Ilario, Quarto Otilia umbro, Italy	\N
168	0	0101000020E6100000622D3E05C0782840F70BD17C29DE4640		6 Incrocio Di Fiore, Settimo Menardo, Italy	\N
169	0	0101000020E6100000B05758703F782440773A4668BAB84640		56 Borgo Marta, Quarto Desiderio nell'emilia, Italy	\N
170	0	0101000020E610000011D20957F63B2640E6B8AEF3CA084740		29 Contrada Marangoni, San Nicodemo, Italy	\N
171	0	0101000020E61000004704E3E0D2692C408514F2F741A74640		682 Via Caterino, Romoaldo laziale, Italy	\N
172	0	0101000020E61000002F0ACC54D2C8264038FE9F1E36CA4640		369 Borgo Licitra, Rago a mare, Italy	\N
173	0	0101000020E610000046E80C31035E29405A46EA3D95E54640		761 Piazza Murgia, Borgo Cristoforo, Italy	\N
174	0	0101000020E6100000E4F90CA8376B2340ABA3F496BC5E4440		301 Contrada Fior, Spizzirri veneto, Italy	\N
175	0	0101000020E6100000967DB2BD71ED26406F7319EDA7C14640		12 Strada Terzo, Borgo Palladio, Italy	\N
176	0	0101000020E6100000FC68DDABFB5427401073EE1B04334740		37 Rotonda Gaspare, Bino veneto, Italy	\N
177	0	0101000020E610000069965F611C5B2540B52792F991CA4540		6 Rotonda Evaristo, Sesto Enimia lido, Italy	\N
178	0	0101000020E6100000B4C6455ACF692740D8C523A765B04640		543 Incrocio Girardo, Sansone laziale, Italy	\N
179	0	0101000020E61000003B843B61D3CC1E40935742D202D44640		9 Contrada Passeri, Quarto Delia lido, Italy	\N
180	0	0101000020E6100000C03FA54A9455284094347F4C6BE54640		920 Contrada Fortunata, San Guerrino, Italy	\N
181	0	0101000020E610000003FBF900EEEB1E40FA6184F068EE4640		505 Contrada Fernanda, Virginio laziale, Italy	\N
182	0	0101000020E610000007681140209E2640B177352F3D9D4640		0 Rotonda Savini, Sesto Vasco, Italy	\N
183	0	0101000020E6100000525F96766AFE23402A7C6C81F3EE4640		58 Rotonda Giorgia, Borgo Romola, Italy	\N
184	0	0101000020E61000007319EDA7B5EF1E400B1060EC18EC4640		922 Rotonda Annagrazia, Benvenuti ligure, Italy	\N
185	0	0101000020E6100000F86B578DCA1A284015E06014A9B14640		01 Borgo Antigone, Murolo sardo, Italy	\N
186	0	0101000020E6100000D634947FD2A12740811A081390584540		29 Incrocio Ramiro, Borgo Cosma terme, Italy	\N
187	0	0101000020E61000009D63E53C08EA2640B7FB0BF3D4DC4540		048 Piazza Addo, Quarto Fidenzio, Italy	\N
188	0	0101000020E6100000EA0E18DAEF9B2B40948444DAC6764640		51 Incrocio Cesario, Quarto Adelgardo umbro, Italy	\N
189	0	0101000020E610000014BCD7FFEFC62640BA66F2CD36DE4640		0 Borgo Primo, Viviano calabro, Italy	\N
190	0	0101000020E610000009168733BFBE27405D4E098849354540		52 Rotonda Menardo, Pasini sardo, Italy	\N
191	0	0101000020E6100000462AE7E6763A2940ABB8CC446CE14440		659 Piazza Servidio, Adamo nell'emilia, Italy	\N
192	0	0101000020E610000075EED176A7F62640A7F97486F3B24640		845 Via Balderico, Ermenegildo calabro, Italy	\N
193	0	0101000020E6100000F9A23D5E48F727405789C3E3ECE04640		7 Strada Tralli, La Sala lido, Italy	\N
194	0	0101000020E6100000731A587D64FD294065FED13769E64540		24 Incrocio Mariani, Monica salentino, Italy	\N
195	0	0101000020E6100000ABC5F18D322421407D1FB3582FFA4640		845 Incrocio Zito, San Ulpiano umbro, Italy	\N
196	0	0101000020E610000035D252793B0228403A79ECC26AEA4640		481 Rotonda Sibilla, Settimo Ippocrate laziale, Italy	\N
197	0	0101000020E6100000DD730580CFD02640F16261889CD44640		916 Piazza Tina, Quarto Leonia, Italy	\N
198	0	0101000020E61000006531564046E12040530E1C8645E74640		40 Contrada Teodosio, Fleano del friuli, Italy	\N
199	0	0101000020E610000026B8A2DE9D5E2740311A434AFDDC4640		232 Piazza Volpe, Valerico laziale, Italy	\N
200	0	0101000020E61000000A5BFD22B27524407121EA99B95B4640		8 Incrocio Genoveffa, Varriale nell'emilia, Italy	\N
201	0	0101000020E6100000C132DBBA40CE2240D0EFFB372F274740		821 Strada Cantagallo, Settimo Orietta, Italy	\N
202	0	0101000020E6100000CA558737C6B91F40EB79ED88F9BD4640		02 Contrada Denti, Pellegrini salentino, Italy	\N
203	0	0101000020E61000006AEE320DD4F324401D098F9147B14640		379 Piazza Odetta, Sesto Tamara, Italy	\N
204	0	0101000020E610000044053D8A291B2140F0FACC599F5A4440		56 Piazza Picariello, Fiordaliso laziale, Italy	\N
205	0	0101000020E61000002B1D07B9E6212040F08C11E4FBF04640		3 Piazza Pitzalis, San Tiziano, Italy	\N
206	0	0101000020E61000007BEDE3B21BB727403464E190B2DD4640		247 Incrocio Camelia, Sesto Secondina del friuli, Italy	\N
207	0	0101000020E6100000D8E9ACBB1EE91F40A0A932E774D04640		42 Strada Massimiliano, Quarto Ilaria calabro, Italy	\N
208	0	0101000020E61000009C8136DEC21B294063731FCA61894540		868 Strada Barone, Sesto Italia lido, Italy	\N
209	0	0101000020E6100000E3B08FA91680204076A0F3BF01E94640		88 Piazza Proietti, San Isacco a mare, Italy	\N
210	0	0101000020E6100000EE6EAF16E9832340C6F0225D7DCC4640		724 Contrada Sisto, Quasimodo nell'emilia, Italy	\N
211	0	0101000020E6100000D81D41E037B02140C2F1214D61C54440		1 Piazza Atanasio, Colella lido, Italy	\N
212	0	0101000020E6100000A807BB174E80284061BC8B9C2AD94640		497 Incrocio Zelinda, Bianchini lido, Italy	\N
213	0	0101000020E6100000FD18CE9085A322406C9CA80073DB4640		7 Rotonda Carola, Sesto Apollonia, Italy	\N
214	0	0101000020E6100000E39F635122672540E113A1C7DEDE4640		002 Rotonda Giordano, Borgo Giulio, Italy	\N
215	0	0101000020E610000098231A93B47928409916500361674640		8 Piazza Nicodemo, Lippi del friuli, Italy	\N
216	0	0101000020E6100000ABBCD3539A032740A544B7031AEF4640		610 Incrocio Carmela, Carlotti a mare, Italy	\N
217	0	0101000020E61000001E424B0D239B2440D8D1DD1A7DA04640		1 Incrocio Ionne, Daidone umbro, Italy	\N
218	0	0101000020E6100000CF2CAE96E0891F405EB642FDD3234640		4 Rotonda Guida, Quarto Italo del friuli, Italy	\N
219	0	0101000020E6100000D7BDBACF96BC254007205AD020C34640		191 Piazza Morello, San Averardo salentino, Italy	\N
220	0	0101000020E6100000C96BCABA24832740A97E4A3A6FE54640		275 Incrocio Euseo, Rosalia ligure, Italy	\N
221	0	0101000020E6100000A8DAB80F8AC32940DF67017F9D1A4540		28 Borgo Valeriano, Adalardo sardo, Italy	\N
222	0	0101000020E6100000C272DFC556972640A4271BC528D24640		9 Rotonda Montagna, Aiace lido, Italy	\N
223	0	0101000020E61000005F306E5974411E40EC3F21F1E13A4740		854 Piazza Antonio, Fernando lido, Italy	\N
224	0	0101000020E61000006C109CE9142628401760C4E347124740		71 Incrocio Avallone, Alberico terme, Italy	\N
225	0	0101000020E610000044EC0214D9FD284012AC600AC5EE4440		120 Via Cristoforo Colombo, Roma, Italy	\N
226	0	0101000020E6100000B0FECF61BEF827406DFD99E6C2F24640		2 Rotonda Damiano, Eliano umbro, Italy	\N
227	0	0101000020E6100000EBB76576CCAF26407B8FE9BFBD424640		98 Contrada Claudia, Salvadori calabro, Italy	\N
228	0	0101000020E6100000D6479682247220407379BD4571084740		137 Borgo Alvaro, Gianotti a mare, Italy	\N
229	0	0101000020E610000097900F7A36872040AB251DE560074740		3 Rotonda Incoronata, Borgo Alina, Italy	\N
230	0	0101000020E61000000DABD3DC65C22740D32F116F9DE34640		0 Borgo Florio, Sebastiana a mare, Italy	\N
231	0	0101000020E61000009FEE97AA0FCF27402834FF9E0E024740		301 Rotonda Girolamo, Sesto Immacolato veneto, Italy	\N
232	0	0101000020E6100000E417B90265622C40EFC0A50815E24440		6 Via Moffa, Proteo nell'emilia, Italy	\N
233	0	0101000020E6100000B2463D44A37B2540F3C011EEDF764540		1 Borgo Buongiorno, Sesto Siro, Italy	\N
234	0	0101000020E6100000B6B0B84956A326409DC2A5BE87334740		997 Piazza Macchia, Borgo Nicola, Italy	\N
235	0	0101000020E6100000D56C2FB319AD2840823C16365EC04640		382 Incrocio Generosa, Borgo Galatea, Italy	\N
236	0	0101000020E610000076583C5002EE1E40E0CCF9731BE14640		72 Strada Senofonte, San Catullo calabro, Italy	\N
237	0	0101000020E6100000470EC7A98CC52840B6A73F564BE04640		9 Contrada Tufano, Leale veneto, Italy	\N
238	0	0101000020E61000004DC00A4B97B91F4005C1E3DBBBF84540		81 Rotonda Cuzzocrea, Iride veneto, Italy	\N
239	0	0101000020E610000059EB7A585E182740106D1162780E4640		982 Rotonda Miriam, Quarto Gianni nell'emilia, Italy	\N
240	0	0101000020E610000051D9B0A6B2581F4089B7CEBF5DE14640		835 Piazza Bernadetta, Settimo Salom�, Italy	\N
241	0	0101000020E6100000AD7603BB504F27406049A8CFC4374640		42 Incrocio Beniamino, Pantano del friuli, Italy	\N
242	0	0101000020E61000004692C5A28EF72640D32934B511794640		17 Piazza Apollo, Quarto Rossana, Italy	\N
243	0	0101000020E6100000068B790C45182740C3CB1D47BD774640		25 Incrocio Rotolo, Biasci ligure, Italy	\N
244	0	0101000020E61000005CC0159A35C620401880A1A245F44640		2 Strada Murolo, San Alfreda, Italy	\N
245	0	0101000020E6100000FA2D9512DD7227409453967C47234640		830 Incrocio Lucarelli, Girardo calabro, Italy	\N
246	0	0101000020E61000008ECD8E54DFA12B403562C1583A2D4540		31 Rotonda Maura, Pacifici calabro, Italy	\N
247	0	0101000020E610000020651FBF127F254034C06092257F4640		64 Strada Odorico, Benigna lido, Italy	\N
248	0	0101000020E610000064BB31F3D36E22404F401361C3C24640		87 Strada Onorata, Cecchi ligure, Italy	\N
249	0	0101000020E6100000D160AEA0C47E2240E41824D813C04640		928 Borgo Vezio, Greco lido, Italy	\N
250	0	0101000020E61000006FD8B628B3B91E40086465EA64D64640		3 Strada Eufrasia, Savino a mare, Italy	\N
251	0	0101000020E610000016CDB9CAC93E2140BC0E8B074A744640		23 Borgo Emiliana, Sesto Casto nell'emilia, Italy	\N
252	0	0101000020E6100000B4064A65E54A274026DAFA8E86E14640		72 Via Di Santo, Giacomelli sardo, Italy	\N
253	0	0101000020E61000000736F80CF26822405273034F6B9C4640		6 Borgo Merola, Ambra lido, Italy	\N
254	0	0101000020E6100000DF6124C511412140D11CFE3FF3744640		85 Incrocio Ferrando, San Tiziana ligure, Italy	\N
255	0	0101000020E610000077ED77CD50412140CB243493B9744640		655 Strada Bindo, Giardini sardo, Italy	\N
256	0	0101000020E61000002E008DD2A5032D406B5CA4F55C204540		5 Borgo Maurizi, San Attilio, Italy	\N
257	0	0101000020E61000004ED367075C6F1F403A57941282D64640		80 Strada Cianci, Oggiano sardo, Italy	\N
258	0	0101000020E61000006405BF0D316E1F409F07D22060D24640		06 Incrocio Costantin, Baldi salentino, Italy	\N
259	0	0101000020E61000006F4BE482334C2740A928A8F287304640		643 Incrocio Donato, Violi nell'emilia, Italy	\N
260	0	0101000020E61000005BC52CC59F522B40DB68A5B50EFA4640		63 Via Saba, San Sabrina a mare, Italy	\N
261	0	0101000020E61000000D5F155E383A21402BCC310F4F724640		364 Borgo Calcedonio, Alcina lido, Italy	\N
262	0	0101000020E6100000E04158326C5D2140821C9430D3704640		29 Via Gatta, Amedeo terme, Italy	\N
263	0	0101000020E6100000C1F979F8D7071F404EFA319C21CD4640		85 Incrocio Vladimiro, San Giotto, Italy	\N
264	0	0101000020E61000000C97B0917F3921404C9C267D6B734640		643 Via Boscaino, Sesto Desiderato terme, Italy	\N
265	0	0101000020E6100000EFA18ED838742840FA10AF46D1764640		4 Incrocio Boccia, Quarto Lia, Italy	\N
266	0	0101000020E6100000B032BF3F4AC11E4019CD25B094D54640		003 Rotonda Gloria, Clemente calabro, Italy	\N
267	0	0101000020E610000039FBB9579CA829401D9C3EF152FC4440		9 Borgo Gianpietro, Borgo Ilia terme, Italy	\N
268	0	0101000020E6100000440E5BC4C1F71E4071033E3F8C7E4640		333 Borgo Giorgio, Settimo Serafino terme, Italy	\N
269	0	0101000020E6100000C69EE2DD36D82B400B8AD5D5D3E84640		29 Piazza Giuditta, Sesto Bertolfo a mare, Italy	\N
270	0	0101000020E6100000888961E2EA131F4040E7244A31CD4640		707 Rotonda Adalberto, Settimo Leontina calabro, Italy	\N
271	0	0101000020E6100000E8F86871C6D81E40E7EBE86E8DD84640		237 Piazza Solocone, Dianora lido, Italy	\N
272	0	0101000020E610000024BF34FBF2301F405FCE6C57E8CB4640		6 Incrocio Barbara, Loreno calabro, Italy	\N
273	0	0101000020E61000000242902859C7254075988AE832F64540		425 Rotonda Fabio, Settimo Cupido ligure, Italy	\N
274	0	0101000020E61000005CEC5113D8AF1E405650ACAE9ED84640		3 Via Carloni, Degna veneto, Italy	\N
275	0	0101000020E6100000A6A84423E9E41E40BF20336145E14640		07 Rotonda Diodoro, Borgo Cesario, Italy	\N
276	0	0101000020E6100000F07A7AB6582B2740B1ADFAB726234640		25 Borgo Margherita, Marzia sardo, Italy	\N
277	0	0101000020E61000002252D32EA6C91E404392B47636E94640		39 Strada Loreti, Latini sardo, Italy	\N
278	0	0101000020E61000000BC336983C2C27405262D7F676234640		6 Strada Tarso, Damiano calabro, Italy	\N
279	0	0101000020E61000004F722C94F1E8264075F2D885D5064740		5 Contrada D'Errico, Scrofani salentino, Italy	\N
280	0	0101000020E61000005C8BBBE6FA8F26407A4F8AFB343B4740		8 Via Casula, Quarto Ramiro nell'emilia, Italy	\N
281	0	0101000020E61000007B9054956C0B28407BB5487FD4974640		77 Borgo Gianotti, Orchidea umbro, Italy	\N
282	0	0101000020E6100000BE52F1DA00B72B40D21D1F8887274540		36 Strada Barbara, Giove ligure, Italy	\N
283	0	0101000020E6100000A732D6485C052740FDD8243FE2394640		55 Contrada Elaide, San Catena lido, Italy	\N
284	0	0101000020E6100000AD94545C0B4D2240EE885462E8B94640		5 Borgo Ariberto, Baldassarre salentino, Italy	\N
285	0	0101000020E6100000333097F9B3641F40983BE93356DF4640		22 Rotonda Euridice, Rachele sardo, Italy	\N
286	0	0101000020E61000002B8AB2124E762740C1EA234B41314640		90 Piazza Tommaso, Di Giovanni nell'emilia, Italy	\N
287	0	0101000020E6100000905F8951219022403E5695229E864640		5 Via Santarossa, Sesto Adelgardo, Italy	\N
288	0	0101000020E610000096C1621E43E92640E580B80611044740		938 Piazza Emanuela, Borgo Gaspare terme, Italy	\N
289	0	0101000020E61000007090B52B99842B40E461461DC27E4640		59 Piazza Corrado, Borgo Elvia a mare, Italy	\N
290	0	0101000020E610000084B1CFAD219A26406BDECC43010E4740		787 Incrocio Emiliano, Piccoli nell'emilia, Italy	\N
291	0	0101000020E6100000CC1D47BDF13F2240A5A31CCC26824640		506 Borgo Rambaldi, Quarto Valentino, Italy	\N
292	0	0101000020E610000048E58123DCFF26407F7E294D94084740		440 Incrocio Cecilio, Madonna nell'emilia, Italy	\N
293	0	0101000020E61000006B5A73918C1625409D7C1FB358204740		5 Rotonda Orsolina, Sesto Lavinio veneto, Italy	\N
294	0	0101000020E6100000204F818241C01E40068B1E53D2D34640		54 Borgo Rufino, Panico lido, Italy	\N
295	0	0101000020E6100000C0CBB161F2931E40B859BC5818D34640		782 Incrocio Mele, Borgo Carlo, Italy	\N
296	0	0101000020E610000070DA4246F68B2C40A79C8AAFD1364740		927 Piazza Fernando, Mautone calabro, Italy	\N
297	0	0101000020E6100000A9D5FC9D92882C4058FBE02131384740		018 Via Leoni, Gallicano a mare, Italy	\N
298	0	0101000020E6100000F74A0FF91DD1274067DC8AB3D8024740		39 Via Ranucci, Macaria lido, Italy	\N
299	0	0101000020E61000004221A7542EE52C40A39BB3F457164740		74 Strada Chessa, Quarto Neopolo a mare, Italy	\N
300	0	0101000020E6100000D3D7987C586422408E7CB9AA47A84640		403 Borgo Quinzio, Lattanzi lido, Italy	\N
301	0	0101000020E610000008CDAE7B2B8A2440E646EC6EF9664540		07 Borgo Cipriano, Soro sardo, Italy	\N
302	0	0101000020E610000081EB8A19E1CD26408A4457D8C2194640		478 Rotonda Algiso, Settimo Dagoberto, Italy	\N
303	0	0101000020E6100000B4CA4C69FD5122404A95CDC1D8134540		2 Incrocio Rucco, Fortugno lido, Italy	\N
304	0	0101000020E6100000E4BD6A65C267264033260EEA6CBC4640		09 Via Doroteo, Maffeo lido, Italy	\N
305	0	0101000020E610000071C0536DDCD325406C312E0BDCB14640		65 Piazza Ursicio, San Averardo laziale, Italy	\N
306	0	0101000020E6100000B368F0ADFEEA2540D42AFA4333B54640		605 Borgo Verano, Peleo calabro, Italy	\N
307	0	0101000020E61000005B2CA0AB08EA2740DE454E15422C4740		5 Contrada Di Francesco, Sesto Flavio a mare, Italy	\N
308	0	0101000020E61000009703988D2933274052EC0D63778A4640		98 Via Monte Grappa, Lendinara, Italy	\N
309	0	0101000020E61000005389FC44AF582940E7D2AEF83CCA4640		99 Piazza Virginia, Pollione a mare, Italy	\N
310	0	0101000020E61000000236D6B441802C4025D5D237C46B4440		44 Via dei Greci, Napoli, Italy	\N
311	0	0101000020E610000073220BE24DBC2740A1E4C40DAE2D4740		582 Contrada Gonzaga, Borgo Guiberto, Italy	\N
312	0	0101000020E610000046B1DCD26AB02540072E45A808074740		249 Borgo Andrisani, Minervino salentino, Italy	\N
313	0	0101000020E6100000B17E7DBE77992240C0F858B043504440		5 Incrocio Bergamini, Vicinanza umbro, Italy	\N
314	0	0101000020E6100000EC3026FDBD2C27403B6AF1CE46024740		09 Strada Ingrosso, De Giorgio calabro, Italy	\N
315	0	0101000020E6100000996EC8F5A5712B40C576F700DD3C4740		471 Borgo Eleonora, Elita laziale, Italy	\N
316	0	0101000020E6100000AA5DB818A8F922406B0DA5F622154440		299 Incrocio Florina, San Michela, Italy	\N
317	0	0101000020E610000034B10AE58E682040CFC941BFA57A4440		414 Borgo Fulvio, Eutalia salentino, Italy	\N
318	0	0101000020E610000008D04AB5AABC2140800F5EBBB4374640		2 Incrocio Leonida, Cittadino calabro, Italy	\N
319	0	0101000020E6100000B35DA10F967D2D408F49905BDD324740		74 Piazza Tagliaferri, Mastropietro laziale, Italy	\N
320	0	0101000020E6100000852348A5D8C12840842458C114E24540		770 Incrocio Verdiana, Petrarca nell'emilia, Italy	\N
321	0	0101000020E6100000BF5076E915252B40EA398EC4703B4740		3 Piazza Bortot, Sesto Iago ligure, Italy	\N
322	0	0101000020E6100000B956D6917EDA2B40DF707A72A8054540		675 Contrada Placido, Aiace lido, Italy	\N
323	0	0101000020E61000007889A02067742340DE2A3EF493CE4640		6 Piazza Ciro, Settimo Valeriano, Italy	\N
324	0	0101000020E6100000235399BDC70C254059CFFF6101ED4540		580 Piazza Nunziata, Settimo Romero, Italy	\N
325	0	0101000020E610000027F33405D7392640E75E16C90D2C4740		3 Via Brambilla, San Silvia, Italy	\N
326	0	0101000020E61000001C15EE4BECAC2A40DD11A9C4D02E4540		5 Contrada Agenore, Settimo Ausiliatrice, Italy	\N
327	0	0101000020E6100000C1D4850E70E722408E6D63FDB0594540		8 Via Tazio, Settimo Giliola, Italy	\N
328	0	0101000020E6100000E5BA849E28A826407E7D63BE723F4640		32 Piazza Celano, Tarantino salentino, Italy	\N
329	0	0101000020E610000055B1E72109D11F4018CFA0A17FB14640		12 Via Gigliola, Quarto Michela, Italy	\N
330	0	0101000020E61000007DEFCA89D18E2640DB0B16985F354540		84 Piazza La Manna, Settimo Damiano sardo, Italy	\N
331	0	0101000020E6100000BB6D9516E41D244002678412C1A94640		3 Incrocio Crispino, Quarto Lucia ligure, Italy	\N
332	0	0101000020E6100000F67AF7C77BB52740FA449E245D4F4740		66 Borgo Filomeno, Genna ligure, Italy	\N
333	0	0101000020E6100000DE68119BD960294098E8E225EEFB4440		80 Rotonda Caterina, Borgo Mariella, Italy	\N
334	0	0101000020E61000007ED3AA4CE7E52340C9CC052E8F254640		39 Piazza Adamo, Gioacchina ligure, Italy	\N
335	0	0101000020E61000004EDF217B732E2240D3F4D901D7214540		6 Incrocio Silvestro, Gumesindo laziale, Italy	\N
336	0	0101000020E61000004377A45588CA264008951348E43C4640		79 Strada Zeni, Quarto Giotto veneto, Italy	\N
337	0	0101000020E610000072593B40E6692840252D4B2A09EC4440		6 Piazza Sabato, De Simone laziale, Italy	\N
338	0	0101000020E610000023E7B3F281D7214072C8618B38C84640		0 Piazza Celano, Cipriano terme, Italy	\N
339	0	0101000020E61000000C84AE8E2D752740A4897780272E4640		042 Piazza Viale, Sesto Elita, Italy	\N
340	0	0101000020E6100000A63C5F58A33326408C811A63CCED4540		398 Piazza Malaspina, Settimo Egidio del friuli, Italy	\N
341	0	0101000020E6100000CC0C1B65FD922840A42C8DA905C14640		4 Via Moscato, Adalberto lido, Italy	\N
342	0	0101000020E61000007332CC64933F2740FEDDF1DC31254640		35 Piazza Manno, Lodovica umbro, Italy	\N
343	0	0101000020E610000032D758784D462240743F4C67CC0B4740		1 Rotonda Rosamunda, Alice umbro, Italy	\N
344	0	0101000020E61000002B16BF29ACC825401AB6775787864540		9 Piazza Sebastiano, Alma veneto, Italy	\N
345	0	0101000020E6100000FE00B562C9B62A4032CFA51364D94440		1 Via Venturini, Sesto Anita umbro, Italy	\N
346	0	0101000020E61000002AD890C9F3362640A3C629DFD80F4640		6 Piazza Franca, Grieco sardo, Italy	\N
347	0	0101000020E610000098F0958AD7422540F3DD52735E994640		528 Rotonda Lo Giudice, Bonavita a mare, Italy	\N
348	0	0101000020E6100000451B36806D772640B99BF1C7FE074740		233 Contrada Paolini, Natali lido, Italy	\N
349	0	0101000020E61000008948A8740B9027402B7D321015F14540		2 Via Clelia, Sesto Regolo, Italy	\N
350	0	0101000020E6100000484B8A3496612B40F1F44A5986DF4640		1 Contrada Rainelda, Almerigo a mare, Italy	\N
351	0	0101000020E610000006240626DCE0264059631A97BBDC4640		586 Strada Stella, Quarto Bardomiano terme, Italy	\N
352	0	0101000020E61000001A62067470422640EF6BC94F4FBD4540		8 Incrocio Matta, Settimo Milo, Italy	\N
353	0	0101000020E6100000F0F1536694F425402F5D77A9C7134640		3 Contrada Pavone, Neopolo a mare, Italy	\N
354	0	0101000020E6100000A5DAA7E3317F2240E75E16C90DEF4640		35 Contrada Adone, San Desiderato, Italy	\N
355	0	0101000020E6100000D12E956D967D2C40126C5CFFAE6D4440		9 Piazza Pacifico, Sesto Celinia, Italy	\N
356	0	0101000020E6100000DD6CBDF0941F27409F515F3BBDDA4640		31 Rotonda Marchetti, Quarto Costante, Italy	\N
357	0	0101000020E610000096EA025E66002640FA4E82ED16F44540		49 Piazza Apuleio, Settimo Tiziana, Italy	\N
358	0	0101000020E61000009DDE20B5E43C25407F83F6EAE39D4540		9 Incrocio Romani, Sesto Idea, Italy	\N
359	0	0101000020E6100000016E162F168E2340861BF0F9614A4440		366 Borgo Oggiano, San Olga ligure, Italy	\N
360	0	0101000020E61000009F32480BE1EA20405C8A50114CDA4640		59 Rotonda Nigro, Quarto Guerrino, Italy	\N
361	0	0101000020E6100000618841052C422B400938DFE3A78E4640		895 Strada Eufrasia, Quarto Calanico, Italy	\N
362	0	0101000020E6100000160F94803D132140276BD44334E04640		00 Piazza Scarpellini, Giovanna lido, Italy	\N
363	0	0101000020E610000097A13BD22A4C25401A80B2CE9DD44540		9 Rotonda Socrate, Surace terme, Italy	\N
364	0	0101000020E6100000AD904D4DDD3827405B632BC313B14540		801 Contrada Gruber, Di Gaetano terme, Italy	\N
365	0	0101000020E610000071E82D1EDEEB2C405F93DA30AF824440		98 Strada Franceschi, Sesto Bernardo, Italy	\N
366	0	0101000020E6100000DA48C8F6109B1F40EE2AFFB5176E4640		65 Via Pozzi, Marcello veneto, Italy	\N
367	0	0101000020E61000004D028A4798F02740C38366D7BD264640		597 Incrocio Regolo, Cleopatra laziale, Italy	\N
368	0	0101000020E6100000BCB77DEAB38A2C404EF04DD3676E4440		55 Contrada Icilio, Beniamina umbro, Italy	\N
369	0	0101000020E6100000CBC80F4BB93126404793E6EA22FD4640		277 Borgo Degrassi, Settimo Ferruccio del friuli, Italy	\N
370	0	0101000020E6100000A68E9FD7E925284065677682A2C64640		5 Strada Anastasia, Borgo Rufo, Italy	\N
371	0	0101000020E6100000407562C55F5D294091FC773359C24640		55 Piazza Balistreri, Pesce del friuli, Italy	\N
372	0	0101000020E6100000CF328B506C4D244070D63B37C8184640		434 Rotonda Mazzanti, Borgo Zosima, Italy	\N
373	0	0101000020E61000007E6E0D11DC1122409453967C47EB4640		64 Via Viliberto, Rucco salentino, Italy	\N
374	0	0101000020E610000043A44BA4D989204072A8DF85ADD34640		202 Borgo Amadeo, Borgo Ecclesio a mare, Italy	\N
375	0	0101000020E61000004371C79BFC022C404AF5F81807254540		53 Strada Vicari, Sesto Guiscardo umbro, Italy	\N
376	0	0101000020E61000009EA74B10BFA422400292FAFC41944440		1 Incrocio Silvestro, Cornelia lido, Italy	\N
377	0	0101000020E61000000D88B59D5B012C40CF70B9B024144540		447 Piazza Filomena, Aldo umbro, Italy	\N
378	0	0101000020E610000059935D1F8CFE26407E6DA23B2D3B4640		94 Rotonda Ofelia, Zanetti a mare, Italy	\N
379	0	0101000020E6100000D50451F7010829403B736AC2510D4640		589 Via Iovino, Semiramide a mare, Italy	\N
380	0	0101000020E6100000CD6152D735012740D65F6523C6394640		85 Contrada Lucia, Sesto Colombo calabro, Italy	\N
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hike_track_points ("userHikeId", index, "pointId", datetime) FROM stdin;
\.


--
-- Data for Name: user_hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes (id, "userId", "hikeId", "startedAt", "updatedAt", "finishedAt", "psTotalKms", "psHighestAltitude", "psAltitudeRange", "psTotalTimeMinutes", "psAverageSpeed", "psAverageVerticalAscentSpeed", "maxElapsedTime", "weatherNotified", "unfinishedNotified") FROM stdin;
\.


--
-- Data for Name: user_hikes_track_points_user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes_track_points_user_hike_track_points ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash", approved, preferences, "plannedHikes") FROM stdin;
2	$2b$10$xhuozTlwVZTjC54jgJDUF.yt7e5htGfpnbt6LisWhOXYNpwRkEEgK	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N	t	\N	\N
4	$2b$10$CIruwHXgj5rqjoZbJZDdQOKZxP67A0wYVFOdB/N93j4AAEtxPNLL6	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N	t	\N	\N
5	$2b$10$kTB1.oAraV7ynQiVTgwzsObJj10pXLRMQr7O71/x4LIK8m1tQIj0W	Laura	Zurru	5	laura@emergency.it	\N	t	\N	t	\N	\N
1	$2b$10$MbShhs0ChBdCDgklTxTvo.OIViGqrd/612s8srssqtqg.3XJJDgne	German	Gorodnev	0	german@hiker.it	\N	t	\N	t	\N	\N
3	$2b$10$XHFeSHRapRB61/5A32V7LOIlcp0VqzULyi8yBiMZg9fDV6ns2km4q	vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N	t	\N	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 5, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 108, true);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 256, true);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 380, true);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_hikes_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

