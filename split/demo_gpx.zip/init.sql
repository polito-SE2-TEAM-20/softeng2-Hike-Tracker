--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: hike_points PK_7fc686c35c52228d8494a7c4947; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_7fc686c35c52228d8494a7c4947" PRIMARY KEY ("hikeId", "pointId");


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$naA/tW.4ikzm1USaTlj2jOyZtMBB6jqw8YyAH.xPFD2.5Kvn8zWh2',
    'Antonio',
    'Battipaglia',
    2,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$qgOoNG.PxbOuF1Nx.xA3FOCKgbNpCb0sCJOm.4aqpxXkPzxELp61.',
    'Erfan',
    'Gholami',
    4,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$U8gacZslEdgin1f1fg7lu..vfXCad4r25CFSazTMv/zycX.hNG90.',
    'Laura',
    'Zurru',
    5,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$QduckJgx1IsmfuYjoQ3LUOZM4riP9cQPaHWtKujii4g6yXWbQwvDe',
    'German',
    'Gorodnev',
    0,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$qCMIdvLj1lt7cmqxOUq97.tiEjWnBI2ZHEosU7oD/MEm9wXjjACF.',
    'vincenzo',
    'Sagristano',
    3,
    true
  );
  

      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Airline Trail - Detour',
        0,
        '/static/gpx/001_Airline_Trail___Detour.gpx',
        'USA',
        'La Spezia',
        '',
        'Pariggiano ligure',
        0.9,
        16.2,
        13.333,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Airline Trail',
        2,
        '/static/gpx/002_Airline_Trail.gpx',
        'USA',
        'Como',
        '',
        'Borgo Ilda',
        0.6,
        14.8,
        8.276,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Colchester Railroad',
        1,
        '/static/gpx/003_Colchester_Railroad.gpx',
        'USA',
        'Milano',
        '',
        'Chilà laziale',
        1.9,
        11,
        25.503,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Willimantic Flower Bridge',
        1,
        '/static/gpx/004_Willimantic_Flower_Bridge.gpx',
        'USA',
        'Imperia',
        '',
        'Settimo Luana',
        1.5,
        7.7,
        18.75,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Willimantic Pedestrian Bridge',
        1,
        '/static/gpx/005_Willimantic_Pedestrian_Bridge.gpx',
        'USA',
        'Padova',
        '',
        'San Valerio',
        0.8,
        29.9,
        10.619,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Two Sister''S Preserve Loop Trail',
        2,
        '/static/gpx/006_Two_Sister_S_Preserve_Loop_Trail.gpx',
        'USA',
        'Modena',
        '',
        'Betti terme',
        0.6,
        29.8,
        7.2,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Putnam River Trail',
        1,
        '/static/gpx/007_Putnam_River_Trail.gpx',
        'USA',
        'Como',
        '',
        'Giannetti ligure',
        0.9,
        12.8,
        13.918,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Airline Trail Bypass',
        2,
        '/static/gpx/008_Airline_Trail_Bypass.gpx',
        'USA',
        'Taranto',
        '',
        'Sesto Massimiliano a mare',
        1.4,
        19.6,
        20.192,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Indian Neck',
        1,
        '/static/gpx/009_Indian_Neck.gpx',
        'USA',
        'Reggio Calabria',
        '',
        'Settimo Ulfa',
        14.6,
        9,
        248.159,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Stony Creek',
        0,
        '/static/gpx/010_Stony_Creek.gpx',
        'USA',
        'Lucca',
        '',
        'Quarto Edilberto',
        6.7,
        5.7,
        86.452,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quarry-Westwoods',
        2,
        '/static/gpx/011_Quarry_Westwoods.gpx',
        'USA',
        'Oristano',
        '',
        'Quarto Marilena',
        8.7,
        10.2,
        107.851,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Short Beach',
        0,
        '/static/gpx/012_Short_Beach.gpx',
        'USA',
        'Siracusa',
        '',
        'Casolaro terme',
        17.3,
        7.8,
        240.835,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Charter Oak Greenway',
        2,
        '/static/gpx/013_Charter_Oak_Greenway.gpx',
        'USA',
        'Taranto',
        '',
        'Riggi lido',
        1.3,
        20.6,
        17.647,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bissell Greenway',
        1,
        '/static/gpx/014_Bissell_Greenway.gpx',
        'USA',
        'Roma',
        '',
        'Sesto Romeo ligure',
        1.7,
        19.9,
        20.902,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Riverfront Trail System',
        0,
        '/static/gpx/015_Riverfront_Trail_System.gpx',
        'USA',
        'Prato',
        '',
        'Borgo Paride',
        0.6,
        25.3,
        9.184,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Millers Pond Park Trail',
        2,
        '/static/gpx/016_Millers_Pond_Park_Trail.gpx',
        'USA',
        'Chieti',
        '',
        'Ilenia calabro',
        1.4,
        7.2,
        19.626,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattabesett Trail',
        2,
        '/static/gpx/017_Mattabesett_Trail.gpx',
        'USA',
        'Pesaro e Urbino',
        '',
        'Assunto nell''emilia',
        0.6,
        8.7,
        7.438,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Jefferson Park Trail',
        2,
        '/static/gpx/018_Jefferson_Park_Trail.gpx',
        'USA',
        'Siracusa',
        '',
        'Druina calabro',
        1.2,
        22.9,
        20.225,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Cockaponset Trail',
        2,
        '/static/gpx/019_Cockaponset_Trail.gpx',
        'USA',
        'Agrigento',
        '',
        'San Proserpina',
        1.2,
        19,
        15.287,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mt. Nebo Park',
        1,
        '/static/gpx/020_Mt__Nebo_Park.gpx',
        'USA',
        'Isernia',
        '',
        'Borgo Nina a mare',
        1,
        18.7,
        13.393,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        ' ',
        2,
        '/static/gpx/021__.gpx',
        'USA',
        'Trento',
        '',
        'Lo Piccolo veneto',
        1.2,
        26.4,
        17.062,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Proposed Trail',
        2,
        '/static/gpx/022_Proposed_Trail.gpx',
        'USA',
        'Verbano-Cusio-Ossola',
        '',
        'Settimo Perla nell''emilia',
        0.8,
        15.9,
        12.308,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Blinnshed Ridge Trail',
        2,
        '/static/gpx/023_Blinnshed_Ridge_Trail.gpx',
        'USA',
        'Messina',
        '',
        'Quarto Cordelia lido',
        1,
        16.9,
        14.052,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Neck River Trail',
        2,
        '/static/gpx/024_Neck_River_Trail.gpx',
        'USA',
        'Carbonia-Iglesias',
        '',
        'Alberico veneto',
        1.4,
        21.4,
        19.905,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Unnamed Trail',
        2,
        '/static/gpx/025_Unnamed_Trail.gpx',
        'USA',
        'Pavia',
        '',
        'Settimo Carlotta umbro',
        1.5,
        25.6,
        25.424,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Oil Mill Brook Trail',
        2,
        '/static/gpx/026_Oil_Mill_Brook_Trail.gpx',
        'USA',
        'Matera',
        '',
        'Settimo Lisa',
        0.6,
        9,
        8.955,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chatfield Trail',
        2,
        '/static/gpx/027_Chatfield_Trail.gpx',
        'USA',
        'Parma',
        '',
        'Perna ligure',
        1.1,
        18,
        15.752,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Unamed Trail',
        2,
        '/static/gpx/028_Unamed_Trail.gpx',
        'USA',
        'Oristano',
        '',
        'San Asella',
        0.8,
        22.4,
        12.598,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Lost Pond Trail',
        2,
        '/static/gpx/029_Lost_Pond_Trail.gpx',
        'USA',
        'Bolzano',
        '',
        'Settimo Ottone',
        0.9,
        29.8,
        11.538,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ccc Camp Hadley Trail',
        2,
        '/static/gpx/030_Ccc_Camp_Hadley_Trail.gpx',
        'USA',
        'Ragusa',
        '',
        'Borgo Prudenzia',
        1.1,
        25.9,
        18.803,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Double Loop Trail',
        2,
        '/static/gpx/031_Double_Loop_Trail.gpx',
        'USA',
        'Lucca',
        '',
        'Borgo Rodrigo',
        0.5,
        24,
        8.264,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Over Brook Trail',
        2,
        '/static/gpx/032_Over_Brook_Trail.gpx',
        'USA',
        'Lucca',
        '',
        'San Alcina del friuli',
        0.7,
        17.3,
        9.567,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Cockaponset Forest Trail',
        2,
        '/static/gpx/033_Cockaponset_Forest_Trail.gpx',
        'USA',
        'Rieti',
        '',
        'Leo sardo',
        1.4,
        18.2,
        23.014,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pattaconk Trail',
        2,
        '/static/gpx/034_Pattaconk_Trail.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Quarto Gaia a mare',
        0.8,
        23.5,
        10.714,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Westwoods Forest Trail',
        2,
        '/static/gpx/035_Westwoods_Forest_Trail.gpx',
        'USA',
        'Vibo Valentia',
        '',
        'Borgo Alice nell''emilia',
        0.9,
        19.3,
        14.286,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Blinnshed Loop Trail',
        2,
        '/static/gpx/036_Blinnshed_Loop_Trail.gpx',
        'USA',
        'Rieti',
        '',
        'Quarto Aldobrando del friuli',
        1.4,
        28.5,
        18.876,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Unnamed Tsail',
        2,
        '/static/gpx/037_Unnamed_Tsail.gpx',
        'USA',
        'Pistoia',
        '',
        'San Proserpina laziale',
        1,
        26.2,
        13.043,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Messerschmidt Wma Trail',
        2,
        '/static/gpx/038_Messerschmidt_Wma_Trail.gpx',
        'USA',
        'Chieti',
        '',
        'Quarto Leonio terme',
        1.3,
        16.8,
        21.667,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Westwoods Nature Trail',
        2,
        '/static/gpx/039_Westwoods_Nature_Trail.gpx',
        'USA',
        'Nuoro',
        '',
        'Sesto Bardomiano calabro',
        1.2,
        18.4,
        18.605,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Enduro',
        2,
        '/static/gpx/040_Enduro.gpx',
        'USA',
        'Terni',
        '',
        'Quarto Scolastica lido',
        0.8,
        18.1,
        12,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Land Trust Trail',
        2,
        '/static/gpx/041_Land_Trust_Trail.gpx',
        'USA',
        'Alessandria',
        '',
        'Otilia sardo',
        0.9,
        8.8,
        14.248,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Beaver Brook Park Trail',
        0,
        '/static/gpx/042_Beaver_Brook_Park_Trail.gpx',
        'USA',
        'Fermo',
        '',
        'Quarto Taziano',
        0.5,
        6.9,
        8.499,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Housatonic Forest Trail',
        1,
        '/static/gpx/043_Housatonic_Forest_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Sesto Liberto',
        0.6,
        20.1,
        8.018,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Farmington Canal Trail',
        2,
        '/static/gpx/044_Farmington_Canal_Trail.gpx',
        'USA',
        'Terni',
        '',
        'Sesto Ella',
        0.8,
        16.1,
        9.979,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Beckley Furnace Park Path',
        1,
        '/static/gpx/045_Beckley_Furnace_Park_Path.gpx',
        'USA',
        'Agrigento',
        '',
        'San Casto terme',
        0.7,
        12.2,
        9.438,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Farmington River Trail',
        0,
        '/static/gpx/046_Farmington_River_Trail.gpx',
        'USA',
        'Trento',
        '',
        'Borgo Graziana veneto',
        1.3,
        15.3,
        16.25,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Farminton Canal Trail',
        0,
        '/static/gpx/047_Farminton_Canal_Trail.gpx',
        'USA',
        'Pavia',
        '',
        'Pavan del friuli',
        0.8,
        14.4,
        11.852,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Farminton River Trail',
        2,
        '/static/gpx/048_Farminton_River_Trail.gpx',
        'USA',
        'La Spezia',
        '',
        'Lo Pinto veneto',
        1.4,
        6.3,
        21.106,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hop River Trail',
        1,
        '/static/gpx/049_Hop_River_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Sesto Enea nell''emilia',
        4.7,
        12.8,
        69.802,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hoprivertrail - Detouraround316',
        1,
        '/static/gpx/050_Hoprivertrail___Detouraround316.gpx',
        'USA',
        'Terni',
        '',
        'Zamboni laziale',
        0.6,
        9.6,
        9.945,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hop River Trail - Long Hill Rd.',
        2,
        '/static/gpx/051_Hop_River_Trail___Long_Hill_Rd_.gpx',
        'USA',
        'Parma',
        '',
        'Notaro sardo',
        0.8,
        5,
        10.619,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hop River Trail - Rockville Spur',
        0,
        '/static/gpx/052_Hop_River_Trail___Rockville_Spur.gpx',
        'USA',
        'Pistoia',
        '',
        'Giacinto ligure',
        0.9,
        22.4,
        15.084,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Housatonic Rail Trail',
        0,
        '/static/gpx/053_Housatonic_Rail_Trail.gpx',
        'USA',
        'Pistoia',
        '',
        'Leoncini ligure',
        0.6,
        16.7,
        7.484,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Middletown Bikeway',
        1,
        '/static/gpx/054_Middletown_Bikeway.gpx',
        'USA',
        'Avellino',
        '',
        'Adelmo veneto',
        2,
        19.8,
        26.549,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattabesett Trolley Trail',
        2,
        '/static/gpx/055_Mattabesett_Trolley_Trail.gpx',
        'USA',
        'Medio Campidano',
        '',
        'Bisconti umbro',
        1.5,
        18.8,
        23.438,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Moosup Valley State Park Trail',
        2,
        '/static/gpx/056_Moosup_Valley_State_Park_Trail.gpx',
        'USA',
        'Enna',
        '',
        'Borgo Alice salentino',
        1.5,
        18,
        23.018,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinnebaug River Trail',
        0,
        '/static/gpx/057_Quinnebaug_River_Trail.gpx',
        'USA',
        'Trapani',
        '',
        'Agrippa ligure',
        0.7,
        20.1,
        9.417,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tracey Road Trail',
        2,
        '/static/gpx/058_Tracey_Road_Trail.gpx',
        'USA',
        'Benevento',
        '',
        'Settimo Vodingo ligure',
        0.7,
        10.5,
        11.2,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Trolley Trail',
        2,
        '/static/gpx/059_Trolley_Trail.gpx',
        'USA',
        'Prato',
        '',
        'Sesto Donata',
        1.5,
        13,
        20.455,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinnebaug Hatchery Trail',
        2,
        '/static/gpx/060_Quinnebaug_Hatchery_Trail.gpx',
        'USA',
        'Bari',
        '',
        'Quarto Biagio',
        1.2,
        21.1,
        15.319,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hopeville Park Trail',
        2,
        '/static/gpx/061_Hopeville_Park_Trail.gpx',
        'USA',
        'Lecce',
        '',
        'Elena calabro',
        1.5,
        23.3,
        21.127,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hopeville Park Path',
        1,
        '/static/gpx/062_Hopeville_Park_Path.gpx',
        'USA',
        'Catanzaro',
        '',
        'Nicarete terme',
        0.5,
        18,
        8.086,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic Trail',
        2,
        '/static/gpx/063_Nehantic_Trail.gpx',
        'USA',
        'Vercelli',
        '',
        'Rosi veneto',
        0.5,
        11,
        7.026,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Camp Columbia Trail',
        2,
        '/static/gpx/064_Camp_Columbia_Trail.gpx',
        'USA',
        'Fermo',
        '',
        'Sesto Rosmunda del friuli',
        1.2,
        26.4,
        20.455,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shelton Land Trust Trail',
        0,
        '/static/gpx/065_Shelton_Land_Trust_Trail.gpx',
        'USA',
        'Gorizia',
        '',
        'Sesto Desiderato',
        0.8,
        23.5,
        10.811,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Dinosaur Park Sidewalk',
        2,
        '/static/gpx/066_Dinosaur_Park_Sidewalk.gpx',
        'USA',
        'Catanzaro',
        '',
        'Tarquini umbro',
        1.4,
        9.6,
        17.949,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Dinosaur Park Trail',
        0,
        '/static/gpx/067_Dinosaur_Park_Trail.gpx',
        'USA',
        'Genova',
        '',
        'Crevatin veneto',
        0.8,
        8.6,
        11.456,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Access Road',
        1,
        '/static/gpx/068_Access_Road.gpx',
        'USA',
        'Bari',
        '',
        'Quarto Severa',
        1.4,
        22.2,
        18.876,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Day Pond Park Path',
        2,
        '/static/gpx/069_Day_Pond_Park_Path.gpx',
        'USA',
        'Rimini',
        '',
        'Bartoli terme',
        0.8,
        28.3,
        11.189,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Day Pond Park Trail',
        1,
        '/static/gpx/070_Day_Pond_Park_Trail.gpx',
        'USA',
        'Torino',
        '',
        'Daniele laziale',
        0.7,
        30,
        8.994,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Salmon River Trail',
        0,
        '/static/gpx/071_Salmon_River_Trail.gpx',
        'USA',
        'Padova',
        '',
        'Settimo Ubaldo',
        2.6,
        24.3,
        42.391,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Salmon River Trial',
        2,
        '/static/gpx/072_Salmon_River_Trial.gpx',
        'USA',
        'Messina',
        '',
        'Amabile veneto',
        1.1,
        19.5,
        15.827,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Dennis Hill Park Trail',
        0,
        '/static/gpx/073_Dennis_Hill_Park_Trail.gpx',
        'USA',
        'Savona',
        '',
        'Sesto Dalida salentino',
        0.8,
        8.4,
        11.137,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Railroad Trail',
        1,
        '/static/gpx/074_Railroad_Trail.gpx',
        'USA',
        'Livorno',
        '',
        'Sesto Vezio calabro',
        1,
        9.8,
        16,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Gillette Castle Trail',
        2,
        '/static/gpx/075_Gillette_Castle_Trail.gpx',
        'USA',
        'Nuoro',
        '',
        'Sesto Alceste sardo',
        0.9,
        25,
        11.613,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kent Falls Park Path',
        1,
        '/static/gpx/076_Kent_Falls_Park_Path.gpx',
        'USA',
        'Isernia',
        '',
        'Settimo Cointa',
        1.4,
        5.1,
        18.502,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kent Falls Park Trail',
        1,
        '/static/gpx/077_Kent_Falls_Park_Trail.gpx',
        'USA',
        'Como',
        '',
        'Borgo Isotta sardo',
        1.1,
        19.6,
        13.721,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Lovers Leap Park Trail',
        2,
        '/static/gpx/078_Lovers_Leap_Park_Trail.gpx',
        'USA',
        'Vercelli',
        '',
        'La Monaca veneto',
        0.6,
        17.6,
        7.611,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Enders Forest Trail',
        1,
        '/static/gpx/079_Enders_Forest_Trail.gpx',
        'USA',
        'Teramo',
        '',
        'Settimo Ofelia lido',
        0.5,
        24.4,
        8.333,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Gay City Park Path',
        1,
        '/static/gpx/080_Gay_City_Park_Path.gpx',
        'USA',
        'Viterbo',
        '',
        'Settimo Sabato',
        0.7,
        11.1,
        10.474,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Gay City Park Trail',
        0,
        '/static/gpx/081_Gay_City_Park_Trail.gpx',
        'USA',
        'Vercelli',
        '',
        'Alfio a mare',
        0.9,
        18.7,
        12.95,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Split Rock Trail',
        1,
        '/static/gpx/082_Split_Rock_Trail.gpx',
        'USA',
        'Firenze',
        '',
        'Quarto Fiorenza veneto',
        1.5,
        5,
        20.501,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Gillette Castle Path',
        2,
        '/static/gpx/083_Gillette_Castle_Path.gpx',
        'USA',
        'Cuneo',
        '',
        'Sesto Ulfa lido',
        1.1,
        27.6,
        14.602,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Great Pond Forest Trail',
        1,
        '/static/gpx/084_Great_Pond_Forest_Trail.gpx',
        'USA',
        'Massa-Carrara',
        '',
        'Babila sardo',
        1.2,
        27.1,
        17.91,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Haddam Meadows Park Trail',
        0,
        '/static/gpx/085_Haddam_Meadows_Park_Trail.gpx',
        'USA',
        'Agrigento',
        '',
        'Aciscolo lido',
        1.2,
        19.5,
        19.251,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Haley Farm Park Trail',
        2,
        '/static/gpx/086_Haley_Farm_Park_Trail.gpx',
        'USA',
        'Sondrio',
        '',
        'Quarto Aidano',
        0.7,
        14.1,
        8.485,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hammonasset Park Path',
        2,
        '/static/gpx/087_Hammonasset_Park_Path.gpx',
        'USA',
        'La Spezia',
        '',
        'San Ausilia veneto',
        1.5,
        27.7,
        18.48,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nature Trail',
        2,
        '/static/gpx/088_Nature_Trail.gpx',
        'USA',
        'Lecce',
        '',
        'Borgo Riccarda umbro',
        0.9,
        5.9,
        12.676,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hammonasset Bike Path',
        0,
        '/static/gpx/089_Hammonasset_Bike_Path.gpx',
        'USA',
        'Chieti',
        '',
        'Magno calabro',
        1.3,
        5.4,
        19.165,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hammonasset Park Boardwalk',
        2,
        '/static/gpx/090_Hammonasset_Park_Boardwalk.gpx',
        'USA',
        'Cosenza',
        '',
        'San Ezechiele',
        1.1,
        12.4,
        15.385,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Meigs Point Jetty',
        2,
        '/static/gpx/091_Meigs_Point_Jetty.gpx',
        'USA',
        'Lecco',
        '',
        'Silvana ligure',
        1.1,
        7.1,
        13.415,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Willard Island Nature Trail',
        2,
        '/static/gpx/092_Willard_Island_Nature_Trail.gpx',
        'USA',
        'L''Aquila',
        '',
        'Mastroianni veneto',
        1.4,
        13,
        24,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Moraine Nature Trail',
        2,
        '/static/gpx/093_Moraine_Nature_Trail.gpx',
        'USA',
        'Ferrara',
        '',
        'Borgo Estella',
        1.1,
        14.4,
        14.41,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Haystack Park Trail',
        0,
        '/static/gpx/094_Haystack_Park_Trail.gpx',
        'USA',
        'Viterbo',
        '',
        'Ettore lido',
        1.3,
        14.9,
        17.45,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Higganum Reservoir Park Trail',
        2,
        '/static/gpx/095_Higganum_Reservoir_Park_Trail.gpx',
        'USA',
        'Como',
        '',
        'Matilde calabro',
        0.7,
        25.4,
        8.75,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Appalachian Trail',
        2,
        '/static/gpx/096_Appalachian_Trail.gpx',
        'USA',
        'Fermo',
        '',
        'Erenia ligure',
        0.7,
        26.4,
        9.292,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mohawk Trail',
        1,
        '/static/gpx/097_Mohawk_Trail.gpx',
        'USA',
        'Fermo',
        '',
        'Sesto Umberto salentino',
        1.1,
        27.3,
        15.172,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pine Knob Loop',
        2,
        '/static/gpx/098_Pine_Knob_Loop.gpx',
        'USA',
        'Lodi',
        '',
        'Doro nell''emilia',
        1.3,
        7.2,
        20.58,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Appalachian/Pine Knob Loop',
        2,
        '/static/gpx/099_Appalachian_Pine_Knob_Loop.gpx',
        'USA',
        'Nuoro',
        '',
        'San Leonia',
        1,
        13.1,
        16.997,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'White Mountain Trail',
        2,
        '/static/gpx/100_White_Mountain_Trail.gpx',
        'USA',
        'Aosta',
        '',
        'Falzone terme',
        0.9,
        19.9,
        10.8,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'River Trail',
        1,
        '/static/gpx/101_River_Trail.gpx',
        'USA',
        'Pescara',
        '',
        'Abbate a mare',
        1.2,
        10.4,
        14.694,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hurd Park Trail',
        1,
        '/static/gpx/102_Hurd_Park_Trail.gpx',
        'USA',
        'Catania',
        '',
        'Settimo Tea del friuli',
        0.7,
        14.6,
        10.526,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hurd Park Path',
        1,
        '/static/gpx/103_Hurd_Park_Path.gpx',
        'USA',
        'Ragusa',
        '',
        'Medugno ligure',
        0.8,
        24.3,
        10.69,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Paugussett Trail',
        2,
        '/static/gpx/104_Paugussett_Trail.gpx',
        'USA',
        'Medio Campidano',
        '',
        'Settimo Federico terme',
        0.9,
        9.2,
        12.081,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Waterfall Trail',
        1,
        '/static/gpx/105_Waterfall_Trail.gpx',
        'USA',
        'Modena',
        '',
        'Angeli calabro',
        0.8,
        11.2,
        11.241,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Paugussett Trail Connector',
        1,
        '/static/gpx/106_Paugussett_Trail_Connector.gpx',
        'USA',
        'Pordenone',
        '',
        'Borgo Adina a mare',
        0.9,
        19.8,
        11.663,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Minetto Park Trail',
        2,
        '/static/gpx/107_Minetto_Park_Trail.gpx',
        'USA',
        'Avellino',
        '',
        'Settimo Galdino',
        1.3,
        6.9,
        16.116,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Coincident Macedonia Brook Rd',
        2,
        '/static/gpx/108_Coincident_Macedonia_Brook_Rd.gpx',
        'USA',
        'Caltanissetta',
        '',
        'Cosimo nell''emilia',
        1.1,
        10.2,
        15.421,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Coincident Weber Road',
        0,
        '/static/gpx/109_Coincident_Weber_Road.gpx',
        'USA',
        'Ragusa',
        '',
        'Alamanno salentino',
        0.9,
        18.4,
        12.471,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Macedonia Ridge Trail',
        0,
        '/static/gpx/110_Macedonia_Ridge_Trail.gpx',
        'USA',
        'Palermo',
        '',
        'Quarto Ultimo laziale',
        3.4,
        18.6,
        43.22,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Cobble Mountain Trail',
        2,
        '/static/gpx/111_Cobble_Mountain_Trail.gpx',
        'USA',
        'Modena',
        '',
        'Montesano terme',
        1.3,
        5,
        16.49,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shenipsit Trail',
        0,
        '/static/gpx/112_Shenipsit_Trail.gpx',
        'USA',
        'Rovigo',
        '',
        'Fabbri terme',
        1.4,
        29.5,
        18.667,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Meshomasic Forest Trail',
        2,
        '/static/gpx/113_Meshomasic_Forest_Trail.gpx',
        'USA',
        'Fermo',
        '',
        'Lelli nell''emilia',
        0.6,
        23.3,
        8.867,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Crest Trail',
        2,
        '/static/gpx/114_Crest_Trail.gpx',
        'USA',
        'Bologna',
        '',
        'Sesto Calpurnia',
        1.4,
        21.8,
        21.266,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Campground Trail',
        1,
        '/static/gpx/115_Campground_Trail.gpx',
        'USA',
        'Biella',
        '',
        'Alfredo sardo',
        1.3,
        27.7,
        19.403,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Brook Trail',
        2,
        '/static/gpx/116_Brook_Trail.gpx',
        'USA',
        'Novara',
        '',
        'Borgo Luigia sardo',
        0.7,
        13.9,
        10.219,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kettletown Park Trail',
        0,
        '/static/gpx/117_Kettletown_Park_Trail.gpx',
        'USA',
        'Enna',
        '',
        'Quarto Manuele sardo',
        1,
        24.7,
        15.075,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'North Ridge Trail',
        0,
        '/static/gpx/118_North_Ridge_Trail.gpx',
        'USA',
        'Trento',
        '',
        'Quarto Eugenio',
        0.9,
        16.9,
        12.442,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'North Ridge Loop Trail',
        1,
        '/static/gpx/119_North_Ridge_Loop_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'Borgo Osanna',
        0.6,
        6.3,
        9.184,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Miller Brook Connector Trail',
        1,
        '/static/gpx/120_Miller_Brook_Connector_Trail.gpx',
        'USA',
        'Cagliari',
        '',
        'Settimo Irene lido',
        0.8,
        8.1,
        11.268,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Miller Trail',
        2,
        '/static/gpx/121_Miller_Trail.gpx',
        'USA',
        'Vibo Valentia',
        '',
        'Borgo Cosma',
        0.6,
        8.3,
        7.895,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Miller Trail Spur',
        2,
        '/static/gpx/122_Miller_Trail_Spur.gpx',
        'USA',
        'Torino',
        '',
        'Ermilo a mare',
        1.5,
        25.2,
        24.523,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pomperaug Trail',
        1,
        '/static/gpx/123_Pomperaug_Trail.gpx',
        'USA',
        'Vicenza',
        '',
        'Cannone nell''emilia',
        1.2,
        26.1,
        18.557,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Brook Trail Access',
        1,
        '/static/gpx/124_Brook_Trail_Access.gpx',
        'USA',
        'Catania',
        '',
        'Sesto Eusebio sardo',
        1.1,
        16.4,
        15.64,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Waramaug Lake Park Trail',
        2,
        '/static/gpx/125_Waramaug_Lake_Park_Trail.gpx',
        'USA',
        'Prato',
        '',
        'San Taziana laziale',
        0.9,
        5.3,
        11.563,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Well Groomed Trail',
        2,
        '/static/gpx/126_Well_Groomed_Trail.gpx',
        'USA',
        'Lecco',
        '',
        'Pantaleo umbro',
        1.5,
        21.2,
        18.595,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mashamoquet Brook Park Trail',
        1,
        '/static/gpx/127_Mashamoquet_Brook_Park_Trail.gpx',
        'USA',
        'Parma',
        '',
        'Sesto Egeo',
        1.3,
        26.7,
        15.663,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shenipsit Trail Spur',
        2,
        '/static/gpx/128_Shenipsit_Trail_Spur.gpx',
        'USA',
        'Roma',
        '',
        'Azelio sardo',
        0.6,
        10,
        7.516,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shenipsit',
        0,
        '/static/gpx/129_Shenipsit.gpx',
        'USA',
        'Trento',
        '',
        'Pantaleone del friuli',
        0.7,
        14.4,
        9.111,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nassahegon Forest Trail',
        0,
        '/static/gpx/130_Nassahegon_Forest_Trail.gpx',
        'USA',
        'Verona',
        '',
        'Simeoni ligure',
        0.6,
        28.9,
        9.184,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tunxis Trail',
        1,
        '/static/gpx/131_Tunxis_Trail.gpx',
        'USA',
        'Vercelli',
        '',
        'Settimo Loredana sardo',
        1.4,
        16.3,
        16.97,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Black Spruce Bog Trail',
        1,
        '/static/gpx/132_Black_Spruce_Bog_Trail.gpx',
        'USA',
        'Vicenza',
        '',
        'Simona ligure',
        0.5,
        26.3,
        8.499,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mohawk Forest Trail',
        1,
        '/static/gpx/133_Mohawk_Forest_Trail.gpx',
        'USA',
        'Bari',
        '',
        'Raniero sardo',
        1.4,
        11.9,
        23.014,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ethan Allen Youth Trail',
        0,
        '/static/gpx/134_Ethan_Allen_Youth_Trail.gpx',
        'USA',
        'Ascoli Piceno',
        '',
        'San Semiramide',
        0.8,
        29.9,
        11.321,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Punch Brook Trail',
        1,
        '/static/gpx/135_Punch_Brook_Trail.gpx',
        'USA',
        'Monza e della Brianza',
        '',
        'Magno a mare',
        0.9,
        6.1,
        11.921,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Red Cedar Lake Trail',
        0,
        '/static/gpx/136_Red_Cedar_Lake_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'Quarto Balderico umbro',
        1.4,
        12.9,
        22.281,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Under Mountain Trail',
        1,
        '/static/gpx/137_Under_Mountain_Trail.gpx',
        'USA',
        'Padova',
        '',
        'Flore calabro',
        0.5,
        15.1,
        8.086,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mount Tom Trail',
        2,
        '/static/gpx/138_Mount_Tom_Trail.gpx',
        'USA',
        'Ravenna',
        '',
        'Giardina ligure',
        0.8,
        8,
        11.429,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Naugatuck Trail',
        1,
        '/static/gpx/139_Naugatuck_Trail.gpx',
        'USA',
        'Brescia',
        '',
        'Salvi ligure',
        0.6,
        19.7,
        7.86,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic Forest Trail',
        1,
        '/static/gpx/140_Nehantic_Forest_Trail.gpx',
        'USA',
        'Novara',
        '',
        'Beniamino sardo',
        0.5,
        24,
        7.557,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Naugatuck Forest Trail',
        0,
        '/static/gpx/141_Naugatuck_Forest_Trail.gpx',
        'USA',
        'Perugia',
        '',
        'Urdino lido',
        0.9,
        22.4,
        13.706,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Naugatuck Spur',
        1,
        '/static/gpx/142_Naugatuck_Spur.gpx',
        'USA',
        'Avellino',
        '',
        'San Gerino',
        0.6,
        27.8,
        8.072,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Whitemore Trail',
        0,
        '/static/gpx/143_Whitemore_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Settimo Marzia calabro',
        1.3,
        19.5,
        18.75,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinnipiac Trail',
        0,
        '/static/gpx/144_Quinnipiac_Trail.gpx',
        'USA',
        'Monza e della Brianza',
        '',
        'Alessia calabro',
        1.6,
        8.8,
        26.593,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic Forest Trai',
        2,
        '/static/gpx/145_Nehantic_Forest_Trai.gpx',
        'USA',
        'Firenze',
        '',
        'Borgo Sabino',
        1.1,
        5.2,
        14.732,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nepaug Forest Trail',
        2,
        '/static/gpx/146_Nepaug_Forest_Trail.gpx',
        'USA',
        'Carbonia-Iglesias',
        '',
        'Quarto Giovanni terme',
        0.5,
        7.7,
        7.16,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Naugatuck',
        2,
        '/static/gpx/147_Naugatuck.gpx',
        'USA',
        'Vibo Valentia',
        '',
        'Sesto Paola',
        1.5,
        15,
        22.277,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nyantaquit Trail',
        0,
        '/static/gpx/148_Nyantaquit_Trail.gpx',
        'USA',
        'Lucca',
        '',
        'Lazzaro sardo',
        1.5,
        12.8,
        24.59,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tipping Rock Loop Trail',
        1,
        '/static/gpx/149_Tipping_Rock_Loop_Trail.gpx',
        'USA',
        'Caltanissetta',
        '',
        'Calogera ligure',
        0.6,
        16.8,
        9.574,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Valley Outlook Trail',
        0,
        '/static/gpx/150_Valley_Outlook_Trail.gpx',
        'USA',
        'Alessandria',
        '',
        'San Enimia nell''emilia',
        1.1,
        26.2,
        15,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shelter 4 Loop Trail',
        2,
        '/static/gpx/151_Shelter_4_Loop_Trail.gpx',
        'USA',
        'Prato',
        '',
        'Borgo Celinia calabro',
        0.5,
        7.3,
        7.595,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Osbornedale Park Trail',
        2,
        '/static/gpx/152_Osbornedale_Park_Trail.gpx',
        'USA',
        'Enna',
        '',
        'Borgo Raffaella',
        1.2,
        24.4,
        15.319,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Unnamed',
        0,
        '/static/gpx/153_Unnamed.gpx',
        'USA',
        'Foggia',
        '',
        'Albina terme',
        0.9,
        10.9,
        12.385,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Paugnut Forest Trail',
        1,
        '/static/gpx/154_Paugnut_Forest_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'Oddone sardo',
        1.2,
        23.4,
        19.565,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Charles L Pack Trail',
        1,
        '/static/gpx/155_Charles_L_Pack_Trail.gpx',
        'USA',
        'Firenze',
        '',
        'Nocerino lido',
        1.5,
        29.5,
        18.33,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Peoples Forest Trail',
        0,
        '/static/gpx/156_Peoples_Forest_Trail.gpx',
        'USA',
        'Foggia',
        '',
        'Tobia del friuli',
        0.5,
        9.8,
        8.108,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Putnam Memorial Trail',
        0,
        '/static/gpx/157_Putnam_Memorial_Trail.gpx',
        'USA',
        'Ancona',
        '',
        'Bellino laziale',
        1.4,
        26.3,
        17.143,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Platt Hill Park Trail',
        2,
        '/static/gpx/158_Platt_Hill_Park_Trail.gpx',
        'USA',
        'Caltanissetta',
        '',
        'Pastorino nell''emilia',
        0.6,
        11.3,
        9.704,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Metacomet Trail',
        2,
        '/static/gpx/159_Metacomet_Trail.gpx',
        'USA',
        'Vibo Valentia',
        '',
        'Borgo Giambattista nell''emilia',
        1.4,
        9.3,
        17.108,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Metacomet Trail Bypass',
        0,
        '/static/gpx/160_Metacomet_Trail_Bypass.gpx',
        'USA',
        'Taranto',
        '',
        'Quarto Zosima',
        0.5,
        13.9,
        6.834,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Penwood Park Trail',
        0,
        '/static/gpx/161_Penwood_Park_Trail.gpx',
        'USA',
        'Prato',
        '',
        'Leandro salentino',
        1.5,
        10.6,
        23.136,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quadick Park Path',
        2,
        '/static/gpx/162_Quadick_Park_Path.gpx',
        'USA',
        'Verbano-Cusio-Ossola',
        '',
        'Aquilino veneto',
        1,
        11.5,
        13.453,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quadick Red Trail',
        2,
        '/static/gpx/163_Quadick_Red_Trail.gpx',
        'USA',
        'Imperia',
        '',
        'San Ciro',
        0.7,
        9.9,
        10.12,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pootatuck Forest Trail',
        0,
        '/static/gpx/164_Pootatuck_Forest_Trail.gpx',
        'USA',
        'Pordenone',
        '',
        'Settimo Cunegonda',
        0.5,
        28.5,
        8.152,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'River Highland Park Trail',
        2,
        '/static/gpx/165_River_Highland_Park_Trail.gpx',
        'USA',
        'Pordenone',
        '',
        'Sesto Vittore',
        0.7,
        13.1,
        10.853,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tunxis',
        1,
        '/static/gpx/166_Tunxis.gpx',
        'USA',
        'Bologna',
        '',
        'Castaldo lido',
        1.3,
        6.2,
        18.978,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Old Furnace Trail',
        2,
        '/static/gpx/167_Old_Furnace_Trail.gpx',
        'USA',
        'Benevento',
        '',
        'Alberto sardo',
        0.9,
        16,
        14.634,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Old Furnace Park Trail',
        2,
        '/static/gpx/168_Old_Furnace_Park_Trail.gpx',
        'USA',
        'Cagliari',
        '',
        'Luzi salentino',
        1.1,
        9.1,
        15.103,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kestral Trail',
        0,
        '/static/gpx/169_Kestral_Trail.gpx',
        'USA',
        'Caltanissetta',
        '',
        'Atanasia del friuli',
        0.5,
        8.8,
        8.357,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Warbler Trail',
        2,
        '/static/gpx/170_Warbler_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'San Dionigi veneto',
        0.6,
        12.4,
        8.276,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Muir Trail',
        0,
        '/static/gpx/171_Muir_Trail.gpx',
        'USA',
        'Brescia',
        '',
        'Pelagia ligure',
        1,
        13.8,
        13.636,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shadow Pond Nature Trail',
        2,
        '/static/gpx/172_Shadow_Pond_Nature_Trail.gpx',
        'USA',
        'Fermo',
        '',
        'Diletta nell''emilia',
        1.3,
        27.7,
        21.196,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Jesse Gerard Trail',
        2,
        '/static/gpx/173_Jesse_Gerard_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'San Trasea umbro',
        0.8,
        17,
        9.877,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Robert Ross Trail',
        1,
        '/static/gpx/174_Robert_Ross_Trail.gpx',
        'USA',
        'Asti',
        '',
        'Quarto Muziano',
        0.8,
        29,
        9.979,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Agnes Bowen Trail',
        0,
        '/static/gpx/175_Agnes_Bowen_Trail.gpx',
        'USA',
        'Benevento',
        '',
        'Menozzi nell''emilia',
        0.8,
        26,
        9.796,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Elliot Bronson Trail',
        0,
        '/static/gpx/176_Elliot_Bronson_Trail.gpx',
        'USA',
        'Terni',
        '',
        'Quarto Verena',
        1.1,
        18.7,
        16.019,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Walt Landgraf Trail',
        0,
        '/static/gpx/177_Walt_Landgraf_Trail.gpx',
        'USA',
        'Livorno',
        '',
        'Festo laziale',
        0.6,
        19.4,
        8.759,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Squantz Pond Park Trail',
        1,
        '/static/gpx/178_Squantz_Pond_Park_Trail.gpx',
        'USA',
        'Pesaro e Urbino',
        '',
        'Sesto Fiorenzo',
        0.6,
        15,
        7.407,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Putnam Memorial Museum Trail',
        2,
        '/static/gpx/179_Putnam_Memorial_Museum_Trail.gpx',
        'USA',
        'Matera',
        '',
        'Alamanno umbro',
        1.1,
        27.8,
        17.01,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinnipiac Park Trail',
        1,
        '/static/gpx/180_Quinnipiac_Park_Trail.gpx',
        'USA',
        'Ravenna',
        '',
        'Mercurio salentino',
        1,
        26.2,
        14.218,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Boardwalk',
        0,
        '/static/gpx/181_Boardwalk.gpx',
        'USA',
        'Catania',
        '',
        'Borgo Eginardo sardo',
        1.4,
        5.1,
        20.096,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rocky Neck Park Sidewalk',
        1,
        '/static/gpx/182_Rocky_Neck_Park_Sidewalk.gpx',
        'USA',
        'Medio Campidano',
        '',
        'Genziano veneto',
        1.4,
        18.4,
        18.065,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rocky Neck Park Path',
        0,
        '/static/gpx/183_Rocky_Neck_Park_Path.gpx',
        'USA',
        'Foggia',
        '',
        'Magliocco calabro',
        1.1,
        6.9,
        15.789,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rocky Neck Park Trail',
        0,
        '/static/gpx/184_Rocky_Neck_Park_Trail.gpx',
        'USA',
        'Agrigento',
        '',
        'Quarto Viviano',
        1.5,
        14.6,
        22.222,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rope Swing',
        1,
        '/static/gpx/185_Rope_Swing.gpx',
        'USA',
        'Imperia',
        '',
        'Rocchi del friuli',
        1,
        23.8,
        14.851,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sherwood Island Park Path',
        1,
        '/static/gpx/186_Sherwood_Island_Park_Path.gpx',
        'USA',
        'Pavia',
        '',
        'Prospera a mare',
        0.6,
        11,
        9.091,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sleeping Giant Park Trail',
        0,
        '/static/gpx/187_Sleeping_Giant_Park_Trail.gpx',
        'USA',
        'Lodi',
        '',
        'Settimo Morgana',
        1.2,
        25.4,
        19.098,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sherwood Island Nature Trail',
        0,
        '/static/gpx/188_Sherwood_Island_Nature_Trail.gpx',
        'USA',
        'Verona',
        '',
        'Iovino veneto',
        0.7,
        21.5,
        8.434,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sleeping Giant Park Path',
        0,
        '/static/gpx/189_Sleeping_Giant_Park_Path.gpx',
        'USA',
        'Parma',
        '',
        'Alcamo del friuli',
        0.6,
        6.4,
        9.549,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tower Trail',
        1,
        '/static/gpx/190_Tower_Trail.gpx',
        'USA',
        'Ascoli Piceno',
        '',
        'San Plutarco a mare',
        0.7,
        17.3,
        10.219,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinnipiac Trail Spur',
        0,
        '/static/gpx/191_Quinnipiac_Trail_Spur.gpx',
        'USA',
        'Modena',
        '',
        'San Amone',
        1.3,
        26,
        19.165,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Southford Falls Park Trail',
        1,
        '/static/gpx/192_Southford_Falls_Park_Trail.gpx',
        'USA',
        'Gorizia',
        '',
        'Tina veneto',
        0.6,
        23.1,
        9.524,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tunxis Forest Trail',
        1,
        '/static/gpx/193_Tunxis_Forest_Trail.gpx',
        'USA',
        'Salerno',
        '',
        'Schettino ligure',
        1,
        29.1,
        15.385,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sleeping Giant Trail',
        0,
        '/static/gpx/194_Sleeping_Giant_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'Quarto Rosmunda laziale',
        1.2,
        25.7,
        16.667,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Stratton Brook Park Path',
        2,
        '/static/gpx/195_Stratton_Brook_Park_Path.gpx',
        'USA',
        'Sondrio',
        '',
        'San Gerino ligure',
        0.6,
        18.3,
        8.824,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bike Trail',
        1,
        '/static/gpx/196_Bike_Trail.gpx',
        'USA',
        'Terni',
        '',
        'Mura nell''emilia',
        1.4,
        23,
        19.4,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Stratton Brook Park Trail',
        1,
        '/static/gpx/197_Stratton_Brook_Park_Trail.gpx',
        'USA',
        'Reggio Calabria',
        '',
        'San Saffiro',
        1,
        17.6,
        13.1,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Simsbury Park Trail',
        2,
        '/static/gpx/198_Simsbury_Park_Trail.gpx',
        'USA',
        'Enna',
        '',
        'Sesto Emiliana lido',
        1.2,
        6.9,
        15.517,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Wolcott Trail',
        0,
        '/static/gpx/199_Wolcott_Trail.gpx',
        'USA',
        'Bolzano',
        '',
        'Errichiello calabro',
        0.9,
        6.1,
        11.157,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Madden Fyler Pond Trail',
        0,
        '/static/gpx/200_Madden_Fyler_Pond_Trail.gpx',
        'USA',
        'Torino',
        '',
        'Quarto Margherita veneto',
        1.2,
        23.6,
        15.517,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sunny Brook Park Trail',
        0,
        '/static/gpx/201_Sunny_Brook_Park_Trail.gpx',
        'USA',
        'Taranto',
        '',
        'Ermes sardo',
        1,
        5.3,
        16.26,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Fadoir Spring Trail',
        0,
        '/static/gpx/202_Fadoir_Spring_Trail.gpx',
        'USA',
        'Pescara',
        '',
        'Piscitelli ligure',
        0.5,
        5.4,
        6.173,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Fadoir Trail',
        2,
        '/static/gpx/203_Fadoir_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'Settimo Sigfrido',
        1.1,
        20.9,
        16.098,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Walnut Mountain Trail',
        2,
        '/static/gpx/204_Walnut_Mountain_Trail.gpx',
        'USA',
        'Arezzo',
        '',
        'Zeno veneto',
        1.1,
        24.3,
        14.163,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Wolcott',
        0,
        '/static/gpx/205_Wolcott.gpx',
        'USA',
        'Treviso',
        '',
        'Pastorino lido',
        0.5,
        5.7,
        6.593,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Old Metacomet Trail',
        1,
        '/static/gpx/206_Old_Metacomet_Trail.gpx',
        'USA',
        'Benevento',
        '',
        'Caiazzo terme',
        0.9,
        13.8,
        13.433,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Talcott Mountain Park Trail',
        0,
        '/static/gpx/207_Talcott_Mountain_Park_Trail.gpx',
        'USA',
        'Genova',
        '',
        'La Rocca laziale',
        0.8,
        21.8,
        11.566,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Falls Brook Trail',
        0,
        '/static/gpx/208_Falls_Brook_Trail.gpx',
        'USA',
        'Modena',
        '',
        'Sesto Attila ligure',
        1.4,
        26.9,
        22.105,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Whittemore Glen Trail',
        2,
        '/static/gpx/209_Whittemore_Glen_Trail.gpx',
        'USA',
        'Salerno',
        '',
        'Sapiente veneto',
        1.5,
        27.4,
        24.658,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Wharton Brook Park Trail',
        0,
        '/static/gpx/210_Wharton_Brook_Park_Trail.gpx',
        'USA',
        'Trento',
        '',
        'Borgo Adone',
        0.9,
        7.5,
        13.706,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Larkin Bridle Trail',
        2,
        '/static/gpx/211_Larkin_Bridle_Trail.gpx',
        'USA',
        'Cuneo',
        '',
        'Fosco umbro',
        5.4,
        22.1,
        67.22,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bluff Point Bike Path',
        0,
        '/static/gpx/212_Bluff_Point_Bike_Path.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Boris del friuli',
        1,
        27.2,
        14.493,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bluff Point Trail',
        2,
        '/static/gpx/213_Bluff_Point_Trail.gpx',
        'USA',
        'Lecce',
        '',
        'Settimo Alvaro',
        1.3,
        15.7,
        17.333,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Hrt - Main Street Spur',
        1,
        '/static/gpx/214_Hrt___Main_Street_Spur.gpx',
        'USA',
        'Ragusa',
        '',
        'Blanc sardo',
        1.4,
        22.7,
        17.355,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Laurel Brook Trail',
        2,
        '/static/gpx/215_Laurel_Brook_Trail.gpx',
        'USA',
        'Padova',
        '',
        'Settimo Vladimiro',
        1.5,
        9,
        21.226,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Wadsworth Falls Park Trail',
        2,
        '/static/gpx/216_Wadsworth_Falls_Park_Trail.gpx',
        'USA',
        'Arezzo',
        '',
        'Borgo Gioberto',
        1.1,
        27.9,
        18.033,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'White Birch Trail',
        2,
        '/static/gpx/217_White_Birch_Trail.gpx',
        'USA',
        'Carbonia-Iglesias',
        '',
        'Borgo Graciliano laziale',
        1.2,
        16.3,
        14.694,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Red Cedar Trail',
        2,
        '/static/gpx/218_Red_Cedar_Trail.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Amanda a mare',
        1.4,
        11.8,
        16.97,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Little Falls Trail',
        2,
        '/static/gpx/219_Little_Falls_Trail.gpx',
        'USA',
        'Reggio Emilia',
        '',
        'San Querano',
        1.5,
        11.7,
        23.622,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Deer Trail',
        2,
        '/static/gpx/220_Deer_Trail.gpx',
        'USA',
        'Salerno',
        '',
        'Rallo laziale',
        0.7,
        24.3,
        10.169,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Rockfall Land Trust Trail',
        2,
        '/static/gpx/221_Rockfall_Land_Trust_Trail.gpx',
        'USA',
        'Messina',
        '',
        'Nocentini terme',
        1.5,
        20.1,
        19.523,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bridge Trail',
        2,
        '/static/gpx/222_Bridge_Trail.gpx',
        'USA',
        'Isernia',
        '',
        'Borgo Rodiano',
        0.8,
        24.7,
        10.39,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Main Trail',
        2,
        '/static/gpx/223_Main_Trail.gpx',
        'USA',
        'Isernia',
        '',
        'Mastrogiacomo salentino',
        0.7,
        19.9,
        11.23,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'American Legion Forest Trail',
        2,
        '/static/gpx/224_American_Legion_Forest_Trail.gpx',
        'USA',
        'Cremona',
        '',
        'Evangelista sardo',
        0.8,
        22.5,
        11.679,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Turkey Vultures Ledges Trail',
        2,
        '/static/gpx/225_Turkey_Vultures_Ledges_Trail.gpx',
        'USA',
        'Pordenone',
        '',
        'Quarto Antonella',
        1.2,
        9.8,
        16.29,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Henry R Buck Trail',
        2,
        '/static/gpx/226_Henry_R_Buck_Trail.gpx',
        'USA',
        'Avellino',
        '',
        'Leonida laziale',
        5.2,
        18.7,
        85.714,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mashapaug Pond View Trail',
        2,
        '/static/gpx/227_Mashapaug_Pond_View_Trail.gpx',
        'USA',
        'Brescia',
        '',
        'Perilli nell''emilia',
        1.1,
        24.1,
        15.529,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bigelow Hollow Park Trail',
        2,
        '/static/gpx/228_Bigelow_Hollow_Park_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'Trovato ligure',
        1.1,
        7.4,
        13.895,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Breakneck Pond View Trail',
        2,
        '/static/gpx/229_Breakneck_Pond_View_Trail.gpx',
        'USA',
        'Enna',
        '',
        'Sesto Norina',
        1.2,
        10.5,
        19.407,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'East Ridge Trail',
        2,
        '/static/gpx/230_East_Ridge_Trail.gpx',
        'USA',
        'Udine',
        '',
        'Liberati veneto',
        1.4,
        30,
        19.005,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bigelow Pond Loop Trail',
        2,
        '/static/gpx/231_Bigelow_Pond_Loop_Trail.gpx',
        'USA',
        'Potenza',
        '',
        'Gianluigi del friuli',
        1.2,
        15.9,
        18.228,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ridge Trail',
        2,
        '/static/gpx/232_Ridge_Trail.gpx',
        'USA',
        'Cremona',
        '',
        'Quarto Melchiade sardo',
        1.1,
        29.5,
        14.898,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nipmuck Trail',
        2,
        '/static/gpx/233_Nipmuck_Trail.gpx',
        'USA',
        'Padova',
        '',
        'Mercuri calabro',
        1.1,
        16.3,
        16.058,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattatuck Trail',
        2,
        '/static/gpx/234_Mattatuck_Trail.gpx',
        'USA',
        'Prato',
        '',
        'Vidiano a mare',
        0.5,
        10.1,
        7.895,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Black Rock Park Trail',
        2,
        '/static/gpx/235_Black_Rock_Park_Trail.gpx',
        'USA',
        'Nuoro',
        '',
        'Lolli lido',
        1,
        20.4,
        12.397,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Poquonnock River Walk',
        1,
        '/static/gpx/236_Poquonnock_River_Walk.gpx',
        'USA',
        'Ravenna',
        '',
        'Sesto Iacopone umbro',
        0.5,
        21.1,
        8.547,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kempf & Shenipsit Trail',
        2,
        '/static/gpx/237_Kempf___Shenipsit_Trail.gpx',
        'USA',
        'Parma',
        '',
        'Borgo Siro sardo',
        1.4,
        13.5,
        20.144,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kempf Trail',
        1,
        '/static/gpx/238_Kempf_Trail.gpx',
        'USA',
        'Vercelli',
        '',
        'Borgo Adelfo',
        0.8,
        10.5,
        10.256,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Railroad Bed',
        0,
        '/static/gpx/239_Railroad_Bed.gpx',
        'USA',
        'Pavia',
        '',
        'Generosa calabro',
        0.8,
        22.5,
        11.594,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mohegan Trail',
        0,
        '/static/gpx/240_Mohegan_Trail.gpx',
        'USA',
        'Rimini',
        '',
        'Romilda laziale',
        0.7,
        16.2,
        11.667,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Burr Pond Park Trail',
        1,
        '/static/gpx/241_Burr_Pond_Park_Trail.gpx',
        'USA',
        'Udine',
        '',
        'Sesto Aloisio calabro',
        1.5,
        9.1,
        20.455,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Burr Pond Park Path',
        1,
        '/static/gpx/242_Burr_Pond_Park_Path.gpx',
        'USA',
        'Ancona',
        '',
        'Borgo Elvia',
        1,
        12.1,
        14.052,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Campbell Falls Trail',
        0,
        '/static/gpx/243_Campbell_Falls_Trail.gpx',
        'USA',
        'Catania',
        '',
        'Quarto Liberatore sardo',
        1.5,
        16.7,
        18.634,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Deep Woods Trail',
        2,
        '/static/gpx/244_Deep_Woods_Trail.gpx',
        'USA',
        'Catanzaro',
        '',
        'Neri a mare',
        0.7,
        6.2,
        10.769,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chimney Trail',
        2,
        '/static/gpx/245_Chimney_Trail.gpx',
        'USA',
        'Asti',
        '',
        'Settimo Sonia laziale',
        1.8,
        10.3,
        22.222,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chimney Connector Trail',
        2,
        '/static/gpx/246_Chimney_Connector_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'Melissa del friuli',
        0.9,
        23.5,
        13.203,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'East Woods Trail',
        2,
        '/static/gpx/247_East_Woods_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Antonella a mare',
        1.4,
        9.2,
        23.529,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'East Woods Connector Trail',
        2,
        '/static/gpx/248_East_Woods_Connector_Trail.gpx',
        'USA',
        'Pistoia',
        '',
        'Carla calabro',
        0.8,
        28.2,
        11.94,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Covered Bridge Connector Trail',
        2,
        '/static/gpx/249_Covered_Bridge_Connector_Trail.gpx',
        'USA',
        'Rieti',
        '',
        'Quarto Fernando calabro',
        0.8,
        23.8,
        10.367,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Covered Bridge Trail',
        2,
        '/static/gpx/250_Covered_Bridge_Trail.gpx',
        'USA',
        'Mantova',
        '',
        'San Cremenzio sardo',
        1.3,
        28,
        19.549,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Lookout Trail',
        2,
        '/static/gpx/251_Lookout_Trail.gpx',
        'USA',
        'Livorno',
        '',
        'Zullo del friuli',
        1.3,
        29,
        19.259,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chatfield Hollow Park Trail',
        2,
        '/static/gpx/252_Chatfield_Hollow_Park_Trail.gpx',
        'USA',
        'Bologna',
        '',
        'Settimo Attila',
        1.1,
        16.7,
        15.942,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Lookout Spur Trail',
        2,
        '/static/gpx/253_Lookout_Spur_Trail.gpx',
        'USA',
        'Lecce',
        '',
        'Quarto Bertoldo',
        1.4,
        13.3,
        18.341,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chimney Spur Trail',
        2,
        '/static/gpx/254_Chimney_Spur_Trail.gpx',
        'USA',
        'Ragusa',
        '',
        'Fernanda terme',
        0.8,
        13.7,
        10.345,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Deep Woods Access Trail',
        2,
        '/static/gpx/255_Deep_Woods_Access_Trail.gpx',
        'USA',
        'Alessandria',
        '',
        'Renda del friuli',
        1.1,
        17.7,
        13.983,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'West Crest Trail',
        2,
        '/static/gpx/256_West_Crest_Trail.gpx',
        'USA',
        'Reggio Emilia',
        '',
        'San Carla laziale',
        0.9,
        21.4,
        12.385,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chatfield Park Path',
        2,
        '/static/gpx/257_Chatfield_Park_Path.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Narseo nell''emilia',
        0.9,
        27.2,
        13.268,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pond Trail',
        2,
        '/static/gpx/258_Pond_Trail.gpx',
        'USA',
        'Reggio Emilia',
        '',
        'Sesto Doroteo',
        0.9,
        8.7,
        13.433,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Paul F Wildermann',
        1,
        '/static/gpx/259_Paul_F_Wildermann.gpx',
        'USA',
        'Prato',
        '',
        'Settimo Azelia',
        1.2,
        10.2,
        14.545,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Cockaponset Forest Path',
        2,
        '/static/gpx/260_Cockaponset_Forest_Path.gpx',
        'USA',
        'Savona',
        '',
        'Sesto Lapo',
        0.9,
        29.2,
        12.135,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kay Fullerton Trail',
        2,
        '/static/gpx/261_Kay_Fullerton_Trail.gpx',
        'USA',
        'Torino',
        '',
        'San Dodato terme',
        0.6,
        19.1,
        10.028,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinimay Trail',
        2,
        '/static/gpx/262_Quinimay_Trail.gpx',
        'USA',
        'Cremona',
        '',
        'Quarto Agapito lido',
        1,
        25.9,
        12.245,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Cowboy Way Trail',
        2,
        '/static/gpx/263_Cowboy_Way_Trail.gpx',
        'USA',
        'Trento',
        '',
        'Settimo Annibale',
        1,
        11.1,
        14.184,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Muck Rock Road Trail',
        2,
        '/static/gpx/264_Muck_Rock_Road_Trail.gpx',
        'USA',
        'Vibo Valentia',
        '',
        'Quarto Sabino',
        1.1,
        14.1,
        13.442,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Weber Road Trail',
        2,
        '/static/gpx/265_Weber_Road_Trail.gpx',
        'USA',
        'Como',
        '',
        'Sesto Gaudino calabro',
        0.9,
        23.6,
        11.088,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Beechnut Bog Trail',
        2,
        '/static/gpx/266_Beechnut_Bog_Trail.gpx',
        'USA',
        'Massa-Carrara',
        '',
        'Liberto terme',
        0.8,
        7,
        12.308,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Wood Road Trail',
        2,
        '/static/gpx/267_Wood_Road_Trail.gpx',
        'USA',
        'Padova',
        '',
        'San Calogero sardo',
        0.6,
        6.3,
        8.654,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bumpy Hill Road Trail',
        2,
        '/static/gpx/268_Bumpy_Hill_Road_Trail.gpx',
        'USA',
        'Firenze',
        '',
        'Bertolini umbro',
        0.7,
        9.6,
        11.024,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kristens Way Trail',
        2,
        '/static/gpx/269_Kristens_Way_Trail.gpx',
        'USA',
        'Enna',
        '',
        'Borgo Dulina',
        1.3,
        17.1,
        21.311,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Messerschmidt Lane Trail',
        2,
        '/static/gpx/270_Messerschmidt_Lane_Trail.gpx',
        'USA',
        'Isernia',
        '',
        'Monica laziale',
        1.5,
        6,
        18.987,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tower Hill Connector Trail',
        2,
        '/static/gpx/271_Tower_Hill_Connector_Trail.gpx',
        'USA',
        'Benevento',
        '',
        'Angela veneto',
        1.3,
        25.2,
        20.526,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattabesset Trail',
        2,
        '/static/gpx/272_Mattabesset_Trail.gpx',
        'USA',
        'Bolzano',
        '',
        'Guastella calabro',
        1.6,
        5.6,
        26.23,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mattabasset Trail',
        2,
        '/static/gpx/273_Mattabasset_Trail.gpx',
        'USA',
        'Ferrara',
        '',
        'San Graziano',
        0.8,
        22.5,
        11.034,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Old Mattebesset Trail',
        2,
        '/static/gpx/274_Old_Mattebesset_Trail.gpx',
        'USA',
        'Torino',
        '',
        'Leonzio sardo',
        1.2,
        17.3,
        19.78,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Huntington Park Trail',
        2,
        '/static/gpx/275_Huntington_Park_Trail.gpx',
        'USA',
        'Sondrio',
        '',
        'Quarto Norina',
        0.7,
        14.5,
        9.906,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Huntington Ridge Trail',
        2,
        '/static/gpx/276_Huntington_Ridge_Trail.gpx',
        'USA',
        'Verona',
        '',
        'Quarto Asella',
        1.5,
        16.1,
        24.064,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Aspetuck Valley Trail',
        2,
        '/static/gpx/277_Aspetuck_Valley_Trail.gpx',
        'USA',
        'Pisa',
        '',
        'Settimo Rosalinda umbro',
        0.6,
        21.4,
        9.091,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Vista Trail',
        2,
        '/static/gpx/278_Vista_Trail.gpx',
        'USA',
        'Fermo',
        '',
        'Sesto Abibo sardo',
        1.5,
        11.3,
        23.196,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Devils Hopyard Park Trail',
        2,
        '/static/gpx/279_Devils_Hopyard_Park_Trail.gpx',
        'USA',
        'Medio Campidano',
        '',
        'Settimo Marinetta laziale',
        1.2,
        16.9,
        16.107,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Witch Hazel/Millington Trail',
        2,
        '/static/gpx/280_Witch_Hazel_Millington_Trail.gpx',
        'USA',
        'Viterbo',
        '',
        'Settimo Santina nell''emilia',
        1,
        25.4,
        13.699,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Millington Trail',
        2,
        '/static/gpx/281_Millington_Trail.gpx',
        'USA',
        'Carbonia-Iglesias',
        '',
        'Sesto Egeo',
        1.5,
        22.4,
        19.565,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Loop Trail',
        2,
        '/static/gpx/282_Loop_Trail.gpx',
        'USA',
        'Sassari',
        '',
        'San Wanda',
        1.4,
        9.2,
        22.642,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Witch Hazel Trail',
        2,
        '/static/gpx/283_Witch_Hazel_Trail.gpx',
        'USA',
        'Reggio Emilia',
        '',
        'Di Palma calabro',
        2,
        5,
        27.842,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Woodcutters Trail',
        2,
        '/static/gpx/284_Woodcutters_Trail.gpx',
        'USA',
        'Livorno',
        '',
        'Quarto Miriam',
        1.6,
        17.5,
        27.042,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Chapman Falls Trail',
        2,
        '/static/gpx/285_Chapman_Falls_Trail.gpx',
        'USA',
        'Crotone',
        '',
        'San Apollonia terme',
        0.9,
        16,
        14.876,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Devils Oven Spur Trail',
        2,
        '/static/gpx/286_Devils_Oven_Spur_Trail.gpx',
        'USA',
        'Pistoia',
        '',
        'De Biase veneto',
        1.4,
        9.2,
        23.529,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Maxs Trail',
        2,
        '/static/gpx/287_Maxs_Trail.gpx',
        'USA',
        'Trento',
        '',
        'Mansueto umbro',
        3.1,
        27.6,
        39.323,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Machimoodus Park Trail',
        1,
        '/static/gpx/288_Machimoodus_Park_Trail.gpx',
        'USA',
        'Fermo',
        '',
        'Zenaide salentino',
        0.6,
        27.9,
        9.783,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Fishermans Trail',
        2,
        '/static/gpx/289_Fishermans_Trail.gpx',
        'USA',
        'Pisa',
        '',
        'Sesto Porfirio veneto',
        1.5,
        11.4,
        19.481,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ccc Trail',
        2,
        '/static/gpx/290_Ccc_Trail.gpx',
        'USA',
        'Ragusa',
        '',
        'Sesto Virginio calabro',
        2.2,
        7.2,
        28.884,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Natchaug Trail',
        2,
        '/static/gpx/291_Natchaug_Trail.gpx',
        'USA',
        'L''Aquila',
        '',
        'Aniello sardo',
        0.8,
        24.2,
        13.008,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Natchaug Forest Trail',
        2,
        '/static/gpx/292_Natchaug_Forest_Trail.gpx',
        'USA',
        'Novara',
        '',
        'Settimo Manlio',
        1.4,
        25.6,
        16.834,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Goodwin Forest Trail',
        2,
        '/static/gpx/293_Goodwin_Forest_Trail.gpx',
        'USA',
        'Trapani',
        '',
        'Sesto Gaglioffo salentino',
        1.1,
        26.4,
        13.836,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pine Acres Pond Trail',
        2,
        '/static/gpx/294_Pine_Acres_Pond_Trail.gpx',
        'USA',
        'Sassari',
        '',
        'Borgo Claudio veneto',
        0.9,
        23.7,
        11.868,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Brown Hill Pond Trail',
        2,
        '/static/gpx/295_Brown_Hill_Pond_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'Illidio laziale',
        0.5,
        11.8,
        8.021,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Yellow White Loop Trail',
        2,
        '/static/gpx/296_Yellow_White_Loop_Trail.gpx',
        'USA',
        'Benevento',
        '',
        'Isidora a mare',
        1.5,
        16.9,
        19.027,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Red Yellow Connector Trail',
        2,
        '/static/gpx/297_Red_Yellow_Connector_Trail.gpx',
        'USA',
        'Novara',
        '',
        'Mario veneto',
        0.7,
        19.4,
        9.976,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Governor''S Island Trail',
        2,
        '/static/gpx/298_Governor_S_Island_Trail.gpx',
        'USA',
        'Varese',
        '',
        'Lombardo calabro',
        1,
        6.8,
        15.544,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Goodwin Foresttrail',
        2,
        '/static/gpx/299_Goodwin_Foresttrail.gpx',
        'USA',
        'Lodi',
        '',
        'Taormina calabro',
        0.5,
        26.6,
        6.772,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Forest Discovery Trail',
        2,
        '/static/gpx/300_Forest_Discovery_Trail.gpx',
        'USA',
        'Milano',
        '',
        'Ciotti lido',
        1.4,
        14.5,
        20.144,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Goodwin Heritage Trail',
        2,
        '/static/gpx/301_Goodwin_Heritage_Trail.gpx',
        'USA',
        'Trieste',
        '',
        'San Simone',
        0.7,
        13.4,
        8.714,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Crest',
        2,
        '/static/gpx/302_Crest.gpx',
        'USA',
        'Biella',
        '',
        'Quarto Erardo',
        1,
        11.6,
        16.304,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mansfield Hollow Park Trail',
        2,
        '/static/gpx/303_Mansfield_Hollow_Park_Trail.gpx',
        'USA',
        'Belluno',
        '',
        'Quarto Gertrude',
        1.6,
        9.6,
        27.042,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nipmuck Trail - East Branch',
        0,
        '/static/gpx/304_Nipmuck_Trail___East_Branch.gpx',
        'USA',
        'Vibo Valentia',
        '',
        'Gustavo sardo',
        0.7,
        17.9,
        9.976,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nipmuck Alternate',
        0,
        '/static/gpx/305_Nipmuck_Alternate.gpx',
        'USA',
        'Avellino',
        '',
        'Borgo Fleano',
        2.4,
        13.5,
        38.095,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mashamoquet Brook Nature Trail',
        0,
        '/static/gpx/306_Mashamoquet_Brook_Nature_Trail.gpx',
        'USA',
        'Trapani',
        '',
        'Settimo Alcibiade',
        1.4,
        19.2,
        20.29,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nipmuck Forest Trail',
        2,
        '/static/gpx/307_Nipmuck_Forest_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'Venerio ligure',
        0.9,
        6.1,
        12.5,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Morey Pond Trail',
        2,
        '/static/gpx/308_Morey_Pond_Trail.gpx',
        'USA',
        'Bolzano',
        '',
        'Cerri nell''emilia',
        1.1,
        27.6,
        17.838,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nipmuck Foreat Trail',
        2,
        '/static/gpx/309_Nipmuck_Foreat_Trail.gpx',
        'USA',
        'Ragusa',
        '',
        'Porfirio nell''emilia',
        1.2,
        13.9,
        16.18,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pharisee Rock Trail',
        2,
        '/static/gpx/310_Pharisee_Rock_Trail.gpx',
        'USA',
        'Genova',
        '',
        'San Ezechiele',
        1.5,
        6.9,
        20.045,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug Forest Trail',
        2,
        '/static/gpx/311_Pachaug_Forest_Trail.gpx',
        'USA',
        'Foggia',
        '',
        'Sesto Arabella umbro',
        1,
        7.6,
        13.216,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug Trail',
        2,
        '/static/gpx/312_Pachaug_Trail.gpx',
        'USA',
        'Matera',
        '',
        'Piero del friuli',
        0.7,
        20,
        9.211,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Canonicus Trail',
        2,
        '/static/gpx/313_Canonicus_Trail.gpx',
        'USA',
        'Ascoli Piceno',
        '',
        'Di Iorio terme',
        1.1,
        19.1,
        14.317,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug',
        2,
        '/static/gpx/314_Pachaug.gpx',
        'USA',
        'Pavia',
        '',
        'Gaio lido',
        1.4,
        23.5,
        23.14,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Laurel Loop Trail',
        2,
        '/static/gpx/315_Laurel_Loop_Trail.gpx',
        'USA',
        'Nuoro',
        '',
        'Arduino nell''emilia',
        0.5,
        22.5,
        7.212,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug/Nehantic Connector',
        2,
        '/static/gpx/316_Pachaug_Nehantic_Connector.gpx',
        'USA',
        'Monza e della Brianza',
        '',
        'Sesto Ireneo',
        1.3,
        14.5,
        22.286,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug/Tippecansett Connector',
        2,
        '/static/gpx/317_Pachaug_Tippecansett_Connector.gpx',
        'USA',
        'Caserta',
        '',
        'Quarto Candida',
        0.7,
        8.7,
        10.853,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic/Pachaug Connector',
        2,
        '/static/gpx/318_Nehantic_Pachaug_Connector.gpx',
        'USA',
        'Campobasso',
        '',
        'Settimo Donato umbro',
        1.5,
        28.2,
        22.005,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinebaug/Pachaug Connector',
        2,
        '/static/gpx/319_Quinebaug_Pachaug_Connector.gpx',
        'USA',
        'Bolzano',
        '',
        'San Tammaro',
        1.3,
        20,
        19.024,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinebaug Trail',
        2,
        '/static/gpx/320_Quinebaug_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Landolfo laziale',
        0.9,
        29.9,
        12.981,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pachaug/Narragansett Connector',
        2,
        '/static/gpx/321_Pachaug_Narragansett_Connector.gpx',
        'USA',
        'Perugia',
        '',
        'Sesto Beata nell''emilia',
        1.1,
        28.4,
        16.377,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Narragansett Trail',
        2,
        '/static/gpx/322_Narragansett_Trail.gpx',
        'USA',
        'Savona',
        '',
        'Cacciapuoti laziale',
        0.6,
        19.9,
        9.424,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Green Falls Loop Trail',
        2,
        '/static/gpx/323_Green_Falls_Loop_Trail.gpx',
        'USA',
        'Avellino',
        '',
        'Orso terme',
        0.7,
        18.2,
        10.072,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Green Falls Water Access Trail',
        2,
        '/static/gpx/324_Green_Falls_Water_Access_Trail.gpx',
        'USA',
        'Ascoli Piceno',
        '',
        'Quarto Saturniano',
        0.7,
        25.5,
        9.091,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Freeman Trail',
        2,
        '/static/gpx/325_Freeman_Trail.gpx',
        'USA',
        'Perugia',
        '',
        'Quarto Felice a mare',
        1.2,
        14.6,
        20.168,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tippecansett Trail',
        2,
        '/static/gpx/326_Tippecansett_Trail.gpx',
        'USA',
        'Piacenza',
        '',
        'Settimo Agnese del friuli',
        0.8,
        24.9,
        9.959,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Tippecansett/Freeman Trail',
        2,
        '/static/gpx/327_Tippecansett_Freeman_Trail.gpx',
        'USA',
        'Varese',
        '',
        'Iolanda a mare',
        1.1,
        22.9,
        13.608,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Green Falls Pond Trail',
        1,
        '/static/gpx/328_Green_Falls_Pond_Trail.gpx',
        'USA',
        'Isernia',
        '',
        'Repetto a mare',
        1.2,
        8.5,
        14.724,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic/Pachaug Trail',
        2,
        '/static/gpx/329_Nehantic_Pachaug_Trail.gpx',
        'USA',
        'Ogliastra',
        '',
        'Speranza ligure',
        0.7,
        5.6,
        10.024,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Phillips Pond Spur Trail',
        2,
        '/static/gpx/330_Phillips_Pond_Spur_Trail.gpx',
        'USA',
        'Campobasso',
        '',
        'Sesto Gertrude nell''emilia',
        1.5,
        29.5,
        21.635,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quinebaug/Nehantic Connector',
        2,
        '/static/gpx/331_Quinebaug_Nehantic_Connector.gpx',
        'USA',
        'Cremona',
        '',
        'San Bruna umbro',
        0.8,
        27.5,
        13.043,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nehantic/Quinebaug Connector',
        1,
        '/static/gpx/332_Nehantic_Quinebaug_Connector.gpx',
        'USA',
        'Forlì-Cesena',
        '',
        'Giancarlo sardo',
        0.7,
        26.8,
        10,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Patagansett Trail',
        0,
        '/static/gpx/333_Patagansett_Trail.gpx',
        'USA',
        'Perugia',
        '',
        'San Elvira a mare',
        1.4,
        7.4,
        23.662,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Paugussett Forest Trail',
        2,
        '/static/gpx/334_Paugussett_Forest_Trail.gpx',
        'USA',
        'Perugia',
        '',
        'Sesto Giovenzio nell''emilia',
        1.3,
        22.2,
        19.024,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Zoar Trail',
        2,
        '/static/gpx/335_Zoar_Trail.gpx',
        'USA',
        'Lucca',
        '',
        'Veneranda lido',
        1,
        11.6,
        16.304,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Lillinonah Trail',
        2,
        '/static/gpx/336_Lillinonah_Trail.gpx',
        'USA',
        'Bari',
        '',
        'Aristarco a mare',
        1.2,
        5.2,
        14.694,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Zoar Trail (Old)',
        2,
        '/static/gpx/337_Zoar_Trail__Old_.gpx',
        'USA',
        'Grosseto',
        '',
        'Borgo Michele sardo',
        0.7,
        8.5,
        9.79,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Upper Gussy Trail',
        1,
        '/static/gpx/338_Upper_Gussy_Trail.gpx',
        'USA',
        'Latina',
        '',
        'Sesto Platone',
        1,
        10,
        12.848,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Pierrepont Park Trail',
        2,
        '/static/gpx/339_Pierrepont_Park_Trail.gpx',
        'USA',
        'Vicenza',
        '',
        'Cipolla del friuli',
        1,
        21.7,
        15.707,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shenipsit Forest Trail',
        2,
        '/static/gpx/340_Shenipsit_Forest_Trail.gpx',
        'USA',
        'Agrigento',
        '',
        'Giuda laziale',
        0.8,
        14.2,
        12.121,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Quary Trail',
        2,
        '/static/gpx/341_Quary_Trail.gpx',
        'USA',
        'Trento',
        '',
        'Cacciatore sardo',
        1.1,
        20.4,
        16.625,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Shenipsit Forest Road',
        2,
        '/static/gpx/342_Shenipsit_Forest_Road.gpx',
        'USA',
        'Benevento',
        '',
        'San Ambrosiano sardo',
        1,
        11.4,
        15.345,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Topsmead Forest Trail',
        2,
        '/static/gpx/343_Topsmead_Forest_Trail.gpx',
        'USA',
        'Caserta',
        '',
        'Edgardo lido',
        1.2,
        26.8,
        20,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Edith M Chase Ecology Trail',
        2,
        '/static/gpx/344_Edith_M_Chase_Ecology_Trail.gpx',
        'USA',
        'Latina',
        '',
        'Renato lido',
        2.3,
        15.9,
        28.992,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bernard H Stairs Trail',
        2,
        '/static/gpx/345_Bernard_H_Stairs_Trail.gpx',
        'USA',
        'Crotone',
        '',
        'Restivo lido',
        0.8,
        16.8,
        11.06,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'West Rock Park Trail',
        2,
        '/static/gpx/346_West_Rock_Park_Trail.gpx',
        'USA',
        'Matera',
        '',
        'Settimo Evaristo',
        1.5,
        7.3,
        19.694,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'West Rock Summit Trail',
        2,
        '/static/gpx/347_West_Rock_Summit_Trail.gpx',
        'USA',
        'Avellino',
        '',
        'Valenza nell''emilia',
        0.6,
        14.6,
        7.214,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Regicides Trail',
        2,
        '/static/gpx/348_Regicides_Trail.gpx',
        'USA',
        'Latina',
        '',
        'Settimo Maddalena',
        0.6,
        22.9,
        8.182,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sanford Feeder Trail',
        0,
        '/static/gpx/349_Sanford_Feeder_Trail.gpx',
        'USA',
        'Biella',
        '',
        'Margherita terme',
        1.1,
        19.9,
        13.2,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'North Summit Trail',
        2,
        '/static/gpx/350_North_Summit_Trail.gpx',
        'USA',
        'Milano',
        '',
        'Borgo Ramiro',
        3.3,
        27,
        40.326,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Westville Feeder Trail',
        2,
        '/static/gpx/351_Westville_Feeder_Trail.gpx',
        'USA',
        'Pistoia',
        '',
        'Pizzimenti terme',
        1.2,
        17.8,
        19.726,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'West Rock Park Road',
        1,
        '/static/gpx/352_West_Rock_Park_Road.gpx',
        'USA',
        'Udine',
        '',
        'Rapuano umbro',
        0.7,
        27,
        8.485,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Bennetts Pond Trail',
        1,
        '/static/gpx/353_Bennetts_Pond_Trail.gpx',
        'USA',
        'Pisa',
        '',
        'Sesto Iride',
        1.1,
        14.8,
        18.857,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ives Trail',
        0,
        '/static/gpx/354_Ives_Trail.gpx',
        'USA',
        'Siena',
        '',
        'San Gosto a mare',
        1.5,
        19.4,
        24.59,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Ridgefield Open Space Trail',
        2,
        '/static/gpx/355_Ridgefield_Open_Space_Trail.gpx',
        'USA',
        'Massa-Carrara',
        '',
        'Quarto Sicuro laziale',
        1,
        14,
        13.015,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'George Dudley Seymour Park Trail',
        1,
        '/static/gpx/356_George_Dudley_Seymour_Park_Trail.gpx',
        'USA',
        'Salerno',
        '',
        'Serafini terme',
        1.1,
        11.3,
        14.634,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Grta',
        0,
        '/static/gpx/357_Grta.gpx',
        'USA',
        'Rovigo',
        '',
        'Dina veneto',
        1.1,
        23.1,
        13.836,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mohegan Forest Trail',
        0,
        '/static/gpx/358_Mohegan_Forest_Trail.gpx',
        'USA',
        'Massa-Carrara',
        '',
        'Sesto Gianpietro',
        1.1,
        9.9,
        14.442,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Mount Bushnell Trail',
        1,
        '/static/gpx/359_Mount_Bushnell_Trail.gpx',
        'USA',
        'Barletta-Andria-Trani',
        '',
        'Sesto Aquilino',
        2.1,
        12.9,
        29.717,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Nye Holman Trail',
        2,
        '/static/gpx/360_Nye_Holman_Trail.gpx',
        'USA',
        'Gorizia',
        '',
        'Demontis a mare',
        1.2,
        13.6,
        14.4,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Al''S Trail',
        2,
        '/static/gpx/361_Al_S_Trail.gpx',
        'USA',
        'Rimini',
        '',
        'Taziano sardo',
        1.5,
        20.5,
        19.397,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Salt Rock State Park Trail',
        2,
        '/static/gpx/362_Salt_Rock_State_Park_Trail.gpx',
        'USA',
        'Grosseto',
        '',
        'Settimo Ezio lido',
        1,
        26,
        13.158,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Scantic River Trail',
        2,
        '/static/gpx/363_Scantic_River_Trail.gpx',
        'USA',
        'Belluno',
        '',
        'Sesto Riccardo',
        0.8,
        23.7,
        12.214,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Scantic River Park Trail',
        0,
        '/static/gpx/364_Scantic_River_Park_Trail.gpx',
        'USA',
        'Pavia',
        '',
        'Settimo Varo',
        1.3,
        23.8,
        17.647,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Scantic Park Access',
        2,
        '/static/gpx/365_Scantic_Park_Access.gpx',
        'USA',
        'Udine',
        '',
        'Sesto Carlo',
        0.6,
        19.7,
        7.547,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Sunrise Park Trail',
        0,
        '/static/gpx/366_Sunrise_Park_Trail.gpx',
        'USA',
        'Cosenza',
        '',
        'Viscardo laziale',
        0.8,
        11.8,
        11.881,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kitchel Trail',
        1,
        '/static/gpx/367_Kitchel_Trail.gpx',
        'USA',
        'Pordenone',
        '',
        'Settimo Bonagiunta lido',
        2.2,
        12.7,
        27.329,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Old Driveway',
        0,
        '/static/gpx/368_Old_Driveway.gpx',
        'USA',
        'Trapani',
        '',
        'Sesto Rinaldo ligure',
        0.6,
        27.8,
        8.78,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Kitchel',
        0,
        '/static/gpx/369_Kitchel.gpx',
        'USA',
        'Pisa',
        '',
        'Capponi calabro',
        0.6,
        23.4,
        7.692,
        ''
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description"
      ) VALUES(
        2,
        'Driveway',
        2,
        '/static/gpx/370_Driveway.gpx',
        'USA',
        'Asti',
        '',
        'Belli veneto',
        1.1,
        29.1,
        14.732,
        ''
      );
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2)
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        8,
        55,
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Fortunata Guerriero',
        'https://steep-vibe.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        5,
        94,
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Osvaldo Valle',
        'https://acclaimed-equinox.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        8,
        78,
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Enea Pollina',
        'http://exotic-mukluk.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        10,
        138,
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Misaele Piras',
        'https://honorable-permit.com',
        null
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        8,
        53,
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Sig. Paola Buzzi',
        'http://noteworthy-tabernacle.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        7,
        103,
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Lamberto De Meo',
        'https://ill-variable.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        4,
        126,
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Gaudino Blasi',
        'http://cultured-metro.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        7,
        42,
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Armando Spada',
        'https://made-up-botany.org',
        null
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        5,
        93,
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Lisa Salierno',
        'http://inferior-polyester.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        6,
        80,
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Taziana Politi',
        'https://burdensome-grouper.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        6,
        107,
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Otilia Fiorenza',
        'http://puny-gnu.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        8,
        135,
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Pancrazio Cavallo',
        'http://fussy-cashier.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        9,
        99,
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Marina Oggiano',
        'https://detailed-clogs.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        8,
        55,
        'Vernagthütte',
        'Austria',
        'Alfio Di Pietro',
        'https://untrue-shelf.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        6,
        92,
        'Wormser Hütte',
        'Austria',
        'Sefora Iodice',
        'https://dutiful-oboe.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        6,
        133,
        'Biberacher Hütte',
        'Austria',
        'Caio Bini',
        'https://faint-tulip.net',
        null
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        4,
        122,
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Dr. Doda Doro',
        'http://triangular-glasses.com',
        null
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        5,
        117,
        'Hochwaldhütte',
        'Germany',
        'Dr. Nicea Martini',
        'http://prestigious-warfare.com',
        null
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        8,
        104,
        'Kölner Eifelhütte',
        'Germany',
        'Giuliano Ceccarelli',
        'https://quarterly-nationality.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        1,
        73,
        'Madrisahütte',
        'Austria',
        'Demostene Guidi',
        'https://direct-cirrus.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        8,
        77,
        'Dresdner Hütte',
        'Austria',
        'Alice Colonna',
        'https://avaricious-gobbler.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        9,
        107,
        'Fiderepasshütte',
        'Germany',
        'Maria Vicinanza',
        'http://essential-fellow.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        8,
        85,
        'Göppinger Hütte',
        'Austria',
        'Gesualdo Pugliesi',
        'http://gloomy-angel.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        4,
        138,
        'Oberzalimhütte',
        'Austria',
        'Feliciano Di Marco',
        'http://troubled-refectory.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        5,
        45,
        'Rastkogelhütte',
        'Austria',
        'Liviana Repetto',
        'https://untimely-singer.it',
        null
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        7,
        140,
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Dante Leoncini',
        'https://affectionate-pickaxe.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        1,
        146,
        'Kaltenberghütte',
        'Austria',
        'Dott. Giosuele Motisi',
        'https://inferior-hospice.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        1,
        120,
        'Schweinfurter Hütte',
        'Austria',
        'Demetrio Di Lecce',
        'http://scientific-post.it',
        null
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        6,
        82,
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Leo Sapienza',
        'http://fabulous-mrna.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        4,
        131,
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Filomena Campoli',
        'https://sore-alligator.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        2,
        48,
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Alba Paolillo',
        'https://confused-primate.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        7,
        130,
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Alina Cozzani',
        'https://broken-termite.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        4,
        71,
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Dott. Pamela Del Monte',
        'https://powerless-prestige.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        8,
        76,
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Arminio Lazzaro',
        'https://glass-goggles.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        1,
        76,
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Eva De Feo',
        'https://snappy-viola.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        2,
        55,
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Desiderio Palmisani',
        'http://sparkling-piccolo.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        7,
        36,
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Demetrio Fantini',
        'http://celebrated-mayonnaise.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        3,
        51,
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Pellegrino Montesano',
        'https://spirited-sadness.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        1,
        48,
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Marinella Schiavone',
        'http://posh-canoe.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        3,
        128,
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Penelope Bonazzi',
        'https://likely-tavern.it',
        null
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        8,
        95,
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Alda Giannetti',
        'https://short-wing.org',
        null
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        5,
        102,
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Innocente Cavaliere',
        'https://vengeful-gray.com',
        null
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        5,
        144,
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Duilio Guarnieri',
        'http://punctual-ziggurat.org',
        null
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        9,
        148,
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Ivo Grieco',
        'https://large-width.net',
        null
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        2,
        149,
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Valente Barbarulo',
        'http://pretty-hake.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        9,
        114,
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Dr. Manuela Pellegrino',
        'https://sandy-boxer.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        1,
        70,
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Degna Perra',
        'https://granular-angora.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        6,
        109,
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Sig. Franco Antenucci',
        'http://optimistic-comportment.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        3,
        113,
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Adelmo Totaro',
        'http://imperfect-song.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        4,
        54,
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Venerando Polizzi',
        'http://sad-stop.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        4,
        107,
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Catena Coletta',
        'https://striped-aid.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        7,
        149,
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Ing. Ines Alessandrini',
        'https://easy-going-revenant.org',
        null
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        2,
        84,
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Gianluigi Perin',
        'https://large-edger.net',
        null
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        4,
        111,
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Apollina Pacifici',
        'http://internal-secretion.it',
        null
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        8,
        117,
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Elio Lelli',
        'http://aggressive-chug.it',
        null
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        9,
        122,
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Saverio Quaranta',
        'http://wry-evaporation.net',
        null
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        5,
        149,
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Bacco Iannello',
        'https://suburban-linguist.com',
        null
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        8,
        80,
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Alcino Tammaro',
        'http://pointed-military.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        5,
        142,
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Ing. Pupolo Capasso',
        'https://pricey-deduce.it',
        null
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        5,
        93,
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Salvatore Santo',
        'https://electric-fairy.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        7,
        46,
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Rossana Fumarola',
        'http://luxurious-kendo.net',
        null
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        4,
        86,
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Ilenia Piazzolla',
        'https://tight-peony.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        5,
        38,
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Lucia Modica',
        'http://illiterate-shaker.net',
        null
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        6,
        86,
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Vidone Cozzani',
        'http://wise-diver.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        6,
        95,
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Innocenzo Praticò',
        'http://inferior-model.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        7,
        60,
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Ing. Amalia Di Costanzo',
        'https://severe-bangle.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        1,
        148,
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Osvaldo Perugini',
        'http://slimy-reasoning.it',
        null
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        6,
        127,
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Patrizio Caiazzo',
        'http://spanish-spokeswoman.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        2,
        135,
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Leonio Soldati',
        'http://lavish-smile.it',
        null
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        1,
        88,
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Ildefonso Latorre',
        'https://dutiful-dip.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        4,
        76,
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Cinzia Pani',
        'http://grave-background.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        6,
        107,
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Addo D''Alessio',
        'https://organic-attempt.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        4,
        107,
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Otello Pavani',
        'http://ringed-incidence.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        8,
        135,
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Ing. Antonia Bucci',
        'https://exhausted-threshold.net',
        null
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        7,
        133,
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Demetria Barsotti',
        'http://noted-bronze.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        9,
        83,
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Irma Ciccarelli',
        'https://favorite-goat.com',
        null
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        2,
        83,
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Petronilla Silvestro',
        'https://shadowy-bloomer.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        9,
        102,
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Greta Gori',
        'http://frequent-laboratory.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        8,
        125,
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Vilma Campus',
        'http://odd-chairlift.it',
        null
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        8,
        130,
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Grazia Florio',
        'https://judicious-waitress.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        5,
        148,
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Ninfa Di Maria',
        'https://fatal-activity.com',
        null
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        3,
        61,
        'Wittener Hütte',
        'Germany',
        'Coreno Alessi',
        'http://moist-vineyard.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        1,
        66,
        'Hochjoch-Hospiz',
        'Austria',
        'Ludovico Ippolito',
        'http://prudent-archeology.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        4,
        83,
        'Meilerhütte',
        'Germany',
        'Brando Simeoli',
        'http://sinful-pressurization.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        10,
        59,
        'Gaudeamushütte',
        'Austria',
        'Sig. Amerigo Lelli',
        'http://cuddly-confidentiality.com',
        null
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        3,
        81,
        'Rheydter Hütte',
        'Germany',
        'Daniele Brandi',
        'http://hidden-dryer.org',
        null
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        6,
        123,
        'Sektionshütte Krippen',
        'Germany',
        'Amina Maragno',
        'https://barren-ninja.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        1,
        69,
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Nicarete Tornatore',
        'https://messy-confirmation.net',
        null
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        10,
        52,
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Davide Cavriani',
        'https://surprised-antler.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        6,
        149,
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Teodosio Sini',
        'http://uncommon-plant.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        2,
        76,
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Fedele Luppino',
        'https://smart-tile.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        7,
        80,
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Melitina De Martino',
        'https://babyish-forelimb.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        9,
        147,
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Altea Bartoli',
        'https://responsible-jiffy.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        5,
        125,
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Lisandro Santarelli',
        'https://weary-tackle.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        4,
        91,
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Diamante Carlucci',
        'http://digital-slope.it',
        null
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        8,
        136,
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Dr. Rufina Avola',
        'http://humongous-cinder.it',
        null
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        3,
        140,
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Concetta Zanella',
        'http://rubbery-zither.com',
        null
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        9,
        138,
        'Dobra voda',
        'Suvobor, Serbia',
        'Servidio Tallone',
        'https://mysterious-creative.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        4,
        131,
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Adalrico Di Franco',
        'http://suburban-pig.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        5,
        144,
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Lena Fuoco',
        'http://yearly-tempo.it',
        null
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        9,
        93,
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Ester Carriero',
        'http://similar-observation.net',
        null
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        3,
        90,
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Celeste Torchio',
        'http://excitable-sunflower.com',
        null
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        6,
        94,
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Prudenzia Biondi',
        'http://official-evening-wear.com',
        null
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        8,
        133,
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Lea Matarazzo',
        'https://past-custard.it',
        null
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        9,
        128,
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Isidoro Maiello',
        'https://weird-tart.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        2,
        85,
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Gioacchino Fratello',
        'http://weird-crow.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        7,
        141,
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Giuseppe Gamper',
        'http://yearly-agent.it',
        null
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        5,
        42,
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Niceforo Pariggiano',
        'http://polished-cracker.com',
        null
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '040 Borgo Armando, Quarto Liberatore calabro, Italy',
        'Quarto Liberatore calabro',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        190,
        '44 Strada Pierangelo, Settimo Enimia, Italy',
        'Settimo Enimia',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        292,
        '256 Strada Pili, Azara lido, Italy',
        'Azara lido',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        140,
        '69 Rotonda Gennaro, Adriana nell''emilia, Italy',
        'Adriana nell''emilia',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        33,
        '783 Rotonda D''Aleo, Geltrude terme, Italy',
        'Geltrude terme',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        73,
        '154 Incrocio Reale, Borgo Aristofane, Italy',
        'Borgo Aristofane',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        137,
        '0 Borgo Solinas, Ausilio ligure, Italy',
        'Ausilio ligure',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        236,
        '7 Via Melchiade, San Erberto, Italy',
        'San Erberto',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        168,
        '5 Strada Diletta, Elvino ligure, Italy',
        'Elvino ligure',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        248,
        '7 Borgo Valenti, San Manuela veneto, Italy',
        'San Manuela veneto',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        273,
        '2 Rotonda Caio, Borgo Agazio, Italy',
        'Borgo Agazio',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        94,
        '120 Borgo Margiotta, Borgo Endrigo terme, Italy',
        'Borgo Endrigo terme',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        35,
        '727 Incrocio Govoni, Settimo Melissa salentino, Italy',
        'Settimo Melissa salentino',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        128,
        '33 Via Fabiano, Quarto Cristaldo, Italy',
        'Quarto Cristaldo',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        127,
        '8 Via Elmo, Dodaro lido, Italy',
        'Dodaro lido',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        179,
        '420 Incrocio Fois, San Zena, Italy',
        'San Zena',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        297,
        '0 Via Giuliano, Ecclesio calabro, Italy',
        'Ecclesio calabro',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        56,
        '50 Strada Alma, Sesto Filippa, Italy',
        'Sesto Filippa',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        41,
        '0 Rotonda Lavinia, Fiore laziale, Italy',
        'Fiore laziale',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        153,
        '40 Borgo Valenza, Candida salentino, Italy',
        'Candida salentino',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        120,
        '0 Rotonda Rucco, Sesto Pelagia umbro, Italy',
        'Sesto Pelagia umbro',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        201,
        '911 Rotonda Lo Iacono, Quarto Natalina, Italy',
        'Quarto Natalina',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '287 Piazza Mastropietro, Quarto Duilio, Italy',
        'Quarto Duilio',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        197,
        '96 Borgo Lucia, Zefiro del friuli, Italy',
        'Zefiro del friuli',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        66,
        '443 Strada Enrico, Sesto Climaco, Italy',
        'Sesto Climaco',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        56,
        '16 Strada Marsella, Ferraro lido, Italy',
        'Ferraro lido',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        158,
        '0 Contrada Agresta, Settimo Sonia, Italy',
        'Settimo Sonia',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        148,
        '52 Incrocio Pacifico, Martinelli laziale, Italy',
        'Martinelli laziale',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        270,
        '6 Piazza Marisa, San Turibio veneto, Italy',
        'San Turibio veneto',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        257,
        '741 Strada Ortensio, Quarto Donato, Italy',
        'Quarto Donato',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        201,
        '3 Incrocio Rogolino, Amatore a mare, Italy',
        'Amatore a mare',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        177,
        '5 Contrada Narcisi, Ave del friuli, Italy',
        'Ave del friuli',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        56,
        '27 Incrocio Canale, Camelia nell''emilia, Italy',
        'Camelia nell''emilia',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '2 Borgo Leonardi, San Fulvia, Italy',
        'San Fulvia',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        219,
        '042 Piazza Bandini, San Prudenzio terme, Italy',
        'San Prudenzio terme',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        133,
        '4 Strada Beltramo, Settimo Ulberto sardo, Italy',
        'Settimo Ulberto sardo',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        233,
        '392 Borgo No�, Serafino del friuli, Italy',
        'Serafino del friuli',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        153,
        '79 Via Quinzio, Quarto Egizia, Italy',
        'Quarto Egizia',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        35,
        '4 Incrocio Aronne, Piccinini terme, Italy',
        'Piccinini terme',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        67,
        '2 Strada Barile, San Martina, Italy',
        'San Martina',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '74 Borgo Ireneo, Gaio a mare, Italy',
        'Gaio a mare',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        289,
        '22 Rotonda Fausta, Borgo Tiberio a mare, Italy',
        'Borgo Tiberio a mare',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        101,
        '33 Incrocio Ulfa, Iride del friuli, Italy',
        'Iride del friuli',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        186,
        '54 Piazza Panico, Settimo Fleano, Italy',
        'Settimo Fleano',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        274,
        '091 Via Pozzi, Caporaso sardo, Italy',
        'Caporaso sardo',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        197,
        '1 Contrada Pozzi, Sesto Landolfo, Italy',
        'Sesto Landolfo',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        153,
        '40 Strada Pisu, Sesto Gilda calabro, Italy',
        'Sesto Gilda calabro',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        285,
        '39 Contrada Sabino, Sesto Annibale, Italy',
        'Sesto Annibale',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        261,
        '59 Incrocio Rogolino, Borgo Silvestro calabro, Italy',
        'Borgo Silvestro calabro',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        28,
        '9 Incrocio Donati, Cherchi salentino, Italy',
        'Cherchi salentino',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        235,
        '86 Contrada Fabiana, Mazzanti calabro, Italy',
        'Mazzanti calabro',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '17 Via Beronico, Pennestrì salentino, Italy',
        'Pennestrì salentino',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        289,
        '794 Piazza Pizzuti, Sesto Panfilo del friuli, Italy',
        'Sesto Panfilo del friuli',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '332 Contrada Abele, Borgo Acacio a mare, Italy',
        'Borgo Acacio a mare',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        254,
        '7 Piazza Sante, Gruber umbro, Italy',
        'Gruber umbro',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        80,
        '5 Rotonda Ugolini, Sesto Richelmo a mare, Italy',
        'Sesto Richelmo a mare',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        112,
        '386 Via Bruni, San Adalgisa, Italy',
        'San Adalgisa',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        226,
        '3 Strada Labate, Lucchesi a mare, Italy',
        'Lucchesi a mare',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        146,
        '0 Contrada Caserta, Soldati calabro, Italy',
        'Soldati calabro',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        260,
        '7 Borgo Bonetti, Borgo Bino, Italy',
        'Borgo Bino',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        119,
        '33 Contrada Fior, San Marica, Italy',
        'San Marica',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        162,
        '44 Borgo Bonito, Sesto Elena del friuli, Italy',
        'Sesto Elena del friuli',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        129,
        '51 Strada Crocefisso, Sesto Ermenegildo calabro, Italy',
        'Sesto Ermenegildo calabro',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        140,
        '776 Borgo Spiga, Federici del friuli, Italy',
        'Federici del friuli',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        179,
        '66 Contrada Mara, Bastiano nell''emilia, Italy',
        'Bastiano nell''emilia',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        50,
        '4 Contrada Lamberto, Del Prete terme, Italy',
        'Del Prete terme',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        56,
        '4 Contrada Pignatelli, Luzi lido, Italy',
        'Luzi lido',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        181,
        '17 Incrocio Taziana, Settimo Patrizia umbro, Italy',
        'Settimo Patrizia umbro',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        169,
        '35 Piazza Marianna, Chiara lido, Italy',
        'Chiara lido',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '1 Contrada Meneo, Celi a mare, Italy',
        'Celi a mare',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        60,
        '41 Via Amando, Zamboni a mare, Italy',
        'Zamboni a mare',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        259,
        '081 Via Clodomiro, Borgo Attilio lido, Italy',
        'Borgo Attilio lido',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        171,
        '42 Contrada Chiodi, Sesto Fidenzio, Italy',
        'Sesto Fidenzio',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        63,
        '0 Strada Cronida, Sesto Rosanna a mare, Italy',
        'Sesto Rosanna a mare',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        152,
        '4 Strada Celeste, Cacciatore sardo, Italy',
        'Cacciatore sardo',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        25,
        '0 Borgo Cremenzio, Alcamo del friuli, Italy',
        'Alcamo del friuli',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        47,
        '115 Incrocio Tarso, Borgo Amanzio terme, Italy',
        'Borgo Amanzio terme',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        59,
        '354 Piazza Acrisio, Quarto Prudenzio nell''emilia, Italy',
        'Quarto Prudenzio nell''emilia',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        58,
        '9 Strada Giusti, Samona del friuli, Italy',
        'Samona del friuli',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        200,
        '131 Borgo Tarcisio, Cavallari veneto, Italy',
        'Cavallari veneto',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        294,
        '8 Strada Giancarlo, Settimo Eleuterio, Italy',
        'Settimo Eleuterio',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        179,
        '5 Borgo Pagliuca, Amleto calabro, Italy',
        'Amleto calabro',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        287,
        '55 Rotonda Petronilla, Gaglioffo umbro, Italy',
        'Gaglioffo umbro',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        290,
        '041 Strada Auro, Bellucci terme, Italy',
        'Bellucci terme',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        94,
        '20 Piazza Severino, Settimo Graziano, Italy',
        'Settimo Graziano',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        125,
        '17 Strada Marino, Gennaro terme, Italy',
        'Gennaro terme',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        259,
        '5 Strada Mancinelli, Pascucci salentino, Italy',
        'Pascucci salentino',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        286,
        '0 Borgo Galatea, Sesto Neri, Italy',
        'Sesto Neri',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        251,
        '850 Contrada Giovenzio, Addo ligure, Italy',
        'Addo ligure',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        174,
        '5 Rotonda Evaristo, Quarto Gustavo veneto, Italy',
        'Quarto Gustavo veneto',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        72,
        '3 Contrada Climaco, Liverani calabro, Italy',
        'Liverani calabro',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        149,
        '1 Via Storti, Salvatori a mare, Italy',
        'Salvatori a mare',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        140,
        '43 Contrada Brignone, Aldobrando laziale, Italy',
        'Aldobrando laziale',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        54,
        '264 Strada Marchi, San Flora salentino, Italy',
        'San Flora salentino',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        192,
        '265 Strada Pierangelo, Betta a mare, Italy',
        'Betta a mare',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        38,
        '58 Via Speranza, Settimo Rosa salentino, Italy',
        'Settimo Rosa salentino',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        206,
        '421 Borgo Romualdo, Settimo Leo a mare, Italy',
        'Settimo Leo a mare',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        286,
        '5 Incrocio Gavino, Cleofe ligure, Italy',
        'Cleofe ligure',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        77,
        '7 Borgo Ciriaco, Bonavita umbro, Italy',
        'Bonavita umbro',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        116,
        '9 Rotonda Osvaldo, Sesto Saverio a mare, Italy',
        'Sesto Saverio a mare',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        143,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        98,
        '7 Strada Catullo, Girardi ligure, Italy',
        'Girardi ligure',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        156,
        '9 Piazza Pippo, Settimo Aristarco calabro, Italy',
        'Settimo Aristarco calabro',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        52,
        '2 Rotonda Nucci, Petito sardo, Italy',
        'Petito sardo',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        114,
        '18 Strada Donda, Settimo Ermete, Italy',
        'Settimo Ermete',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        73,
        '6 Strada Puleo, Guidi terme, Italy',
        'Guidi terme',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        228,
        '0 Rotonda Eliana, Scardino ligure, Italy',
        'Scardino ligure',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        174,
        '6 Rotonda Maruta, Borgo Luigi ligure, Italy',
        'Borgo Luigi ligure',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        290,
        '16 Strada Lo Pinto, Quarto Lorenzo nell''emilia, Italy',
        'Quarto Lorenzo nell''emilia',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        261,
        '3 Strada Aniello, Sesto Stanislao, Italy',
        'Sesto Stanislao',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        243,
        '947 Incrocio Masiero, Guelfo del friuli, Italy',
        'Guelfo del friuli',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        113,
        '24 Via Marone, Quarto Cunegonda, Italy',
        'Quarto Cunegonda',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        26,
        '39 Rotonda Lari, Graziano lido, Italy',
        'Graziano lido',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        119,
        '88 Strada Rigoni, Simeoni lido, Italy',
        'Simeoni lido',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        270,
        '91 Borgo Lecca, Borgo Davino, Italy',
        'Borgo Davino',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        90,
        '461 Strada Valenza, Borgo Gonzaga laziale, Italy',
        'Borgo Gonzaga laziale',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        106,
        '249 Piazza Pili, Spano terme, Italy',
        'Spano terme',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        154,
        '8 Strada Clodoveo, Quarto Anacleto a mare, Italy',
        'Quarto Anacleto a mare',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        167,
        '340 Contrada Minervina, San Ugo, Italy',
        'San Ugo',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        121,
        '89 Piazza Feliziani, Nocera del friuli, Italy',
        'Nocera del friuli',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        31,
        '7 Piazza Martina, Franceschi lido, Italy',
        'Franceschi lido',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        139,
        '47 Rotonda Piva, Ada calabro, Italy',
        'Ada calabro',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        258,
        '924 Contrada Ferilli, Pastorelli umbro, Italy',
        'Pastorelli umbro',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        180,
        '8 Via Caporaso, Quarto Nilde, Italy',
        'Quarto Nilde',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        37,
        '40 Piazza Mancio, Violante laziale, Italy',
        'Violante laziale',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        179,
        '8 Piazza Benvenuta, Ermenegildo salentino, Italy',
        'Ermenegildo salentino',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '02 Incrocio Ferrando, Dionisi calabro, Italy',
        'Dionisi calabro',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        120,
        '07 Borgo Grande, Settimo Prudenzia, Italy',
        'Settimo Prudenzia',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        173,
        '937 Incrocio Lori, Izzo veneto, Italy',
        'Izzo veneto',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '20 Borgo Giuseppe, Tarcisio del friuli, Italy',
        'Tarcisio del friuli',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '16 Borgo Marchesini, Arianna nell''emilia, Italy',
        'Arianna nell''emilia',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        77,
        '503 Strada Sabele, Fabiano sardo, Italy',
        'Fabiano sardo',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        239,
        '66 Piazza Pavone, Speranza del friuli, Italy',
        'Speranza del friuli',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        202,
        '6 Rotonda Capannolo, Massimo del friuli, Italy',
        'Massimo del friuli',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        259,
        '818 Strada Veneranda, Pedrotti terme, Italy',
        'Pedrotti terme',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        147,
        '636 Contrada Lezzi, Festo veneto, Italy',
        'Festo veneto',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '766 Piazza Alessandra, Lo Cascio nell''emilia, Italy',
        'Lo Cascio nell''emilia',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '57 Rotonda Salomone, Borgo Bianca veneto, Italy',
        'Borgo Bianca veneto',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        32,
        '154 Incrocio Alida, Masia calabro, Italy',
        'Masia calabro',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '0 Via Elvira, Petrone lido, Italy',
        'Petrone lido',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        198,
        '80 Strada Restivo, Pesce nell''emilia, Italy',
        'Pesce nell''emilia',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        209,
        '121 Via Cataldo, Fiorenza salentino, Italy',
        'Fiorenza salentino',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        250,
        '34 Contrada Panetta, San Perseo, Italy',
        'San Perseo',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        281,
        '82 Piazza Gravina, Settimo Addo veneto, Italy',
        'Settimo Addo veneto',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        268,
        '66 Strada Sassi, Siria nell''emilia, Italy',
        'Siria nell''emilia',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        172,
        '099 Rotonda Tiziano, Quarto Leonio, Italy',
        'Quarto Leonio',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        261,
        '8 Via Privato, Sviturno calabro, Italy',
        'Sviturno calabro',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        288,
        '6 Incrocio Greppi, San Costanza ligure, Italy',
        'San Costanza ligure',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        88,
        '751 Strada Pierluigi, Quarto Panfilo ligure, Italy',
        'Quarto Panfilo ligure',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        211,
        '2 Strada Osanna, Dalmasso nell''emilia, Italy',
        'Dalmasso nell''emilia',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        142,
        '2 Borgo Martini, Valente terme, Italy',
        'Valente terme',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        223,
        '389 Contrada Musso, Quarto Carina salentino, Italy',
        'Quarto Carina salentino',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        226,
        '2 Incrocio Igino, San Mirocleto, Italy',
        'San Mirocleto',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        283,
        '70 Borgo Enrico, Cataldo del friuli, Italy',
        'Cataldo del friuli',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        150,
        '08 Via Napolitano, Chessari a mare, Italy',
        'Chessari a mare',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        264,
        '3 Incrocio Brando, Borgo Romana laziale, Italy',
        'Borgo Romana laziale',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        249,
        '814 Incrocio Salomone, Piazza a mare, Italy',
        'Piazza a mare',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        268,
        '6 Strada Apollina, San Onesto del friuli, Italy',
        'San Onesto del friuli',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        166,
        '296 Piazza Barresi, Sesto Tabita, Italy',
        'Sesto Tabita',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        65,
        '3 Rotonda Priamo, Ciavarella ligure, Italy',
        'Ciavarella ligure',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        26,
        '776 Incrocio Palano, Quarto Auberto terme, Italy',
        'Quarto Auberto terme',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        146,
        '9 Borgo Biagio, Cointa del friuli, Italy',
        'Cointa del friuli',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        43,
        '98 Borgo Emiliana, Sesto Ubertino a mare, Italy',
        'Sesto Ubertino a mare',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        274,
        '18 Via Giorgia, Quarto Nicarete, Italy',
        'Quarto Nicarete',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        258,
        '58 Strada Casano, San Giosu� salentino, Italy',
        'San Giosu� salentino',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '40 Piazza Mauro, Guarino laziale, Italy',
        'Guarino laziale',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        115,
        '077 Rotonda Semplicio, Settimo Maruta, Italy',
        'Settimo Maruta',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        255,
        '16 Via Decimo, Borgo Lelia nell''emilia, Italy',
        'Borgo Lelia nell''emilia',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        289,
        '5 Borgo Maugeri, Sviturno terme, Italy',
        'Sviturno terme',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        299,
        '096 Contrada Antonio, Bentivoglio lido, Italy',
        'Bentivoglio lido',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        131,
        '061 Incrocio De Biase, Settimo Patrizia, Italy',
        'Settimo Patrizia',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        260,
        '45 Piazza Doro, San Agabio umbro, Italy',
        'San Agabio umbro',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        147,
        '2 Contrada Galeazzo, Ione laziale, Italy',
        'Ione laziale',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        179,
        '706 Strada Innocenti, Settimo Concordio ligure, Italy',
        'Settimo Concordio ligure',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        77,
        '77 Contrada Acrisio, Grazia a mare, Italy',
        'Grazia a mare',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        159,
        '568 Borgo Esterina, Ilario del friuli, Italy',
        'Ilario del friuli',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        250,
        '301 Incrocio Lepore, Settimo Altea, Italy',
        'Settimo Altea',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        137,
        '51 Piazza Olimpia, Eleonora del friuli, Italy',
        'Eleonora del friuli',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        207,
        '8 Contrada Maione, Eliana calabro, Italy',
        'Eliana calabro',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        98,
        '611 Piazza Panza, Sempronio salentino, Italy',
        'Sempronio salentino',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        216,
        '36 Contrada Ivanoe, Nicola veneto, Italy',
        'Nicola veneto',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        156,
        '013 Incrocio Matteucci, Borgo Nilde nell''emilia, Italy',
        'Borgo Nilde nell''emilia',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '46 Contrada Capizzi, Giambattista umbro, Italy',
        'Giambattista umbro',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        295,
        '2 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        256,
        '14 Rotonda Crespignano, San Paola veneto, Italy',
        'San Paola veneto',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        146,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        113,
        '734 Rotonda Dodaro, Settimo Dianora ligure, Italy',
        'Settimo Dianora ligure',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        162,
        '6 Via Orsolina, Borgo Aronne terme, Italy',
        'Borgo Aronne terme',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        87,
        '525 Piazza Giulio, Dianora ligure, Italy',
        'Dianora ligure',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        211,
        '535 Contrada Rusciano, Sesto Valentina, Italy',
        'Sesto Valentina',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        196,
        '135 Rotonda Climaco, Bisio del friuli, Italy',
        'Bisio del friuli',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        198,
        '7 Incrocio Valentini, Quarto Beltramo, Italy',
        'Quarto Beltramo',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        83,
        '894 Incrocio Sarbello, Ave umbro, Italy',
        'Ave umbro',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        30,
        '617 Contrada Cleopatra, Vinfrido nell''emilia, Italy',
        'Vinfrido nell''emilia',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        208,
        '19 Via Ferrara, Borgo Adalgiso nell''emilia, Italy',
        'Borgo Adalgiso nell''emilia',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        150,
        '347 Incrocio Berto, Settimo Linda, Italy',
        'Settimo Linda',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        143,
        '394 Incrocio Cleopatra, Castaldi ligure, Italy',
        'Castaldi ligure',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        81,
        '5 Rotonda Rosario, Ennio ligure, Italy',
        'Ennio ligure',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        220,
        '630 Strada Sabazio, Nicol� a mare, Italy',
        'Nicol� a mare',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        260,
        '6 Piazza Evaldo, Piergiorgio ligure, Italy',
        'Piergiorgio ligure',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        296,
        '722 Via Zampieri, Giorgia del friuli, Italy',
        'Giorgia del friuli',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        88,
        '444 Rotonda Vera, Borgo Ottaviano terme, Italy',
        'Borgo Ottaviano terme',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '66 Contrada Giuseppa, Filomena lido, Italy',
        'Filomena lido',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        196,
        '860 Piazza Di Caccamo, Bonomo nell''emilia, Italy',
        'Bonomo nell''emilia',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        45,
        '234 Strada Cirillo, Noemi salentino, Italy',
        'Noemi salentino',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        283,
        '61 Strada Benedetti, San Porzia, Italy',
        'San Porzia',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        181,
        '495 Borgo Masi, Quarto Soccorso, Italy',
        'Quarto Soccorso',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        172,
        '362 Strada Colmazio, Settimo Zanita del friuli, Italy',
        'Settimo Zanita del friuli',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        59,
        '9 Piazza Ildefonso, Guiscardo veneto, Italy',
        'Guiscardo veneto',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        65,
        '402 Borgo Giona, Settimo Laura salentino, Italy',
        'Settimo Laura salentino',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        163,
        '43 Contrada Scotti, Agnello del friuli, Italy',
        'Agnello del friuli',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        157,
        '0 Incrocio Sabato, Zingaretti lido, Italy',
        'Zingaretti lido',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '2 Incrocio Alcamo, Sesto Ulfa, Italy',
        'Sesto Ulfa',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        284,
        '9 Borgo Cardinale, Luconi sardo, Italy',
        'Luconi sardo',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        66,
        '0 Strada Pesaresi, Metrofane lido, Italy',
        'Metrofane lido',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        70,
        '593 Via Remo, San Desiderato salentino, Italy',
        'San Desiderato salentino',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        181,
        '946 Rotonda Siricio, Amabile sardo, Italy',
        'Amabile sardo',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        258,
        '48 Strada Bosco, Sesto Adelardo, Italy',
        'Sesto Adelardo',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        107,
        '7 Contrada Iorio, Sesto Sebastiano sardo, Italy',
        'Sesto Sebastiano sardo',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        108,
        '4 Rotonda Ercoli, Settimo Fedele, Italy',
        'Settimo Fedele',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        42,
        '736 Piazza Rollo, Settimo Crescenzia umbro, Italy',
        'Settimo Crescenzia umbro',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '9 Rotonda Colmanno, Ines umbro, Italy',
        'Ines umbro',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        209,
        '90 Contrada Galluzzo, Gianpaolo lido, Italy',
        'Gianpaolo lido',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        107,
        '444 Incrocio Serafino, Sicuro terme, Italy',
        'Sicuro terme',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        249,
        '22 Rotonda Ragone, Borgo Regolo, Italy',
        'Borgo Regolo',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        199,
        '777 Piazza Remondo, Quarto Apollonia, Italy',
        'Quarto Apollonia',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        209,
        '59 Via Cottone, Settimo Ester calabro, Italy',
        'Settimo Ester calabro',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        205,
        '98 Incrocio Elena, Quarto Annunziata, Italy',
        'Quarto Annunziata',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        176,
        '026 Contrada Isabella, Sesto Santo lido, Italy',
        'Sesto Santo lido',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        66,
        '757 Contrada Asterio, Bassilla calabro, Italy',
        'Bassilla calabro',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        55,
        '40 Strada Gianbattista, Pierangelo veneto, Italy',
        'Pierangelo veneto',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        62,
        '06 Incrocio Pacifico, Borrelli del friuli, Italy',
        'Borrelli del friuli',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        231,
        '428 Incrocio Marini, Settimo Alfio, Italy',
        'Settimo Alfio',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        174,
        '5 Rotonda Salis, Borgo Aristione veneto, Italy',
        'Borgo Aristione veneto',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        163,
        '094 Incrocio Michelangelo, Quarto Mauro, Italy',
        'Quarto Mauro',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        81,
        '30 Incrocio Efisio, Marica umbro, Italy',
        'Marica umbro',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        150,
        '08 Rotonda Dal Farra, Andromeda laziale, Italy',
        'Andromeda laziale',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        70,
        '8 Rotonda Lorenzo, Paladini ligure, Italy',
        'Paladini ligure',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        144,
        '5 Piazza Asimodeo, Plinio ligure, Italy',
        'Plinio ligure',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        79,
        '9 Strada Casimiro, Di Martino sardo, Italy',
        'Di Martino sardo',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        61,
        '507 Contrada Correale, Dolci veneto, Italy',
        'Dolci veneto',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        238,
        '190 Piazza Masi, San Amerigo, Italy',
        'San Amerigo',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        81,
        '55 Rotonda Donata, Sparacino calabro, Italy',
        'Sparacino calabro',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        250,
        '4 Piazza Verme, Acilia lido, Italy',
        'Acilia lido',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        298,
        '5 Via Cleo, Settimo Ardito laziale, Italy',
        'Settimo Ardito laziale',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        118,
        '150 Strada Barbarigo, Salomone laziale, Italy',
        'Salomone laziale',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        149,
        '931 Rotonda Concetta, San Odidone, Italy',
        'San Odidone',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        233,
        '653 Borgo Servidio, Quarto Adelasia, Italy',
        'Quarto Adelasia',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        255,
        '545 Incrocio Verulo, Canova terme, Italy',
        'Canova terme',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '66 Piazza Poggi, Quaranta umbro, Italy',
        'Quaranta umbro',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        129,
        '911 Rotonda Castaldo, San Sveva calabro, Italy',
        'San Sveva calabro',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        160,
        '744 Via Pallotta, Quarto Odorico laziale, Italy',
        'Quarto Odorico laziale',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        260,
        '13 Strada Pugliesi, Borgo Cora terme, Italy',
        'Borgo Cora terme',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        208,
        '2 Strada Palladio, Borgo Verecondo, Italy',
        'Borgo Verecondo',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        173,
        '97 Rotonda Antenucci, Antenucci sardo, Italy',
        'Antenucci sardo',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        238,
        '3 Strada Tullia, Borgo Donna terme, Italy',
        'Borgo Donna terme',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    
  