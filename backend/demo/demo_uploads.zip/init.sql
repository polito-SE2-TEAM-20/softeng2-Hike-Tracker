--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$.9h1eR8UaCljB.WMZ93qLeInbOPxtP.5QTQxAJ3Rc4arRgLehVyvy',
    'Antonio',
    'Battipaglia',
    2,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$L6.IYZfnr6Eu00mlbGVPceaVFNowfXgZbalKB9WLQpB9OfM31BRbO',
    'Erfan',
    'Gholami',
    4,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$8CrGwmlPQi3WD9GxRjf4jeJVe2MtOqws/e8BJQgb4cYPHdRzUWOV2',
    'Laura',
    'Zurru',
    5,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$xZCJijW9BS71Dm2SPE2Sju7Qwm4YF6LS.x.yUQhjMLdd4P8Jx65oW',
    'German',
    'Gorodnev',
    0,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$PZd0QeHzcdtlGQ4SezgkvOSwSvHnBor.FERyDqIBuDDF4cmIQuBgC',
    'Vincenzo',
    'Sagristano',
    3,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    6,
    'francesco@friend.it',
    '$2b$10$BT5PciAaxQyAKD5wF86z0ORl9W8y.a8KimGjZ8TrZDkzEg6DQ.bli',
    'Francesco',
    'Grande',
    1,
    true,
    true
  );
  

      CREATE OR REPLACE FUNCTION public.insert_hike(
        user_id integer,
        title varchar,
        difficulty integer,
        gpx_path varchar,
        country varchar,
        region varchar,
        province varchar,
        city varchar,
        length numeric(12,2),
        ascent numeric(12,2),
        expected_time integer,
        description varchar,
        pictures jsonb,
        start_point jsonb,
        end_point jsonb,
        reference_points jsonb
      )  RETURNS VOID AS
      $func$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hike"(
        2,
        'Amprimo',
        2,
        '/static/gpx/Amprimo.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        0.7,
        29.9,
        80,
        'Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.',
        '["/static/images/3.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.165559804,"lat":45.102780737}'::jsonb,
        '{"name":"End Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.14299586,"lat":45.099887898}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":7.164360252,"lat":45.102912389,"altitude":1256.852},{"name":"Ref Point 2","address":"","lon":7.158207147,"lat":45.102886551,"altitude":1283.605}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello Chateau Beaulard - Cotolivier - Vazon',
        1,
        '/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Beaulard',
        10.5,
        8,
        200,
        'Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.',
        '["/static/images/2.jpg"]'::jsonb,
        '{"name":"Start Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.772358,"lat":45.03205}'::jsonb,
        '{"name":"End Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.77234,"lat":45.032238}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'borgata ruà a cima di crosa',
        1,
        '/static/gpx/Borgata Ruà-Cima di Crosa (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Sampeyre',
        5387.070533803441,
        955.0963319999998,
        150,
        'Raggiungi la partenza del Sentiero per la Cima di Crosa impostando sul navigatore “Borgata Ruà – Becetto“.

Parcheggiata la macchina a Borgata Ruà (o se impossibilitati a trovare un parcheggio anche a Becetto, allungando di 10 minuti il giro), si prende il sentiero sulla sinistra, nei pressi di una cartina (INDICAZIONI CIMA DI CROSA).',
        '["/static/images/46.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia","lon":7.201825,"lat":44.596613}'::jsonb,
        '{"name":"End Point","address":"Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia","lon":7.177367,"lat":44.615185}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Colle della Gianna da Pian della Regina',
        2,
        '/static/gpx/Colle Della Gianna (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        3622.3230077193216,
        865.2000000000003,
        130,
        'Colle della Gianna at an altitude of approximately 2530m connects the Po Valley to the Pellice Valley allowing you to reach the Barbara Lowrie refuge, an ideal base for multi-day crossings.

It is advisable to carefully consult the weather forecasts especially for these areas frequently subject to very thick fog.

Being at moderately high altitudes in spring there is the possibility of finding tongues of snow that could make the ascent more difficult.',
        '["/static/images/37.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia","lon":7.114553963765502,"lat":44.70202149823308}'::jsonb,
        '{"name":"End Point","address":"Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia","lon":7.103742817416787,"lat":44.722054582089186}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Hike Zicher',
        3,
        '/static/gpx/Hike_Zicher (2).gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Craveggio',
        3221.31231047859,
        712.936152,
        120,
        'Lungo l’itinerario non è garantita la piena copertura telefonica
In periodo estivo, la parte finale può essere molto esposta al sole e richiedere fatica.
In condizioni di vento forte, è preferibile non proseguire
E’ possibile sviluppare un itinerario ad anello scendendo dal versante nord della montagna in direzione Bocchetta Sant’Antonio (ma attenzione ad un passaggio su rocce, soprattutto se ghiacciate).',
        '["/static/images/29.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia","lon":8.534505,"lat":46.147128}'::jsonb,
        '{"name":"End Point","address":"Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia","lon":8.534103,"lat":46.163437}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Usseaux Altro',
        2,
        '/static/gpx/Laghi_Albergian.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Usseaux',
        15636.670195666402,
        1366.7991943359375,
        150,
        'The flowering of Eriofori along the shores of the lake between July and August is interesting, making it very suggestive.',
        '["/static/images/40.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025457266718149,"lat":45.0393102876842}'::jsonb,
        '{"name":"End Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025509485974908,"lat":45.039591416716576}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Usseaux Altro',
        3,
        '/static/gpx/Laghi_Albergiani.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Usseaux',
        15636.670195666402,
        1366.7991943359375,
        150,
        'Itinerario vario e panoramico, non presenta particolari difficoltà ma per la lunghezza, il dislivello, la mancanza di punti di appoggio e la necessità di una certa capacità di orientamento su sentieri non sempre evidenti (specialmente per la variante in discesa) è consigliato a escursionisti allenati e esperti.',
        '["/static/images/42.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025457266718149,"lat":45.0393102876842}'::jsonb,
        '{"name":"End Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025509485974908,"lat":45.039591416716576}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago Bianco',
        2,
        '/static/gpx/Lago Bianco.gpx',
        'Francia',
        'Auvergne-Rhone-Alpes',
        'Savoia',
        'Val-Cenis',
        5.3,
        20.2,
        210,
        'Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.

La diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.

La Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.

Si può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.',
        '["/static/images/1.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945681,"lat":45.223814}'::jsonb,
        '{"name":"End Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945581,"lat":45.224058}'::jsonb,
        '[{"name":"fountain","address":"","lon":6.940291,"lat":45.222543,"altitude":2027},{"name":"Peak","address":"","lon":6.937204,"lat":45.215867,"altitude":2131}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Lago dei 7 colori (lago gignoux)',
        2,
        '/static/gpx/Lago dei 7 colori (lago gignoux) (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Claviere',
        21358.82545547226,
        1087.900000000002,
        170,
        'Parcheggia a Claviere e dirigiti verso la strada comunale Valle Gimont che, dopo poco, si fa sterrata.

Lascia alla tua destra i cartelli che indicano il Lago Gignoux e prosegui risalendo le piste da sci.

Giunto a Sagna Longa noterai che la zona è di interesse sciistico, infatti ci sono numerosi arrivi di seggiovia. Segui le indicazioni per Colle Bercia, attraversa una chiesetta, dei caseggiati in pietra e prosegui per il largo sentiero.

L’intero percorso si sviluppa circondato dai bellissimi Monti della Luna ed è caratterizzato da una dolce e semicostante salita su terreno sterrato a tratti ghiaioso.

Superato il Colle Bercia continua sull’ampia carreggiata che ti conduce ad un valico nel quale noterai particolari conformazioni rocciose e una punta (Cima Saurel 2451 mt). Tieniti sul sentiero basso e supera il valico, che segna anche il confine con la Francia, dopo il quale troverai il lago immerso in una conca.',
        '["/static/images/51.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia","lon":6.749585,"lat":44.938467}'::jsonb,
        '{"name":"End Point","address":"Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia","lon":6.749585,"lat":44.938467}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago d''Afframont 1986 m',
        2,
        '/static/gpx/Lago di Afframont 1986 m.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Balme',
        4024.727690039548,
        810.8999999999994,
        120,
        'Una volta parcheggiata la macchina dirigiti verso il villaggio Albaron. Poco dopo i caseggiati ti troverai di fronte ad un impianto di risalita dismesso, a sinistra troverai un campetto da calcio, proprio dopo il campetto si intravedono i primi cartelli con le indicazioni per il Lago di Afframont. Il sentiero da seguire è il 213, ma lungo il tragitto troverai solo bandiere bianco/rosse e cartelli di legno che indicano la destinazione.

Si sale l’ex pista da sci e ci si addentra nel bosco. Il primo tratto rimane ombreggiato, mentre inizia a farsi sentire la salita. Ad un certo punto ci si affianca ad un ruscello, il Rio di Afframont, che scorre sulla sinistra e si supera con facilità in prossimità dei caseggiati in pietra (attenzione nei periodi di pioggia perché potrebbe essere impraticabile).',
        '["/static/images/52.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia","lon":7.223873427137733,"lat":45.30158649198711}'::jsonb,
        '{"name":"End Point","address":"Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia","lon":7.238771421834827,"lat":45.292359441518784}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Briccas da Borgata Brich 20/02/21',
        2,
        '/static/gpx/Monte Briccas da Brich (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        7580.49492167635,
        1049.2599999999993,
        110,
        'After leaving the car, we continue along the road, first paved and then dirt.

In case of little snow or high temperatures it is possible to cover the first 150m in altitude without snowshoes.

As soon as we hit the first snow, we put on our snowshoes and set off on a well-defined path that crosses a wood.

After having left the last huts behind us, we turn right towards the North/East near a GTA trail sign painted on a boulder.

From here, after the last bush, an enormous, very wide slope opens up before us which culminates right at our peak',
        '["/static/images/35.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia","lon":7.159385243430734,"lat":44.70842678099871}'::jsonb,
        '{"name":"End Point","address":"Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia","lon":7.158207753673196,"lat":44.708156045526266}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Monte Ferra Con Marco e Daniel',
        3,
        '/static/gpx/Monte Ferra (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cuneo',
        11664.786185753126,
        1472.7999999999993,
        150,
        'Fondamentali i bastoncini specialmente nella discesa dal Monte Ferra al lago Reisassa.

Unico punto di appoggio è il rifugio Melezè ad inizio itinerario (consigliamo di contattare direttamente la struttura per verificare giorni e orari di apertura)',
        '["/static/images/28.jpg"]'::jsonb,
        '{"name":"Start Point","address":"SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia","lon":6.982689192518592,"lat":44.57425086759031}'::jsonb,
        '{"name":"End Point","address":"SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia","lon":6.982647031545639,"lat":44.574263943359256}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Crissolo a Ghincia',
        2,
        '/static/gpx/Monte Granè (2).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        6229.073301997005,
        1024.7599999999993,
        200,
        'The Path to Monte Granè is a suggestive walk with a splendid view of Monviso (3841 m) and Viso Mozzo (3019 m).

Leave the car in the car park and continue to the left of the sports field where a splendid path immersed in the woods appears before us and after about 1.5 km you come to the dirt road which in summer leads to the Black Eagle refuge.

Continuing on the latter and having reached the refuge, continue along the Crissolo slopes to the end of the ski-lift where, just above the Ghincia Pastour hut, we will find a statue of the Madonna to indicate the end of the path to Monte Granè.

The return takes place along the same route as the outward journey.',
        '["/static/images/36.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.151954518631101,"lat":44.70016373321414}'::jsonb,
        '{"name":"End Point","address":"Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.121506668627262,"lat":44.688729643821716}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Montr Pigna da Prea',
        2,
        '/static/gpx/Monte Pigna Da Prea (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Roccaforte Mondovì',
        6588.816640728274,
        936.79,
        150,
        'Posteggiata la macchina nel parcheggio sotto l’abitato di Prea ci dirigiamo lungo la strada asfaltata situata sotto il cimitero, lasciandocelo sulla destra.

Appena incontriamo la prima neve possiamo allacciare le ciaspole e proseguire fino alla borgata di Sant’Anna di Prea. (Nei mesi invernali, con nevicate nella norma, la strada viene pulita fino al parcheggio quindi si può iniziare ad indossare le ciaspole fin da subito).

Subito dopo il cartello, all’ingresso di Sant’Anna di Prea, sulla destra vi è un magnifico sentiero immerso nel bosco che permette di tagliare la borgata accorciando la salita di circa 1 km.

Incrociando nuovamente la strada principale e percorrendo circa 3 km si giunge alla Baita Monte Pigna situata a metà degli impianti di Lurisia.',
        '["/static/images/47.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Pigna - Gardiola, Chiusa di Pesio, Cuneo, Piemonte, 12088, Italia","lon":7.738071503117681,"lat":44.27760533988476}'::jsonb,
        '{"name":"End Point","address":"","lon":7.702411115169525,"lat":44.25919541157782}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pian della Regina - Laghi del Monviso',
        2,
        '/static/gpx/Pian della Regina - Laghi del Monviso (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        10065.934631649065,
        842.6999999999998,
        130,
        'The excursion can start near the Po, parking the car in one of the many spaces available. Once you have crossed the stream, follow via Ruata.

To get your bearings in Crissolo, we suggest following the signs for "La Capanna" and ignoring the various detours on the left that follow the ski lifts. Before reaching the restaurant, you finally take the road, following the signs for Monte Tivoli.

The path climbs up into the wood (splendid during the autumn season) and crosses the Sbarme stream.',
        '["/static/images/32.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.117767,"lat":44.700645}'::jsonb,
        '{"name":"End Point","address":"Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.117535,"lat":44.700759}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Fenestrelle Escursionismo',
        2,
        '/static/gpx/Rif. Selleries.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        7281.87058844728,
        504.40087890625,
        120,
        'Itinerario di medio sviluppo con ampio panorama verso la Val Chisone.

Attenzione nella stagione invernale: la zona soggetta a valanghe in caso di abbondanti precipitazioni nevose, specialmente nella conca che precede il rifugio.

Informarsi sempre sullo stato della neve presso i gestori del rifugio o l’ufficio turistico di Fenestrelle.',
        '["/static/images/43.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia","lon":7.0737862307578325,"lat":45.03657284192741}'::jsonb,
        '{"name":"End Point","address":"Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia","lon":7.120104543864727,"lat":45.047753965482116}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Meira Garneri da Sampeyre',
        0,
        '/static/gpx/Rifugio Meira Garneri da Sampeyre (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Sampeyre',
        4156.23862253066,
        850.7600000000003,
        150,
        'Lascia l’auto nel parcheggio della seggiovia di Sampeyre.

Lasciato il parcheggio saliamo subito a destra degli impianti di risalita, dove alcuni cartelli rossi ci segnalano il sentiero attraverso il bosco.

Prendendo rapidamente quota, alla fine del primo tratto di boscoso, raggiungiamo la frazione Sodani dove possiamo osservare la bella chiesa affrescata.

Usciti dalla borgata proseguiamo nuovamente lungo il sentiero circondati da larici, faggi, betulle e dopo alcune deviazione, sempre ben segnalate, usciamo in una splendida radura.

Saliamo gli ultimi 200m a lato della pista o volendo possiamo proseguire più a destra incrociando la strada carrozzabile che nel periodo estivo porta al rifugio.',
        '["/static/images/45.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia","lon":7.180788516998291,"lat":44.57619898952544}'::jsonb,
        '{"name":"End Point","address":"Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia","lon":7.155619841068983,"lat":44.55683704465628}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per ROCCA PATANUA',
        2,
        '/static/gpx/Rocca Patanua da Prarotto (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Condove',
        4388.161778983409,
        923.6238601720527,
        200,
        'Itinerario interamente rivolto a Sud che normalmente si libera dalla neve già a inizio primavera.

(l’itinerario è stato svolto in periodo invernale, seguito scarsa e quasi totalmente assente copertura nevosa).',
        '["/static/images/28.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Alpe Tulivit, Condove, Torino, Piemonte, Italia","lon":7.237061262130737,"lat":45.14908790588379}'::jsonb,
        '{"name":"End Point","address":"Alpe Tulivit, Condove, Torino, Piemonte, Italia","lon":7.219639476388693,"lat":45.17825868912041}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Cima Durand-Colle Bauzano-Artesina',
        3,
        '/static/gpx/Senriero per Anello cima Durand, Colle Bauzano, Artesina (1) (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Artesina',
        8085.211186643268,
        829.1299999999999,
        150,
        'Lasciata la macchina nello spazioso parcheggio di Artesina o nei posteggi vicino al bar Tana del Lupo, saliamo sulle piste dove possiamo subito infilare le ciaspole.

Procediamo per circa 400m sull’ampio sentiero in direzione Ovest (a destra) e dopo alcuni tornanti troviamo un bivio (a sinistra vi è la stradina che percorreremo al ritorno) dove proseguiamo sulla destra (sentiero F02) dirigendoci verso la Celletta, punto panoramico sulla valle Ellero.

Percorriamo il sentiero per Serra della Turra che ci porta prima a passare sotto la seggiovia e poi ad un pianoro dove troviamo la Baita della Turra, tappa ideale per un eventuale break o colazione.',
        '["/static/images/48.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia","lon":7.755467472597957,"lat":44.24691265448928}'::jsonb,
        '{"name":"End Point","address":"Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia","lon":7.754717627540231,"lat":44.246627166867256}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Quintino Sella e Viso Mozzo',
        1,
        '/static/gpx/Sentiero per Rifugio Quintino Sella e Viso Mozzo.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        9039.751801123071,
        1090.660000000001,
        120,
        'The path does not present any difficulty, in case of rain, however, the climb is not recommended as the route is entirely on stony ground.

From up there you have a privileged view of a large part of the Monviso chain and the close distance to the Re di pietra is unique.',
        '["/static/images/31.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia","lon":7.094606207683682,"lat":44.70125044696033}'::jsonb,
        '{"name":"End Point","address":"Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia","lon":7.109863618388772,"lat":44.66575786471367}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Ss659 a Ss6591',
        3,
        '/static/gpx/Sentiero per Rupe del Gesso - CIASPOLE.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Formazzo',
        16969.02550810036,
        984.23046875,
        120,
        'Take the A26 motorway towards Gravellona Toce and follow it to the end. From there stay on the SS33 del Sempione passing Domodossola. At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls. There are unpaved parking lots just before the Centro Fondo Riale.',
        '["/static/images/38.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia","lon":8.41653149574995,"lat":46.41965291462839}'::jsonb,
        '{"name":"End Point","address":"Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia","lon":8.41653149574995,"lat":46.41965291462839}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Albogno-Pieve Margineta Mater',
        2,
        '/static/gpx/albogno-pieve-margineta-mater-27-8-21.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Albogno',
        11301.8785751773,
        1381.6880000000006,
        140,
        'Escursione senza molte difficoltà ideale per il periodo primaverile e autunnale. 
Dopo circa 2 ore di bosco si esce su delle creste molto panoramiche e semplici, il ritorno purtroppo viene fatto su un sentiero poco segnato sulla parte iniziale e ma man mano che si scende compiano sia segni e gli ometti.',
        '["/static/images/11.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia","lon":8.421405,"lat":46.139077}'::jsonb,
        '{"name":"End Point","address":"Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia","lon":8.421395,"lat":46.139111}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Alte Langhe Settentrionali - Cossano Belbo',
        2,
        '/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cossano Belbo',
        2.3,
        25.8,
        200,
        'Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.
Si svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.
Si imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.
Inizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.
Percorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. 
Seguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. 
Si procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante',
        '["/static/images/4.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199049,"lat":44.670379}'::jsonb,
        '{"name":"End Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199052,"lat":44.670377}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":8.214142,"lat":44.674545,"altitude":482.526},{"name":"Ref Point 2","address":"","lon":8.197792,"lat":44.668772,"altitude":242.585}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello per il Monte Freidour (PERLEVIEDELMONDO)',
        2,
        '/static/gpx/anello monte freidour (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'San Pietro Val Lemina',
        8503.263605697935,
        558.511400000002,
        150,
        'At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls.',
        '["/static/images/39.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia","lon":7.284098,"lat":44.96472}'::jsonb,
        '{"name":"End Point","address":"Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia","lon":7.284125,"lat":44.964785}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Anello Pieve di Ledro-Biacesa di Ledro-Rifugio Nino Pernici',
        2,
        '/static/gpx/anello-pieve-di-ledro-biacesa-di-ledro-rifugio-nino-pernici.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        42458.63040670248,
        23175.26399999994,
        320,
        'Anello sui monti a nord-est del Lago di Ledro, percorso in 3 giorni andando con molta calma, percorribile anche in 2. 
Alcuni tratti della prima metà del percorso sono attrezzati con scale e corde.',
        '["/static/images/14.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.73147,"lat":45.882851}'::jsonb,
        '{"name":"End Point","address":"Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731364,"lat":45.882702}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Anello sui colli imolesi: Dozza - Pieve S. Andrea',
        2,
        '/static/gpx/anello-sui-colli-imolesi-dozza-pieve-s-andrea-valsellustra-s.gpx',
        'Italia',
        'Emilia-Romagna',
        'Bologna',
        'Dozza',
        19320.58160760896,
        666.374,
        210,
        'Crossing the provincial road you can see the first of the various signs of the Camino di San Antonio that we will find along the way. We cross and begin a slow but constant climb alongside the fields, which will lead us to a beautiful panoramic view of the surrounding valleys. Paying attention to the crossroads, we continue until we cross the paved road again. In reality there is very little traffic... with a decent view of the Vena del Gesso Romagnola we arrive at the delightful village of Pieve Sant''Andrea (worth a quick detour), to then resume our journey. Be careful not to follow the path of Sant''Antonio, we descend rapidly (shortly after we find the Sorgente delle Accarisie on our left, already existing in Roman times) until we reach the small hamlet of Valsellustra. Here too we cross the road and follow the paved via delle Ville uphill to arrive at a first panoramic point over the surrounding gullies.',
        '["/static/images/21.jpg"]'::jsonb,
        '{"name":"Start Point","address":"5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia","lon":11.632106,"lat":44.359936}'::jsonb,
        '{"name":"End Point","address":"5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia","lon":11.63228,"lat":44.359936}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Campione Pieve Campione',
        2,
        '/static/gpx/campione-pieve-campione.gpx',
        'Italia',
        'Lombardia',
        'Brescia',
        'Campione del Garda',
        10764.501653316338,
        1852.4639999999995,
        300,
        'Campione Pieve Campione',
        '["/static/images/17.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia","lon":10.749084,"lat":45.752875}'::jsonb,
        '{"name":"End Point","address":"Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia","lon":10.749743,"lat":45.757881}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Casalfiumanese (BO) - Pieve di Sant''Andrea',
        2,
        '/static/gpx/casalfiumanese-bo-pieve-di-santandrea.gpx',
        'Italia',
        'Emilia-Romagna',
        'Bologna',
        'Casal Fiumese',
        15650.261397546863,
        838.3309999999993,
        210,
        'Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don''t die from the heat and the clouds filter the sun''s rays and allow you to better enjoy the landscapes',
        '["/static/images/24.jpg"]'::jsonb,
        '{"name":"Start Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616255,"lat":44.29726}'::jsonb,
        '{"name":"End Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616326,"lat":44.297235}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Casalfiumanese (BO) - Pieve di Sant''Andrea',
        2,
        '/static/gpx/casalfiumanese-bo-pieve.gpx',
        'Italia',
        'Emilia-romagna',
        'Bologna',
        'CasalFiumese',
        15650.261397546863,
        838.3309999999993,
        210,
        'Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don''t die from the heat and the clouds filter the sun''s rays and allow you to better enjoy the landscapes',
        '["/static/images/25.jpg"]'::jsonb,
        '{"name":"Start Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616255,"lat":44.29726}'::jsonb,
        '{"name":"End Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616326,"lat":44.297235}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Cavriana pieve- Volta mantovana chiesetta Madonna dei Marchi',
        1,
        '/static/gpx/cavriana-pieve-volta-mantovana-chiesetta-madonna-dei-marchi.gpx',
        'Italia',
        'Lombardia',
        'Mantova',
        'Cavriana',
        17987.27359307591,
        651.414999999999,
        150,
        'Bellissima passeggiata con displivello',
        '["/static/images/13.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia","lon":10.613546,"lat":45.347279}'::jsonb,
        '{"name":"End Point","address":"Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia","lon":10.614472,"lat":45.347241}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":10.625996,"lat":45.345584,"altitude":130.117},{"name":"Ref Point 2","address":"","lon":10.633173,"lat":45.34138,"altitude":139.742},{"name":"Fontain","address":"","lon":10.647482,"lat":45.332552,"altitude":107.319}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per CIMA CIANTIPLAGNA',
        2,
        '/static/gpx/ciantiplagna.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Meana di Susa',
        5474.279781243261,
        791.5095210000009,
        140,
        'The route is safe and within everyone''s reach, even though you reach a relatively high altitude... for this reason it is good to take into account sudden changes in the weather (wind, rain, thick fog).

Due to the total absence of shading, I recommend sunscreen cream and adequate water supply.

In late spring it is still possible to find accumulations of snow which can make the ascent difficult, especially in the final stretch towards the summit.

For cheese lovers, I highly recommend a stop at the Pian dell''Alpe bergeria...',
        '["/static/images/41.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Cima Ciantiplagna, Strada militare del Colle dell''Assietta, Bergerie dell''Assietta, Usseaux, Torino, Piemonte, Italia","lon":7.053414,"lat":45.071918}'::jsonb,
        '{"name":"End Point","address":"Cima Ciantiplagna, Strada militare del Colle dell''Assietta, Bergerie dell''Assietta, Usseaux, Torino, Piemonte, Italia","lon":7.012962,"lat":45.072133}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Voltino a Pieve di Tremosine e ritorno',
        2,
        '/static/gpx/da-voltino-a-pieve-di-tremosine-e-ritorno.gpx',
        'Italia',
        'Lombardia',
        'Brescia',
        'Tremosine sul Garda',
        6588.816640728274,
        936.79,
        120,
        'Fa quasi paura ad avvicinarsi alla ringhiera. 
Vicino alla postazione panoramica presso il bar ristorante che ho fotografato, c''è l''inizio del sentiero per la discesa al Porto di Tremosine.C''è scritto che è consigliato per escursionisti esperti.',
        '["/static/images/15.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia","lon":10.764297,"lat":45.782504}'::jsonb,
        '{"name":"End Point","address":"Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia","lon":10.763028,"lat":45.782797}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Dalla chiesa romanica di San Pietro di Fenestrella alla abba...',
        2,
        '/static/gpx/dalla-chiesa-romanica-di-san-pietro-di-fenestrella-alla-abba.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Albugnano',
        13691.922955982358,
        584.9190000000001,
        150,
        'Chiesa di San Pietro de Fenestrella: 
La chiesa è situata nel cimitero di Albugnano. 
Essa ha affinità compositive con la Canonica di santa Maria di Vezzolano e deriverebbe il suo nome ,secondo alcuni,dalla insolita presenza di tre finestre nell’abside,secondo altri, sarebbe stata così denominata perchè situata nello stretto colle (una gola) compreso tra il rilievo collinare di Albugnano e il rilievo ove sorge il cimitero: 
Una specie di finestra aperta sulla valle sottostante.',
        '["/static/images/27.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia","lon":7.97125,"lat":45.077934}'::jsonb,
        '{"name":"End Point","address":"Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia","lon":7.971227,"lat":45.077991}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Gulo - Pieve Vergonte',
        1,
        '/static/gpx/gulo-pieve-vergonte.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Santa Maria',
        14496.863954985321,
        832.3479999999993,
        90,
        'Gulo - Pieve Vergonte',
        '["/static/images/9.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia","lon":8.248234,"lat":45.997598}'::jsonb,
        '{"name":"End Point","address":"Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia","lon":8.264287,"lat":46.004814}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Il giro del Montorfano: la chiesa romanica, il borgo e la ve...',
        2,
        '/static/gpx/il-giro-del-montorfano-la-chiesa-romanica-il-borgo-e-la-vett.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Bracchio',
        9623.856463002363,
        697.1199999999999,
        210,
        'Il giro del Montorfano: la chiesa romanica, il borgo e la vetta',
        '["/static/images/10.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia","lon":8.448922,"lat":45.960306}'::jsonb,
        '{"name":"End Point","address":"Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia","lon":8.448922,"lat":45.960306}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'La chiesa romanica di S. Vittore(anello Montemagno--Viarigi)',
        3,
        '/static/gpx/la-chiesa-romanica-di-s-vittoreanello-montemagno-viarigi.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montemagno',
        12572.716765417841,
        341.5519999999999,
        210,
        'Il percorso si svolge prevalentemente su sterrata. 
Esso non ha segnaletica ad eccezione dell’ultimo tratto (due km. circa) da località Madonna del Gombo fino a Montemagno. 
In questo tratto si incontra la segnaletica del sentiero n.507 della Regione Piemonte.',
        '["/static/images/6.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia","lon":8.323294,"lat":44.983183}'::jsonb,
        '{"name":"End Point","address":"Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia","lon":8.323553,"lat":44.983388}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'La pieve romanica di Piesenzana e la valle delle tartufaie',
        2,
        '/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montechiaro d''Asti',
        4.4,
        8.4,
        225,
        'Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. 
Circa 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. 
In regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. 
A Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). 
Contemporaneamente i ristoranti della zona propongono piatti a base di tartufi',
        '["/static/images/5.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.113224,"lat":45.007605}'::jsonb,
        '{"name":"End Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.11358,"lat":45.007557}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Le Paludi di Ostiglia Oasi del Busatello Sermide e Pieve',
        3,
        '/static/gpx/le-paludi-di-ostiglia-oasi-del-busatello-sermide-e-pieve-di-.gpx',
        'Italia',
        'Lombardia',
        'Mantova',
        'Pieve di Coriano',
        12572.716765417841,
        341.5519999999999,
        255,
        'La tradizione afferma che la chiesa fu costruita nel 1082, per volere di Matilde di Canossa. Questa attribuzione risale al 1612 nella Historia ecclesiastica di Mantova dove il Donesmondi attribuisce l''edificazione della chiesa a Matilde, assieme ad altre chiese del territorio. 
Il Donesmondi affermò questa data riprendendo l''iscrizione da una lapide presente sulla facciata della pieve, visibile ancora oggi, dove sta scritto "D.O.M. ET B. MARIAE V. IN COELUM ASSUMPTAE ERECTA A.D. 1082 A CONNTISSA MATHILDE". Secondo un''analisi storica questa lapide non può essere ritenuta originale dell''XI secolo, ma risale al cinquecento. L''ipotesi è che questa iscrizione si stata realizzata durante il restauro del 1538. 
Storicamente, quindi, non ci sono documenti che attestano una data certa di costruzione della chiesa, ma sulla base degli elementi architettonici si può affermare che la pieve venne eretta nell''XI secolo. 
La chiesa è in stile romanico, costruita in laterizio ed è composta da tre navat',
        '["/static/images/7.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia","lon":11.106454,"lat":45.035438}'::jsonb,
        '{"name":"End Point","address":"Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia","lon":11.106576,"lat":45.03596}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":11.109236,"lat":45.044962,"altitude":22.75},{"name":"Ref Point 2","address":"","lon":11.155368,"lat":45.034617,"altitude":35.551}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per il MONTE CUCETTO',
        2,
        '/static/gpx/monte cucetto.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Dubbione',
        2150.3010767004043,
        586.4262699999999,
        120,
        'Escursione Facile e, nella parte alta, molto panoramica; la cima offre una buona panoramica dei rilievi tra bassa Val Chisone e Val Sangone.

Lasciata l’auto, il sentiero parte in corrispondenza del tornante ed entra nel bosco in direzione Nord-Ovest; al primo bivio, proseguire dritto e seguire le indicazioni per “Cucetto”; il sentiero inizia a guadagnare quota abbastanza rapidamente e costantemente, sempre nel bosco.

Dopo una serie di tornantini la vegetazione inizierà a diradarsi e si inizierà a scorgere un bel panorama con il Monviso in bella mostra (se il meteo lo permette).',
        '["/static/images/50.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Pralamar, Pinasca, Torino, Piemonte, 10063, Italia","lon":7.243299,"lat":44.961979}'::jsonb,
        '{"name":"End Point","address":"Pralamar, Pinasca, Torino, Piemonte, 10063, Italia","lon":7.240229,"lat":44.977112}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per il MONTE MURETTO',
        2,
        '/static/gpx/monte muretto.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Torino',
        2127.346730436805,
        277.51812700000005,
        200,
        'È presente un unico punto acqua nel luogo del parcheggio (fontana). Nella stessa piazzetta, al momento della recensione, è sempre aperto nei weekend un singolare bar allestito dentro un vecchio furgone.

Per chi cammina con bimbi e soprattutto cani, attenzione in primavera alla presenza di processionarie.',
        '["/static/images/44.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia","lon":7.31544,"lat":44.918242}'::jsonb,
        '{"name":"End Point","address":"Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia","lon":7.309893,"lat":44.929433}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pieve di Ledro - Monte Cocca',
        1,
        '/static/gpx/pieve-di-ledro-monte-cocca.gpx',
        'Italia',
        'Trentino Alto Adige',
        'Provincia di Trento',
        'Pieve di Ledro',
        8627.552532528542,
        1018.0050000000002,
        70,
        'Very challenging, but worth it! The view from the top is gorgeous! For the descent it is better to use sticks, or repeat the same route as the climb.',
        '["/static/images/20.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.730931,"lat":45.889379}'::jsonb,
        '{"name":"End Point","address":"Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731044,"lat":45.889397}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pieve S. Stefano a Pian delle Capanne',
        2,
        '/static/gpx/pieve-s-stefano-a-pian-delle-capanne.gpx',
        'Italia',
        'Toscana',
        'Arezzo',
        'Pieve Santo Stefano',
        22430.396794868582,
        1004.4300000000019,
        150,
        'Causa pioggia e terreno scivoloso preso la 1º variante fino al passo Viamaggio poi proseguito ancora per la 2º variante. 
Bisogna calcolare circa 4 km in più.',
        '["/static/images/23.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Poggiolino delle Viole, Castellare, Pieve Santo Stefano, Arezzo, Toscana, 52036, Italia","lon":12.039528,"lat":43.670638}'::jsonb,
        '{"name":"End Point","address":"Bike Help, Pian della Capanna, Pieve Santo Stefano, Arezzo, Toscana, Italia","lon":12.150503,"lat":43.651402}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Piverone - Anello IV - “Via Romanica al Gesiun”',
        1,
        '/static/gpx/piverone-anello-iv-via-romanica-al-gesiun.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Pieverone',
        4857.311515489554,
        94.22999999999996,
        60,
        'Piverone - Anello IV - “Via Romanica al Gesiun”',
        '["/static/images/8.jpg"]'::jsonb,
        '{"name":"Start Point","address":"26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia","lon":8.00725,"lat":45.44783}'::jsonb,
        '{"name":"End Point","address":"26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia","lon":8.00696,"lat":45.44779}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Plois - Pieve d''Alpago',
        2,
        '/static/gpx/plois-pieve-dalpago.gpx',
        'Italia',
        'Veneto',
        'Belluno',
        'Pieve d''Alpegno',
        6588.816640728274,
        936.79,
        320,
        'percorso è tranquillamente percorribile',
        '["/static/images/19.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Municipio, Via Roma, Torres, Tignes, Pieve d''Alpago, Alpago, Belluno, Veneto, 32010, Italia","lon":12.360272,"lat":46.175025}'::jsonb,
        '{"name":"End Point","address":"Municipio, Via Roma, Torres, Tignes, Pieve d''Alpago, Alpago, Belluno, Veneto, 32010, Italia","lon":12.352636,"lat":46.167926}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Galassi, forcella del ghiacciaio, Rifugio Antelao',
        2,
        '/static/gpx/rifugio-galassi-forcella-del-ghiacciaio-rifugio-antelao-piev.gpx',
        'Italia',
        'Veneto',
        'Belluno',
        'Belluno',
        6588.816640728274,
        936.79,
        200,
        'Quinta giornata Alta via N°4
Rifugio Galassi, forcella del ghiacciaio, Rifugio Antelao, Pieve di Cadore.',
        '["/static/images/18.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia","lon":12.261855,"lat":46.470487}'::jsonb,
        '{"name":"End Point","address":"Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia","lon":12.364278,"lat":46.426071}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Riva del Garda - Pieve di Ledro - Panchina',
        3,
        '/static/gpx/riva-del-garda-pieve-di-ledro-panchina.gpx',
        'Italia',
        'Trentino Alto Adige',
        'Provincia di Trento',
        'Sant''Alessandro',
        8085.211186643268,
        829.1299999999999,
        135,
        'Riva del Garda - Pieve di Ledro - Panchina',
        '["/static/images/16.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.853195,"lat":45.882925}'::jsonb,
        '{"name":"End Point","address":"Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731102,"lat":45.88923}'::jsonb,
        '[{"name":"Peak","address":"","lon":10.853195,"lat":45.882925,"altitude":67.085},{"name":"Lake","address":"","lon":10.764528,"lat":45.873764,"altitude":712.069}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sovicille delle Meraviglie - Villa Cetinale - Scala Santa',
        2,
        '/static/gpx/sovicille-delle-meraviglie-villa-cetinale-scala-santa-e-romi.gpx',
        'Italia',
        'Toscana',
        'Siena',
        'Sovicille',
        19553.110970430764,
        1298.215999999996,
        210,
        'Suggestivo anello con visita della pieve di Pernina e del parco di Villa Cetinale/Castello di Celsa aperti in occasione dell''evento Sovicille delle Meraviglie ottobre 2021',
        '["/static/images/26.jpg"]'::jsonb,
        '{"name":"Start Point","address":"4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia","lon":11.228176,"lat":43.279339}'::jsonb,
        '{"name":"End Point","address":"4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia","lon":11.228044,"lat":43.279294}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'BERGERIE DI VALLONCRO’',
        3,
        '/static/gpx/vallone di massello (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Massello',
        5304.03695311155,
        958.8864720000013,
        150,
        'Open and shade-free environment: remember sunscreen; if the walk is too long, the plateau at the base of the waterfall still offers various possibilities for pleasant picnics.',
        '["/static/images/30.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia","lon":7.031857,"lat":44.964905}'::jsonb,
        '{"name":"End Point","address":"Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia","lon":6.997145,"lat":44.978063}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Ville Disunite - Anello Ghibullo - Villa Pasolini.',
        2,
        '/static/gpx/ville-disunite-anello-ghibullo-villa-pasolini-torre-albicini.gpx',
        'Italia',
        'Emilia-Romagna',
        'Ravenna',
        'Lognana',
        22696.477033711653,
        236.7130000000004,
        110,
        'The first stretch is entirely on the right bank of the Ronco, on the Via Romea Germanica. Then you enter the territory to go towards the center of the journey, the area of ​​San Pietro in Trento where, within two kilometres, you come across a medieval tower, a 9th century parish church with a fantastic crypt, the ruins of a large villa and a perfectly healthy 16th century villa.',
        '["/static/images/23.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia","lon":12.138685,"lat":44.343306}'::jsonb,
        '{"name":"End Point","address":"Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia","lon":12.139573,"lat":44.343643}'::jsonb,
        NULL
      );
    
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2),
        working_time_start time without time zone,
        working_time_end time without time zone,
        email varchar,
        phone_number varchar,
        pictures jsonb,
        description varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber",
      "pictures",
      "description"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number,
      pictures,
      description
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        1,
        149::numeric(12,2),
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Lisa Viscò',
        'http://slimy-participant.it',
        336.289,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Archimede.Merlo25@gmail.com',
        '+395572263341',
        '["/static/images/0cf0a68d-353d-483a-96c2-e705ff3a0aff.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg"]'::jsonb,
        'Deserunt ea odit illum illum atque.
Doloremque iure ducimus repellendus.
Nobis blanditiis autem repellendus sint totam cumque.
Iure amet cum.'
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        8,
        37::numeric(12,2),
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Renato Zucca',
        'http://skeletal-eurocentrism.it',
        302.495,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Girardo.Ciani92@hotmail.com',
        '+397817251795',
        '["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg"]'::jsonb,
        'Amet unde minima aliquid esse dignissimos error explicabo.
Explicabo unde repellendus saepe laborum magnam illum recusandae aspernatur voluptatibus.
Ipsa nulla facilis ex amet.
Recusandae cumque rerum reiciendis voluptas eius aut veritatis.'
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        1,
        113::numeric(12,2),
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Otilia Bandini',
        'http://advanced-porcupine.it',
        294.324,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Servidio49@email.it',
        '+390684825513',
        '["/static/images/d03cf932-28ff-418b-8c01-cbe9b3595a42.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg"]'::jsonb,
        'Doloribus cumque quidem saepe mollitia.
Natus cum placeat a labore.
Rem aliquid cum ab quam quis.
Earum repellat error.
Enim eveniet temporibus deleniti odio velit vero.'
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        9,
        107::numeric(12,2),
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Sig. Fiordaliso Coccia',
        'https://specific-cornmeal.org',
        322,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Alceste81@yahoo.it',
        '+394486261630',
        '["/static/images/013a52c4-de83-4844-b30f-ecdbdd87bcd2.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg"]'::jsonb,
        'Occaecati excepturi eaque consequatur temporibus numquam recusandae.
Ipsa rerum minus ipsam nisi deserunt maiores alias.'
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        6,
        47::numeric(12,2),
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Saturnino Massa',
        'https://worldly-seeker.it',
        320.81,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Zena_Cannone@libero.it',
        '+399261083460',
        '["/static/images/5c1d9ff4-870c-43f3-9a43-5c75839b798f.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]'::jsonb,
        'Pariatur aliquid iste praesentium aut.
Corrupti deserunt optio voluptatibus fugit omnis autem ex illo porro.
Consequuntur veniam velit ut eligendi.'
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        5,
        139::numeric(12,2),
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Vanna Vicini',
        'http://secondary-fingerling.org',
        267.723,
        '08:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Eulalia19@yahoo.it',
        '+398351971306',
        '["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg"]'::jsonb,
        'Vero maiores fugiat veritatis fuga.
Dolor reprehenderit laborum rem perspiciatis.
Nemo nam vel est ullam magni blanditiis accusantium.'
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        3,
        94::numeric(12,2),
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Archimede Fanelli',
        'http://mortified-cupboard.net',
        287.799,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Manetto34@libero.it',
        '+391333933803',
        '["/static/images/e44a5c11-f2a2-4f3e-8c53-af9957e1ea11.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg"]'::jsonb,
        'Repellendus tempora maiores dignissimos consectetur saepe mollitia.
Eum adipisci est veritatis similique labore qui aperiam.
Error quidem facere.'
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        7,
        136::numeric(12,2),
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Viola Vanni',
        'http://alarmed-guideline.org',
        310.958,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Folco.Marcon@hotmail.com',
        '+399299633419',
        '["/static/images/e25caa47-16e0-4d5a-81f8-0f6a69499027.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg"]'::jsonb,
        'Esse consequuntur debitis laboriosam dicta laboriosam dolorum.
Laboriosam quos voluptatem.
Reiciendis fuga qui ipsam.
Nobis aspernatur rerum.
Nulla sapiente necessitatibus id at officiis dolore accusamus ipsa.'
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        5,
        81::numeric(12,2),
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Giulio Ermini',
        'https://clever-perp.it',
        322.428,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Verenzio.Lodi84@gmail.com',
        '+398795250522',
        '["/static/images/e25caa47-16e0-4d5a-81f8-0f6a69499027.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg"]'::jsonb,
        'Quasi laudantium unde adipisci assumenda dolorum officiis.
Alias assumenda odio ut harum architecto consequuntur.
Sed libero in aliquam corporis.'
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        6,
        137::numeric(12,2),
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Gianmario Marega',
        'http://enormous-offering.com',
        276.598,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Onesto.Minelli22@email.it',
        '+390414168573',
        '["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg"]'::jsonb,
        'Quod rem cum tenetur aliquam iste voluptatem quisquam.
Minima commodi modi placeat.
Autem placeat natus quo itaque reprehenderit.
Numquam atque quae voluptatem odit itaque.'
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        7,
        102::numeric(12,2),
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Sig. Nicla Pardini',
        'https://cultivated-oversight.it',
        261.288,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Iona37@hotmail.com',
        '+394070835589',
        '["/static/images/9632fe84-ed47-4201-8ee8-9aff4fc7bd51.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg"]'::jsonb,
        'Pariatur atque natus quae.
Ducimus unde earum.
Odio facere voluptatum.
Illo at placeat consequatur accusamus cupiditate quasi mollitia officiis culpa.
Placeat nesciunt assumenda vero in soluta doloribus.'
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        9,
        98::numeric(12,2),
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Gioventino Oliva',
        'https://earnest-corn.com',
        265.8,
        '08:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Menardo64@gmail.com',
        '+398078617391',
        '["/static/images/814e2adf-d56e-4afd-9b9a-5c9e93c9bab6.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]'::jsonb,
        'Vitae repellat doloribus iure eos aut unde quia.
Tenetur similique consequuntur sint quidem ut.
Debitis ab magnam.
Non animi tenetur neque ad.'
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        3,
        60::numeric(12,2),
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Geronzio Giraudo',
        'http://dapper-jute.com',
        276.659,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Dora60@yahoo.it',
        '+395893138153',
        '["/static/images/3ab7353d-3916-4811-8265-1e83602ade8c.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg"]'::jsonb,
        'Aliquid consequatur atque quam.
Illum nulla labore dolore architecto culpa mollitia labore.'
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        5,
        69::numeric(12,2),
        'Vernagthütte',
        'Austria',
        'Isotta Hofer',
        'http://posh-deviation.it',
        313.901,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Salvatore35@libero.it',
        '+395482914324',
        '["/static/images/4b4ed22c-46cd-4422-97fe-683905feeaa6.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg"]'::jsonb,
        'Corrupti maxime aliquam.
Voluptates amet sequi beatae aspernatur.
Quia rem magnam iste iusto consequuntur accusamus totam.
Culpa placeat beatae exercitationem amet quasi.
Fuga deserunt facilis magnam accusamus sequi dolorem aliquid soluta.'
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        9,
        116::numeric(12,2),
        'Wormser Hütte',
        'Austria',
        'Nicodemo Orefice',
        'http://determined-authenticity.net',
        282.582,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Selvaggia.Rondoni26@gmail.com',
        '+398162709590',
        '["/static/images/76af67a0-a788-48d2-8882-e0b626b8cd9f.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]'::jsonb,
        'Earum repellendus ipsa occaecati asperiores.
Facilis cupiditate dolorem soluta nobis voluptatibus.
Deserunt ipsum itaque animi necessitatibus.
Maiores non hic quod blanditiis eveniet possimus nobis itaque fugit.'
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        9,
        128::numeric(12,2),
        'Biberacher Hütte',
        'Austria',
        'Eustorgio Vierin',
        'http://usable-whirlwind.com',
        320.991,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Urdino41@yahoo.it',
        '+390138009378',
        '["/static/images/e44a5c11-f2a2-4f3e-8c53-af9957e1ea11.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg"]'::jsonb,
        'Labore aperiam minima dolorem sequi ratione sed fuga.
Sapiente itaque maxime voluptatem labore animi laboriosam.
Eum pariatur magnam fugit perferendis saepe itaque adipisci blanditiis quibusdam.
Modi exercitationem quam.
Amet iusto reiciendis a reprehenderit.'
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        4,
        100::numeric(12,2),
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Edoardo Gravina',
        'http://unique-buddy.it',
        278.197,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Marzio.Serra@hotmail.com',
        '+393605293066',
        '["/static/images/0cf0a68d-353d-483a-96c2-e705ff3a0aff.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg"]'::jsonb,
        'Earum labore explicabo explicabo.
Laudantium sed debitis dicta animi.'
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        8,
        46::numeric(12,2),
        'Hochwaldhütte',
        'Germany',
        'Elisabetta Raniolo',
        'https://musty-fanny-pack.org',
        303.818,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Diodoro.Micco87@yahoo.com',
        '+393302777319',
        '["/static/images/5c1d9ff4-870c-43f3-9a43-5c75839b798f.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]'::jsonb,
        'Nisi architecto accusamus laborum repudiandae quos.
Rem eaque velit ducimus hic.'
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        5,
        62::numeric(12,2),
        'Kölner Eifelhütte',
        'Germany',
        'Virone Galati',
        'http://granular-gather.org',
        338.164,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Cupido.DiMartino@email.it',
        '+393619550478',
        '["/static/images/23225d35-5350-4600-89d5-7c01fd116f1d.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg"]'::jsonb,
        'Harum debitis occaecati voluptatem.
Itaque impedit asperiores exercitationem.
Alias voluptatum voluptate reprehenderit mollitia.
Eius eum dolorem ex vel nostrum iste consequatur quod voluptate.'
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        2,
        38::numeric(12,2),
        'Madrisahütte',
        'Austria',
        'Antea Agostinelli',
        'https://unlined-welfare.net',
        298.762,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Ambra.Mottola77@yahoo.com',
        '+392340885631',
        '["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]'::jsonb,
        'Velit aliquam illo necessitatibus voluptates quam pariatur.
Quibusdam rem facilis ea minima mollitia modi natus eaque nam.
Et nobis doloremque aliquam sit sit consectetur fugit fugiat.
Recusandae eum animi.
Nesciunt dignissimos veniam pariatur fuga velit aperiam.'
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        4,
        40::numeric(12,2),
        'Dresdner Hütte',
        'Austria',
        'Rocco De Angelis',
        'http://vivacious-platform.org',
        272.25,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Alfio_Spagnuolo12@hotmail.com',
        '+395348171897',
        '["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]'::jsonb,
        'Numquam rerum distinctio sapiente excepturi harum molestiae placeat.
Deserunt eum dicta vel et explicabo debitis vitae tenetur iure.
Fugit explicabo officia aspernatur minima libero.
Quia itaque consequatur adipisci explicabo sapiente quaerat.
Et impedit officiis veniam cum placeat nesciunt voluptatibus adipisci ab.'
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        6,
        125::numeric(12,2),
        'Fiderepasshütte',
        'Germany',
        'Palmira Papini',
        'http://rectangular-oncology.it',
        271.088,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Clelia0@gmail.com',
        '+393555003191',
        '["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]'::jsonb,
        'Quia saepe iste earum natus quia sint dolor eaque impedit.
Inventore quasi voluptates quisquam.
Pariatur voluptas ab quaerat.'
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        3,
        37::numeric(12,2),
        'Göppinger Hütte',
        'Austria',
        'Fiorenza Zanelli',
        'http://agile-polo.org',
        327.354,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Gianpietro_Motisi@libero.it',
        '+395875499072',
        '["/static/images/480257c1-8fac-4019-a612-6b46ce1a2eb3.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg"]'::jsonb,
        'Ut velit necessitatibus mollitia accusamus repudiandae.
Impedit eligendi fugit fugit eveniet quis ad.'
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        8,
        132::numeric(12,2),
        'Oberzalimhütte',
        'Austria',
        'Sig. Urbano Rambaldi',
        'https://arctic-cone.it',
        292.28,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Rodiano27@hotmail.com',
        '+394171415111',
        '["/static/images/23225d35-5350-4600-89d5-7c01fd116f1d.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg"]'::jsonb,
        'Ea iusto hic ex ea odio eius quia saepe in.
Ipsam quia adipisci deserunt deleniti iste pariatur.
Cum expedita facere nobis praesentium facilis a.
Dolor dolore numquam.
Eaque dignissimos ullam ad quasi numquam.'
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        5,
        89::numeric(12,2),
        'Rastkogelhütte',
        'Austria',
        'Proteo Locatelli',
        'http://neglected-graduate.net',
        336.267,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Leonio_Luppi72@hotmail.com',
        '+390010808406',
        '["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg"]'::jsonb,
        'Fugiat porro animi hic.
Quidem ipsum nobis repudiandae architecto ab animi eaque.
Dolorum quasi quod sint voluptate odio sapiente nostrum atque.
Nulla voluptatibus debitis odio culpa nostrum vitae ab natus iste.'
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        3,
        102::numeric(12,2),
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Giorgio Perrone',
        'https://weird-paste.com',
        333.684,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Graziana_Antezza96@libero.it',
        '+392665568561',
        '["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg"]'::jsonb,
        'Ab eveniet esse deleniti ex eos illum facere veniam magni.
Tempore architecto soluta eveniet minima earum id.'
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        10,
        72::numeric(12,2),
        'Kaltenberghütte',
        'Austria',
        'Ing. Carlotta Ricciardi',
        'http://droopy-streetcar.org',
        266.923,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Adelfo.Rallo57@yahoo.it',
        '+394239213661',
        '["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg"]'::jsonb,
        'Atque fuga laborum ipsa perferendis occaecati officia.
Velit ipsum nostrum deleniti laboriosam commodi quibusdam voluptates quisquam optio.
Ea odio iste quos harum aliquid.
Vel deleniti minus explicabo ad dolorem commodi quo laudantium voluptates.
Praesentium eos molestiae illum possimus quisquam veritatis.'
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        3,
        42::numeric(12,2),
        'Schweinfurter Hütte',
        'Austria',
        'Ulfo Palladino',
        'http://scary-assault.com',
        333.427,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Polidoro.Guastella91@hotmail.com',
        '+394858783959',
        '["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg"]'::jsonb,
        'Necessitatibus molestiae qui enim dolore dolore ea ex.
Ab fugit soluta provident.'
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        1,
        115::numeric(12,2),
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Agata Brumat',
        'http://double-mechanic.net',
        334.996,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Lorena_Fuoco25@hotmail.com',
        '+391658979809',
        '["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]'::jsonb,
        'Beatae nesciunt aut.
Voluptates debitis nesciunt et non dolor.
Occaecati numquam eius a quis mollitia ratione sunt.
Dolorem nobis non officiis velit officiis quibusdam officia provident.
Ea cumque vitae.'
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        8,
        48::numeric(12,2),
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Sostene Borgia',
        'http://closed-vicinity.it',
        294.627,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Graziano8@yahoo.it',
        '+394173425592',
        '["/static/images/e44a5c11-f2a2-4f3e-8c53-af9957e1ea11.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg"]'::jsonb,
        'Expedita alias ipsam quia mollitia sint.
Accusantium iure voluptas facere accusantium iste fugit animi excepturi sequi.
Adipisci dolore cum architecto.
Libero voluptatum repellendus odio perspiciatis corporis laudantium et accusamus commodi.
Unde itaque sint quae doloribus necessitatibus quidem.'
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        3,
        68::numeric(12,2),
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Birino Manzo',
        'https://ultimate-melody.com',
        336.478,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Onofrio31@yahoo.com',
        '+397748548035',
        '["/static/images/0bcb87eb-9a35-47b2-b9e5-eaae9723f0a3.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg"]'::jsonb,
        'Explicabo cupiditate quia deserunt soluta facere quasi aliquam.
Sit doloremque excepturi.
Aut totam occaecati recusandae.
Sequi ipsum qui velit provident.'
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        3,
        102::numeric(12,2),
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Santo Lupica',
        'http://worst-can.it',
        280.269,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Aristione_Sammartino@yahoo.com',
        '+396942892320',
        '["/static/images/480257c1-8fac-4019-a612-6b46ce1a2eb3.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg"]'::jsonb,
        'Nam in inventore animi.
Pariatur rerum eum est alias necessitatibus.
Officiis libero vero voluptatibus.
Vero vero eum praesentium vero iure.
Vero tempora dolorem incidunt itaque suscipit.'
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        8,
        50::numeric(12,2),
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Saba Pucci',
        'https://mountainous-migration.com',
        321.24,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Gaspare_Licciardello77@yahoo.com',
        '+391164885829',
        '["/static/images/3ab7353d-3916-4811-8265-1e83602ade8c.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]'::jsonb,
        'Consectetur sapiente eius.
Laborum vel accusantium consequatur at deleniti libero consequatur.
Repudiandae expedita corporis doloribus molestiae possimus deserunt similique.'
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        4,
        108::numeric(12,2),
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Concetta Porcu',
        'https://ironclad-donut.it',
        282.976,
        '05:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Odetta42@gmail.com',
        '+394122139347',
        '["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]'::jsonb,
        'Corrupti fuga accusantium nostrum.
Corporis ab dignissimos fuga culpa nulla vero.'
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        2,
        40::numeric(12,2),
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Novella Barretta',
        'http://spectacular-laparoscope.org',
        338.47,
        '07:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Nostriano.Ceccarini@yahoo.com',
        '+392679657484',
        '["/static/images/480257c1-8fac-4019-a612-6b46ce1a2eb3.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg"]'::jsonb,
        'Reprehenderit laboriosam optio quia hic ullam fugit.
Sunt cumque blanditiis.
Illum tempora sed.'
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        8,
        40::numeric(12,2),
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Ing. Fabiano De Martino',
        'https://finished-main.it',
        293.864,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Generosa3@yahoo.it',
        '+397454390566',
        '["/static/images/cd0b41d9-e5d2-47d3-8863-fe201a9b9f0e.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg"]'::jsonb,
        'Sequi culpa aliquid illum.
Accusamus quas aliquid ullam dicta.'
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        4,
        62::numeric(12,2),
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Ulfa Maggiore',
        'https://dual-temporariness.com',
        318.079,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Gianmaria.Tataranni@hotmail.com',
        '+390362983455',
        '["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg"]'::jsonb,
        'Iure sequi aliquam eius ducimus eveniet omnis rem.
Voluptates consequatur enim fuga.
Quia officiis fugiat itaque delectus blanditiis.
Quibusdam enim similique rem placeat veritatis saepe est autem eos.'
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        2,
        113::numeric(12,2),
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Dr. Amone Volpi',
        'https://rural-moonshine.net',
        303.45,
        '05:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Santo_Mastrogiacomo@yahoo.it',
        '+394324399016',
        '["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg"]'::jsonb,
        'Doloribus quibusdam cum.
Vero illo neque.
Nam at saepe.
Fugiat mollitia animi ratione accusamus sed quidem blanditiis aperiam.
Voluptate sunt voluptatum voluptatibus suscipit corporis sit quis.'
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        1,
        38::numeric(12,2),
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Nina Castellani',
        'https://official-malnutrition.org',
        271.305,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Taziano_Lelli@yahoo.it',
        '+390347268031',
        '["/static/images/76af67a0-a788-48d2-8882-e0b626b8cd9f.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg"]'::jsonb,
        'Similique eum hic ipsam.
Vel libero omnis hic exercitationem omnis nemo impedit.
Quis amet mollitia quasi soluta dolore qui quo esse.
Modi totam dolorum sed neque in ipsum rerum consequatur.'
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        6,
        58::numeric(12,2),
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Carlotta Pavan',
        'https://putrid-saxophone.it',
        269.394,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Iago_Masucci@yahoo.com',
        '+390135476988',
        '["/static/images/480257c1-8fac-4019-a612-6b46ce1a2eb3.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]'::jsonb,
        'Pariatur id dignissimos quaerat id reiciendis repellat laborum.
At officiis sed omnis delectus voluptatibus possimus inventore sed.
Sunt hic esse.'
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        5,
        91::numeric(12,2),
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Acacio Carlino',
        'http://energetic-knock.com',
        324.408,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Vidiano37@gmail.com',
        '+398280220419',
        '["/static/images/480257c1-8fac-4019-a612-6b46ce1a2eb3.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg"]'::jsonb,
        'Commodi itaque error vel vitae eveniet amet saepe quidem.
Illum consequatur officiis suscipit illo unde deserunt veritatis vel.
Dolores inventore eveniet id illum omnis ut libero dignissimos.'
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        6,
        134::numeric(12,2),
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Carolina Adami',
        'http://jovial-contest.com',
        314.346,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Novella.Procopio@libero.it',
        '+396306415708',
        '["/static/images/cd0b41d9-e5d2-47d3-8863-fe201a9b9f0e.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg"]'::jsonb,
        'Quia fugiat ducimus ex esse.
Odio ipsam architecto occaecati veniam vel iste exercitationem possimus a.
Doloribus nam vitae odio veritatis fuga.'
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        2,
        111::numeric(12,2),
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Endrigo Paolella',
        'https://scaly-sidestream.org',
        262.078,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Marzio.Patriarca@yahoo.com',
        '+394369987471',
        '["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg"]'::jsonb,
        'Perspiciatis similique ullam doloribus nobis.
Porro neque totam aperiam quod laboriosam praesentium quos.
Fuga in velit numquam delectus esse natus nam unde illum.
Laboriosam totam temporibus blanditiis minima vel modi culpa.
Mollitia ipsa aperiam illum quidem nesciunt tenetur.'
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        7,
        94::numeric(12,2),
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Ausilia Marano',
        'http://unconscious-keep.org',
        286.258,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Anastasia_Rossetti@hotmail.com',
        '+393732228797',
        '["/static/images/0bcb87eb-9a35-47b2-b9e5-eaae9723f0a3.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]'::jsonb,
        'Quidem modi tempore.
Debitis distinctio excepturi soluta.
Nihil a quod reiciendis repellat.
Asperiores repellat aliquam ipsam distinctio debitis ullam sunt.
At ea dolore sequi ducimus quaerat qui dignissimos delectus.'
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        9,
        131::numeric(12,2),
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Ricario Manti',
        'https://worn-safety.org',
        337.375,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Plutarco_Genchi@gmail.com',
        '+395256231383',
        '["/static/images/5c1d9ff4-870c-43f3-9a43-5c75839b798f.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]'::jsonb,
        'Maxime asperiores assumenda error.
Eligendi debitis consectetur laborum illum corporis unde.
Quasi iure quisquam error nisi occaecati saepe similique nostrum.
Dignissimos illo autem dolores sint labore est adipisci magni molestias.
Tenetur quidem nobis similique nemo debitis nisi laudantium.'
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        1,
        45::numeric(12,2),
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Sidonio Petrarca',
        'http://awesome-dick.net',
        275.839,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Alfredo28@email.it',
        '+394674086833',
        '["/static/images/9632fe84-ed47-4201-8ee8-9aff4fc7bd51.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg"]'::jsonb,
        'Consequatur magnam tenetur quibusdam facere ipsum labore laborum sunt laudantium.
Cumque consequuntur iste aut pariatur blanditiis veniam.
Nobis voluptates non ex animi officia numquam blanditiis ratione.
Eum natus enim amet non consequatur consectetur.'
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        2,
        49::numeric(12,2),
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Emanuela Mautone',
        'https://round-gander.net',
        281.151,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Amone_Grassi2@yahoo.it',
        '+397668491490',
        '["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg"]'::jsonb,
        'Molestias necessitatibus ipsa provident fugiat totam illum deleniti iure.
Beatae debitis perferendis illo eos tenetur et earum autem fugit.'
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        8,
        45::numeric(12,2),
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Giacinto Melandri',
        'http://lame-illiteracy.net',
        309.608,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Piera16@yahoo.com',
        '+398419536417',
        '["/static/images/e44a5c11-f2a2-4f3e-8c53-af9957e1ea11.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg"]'::jsonb,
        'Sint voluptatum in nobis reprehenderit sed error.
Reiciendis impedit in molestiae sint et laborum accusantium.'
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        8,
        58::numeric(12,2),
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Demetrio Pagliai',
        'https://political-hardening.net',
        294.222,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Tabita.Vaccaro@hotmail.com',
        '+397315727528',
        '["/static/images/e44a5c11-f2a2-4f3e-8c53-af9957e1ea11.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg"]'::jsonb,
        'Cumque dolores fugit amet cupiditate maxime deserunt.
Accusantium facere nostrum in dignissimos facilis nesciunt.
Cupiditate molestias assumenda voluptatem impedit facere eos.
Nobis at amet.'
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        5,
        117::numeric(12,2),
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Ilario Zanotti',
        'https://hollow-anywhere.org',
        311.224,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Aronne.Giovannini@email.it',
        '+398739265585',
        '["/static/images/013a52c4-de83-4844-b30f-ecdbdd87bcd2.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg"]'::jsonb,
        'Provident at consequuntur consequatur cupiditate.
In neque consectetur qui vero optio ea assumenda accusantium sint.
Repellendus possimus placeat.'
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        2,
        106::numeric(12,2),
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Aurelia Molteni',
        'https://unusual-spiritual.net',
        261.881,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Garimberto.Mirabella@hotmail.com',
        '+398899290828',
        '["/static/images/e44a5c11-f2a2-4f3e-8c53-af9957e1ea11.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg"]'::jsonb,
        'Corporis minima voluptates quae saepe nihil laboriosam sunt itaque.
Dicta velit dolor fugit perspiciatis ipsa sit minima velit beatae.'
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        6,
        90::numeric(12,2),
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Dr. Felice Guarino',
        'https://klutzy-wheat.com',
        310.87,
        '03:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Ultimo1@yahoo.it',
        '+393715239938',
        '["/static/images/0bcb87eb-9a35-47b2-b9e5-eaae9723f0a3.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg"]'::jsonb,
        'Saepe aspernatur aspernatur repudiandae expedita maiores.
Dolore veritatis dolorem eius aliquam placeat ipsam voluptatibus deserunt quisquam.
Excepturi iusto esse aspernatur quis nam.'
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        6,
        63::numeric(12,2),
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Livino Zaccaro',
        'https://insubstantial-glass.net',
        278.207,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Fidenziano.Pollina@email.it',
        '+396531561043',
        '["/static/images/23225d35-5350-4600-89d5-7c01fd116f1d.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]'::jsonb,
        'Ad nisi laborum asperiores facilis.
Officia quo impedit quis voluptate temporibus.
Dicta ex voluptatum soluta labore.'
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        4,
        133::numeric(12,2),
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Morgana Sabbatini',
        'http://unused-modernist.org',
        261.492,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Omar.Capriotti@yahoo.it',
        '+397177020397',
        '["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]'::jsonb,
        'Similique quis tempore deleniti non hic enim.
Minus magnam at possimus deserunt.
Sunt consequatur ducimus aliquam.
Eveniet vero nisi ex voluptate ad porro quae esse ducimus.
Consequatur laudantium rerum dolor accusamus.'
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        9,
        57::numeric(12,2),
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Ing. Seconda Addari',
        'http://french-spider.com',
        295.44,
        '09:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Giusto52@hotmail.com',
        '+399996735186',
        '["/static/images/0bcb87eb-9a35-47b2-b9e5-eaae9723f0a3.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg"]'::jsonb,
        'Occaecati id minus rerum at delectus eos.
Alias quo dolorem.'
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        4,
        38::numeric(12,2),
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Alma Cannata',
        'http://glum-solitaire.com',
        277.025,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Omero22@email.it',
        '+397643869307',
        '["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg"]'::jsonb,
        'Quos eos vel architecto officia molestias ea ad.
Eum minus doloribus eum explicabo facilis saepe.
Dolore blanditiis labore.
Aspernatur fugit quia.
Nam reiciendis pariatur omnis impedit voluptate.'
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        1,
        51::numeric(12,2),
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Iginio Adami',
        'http://definite-macaw.org',
        323.223,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Bonaventura_Moretti@gmail.com',
        '+399327334120',
        '["/static/images/814e2adf-d56e-4afd-9b9a-5c9e93c9bab6.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]'::jsonb,
        'Perferendis similique nam esse consequatur earum dolorem eaque nemo.
Laudantium tempore incidunt nisi voluptate at excepturi sequi suscipit.'
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        10,
        120::numeric(12,2),
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Guenda Castagna',
        'http://fast-guilder.org',
        320.842,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Gisella_Nicolini24@email.it',
        '+395222404924',
        '["/static/images/814e2adf-d56e-4afd-9b9a-5c9e93c9bab6.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]'::jsonb,
        'Soluta dolorum autem alias tempora excepturi neque recusandae totam.
Architecto minus possimus modi repellendus eligendi facilis.
Eius magnam iusto ex perspiciatis dolore corporis.
Expedita eos quisquam corporis.'
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        5,
        125::numeric(12,2),
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Terenzio Allegretti',
        'http://deserted-mission.net',
        339.118,
        '04:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Ursino_Tomassoni67@yahoo.it',
        '+395257024127',
        '["/static/images/013a52c4-de83-4844-b30f-ecdbdd87bcd2.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg"]'::jsonb,
        'Natus architecto quisquam nostrum nostrum vel consequatur voluptate quisquam quod.
Quisquam error aperiam esse animi fuga aliquid ipsum ipsum perspiciatis.
Veniam recusandae earum possimus totam illum voluptatibus quaerat reprehenderit.'
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        2,
        87::numeric(12,2),
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Agata Repetto',
        'http://misguided-poverty.it',
        325.451,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Elita63@gmail.com',
        '+393331854002',
        '["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg"]'::jsonb,
        'Ipsam natus sequi blanditiis animi.
At laboriosam commodi magni illum recusandae necessitatibus mollitia laudantium id.
Quia libero expedita iusto quia quos ipsa quaerat.
Illo excepturi totam soluta architecto.'
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        5,
        124::numeric(12,2),
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Pierluigi De Chiara',
        'https://aching-grandma.net',
        330.073,
        '09:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Alfonsa.Olivieri27@email.it',
        '+390821627444',
        '["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg"]'::jsonb,
        'Possimus dolores delectus.
Odit necessitatibus nemo quis porro nobis ullam nesciunt soluta.'
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        10,
        115::numeric(12,2),
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Armida Accardi',
        'http://abandoned-borrower.com',
        335.717,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Lidia.Marchesi@email.it',
        '+390130515072',
        '["/static/images/0bcb87eb-9a35-47b2-b9e5-eaae9723f0a3.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg"]'::jsonb,
        'Aliquid iste officiis consectetur modi.
Exercitationem ducimus possimus laborum.'
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        6,
        108::numeric(12,2),
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Mattia Castaldi',
        'https://shy-processor.it',
        313.303,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Beato_Caporaso82@yahoo.it',
        '+390440857293',
        '["/static/images/23225d35-5350-4600-89d5-7c01fd116f1d.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg"]'::jsonb,
        'Tempora consectetur similique iusto molestiae.
Distinctio voluptatem odit veniam quasi reiciendis adipisci laborum alias.'
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        8,
        88::numeric(12,2),
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Giuliana Rodigari',
        'https://hard-to-find-lesbian.org',
        296.26,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Verano68@hotmail.com',
        '+395346463349',
        '["/static/images/9632fe84-ed47-4201-8ee8-9aff4fc7bd51.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg"]'::jsonb,
        'Dicta eveniet ea asperiores autem praesentium dolorum dolore fugit.
Consectetur dolore nihil.
Nesciunt ab eius rem mollitia maxime dolore.
Temporibus veniam beatae nam.'
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        10,
        145::numeric(12,2),
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Ezechiele Musumeci',
        'https://variable-headline.it',
        266.711,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Danilo_Demontis@yahoo.com',
        '+397089955869',
        '["/static/images/6e98325a-8ec6-4065-aa74-d713ecb47872.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg"]'::jsonb,
        'Placeat asperiores aliquam nulla reprehenderit.
Repellendus quas quas quam ratione at sapiente minima.
Dicta culpa delectus temporibus harum ducimus doloremque voluptatibus voluptate tenetur.'
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        4,
        134::numeric(12,2),
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Onofrio De Vito',
        'http://slimy-press.it',
        280.423,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Genesia70@libero.it',
        '+398764548116',
        '["/static/images/cd0b41d9-e5d2-47d3-8863-fe201a9b9f0e.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg"]'::jsonb,
        'Sunt libero at.
Maiores adipisci assumenda nemo incidunt nemo.
Delectus nihil nesciunt animi id dolores voluptas rem.'
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        3,
        127::numeric(12,2),
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Adelaide Pucci',
        'http://sharp-windscreen.org',
        279.702,
        '08:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Fiorenziano_Preziosi39@gmail.com',
        '+396369377632',
        '["/static/images/013a52c4-de83-4844-b30f-ecdbdd87bcd2.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg"]'::jsonb,
        'Consectetur quaerat aut in inventore.
Tempora libero amet debitis possimus eaque cum debitis.'
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        5,
        54::numeric(12,2),
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Chiara Natali',
        'http://legal-cytoplasm.it',
        270.498,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Druina_Satta61@email.it',
        '+398217330600',
        '["/static/images/6e98325a-8ec6-4065-aa74-d713ecb47872.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg"]'::jsonb,
        'Numquam possimus optio nam quo animi nisi.
Velit unde praesentium fuga saepe eum doloremque vitae nobis.
Reiciendis mollitia ipsum ratione asperiores inventore quia ex reiciendis dolor.
Facilis modi dicta repellat ratione ad.'
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        1,
        131::numeric(12,2),
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Aquilino Corradini',
        'https://decisive-veranda.net',
        305.008,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Alda.Talarico8@libero.it',
        '+393691213605',
        '["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg"]'::jsonb,
        'Aspernatur necessitatibus quia odio.
Ut repellendus quas hic quaerat.
Architecto iure magni quos excepturi ipsa.
Iusto omnis fuga reprehenderit ipsa officia non deleniti perspiciatis libero.'
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        7,
        53::numeric(12,2),
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Ramiro Alessi',
        'https://sarcastic-trout.org',
        303.856,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Zetico_Cavallini67@yahoo.it',
        '+396000047541',
        '["/static/images/9632fe84-ed47-4201-8ee8-9aff4fc7bd51.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg"]'::jsonb,
        'Eius at deleniti nobis cumque.
Deserunt iusto maiores adipisci esse.
Incidunt expedita doloremque dolore maxime asperiores.
Veritatis similique saepe nisi delectus architecto sit rerum similique ea.'
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        9,
        145::numeric(12,2),
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Ciriaco Giannini',
        'https://intent-speculation.net',
        291.764,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Narsete.Recchia@email.it',
        '+395161474085',
        '["/static/images/cd0b41d9-e5d2-47d3-8863-fe201a9b9f0e.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg"]'::jsonb,
        'Minima suscipit error inventore vel.
Soluta quam sapiente reprehenderit quo porro fuga.'
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        10,
        140::numeric(12,2),
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Bassilla Di Gennaro',
        'https://french-finding.net',
        260.713,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Crescente.Monaco44@libero.it',
        '+391246991862',
        '["/static/images/76af67a0-a788-48d2-8882-e0b626b8cd9f.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg"]'::jsonb,
        'Quod quod voluptate illo quasi quisquam ullam perferendis ad.
Esse modi tempore consequuntur nulla tempora magni eius fugiat pariatur.
Perspiciatis esse voluptatum officia fuga maxime illo maxime doloremque optio.
Eveniet harum cum perferendis numquam omnis odio.'
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        2,
        122::numeric(12,2),
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Elimena Severi',
        'https://frivolous-communist.it',
        275.51,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Amauri41@gmail.com',
        '+396178223404',
        '["/static/images/23225d35-5350-4600-89d5-7c01fd116f1d.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg"]'::jsonb,
        'Fuga non facere pariatur labore totam rerum.
Adipisci soluta nesciunt doloremque dolorum sed totam ea.
Odio eos tempora harum necessitatibus doloribus sapiente ducimus asperiores quos.
Quisquam unde adipisci molestiae accusamus dolor vitae architecto quasi possimus.
Nostrum saepe id.'
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        5,
        46::numeric(12,2),
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Fiore Grange',
        'https://ancient-intentionality.net',
        271.125,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Ianira_Rauso35@yahoo.com',
        '+396569328469',
        '["/static/images/814e2adf-d56e-4afd-9b9a-5c9e93c9bab6.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg"]'::jsonb,
        'Ullam labore vero consequatur ex cupiditate facilis unde.
Minima neque expedita provident iusto maiores expedita doloribus.'
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        10,
        65::numeric(12,2),
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Basilia Traini',
        'https://petty-trophy.com',
        277.637,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Festo_DeGiorgi22@yahoo.com',
        '+390003723108',
        '["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]'::jsonb,
        'Quas accusamus maxime.
Asperiores mollitia et veniam possimus eos perspiciatis mollitia impedit unde.
Cupiditate error fugit.'
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        2,
        54::numeric(12,2),
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Onorina Marelli',
        'https://soulful-seeker.com',
        283.399,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Cipriano37@yahoo.com',
        '+390538280776',
        '["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]'::jsonb,
        'Vero sed reiciendis deleniti omnis quia praesentium harum officia.
Debitis architecto delectus totam.
Illo ipsam ullam.'
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        6,
        128::numeric(12,2),
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Matroniano Balsamo',
        'http://equatorial-land.it',
        302.582,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Arcadio_Zunino@libero.it',
        '+397609177401',
        '["/static/images/3ab7353d-3916-4811-8265-1e83602ade8c.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg"]'::jsonb,
        'Eligendi et quis quia.
Maiores modi neque sapiente voluptas.
Aliquid deserunt quibusdam eligendi corrupti.
Itaque libero officia earum assumenda.
Pariatur atque repellat iste blanditiis facere neque quod voluptatem.'
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        5,
        69::numeric(12,2),
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Cristoforo Piazzolla',
        'https://illustrious-saviour.net',
        269.956,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Claudia.Forconi@libero.it',
        '+391353844816',
        '["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg"]'::jsonb,
        'Enim non atque voluptatum sit quae sunt sequi at vitae.
Nulla nobis rerum delectus mollitia ullam excepturi repellendus facilis.
Eligendi quia dolorem illo voluptatum quam asperiores quos accusantium cupiditate.'
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        2,
        75::numeric(12,2),
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Dr. Aurelio Guarneri',
        'http://false-associate.net',
        303.941,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Climaco73@email.it',
        '+390032342571',
        '["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]'::jsonb,
        'Rem modi perferendis perferendis error voluptate fugit harum.
Cupiditate doloribus tempore.
Minus eveniet maiores temporibus minus explicabo iste ex ipsum aut.
Iusto rerum deleniti illo.'
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        6,
        69::numeric(12,2),
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Dott. Cinzia Fuoco',
        'http://equatorial-hearsay.org',
        279.364,
        '04:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Romolo_Critelli@gmail.com',
        '+394358762209',
        '["/static/images/3ab7353d-3916-4811-8265-1e83602ade8c.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg"]'::jsonb,
        'Accusantium quidem officiis exercitationem iste numquam culpa at.
Libero nesciunt perspiciatis eaque voluptas asperiores libero consequatur.
Ratione itaque minima excepturi similique.
Nobis repellat ex enim debitis ex quis necessitatibus.'
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        4,
        44::numeric(12,2),
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Glauco Mazzotti',
        'https://classic-trailpatrol.com',
        262.562,
        '02:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Veriana_Terlizzi25@gmail.com',
        '+393871477417',
        '["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]'::jsonb,
        'Sapiente ut perferendis earum accusamus at mollitia sed temporibus mollitia.
Qui pariatur alias iure unde est.
Repellat ipsum atque quam occaecati.
Amet deleniti eius.'
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        3,
        147::numeric(12,2),
        'Wittener Hütte',
        'Germany',
        'Dr. Fermiano Colonna',
        'http://yummy-engine.com',
        312.391,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Aresio16@hotmail.com',
        '+398967440142',
        '["/static/images/4b4ed22c-46cd-4422-97fe-683905feeaa6.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg"]'::jsonb,
        'Soluta nesciunt repellat provident.
Iusto ullam corporis voluptatem velit fugiat recusandae ab porro.'
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        9,
        42::numeric(12,2),
        'Hochjoch-Hospiz',
        'Austria',
        'Tamara Monti',
        'http://remarkable-baobab.it',
        308.768,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Germano.Tufo9@hotmail.com',
        '+398570702877',
        '["/static/images/23225d35-5350-4600-89d5-7c01fd116f1d.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg"]'::jsonb,
        'Inventore explicabo quod sint tempora quo.
Vitae eaque quis accusantium vero quos cumque ut ut excepturi.
Mollitia quam quod possimus necessitatibus incidunt occaecati ab.
Sit quam nulla.
Ex tempore voluptas culpa non enim dolor labore officiis.'
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        4,
        67::numeric(12,2),
        'Meilerhütte',
        'Germany',
        'Fazio Scaglione',
        'https://untried-barrel.it',
        332.86,
        '09:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Iole.Moras@yahoo.com',
        '+390627771590',
        '["/static/images/d03cf932-28ff-418b-8c01-cbe9b3595a42.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]'::jsonb,
        'At consequuntur amet nesciunt delectus adipisci illum ducimus incidunt.
Similique ad quos ea eveniet exercitationem.
Ipsa nulla soluta laboriosam laudantium occaecati iusto eum dolorum omnis.
Possimus vitae pariatur reprehenderit totam ullam laudantium temporibus delectus.
Dolorem ullam cupiditate et explicabo fugit mollitia porro.'
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        1,
        80::numeric(12,2),
        'Gaudeamushütte',
        'Austria',
        'Simone Musumeci',
        'http://optimal-tempo.org',
        308.932,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Geronzio4@yahoo.com',
        '+391234688900',
        '["/static/images/0cf0a68d-353d-483a-96c2-e705ff3a0aff.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg"]'::jsonb,
        'Eos veniam fuga iusto deserunt incidunt ad velit temporibus.
Delectus quis eveniet veniam.
Magnam suscipit tempora tempore excepturi vero.
Commodi quisquam tempora quo ab consequatur quaerat.'
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        8,
        43::numeric(12,2),
        'Rheydter Hütte',
        'Germany',
        'Veriana Riccobono',
        'https://cheery-helicopter.com',
        287.873,
        '03:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Concetto2@hotmail.com',
        '+398824825208',
        '["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg"]'::jsonb,
        'Incidunt ad neque maxime molestias sit.
Hic error alias repellendus facilis.
Impedit tempora ipsum pariatur ad voluptatem cum dolorum.
Voluptas delectus ea ullam molestias esse.
Odio illum laboriosam saepe.'
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        8,
        56::numeric(12,2),
        'Sektionshütte Krippen',
        'Germany',
        'Glenda Addis',
        'https://wan-icon.it',
        263.75,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Rufina.Argiolas2@libero.it',
        '+399998330377',
        '["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]'::jsonb,
        'In sed et unde optio.
Suscipit eius praesentium placeat quis provident porro reiciendis.'
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        9,
        74::numeric(12,2),
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Alda Tomaselli',
        'http://watchful-inglenook.net',
        310.177,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Romana.Santo@gmail.com',
        '+399169950321',
        '["/static/images/9632fe84-ed47-4201-8ee8-9aff4fc7bd51.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg"]'::jsonb,
        'Nesciunt in nemo aspernatur odio quidem consequuntur consequuntur.
Quis quis minima pariatur enim temporibus dolore sunt iusto nihil.
Illo non ut.'
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        8,
        115::numeric(12,2),
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Orsola Moser',
        'https://triangular-statin.org',
        321.751,
        '07:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Noemi_Gatta@email.it',
        '+398122893108',
        '["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg"]'::jsonb,
        'Reiciendis doloremque eius ipsa nihil consequuntur nemo suscipit tempora culpa.
Corrupti ullam natus quo quas qui sunt odit.'
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        7,
        41::numeric(12,2),
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Mario Ingrassia',
        'http://reckless-meridian.net',
        331.083,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Tulliano13@hotmail.com',
        '+396727668897',
        '["/static/images/76af67a0-a788-48d2-8882-e0b626b8cd9f.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]'::jsonb,
        'Illo voluptatum nihil accusantium dolorum.
Eos facere odit.
Amet illo quaerat deserunt.
Quibusdam quo voluptas maxime.
Velit sapiente quisquam.'
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        10,
        116::numeric(12,2),
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Laura Pianese',
        'https://naive-diversity.org',
        292.967,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Simona.Cecchetti27@yahoo.com',
        '+393450809501',
        '["/static/images/e25caa47-16e0-4d5a-81f8-0f6a69499027.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg"]'::jsonb,
        'Quam illo ad numquam debitis.
Accusamus aspernatur ab labore cumque cupiditate officia explicabo vel excepturi.
Rerum pariatur vel.'
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        5,
        68::numeric(12,2),
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Rosalinda Manzella',
        'http://equal-guerrilla.com',
        307.265,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Aciscolo_Olivieri@email.it',
        '+396361685040',
        '["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]'::jsonb,
        'Temporibus enim ea commodi.
Aliquam eos amet.
Quisquam quia debitis unde earum commodi omnis cum ex autem.'
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        8,
        75::numeric(12,2),
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Godiva Papini',
        'https://sharp-lifetime.org',
        273.571,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Maura_Santarossa52@libero.it',
        '+394888964053',
        '["/static/images/5c1d9ff4-870c-43f3-9a43-5c75839b798f.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]'::jsonb,
        'Quam tenetur nihil suscipit voluptas minus ex.
Error atque nobis modi tempora.
Velit est eum.
Sequi et culpa atque.
Magnam ut quisquam debitis asperiores culpa veritatis fugiat eveniet.'
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        4,
        130::numeric(12,2),
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Ada Filippi',
        'http://dear-tailspin.it',
        320.232,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Arrigo56@libero.it',
        '+394109271673',
        '["/static/images/e25caa47-16e0-4d5a-81f8-0f6a69499027.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg"]'::jsonb,
        'Incidunt nesciunt porro.
Unde dicta quis repudiandae.'
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        5,
        64::numeric(12,2),
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Saffiro Genovese',
        'https://tired-bank.it',
        335.757,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Alano_Beso31@yahoo.com',
        '+393477567038',
        '["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg"]'::jsonb,
        'Distinctio quia nisi laboriosam architecto optio maiores consectetur.
Dolorem delectus officiis perspiciatis.
Velit eum sequi dicta vitae perspiciatis vitae.'
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        5,
        72::numeric(12,2),
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Dott. Oronzo Brizzi',
        'http://idiotic-standing.it',
        338.217,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Generosa7@email.it',
        '+398643484528',
        '["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg","/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg"]'::jsonb,
        'Eaque sapiente incidunt.
Deleniti vel temporibus aut distinctio.
Molestiae esse amet vitae.'
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        1,
        148::numeric(12,2),
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Lucia Salvatore',
        'http://straight-plaster.com',
        310.193,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Amando_Ferrante@libero.it',
        '+397254767486',
        '["/static/images/76af67a0-a788-48d2-8882-e0b626b8cd9f.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]'::jsonb,
        'Neque cumque minus optio temporibus laudantium non.
Illo laborum quasi cumque delectus magni hic assumenda explicabo corporis.
Possimus numquam iste perspiciatis eligendi omnis dicta corrupti.'
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        9,
        46::numeric(12,2),
        'Dobra voda',
        'Suvobor, Serbia',
        'Geronimo Zunino',
        'http://sneaky-sprout.org',
        264.888,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Siriano_Santucci@libero.it',
        '+393581006816',
        '["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg"]'::jsonb,
        'Ab ad velit odit ea corrupti.
Dolore maiores totam unde enim aspernatur odit alias.
Dignissimos qui delectus aliquam pariatur hic incidunt consectetur laborum.
Odio placeat qui vel.
Unde esse sed commodi alias quibusdam.'
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        8,
        105::numeric(12,2),
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Raimondo Gullì',
        'https://poor-woman.com',
        323.812,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Pierluigi.Festa32@hotmail.com',
        '+397311931425',
        '["/static/images/5c1d9ff4-870c-43f3-9a43-5c75839b798f.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg"]'::jsonb,
        'Voluptatum iusto corrupti reiciendis.
Laudantium tempora temporibus rem praesentium rem voluptas.
Repudiandae similique commodi commodi.
Tenetur alias ipsum repellat quisquam animi.
Veniam minima voluptatem.'
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        2,
        101::numeric(12,2),
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Lorella Marsella',
        'http://nutritious-spirit.net',
        274,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Esuperio.Milano@yahoo.it',
        '+390158067793',
        '["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg"]'::jsonb,
        'Facere perferendis aperiam vitae occaecati.
Exercitationem animi illum quos a quam.
Quaerat ducimus repellat nam unde deserunt voluptate nisi quidem.
Non cumque ut.
Corrupti aspernatur ab numquam iusto.'
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        2,
        112::numeric(12,2),
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Venanzio Palombi',
        'http://composed-obligation.it',
        333.591,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Lanfranco_Piazzolla32@yahoo.com',
        '+394646328053',
        '["/static/images/480257c1-8fac-4019-a612-6b46ce1a2eb3.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg"]'::jsonb,
        'Corporis dolorem quasi similique ullam sed.
Nam numquam harum quia at et minus doloribus eos.
Eos repellat placeat quaerat rerum consectetur temporibus repellat animi incidunt.
Beatae nostrum necessitatibus recusandae inventore magni eius quo.
Enim voluptate odio magni cupiditate error eum recusandae.'
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        5,
        46::numeric(12,2),
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Renato Valletta',
        'https://candid-crush.org',
        264.28,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Felicita.Pianese@libero.it',
        '+395055367502',
        '["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg","/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]'::jsonb,
        'Ut aperiam qui dolore rem eveniet tempore a.
Cum in sed consequatur praesentium vel consectetur officiis doloribus ea.
Consequuntur architecto voluptates quas suscipit.'
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        6,
        118::numeric(12,2),
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Bardo Annunziata',
        'http://ultimate-eel.org',
        323.376,
        '07:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Melitina22@email.it',
        '+394818254575',
        '["/static/images/5c1d9ff4-870c-43f3-9a43-5c75839b798f.jpg","/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]'::jsonb,
        'Animi corrupti necessitatibus illo cupiditate soluta ipsum accusantium aliquam earum.
Laudantium eum repellat ad architecto ea repudiandae odio.
Illum deserunt nihil atque.
Assumenda enim laboriosam pariatur quasi eos dolores eum aut aliquid.
Soluta quia delectus quia aspernatur voluptatibus.'
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        2,
        58::numeric(12,2),
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Ing. Alba Palombi',
        'https://authorized-login.org',
        331.878,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Pauside48@yahoo.com',
        '+394756266329',
        '["/static/images/4b4ed22c-46cd-4422-97fe-683905feeaa6.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg"]'::jsonb,
        'Officiis totam sunt itaque voluptatem autem animi nobis incidunt.
Sit eos ipsum porro itaque aperiam adipisci corporis voluptatum.'
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        5,
        66::numeric(12,2),
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Stefano Spagnolo',
        'https://vast-crackers.it',
        305.83,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Telica_Bosco@email.it',
        '+396707427725',
        '["/static/images/4b4ed22c-46cd-4422-97fe-683905feeaa6.jpg","/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg","/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg","/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg"]'::jsonb,
        'Error debitis cupiditate atque aut quam perspiciatis qui aut.
Perferendis dolorum nemo.
Ex enim laborum temporibus vitae quis.
Ad non rerum aspernatur error est.
Itaque dignissimos praesentium facere doloremque velit quidem natus.'
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        8,
        73::numeric(12,2),
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Dott. Liliana Pompilio',
        'https://fond-gateway.net',
        291.301,
        '05:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Saverio_Mulas14@yahoo.it',
        '+399543470816',
        '["/static/images/6e98325a-8ec6-4065-aa74-d713ecb47872.jpg","/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg","/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg","/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg"]'::jsonb,
        'Fugiat hic necessitatibus animi architecto consectetur provident saepe.
Blanditiis ea nemo eius animi.
Fugiat atque nostrum molestiae repudiandae veniam voluptate magni.
Cupiditate inventore sed tempora illo nemo officiis aperiam voluptate magni.
Distinctio sit non doloremque corrupti assumenda ea accusamus.'
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        10,
        45::numeric(12,2),
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Geronzio Fusco',
        'https://mountainous-courtroom.com',
        302.015,
        '03:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Elena_LoGiudice0@gmail.com',
        '+397668505733',
        '["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg","/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg"]'::jsonb,
        'Iste libero dolores iusto error illo consequuntur iure a.
Eaque accusamus veniam alias magnam accusamus dolores minima.
Vel aliquam repellendus quae enim eveniet praesentium voluptas ut tenetur.
Odio at quod nesciunt tempora nobis sapiente.'
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        9,
        130::numeric(12,2),
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Amabile Adami',
        'https://unwitting-triad.org',
        281.473,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Elettra.DErrico@yahoo.it',
        '+398070796038',
        '["/static/images/0cf0a68d-353d-483a-96c2-e705ff3a0aff.jpg","/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg","/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg","/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg","/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg"]'::jsonb,
        'Sint eaque libero ab repellat incidunt cupiditate dolores excepturi.
Minus accusamus aliquam accusantium voluptates enim totam.
Accusamus recusandae asperiores.'
      );
    
  

      CREATE OR REPLACE FUNCTION public.insert_hut_worker(
        hwid integer,
        email varchar,
        password varchar,
        first_name varchar,
        last_name varchar,
        role integer,
        hut_id integer,
        approved boolean
      ) RETURNS VOID AS
      $func$
      DECLARE
        user_id integer;
      BEGIN
      INSERT INTO "public"."users" (
        "id",
        "email",
        "password",
        "firstName",
        "lastName",
        "role",
        "verified",
        "approved"
      ) VALUES(
        hwid, email, password, first_name, last_name, role, true, approved
      ) returning id into user_id;

      INSERT INTO "public"."hut-worker" (
        "userId",
        "hutId"
      ) VALUES ( user_id, hut_id);
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hut_worker"(
        7,
        'hutWorker0@gmail.com',
        '$2b$10$fnrZ937CnqhlYltMyVuzdehHI0qgcmpYY6GBuoRz234lOlgad8r/.',
        'Cloe',
        'Caiazza',
        4,
        1,
        true
      );
    

      select public."insert_hut_worker"(
        8,
        'hutWorker1@gmail.com',
        '$2b$10$Qw.NcrD5bb4hhmt042/D2.PRmh0Kt7eUw7syHLUq7zvfD43U9DWXy',
        'Iginia',
        'Manzi',
        4,
        2,
        false
      );
    

      select public."insert_hut_worker"(
        9,
        'hutWorker2@gmail.com',
        '$2b$10$Nfaib1smwlh1/eb8XwKt1eXDKoVyEnDtVFdpSvbogC5hsleTCrphG',
        'Ursicio',
        'Mele',
        4,
        3,
        true
      );
    

      select public."insert_hut_worker"(
        10,
        'hutWorker3@gmail.com',
        '$2b$10$4fJnSTy2q5Mt8HTt38Nxv.WD8CxG9RkkiBhgR5wFuYPtSF5LNEn5G',
        'Basileo',
        'Simeti',
        4,
        4,
        false
      );
    

      select public."insert_hut_worker"(
        11,
        'hutWorker4@gmail.com',
        '$2b$10$7.fns18sX2lxvBZINpQ3O.IewjikFumunI4cX7goZkJ4y2aSUI/IG',
        'Fidenzio',
        'Dal Farra',
        4,
        5,
        true
      );
    

      select public."insert_hut_worker"(
        12,
        'hutWorker5@gmail.com',
        '$2b$10$ygKYRHlGutq6tAXNK3u73Oe4hsi4s2d1UMC11NpA.zziQ3jcAsazW',
        'Franco',
        'Marchini',
        4,
        6,
        false
      );
    

      select public."insert_hut_worker"(
        13,
        'hutWorker6@gmail.com',
        '$2b$10$kd3NTeKxBklZZixlQ3Hrj.hamaamB5FfBUjzQYbNaaFrzz..x.B4C',
        'Teodolinda',
        'Casella',
        4,
        7,
        true
      );
    

      select public."insert_hut_worker"(
        14,
        'hutWorker7@gmail.com',
        '$2b$10$e4jsix9XZExFW80p1HgiWOvY8XWiPIkUQ866ybNRDIY0O2zI3pA9K',
        'Giacomo',
        'Cassano',
        4,
        8,
        false
      );
    

      select public."insert_hut_worker"(
        15,
        'hutWorker8@gmail.com',
        '$2b$10$qtdvhBmGlmlMHJQpmfgNbuYbovV43STWU9REior75DOBKIsBxRiYm',
        'Maria',
        'Barberis',
        4,
        9,
        true
      );
    

      select public."insert_hut_worker"(
        16,
        'hutWorker9@gmail.com',
        '$2b$10$PL6WoiU.IUDh5cYHrosogeePTt0iJPktT2SIvIiBDKtLQS0bGtmiO',
        'Audace',
        'Tagliabue',
        4,
        10,
        false
      );
    

      select public."insert_hut_worker"(
        17,
        'hutWorker10@gmail.com',
        '$2b$10$yRNGvxmYDqyzXBv4Mg/.9uvW6MnvNk3PqqICN2fdVGzlH0i801Kte',
        'Carolina',
        'Sartori',
        4,
        11,
        true
      );
    

      select public."insert_hut_worker"(
        18,
        'hutWorker11@gmail.com',
        '$2b$10$bgK.Dx/6PLiyeYFxP.Bo3eZuLdWjKSfUEOSx38G3s7VPGWXKv.UTW',
        'Cesario',
        'Picchi',
        4,
        12,
        false
      );
    

      select public."insert_hut_worker"(
        19,
        'hutWorker12@gmail.com',
        '$2b$10$4/62aIpob2/n1Js6iNyGxO6fDjgjIhM1kGhu3gkpWDdad0g7er8L.',
        'Lodovico',
        'Di Maggio',
        4,
        13,
        true
      );
    

      select public."insert_hut_worker"(
        20,
        'hutWorker13@gmail.com',
        '$2b$10$8dPsc4TJO9O1QmzdcrZRKOUeG6i9rkcZ88CqMQcJCI.VPN8GkJBN2',
        'Ettore',
        'Serena',
        4,
        14,
        false
      );
    

      select public."insert_hut_worker"(
        21,
        'hutWorker14@gmail.com',
        '$2b$10$5vl/cD/MG1JgjaiuEy0m0OLZD/DSB9RpW9r/L4IOe683/k/U3ubqi',
        'Siria',
        'Riva',
        4,
        15,
        true
      );
    

      select public."insert_hut_worker"(
        22,
        'hutWorker15@gmail.com',
        '$2b$10$cHG3pTBpmKS9oBxM3Z/uD.8UjDjCm809wZBmsuVmYvRlittOpcDbW',
        'Romana',
        'Acquaviva',
        4,
        16,
        false
      );
    

      select public."insert_hut_worker"(
        23,
        'hutWorker16@gmail.com',
        '$2b$10$A0Dyl6/cKOciiXodhtlMJOQL6WAV3Sfr48lT9mUhEAT/jrmuKGJ.m',
        'Geronimo',
        'Alessandrini',
        4,
        17,
        true
      );
    

      select public."insert_hut_worker"(
        24,
        'hutWorker17@gmail.com',
        '$2b$10$7LuuAXAbs4XqYKkZG9xkMuQhyKgkU7thOQ.lofN./LW8.30ht3Phq',
        'Elia',
        'Atzori',
        4,
        18,
        false
      );
    

      select public."insert_hut_worker"(
        25,
        'hutWorker18@gmail.com',
        '$2b$10$YcmlW61g3vziqfFb7a5rEeov9KlzdaQmFvZ3mri3H9Ehv1JYzJdVS',
        'Eterie',
        'Innocenti',
        4,
        19,
        true
      );
    

      select public."insert_hut_worker"(
        26,
        'hutWorker19@gmail.com',
        '$2b$10$317n.prSz8MmIqiXzmjX8.45lORmzDJ7jUG5o/PNuC0T8OE6kcmbO',
        'Gervasio',
        'Bassani',
        4,
        20,
        false
      );
    

      select public."insert_hut_worker"(
        27,
        'hutWorker20@gmail.com',
        '$2b$10$e8ipiH/lXbXX8cjrPb9FyeA2lyJsWolKwKZJM03kt0KlHVHnO9cUW',
        'Vincenza',
        'Ligorio',
        4,
        21,
        true
      );
    

      select public."insert_hut_worker"(
        28,
        'hutWorker21@gmail.com',
        '$2b$10$lo19vucSibpFH5uYw4jOYOdUMQDWWFU6IHRi0gtZ.jXp8MxI8HyKe',
        'Zama',
        'Fuoco',
        4,
        22,
        false
      );
    

      select public."insert_hut_worker"(
        29,
        'hutWorker22@gmail.com',
        '$2b$10$1bg9f10tPVZm5IV3QxjdCOeTnEdof/c25wt6.n1UrEZgts3Cz/wWC',
        'Selvaggia',
        'Sanfilippo',
        4,
        23,
        true
      );
    

      select public."insert_hut_worker"(
        30,
        'hutWorker23@gmail.com',
        '$2b$10$o6MVAtn4QRumBVizQ5BcHuTv9usjmSbuxjpT8O.EYDUd/SC97Pwya',
        'Zama',
        'Lanza',
        4,
        24,
        false
      );
    

      select public."insert_hut_worker"(
        31,
        'hutWorker24@gmail.com',
        '$2b$10$TrAHmifEa8bkdfhuyLO.L.isaulnAv5FjzWSe4KAeg3D6F3ZlVb5y',
        'Ferruccio',
        'Pintus',
        4,
        25,
        true
      );
    

      select public."insert_hut_worker"(
        32,
        'hutWorker25@gmail.com',
        '$2b$10$n4wngfqkafzb93SI/BZ5u.G7UtbGDMXc0SfNIabXQwXiHQJ7Z62uy',
        'Salomone',
        'Postiglione',
        4,
        26,
        false
      );
    

      select public."insert_hut_worker"(
        33,
        'hutWorker26@gmail.com',
        '$2b$10$M3D4utxzEXCiNMg5mxbsxOmlJDTjsPLkeI3UchKka6u3qyE9je4b2',
        'Amintore',
        'Franzoni',
        4,
        27,
        true
      );
    

      select public."insert_hut_worker"(
        34,
        'hutWorker27@gmail.com',
        '$2b$10$63zot6vK3ov0iLduSRgCjujymaQH9T5AbewXnsFvPmLXDhVBypBwy',
        'Ebe',
        'Cianci',
        4,
        28,
        false
      );
    

      select public."insert_hut_worker"(
        35,
        'hutWorker28@gmail.com',
        '$2b$10$lzopQOkN3P3P0xKDiNNL1.th4Q1HtzSa.zVKR7pySi/54kU6l8xUa',
        'Apollina',
        'Campo',
        4,
        29,
        true
      );
    

      select public."insert_hut_worker"(
        36,
        'hutWorker29@gmail.com',
        '$2b$10$irvk.La83l6fWAQ0JqrXbevCCt3yHEiwYn4oUfaveK2slAxycjCCa',
        'Geltrude',
        'Valente',
        4,
        30,
        false
      );
    

      select public."insert_hut_worker"(
        37,
        'hutWorker30@gmail.com',
        '$2b$10$fFx9TUlK8cxYcBMreWhgeeP9H09xn0/zIw33IBr2DHfiVCEzerILW',
        'Bonifacio',
        'Baroni',
        4,
        31,
        true
      );
    

      select public."insert_hut_worker"(
        38,
        'hutWorker31@gmail.com',
        '$2b$10$w9O66LBmXxC2xd1/.Tvq1Oy3aDIr8X3cfT75FJrJa7qIVXunumd8m',
        'Mirella',
        'Cabras',
        4,
        32,
        false
      );
    

      select public."insert_hut_worker"(
        39,
        'hutWorker32@gmail.com',
        '$2b$10$O/O21tBV8yROT9SPYNu.le3eZeyVIKfjKOG6c6MljPXiY541X4Eku',
        'Ariosto',
        'Mauri',
        4,
        33,
        true
      );
    

      select public."insert_hut_worker"(
        40,
        'hutWorker33@gmail.com',
        '$2b$10$6n3HB.rHaNuwoL98TVzmyefVQxHzDinpcu/UAs7i3G1vg.63VhqIq',
        'Veronica',
        'Fioretti',
        4,
        34,
        false
      );
    

      select public."insert_hut_worker"(
        41,
        'hutWorker34@gmail.com',
        '$2b$10$kRAA1rfV4MN/Ewlfy.dgB.IjEpYstwGiN4wDdA59NcVkwvfHAFP4K',
        'Mamante',
        'Tomasello',
        4,
        35,
        true
      );
    

      select public."insert_hut_worker"(
        42,
        'hutWorker35@gmail.com',
        '$2b$10$52Olc7qQdNXj7okA5iC1POrmg7XdPC12s5FezkYeCqYyEhOJJdLZS',
        'Mimma',
        'Strano',
        4,
        36,
        false
      );
    

      select public."insert_hut_worker"(
        43,
        'hutWorker36@gmail.com',
        '$2b$10$vV7IAJRPstFUOU476/XxhuMIw6XIaLp4Cv/1U2qk.KAnyBpku2YZi',
        'Fiorenza',
        'D''Argenio',
        4,
        37,
        true
      );
    

      select public."insert_hut_worker"(
        44,
        'hutWorker37@gmail.com',
        '$2b$10$//JAXVcyVormriAxpNDUXOAA4Zu2k5vHrUtaMTzkqf2Rij3K5jsB6',
        'Bacco',
        'Fedele',
        4,
        38,
        false
      );
    

      select public."insert_hut_worker"(
        45,
        'hutWorker38@gmail.com',
        '$2b$10$uJU6ZQtH..8RkgQJyXwHMOxpbyx5gdwxLQGahK7.nRxv/4JjFABtq',
        'Decimo',
        'Paola',
        4,
        39,
        true
      );
    

      select public."insert_hut_worker"(
        46,
        'hutWorker39@gmail.com',
        '$2b$10$EGQDyApzkcCTUgH3V1QE7eXHH/ZqWMnqZGvBdzoYyI6hXke83hW26',
        'Elvezio',
        'Prisco',
        4,
        40,
        false
      );
    

      select public."insert_hut_worker"(
        47,
        'hutWorker40@gmail.com',
        '$2b$10$GT8MjEKvjZZym4oDwEUGG.2.h92/elRIsaA11UjJxznKV6C7yxxzi',
        'Erminio',
        'Lo Cascio',
        4,
        41,
        true
      );
    

      select public."insert_hut_worker"(
        48,
        'hutWorker41@gmail.com',
        '$2b$10$AGKYnJ3NeYcgEkSwLOdQQ.Y0UV.i.mMCQ1DbC5j95VwIQXq2Qizs6',
        'Graziana',
        'Genovese',
        4,
        42,
        false
      );
    

      select public."insert_hut_worker"(
        49,
        'hutWorker42@gmail.com',
        '$2b$10$2FaV7P3RMeNnkk/ejfcXW.0tFZXBAOjSTB5AfchYWLLebsAaeb3s6',
        'Roberta',
        'Bortot',
        4,
        43,
        true
      );
    

      select public."insert_hut_worker"(
        50,
        'hutWorker43@gmail.com',
        '$2b$10$0gp5Sk5DOibBSXDRjvQCs.hfUi6DLZucko74aeaH8BcojwYUXNUeC',
        'Addo',
        'Frezza',
        4,
        44,
        false
      );
    

      select public."insert_hut_worker"(
        51,
        'hutWorker44@gmail.com',
        '$2b$10$MZoyWIiLVZt5WkzpP36vx.ixatN0c9XWEYXdJttKxwBUIdsHNp8Gm',
        'Ludovico',
        'Miglio',
        4,
        45,
        true
      );
    

      select public."insert_hut_worker"(
        52,
        'hutWorker45@gmail.com',
        '$2b$10$fSEdaKz27aguB5956ZpAjeM0O6ENOT/N0fN35T/oq1rBu5oUXDhHu',
        'Marinella',
        'Falcone',
        4,
        46,
        false
      );
    

      select public."insert_hut_worker"(
        53,
        'hutWorker46@gmail.com',
        '$2b$10$gePhe1GUQUOu8hxcgg5iEOr7rXsu.YsGzTZapjviD7LQdd9ZSGmYq',
        'Benigna',
        'Iannone',
        4,
        47,
        true
      );
    

      select public."insert_hut_worker"(
        54,
        'hutWorker47@gmail.com',
        '$2b$10$YS3.tmfIuBwgn98RtkDRouYGWP7MhJGb3Hj59SXyRKYH1s6wO3nxu',
        'Zanobi',
        'Savoca',
        4,
        48,
        false
      );
    

      select public."insert_hut_worker"(
        55,
        'hutWorker48@gmail.com',
        '$2b$10$2YLfVIdEqYOESjqwa8pLMukNEsp1wlLbE07zCbdkig.d0cu1hytxa',
        'Livino',
        'Oliva',
        4,
        49,
        true
      );
    

      select public."insert_hut_worker"(
        56,
        'hutWorker49@gmail.com',
        '$2b$10$xyzhOmyfNsf3PeX.Zij.3Oh9zMcQIgwytZjKJ5.lIca7fwguZAM2m',
        'Eracla',
        'Ippoliti',
        4,
        50,
        false
      );
    

      select public."insert_hut_worker"(
        57,
        'hutWorker50@gmail.com',
        '$2b$10$F.zioyhRYcume1.lb5prQOJbbLykLo6z9m6kOb7ASuGhOttD6iwqq',
        'Lodovica',
        'Ghilardi',
        4,
        51,
        true
      );
    

      select public."insert_hut_worker"(
        58,
        'hutWorker51@gmail.com',
        '$2b$10$hYsdWri/QL42wzS0BFi4MusK1gvW9mTjKQx6RYSa/wh5YK4z0UEgm',
        'Siria',
        'Garofalo',
        4,
        52,
        false
      );
    

      select public."insert_hut_worker"(
        59,
        'hutWorker52@gmail.com',
        '$2b$10$cUDPtjxnx/qE3HZWVnpQW.kznoQdsrkZCF1Pwiqb6h6mWNf7XwbE2',
        'Primo',
        'Antonini',
        4,
        53,
        true
      );
    

      select public."insert_hut_worker"(
        60,
        'hutWorker53@gmail.com',
        '$2b$10$gtuBQu7ypmqG80c4gnOvHODxZphwb8U6qawj1u1FsBzL/KWMxW4N2',
        'Giambattista',
        'Filippini',
        4,
        54,
        false
      );
    

      select public."insert_hut_worker"(
        61,
        'hutWorker54@gmail.com',
        '$2b$10$n5DbvsmMNcyEOri9WFubW.CdgwLuT6Fx7Dm5VoGWuG.AiZGtb/zhW',
        'Liboria',
        'Pirrone',
        4,
        55,
        true
      );
    

      select public."insert_hut_worker"(
        62,
        'hutWorker55@gmail.com',
        '$2b$10$wMCakl84ncq5PxLZnwkbZuo7KjmA75mfTejEXuFLpME36W19B.sD6',
        'Zarina',
        'Nava',
        4,
        56,
        false
      );
    

      select public."insert_hut_worker"(
        63,
        'hutWorker56@gmail.com',
        '$2b$10$YQFfJl9y33kwegCy8bANeuAx4iXDt36AhT6ig0MZwMXRAJlGd1kQu',
        'Amabile',
        'Massa',
        4,
        57,
        true
      );
    

      select public."insert_hut_worker"(
        64,
        'hutWorker57@gmail.com',
        '$2b$10$p/kvteDbR1b3ETd742sVnearvz6OQLaconh4lKo/kJ/eRR.F/Tl06',
        'Loreno',
        'Oliveri',
        4,
        58,
        false
      );
    

      select public."insert_hut_worker"(
        65,
        'hutWorker58@gmail.com',
        '$2b$10$ePe4Vrt2UD36axGCNCKkoOFqx9O0sbiHWfGY8YkQXJ40JYkRPJAZy',
        'Flavia',
        'Polverino',
        4,
        59,
        true
      );
    

      select public."insert_hut_worker"(
        66,
        'hutWorker59@gmail.com',
        '$2b$10$nR3V0bpV0WOmpqASdsI54ufVrknpuZSxEiO.OIiiap7pyNVJZrgcS',
        'Donato',
        'Ceccarini',
        4,
        60,
        false
      );
    

      select public."insert_hut_worker"(
        67,
        'hutWorker60@gmail.com',
        '$2b$10$oXFeF8bA/TAZG2LUUSYN8O0KNg/k5vzmMBU/wRkJBHAc7Kl.2i5OG',
        'Mancio',
        'Cammarata',
        4,
        61,
        true
      );
    

      select public."insert_hut_worker"(
        68,
        'hutWorker61@gmail.com',
        '$2b$10$FxqRPpaqPT.DUDtmUKD37.gGhSLl.2Mnh3Rq3m4/0BP.5pFCI5t7i',
        'Otello',
        'Gagliardi',
        4,
        62,
        false
      );
    

      select public."insert_hut_worker"(
        69,
        'hutWorker62@gmail.com',
        '$2b$10$6EJjZZyQZyGIzM9Y7uCjxe3yhsmhoZ10.D6pyliGRQZ9H0sg2SdWW',
        'Tabita',
        'Signorile',
        4,
        63,
        true
      );
    

      select public."insert_hut_worker"(
        70,
        'hutWorker63@gmail.com',
        '$2b$10$V1P5zwdBnmmaRSEH8e.e/.Pz3QeFbc1wAediUuJmNRA1IxmtdSK8e',
        'Iginio',
        'Loiacono',
        4,
        64,
        false
      );
    

      select public."insert_hut_worker"(
        71,
        'hutWorker64@gmail.com',
        '$2b$10$Mr08bBmZPl1oaYg4Gn9JletYESE7Jx5OeJYLd6F63POK7kjnRTQPK',
        'Carola',
        'Pece',
        4,
        65,
        true
      );
    

      select public."insert_hut_worker"(
        72,
        'hutWorker65@gmail.com',
        '$2b$10$ekK.00hUgXygYodAKGAAQORdoObMwFdZbeYttX9CKi0hzZY6mmSqK',
        'Bertolfo',
        'Gigliotti',
        4,
        66,
        false
      );
    

      select public."insert_hut_worker"(
        73,
        'hutWorker66@gmail.com',
        '$2b$10$MNzYyOVYsxt5acsuyM.qyO926Rk.eFhgZzCA5jKtu2o10fsekvHxG',
        'Omar',
        'Barbarossa',
        4,
        67,
        true
      );
    

      select public."insert_hut_worker"(
        74,
        'hutWorker67@gmail.com',
        '$2b$10$mtCFPx.tcRZuaMlfPLB01OtkjOa2LKl0vLc0VAymWbop9Ps3dJT.O',
        'Leandro',
        'Frigo',
        4,
        68,
        false
      );
    

      select public."insert_hut_worker"(
        75,
        'hutWorker68@gmail.com',
        '$2b$10$iyPyGMFccE4XYOplF0H4gev.89q/2XyIazj7TxN4T34.NosX8XXDy',
        'Sabino',
        'Di Lorenzo',
        4,
        69,
        true
      );
    

      select public."insert_hut_worker"(
        76,
        'hutWorker69@gmail.com',
        '$2b$10$nHI38bUvHJPvnrU2KevGTeb77Afg2wxqz4sMctIKbKYyWvgVK4tZu',
        'Cirilla',
        'Santarelli',
        4,
        70,
        false
      );
    

      select public."insert_hut_worker"(
        77,
        'hutWorker70@gmail.com',
        '$2b$10$t6Lq5XJ5QkmsiOTA8xNE2.bu7eFOD.7dxJ6Q.NI733goLkBgUCXpu',
        'Gabino',
        'Polidori',
        4,
        71,
        true
      );
    

      select public."insert_hut_worker"(
        78,
        'hutWorker71@gmail.com',
        '$2b$10$exkV5./jRbzpGOQ2jd3sC.zBrHprdtftjJA9jmQuDJW29IA1wIDUe',
        'Abelardo',
        'Ambrosino',
        4,
        72,
        false
      );
    

      select public."insert_hut_worker"(
        79,
        'hutWorker72@gmail.com',
        '$2b$10$SuRdcYwcpyR9Bdpi8lV24.nCfyW1MoYY/Bv3aI3lDZ8FzrhARDbpu',
        'Abaco',
        'De Vito',
        4,
        73,
        true
      );
    

      select public."insert_hut_worker"(
        80,
        'hutWorker73@gmail.com',
        '$2b$10$otI.lAS./MdndkDpZITmS.JMPOtKN0qCIkIukWBnzuVhcL0EuUiwa',
        'Quintiliano',
        'Coppola',
        4,
        74,
        false
      );
    

      select public."insert_hut_worker"(
        81,
        'hutWorker74@gmail.com',
        '$2b$10$grwC1zdDlrXtT1riqAUZd.CasveTrSJb/h35mfzOuezYqF2C3ah3i',
        'Maffeo',
        'Sorrentino',
        4,
        75,
        true
      );
    

      select public."insert_hut_worker"(
        82,
        'hutWorker75@gmail.com',
        '$2b$10$7lLMWPSbvoxeS1KYM/It5uxtBUKqze6NwpEVWtOfXlscwBxf/WgCe',
        'Tea',
        'Giaccio',
        4,
        76,
        false
      );
    

      select public."insert_hut_worker"(
        83,
        'hutWorker76@gmail.com',
        '$2b$10$IDCtMk1aQDJpn2VfxKwGRuibd5sAPVHNxjC3a2KQi/gFvoJVqPKw.',
        'Imelda',
        'Siri',
        4,
        77,
        true
      );
    

      select public."insert_hut_worker"(
        84,
        'hutWorker77@gmail.com',
        '$2b$10$D4jTZu88L7b8p.1B30A7PesXoOU7HNZ8R2R4Rb7UZncMg056yzR72',
        'Antonia',
        'Stanzione',
        4,
        78,
        false
      );
    

      select public."insert_hut_worker"(
        85,
        'hutWorker78@gmail.com',
        '$2b$10$XpK9fXNyCXf0DCX53PeQ0ui3FgTjDVc6tirgvW/ZMUKJW/Xc8a8t2',
        'Zoe',
        'Guastone',
        4,
        79,
        true
      );
    

      select public."insert_hut_worker"(
        86,
        'hutWorker79@gmail.com',
        '$2b$10$1bQe8hu6UR5uwZPspQXE2.xV5xyHeLT9bOgaRQRsDFylrRjvVnd/q',
        'Monica',
        'Matta',
        4,
        80,
        false
      );
    

      select public."insert_hut_worker"(
        87,
        'hutWorker80@gmail.com',
        '$2b$10$84Y3hRKYAR7C9SXSekiGM.z2O.xSV0wJ..AbNRrjodtiA9r0SWRt.',
        'Giotto',
        'Palombo',
        4,
        81,
        true
      );
    

      select public."insert_hut_worker"(
        88,
        'hutWorker81@gmail.com',
        '$2b$10$cDmQ5/d5IVq.Cup0kWnLRev8VNiIO16kk3wyNZfganPgnZkwHLgSK',
        'Terzo',
        'Benini',
        4,
        82,
        false
      );
    

      select public."insert_hut_worker"(
        89,
        'hutWorker82@gmail.com',
        '$2b$10$jggztkbwh6xezFpyXQE2gOQtkX2LTcNKAAbzKMDLxSqawRQLH0WD.',
        'Capitolina',
        'Bresciani',
        4,
        83,
        true
      );
    

      select public."insert_hut_worker"(
        90,
        'hutWorker83@gmail.com',
        '$2b$10$ruvsOlBgb8Y3mzBPGZs7nOCRiTwkSJiQ.brGPtEESbpLGVVk40t5O',
        'Cesario',
        'Vizziello',
        4,
        84,
        false
      );
    

      select public."insert_hut_worker"(
        91,
        'hutWorker84@gmail.com',
        '$2b$10$F7Vdzb3/kLOnErK6mp97LeXPHm9MQqBNRuSVxwAhhRdGjguD92O9y',
        'Rosa',
        'Rigoni',
        4,
        85,
        true
      );
    

      select public."insert_hut_worker"(
        92,
        'hutWorker85@gmail.com',
        '$2b$10$AFizYjUyKKtRgzbXEzGTl.YRQrgldqh8ltM.FFg.EzRdyug3Q.1mS',
        'Giuseppina',
        'Pandolfi',
        4,
        86,
        false
      );
    

      select public."insert_hut_worker"(
        93,
        'hutWorker86@gmail.com',
        '$2b$10$LAY.I5fqF7pT0YrhbSy/yOjfBC8MkyAIqkVJi8hfltKEij0B74Y56',
        'Crescenzia',
        'Luciani',
        4,
        87,
        true
      );
    

      select public."insert_hut_worker"(
        94,
        'hutWorker87@gmail.com',
        '$2b$10$YroJuaUC9OPbwfx8ygQAVOsAO6/Gz9Nl5V/iFOtI92UXFBJrDKqMS',
        'Turi',
        'Boscolo',
        4,
        88,
        false
      );
    

      select public."insert_hut_worker"(
        95,
        'hutWorker88@gmail.com',
        '$2b$10$2DwkZ8rZ4JkiGqI9FF1D7eTwGQf.hBUFONdJ./6b5AGfqmtrNYTEi',
        'Rosalia',
        'Barberi',
        4,
        89,
        true
      );
    

      select public."insert_hut_worker"(
        96,
        'hutWorker89@gmail.com',
        '$2b$10$Cya0tK43XfSFbBeYOUHXuOW0HEKSYm0uFAPjNIqAlBdy/lv/SwBAS',
        'Bassilla',
        'Rocca',
        4,
        90,
        false
      );
    

      select public."insert_hut_worker"(
        97,
        'hutWorker90@gmail.com',
        '$2b$10$bQ7.ydAyMZzLCFOFM5/ffuGVuXHC5yO3KxasCi3Pr8F/4vZBu8ENG',
        'Scolastica',
        'Mosca',
        4,
        91,
        true
      );
    

      select public."insert_hut_worker"(
        98,
        'hutWorker91@gmail.com',
        '$2b$10$T32qDxXz1g5Z7MbLD2A8HeSMZngzL92Fdmv7rErjauFgkAibnXmwy',
        'Vittoria',
        'Spadoni',
        4,
        92,
        false
      );
    

      select public."insert_hut_worker"(
        99,
        'hutWorker92@gmail.com',
        '$2b$10$NnhDoULv9cV0JZC7r5Ki9eElNx7LApDxgGT7d16OfTIiJMsm6iYHG',
        'Genesia',
        'Montagna',
        4,
        93,
        true
      );
    

      select public."insert_hut_worker"(
        100,
        'hutWorker93@gmail.com',
        '$2b$10$0b5pu.BInN7tzhtqNUv0DekN93gQwSZ9wnXiGIUqbuf4K6QCCkkoK',
        'Rosanna',
        'Olla',
        4,
        94,
        false
      );
    

      select public."insert_hut_worker"(
        101,
        'hutWorker94@gmail.com',
        '$2b$10$9ygCj4NAPpp7uNudTpI3.uVNkurvIIG3MipJge454HmKfpqOLBv4O',
        'Fiorella',
        'Branca',
        4,
        95,
        true
      );
    

      select public."insert_hut_worker"(
        102,
        'hutWorker95@gmail.com',
        '$2b$10$9UQzvCtHz3FprwcIRyGTQ.oFlh5dhYc4DxFLSTh6ZvYl0lDUnUjw.',
        'Giocondo',
        'Forlani',
        4,
        96,
        false
      );
    

      select public."insert_hut_worker"(
        103,
        'hutWorker96@gmail.com',
        '$2b$10$TFhz1cMnWOzJBLNYfpN9j.b6GXAlorWMFB8t6Af7rsX0OqePiNJa.',
        'Gianpaolo',
        'Gamper',
        4,
        97,
        true
      );
    

      select public."insert_hut_worker"(
        104,
        'hutWorker97@gmail.com',
        '$2b$10$q2DwtbbsmOn7GPLsQ4gj/OxynIAG/TNMytqoL6pWx4UC0JiF2o4S2',
        'Perseo',
        'Spinelli',
        4,
        98,
        false
      );
    

      select public."insert_hut_worker"(
        105,
        'hutWorker98@gmail.com',
        '$2b$10$tJ49BkmbF0/W.VrvQyoJTO.agkpTgO0NHhuOI6It1fqNz6iS4yn/W',
        'Brigida',
        'Migliaccio',
        4,
        99,
        true
      );
    

      select public."insert_hut_worker"(
        106,
        'hutWorker99@gmail.com',
        '$2b$10$WA8wRhOG2/kSpbUKvly7SOYnruD41lHvI.aMAXR6KRMWVoUWPXE4S',
        'Corinna',
        'Casano',
        4,
        100,
        false
      );
    

      select public."insert_hut_worker"(
        107,
        'hutWorker100@gmail.com',
        '$2b$10$/RLibOjBvxYDwanmcz/diOCJB3aRU4chBvksfKzgsXvb11uoiPUVu',
        'Ausilia',
        'Pagani',
        4,
        101,
        true
      );
    

      select public."insert_hut_worker"(
        108,
        'hutWorker101@gmail.com',
        '$2b$10$Zec/ejv8w5ubBkQUEoSMQeKvLXpanbGpTirTdTyHaQmL3KhSwHldm',
        'Adelaide',
        'Ruggiero',
        4,
        102,
        false
      );
    

      select public."insert_hut_worker"(
        109,
        'hutWorker102@gmail.com',
        '$2b$10$1ekvbIqZ7BO5ZHFDmHDLVuV6z4YgvYEoORBDSu1FJO8jP3tlrs11C',
        'Onorino',
        'Cesaretti',
        4,
        103,
        true
      );
    

      select public."insert_hut_worker"(
        110,
        'hutWorker103@gmail.com',
        '$2b$10$aThM3YxPC8mmXVjAN5ukYOvaCjBM0lpdJXfbQcDeIeQZC84m1USlK',
        'Antonello',
        'Marciano',
        4,
        104,
        false
      );
    

      select public."insert_hut_worker"(
        111,
        'hutWorker104@gmail.com',
        '$2b$10$ij8PFgmvKtgcvEqD.sNR5.kH/BFJtuzy73dcZwQApOt.QswavswLy',
        'Luce',
        'Mingarelli',
        4,
        105,
        true
      );
    

      select public."insert_hut_worker"(
        112,
        'hutWorker105@gmail.com',
        '$2b$10$Y8tplQo/3PpQ1ZIuFVKl1uh7kAoeIeimbsjXuL5obwRAAvLMMFOJ2',
        'Venera',
        'Malerba',
        4,
        106,
        false
      );
    

      select public."insert_hut_worker"(
        113,
        'hutWorker106@gmail.com',
        '$2b$10$SmX7HumQKOjlPbzU1aw96OyZK5/Us0ThbPwrjpWIKLmxjHDvFdSoO',
        'Dolores',
        'Giannetti',
        4,
        107,
        true
      );
    

      select public."insert_hut_worker"(
        114,
        'hutWorker107@gmail.com',
        '$2b$10$Bf.jrYqTFD2F5h66/AyH8O96tHm.L.thx38.UkrNnsZhtMlb7o54m',
        'Lodovico',
        'Lombardo',
        4,
        108,
        false
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '23 Piazza Valentino, Settimo Zaccheo calabro, Italy',
        'Settimo Zaccheo calabro',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        214,
        '271 Strada Bonifazi, Ragone a mare, Italy',
        'Ragone a mare',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        154,
        '5 Contrada Marotta, Palladio ligure, Italy',
        'Palladio ligure',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        163,
        '0 Via Feleppa, Settimo Vidiano umbro, Italy',
        'Settimo Vidiano umbro',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        183,
        '191 Piazza Menozzi, Quarto Tiburzio, Italy',
        'Quarto Tiburzio',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        66,
        '4 Contrada Manzi, Marsella nell''emilia, Italy',
        'Marsella nell''emilia',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        228,
        '793 Borgo Fadda, Quarto Alvise sardo, Italy',
        'Quarto Alvise sardo',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        44,
        '109 Rotonda Fatima, Marciano umbro, Italy',
        'Marciano umbro',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        194,
        '9 Strada Finotti, Quarto Italia umbro, Italy',
        'Quarto Italia umbro',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        285,
        '0 Via Vaccaro, Ansovino veneto, Italy',
        'Ansovino veneto',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        56,
        '235 Piazza Marian, Testa a mare, Italy',
        'Testa a mare',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        150,
        '4 Borgo Liverani, Viliana ligure, Italy',
        'Viliana ligure',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        173,
        '00 Rotonda Teresa, Massari lido, Italy',
        'Massari lido',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        211,
        '1 Borgo Salvo, Settimo Livia, Italy',
        'Settimo Livia',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        60,
        '344 Contrada Gabriele, Iginia del friuli, Italy',
        'Iginia del friuli',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        300,
        '29 Via Stefania, Bambina nell''emilia, Italy',
        'Bambina nell''emilia',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        137,
        '03 Contrada Giacalone, Casula nell''emilia, Italy',
        'Casula nell''emilia',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        124,
        '753 Contrada Noemi, Quarto Alberta veneto, Italy',
        'Quarto Alberta veneto',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        157,
        '3 Incrocio Ferrero, San Menardo sardo, Italy',
        'San Menardo sardo',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        148,
        '6 Piazza Tristano, Duilio terme, Italy',
        'Duilio terme',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        110,
        '93 Incrocio Cellini, Cipolla del friuli, Italy',
        'Cipolla del friuli',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        139,
        '7 Contrada Incoronata, Visconti veneto, Italy',
        'Visconti veneto',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '1 Via Eleonora, Bianchi ligure, Italy',
        'Bianchi ligure',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        71,
        '397 Contrada Vichi, Borgo Germana nell''emilia, Italy',
        'Borgo Germana nell''emilia',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        33,
        '709 Via Barbato, Azara salentino, Italy',
        'Azara salentino',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        156,
        '092 Piazza Catarsi, San Teresa terme, Italy',
        'San Teresa terme',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        59,
        '137 Incrocio Ivone, Settimo Petronilla, Italy',
        'Settimo Petronilla',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        287,
        '339 Piazza Antino, Addolorata ligure, Italy',
        'Addolorata ligure',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        192,
        '51 Rotonda Ermenegarda, Borgo Prudenzio, Italy',
        'Borgo Prudenzio',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        158,
        '0 Contrada Alessi, Ottonello laziale, Italy',
        'Ottonello laziale',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        97,
        '68 Via Locci, San Gumesindo terme, Italy',
        'San Gumesindo terme',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        147,
        '7 Rotonda Alessia, Gualtieri nell''emilia, Italy',
        'Gualtieri nell''emilia',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        108,
        '1 Via Desiderato, Settimo Letizia, Italy',
        'Settimo Letizia',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '5 Piazza Siricio, Lotito a mare, Italy',
        'Lotito a mare',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        219,
        '660 Rotonda Tagliabue, Borgo Goffredo, Italy',
        'Borgo Goffredo',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        267,
        '3 Rotonda Lotti, Cataldo terme, Italy',
        'Cataldo terme',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        44,
        '361 Via Izzi, Alessi lido, Italy',
        'Alessi lido',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        58,
        '9 Via Cipolla, Quarto Benedetta, Italy',
        'Quarto Benedetta',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        71,
        '77 Contrada Buccheri, Settimo Mansueto umbro, Italy',
        'Settimo Mansueto umbro',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        148,
        '744 Via Rodolfo, Ercoli veneto, Italy',
        'Ercoli veneto',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '5 Via Nives, Sesto Cleopatra laziale, Italy',
        'Sesto Cleopatra laziale',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        250,
        '1 Rotonda Urbano, San Ladislao umbro, Italy',
        'San Ladislao umbro',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        39,
        '6 Borgo Toto, Sesto Cleopatra, Italy',
        'Sesto Cleopatra',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        69,
        '219 Incrocio Leopardi, Settimo Renata veneto, Italy',
        'Settimo Renata veneto',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        116,
        '6 Via Alcamo, Borgo Remondo salentino, Italy',
        'Borgo Remondo salentino',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        175,
        '9 Piazza Ildefonso, San Ionne, Italy',
        'San Ionne',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        122,
        '901 Rotonda Toscano, Crescenzia a mare, Italy',
        'Crescenzia a mare',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        157,
        '5 Piazza Oliviera, Salemi umbro, Italy',
        'Salemi umbro',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        255,
        '34 Borgo Giannone, Quarto Gioia, Italy',
        'Quarto Gioia',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        174,
        '376 Incrocio Uranio, Croce a mare, Italy',
        'Croce a mare',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        64,
        '281 Strada Carlucci, Marino salentino, Italy',
        'Marino salentino',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '9 Contrada Ferraiuolo, Borgo Mariella umbro, Italy',
        'Borgo Mariella umbro',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        57,
        '239 Rotonda Venerio, Quarto Alina, Italy',
        'Quarto Alina',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '363 Incrocio Donata, Quarto Rainelda sardo, Italy',
        'Quarto Rainelda sardo',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        295,
        '765 Incrocio Ermenegildo, Borgo Venusta, Italy',
        'Borgo Venusta',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        75,
        '958 Incrocio Celso, Lazzarini a mare, Italy',
        'Lazzarini a mare',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        214,
        '11 Piazza Adelasia, Borgo Tancredi del friuli, Italy',
        'Borgo Tancredi del friuli',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        263,
        '30 Borgo Pascarella, Sesto Romilda sardo, Italy',
        'Sesto Romilda sardo',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        210,
        '180 Strada Poggi, San Isaia, Italy',
        'San Isaia',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        178,
        '081 Contrada Adele, Settimo Igino laziale, Italy',
        'Settimo Igino laziale',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        116,
        '2 Incrocio Maltese, Perna laziale, Italy',
        'Perna laziale',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        106,
        '94 Contrada Greco, San Ghita nell''emilia, Italy',
        'San Ghita nell''emilia',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        223,
        '66 Strada Mangano, La Rosa sardo, Italy',
        'La Rosa sardo',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        244,
        '94 Strada Aida, Pichler lido, Italy',
        'Pichler lido',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        40,
        '515 Incrocio Cucciniello, Raniero del friuli, Italy',
        'Raniero del friuli',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        213,
        '123 Contrada Cesaretti, Borgo Alfio terme, Italy',
        'Borgo Alfio terme',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        238,
        '51 Piazza Lonardi, Livia a mare, Italy',
        'Livia a mare',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        72,
        '144 Incrocio Carponio, Quarto Baldomero, Italy',
        'Quarto Baldomero',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        231,
        '28 Incrocio Anna, Borgo Godiva calabro, Italy',
        'Borgo Godiva calabro',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '9 Contrada Lombardini, Dulina laziale, Italy',
        'Dulina laziale',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        95,
        '1 Via Nerea, Barnaba salentino, Italy',
        'Barnaba salentino',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        221,
        '33 Strada Grillo, Alcibiade salentino, Italy',
        'Alcibiade salentino',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        115,
        '21 Borgo Cascio, Quarto Felicita calabro, Italy',
        'Quarto Felicita calabro',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        295,
        '19 Borgo Zanetti, Borgo Isa, Italy',
        'Borgo Isa',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        36,
        '1 Contrada Adelmo, Lavinio veneto, Italy',
        'Lavinio veneto',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        77,
        '6 Strada Coniglio, Borgo Verecondo ligure, Italy',
        'Borgo Verecondo ligure',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        178,
        '06 Via Corinna, Eulalia umbro, Italy',
        'Eulalia umbro',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        30,
        '662 Via Olinda, Prospera lido, Italy',
        'Prospera lido',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        242,
        '37 Piazza Passeri, Quarto Concetto nell''emilia, Italy',
        'Quarto Concetto nell''emilia',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        28,
        '275 Rotonda Stella, San Melchiorre, Italy',
        'San Melchiorre',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        148,
        '994 Rotonda Elia, Settimo Aresio, Italy',
        'Settimo Aresio',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        152,
        '5 Borgo Bassi, San Corbiniano, Italy',
        'San Corbiniano',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        273,
        '89 Piazza Ledda, Sesto Raffaele, Italy',
        'Sesto Raffaele',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        278,
        '087 Rotonda Mottola, Settimo Giordano nell''emilia, Italy',
        'Settimo Giordano nell''emilia',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        108,
        '86 Incrocio Polizzi, Benvenuto terme, Italy',
        'Benvenuto terme',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        193,
        '336 Via Ivano, Settimo Orsino salentino, Italy',
        'Settimo Orsino salentino',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        275,
        '585 Borgo Puccio, Diodata sardo, Italy',
        'Diodata sardo',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        76,
        '929 Rotonda Campagna, San Clemente a mare, Italy',
        'San Clemente a mare',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        177,
        '8 Contrada Manca, Vicari del friuli, Italy',
        'Vicari del friuli',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        97,
        '902 Via Ernesta, San Gioia calabro, Italy',
        'San Gioia calabro',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        63,
        '22 Strada Baldassarre, Martorana umbro, Italy',
        'Martorana umbro',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        141,
        '944 Borgo Azelio, Quarto Nicoletta, Italy',
        'Quarto Nicoletta',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        74,
        '238 Piazza Piazza, Borgo Iago calabro, Italy',
        'Borgo Iago calabro',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        83,
        '8 Contrada Dante, Romano calabro, Italy',
        'Romano calabro',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        234,
        '124 Contrada Liliana, Recchia calabro, Italy',
        'Recchia calabro',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        220,
        '633 Strada Mercurio, Quarto Gualtiero calabro, Italy',
        'Quarto Gualtiero calabro',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        196,
        '26 Borgo Orsini, Sesto Orsolina, Italy',
        'Sesto Orsolina',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        54,
        '7 Rotonda Cherubino, San Sico, Italy',
        'San Sico',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        43,
        '265 Contrada Davide, Borgo Baldo, Italy',
        'Borgo Baldo',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        233,
        '571 Piazza Tiziano, Sesto Ticone, Italy',
        'Sesto Ticone',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        221,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        182,
        '3 Contrada Macario, Giordano nell''emilia, Italy',
        'Giordano nell''emilia',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        47,
        '51 Piazza Liccardo, Ettore calabro, Italy',
        'Ettore calabro',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        143,
        '5 Borgo Guerrino, Borgo Gherardo, Italy',
        'Borgo Gherardo',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        62,
        '4 Borgo Doroteo, Cozzi a mare, Italy',
        'Cozzi a mare',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        137,
        '01 Borgo Inzerillo, Giansante veneto, Italy',
        'Giansante veneto',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        276,
        '7 Via Nardi, Settimo Liberto, Italy',
        'Settimo Liberto',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        291,
        '791 Incrocio Senatore, Borgo Clarenzio sardo, Italy',
        'Borgo Clarenzio sardo',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        168,
        '40 Via Guastone, Sesto Ataleo umbro, Italy',
        'Sesto Ataleo umbro',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        269,
        '6 Contrada Renzo, Quarto Gioacchina, Italy',
        'Quarto Gioacchina',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        29,
        '0 Rotonda Di Maro, Sirio a mare, Italy',
        'Sirio a mare',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        99,
        '79 Piazza Spanò, Sesto Elifio, Italy',
        'Sesto Elifio',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        162,
        '1 Incrocio Battista, Paolino laziale, Italy',
        'Paolino laziale',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        288,
        '935 Via Biondi, Castellani veneto, Italy',
        'Castellani veneto',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        53,
        '4 Contrada Secondina, Quinzio ligure, Italy',
        'Quinzio ligure',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        228,
        '67 Piazza Pagliai, Settimo Germano, Italy',
        'Settimo Germano',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        36,
        '8 Incrocio Manilio, Settimo Ugolino, Italy',
        'Settimo Ugolino',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        108,
        '73 Piazza Benedetto, Irma terme, Italy',
        'Irma terme',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        271,
        '38 Contrada Guidetti, Scarpa terme, Italy',
        'Scarpa terme',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        260,
        '23 Piazza Lorenza, Tavani sardo, Italy',
        'Tavani sardo',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        255,
        '40 Strada Olimpio, Famiano lido, Italy',
        'Famiano lido',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        144,
        '719 Contrada Comito, Orlando salentino, Italy',
        'Orlando salentino',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        151,
        '727 Contrada Noto, San Donna a mare, Italy',
        'San Donna a mare',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        139,
        '000 Incrocio Venturini, Amerigo ligure, Italy',
        'Amerigo ligure',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        236,
        '210 Incrocio Zumbo, Settimo Amadeo, Italy',
        'Settimo Amadeo',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        76,
        '4 Piazza Isabella, Merli ligure, Italy',
        'Merli ligure',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '9 Via Flaviano, Settimo Clodoveo, Italy',
        'Settimo Clodoveo',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        212,
        '4 Incrocio Rondinone, Borgo Asterio laziale, Italy',
        'Borgo Asterio laziale',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        110,
        '8 Strada Moira, Borgo Babila, Italy',
        'Borgo Babila',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '2 Strada Cipriano, San Lorena ligure, Italy',
        'San Lorena ligure',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '195 Incrocio Amata, Ferluga calabro, Italy',
        'Ferluga calabro',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        274,
        '849 Via Batilda, Borgo Senofonte, Italy',
        'Borgo Senofonte',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        139,
        '412 Borgo Mauro, Batilda salentino, Italy',
        'Batilda salentino',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        178,
        '0 Piazza Patrizia, Sesto Berengario veneto, Italy',
        'Sesto Berengario veneto',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        198,
        '40 Rotonda Malco, Settimo Amalia veneto, Italy',
        'Settimo Amalia veneto',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        154,
        '3 Piazza Tirri, Marina salentino, Italy',
        'Marina salentino',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '63 Piazza Daidone, Carè terme, Italy',
        'Carè terme',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '48 Via Gaddini, Borgo Asella salentino, Italy',
        'Borgo Asella salentino',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        133,
        '566 Strada Servidio, Satta del friuli, Italy',
        'Satta del friuli',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '9 Borgo Ausilia, Quarto Severa, Italy',
        'Quarto Severa',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        225,
        '06 Piazza Storti, Bruno sardo, Italy',
        'Bruno sardo',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        242,
        '634 Via Graziano, Orenzio calabro, Italy',
        'Orenzio calabro',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        158,
        '122 Borgo Castelli, Quarto Verecondo lido, Italy',
        'Quarto Verecondo lido',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        221,
        '025 Strada Adriano, Zennaro terme, Italy',
        'Zennaro terme',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        241,
        '3 Borgo Camillo, Marras lido, Italy',
        'Marras lido',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        283,
        '506 Incrocio Carrozzo, Fidenzio terme, Italy',
        'Fidenzio terme',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        156,
        '68 Piazza Aristide, Quarto Amleto, Italy',
        'Quarto Amleto',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        262,
        '012 Rotonda Barberis, Zucca umbro, Italy',
        'Zucca umbro',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        228,
        '2 Incrocio Vittori, Quarto Achille del friuli, Italy',
        'Quarto Achille del friuli',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        204,
        '80 Strada Drago, Giorgio veneto, Italy',
        'Giorgio veneto',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        175,
        '1 Incrocio Librizzi, Gangemi calabro, Italy',
        'Gangemi calabro',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        251,
        '6 Incrocio Benigna, Settimo Emmerico, Italy',
        'Settimo Emmerico',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        112,
        '617 Strada Edvige, Lo Iacono lido, Italy',
        'Lo Iacono lido',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        102,
        '81 Incrocio Corrado, Quarto Benigno calabro, Italy',
        'Quarto Benigno calabro',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        213,
        '20 Rotonda Giannetti, Bianchi umbro, Italy',
        'Bianchi umbro',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        73,
        '605 Rotonda Ciuffreda, Macchi laziale, Italy',
        'Macchi laziale',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        214,
        '2 Strada Sebastiano, Settimo Varo, Italy',
        'Settimo Varo',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        164,
        '08 Incrocio Porziano, Sesto Gionata veneto, Italy',
        'Sesto Gionata veneto',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        196,
        '75 Piazza Amanzio, Quarto Agrippa, Italy',
        'Quarto Agrippa',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        300,
        '60 Borgo Aniello, San Robaldo nell''emilia, Italy',
        'San Robaldo nell''emilia',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        175,
        '69 Via Ottaviani, Settimo Marianna, Italy',
        'Settimo Marianna',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        288,
        '18 Piazza Cappelli, Rosa salentino, Italy',
        'Rosa salentino',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        102,
        '179 Via Aris, Sesto Ilario nell''emilia, Italy',
        'Sesto Ilario nell''emilia',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        71,
        '51 Incrocio Urso, Borgo Isacco lido, Italy',
        'Borgo Isacco lido',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        98,
        '342 Contrada Bianca, Fava terme, Italy',
        'Fava terme',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '95 Strada Pitzalis, Mazzone a mare, Italy',
        'Mazzone a mare',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        161,
        '386 Via Estella, Dagoberto salentino, Italy',
        'Dagoberto salentino',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        109,
        '2 Rotonda Isidoro, Sesto Elogio laziale, Italy',
        'Sesto Elogio laziale',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        268,
        '468 Contrada Daniela, Borgo Costante nell''emilia, Italy',
        'Borgo Costante nell''emilia',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        114,
        '4 Rotonda Villari, Settimo Dorotea calabro, Italy',
        'Settimo Dorotea calabro',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        99,
        '946 Strada Cavallari, Settimo Alina nell''emilia, Italy',
        'Settimo Alina nell''emilia',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        241,
        '7 Piazza Baldo, Dario ligure, Italy',
        'Dario ligure',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        214,
        '03 Borgo Longhi, Borgo Bonito nell''emilia, Italy',
        'Borgo Bonito nell''emilia',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        126,
        '560 Via Cirilla, Sammartino del friuli, Italy',
        'Sammartino del friuli',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        168,
        '1 Piazza Provenzano, Settimo Ludano, Italy',
        'Settimo Ludano',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        150,
        '79 Rotonda Frau, Borgo Ionne, Italy',
        'Borgo Ionne',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        87,
        '91 Borgo Giove, Sesto Ecclesio, Italy',
        'Sesto Ecclesio',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        31,
        '68 Borgo Bacco, Bindi a mare, Italy',
        'Bindi a mare',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        37,
        '1 Borgo Ferroni, Gonerio salentino, Italy',
        'Gonerio salentino',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        209,
        '399 Incrocio Schiavo, Sesto Colmazio nell''emilia, Italy',
        'Sesto Colmazio nell''emilia',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        197,
        '87 Strada Paolo, Asdrubale calabro, Italy',
        'Asdrubale calabro',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        111,
        '901 Borgo Adelasia, Emiliana sardo, Italy',
        'Emiliana sardo',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '2 Piazza Sarti, Brunilde lido, Italy',
        'Brunilde lido',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        196,
        '489 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        87,
        '734 Rotonda Olivi, San Veridiana sardo, Italy',
        'San Veridiana sardo',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        250,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        55,
        '292 Strada Omar, San Gianluca a mare, Italy',
        'San Gianluca a mare',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        267,
        '559 Incrocio Bartolo, Borgo Furseo nell''emilia, Italy',
        'Borgo Furseo nell''emilia',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        83,
        '9 Borgo Mastroianni, Settimo Isa terme, Italy',
        'Settimo Isa terme',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        154,
        '360 Strada Milan, Oggiano ligure, Italy',
        'Oggiano ligure',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        39,
        '00 Rotonda Euclide, San Regolo, Italy',
        'San Regolo',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        36,
        '902 Contrada Perra, Sebastiana nell''emilia, Italy',
        'Sebastiana nell''emilia',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        173,
        '32 Rotonda Iandolo, Settimo Ugolino, Italy',
        'Settimo Ugolino',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        149,
        '4 Borgo Biagini, Mautone nell''emilia, Italy',
        'Mautone nell''emilia',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        52,
        '17 Borgo Aldo, Moreno salentino, Italy',
        'Moreno salentino',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        184,
        '22 Incrocio Tarso, Cifarelli laziale, Italy',
        'Cifarelli laziale',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        292,
        '974 Strada Melchiade, Alviero del friuli, Italy',
        'Alviero del friuli',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        84,
        '00 Rotonda Sirio, Sesto Irene veneto, Italy',
        'Sesto Irene veneto',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        180,
        '3 Borgo Annibale, Sesto Fedora, Italy',
        'Sesto Fedora',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        176,
        '056 Contrada Marzi, Quarto Fortunata, Italy',
        'Quarto Fortunata',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        37,
        '595 Strada Grosso, Settimo Gianmarco a mare, Italy',
        'Settimo Gianmarco a mare',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        128,
        '57 Strada Giudice, Mora veneto, Italy',
        'Mora veneto',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '6 Incrocio Gioele, Evremondo ligure, Italy',
        'Evremondo ligure',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        113,
        '74 Via Valentina, Borgo Eriberto sardo, Italy',
        'Borgo Eriberto sardo',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        40,
        '097 Strada Alaimo, Settimo Didimo, Italy',
        'Settimo Didimo',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        206,
        '4 Incrocio Carbon, Eliano umbro, Italy',
        'Eliano umbro',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        108,
        '362 Rotonda Pelagia, Borgo Agostina sardo, Italy',
        'Borgo Agostina sardo',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        209,
        '083 Piazza Ruggeri, La Porta del friuli, Italy',
        'La Porta del friuli',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        41,
        '15 Strada Pasquali, San Orsola terme, Italy',
        'San Orsola terme',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        110,
        '544 Contrada Loiacono, San Isidora lido, Italy',
        'San Isidora lido',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        247,
        '891 Incrocio Giuseppe, Settimo Alma ligure, Italy',
        'Settimo Alma ligure',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        72,
        '831 Borgo Fleano, Sesto Fiorenzo del friuli, Italy',
        'Sesto Fiorenzo del friuli',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '7 Piazza Martelli, Quarto Fosco calabro, Italy',
        'Quarto Fosco calabro',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        216,
        '13 Contrada Uriele, Vanessa terme, Italy',
        'Vanessa terme',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        64,
        '6 Strada Aquilino, Sesto Damaso salentino, Italy',
        'Sesto Damaso salentino',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        50,
        '22 Via Venanzio, Angelica umbro, Italy',
        'Angelica umbro',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        55,
        '8 Contrada Cruciani, Settimo Alamanno, Italy',
        'Settimo Alamanno',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        52,
        '168 Incrocio Ivone, Pichler salentino, Italy',
        'Pichler salentino',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        252,
        '3 Incrocio Daniele, Aleramo salentino, Italy',
        'Aleramo salentino',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        258,
        '358 Contrada Edilberto, Cassio lido, Italy',
        'Cassio lido',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        166,
        '0 Rotonda Cornelia, San Maddalena lido, Italy',
        'San Maddalena lido',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '4 Via Gerasimo, Quarto Afro umbro, Italy',
        'Quarto Afro umbro',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        109,
        '912 Via D''Aleo, Pugliesi ligure, Italy',
        'Pugliesi ligure',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        151,
        '9 Borgo Paolo, Quarto Egidio lido, Italy',
        'Quarto Egidio lido',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        243,
        '9 Rotonda Alma, Montanari laziale, Italy',
        'Montanari laziale',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        208,
        '596 Contrada Venusto, San Filomeno veneto, Italy',
        'San Filomeno veneto',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        258,
        '62 Incrocio Iazzetta, Leo a mare, Italy',
        'Leo a mare',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        242,
        '4 Borgo Cinzia, Cunegonda a mare, Italy',
        'Cunegonda a mare',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        126,
        '97 Borgo Elsa, San Consolata nell''emilia, Italy',
        'San Consolata nell''emilia',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        133,
        '914 Incrocio Violi, Stefania nell''emilia, Italy',
        'Stefania nell''emilia',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        292,
        '2 Contrada Cantoni, Vittoriano umbro, Italy',
        'Vittoriano umbro',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        149,
        '183 Borgo Caio, Piana umbro, Italy',
        'Piana umbro',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        41,
        '3 Strada Pagliuca, Borgo Fiorenziano, Italy',
        'Borgo Fiorenziano',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        127,
        '35 Contrada Brunilde, San Alessandro del friuli, Italy',
        'San Alessandro del friuli',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        101,
        '8 Rotonda Onorio, Erardo laziale, Italy',
        'Erardo laziale',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        111,
        '279 Contrada Flora, Genesia sardo, Italy',
        'Genesia sardo',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        152,
        '43 Contrada Roberto, Gillo veneto, Italy',
        'Gillo veneto',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        99,
        '02 Borgo Galante, Costante salentino, Italy',
        'Costante salentino',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        257,
        '663 Contrada Mancini, Quarto Antea sardo, Italy',
        'Quarto Antea sardo',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        54,
        '677 Borgo Zani, San Enecone, Italy',
        'San Enecone',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        175,
        '705 Borgo Paoletti, Settimo Giliola, Italy',
        'Settimo Giliola',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        106,
        '38 Rotonda Desiderata, Calogera veneto, Italy',
        'Calogera veneto',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        96,
        '173 Incrocio Sara, Quarto Eligio umbro, Italy',
        'Quarto Eligio umbro',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        43,
        '66 Incrocio Francesca, Sesto Radolfo, Italy',
        'Sesto Radolfo',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        109,
        '2 Incrocio Di Giuseppe, Zennaro lido, Italy',
        'Zennaro lido',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        131,
        '3 Contrada Mauro, Fabbri laziale, Italy',
        'Fabbri laziale',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        113,
        '45 Incrocio Taziana, San Tullia, Italy',
        'San Tullia',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        213,
        '517 Strada Trapani, Reginaldo sardo, Italy',
        'Reginaldo sardo',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        44,
        '9 Rotonda Favaro, Settimo Cordelia, Italy',
        'Settimo Cordelia',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '0 Rotonda Belvisi, Omar salentino, Italy',
        'Omar salentino',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        104,
        '62 Strada Piccoli, Militello a mare, Italy',
        'Militello a mare',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        38,
        '89 Piazza Antigone, Baldo terme, Italy',
        'Baldo terme',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        35,
        '5 Rotonda Samona, San Vittoriano, Italy',
        'San Vittoriano',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        264,
        '624 Piazza Motta, Borgo Concordio terme, Italy',
        'Borgo Concordio terme',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        188,
        '80 Incrocio Amilcare, San Zabina laziale, Italy',
        'San Zabina laziale',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        214,
        '6 Incrocio Amerio, Quarto Cino, Italy',
        'Quarto Cino',
        'Italy',
        'Aosta',
        ''
      );
    
  