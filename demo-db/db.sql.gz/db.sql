--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: insert_hike(integer, character varying, integer, character varying, character varying, character varying, character varying, character varying, numeric, numeric, integer, character varying, jsonb, jsonb, jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hike(user_id integer, title character varying, difficulty integer, gpx_path character varying, country character varying, region character varying, province character varying, city character varying, length numeric, ascent numeric, expected_time integer, description character varying, pictures jsonb, start_point jsonb, end_point jsonb, reference_points jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $$;


--
-- Name: insert_hut(integer, double precision, double precision, integer, numeric, character varying, character varying, character varying, character varying, numeric, time without time zone, time without time zone, character varying, character varying, jsonb, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut(user_id integer, lat double precision, lon double precision, number_of_beds integer, price numeric, title character varying, address character varying, owner_name character varying, website character varying, elevation numeric, working_time_start time without time zone, working_time_end time without time zone, email character varying, phone_number character varying, pictures jsonb, description character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber",
      "pictures",
      "description"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number,
      pictures,
      description
    );
    END
    $$;


--
-- Name: insert_hut_worker(integer, character varying, character varying, character varying, character varying, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut_worker(hwid integer, email character varying, password character varying, first_name character varying, last_name character varying, role integer, hut_id integer, approved boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$
      DECLARE
        user_id integer;
      BEGIN
      INSERT INTO "public"."users" (
        "id",
        "email",
        "password",
        "firstName",
        "lastName",
        "role",
        "verified",
        "approved"
      ) VALUES(
        hwid, email, password, first_name, last_name, role, true, approved
      ) returning id into user_id;

      INSERT INTO "public"."hut-worker" (
        "userId",
        "hutId"
      ) VALUES ( user_id, hut_id);
      END
      $$;


--
-- Name: insert_parking_lot(integer, double precision, double precision, character varying, integer, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_parking_lot(user_id integer, lat double precision, lon double precision, name character varying, max_cars integer, address character varying, city character varying, country character varying, region character varying, province character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: code-hike; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."code-hike" (code, "userHikeId") FROM stdin;
\.


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
1	1	0	5
1	2	100000	6
1	3	1	3
1	4	2	3
2	5	0	5
2	6	100000	6
3	7	0	5
3	8	100000	6
4	9	0	5
4	10	100000	6
5	11	0	5
5	12	100000	6
6	13	0	5
6	14	100000	6
7	15	0	5
7	16	100000	6
8	17	0	5
8	18	100000	6
8	19	1	3
8	20	2	3
9	21	0	5
9	22	100000	6
10	23	0	5
10	24	100000	6
11	25	0	5
11	26	100000	6
12	27	0	5
12	28	100000	6
13	29	0	5
13	30	100000	6
14	31	0	5
14	32	100000	6
15	33	0	5
15	34	100000	6
16	35	0	5
16	36	100000	6
17	37	0	5
17	38	100000	6
18	39	0	5
18	40	100000	6
19	41	0	5
19	42	100000	6
20	43	0	5
20	44	100000	6
21	45	0	5
21	46	100000	6
22	47	0	5
22	48	100000	6
23	49	0	5
23	50	100000	6
23	51	1	3
23	52	2	3
24	53	0	5
24	54	100000	6
25	55	0	5
25	56	100000	6
26	57	0	5
26	58	100000	6
27	59	0	5
27	60	100000	6
28	61	0	5
28	62	100000	6
29	63	0	5
29	64	100000	6
30	65	0	5
30	66	100000	6
30	67	1	3
30	68	2	3
30	69	3	3
31	70	0	5
31	71	100000	6
32	72	0	5
32	73	100000	6
33	74	0	5
33	75	100000	6
34	76	0	5
34	77	100000	6
35	78	0	5
35	79	100000	6
36	80	0	5
36	81	100000	6
37	82	0	5
37	83	100000	6
38	84	0	5
38	85	100000	6
38	86	1	3
38	87	2	3
39	88	0	5
39	89	100000	6
40	90	0	5
40	91	100000	6
41	92	0	5
41	93	100000	6
42	94	0	5
42	95	100000	6
43	96	0	5
43	97	100000	6
44	98	0	5
44	99	100000	6
45	100	0	5
45	101	100000	6
46	102	0	5
46	103	100000	6
46	104	1	3
46	105	2	3
47	106	0	5
47	107	100000	6
48	108	0	5
48	109	100000	6
49	110	0	5
49	111	100000	6
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country, condition, cause, pictures, "weatherStatus", "weatherDescription") FROM stdin;
1	2	0.70	80	29.90	2	Amprimo	Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.	/static/gpx/Amprimo.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/3.jpg"]	0	
2	2	10.50	200	8.00	1	Anello Chateau Beaulard - Cotolivier - Vazon	Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.	/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx	0.00	Piemonte	Torino	Beaulard	Italia	0		["/static/images/2.jpg"]	0	
3	2	5387.07	150	955.10	1	borgata ruà a cima di crosa	Raggiungi la partenza del Sentiero per la Cima di Crosa impostando sul navigatore “Borgata Ruà – Becetto“.\n\nParcheggiata la macchina a Borgata Ruà (o se impossibilitati a trovare un parcheggio anche a Becetto, allungando di 10 minuti il giro), si prende il sentiero sulla sinistra, nei pressi di una cartina (INDICAZIONI CIMA DI CROSA).	/static/gpx/Borgata Ruà-Cima di Crosa (1).gpx	0.00	Piemonte	Cuneo	Sampeyre	Italia	0		["/static/images/46.jpg"]	0	
4	2	3622.32	130	865.20	2	Colle della Gianna da Pian della Regina	Colle della Gianna at an altitude of approximately 2530m connects the Po Valley to the Pellice Valley allowing you to reach the Barbara Lowrie refuge, an ideal base for multi-day crossings.\n\nIt is advisable to carefully consult the weather forecasts especially for these areas frequently subject to very thick fog.\n\nBeing at moderately high altitudes in spring there is the possibility of finding tongues of snow that could make the ascent more difficult.	/static/gpx/Colle Della Gianna (1).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/37.jpg"]	0	
5	2	3221.31	120	712.94	3	Hike Zicher	Lungo l’itinerario non è garantita la piena copertura telefonica\nIn periodo estivo, la parte finale può essere molto esposta al sole e richiedere fatica.\nIn condizioni di vento forte, è preferibile non proseguire\nE’ possibile sviluppare un itinerario ad anello scendendo dal versante nord della montagna in direzione Bocchetta Sant’Antonio (ma attenzione ad un passaggio su rocce, soprattutto se ghiacciate).	/static/gpx/Hike_Zicher (2).gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Craveggio	Italia	0		["/static/images/29.jpg"]	0	
6	2	15636.67	150	1366.80	2	Usseaux Altro	The flowering of Eriofori along the shores of the lake between July and August is interesting, making it very suggestive.	/static/gpx/Laghi_Albergian.gpx	0.00	Piemonte	Torino	Usseaux	Italia	0		["/static/images/40.jpg"]	0	
7	2	15636.67	150	1366.80	3	Usseaux Altro	Itinerario vario e panoramico, non presenta particolari difficoltà ma per la lunghezza, il dislivello, la mancanza di punti di appoggio e la necessità di una certa capacità di orientamento su sentieri non sempre evidenti (specialmente per la variante in discesa) è consigliato a escursionisti allenati e esperti.	/static/gpx/Laghi_Albergiani.gpx	0.00	Piemonte	Torino	Usseaux	Italia	0		["/static/images/42.jpg"]	0	
8	2	5.30	210	20.20	2	Lago Bianco	Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.\n\nLa diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.\n\nLa Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.\n\nSi può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.	/static/gpx/Lago Bianco.gpx	0.00	Auvergne-Rhone-Alpes	Savoia	Val-Cenis	Francia	0		["/static/images/1.jpg"]	0	
9	2	21358.83	170	1087.90	2	Lago dei 7 colori (lago gignoux)	Parcheggia a Claviere e dirigiti verso la strada comunale Valle Gimont che, dopo poco, si fa sterrata.\n\nLascia alla tua destra i cartelli che indicano il Lago Gignoux e prosegui risalendo le piste da sci.\n\nGiunto a Sagna Longa noterai che la zona è di interesse sciistico, infatti ci sono numerosi arrivi di seggiovia. Segui le indicazioni per Colle Bercia, attraversa una chiesetta, dei caseggiati in pietra e prosegui per il largo sentiero.\n\nL’intero percorso si sviluppa circondato dai bellissimi Monti della Luna ed è caratterizzato da una dolce e semicostante salita su terreno sterrato a tratti ghiaioso.\n\nSuperato il Colle Bercia continua sull’ampia carreggiata che ti conduce ad un valico nel quale noterai particolari conformazioni rocciose e una punta (Cima Saurel 2451 mt). Tieniti sul sentiero basso e supera il valico, che segna anche il confine con la Francia, dopo il quale troverai il lago immerso in una conca.	/static/gpx/Lago dei 7 colori (lago gignoux) (1).gpx	0.00	Piemonte	Torino	Claviere	Italia	0		["/static/images/51.jpg"]	0	
10	2	4024.73	120	810.90	2	Lago d'Afframont 1986 m	Una volta parcheggiata la macchina dirigiti verso il villaggio Albaron. Poco dopo i caseggiati ti troverai di fronte ad un impianto di risalita dismesso, a sinistra troverai un campetto da calcio, proprio dopo il campetto si intravedono i primi cartelli con le indicazioni per il Lago di Afframont. Il sentiero da seguire è il 213, ma lungo il tragitto troverai solo bandiere bianco/rosse e cartelli di legno che indicano la destinazione.\n\nSi sale l’ex pista da sci e ci si addentra nel bosco. Il primo tratto rimane ombreggiato, mentre inizia a farsi sentire la salita. Ad un certo punto ci si affianca ad un ruscello, il Rio di Afframont, che scorre sulla sinistra e si supera con facilità in prossimità dei caseggiati in pietra (attenzione nei periodi di pioggia perché potrebbe essere impraticabile).	/static/gpx/Lago di Afframont 1986 m.gpx	0.00	Piemonte	Torino	Balme	Italia	0		["/static/images/52.jpg"]	0	
11	2	7580.49	110	1049.26	2	Briccas da Borgata Brich 20/02/21	After leaving the car, we continue along the road, first paved and then dirt.\n\nIn case of little snow or high temperatures it is possible to cover the first 150m in altitude without snowshoes.\n\nAs soon as we hit the first snow, we put on our snowshoes and set off on a well-defined path that crosses a wood.\n\nAfter having left the last huts behind us, we turn right towards the North/East near a GTA trail sign painted on a boulder.\n\nFrom here, after the last bush, an enormous, very wide slope opens up before us which culminates right at our peak	/static/gpx/Monte Briccas da Brich (1).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/35.jpg"]	0	
12	2	11664.79	150	1472.80	3	Monte Ferra Con Marco e Daniel	Fondamentali i bastoncini specialmente nella discesa dal Monte Ferra al lago Reisassa.\n\nUnico punto di appoggio è il rifugio Melezè ad inizio itinerario (consigliamo di contattare direttamente la struttura per verificare giorni e orari di apertura)	/static/gpx/Monte Ferra (1).gpx	0.00	Piemonte	Cuneo	Cuneo	Italia	0		["/static/images/28.jpg"]	0	
13	2	6229.07	200	1024.76	2	Da Crissolo a Ghincia	The Path to Monte Granè is a suggestive walk with a splendid view of Monviso (3841 m) and Viso Mozzo (3019 m).\n\nLeave the car in the car park and continue to the left of the sports field where a splendid path immersed in the woods appears before us and after about 1.5 km you come to the dirt road which in summer leads to the Black Eagle refuge.\n\nContinuing on the latter and having reached the refuge, continue along the Crissolo slopes to the end of the ski-lift where, just above the Ghincia Pastour hut, we will find a statue of the Madonna to indicate the end of the path to Monte Granè.\n\nThe return takes place along the same route as the outward journey.	/static/gpx/Monte Granè (2).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/36.jpg"]	0	
14	2	6588.82	150	936.79	2	Montr Pigna da Prea	Posteggiata la macchina nel parcheggio sotto l’abitato di Prea ci dirigiamo lungo la strada asfaltata situata sotto il cimitero, lasciandocelo sulla destra.\n\nAppena incontriamo la prima neve possiamo allacciare le ciaspole e proseguire fino alla borgata di Sant’Anna di Prea. (Nei mesi invernali, con nevicate nella norma, la strada viene pulita fino al parcheggio quindi si può iniziare ad indossare le ciaspole fin da subito).\n\nSubito dopo il cartello, all’ingresso di Sant’Anna di Prea, sulla destra vi è un magnifico sentiero immerso nel bosco che permette di tagliare la borgata accorciando la salita di circa 1 km.\n\nIncrociando nuovamente la strada principale e percorrendo circa 3 km si giunge alla Baita Monte Pigna situata a metà degli impianti di Lurisia.	/static/gpx/Monte Pigna Da Prea (1).gpx	0.00	Piemonte	Cuneo	Roccaforte Mondovì	Italia	0		["/static/images/47.jpg"]	0	
15	2	10065.93	130	842.70	2	Pian della Regina - Laghi del Monviso	The excursion can start near the Po, parking the car in one of the many spaces available. Once you have crossed the stream, follow via Ruata.\n\nTo get your bearings in Crissolo, we suggest following the signs for "La Capanna" and ignoring the various detours on the left that follow the ski lifts. Before reaching the restaurant, you finally take the road, following the signs for Monte Tivoli.\n\nThe path climbs up into the wood (splendid during the autumn season) and crosses the Sbarme stream.	/static/gpx/Pian della Regina - Laghi del Monviso (1).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/32.jpg"]	0	
16	2	7281.87	120	504.40	2	Fenestrelle Escursionismo	Itinerario di medio sviluppo con ampio panorama verso la Val Chisone.\n\nAttenzione nella stagione invernale: la zona soggetta a valanghe in caso di abbondanti precipitazioni nevose, specialmente nella conca che precede il rifugio.\n\nInformarsi sempre sullo stato della neve presso i gestori del rifugio o l’ufficio turistico di Fenestrelle.	/static/gpx/Rif. Selleries.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/43.jpg"]	0	
17	2	4156.24	150	850.76	0	Rifugio Meira Garneri da Sampeyre	Lascia l’auto nel parcheggio della seggiovia di Sampeyre.\n\nLasciato il parcheggio saliamo subito a destra degli impianti di risalita, dove alcuni cartelli rossi ci segnalano il sentiero attraverso il bosco.\n\nPrendendo rapidamente quota, alla fine del primo tratto di boscoso, raggiungiamo la frazione Sodani dove possiamo osservare la bella chiesa affrescata.\n\nUsciti dalla borgata proseguiamo nuovamente lungo il sentiero circondati da larici, faggi, betulle e dopo alcune deviazione, sempre ben segnalate, usciamo in una splendida radura.\n\nSaliamo gli ultimi 200m a lato della pista o volendo possiamo proseguire più a destra incrociando la strada carrozzabile che nel periodo estivo porta al rifugio.	/static/gpx/Rifugio Meira Garneri da Sampeyre (1).gpx	0.00	Piemonte	Cuneo	Sampeyre	Italia	0		["/static/images/45.jpg"]	0	
18	2	4388.16	200	923.62	2	Sentiero per ROCCA PATANUA	Itinerario interamente rivolto a Sud che normalmente si libera dalla neve già a inizio primavera.\n\n(l’itinerario è stato svolto in periodo invernale, seguito scarsa e quasi totalmente assente copertura nevosa).	/static/gpx/Rocca Patanua da Prarotto (1).gpx	0.00	Piemonte	Torino	Condove	Italia	0		["/static/images/28.jpg"]	0	
19	2	8085.21	150	829.13	3	Cima Durand-Colle Bauzano-Artesina	Lasciata la macchina nello spazioso parcheggio di Artesina o nei posteggi vicino al bar Tana del Lupo, saliamo sulle piste dove possiamo subito infilare le ciaspole.\n\nProcediamo per circa 400m sull’ampio sentiero in direzione Ovest (a destra) e dopo alcuni tornanti troviamo un bivio (a sinistra vi è la stradina che percorreremo al ritorno) dove proseguiamo sulla destra (sentiero F02) dirigendoci verso la Celletta, punto panoramico sulla valle Ellero.\n\nPercorriamo il sentiero per Serra della Turra che ci porta prima a passare sotto la seggiovia e poi ad un pianoro dove troviamo la Baita della Turra, tappa ideale per un eventuale break o colazione.	/static/gpx/Senriero per Anello cima Durand, Colle Bauzano, Artesina (1) (1).gpx	0.00	Piemonte	Cuneo	Artesina	Italia	0		["/static/images/48.jpg"]	0	
20	2	9039.75	120	1090.66	1	Rifugio Quintino Sella e Viso Mozzo	The path does not present any difficulty, in case of rain, however, the climb is not recommended as the route is entirely on stony ground.\n\nFrom up there you have a privileged view of a large part of the Monviso chain and the close distance to the Re di pietra is unique.	/static/gpx/Sentiero per Rifugio Quintino Sella e Viso Mozzo.gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/31.jpg"]	0	
21	2	16969.03	120	984.23	3	Da Ss659 a Ss6591	Take the A26 motorway towards Gravellona Toce and follow it to the end. From there stay on the SS33 del Sempione passing Domodossola. At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls. There are unpaved parking lots just before the Centro Fondo Riale.	/static/gpx/Sentiero per Rupe del Gesso - CIASPOLE.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Formazzo	Italia	0		["/static/images/38.jpg"]	0	
22	2	11301.88	140	1381.69	2	Albogno-Pieve Margineta Mater	Escursione senza molte difficoltà ideale per il periodo primaverile e autunnale. \nDopo circa 2 ore di bosco si esce su delle creste molto panoramiche e semplici, il ritorno purtroppo viene fatto su un sentiero poco segnato sulla parte iniziale e ma man mano che si scende compiano sia segni e gli ometti.	/static/gpx/albogno-pieve-margineta-mater-27-8-21.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Albogno	Italia	0		["/static/images/11.jpg"]	0	
37	2	4.40	225	8.40	2	La pieve romanica di Piesenzana e la valle delle tartufaie	Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. \nCirca 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. \nIn regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. \nA Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). \nContemporaneamente i ristoranti della zona propongono piatti a base di tartufi	/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx	0.00	Piemonte	Asti	Montechiaro d'Asti	Italia	0		["/static/images/5.jpg"]	0	
23	2	2.30	200	25.80	2	Alte Langhe Settentrionali - Cossano Belbo	Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.\nSi svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.\nSi imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.\nInizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.\nPercorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. \nSeguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. \nSi procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante	/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx	0.00	Piemonte	Cuneo	Cossano Belbo	Italia	0		["/static/images/4.jpg"]	0	
24	2	8503.26	150	558.51	2	Anello per il Monte Freidour (PERLEVIEDELMONDO)	At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls.	/static/gpx/anello monte freidour (1).gpx	0.00	Piemonte	Torino	San Pietro Val Lemina	Italia	0		["/static/images/39.jpg"]	0	
25	2	42458.63	320	23175.26	2	Anello Pieve di Ledro-Biacesa di Ledro-Rifugio Nino Pernici	Anello sui monti a nord-est del Lago di Ledro, percorso in 3 giorni andando con molta calma, percorribile anche in 2. \nAlcuni tratti della prima metà del percorso sono attrezzati con scale e corde.	/static/gpx/anello-pieve-di-ledro-biacesa-di-ledro-rifugio-nino-pernici.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/14.jpg"]	0	
26	2	19320.58	210	666.37	2	Anello sui colli imolesi: Dozza - Pieve S. Andrea	Crossing the provincial road you can see the first of the various signs of the Camino di San Antonio that we will find along the way. We cross and begin a slow but constant climb alongside the fields, which will lead us to a beautiful panoramic view of the surrounding valleys. Paying attention to the crossroads, we continue until we cross the paved road again. In reality there is very little traffic... with a decent view of the Vena del Gesso Romagnola we arrive at the delightful village of Pieve Sant'Andrea (worth a quick detour), to then resume our journey. Be careful not to follow the path of Sant'Antonio, we descend rapidly (shortly after we find the Sorgente delle Accarisie on our left, already existing in Roman times) until we reach the small hamlet of Valsellustra. Here too we cross the road and follow the paved via delle Ville uphill to arrive at a first panoramic point over the surrounding gullies.	/static/gpx/anello-sui-colli-imolesi-dozza-pieve-s-andrea-valsellustra-s.gpx	0.00	Emilia-Romagna	Bologna	Dozza	Italia	0		["/static/images/21.jpg"]	0	
27	2	10764.50	300	1852.46	2	Campione Pieve Campione	Campione Pieve Campione	/static/gpx/campione-pieve-campione.gpx	0.00	Lombardia	Brescia	Campione del Garda	Italia	0		["/static/images/17.jpg"]	0	
28	2	15650.26	210	838.33	2	Casalfiumanese (BO) - Pieve di Sant'Andrea	Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don't die from the heat and the clouds filter the sun's rays and allow you to better enjoy the landscapes	/static/gpx/casalfiumanese-bo-pieve-di-santandrea.gpx	0.00	Emilia-Romagna	Bologna	Casal Fiumese	Italia	0		["/static/images/24.jpg"]	0	
29	2	15650.26	210	838.33	2	Casalfiumanese (BO) - Pieve di Sant'Andrea	Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don't die from the heat and the clouds filter the sun's rays and allow you to better enjoy the landscapes	/static/gpx/casalfiumanese-bo-pieve.gpx	0.00	Emilia-romagna	Bologna	CasalFiumese	Italia	0		["/static/images/25.jpg"]	0	
30	2	17987.27	150	651.41	1	Cavriana pieve- Volta mantovana chiesetta Madonna dei Marchi	Bellissima passeggiata con displivello	/static/gpx/cavriana-pieve-volta-mantovana-chiesetta-madonna-dei-marchi.gpx	0.00	Lombardia	Mantova	Cavriana	Italia	0		["/static/images/13.jpg"]	0	
31	2	5474.28	140	791.51	2	Sentiero per CIMA CIANTIPLAGNA	The route is safe and within everyone's reach, even though you reach a relatively high altitude... for this reason it is good to take into account sudden changes in the weather (wind, rain, thick fog).\n\nDue to the total absence of shading, I recommend sunscreen cream and adequate water supply.\n\nIn late spring it is still possible to find accumulations of snow which can make the ascent difficult, especially in the final stretch towards the summit.\n\nFor cheese lovers, I highly recommend a stop at the Pian dell'Alpe bergeria...	/static/gpx/ciantiplagna.gpx	0.00	Piemonte	Torino	Meana di Susa	Italia	0		["/static/images/41.jpg"]	0	
32	2	6588.82	120	936.79	2	Da Voltino a Pieve di Tremosine e ritorno	Fa quasi paura ad avvicinarsi alla ringhiera. \nVicino alla postazione panoramica presso il bar ristorante che ho fotografato, c'è l'inizio del sentiero per la discesa al Porto di Tremosine.C'è scritto che è consigliato per escursionisti esperti.	/static/gpx/da-voltino-a-pieve-di-tremosine-e-ritorno.gpx	0.00	Lombardia	Brescia	Tremosine sul Garda	Italia	0		["/static/images/15.jpg"]	0	
33	2	13691.92	150	584.92	2	Dalla chiesa romanica di San Pietro di Fenestrella alla abba...	Chiesa di San Pietro de Fenestrella: \nLa chiesa è situata nel cimitero di Albugnano. \nEssa ha affinità compositive con la Canonica di santa Maria di Vezzolano e deriverebbe il suo nome ,secondo alcuni,dalla insolita presenza di tre finestre nell’abside,secondo altri, sarebbe stata così denominata perchè situata nello stretto colle (una gola) compreso tra il rilievo collinare di Albugnano e il rilievo ove sorge il cimitero: \nUna specie di finestra aperta sulla valle sottostante.	/static/gpx/dalla-chiesa-romanica-di-san-pietro-di-fenestrella-alla-abba.gpx	0.00	Piemonte	Asti	Albugnano	Italia	0		["/static/images/27.jpg"]	0	
34	2	14496.86	90	832.35	1	Gulo - Pieve Vergonte	Gulo - Pieve Vergonte	/static/gpx/gulo-pieve-vergonte.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Santa Maria	Italia	0		["/static/images/9.jpg"]	0	
35	2	9623.86	210	697.12	2	Il giro del Montorfano: la chiesa romanica, il borgo e la ve...	Il giro del Montorfano: la chiesa romanica, il borgo e la vetta	/static/gpx/il-giro-del-montorfano-la-chiesa-romanica-il-borgo-e-la-vett.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Bracchio	Italia	0		["/static/images/10.jpg"]	0	
36	2	12572.72	210	341.55	3	La chiesa romanica di S. Vittore(anello Montemagno--Viarigi)	Il percorso si svolge prevalentemente su sterrata. \nEsso non ha segnaletica ad eccezione dell’ultimo tratto (due km. circa) da località Madonna del Gombo fino a Montemagno. \nIn questo tratto si incontra la segnaletica del sentiero n.507 della Regione Piemonte.	/static/gpx/la-chiesa-romanica-di-s-vittoreanello-montemagno-viarigi.gpx	0.00	Piemonte	Asti	Montemagno	Italia	0		["/static/images/6.jpg"]	0	
38	2	12572.72	255	341.55	3	Le Paludi di Ostiglia Oasi del Busatello Sermide e Pieve	La tradizione afferma che la chiesa fu costruita nel 1082, per volere di Matilde di Canossa. Questa attribuzione risale al 1612 nella Historia ecclesiastica di Mantova dove il Donesmondi attribuisce l'edificazione della chiesa a Matilde, assieme ad altre chiese del territorio. \nIl Donesmondi affermò questa data riprendendo l'iscrizione da una lapide presente sulla facciata della pieve, visibile ancora oggi, dove sta scritto "D.O.M. ET B. MARIAE V. IN COELUM ASSUMPTAE ERECTA A.D. 1082 A CONNTISSA MATHILDE". Secondo un'analisi storica questa lapide non può essere ritenuta originale dell'XI secolo, ma risale al cinquecento. L'ipotesi è che questa iscrizione si stata realizzata durante il restauro del 1538. \nStoricamente, quindi, non ci sono documenti che attestano una data certa di costruzione della chiesa, ma sulla base degli elementi architettonici si può affermare che la pieve venne eretta nell'XI secolo. \nLa chiesa è in stile romanico, costruita in laterizio ed è composta da tre navat	/static/gpx/le-paludi-di-ostiglia-oasi-del-busatello-sermide-e-pieve-di-.gpx	0.00	Lombardia	Mantova	Pieve di Coriano	Italia	0		["/static/images/7.jpg"]	0	
39	2	2150.30	120	586.43	2	Sentiero per il MONTE CUCETTO	Escursione Facile e, nella parte alta, molto panoramica; la cima offre una buona panoramica dei rilievi tra bassa Val Chisone e Val Sangone.\n\nLasciata l’auto, il sentiero parte in corrispondenza del tornante ed entra nel bosco in direzione Nord-Ovest; al primo bivio, proseguire dritto e seguire le indicazioni per “Cucetto”; il sentiero inizia a guadagnare quota abbastanza rapidamente e costantemente, sempre nel bosco.\n\nDopo una serie di tornantini la vegetazione inizierà a diradarsi e si inizierà a scorgere un bel panorama con il Monviso in bella mostra (se il meteo lo permette).	/static/gpx/monte cucetto.gpx	0.00	Piemonte	Torino	Dubbione	Italia	0		["/static/images/50.jpg"]	0	
40	2	2127.35	200	277.52	2	Sentiero per il MONTE MURETTO	È presente un unico punto acqua nel luogo del parcheggio (fontana). Nella stessa piazzetta, al momento della recensione, è sempre aperto nei weekend un singolare bar allestito dentro un vecchio furgone.\n\nPer chi cammina con bimbi e soprattutto cani, attenzione in primavera alla presenza di processionarie.	/static/gpx/monte muretto.gpx	0.00	Piemonte	Torino	Torino	Italia	0		["/static/images/44.jpg"]	0	
41	2	8627.55	70	1018.01	1	Pieve di Ledro - Monte Cocca	Very challenging, but worth it! The view from the top is gorgeous! For the descent it is better to use sticks, or repeat the same route as the climb.	/static/gpx/pieve-di-ledro-monte-cocca.gpx	0.00	Trentino Alto Adige	Provincia di Trento	Pieve di Ledro	Italia	0		["/static/images/20.jpg"]	0	
42	2	22430.40	150	1004.43	2	Pieve S. Stefano a Pian delle Capanne	Causa pioggia e terreno scivoloso preso la 1º variante fino al passo Viamaggio poi proseguito ancora per la 2º variante. \nBisogna calcolare circa 4 km in più.	/static/gpx/pieve-s-stefano-a-pian-delle-capanne.gpx	0.00	Toscana	Arezzo	Pieve Santo Stefano	Italia	0		["/static/images/23.jpg"]	0	
43	2	4857.31	60	94.23	1	Piverone - Anello IV - “Via Romanica al Gesiun”	Piverone - Anello IV - “Via Romanica al Gesiun”	/static/gpx/piverone-anello-iv-via-romanica-al-gesiun.gpx	0.00	Piemonte	Torino	Pieverone	Italia	0		["/static/images/8.jpg"]	0	
44	2	6588.82	320	936.79	2	Plois - Pieve d'Alpago	percorso è tranquillamente percorribile	/static/gpx/plois-pieve-dalpago.gpx	0.00	Veneto	Belluno	Pieve d'Alpegno	Italia	0		["/static/images/19.jpg"]	0	
45	2	6588.82	200	936.79	2	Rifugio Galassi, forcella del ghiacciaio, Rifugio Antelao	Quinta giornata Alta via N°4\nRifugio Galassi, forcella del ghiacciaio, Rifugio Antelao, Pieve di Cadore.	/static/gpx/rifugio-galassi-forcella-del-ghiacciaio-rifugio-antelao-piev.gpx	0.00	Veneto	Belluno	Belluno	Italia	0		["/static/images/18.jpg"]	0	
46	2	8085.21	135	829.13	3	Riva del Garda - Pieve di Ledro - Panchina	Riva del Garda - Pieve di Ledro - Panchina	/static/gpx/riva-del-garda-pieve-di-ledro-panchina.gpx	0.00	Trentino Alto Adige	Provincia di Trento	Sant'Alessandro	Italia	0		["/static/images/16.jpg"]	0	
47	2	19553.11	210	1298.22	2	Sovicille delle Meraviglie - Villa Cetinale - Scala Santa	Suggestivo anello con visita della pieve di Pernina e del parco di Villa Cetinale/Castello di Celsa aperti in occasione dell'evento Sovicille delle Meraviglie ottobre 2021	/static/gpx/sovicille-delle-meraviglie-villa-cetinale-scala-santa-e-romi.gpx	0.00	Toscana	Siena	Sovicille	Italia	0		["/static/images/26.jpg"]	0	
48	2	5304.04	150	958.89	3	BERGERIE DI VALLONCRO’	Open and shade-free environment: remember sunscreen; if the walk is too long, the plateau at the base of the waterfall still offers various possibilities for pleasant picnics.	/static/gpx/vallone di massello (1).gpx	0.00	Piemonte	Torino	Massello	Italia	0		["/static/images/30.jpg"]	0	
49	2	22696.48	110	236.71	2	Ville Disunite - Anello Ghibullo - Villa Pasolini.	The first stretch is entirely on the right bank of the Ronco, on the Via Romea Germanica. Then you enter the territory to go towards the center of the journey, the area of ​​San Pietro in Trento where, within two kilometres, you come across a medieval tower, a 9th century parish church with a fantastic crypt, the ruins of a large villa and a perfectly healthy 16th century villa.	/static/gpx/ville-disunite-anello-ghibullo-villa-pasolini-torre-albicini.gpx	0.00	Emilia-Romagna	Ravenna	Lognana	Italia	0		["/static/images/23.jpg"]	0	
\.


--
-- Data for Name: hut-worker; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."hut-worker" ("userId", "hutId") FROM stdin;
7	1
8	2
9	3
10	4
11	5
12	6
13	7
14	8
15	9
16	10
17	11
18	12
19	13
20	14
21	15
22	16
23	17
24	18
25	19
26	20
27	21
28	22
29	23
30	24
31	25
32	26
33	27
34	28
35	29
36	30
37	31
38	32
39	33
40	34
41	35
42	36
43	37
44	38
45	39
46	40
47	41
48	42
49	43
50	44
51	45
52	46
53	47
54	48
55	49
56	50
57	51
58	52
59	53
60	54
61	55
62	56
63	57
64	58
65	59
66	60
67	61
68	62
69	63
70	64
71	65
72	66
73	67
74	68
75	69
76	70
77	71
78	72
79	73
80	74
81	75
82	76
83	77
84	78
85	79
86	80
87	81
88	82
89	83
90	84
91	85
92	86
93	87
94	88
95	89
96	90
97	91
98	92
99	93
100	94
101	95
102	96
103	97
104	98
105	99
106	100
107	101
108	102
109	103
110	104
111	105
112	106
113	107
114	108
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website, elevation, pictures, description, "workingTimeStart", "workingTimeEnd", "phoneNumber", email) FROM stdin;
1	112	1	149.00	Edmund-Graf-Hütte	2	Lisa Viscò	http://slimy-participant.it	336.29	["/static/images/0cf0a68d-353d-483a-96c2-e705ff3a0aff.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg"]	Deserunt ea odit illum illum atque.\nDoloremque iure ducimus repellendus.\nNobis blanditiis autem repellendus sint totam cumque.\nIure amet cum.	06:00:00	20:00:00	+395572263341	Archimede.Merlo25@gmail.com
2	113	8	37.00	Dr.Hernaus-Stöckl	2	Renato Zucca	http://skeletal-eurocentrism.it	302.50	["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg"]	Amet unde minima aliquid esse dignissimos error explicabo.\nExplicabo unde repellendus saepe laborum magnam illum recusandae aspernatur voluptatibus.\nIpsa nulla facilis ex amet.\nRecusandae cumque rerum reiciendis voluptas eius aut veritatis.	08:00:00	22:00:00	+397817251795	Girardo.Ciani92@hotmail.com
3	114	1	113.00	Amstettner Hütte	2	Otilia Bandini	http://advanced-porcupine.it	294.32	["/static/images/d03cf932-28ff-418b-8c01-cbe9b3595a42.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg"]	Doloribus cumque quidem saepe mollitia.\nNatus cum placeat a labore.\nRem aliquid cum ab quam quis.\nEarum repellat error.\nEnim eveniet temporibus deleniti odio velit vero.	09:00:00	19:00:00	+390684825513	Servidio49@email.it
4	115	9	107.00	Hochleckenhaus	2	Sig. Fiordaliso Coccia	https://specific-cornmeal.org	322.00	["/static/images/013a52c4-de83-4844-b30f-ecdbdd87bcd2.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg"]	Occaecati excepturi eaque consequatur temporibus numquam recusandae.\nIpsa rerum minus ipsam nisi deserunt maiores alias.	05:00:00	19:00:00	+394486261630	Alceste81@yahoo.it
5	116	6	47.00	Kampthalerhütte	2	Saturnino Massa	https://worldly-seeker.it	320.81	["/static/images/5c1d9ff4-870c-43f3-9a43-5c75839b798f.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]	Pariatur aliquid iste praesentium aut.\nCorrupti deserunt optio voluptatibus fugit omnis autem ex illo porro.\nConsequuntur veniam velit ut eligendi.	06:00:00	19:00:00	+399261083460	Zena_Cannone@libero.it
6	117	5	139.00	Lambacher Hütte	2	Vanna Vicini	http://secondary-fingerling.org	267.72	["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg"]	Vero maiores fugiat veritatis fuga.\nDolor reprehenderit laborum rem perspiciatis.\nNemo nam vel est ullam magni blanditiis accusantium.	08:00:00	20:00:00	+398351971306	Eulalia19@yahoo.it
7	118	3	94.00	Lustenauer Hütte	2	Archimede Fanelli	http://mortified-cupboard.net	287.80	["/static/images/e44a5c11-f2a2-4f3e-8c53-af9957e1ea11.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg"]	Repellendus tempora maiores dignissimos consectetur saepe mollitia.\nEum adipisci est veritatis similique labore qui aperiam.\nError quidem facere.	06:00:00	21:00:00	+391333933803	Manetto34@libero.it
8	119	7	136.00	Gablonzer Hütte	2	Viola Vanni	http://alarmed-guideline.org	310.96	["/static/images/e25caa47-16e0-4d5a-81f8-0f6a69499027.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg"]	Esse consequuntur debitis laboriosam dicta laboriosam dolorum.\nLaboriosam quos voluptatem.\nReiciendis fuga qui ipsam.\nNobis aspernatur rerum.\nNulla sapiente necessitatibus id at officiis dolore accusamus ipsa.	01:00:00	20:00:00	+399299633419	Folco.Marcon@hotmail.com
9	120	5	81.00	Katafygio «Flampouri»	2	Giulio Ermini	https://clever-perp.it	322.43	["/static/images/e25caa47-16e0-4d5a-81f8-0f6a69499027.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg"]	Quasi laudantium unde adipisci assumenda dolorum officiis.\nAlias assumenda odio ut harum architecto consequuntur.\nSed libero in aliquam corporis.	05:00:00	23:00:00	+398795250522	Verenzio.Lodi84@gmail.com
10	121	6	137.00	Simonyhütte	2	Gianmario Marega	http://enormous-offering.com	276.60	["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg"]	Quod rem cum tenetur aliquam iste voluptatem quisquam.\nMinima commodi modi placeat.\nAutem placeat natus quo itaque reprehenderit.\nNumquam atque quae voluptatem odit itaque.	02:00:00	22:00:00	+390414168573	Onesto.Minelli22@email.it
11	122	7	102.00	Vinzenz-Tollinger-Hütte	2	Sig. Nicla Pardini	https://cultivated-oversight.it	261.29	["/static/images/9632fe84-ed47-4201-8ee8-9aff4fc7bd51.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg"]	Pariatur atque natus quae.\nDucimus unde earum.\nOdio facere voluptatum.\nIllo at placeat consequatur accusamus cupiditate quasi mollitia officiis culpa.\nPlaceat nesciunt assumenda vero in soluta doloribus.	05:00:00	21:00:00	+394070835589	Iona37@hotmail.com
12	123	9	98.00	Ottokar-Kernstock-Haus	2	Gioventino Oliva	https://earnest-corn.com	265.80	["/static/images/814e2adf-d56e-4afd-9b9a-5c9e93c9bab6.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]	Vitae repellat doloribus iure eos aut unde quia.\nTenetur similique consequuntur sint quidem ut.\nDebitis ab magnam.\nNon animi tenetur neque ad.	08:00:00	20:00:00	+398078617391	Menardo64@gmail.com
13	124	3	60.00	Reisseckhütte	2	Geronzio Giraudo	http://dapper-jute.com	276.66	["/static/images/3ab7353d-3916-4811-8265-1e83602ade8c.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg"]	Aliquid consequatur atque quam.\nIllum nulla labore dolore architecto culpa mollitia labore.	02:00:00	22:00:00	+395893138153	Dora60@yahoo.it
14	125	5	69.00	Vernagthütte	2	Isotta Hofer	http://posh-deviation.it	313.90	["/static/images/4b4ed22c-46cd-4422-97fe-683905feeaa6.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg"]	Corrupti maxime aliquam.\nVoluptates amet sequi beatae aspernatur.\nQuia rem magnam iste iusto consequuntur accusamus totam.\nCulpa placeat beatae exercitationem amet quasi.\nFuga deserunt facilis magnam accusamus sequi dolorem aliquid soluta.	09:00:00	18:00:00	+395482914324	Salvatore35@libero.it
15	126	9	116.00	Wormser Hütte	2	Nicodemo Orefice	http://determined-authenticity.net	282.58	["/static/images/76af67a0-a788-48d2-8882-e0b626b8cd9f.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]	Earum repellendus ipsa occaecati asperiores.\nFacilis cupiditate dolorem soluta nobis voluptatibus.\nDeserunt ipsum itaque animi necessitatibus.\nMaiores non hic quod blanditiis eveniet possimus nobis itaque fugit.	01:00:00	19:00:00	+398162709590	Selvaggia.Rondoni26@gmail.com
16	127	9	128.00	Biberacher Hütte	2	Eustorgio Vierin	http://usable-whirlwind.com	320.99	["/static/images/e44a5c11-f2a2-4f3e-8c53-af9957e1ea11.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg"]	Labore aperiam minima dolorem sequi ratione sed fuga.\nSapiente itaque maxime voluptatem labore animi laboriosam.\nEum pariatur magnam fugit perferendis saepe itaque adipisci blanditiis quibusdam.\nModi exercitationem quam.\nAmet iusto reiciendis a reprehenderit.	07:00:00	18:00:00	+390138009378	Urdino41@yahoo.it
17	128	4	100.00	Katafygio «1777»	2	Edoardo Gravina	http://unique-buddy.it	278.20	["/static/images/0cf0a68d-353d-483a-96c2-e705ff3a0aff.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg"]	Earum labore explicabo explicabo.\nLaudantium sed debitis dicta animi.	01:00:00	19:00:00	+393605293066	Marzio.Serra@hotmail.com
18	129	8	46.00	Hochwaldhütte	2	Elisabetta Raniolo	https://musty-fanny-pack.org	303.82	["/static/images/5c1d9ff4-870c-43f3-9a43-5c75839b798f.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]	Nisi architecto accusamus laborum repudiandae quos.\nRem eaque velit ducimus hic.	02:00:00	19:00:00	+393302777319	Diodoro.Micco87@yahoo.com
19	130	5	62.00	Kölner Eifelhütte	2	Virone Galati	http://granular-gather.org	338.16	["/static/images/23225d35-5350-4600-89d5-7c01fd116f1d.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg"]	Harum debitis occaecati voluptatem.\nItaque impedit asperiores exercitationem.\nAlias voluptatum voluptate reprehenderit mollitia.\nEius eum dolorem ex vel nostrum iste consequatur quod voluptate.	08:00:00	18:00:00	+393619550478	Cupido.DiMartino@email.it
20	131	2	38.00	Madrisahütte	2	Antea Agostinelli	https://unlined-welfare.net	298.76	["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]	Velit aliquam illo necessitatibus voluptates quam pariatur.\nQuibusdam rem facilis ea minima mollitia modi natus eaque nam.\nEt nobis doloremque aliquam sit sit consectetur fugit fugiat.\nRecusandae eum animi.\nNesciunt dignissimos veniam pariatur fuga velit aperiam.	01:00:00	21:00:00	+392340885631	Ambra.Mottola77@yahoo.com
21	132	4	40.00	Dresdner Hütte	2	Rocco De Angelis	http://vivacious-platform.org	272.25	["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]	Numquam rerum distinctio sapiente excepturi harum molestiae placeat.\nDeserunt eum dicta vel et explicabo debitis vitae tenetur iure.\nFugit explicabo officia aspernatur minima libero.\nQuia itaque consequatur adipisci explicabo sapiente quaerat.\nEt impedit officiis veniam cum placeat nesciunt voluptatibus adipisci ab.	07:00:00	20:00:00	+395348171897	Alfio_Spagnuolo12@hotmail.com
22	133	6	125.00	Fiderepasshütte	2	Palmira Papini	http://rectangular-oncology.it	271.09	["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]	Quia saepe iste earum natus quia sint dolor eaque impedit.\nInventore quasi voluptates quisquam.\nPariatur voluptas ab quaerat.	07:00:00	22:00:00	+393555003191	Clelia0@gmail.com
23	134	3	37.00	Göppinger Hütte	2	Fiorenza Zanelli	http://agile-polo.org	327.35	["/static/images/480257c1-8fac-4019-a612-6b46ce1a2eb3.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg"]	Ut velit necessitatibus mollitia accusamus repudiandae.\nImpedit eligendi fugit fugit eveniet quis ad.	01:00:00	21:00:00	+395875499072	Gianpietro_Motisi@libero.it
24	135	8	132.00	Oberzalimhütte	2	Sig. Urbano Rambaldi	https://arctic-cone.it	292.28	["/static/images/23225d35-5350-4600-89d5-7c01fd116f1d.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg"]	Ea iusto hic ex ea odio eius quia saepe in.\nIpsam quia adipisci deserunt deleniti iste pariatur.\nCum expedita facere nobis praesentium facilis a.\nDolor dolore numquam.\nEaque dignissimos ullam ad quasi numquam.	08:00:00	18:00:00	+394171415111	Rodiano27@hotmail.com
25	136	5	89.00	Rastkogelhütte	2	Proteo Locatelli	http://neglected-graduate.net	336.27	["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg"]	Fugiat porro animi hic.\nQuidem ipsum nobis repudiandae architecto ab animi eaque.\nDolorum quasi quod sint voluptate odio sapiente nostrum atque.\nNulla voluptatibus debitis odio culpa nostrum vitae ab natus iste.	04:00:00	18:00:00	+390010808406	Leonio_Luppi72@hotmail.com
26	137	3	102.00	Ansbacher Skihütte im Allgäu	2	Giorgio Perrone	https://weird-paste.com	333.68	["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg"]	Ab eveniet esse deleniti ex eos illum facere veniam magni.\nTempore architecto soluta eveniet minima earum id.	04:00:00	22:00:00	+392665568561	Graziana_Antezza96@libero.it
27	138	10	72.00	Kaltenberghütte	2	Ing. Carlotta Ricciardi	http://droopy-streetcar.org	266.92	["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg"]	Atque fuga laborum ipsa perferendis occaecati officia.\nVelit ipsum nostrum deleniti laboriosam commodi quibusdam voluptates quisquam optio.\nEa odio iste quos harum aliquid.\nVel deleniti minus explicabo ad dolorem commodi quo laudantium voluptates.\nPraesentium eos molestiae illum possimus quisquam veritatis.	05:00:00	22:00:00	+394239213661	Adelfo.Rallo57@yahoo.it
28	139	3	42.00	Schweinfurter Hütte	2	Ulfo Palladino	http://scary-assault.com	333.43	["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg"]	Necessitatibus molestiae qui enim dolore dolore ea ex.\nAb fugit soluta provident.	06:00:00	23:00:00	+394858783959	Polidoro.Guastella91@hotmail.com
29	140	1	115.00	Katafygio «Vardousion»	2	Agata Brumat	http://double-mechanic.net	335.00	["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]	Beatae nesciunt aut.\nVoluptates debitis nesciunt et non dolor.\nOccaecati numquam eius a quis mollitia ratione sunt.\nDolorem nobis non officiis velit officiis quibusdam officia provident.\nEa cumque vitae.	01:00:00	21:00:00	+391658979809	Lorena_Fuoco25@hotmail.com
30	141	8	48.00	Kocbekov dom na Korošici	2	Sostene Borgia	http://closed-vicinity.it	294.63	["/static/images/e44a5c11-f2a2-4f3e-8c53-af9957e1ea11.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg"]	Expedita alias ipsam quia mollitia sint.\nAccusantium iure voluptas facere accusantium iste fugit animi excepturi sequi.\nAdipisci dolore cum architecto.\nLibero voluptatum repellendus odio perspiciatis corporis laudantium et accusamus commodi.\nUnde itaque sint quae doloribus necessitatibus quidem.	07:00:00	22:00:00	+394173425592	Graziano8@yahoo.it
31	142	3	68.00	Planinski dom Rašiške cete na Rašici	2	Birino Manzo	https://ultimate-melody.com	336.48	["/static/images/0bcb87eb-9a35-47b2-b9e5-eaae9723f0a3.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg"]	Explicabo cupiditate quia deserunt soluta facere quasi aliquam.\nSit doloremque excepturi.\nAut totam occaecati recusandae.\nSequi ipsum qui velit provident.	01:00:00	22:00:00	+397748548035	Onofrio31@yahoo.com
32	143	3	102.00	Prešernova koca na Stolu	2	Santo Lupica	http://worst-can.it	280.27	["/static/images/480257c1-8fac-4019-a612-6b46ce1a2eb3.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg"]	Nam in inventore animi.\nPariatur rerum eum est alias necessitatibus.\nOfficiis libero vero voluptatibus.\nVero vero eum praesentium vero iure.\nVero tempora dolorem incidunt itaque suscipit.	05:00:00	23:00:00	+396942892320	Aristione_Sammartino@yahoo.com
33	144	8	50.00	Planinski dom na Mrzlici	2	Saba Pucci	https://mountainous-migration.com	321.24	["/static/images/3ab7353d-3916-4811-8265-1e83602ade8c.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]	Consectetur sapiente eius.\nLaborum vel accusantium consequatur at deleniti libero consequatur.\nRepudiandae expedita corporis doloribus molestiae possimus deserunt similique.	06:00:00	23:00:00	+391164885829	Gaspare_Licciardello77@yahoo.com
34	145	4	108.00	Koca na Planini nad Vrhniko	2	Concetta Porcu	https://ironclad-donut.it	282.98	["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]	Corrupti fuga accusantium nostrum.\nCorporis ab dignissimos fuga culpa nulla vero.	05:00:00	18:00:00	+394122139347	Odetta42@gmail.com
35	146	2	40.00	Zavetišce gorske straže na Jelencih	2	Novella Barretta	http://spectacular-laparoscope.org	338.47	["/static/images/480257c1-8fac-4019-a612-6b46ce1a2eb3.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg"]	Reprehenderit laboriosam optio quia hic ullam fugit.\nSunt cumque blanditiis.\nIllum tempora sed.	07:00:00	21:00:00	+392679657484	Nostriano.Ceccarini@yahoo.com
36	147	8	40.00	Planinski dom na Gori	2	Ing. Fabiano De Martino	https://finished-main.it	293.86	["/static/images/cd0b41d9-e5d2-47d3-8863-fe201a9b9f0e.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg"]	Sequi culpa aliquid illum.\nAccusamus quas aliquid ullam dicta.	09:00:00	21:00:00	+397454390566	Generosa3@yahoo.it
37	148	4	62.00	Bregarjevo zavetišce na planini Viševnik	2	Ulfa Maggiore	https://dual-temporariness.com	318.08	["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg"]	Iure sequi aliquam eius ducimus eveniet omnis rem.\nVoluptates consequatur enim fuga.\nQuia officiis fugiat itaque delectus blanditiis.\nQuibusdam enim similique rem placeat veritatis saepe est autem eos.	07:00:00	22:00:00	+390362983455	Gianmaria.Tataranni@hotmail.com
38	149	2	113.00	Koca pod Bogatinom	2	Dr. Amone Volpi	https://rural-moonshine.net	303.45	["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg"]	Doloribus quibusdam cum.\nVero illo neque.\nNam at saepe.\nFugiat mollitia animi ratione accusamus sed quidem blanditiis aperiam.\nVoluptate sunt voluptatum voluptatibus suscipit corporis sit quis.	05:00:00	18:00:00	+394324399016	Santo_Mastrogiacomo@yahoo.it
39	150	1	38.00	Pogacnikov dom na Kriških podih	2	Nina Castellani	https://official-malnutrition.org	271.31	["/static/images/76af67a0-a788-48d2-8882-e0b626b8cd9f.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg"]	Similique eum hic ipsam.\nVel libero omnis hic exercitationem omnis nemo impedit.\nQuis amet mollitia quasi soluta dolore qui quo esse.\nModi totam dolorum sed neque in ipsum rerum consequatur.	09:00:00	19:00:00	+390347268031	Taziano_Lelli@yahoo.it
40	151	6	58.00	Dom na Smrekovcu	2	Carlotta Pavan	https://putrid-saxophone.it	269.39	["/static/images/480257c1-8fac-4019-a612-6b46ce1a2eb3.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]	Pariatur id dignissimos quaerat id reiciendis repellat laborum.\nAt officiis sed omnis delectus voluptatibus possimus inventore sed.\nSunt hic esse.	05:00:00	20:00:00	+390135476988	Iago_Masucci@yahoo.com
41	152	5	91.00	Refuge Du Chatelleret	2	Acacio Carlino	http://energetic-knock.com	324.41	["/static/images/480257c1-8fac-4019-a612-6b46ce1a2eb3.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg"]	Commodi itaque error vel vitae eveniet amet saepe quidem.\nIllum consequatur officiis suscipit illo unde deserunt veritatis vel.\nDolores inventore eveniet id illum omnis ut libero dignissimos.	05:00:00	23:00:00	+398280220419	Vidiano37@gmail.com
42	153	6	134.00	Refuge De Chalance	2	Carolina Adami	http://jovial-contest.com	314.35	["/static/images/cd0b41d9-e5d2-47d3-8863-fe201a9b9f0e.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg"]	Quia fugiat ducimus ex esse.\nOdio ipsam architecto occaecati veniam vel iste exercitationem possimus a.\nDoloribus nam vitae odio veritatis fuga.	07:00:00	20:00:00	+396306415708	Novella.Procopio@libero.it
43	154	2	111.00	Refuge Des Bans	2	Endrigo Paolella	https://scaly-sidestream.org	262.08	["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg"]	Perspiciatis similique ullam doloribus nobis.\nPorro neque totam aperiam quod laboriosam praesentium quos.\nFuga in velit numquam delectus esse natus nam unde illum.\nLaboriosam totam temporibus blanditiis minima vel modi culpa.\nMollitia ipsa aperiam illum quidem nesciunt tenetur.	06:00:00	19:00:00	+394369987471	Marzio.Patriarca@yahoo.com
44	155	7	94.00	Refuge De Pombie	2	Ausilia Marano	http://unconscious-keep.org	286.26	["/static/images/0bcb87eb-9a35-47b2-b9e5-eaae9723f0a3.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]	Quidem modi tempore.\nDebitis distinctio excepturi soluta.\nNihil a quod reiciendis repellat.\nAsperiores repellat aliquam ipsam distinctio debitis ullam sunt.\nAt ea dolore sequi ducimus quaerat qui dignissimos delectus.	01:00:00	21:00:00	+393732228797	Anastasia_Rossetti@hotmail.com
45	156	9	131.00	Refuge De Larribet	2	Ricario Manti	https://worn-safety.org	337.38	["/static/images/5c1d9ff4-870c-43f3-9a43-5c75839b798f.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]	Maxime asperiores assumenda error.\nEligendi debitis consectetur laborum illum corporis unde.\nQuasi iure quisquam error nisi occaecati saepe similique nostrum.\nDignissimos illo autem dolores sint labore est adipisci magni molestias.\nTenetur quidem nobis similique nemo debitis nisi laudantium.	01:00:00	22:00:00	+395256231383	Plutarco_Genchi@gmail.com
46	157	1	45.00	Refuge Du Mont Pourri	2	Sidonio Petrarca	http://awesome-dick.net	275.84	["/static/images/9632fe84-ed47-4201-8ee8-9aff4fc7bd51.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg"]	Consequatur magnam tenetur quibusdam facere ipsum labore laborum sunt laudantium.\nCumque consequuntur iste aut pariatur blanditiis veniam.\nNobis voluptates non ex animi officia numquam blanditiis ratione.\nEum natus enim amet non consequatur consectetur.	02:00:00	23:00:00	+394674086833	Alfredo28@email.it
47	158	2	49.00	Refuge De La Dent D?Oche	2	Emanuela Mautone	https://round-gander.net	281.15	["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg"]	Molestias necessitatibus ipsa provident fugiat totam illum deleniti iure.\nBeatae debitis perferendis illo eos tenetur et earum autem fugit.	05:00:00	20:00:00	+397668491490	Amone_Grassi2@yahoo.it
48	159	8	45.00	Bergseehütte SAC	2	Giacinto Melandri	http://lame-illiteracy.net	309.61	["/static/images/e44a5c11-f2a2-4f3e-8c53-af9957e1ea11.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg"]	Sint voluptatum in nobis reprehenderit sed error.\nReiciendis impedit in molestiae sint et laborum accusantium.	07:00:00	20:00:00	+398419536417	Piera16@yahoo.com
49	160	8	58.00	Bivouac au Col de la Dent Blanche CAS	2	Demetrio Pagliai	https://political-hardening.net	294.22	["/static/images/e44a5c11-f2a2-4f3e-8c53-af9957e1ea11.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg"]	Cumque dolores fugit amet cupiditate maxime deserunt.\nAccusantium facere nostrum in dignissimos facilis nesciunt.\nCupiditate molestias assumenda voluptatem impedit facere eos.\nNobis at amet.	09:00:00	22:00:00	+397315727528	Tabita.Vaccaro@hotmail.com
50	161	5	117.00	Salbitschijenbiwak SAC	2	Ilario Zanotti	https://hollow-anywhere.org	311.22	["/static/images/013a52c4-de83-4844-b30f-ecdbdd87bcd2.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg"]	Provident at consequuntur consequatur cupiditate.\nIn neque consectetur qui vero optio ea assumenda accusantium sint.\nRepellendus possimus placeat.	04:00:00	22:00:00	+398739265585	Aronne.Giovannini@email.it
51	162	2	106.00	Spannorthütte SAC	2	Aurelia Molteni	https://unusual-spiritual.net	261.88	["/static/images/e44a5c11-f2a2-4f3e-8c53-af9957e1ea11.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg"]	Corporis minima voluptates quae saepe nihil laboriosam sunt itaque.\nDicta velit dolor fugit perspiciatis ipsa sit minima velit beatae.	06:00:00	21:00:00	+398899290828	Garimberto.Mirabella@hotmail.com
52	163	6	90.00	Cabane Arpitettaz CAS	2	Dr. Felice Guarino	https://klutzy-wheat.com	310.87	["/static/images/0bcb87eb-9a35-47b2-b9e5-eaae9723f0a3.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg"]	Saepe aspernatur aspernatur repudiandae expedita maiores.\nDolore veritatis dolorem eius aliquam placeat ipsam voluptatibus deserunt quisquam.\nExcepturi iusto esse aspernatur quis nam.	03:00:00	18:00:00	+393715239938	Ultimo1@yahoo.it
53	164	6	63.00	Refugio De Lizara	2	Livino Zaccaro	https://insubstantial-glass.net	278.21	["/static/images/23225d35-5350-4600-89d5-7c01fd116f1d.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]	Ad nisi laborum asperiores facilis.\nOfficia quo impedit quis voluptate temporibus.\nDicta ex voluptatum soluta labore.	09:00:00	18:00:00	+396531561043	Fidenziano.Pollina@email.it
54	165	4	133.00	Albergue De Montfalcó	2	Morgana Sabbatini	http://unused-modernist.org	261.49	["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg"]	Similique quis tempore deleniti non hic enim.\nMinus magnam at possimus deserunt.\nSunt consequatur ducimus aliquam.\nEveniet vero nisi ex voluptate ad porro quae esse ducimus.\nConsequatur laudantium rerum dolor accusamus.	03:00:00	20:00:00	+397177020397	Omar.Capriotti@yahoo.it
55	166	9	57.00	El Molonillo/Peña Partida	2	Ing. Seconda Addari	http://french-spider.com	295.44	["/static/images/0bcb87eb-9a35-47b2-b9e5-eaae9723f0a3.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg"]	Occaecati id minus rerum at delectus eos.\nAlias quo dolorem.	09:00:00	20:00:00	+399996735186	Giusto52@hotmail.com
56	167	4	38.00	La Campiñuela	2	Alma Cannata	http://glum-solitaire.com	277.03	["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg"]	Quos eos vel architecto officia molestias ea ad.\nEum minus doloribus eum explicabo facilis saepe.\nDolore blanditiis labore.\nAspernatur fugit quia.\nNam reiciendis pariatur omnis impedit voluptate.	07:00:00	19:00:00	+397643869307	Omero22@email.it
57	168	1	51.00	Titov Vrv	2	Iginio Adami	http://definite-macaw.org	323.22	["/static/images/814e2adf-d56e-4afd-9b9a-5c9e93c9bab6.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]	Perferendis similique nam esse consequatur earum dolorem eaque nemo.\nLaudantium tempore incidunt nisi voluptate at excepturi sequi suscipit.	02:00:00	22:00:00	+399327334120	Bonaventura_Moretti@gmail.com
58	169	10	120.00	Rifugio Franchetti	2	Guenda Castagna	http://fast-guilder.org	320.84	["/static/images/814e2adf-d56e-4afd-9b9a-5c9e93c9bab6.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]	Soluta dolorum autem alias tempora excepturi neque recusandae totam.\nArchitecto minus possimus modi repellendus eligendi facilis.\nEius magnam iusto ex perspiciatis dolore corporis.\nExpedita eos quisquam corporis.	06:00:00	21:00:00	+395222404924	Gisella_Nicolini24@email.it
59	170	5	125.00	Rifugio Semenza	2	Terenzio Allegretti	http://deserted-mission.net	339.12	["/static/images/013a52c4-de83-4844-b30f-ecdbdd87bcd2.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg"]	Natus architecto quisquam nostrum nostrum vel consequatur voluptate quisquam quod.\nQuisquam error aperiam esse animi fuga aliquid ipsum ipsum perspiciatis.\nVeniam recusandae earum possimus totam illum voluptatibus quaerat reprehenderit.	04:00:00	20:00:00	+395257024127	Ursino_Tomassoni67@yahoo.it
60	171	2	87.00	Rifugio Città di Mortara 	2	Agata Repetto	http://misguided-poverty.it	325.45	["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg"]	Ipsam natus sequi blanditiis animi.\nAt laboriosam commodi magni illum recusandae necessitatibus mollitia laudantium id.\nQuia libero expedita iusto quia quos ipsa quaerat.\nIllo excepturi totam soluta architecto.	06:00:00	19:00:00	+393331854002	Elita63@gmail.com
61	172	5	124.00	Rifugio Andolla	2	Pierluigi De Chiara	https://aching-grandma.net	330.07	["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg"]	Possimus dolores delectus.\nOdit necessitatibus nemo quis porro nobis ullam nesciunt soluta.	09:00:00	23:00:00	+390821627444	Alfonsa.Olivieri27@email.it
62	173	10	115.00	Rifugio Forte dei Marmi	2	Armida Accardi	http://abandoned-borrower.com	335.72	["/static/images/0bcb87eb-9a35-47b2-b9e5-eaae9723f0a3.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg"]	Aliquid iste officiis consectetur modi.\nExercitationem ducimus possimus laborum.	02:00:00	21:00:00	+390130515072	Lidia.Marchesi@email.it
63	174	6	108.00	Rifugio Berti	2	Mattia Castaldi	https://shy-processor.it	313.30	["/static/images/23225d35-5350-4600-89d5-7c01fd116f1d.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg"]	Tempora consectetur similique iusto molestiae.\nDistinctio voluptatem odit veniam quasi reiciendis adipisci laborum alias.	01:00:00	18:00:00	+390440857293	Beato_Caporaso82@yahoo.it
64	175	8	88.00	Rifugio Premuda	2	Giuliana Rodigari	https://hard-to-find-lesbian.org	296.26	["/static/images/9632fe84-ed47-4201-8ee8-9aff4fc7bd51.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg"]	Dicta eveniet ea asperiores autem praesentium dolorum dolore fugit.\nConsectetur dolore nihil.\nNesciunt ab eius rem mollitia maxime dolore.\nTemporibus veniam beatae nam.	01:00:00	20:00:00	+395346463349	Verano68@hotmail.com
65	176	10	145.00	Rifugio Elisa	2	Ezechiele Musumeci	https://variable-headline.it	266.71	["/static/images/6e98325a-8ec6-4065-aa74-d713ecb47872.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg"]	Placeat asperiores aliquam nulla reprehenderit.\nRepellendus quas quas quam ratione at sapiente minima.\nDicta culpa delectus temporibus harum ducimus doloremque voluptatibus voluptate tenetur.	02:00:00	21:00:00	+397089955869	Danilo_Demontis@yahoo.com
66	177	4	134.00	Rifugio CAI Saronno	2	Onofrio De Vito	http://slimy-press.it	280.42	["/static/images/cd0b41d9-e5d2-47d3-8863-fe201a9b9f0e.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg"]	Sunt libero at.\nMaiores adipisci assumenda nemo incidunt nemo.\nDelectus nihil nesciunt animi id dolores voluptas rem.	02:00:00	22:00:00	+398764548116	Genesia70@libero.it
67	178	3	127.00	Rifugio Picco Ivigna	2	Adelaide Pucci	http://sharp-windscreen.org	279.70	["/static/images/013a52c4-de83-4844-b30f-ecdbdd87bcd2.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg"]	Consectetur quaerat aut in inventore.\nTempora libero amet debitis possimus eaque cum debitis.	08:00:00	23:00:00	+396369377632	Fiorenziano_Preziosi39@gmail.com
68	179	5	54.00	Rifugio Toesca	2	Chiara Natali	http://legal-cytoplasm.it	270.50	["/static/images/6e98325a-8ec6-4065-aa74-d713ecb47872.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg"]	Numquam possimus optio nam quo animi nisi.\nVelit unde praesentium fuga saepe eum doloremque vitae nobis.\nReiciendis mollitia ipsum ratione asperiores inventore quia ex reiciendis dolor.\nFacilis modi dicta repellat ratione ad.	04:00:00	21:00:00	+398217330600	Druina_Satta61@email.it
69	180	1	131.00	Rifugio Al Cedo	2	Aquilino Corradini	https://decisive-veranda.net	305.01	["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg"]	Aspernatur necessitatibus quia odio.\nUt repellendus quas hic quaerat.\nArchitecto iure magni quos excepturi ipsa.\nIusto omnis fuga reprehenderit ipsa officia non deleniti perspiciatis libero.	04:00:00	18:00:00	+393691213605	Alda.Talarico8@libero.it
70	181	7	53.00	Capanna Gnifetti	2	Ramiro Alessi	https://sarcastic-trout.org	303.86	["/static/images/9632fe84-ed47-4201-8ee8-9aff4fc7bd51.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg"]	Eius at deleniti nobis cumque.\nDeserunt iusto maiores adipisci esse.\nIncidunt expedita doloremque dolore maxime asperiores.\nVeritatis similique saepe nisi delectus architecto sit rerum similique ea.	06:00:00	19:00:00	+396000047541	Zetico_Cavallini67@yahoo.it
71	182	9	145.00	Rifugio Aosta	2	Ciriaco Giannini	https://intent-speculation.net	291.76	["/static/images/cd0b41d9-e5d2-47d3-8863-fe201a9b9f0e.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg"]	Minima suscipit error inventore vel.\nSoluta quam sapiente reprehenderit quo porro fuga.	01:00:00	21:00:00	+395161474085	Narsete.Recchia@email.it
72	183	10	140.00	Rifugio Cevedale	2	Bassilla Di Gennaro	https://french-finding.net	260.71	["/static/images/76af67a0-a788-48d2-8882-e0b626b8cd9f.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg"]	Quod quod voluptate illo quasi quisquam ullam perferendis ad.\nEsse modi tempore consequuntur nulla tempora magni eius fugiat pariatur.\nPerspiciatis esse voluptatum officia fuga maxime illo maxime doloremque optio.\nEveniet harum cum perferendis numquam omnis odio.	09:00:00	22:00:00	+391246991862	Crescente.Monaco44@libero.it
73	184	2	122.00	Rifugio Ponti	2	Elimena Severi	https://frivolous-communist.it	275.51	["/static/images/23225d35-5350-4600-89d5-7c01fd116f1d.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg"]	Fuga non facere pariatur labore totam rerum.\nAdipisci soluta nesciunt doloremque dolorum sed totam ea.\nOdio eos tempora harum necessitatibus doloribus sapiente ducimus asperiores quos.\nQuisquam unde adipisci molestiae accusamus dolor vitae architecto quasi possimus.\nNostrum saepe id.	05:00:00	20:00:00	+396178223404	Amauri41@gmail.com
74	185	5	46.00	Rifugio XII Apostoli	2	Fiore Grange	https://ancient-intentionality.net	271.13	["/static/images/814e2adf-d56e-4afd-9b9a-5c9e93c9bab6.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg"]	Ullam labore vero consequatur ex cupiditate facilis unde.\nMinima neque expedita provident iusto maiores expedita doloribus.	02:00:00	23:00:00	+396569328469	Ianira_Rauso35@yahoo.com
75	186	10	65.00	Rifugio Elisabetta Soldini	2	Basilia Traini	https://petty-trophy.com	277.64	["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]	Quas accusamus maxime.\nAsperiores mollitia et veniam possimus eos perspiciatis mollitia impedit unde.\nCupiditate error fugit.	06:00:00	20:00:00	+390003723108	Festo_DeGiorgi22@yahoo.com
76	187	2	54.00	Rifugio Denza	2	Onorina Marelli	https://soulful-seeker.com	283.40	["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]	Vero sed reiciendis deleniti omnis quia praesentium harum officia.\nDebitis architecto delectus totam.\nIllo ipsam ullam.	09:00:00	18:00:00	+390538280776	Cipriano37@yahoo.com
77	188	6	128.00	Rifugio Fonte Tavoloni 	2	Matroniano Balsamo	http://equatorial-land.it	302.58	["/static/images/3ab7353d-3916-4811-8265-1e83602ade8c.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg"]	Eligendi et quis quia.\nMaiores modi neque sapiente voluptas.\nAliquid deserunt quibusdam eligendi corrupti.\nItaque libero officia earum assumenda.\nPariatur atque repellat iste blanditiis facere neque quod voluptatem.	04:00:00	22:00:00	+397609177401	Arcadio_Zunino@libero.it
78	189	5	69.00	Rifugio Carducci	2	Cristoforo Piazzolla	https://illustrious-saviour.net	269.96	["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg"]	Enim non atque voluptatum sit quae sunt sequi at vitae.\nNulla nobis rerum delectus mollitia ullam excepturi repellendus facilis.\nEligendi quia dolorem illo voluptatum quam asperiores quos accusantium cupiditate.	06:00:00	21:00:00	+391353844816	Claudia.Forconi@libero.it
79	190	2	75.00	Rifugio Bindesi	2	Dr. Aurelio Guarneri	http://false-associate.net	303.94	["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]	Rem modi perferendis perferendis error voluptate fugit harum.\nCupiditate doloribus tempore.\nMinus eveniet maiores temporibus minus explicabo iste ex ipsum aut.\nIusto rerum deleniti illo.	02:00:00	20:00:00	+390032342571	Climaco73@email.it
80	191	6	69.00	Mountain hut Miroslav Hirtz	2	Dott. Cinzia Fuoco	http://equatorial-hearsay.org	279.36	["/static/images/3ab7353d-3916-4811-8265-1e83602ade8c.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg"]	Accusantium quidem officiis exercitationem iste numquam culpa at.\nLibero nesciunt perspiciatis eaque voluptas asperiores libero consequatur.\nRatione itaque minima excepturi similique.\nNobis repellat ex enim debitis ex quis necessitatibus.	04:00:00	20:00:00	+394358762209	Romolo_Critelli@gmail.com
81	192	4	44.00	Koca na Blegošu	2	Glauco Mazzotti	https://classic-trailpatrol.com	262.56	["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]	Sapiente ut perferendis earum accusamus at mollitia sed temporibus mollitia.\nQui pariatur alias iure unde est.\nRepellat ipsum atque quam occaecati.\nAmet deleniti eius.	02:00:00	18:00:00	+393871477417	Veriana_Terlizzi25@gmail.com
82	193	3	147.00	Wittener Hütte	2	Dr. Fermiano Colonna	http://yummy-engine.com	312.39	["/static/images/4b4ed22c-46cd-4422-97fe-683905feeaa6.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg"]	Soluta nesciunt repellat provident.\nIusto ullam corporis voluptatem velit fugiat recusandae ab porro.	09:00:00	18:00:00	+398967440142	Aresio16@hotmail.com
95	206	5	64.00	Monte-Leone-Hütte SAC	2	Saffiro Genovese	https://tired-bank.it	335.76	["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/cccf4526-94e2-49ea-87e4-79c79c2c2b98.jpg"]	Distinctio quia nisi laboriosam architecto optio maiores consectetur.\nDolorem delectus officiis perspiciatis.\nVelit eum sequi dicta vitae perspiciatis vitae.	06:00:00	19:00:00	+393477567038	Alano_Beso31@yahoo.com
83	194	9	42.00	Hochjoch-Hospiz	2	Tamara Monti	http://remarkable-baobab.it	308.77	["/static/images/23225d35-5350-4600-89d5-7c01fd116f1d.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg"]	Inventore explicabo quod sint tempora quo.\nVitae eaque quis accusantium vero quos cumque ut ut excepturi.\nMollitia quam quod possimus necessitatibus incidunt occaecati ab.\nSit quam nulla.\nEx tempore voluptas culpa non enim dolor labore officiis.	06:00:00	21:00:00	+398570702877	Germano.Tufo9@hotmail.com
84	195	4	67.00	Meilerhütte	2	Fazio Scaglione	https://untried-barrel.it	332.86	["/static/images/d03cf932-28ff-418b-8c01-cbe9b3595a42.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]	At consequuntur amet nesciunt delectus adipisci illum ducimus incidunt.\nSimilique ad quos ea eveniet exercitationem.\nIpsa nulla soluta laboriosam laudantium occaecati iusto eum dolorum omnis.\nPossimus vitae pariatur reprehenderit totam ullam laudantium temporibus delectus.\nDolorem ullam cupiditate et explicabo fugit mollitia porro.	09:00:00	20:00:00	+390627771590	Iole.Moras@yahoo.com
85	196	1	80.00	Gaudeamushütte	2	Simone Musumeci	http://optimal-tempo.org	308.93	["/static/images/0cf0a68d-353d-483a-96c2-e705ff3a0aff.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg"]	Eos veniam fuga iusto deserunt incidunt ad velit temporibus.\nDelectus quis eveniet veniam.\nMagnam suscipit tempora tempore excepturi vero.\nCommodi quisquam tempora quo ab consequatur quaerat.	09:00:00	22:00:00	+391234688900	Geronzio4@yahoo.com
86	197	8	43.00	Rheydter Hütte	2	Veriana Riccobono	https://cheery-helicopter.com	287.87	["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg"]	Incidunt ad neque maxime molestias sit.\nHic error alias repellendus facilis.\nImpedit tempora ipsum pariatur ad voluptatem cum dolorum.\nVoluptas delectus ea ullam molestias esse.\nOdio illum laboriosam saepe.	03:00:00	19:00:00	+398824825208	Concetto2@hotmail.com
87	198	8	56.00	Sektionshütte Krippen	2	Glenda Addis	https://wan-icon.it	263.75	["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]	In sed et unde optio.\nSuscipit eius praesentium placeat quis provident porro reiciendis.	06:00:00	22:00:00	+399998330377	Rufina.Argiolas2@libero.it
88	199	9	74.00	Neunkirchner Hütte	2	Alda Tomaselli	http://watchful-inglenook.net	310.18	["/static/images/9632fe84-ed47-4201-8ee8-9aff4fc7bd51.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg"]	Nesciunt in nemo aspernatur odio quidem consequuntur consequuntur.\nQuis quis minima pariatur enim temporibus dolore sunt iusto nihil.\nIllo non ut.	01:00:00	21:00:00	+399169950321	Romana.Santo@gmail.com
89	200	8	115.00	Refugio De Riglos	2	Orsola Moser	https://triangular-statin.org	321.75	["/static/images/1f305bc5-4442-4ac6-9b41-61a1f7b5c2fe.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg"]	Reiciendis doloremque eius ipsa nihil consequuntur nemo suscipit tempora culpa.\nCorrupti ullam natus quo quas qui sunt odit.	07:00:00	21:00:00	+398122893108	Noemi_Gatta@email.it
90	201	7	41.00	Salbithütte SAC	2	Mario Ingrassia	http://reckless-meridian.net	331.08	["/static/images/76af67a0-a788-48d2-8882-e0b626b8cd9f.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]	Illo voluptatum nihil accusantium dolorum.\nEos facere odit.\nAmet illo quaerat deserunt.\nQuibusdam quo voluptas maxime.\nVelit sapiente quisquam.	01:00:00	20:00:00	+396727668897	Tulliano13@hotmail.com
91	202	10	116.00	Finsteraarhornhütte SAC	2	Laura Pianese	https://naive-diversity.org	292.97	["/static/images/e25caa47-16e0-4d5a-81f8-0f6a69499027.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg"]	Quam illo ad numquam debitis.\nAccusamus aspernatur ab labore cumque cupiditate officia explicabo vel excepturi.\nRerum pariatur vel.	01:00:00	22:00:00	+393450809501	Simona.Cecchetti27@yahoo.com
92	203	5	68.00	Cabane des Vignettes CAS	2	Rosalinda Manzella	http://equal-guerrilla.com	307.27	["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]	Temporibus enim ea commodi.\nAliquam eos amet.\nQuisquam quia debitis unde earum commodi omnis cum ex autem.	07:00:00	18:00:00	+396361685040	Aciscolo_Olivieri@email.it
93	204	8	75.00	Glecksteinhütte SAC	2	Godiva Papini	https://sharp-lifetime.org	273.57	["/static/images/5c1d9ff4-870c-43f3-9a43-5c75839b798f.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]	Quam tenetur nihil suscipit voluptas minus ex.\nError atque nobis modi tempora.\nVelit est eum.\nSequi et culpa atque.\nMagnam ut quisquam debitis asperiores culpa veritatis fugiat eveniet.	02:00:00	22:00:00	+394888964053	Maura_Santarossa52@libero.it
94	205	4	130.00	Länta-Hütte SAC	2	Ada Filippi	http://dear-tailspin.it	320.23	["/static/images/e25caa47-16e0-4d5a-81f8-0f6a69499027.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg"]	Incidunt nesciunt porro.\nUnde dicta quis repudiandae.	05:00:00	20:00:00	+394109271673	Arrigo56@libero.it
96	207	5	72.00	Ringelspitzhütte SAC	2	Dott. Oronzo Brizzi	http://idiotic-standing.it	338.22	["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg", "/static/images/1e20cc28-fba0-40e9-8470-cc6636516253.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg"]	Eaque sapiente incidunt.\nDeleniti vel temporibus aut distinctio.\nMolestiae esse amet vitae.	07:00:00	19:00:00	+398643484528	Generosa7@email.it
97	208	1	148.00	Na poljanama Maljen	2	Lucia Salvatore	http://straight-plaster.com	310.19	["/static/images/76af67a0-a788-48d2-8882-e0b626b8cd9f.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]	Neque cumque minus optio temporibus laudantium non.\nIllo laborum quasi cumque delectus magni hic assumenda explicabo corporis.\nPossimus numquam iste perspiciatis eligendi omnis dicta corrupti.	07:00:00	23:00:00	+397254767486	Amando_Ferrante@libero.it
98	209	9	46.00	Dobra voda	2	Geronimo Zunino	http://sneaky-sprout.org	264.89	["/static/images/a3cbcbb1-626f-4d51-b70a-dbc51b049e31.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg"]	Ab ad velit odit ea corrupti.\nDolore maiores totam unde enim aspernatur odit alias.\nDignissimos qui delectus aliquam pariatur hic incidunt consectetur laborum.\nOdio placeat qui vel.\nUnde esse sed commodi alias quibusdam.	09:00:00	21:00:00	+393581006816	Siriano_Santucci@libero.it
99	210	8	105.00	Ivanova hiža	2	Raimondo Gullì	https://poor-woman.com	323.81	["/static/images/5c1d9ff4-870c-43f3-9a43-5c75839b798f.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg"]	Voluptatum iusto corrupti reiciendis.\nLaudantium tempora temporibus rem praesentium rem voluptas.\nRepudiandae similique commodi commodi.\nTenetur alias ipsum repellat quisquam animi.\nVeniam minima voluptatem.	04:00:00	18:00:00	+397311931425	Pierluigi.Festa32@hotmail.com
100	211	2	101.00	Glavica	2	Lorella Marsella	http://nutritious-spirit.net	274.00	["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/5e54d2ac-610e-45c6-80f1-ff079d3ed9c0.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg"]	Facere perferendis aperiam vitae occaecati.\nExercitationem animi illum quos a quam.\nQuaerat ducimus repellat nam unde deserunt voluptate nisi quidem.\nNon cumque ut.\nCorrupti aspernatur ab numquam iusto.	04:00:00	19:00:00	+390158067793	Esuperio.Milano@yahoo.it
101	212	2	112.00	Trpošnjik	2	Venanzio Palombi	http://composed-obligation.it	333.59	["/static/images/480257c1-8fac-4019-a612-6b46ce1a2eb3.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/d9432a3e-ea81-4d76-b15f-dcc785e033ce.jpg"]	Corporis dolorem quasi similique ullam sed.\nNam numquam harum quia at et minus doloribus eos.\nEos repellat placeat quaerat rerum consectetur temporibus repellat animi incidunt.\nBeatae nostrum necessitatibus recusandae inventore magni eius quo.\nEnim voluptate odio magni cupiditate error eum recusandae.	04:00:00	23:00:00	+394646328053	Lanfranco_Piazzolla32@yahoo.com
102	213	5	46.00	Bitorajka	2	Renato Valletta	https://candid-crush.org	264.28	["/static/images/8b772aee-67bf-4ad8-bbfd-28b98717e916.jpg", "/static/images/9bc5b719-84be-447e-8b5c-d6642eba26fb.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/4cb0c79a-0f47-4b47-a03c-8c396f05d115.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg"]	Ut aperiam qui dolore rem eveniet tempore a.\nCum in sed consequatur praesentium vel consectetur officiis doloribus ea.\nConsequuntur architecto voluptates quas suscipit.	04:00:00	19:00:00	+395055367502	Felicita.Pianese@libero.it
103	214	6	118.00	Zlatko Prgin	2	Bardo Annunziata	http://ultimate-eel.org	323.38	["/static/images/5c1d9ff4-870c-43f3-9a43-5c75839b798f.jpg", "/static/images/b80565f8-98eb-4780-b51e-e8a8c49060b5.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/86c4ed63-e889-4b4e-8d08-90094301a20e.jpg"]	Animi corrupti necessitatibus illo cupiditate soluta ipsum accusantium aliquam earum.\nLaudantium eum repellat ad architecto ea repudiandae odio.\nIllum deserunt nihil atque.\nAssumenda enim laboriosam pariatur quasi eos dolores eum aut aliquid.\nSoluta quia delectus quia aspernatur voluptatibus.	07:00:00	21:00:00	+394818254575	Melitina22@email.it
104	215	2	58.00	Prpa	2	Ing. Alba Palombi	https://authorized-login.org	331.88	["/static/images/4b4ed22c-46cd-4422-97fe-683905feeaa6.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg"]	Officiis totam sunt itaque voluptatem autem animi nobis incidunt.\nSit eos ipsum porro itaque aperiam adipisci corporis voluptatum.	05:00:00	22:00:00	+394756266329	Pauside48@yahoo.com
105	216	5	66.00	Ždrilo	2	Stefano Spagnolo	https://vast-crackers.it	305.83	["/static/images/4b4ed22c-46cd-4422-97fe-683905feeaa6.jpg", "/static/images/7dd631d6-ac70-4365-9e62-7b97ba80b814.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg", "/static/images/fc5d967d-a93e-4211-84d0-97a3509743fe.jpg", "/static/images/9f884552-7f33-4e46-9b7b-9ea939ff149c.jpg"]	Error debitis cupiditate atque aut quam perspiciatis qui aut.\nPerferendis dolorum nemo.\nEx enim laborum temporibus vitae quis.\nAd non rerum aspernatur error est.\nItaque dignissimos praesentium facere doloremque velit quidem natus.	08:00:00	19:00:00	+396707427725	Telica_Bosco@email.it
106	217	8	73.00	Miroslav Hirtz	2	Dott. Liliana Pompilio	https://fond-gateway.net	291.30	["/static/images/6e98325a-8ec6-4065-aa74-d713ecb47872.jpg", "/static/images/4c050817-ef31-423e-9153-d494a8cf8dbf.jpg", "/static/images/57e7755e-48ee-4d8d-afd6-592ebd1c5169.jpg", "/static/images/50a03201-f1a8-49b7-939a-b2e03a00bbe1.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg"]	Fugiat hic necessitatibus animi architecto consectetur provident saepe.\nBlanditiis ea nemo eius animi.\nFugiat atque nostrum molestiae repudiandae veniam voluptate magni.\nCupiditate inventore sed tempora illo nemo officiis aperiam voluptate magni.\nDistinctio sit non doloremque corrupti assumenda ea accusamus.	05:00:00	18:00:00	+399543470816	Saverio_Mulas14@yahoo.it
107	218	10	45.00	Jezerce	2	Geronzio Fusco	https://mountainous-courtroom.com	302.02	["/static/images/1a908c11-07ca-4309-96e0-f49141c6d48a.jpg", "/static/images/e0f703b9-4eb6-464e-a19c-79b82cc5751c.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/b8aa336d-b0d5-4553-8352-2539330ba809.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg"]	Iste libero dolores iusto error illo consequuntur iure a.\nEaque accusamus veniam alias magnam accusamus dolores minima.\nVel aliquam repellendus quae enim eveniet praesentium voluptas ut tenetur.\nOdio at quod nesciunt tempora nobis sapiente.	03:00:00	19:00:00	+397668505733	Elena_LoGiudice0@gmail.com
108	219	9	130.00	Ivica Sudnik	2	Amabile Adami	https://unwitting-triad.org	281.47	["/static/images/0cf0a68d-353d-483a-96c2-e705ff3a0aff.jpg", "/static/images/1c5fb59a-3283-4801-8ff2-05509a1a61d6.jpg", "/static/images/4a5ba5b0-2bd5-4799-98a7-65c15ad2e6b5.jpg", "/static/images/16ad8da8-5022-4950-9a04-7f9ee45d3f07.jpg", "/static/images/c3d47544-fc6d-46e7-9d46-45d42c4922c0.jpg"]	Sint eaque libero ab repellat incidunt cupiditate dolores excepturi.\nMinus accusamus aliquam accusantium voluptates enim totam.\nAccusamus recusandae asperiores.	04:00:00	21:00:00	+398070796038	Elettra.DErrico@yahoo.it
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
1	220	72	2	Italy	Ascoli Piceno		Settimo Zaccheo calabro
2	221	214	2	Italy	Asti		Ragone a mare
3	222	154	2	Italy	Caserta		Palladio ligure
4	223	163	2	Italy	Ferrara		Settimo Vidiano umbro
5	224	183	2	Italy	Prato		Quarto Tiburzio
6	225	66	2	Italy	Trento		Marsella nell'emilia
7	226	228	2	Italy	Campobasso		Quarto Alvise sardo
8	227	44	2	Italy	Varese		Marciano umbro
9	228	194	2	Italy	Messina		Quarto Italia umbro
10	229	285	2	Italy	Vibo Valentia		Ansovino veneto
11	230	56	2	Italy	Alessandria		Testa a mare
12	231	150	2	Italy	Parma		Viliana ligure
13	232	173	2	Italy	Rieti		Massari lido
14	233	211	2	Italy	Reggio Emilia		Settimo Livia
15	234	60	2	Italy	Brindisi		Iginia del friuli
16	235	300	2	Italy	Medio Campidano		Bambina nell'emilia
17	236	137	2	Italy	Genova		Casula nell'emilia
18	237	124	2	Italy	Frosinone		Quarto Alberta veneto
19	238	157	2	Italy	Verona		San Menardo sardo
20	239	148	2	Italy	Chieti		Duilio terme
21	240	110	2	Italy	Siracusa		Cipolla del friuli
22	241	139	2	Italy	Torino		Visconti veneto
23	242	6	2	Italy	Cremona		Bianchi ligure
24	243	71	2	Italy	Cremona		Borgo Germana nell'emilia
25	244	33	2	Italy	Barletta-Andria-Trani		Azara salentino
26	245	156	2	Italy	Modena		San Teresa terme
27	246	59	2	Italy	Savona		Settimo Petronilla
28	247	287	2	Italy	Campobasso		Addolorata ligure
29	248	192	2	Italy	Catanzaro		Borgo Prudenzio
30	249	158	2	Italy	Bologna		Ottonello laziale
31	250	97	2	Italy	Cremona		San Gumesindo terme
32	251	147	2	Italy	Medio Campidano		Gualtieri nell'emilia
33	252	108	2	Italy	Enna		Settimo Letizia
34	253	5	2	Italy	Forlì-Cesena		Lotito a mare
35	254	219	2	Italy	Bergamo		Borgo Goffredo
36	255	267	2	Italy	Forlì-Cesena		Cataldo terme
37	256	44	2	Italy	Agrigento		Alessi lido
38	257	58	2	Italy	Treviso		Quarto Benedetta
39	258	71	2	Italy	Varese		Settimo Mansueto umbro
40	259	148	2	Italy	L'Aquila		Ercoli veneto
41	260	20	2	Italy	Latina		Sesto Cleopatra laziale
42	261	250	2	Italy	Rovigo		San Ladislao umbro
43	262	39	2	Italy	Modena		Sesto Cleopatra
44	263	69	2	Italy	Ogliastra		Settimo Renata veneto
45	264	116	2	Italy	Avellino		Borgo Remondo salentino
46	265	175	2	Italy	Siena		San Ionne
47	266	122	2	Italy	Aosta		Crescenzia a mare
48	267	157	2	Italy	Firenze		Salemi umbro
49	268	255	2	Italy	Pesaro e Urbino		Quarto Gioia
50	269	174	2	Italy	Novara		Croce a mare
51	270	64	2	Italy	Firenze		Marino salentino
52	271	11	2	Italy	Verbano-Cusio-Ossola		Borgo Mariella umbro
53	272	57	2	Italy	Cosenza		Quarto Alina
54	273	8	2	Italy	Lecco		Quarto Rainelda sardo
55	274	295	2	Italy	Potenza		Borgo Venusta
56	275	75	2	Italy	Pescara		Lazzarini a mare
57	276	214	2	Italy	Lecce		Borgo Tancredi del friuli
58	277	263	2	Italy	Reggio Calabria		Sesto Romilda sardo
59	278	210	2	Italy	Perugia		San Isaia
60	279	178	2	Italy	Chieti		Settimo Igino laziale
61	280	116	2	Italy	Aosta		Perna laziale
62	281	106	2	Italy	Milano		San Ghita nell'emilia
63	282	223	2	Italy	Viterbo		La Rosa sardo
64	283	244	2	Italy	Nuoro		Pichler lido
65	284	40	2	Italy	Verbano-Cusio-Ossola		Raniero del friuli
66	285	213	2	Italy	Foggia		Borgo Alfio terme
67	286	238	2	Italy	Pesaro e Urbino		Livia a mare
68	287	72	2	Italy	Biella		Quarto Baldomero
69	288	231	2	Italy	Bolzano		Borgo Godiva calabro
70	289	15	2	Italy	Pisa		Dulina laziale
71	290	95	2	Italy	Catanzaro		Barnaba salentino
72	291	221	2	Italy	Savona		Alcibiade salentino
73	292	115	2	Italy	Bergamo		Quarto Felicita calabro
74	293	295	2	Italy	Trapani		Borgo Isa
75	294	36	2	Italy	Alessandria		Lavinio veneto
76	295	77	2	Italy	Lecco		Borgo Verecondo ligure
77	296	178	2	Italy	Olbia-Tempio		Eulalia umbro
78	297	30	2	Italy	Treviso		Prospera lido
79	298	242	2	Italy	Lecce		Quarto Concetto nell'emilia
80	299	28	2	Italy	Teramo		San Melchiorre
81	300	148	2	Italy	Prato		Settimo Aresio
82	301	152	2	Italy	Caserta		San Corbiniano
83	302	273	2	Italy	Biella		Sesto Raffaele
84	303	278	2	Italy	Fermo		Settimo Giordano nell'emilia
85	304	108	2	Italy	Pistoia		Benvenuto terme
86	305	193	2	Italy	Alessandria		Settimo Orsino salentino
87	306	275	2	Italy	Perugia		Diodata sardo
88	307	76	2	Italy	Agrigento		San Clemente a mare
89	308	177	2	Italy	Vercelli		Vicari del friuli
90	309	97	2	Italy	Palermo		San Gioia calabro
91	310	63	2	Italy	Rovigo		Martorana umbro
92	311	141	2	Italy	Pesaro e Urbino		Quarto Nicoletta
93	312	74	2	Italy	Varese		Borgo Iago calabro
94	313	83	2	Italy	Roma		Romano calabro
95	314	234	2	Italy	Venezia		Recchia calabro
96	315	220	2	Italy	Foggia		Quarto Gualtiero calabro
97	316	196	2	Italy	Piacenza		Sesto Orsolina
98	317	54	2	Italy	Potenza		San Sico
99	318	43	2	Italy	Campobasso		Borgo Baldo
100	319	233	2	Italy	Udine		Sesto Ticone
101	320	221	2	Italy	Trapani		Roma
102	321	182	2	Italy	Trapani		Giordano nell'emilia
103	322	47	2	Italy	Imperia		Ettore calabro
104	323	143	2	Italy	Bolzano		Borgo Gherardo
105	324	62	2	Italy	Trieste		Cozzi a mare
106	325	137	2	Italy	Livorno		Giansante veneto
107	326	276	2	Italy	Messina		Settimo Liberto
108	327	291	2	Italy	Prato		Borgo Clarenzio sardo
109	328	168	2	Italy	Terni		Sesto Ataleo umbro
110	329	269	2	Italy	Benevento		Quarto Gioacchina
111	330	29	2	Italy	Ravenna		Sirio a mare
112	331	99	2	Italy	Crotone		Sesto Elifio
113	332	162	2	Italy	Teramo		Paolino laziale
114	333	288	2	Italy	Monza e della Brianza		Castellani veneto
115	334	53	2	Italy	Ancona		Quinzio ligure
116	335	228	2	Italy	Ascoli Piceno		Settimo Germano
117	336	36	2	Italy	Treviso		Settimo Ugolino
118	337	108	2	Italy	Prato		Irma terme
119	338	271	2	Italy	Lodi		Scarpa terme
120	339	260	2	Italy	Udine		Tavani sardo
121	340	255	2	Italy	Massa-Carrara		Famiano lido
122	341	144	2	Italy	Terni		Orlando salentino
123	342	151	2	Italy	Lecco		San Donna a mare
124	343	139	2	Italy	Lucca		Amerigo ligure
125	344	236	2	Italy	Salerno		Settimo Amadeo
126	345	76	2	Italy	Enna		Merli ligure
127	346	1	2	Italy	Benevento		Settimo Clodoveo
128	347	212	2	Italy	Lecce		Borgo Asterio laziale
129	348	110	2	Italy	L'Aquila		Borgo Babila
130	349	1	2	Italy	Pistoia		San Lorena ligure
131	350	1	2	Italy	Varese		Ferluga calabro
132	351	274	2	Italy	Belluno		Borgo Senofonte
133	352	139	2	Italy	Savona		Batilda salentino
134	353	178	2	Italy	Benevento		Sesto Berengario veneto
135	354	198	2	Italy	Campobasso		Settimo Amalia veneto
136	355	154	2	Italy	Oristano		Marina salentino
137	356	1	2	Italy	Trento		Carè terme
138	357	1	2	Italy	Bologna		Borgo Asella salentino
139	358	133	2	Italy	Terni		Satta del friuli
140	359	1	2	Italy	Forlì-Cesena		Quarto Severa
141	360	225	2	Italy	Arezzo		Bruno sardo
142	361	242	2	Italy	Alessandria		Orenzio calabro
143	362	158	2	Italy	Medio Campidano		Quarto Verecondo lido
144	363	221	2	Italy	Fermo		Zennaro terme
145	364	241	2	Italy	Roma		Marras lido
146	365	283	2	Italy	Biella		Fidenzio terme
147	366	156	2	Italy	Pisa		Quarto Amleto
148	367	262	2	Italy	Padova		Zucca umbro
149	368	228	2	Italy	Teramo		Quarto Achille del friuli
150	369	204	2	Italy	Gorizia		Giorgio veneto
151	370	175	2	Italy	Udine		Gangemi calabro
152	371	251	2	Italy	Sondrio		Settimo Emmerico
153	372	112	2	Italy	La Spezia		Lo Iacono lido
154	373	102	2	Italy	Crotone		Quarto Benigno calabro
155	374	213	2	Italy	Grosseto		Bianchi umbro
156	375	73	2	Italy	Milano		Macchi laziale
157	376	214	2	Italy	Foggia		Settimo Varo
158	377	164	2	Italy	Ancona		Sesto Gionata veneto
159	378	196	2	Italy	Viterbo		Quarto Agrippa
160	379	300	2	Italy	Trieste		San Robaldo nell'emilia
161	380	175	2	Italy	Piacenza		Settimo Marianna
162	381	288	2	Italy	Potenza		Rosa salentino
163	382	102	2	Italy	Modena		Sesto Ilario nell'emilia
164	383	71	2	Italy	Ogliastra		Borgo Isacco lido
165	384	98	2	Italy	Potenza		Fava terme
166	385	30	2	Italy	Frosinone		Mazzone a mare
167	386	161	2	Italy	Biella		Dagoberto salentino
168	387	109	2	Italy	Cremona		Sesto Elogio laziale
169	388	268	2	Italy	Forlì-Cesena		Borgo Costante nell'emilia
170	389	114	2	Italy	Chieti		Settimo Dorotea calabro
171	390	99	2	Italy	Lucca		Settimo Alina nell'emilia
172	391	241	2	Italy	Pisa		Dario ligure
173	392	214	2	Italy	Terni		Borgo Bonito nell'emilia
174	393	126	2	Italy	Lodi		Sammartino del friuli
175	394	168	2	Italy	Bologna		Settimo Ludano
176	395	150	2	Italy	La Spezia		Borgo Ionne
177	396	87	2	Italy	Pescara		Sesto Ecclesio
178	397	31	2	Italy	Forlì-Cesena		Bindi a mare
179	398	37	2	Italy	Taranto		Gonerio salentino
180	399	209	2	Italy	Teramo		Sesto Colmazio nell'emilia
181	400	197	2	Italy	Olbia-Tempio		Asdrubale calabro
182	401	111	2	Italy	Lodi		Emiliana sardo
183	402	6	2	Italy	Alessandria		Brunilde lido
184	403	196	2	Italy	Lodi		Lendinara
185	404	87	2	Italy	Napoli		San Veridiana sardo
186	405	250	2	Italy	Brindisi		Napoli
187	406	55	2	Italy	Pavia		San Gianluca a mare
188	407	267	2	Italy	Imperia		Borgo Furseo nell'emilia
189	408	83	2	Italy	Treviso		Settimo Isa terme
190	409	154	2	Italy	Pavia		Oggiano ligure
191	410	39	2	Italy	Monza e della Brianza		San Regolo
192	411	36	2	Italy	Crotone		Sebastiana nell'emilia
193	412	173	2	Italy	Rimini		Settimo Ugolino
194	413	149	2	Italy	Sondrio		Mautone nell'emilia
195	414	52	2	Italy	Enna		Moreno salentino
196	415	184	2	Italy	Siena		Cifarelli laziale
197	416	292	2	Italy	Teramo		Alviero del friuli
198	417	84	2	Italy	Perugia		Sesto Irene veneto
199	418	180	2	Italy	Nuoro		Sesto Fedora
200	419	176	2	Italy	Prato		Quarto Fortunata
201	420	37	2	Italy	Biella		Settimo Gianmarco a mare
202	421	128	2	Italy	Carbonia-Iglesias		Mora veneto
203	422	410	2	Italy	Sondrio		Evremondo ligure
204	423	113	2	Italy	Salerno		Borgo Eriberto sardo
205	424	40	2	Italy	Trapani		Settimo Didimo
206	425	206	2	Italy	Reggio Calabria		Eliano umbro
207	426	108	2	Italy	Alessandria		Borgo Agostina sardo
208	427	209	2	Italy	Imperia		La Porta del friuli
209	428	41	2	Italy	Nuoro		San Orsola terme
210	429	110	2	Italy	Reggio Emilia		San Isidora lido
211	430	247	2	Italy	Massa-Carrara		Settimo Alma ligure
212	431	72	2	Italy	Vercelli		Sesto Fiorenzo del friuli
213	432	9	2	Italy	Roma		Quarto Fosco calabro
214	433	216	2	Italy	Taranto		Vanessa terme
215	434	64	2	Italy	Campobasso		Sesto Damaso salentino
216	435	50	2	Italy	Pavia		Angelica umbro
217	436	55	2	Italy	Rimini		Settimo Alamanno
218	437	52	2	Italy	Reggio Emilia		Pichler salentino
219	438	252	2	Italy	Novara		Aleramo salentino
220	439	258	2	Italy	Ravenna		Cassio lido
221	440	166	2	Italy	Brescia		San Maddalena lido
222	441	3	2	Italy	Massa-Carrara		Quarto Afro umbro
223	442	109	2	Italy	Arezzo		Pugliesi ligure
224	443	151	2	Italy	Trieste		Quarto Egidio lido
225	444	243	2	Italy	Carbonia-Iglesias		Montanari laziale
226	445	208	2	Italy	Ragusa		San Filomeno veneto
227	446	258	2	Italy	Agrigento		Leo a mare
228	447	242	2	Italy	Bergamo		Cunegonda a mare
229	448	126	2	Italy	Aosta		San Consolata nell'emilia
230	449	133	2	Italy	Oristano		Stefania nell'emilia
231	450	292	2	Italy	Bologna		Vittoriano umbro
232	451	149	2	Italy	Isernia		Piana umbro
233	452	41	2	Italy	Roma		Borgo Fiorenziano
234	453	127	2	Italy	Mantova		San Alessandro del friuli
235	454	101	2	Italy	Bergamo		Erardo laziale
236	455	111	2	Italy	Rieti		Genesia sardo
237	456	152	2	Italy	Terni		Gillo veneto
238	457	99	2	Italy	Trapani		Costante salentino
239	458	257	2	Italy	Olbia-Tempio		Quarto Antea sardo
240	459	54	2	Italy	Rieti		San Enecone
241	460	175	2	Italy	Bologna		Settimo Giliola
242	461	106	2	Italy	Modena		Calogera veneto
243	462	96	2	Italy	Cosenza		Quarto Eligio umbro
244	463	43	2	Italy	Trento		Sesto Radolfo
245	464	109	2	Italy	Gorizia		Zennaro lido
246	465	131	2	Italy	Ravenna		Fabbri laziale
247	466	113	2	Italy	Matera		San Tullia
248	467	213	2	Italy	Catania		Reginaldo sardo
249	468	44	2	Italy	Siracusa		Settimo Cordelia
250	469	9	2	Italy	Mantova		Omar salentino
251	470	104	2	Italy	Catania		Militello a mare
252	471	38	2	Italy	Caserta		Baldo terme
253	472	35	2	Italy	Bari		San Vittoriano
254	473	264	2	Italy	Teramo		Borgo Concordio terme
255	474	188	2	Italy	Belluno		San Zabina laziale
256	475	214	2	Italy	Aosta		Quarto Cino
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address, altitude) FROM stdin;
1	0	0101000020E610000043D95E8288A91C40720950EB278D4640	Start Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
2	0	0101000020E610000051A7B8816D921C408D966B20C98C4640	End Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
3	0	0101000020E6100000C668CC0D4EA81C40DA8DB03B2C8D4640		Ref Point 1	1256.85
4	0	0101000020E6100000116FE90D01A21C4022DFF1622B8D4640		Ref Point 2	1283.61
5	0	0101000020E61000004337FB03E5161B401CEBE2361A844640	Start Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
6	0	0101000020E61000001092054CE0161B401FD8F15F20844640	End Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
7	0	0101000020E6100000910F7A36ABCE1C4029AF95D05D4C4640	Start Point	Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia	\N
8	0	0101000020E6100000FC8EE1B19FB51C40B0FECF61BE4E4640	End Point	Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia	\N
9	0	0101000020E6100000000060A24D751C40000028D7DB594640	Start Point	Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia	\N
10	0	0101000020E61000000000A08E3B6A1C400000D8486C5C4640	End Point	Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia	\N
11	0	0101000020E6100000D218ADA3AA112140B7291E17D5124740	Start Point	Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia	\N
12	0	0101000020E61000001764CBF2751121406AFAEC80EB144740	End Point	Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia	\N
13	0	0101000020E610000000004078111A1C400000981E08854640	Start Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
14	0	0101000020E61000000000A0281F1A1C400000E05411854640	End Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
15	0	0101000020E610000000004078111A1C400000981E08854640	Start Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
16	0	0101000020E61000000000A0281F1A1C400000E05411854640	End Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
17	0	0101000020E610000058CB9D9960C81B408731E9EFA59C4640	Start Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
18	0	0101000020E61000003BE0BA6246C81B401E34BBEEAD9C4640	End Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
19	0	0101000020E61000007EE4D6A4DBC21B40147AFD497C9C4640		fountain	2027.00
20	0	0101000020E6100000B7B8C667B2BF1B4090A4A487A19B4640		Peak	2131.00
21	0	0101000020E6100000E449D23593FF1A4008B0C8AF1F784640	Start Point	Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia	\N
22	0	0101000020E6100000E449D23593FF1A4008B0C8AF1F784640	End Point	Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia	\N
23	0	0101000020E6100000010060133FE51C400000DC629AA64640	Start Point	Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia	\N
24	0	0101000020E61000000100E07E80F41C400000C0086CA54640	End Point	Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia	\N
25	0	0101000020E61000000000A0E235A31C40000090BAAD5A4640	Start Point	Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia	\N
26	0	0101000020E61000000000A03601A21C40000078DBA45A4640	End Point	Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia	\N
27	0	0101000020E61000000000601346EE1B4000006C0D81494640	Start Point	SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia	\N
28	0	0101000020E6100000000000063BEE1B4000001C7B81494640	End Point	SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia	\N
29	0	0101000020E6100000000020F7999B1C40000018F79E594640	Start Point	Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
30	0	0101000020E61000000000803E6C7C1C400000004B28584640	End Point	Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
31	0	0101000020E610000001002004C9F31E400000609288234640	Start Point	Pigna - Gardiola, Chiusa di Pesio, Cuneo, Piemonte, 12088, Italia	\N
32	0	0101000020E6100000000000DC44CF1E400000B4502D214640	End Point		\N
33	0	0101000020E61000002F3196E997781C408F8D40BCAE594640	Start Point	Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
34	0	0101000020E61000009C8A54185B781C4057B08D78B2594640	End Point	Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
35	0	0101000020E61000000000209E8E4B1C4000003C6BAE844640	Start Point	Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia	\N
36	0	0101000020E6100000000080AFFC7A1C4000004CCD1C864640	End Point	Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia	\N
37	0	0101000020E6100000000000A020B91C40000074E3C0494640	Start Point	Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia	\N
38	0	0101000020E61000000000C0CE5A9F1C400000B06F46474640	End Point	Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia	\N
39	0	0101000020E610000000000030C0F21C400000005015934640	Start Point	Alpe Tulivit, Condove, Torino, Piemonte, Italia	\N
40	0	0101000020E61000000000C02BE9E01C400000442ED1964640	End Point	Alpe Tulivit, Condove, Torino, Piemonte, Italia	\N
41	0	0101000020E61000000000E04399051F40000078D59A1F4640	Start Point	Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia	\N
42	0	0101000020E61000000000A0B2D4041F400000A07A911F4640	End Point	Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia	\N
43	0	0101000020E610000000002073E0601C4000001C93C2594640	Start Point	Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia	\N
44	0	0101000020E61000000000A01680701C400000C08D37554640	End Point	Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia	\N
45	0	0101000020E61000000000C09D43D520400000CC2FB7354740	Start Point	Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia	\N
46	0	0101000020E61000000000C09D43D520400000CC2FB7354740	End Point	Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia	\N
47	0	0101000020E6100000E4BD6A65C2D720401A506F46CD114740	Start Point	Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia	\N
48	0	0101000020E61000005665DF15C1D72040C6C1A563CE114740	End Point	Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia	\N
49	0	0101000020E61000005F9A22C0E96520406C76A4FACE554640	Start Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
50	0	0101000020E61000002368CC24EA652040CC7EDDE9CE554640	End Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
51	0	0101000020E61000006B662D05A46D20401557957D57564640		Ref Point 1	482.53
52	0	0101000020E610000024D236FE44652040813D26529A554640		Ref Point 2	242.59
53	0	0101000020E6100000A06F0B96EA221D4008E6E8F17B7B4640	Start Point	Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia	\N
54	0	0101000020E61000006DE7FBA9F1221D40EF552B137E7B4640	End Point	Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia	\N
55	0	0101000020E61000009F02603C83762540D61EF64201F14640	Start Point	Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
56	0	0101000020E610000088F19A5775762540910E0F61FCF04640	End Point	Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
57	0	0101000020E6100000F435CB65A343274097530262122E4640	Start Point	5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia	\N
58	0	0101000020E61000006BD44334BA43274097530262122E4640	End Point	5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia	\N
59	0	0101000020E6100000EAE923F0877F2540EE7C3F355EE04640	Start Point	Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia	\N
60	0	0101000020E610000053CF8250DE7F254040A19E3E02E14640	End Point	Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia	\N
61	0	0101000020E610000033FE7DC6853B274059349D9D0C264640	Start Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
62	0	0101000020E61000005859DB148F3B2740001DE6CB0B264640	End Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
63	0	0101000020E610000033FE7DC6853B274059349D9D0C264640	Start Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
64	0	0101000020E61000005859DB148F3B2740001DE6CB0B264640	End Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
65	0	0101000020E6100000E82E89B3223A254036CB65A373AC4640	Start Point	Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia	\N
66	0	0101000020E61000008C9DF0129C3A2540486AA16472AC4640	End Point	Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia	\N
67	0	0101000020E610000088DA368C82402540AC02B5183CAC4640		Ref Point 1	130.12
68	0	0101000020E6100000A06B5F402F44254016C1FF56B2AB4640		Ref Point 2	139.74
69	0	0101000020E6100000527FBDC2824B2540151C5E1091AA4640		Fontain	107.32
70	0	0101000020E61000001C98DC28B2361C4032FFE89B34894640	Start Point	Cima Ciantiplagna, Strada militare del Colle dell'Assietta, Bergerie dell'Assietta, Usseaux, Torino, Piemonte, Italia	\N
71	0	0101000020E6100000EE5C18E9450D1C402FFB75A73B894640	End Point	Cima Ciantiplagna, Strada militare del Colle dell'Assietta, Bergerie dell'Assietta, Usseaux, Torino, Piemonte, Italia	\N
72	0	0101000020E6100000A0DCB6EF518725409E7E501729E44640	Start Point	Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia	\N
73	0	0101000020E610000055DD239BAB86254016342DB132E44640	End Point	Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia	\N
74	0	0101000020E6100000C3F5285C8FE21F408C9FC6BDF9894640	Start Point	Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia	\N
75	0	0101000020E610000001F8A75489E21F40F030ED9BFB894640	End Point	Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia	\N
76	0	0101000020E6100000B282DF86187F20400B47904AB1FF4640	Start Point	Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia	\N
77	0	0101000020E610000012842BA0508720400F48C2BE9D004740	End Point	Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia	\N
78	0	0101000020E6100000EAE8B81AD9E520408813984EEBFA4640	Start Point	Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia	\N
79	0	0101000020E6100000EAE8B81AD9E520408813984EEBFA4640	End Point	Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia	\N
80	0	0101000020E61000006EFC89CA86A52040D87DC7F0D87D4640	Start Point	Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia	\N
81	0	0101000020E61000009E0B23BDA8A52040B1A371A8DF7D4640	End Point	Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia	\N
82	0	0101000020E61000009F3E027FF83920409E245D33F9804640	Start Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
83	0	0101000020E610000099F56228273A20408DEDB5A0F7804640	End Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
84	0	0101000020E6100000880E81238136264090847D3B89844640	Start Point	Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia	\N
85	0	0101000020E6100000B6132521913626406AFB57569A844640	End Point	Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia	\N
86	0	0101000020E61000007A17EFC7ED37264008C89750C1854640		Ref Point 1	22.75
87	0	0101000020E61000009AB0FD648C4F26405C7171546E844640		Ref Point 2	35.55
88	0	0101000020E61000001899805F23F91C402A38BC20227B4640	Start Point	Pralamar, Pinasca, Torino, Piemonte, 10063, Italia	\N
89	0	0101000020E610000001344A97FEF51C40BB438A01127D4640	End Point	Pralamar, Pinasca, Torino, Piemonte, 10063, Italia	\N
90	0	0101000020E6100000A5660FB402431D4025E82FF488754640	Start Point	Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia	\N
91	0	0101000020E61000008D093197543D1D405E6919A9F7764640	End Point	Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia	\N
92	0	0101000020E6100000E14389963C762540E55FCB2BD7F14640	Start Point	Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
93	0	0101000020E6100000C2DF2F664B7625408C14CAC2D7F14640	End Point	Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
94	0	0101000020E6100000768D96033D14284038BA4A77D7D54540	Start Point	Via Poggiolino delle Viole, Castellare, Pieve Santo Stefano, Arezzo, Toscana, 52036, Italia	\N
95	0	0101000020E610000058E6ADBA0E4D28404546072461D34540	End Point	Bike Help, Pian della Capanna, Pieve Santo Stefano, Arezzo, Toscana, Italia	\N
96	0	0101000020E6100000C1CAA145B60320407715527E52B94640	Start Point	26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia	\N
97	0	0101000020E6100000A4C2D84290032040E8BCC62E51B94640	End Point	26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia	\N
98	0	0101000020E61000003B54539275B82840BF7D1D3867164740	Start Point	Municipio, Via Roma, Torres, Tignes, Pieve d'Alpago, Alpago, Belluno, Veneto, 32010, Italia	\N
99	0	0101000020E6100000D6C8AEB48CB42840F51263997E154740	End Point	Municipio, Via Roma, Torres, Tignes, Pieve d'Alpago, Alpago, Belluno, Veneto, 32010, Italia	\N
100	0	0101000020E61000009296CADB11862840B91803EB383C4740	Start Point	Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia	\N
101	0	0101000020E6100000F94D61A582BA28401363997E89364740	End Point	Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia	\N
102	0	0101000020E6100000B0389CF9D5B4254010E9B7AF03F14640	Start Point	Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
170	0	0101000020E610000052E2299ABDFA2840518B1C7D27114740	Rifugio Semenza	Tambre, Veneto, Italy	\N
103	0	0101000020E61000009414580053762540A04FE449D2F14640	End Point	Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
104	0	0101000020E6100000B0389CF9D5B4254010E9B7AF03F14640		Peak	67.09
105	0	0101000020E6100000A9C0C936708725400936AE7FD7EF4640		Lake	712.07
106	0	0101000020E6100000D576137CD3742640A9BF5E61C1A34540	Start Point	4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia	\N
107	0	0101000020E61000001A19E42EC274264009FCE1E7BFA34540	End Point	4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia	\N
108	0	0101000020E61000003D98141F9F201C409A5FCD01827B4640	Start Point	Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia	\N
109	0	0101000020E6100000CC7A319413FD1B40BD361B2B317D4640	End Point	Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia	\N
110	0	0101000020E61000003BE466B801472840A2427573F12B4640	Start Point	Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia	\N
111	0	0101000020E610000029CFBC1C76472840EA3F6B7EFC2B4640	End Point	Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia	\N
112	0	0101000020E61000002D64979723B62440C66F2527958D4740	Edmund-Graf-Hütte	6574 Pettneu am Arlberg, Tyrol, Austria	\N
113	0	0101000020E6100000455BF9D0380E2A4056DBD4F478794740	Dr.Hernaus-Stöckl	9020 Klagenfurt, Kärnten, Austria	\N
114	0	0101000020E61000003AD4CD22968A2D406DAF4FF575F14740	Amstettner Hütte	3340 Waidhofen an der Ybbs, Niederösterreich, Austria	\N
115	0	0101000020E61000003470C88518362B404F23C0A11DEA4740	Hochleckenhaus	4853 Steinbach am Attersee, Oberösterreich, Austria	\N
116	0	0101000020E6100000745CA7EA5C3230400E95C9F10B114840	Kampthalerhütte	2384 Breitenfurt bei Wien, Niederösterreich, Austria	\N
117	0	0101000020E610000059E5350827672B402FB2862AC2D34740	Lambacher Hütte	4822 Bad Goisern, Oberösterreich, Austria	\N
118	0	0101000020E610000019FDD2643FA62340662869A087B24740	Lustenauer Hütte	6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria	\N
119	0	0101000020E610000036849931B0F52A4014BD78F039C44740	Gablonzer Hütte	4825 Gosau-Hintertal, Oberösterreich, Austria	\N
120	0	0101000020E6100000202F5A3629BF3740D489BAC5B2144340	Katafygio «Flampouri»	136 72 Acharnes, Attica region, Greece	\N
121	0	0101000020E6100000103E4BA24D3F2B40F731169C1AC04740	Simonyhütte	4830 Hallstatt, Oberösterreich, Austria	\N
122	0	0101000020E610000033190145D5182740BF9048EBDFA04740	Vinzenz-Tollinger-Hütte	6060 Hall in Tirol, Tyrol, Austria	\N
123	0	0101000020E61000001F1E0B5901B82E4091BFCBF1EAB34740	Ottokar-Kernstock-Haus	8600 Bruck an der Mur, Steiermark, Austria	\N
124	0	0101000020E610000018E4FB977DBF2A40D6A3B4422D754740	Reisseckhütte	9814 Mühldorf, Mölltal, Kärnten, Austria	\N
125	0	0101000020E61000007B116DC7D4A52540C0401020436D4740	Vernagthütte	Austria	\N
126	0	0101000020E6100000286211C30EF323407EC9C6832D884740	Wormser Hütte	Austria	\N
127	0	0101000020E6100000999CDA19A60E24406CD097DEFEA04740	Biberacher Hütte	Austria	\N
128	0	0101000020E610000007BC276AC4133740DDF934DDA1A84440	Katafygio «1777»	620 55 Kerkini, Central Macedonia region, Greece	\N
129	0	0101000020E6100000D5AF743E3C0B2A40E6E786A6EC704840	Hochwaldhütte	Germany	\N
130	0	0101000020E6100000C2FBAA5CA8EC19408FC536A968544940	Kölner Eifelhütte	Germany	\N
131	0	0101000020E6100000323CF6B358D223401763601DC7794740	Madrisahütte	Austria	\N
132	0	0101000020E6100000313F373465472640CDC98B4CC07F4740	Dresdner Hütte	Austria	\N
133	0	0101000020E6100000CDCCCCCCCC6C24403E07962364A84740	Fiderepasshütte	Germany	\N
134	0	0101000020E6100000B727486C77172440A9DDAF027C9B4740	Göppinger Hütte	Austria	\N
135	0	0101000020E6100000A379008BFC622340C7629B54348A4740	Oberzalimhütte	Austria	\N
136	0	0101000020E610000013B70A62A0932740B3B45373B99D4740	Rastkogelhütte	Austria	\N
137	0	0101000020E61000009D2D20B41E0E2440D54F49E70DC24740	Ansbacher Skihütte im Allgäu	Germany	\N
138	0	0101000020E610000009E066F16249244097E13FDD408F4740	Kaltenberghütte	Austria	\N
139	0	0101000020E61000000AD7A3703D0A2640E277D32D3B944740	Schweinfurter Hütte	Austria	\N
140	0	0101000020E61000006DC438245A213640DA172BC5E9574340	Katafygio «Vardousion»	330 53 Delphi, Central Greece region, Greece	\N
141	0	0101000020E6100000630F270F8F472D40336D62F5852D4740	Kocbekov dom na Korošici	3334 Luče, Mozirje, Slovenia	\N
142	0	0101000020E6100000D1F5D08072062D40D25C9F20CE114740	Planinski dom Rašiške cete na Rašici	1211 Ljubljana, Šmartno, Slovenia	\N
143	0	0101000020E6100000F70F966F85592C40971550C935374740	Prešernova koca na Stolu	4274 Žirovnica, Slovenia	\N
144	0	0101000020E6100000AA5C8F5FCB372E408E6CD71919184740	Planinski dom na Mrzlici	3302 Griže, Slovenia	\N
145	0	0101000020E6100000651A4D2EC6802C40577A6D3656FC4640	Koca na Planini nad Vrhniko	1360 Vrhnika, Slovenia	\N
146	0	0101000020E6100000245DF94DDD322C4077DAB7E6D0144740	Zavetišce gorske straže na Jelencih	0, -, Slovenia	\N
147	0	0101000020E6100000313F3734656F2E406F7F2E1A32264740	Planinski dom na Gori	Šentjungert, 3310 Žalec, Slovenia	\N
148	0	0101000020E610000098F2E7FC90A22B40C7CBA2C928274740	Bregarjevo zavetišce na planini Viševnik	4265 Bohinjsko jezero, Slovenia	\N
149	0	0101000020E610000091860959CC862B401635F33FD4244740	Koca pod Bogatinom	4265 Bohinjsko jezero, Slovenia	\N
150	0	0101000020E6100000678B3942E5992B40007F639573334740	Pogacnikov dom na Kriških podih	5232 Soca, Slovenia	\N
151	0	0101000020E610000008F580BBE4CC2D402A9C0F95E7344740	Dom na Smrekovcu	3325 Šoštanj, Slovenia	\N
152	0	0101000020E610000073F6CE68AB32194060E811A3E77C4640	Refuge Du Chatelleret	38520 Saint Christophe En Oisans, Isère, France	\N
153	0	0101000020E610000084622B685AF218408177F2E9B16B4640	Refuge De Chalance	5800 La Chapelle En Valgaudemar, Hautes-Alpes, France	\N
154	0	0101000020E6100000963D096CCE711940AE7FD767CE6A4640	Refuge Des Bans	5290 Vallouise, Hautes-Alpes, France	\N
155	0	0101000020E6100000DEAB5626FC52DBBFAED689CBF16A4540	Refuge De Pombie	65400 Laruns, Pyrénées-Atlantiques, France	\N
156	0	0101000020E6100000A69C2FF65E7CD2BFA9F92AF9D86D4540	Refuge De Larribet	65400 Arrens, Marsous, Hautes-Pyrénées, France	\N
157	0	0101000020E61000009CA6CF0EB84E1B401232906797C34640	Refuge Du Mont Pourri	73210 Peisey Nancroix, Savoie, France	\N
158	0	0101000020E6100000C712D6C6D8E91A40BF81C98D222D4740	Refuge De La Dent D?Oche	74500 Bernex, Haute-Savoie, France	\N
159	0	0101000020E6100000BEBDCA2243F820405620D41E27544740	Bergseehütte SAC	Uri, Switzerland	\N
160	0	0101000020E6100000CDD5732CA96D1E40F591820D5C054740	Bivouac au Col de la Dent Blanche CAS	Wallis, Switzerland	\N
161	0	0101000020E610000060F1FE571F0C2140D6BA5B328C564740	Salbitschijenbiwak SAC	Uri, Switzerland	\N
162	0	0101000020E610000084EAC5BE53052140F224048A5C664740	Spannorthütte SAC	Uri, Switzerland	\N
163	0	0101000020E6100000827FB24EBCB71E406113E452EB0C4740	Cabane Arpitettaz CAS	Wallis, Switzerland	\N
164	0	0101000020E61000008A75AA7CCF48E4BF588BF447BD614540	Refugio De Lizara	22730, Aragón, Spain	\N
165	0	0101000020E6100000AE56C01909F8E43F58DB5E1CA6064540	Albergue De Montfalcó	22585 Tolva, Aragón, Spain	\N
166	0	0101000020E61000000A4CFFBF1E610AC08B780953B6904240	El Molonillo/Peña Partida	18160 Güejar Sierra, Andalucía, Spain	\N
167	0	0101000020E610000029110100A92D0AC0F39F054F27844240	La Campiñuela	18417 Trévelez, Andalucía, Spain	\N
168	0	0101000020E61000008E79782A3BCC3440BEAE152301FF4440	Titov Vrv	Tetovo, Municipality of Tetovo, North Macedonia	\N
169	0	0101000020E6100000A2EC2DE57C212B40C7F143A5113D4540	Rifugio Franchetti	Pietracamela, Abruzzo, Italy	\N
171	0	0101000020E6100000A197F67244A31F40313D06D094EE4640	Rifugio Città di Mortara 	Alagna Valsesia, Piemonte, Italy	\N
172	0	0101000020E61000006E39F29B1D242040AB1ED555260C4740	Rifugio Andolla	Antrona Schieranico, Piemonte, Italy	\N
173	0	0101000020E61000000AD80E46ECAB2440B70BCD751AFF4540	Rifugio Forte dei Marmi	Stazzema, Toscana, Italy	\N
174	0	0101000020E6100000A88B14CAC2CF284038D66AB4C1504740	Rifugio Berti	Comelico Superiore, Veneto, Italy	\N
175	0	0101000020E610000071B43E4052BB2B406FE70CD649CF4640	Rifugio Premuda	San Dorligo della Valle, Friuli Venezia Giulia, Italy	\N
176	0	0101000020E61000006CCF2C0950C32240191BBAD91FF84640	Rifugio Elisa	Mandello del Lario, Lombardia, Italy	\N
177	0	0101000020E6100000A5BDC11726B31F40F90FE9B7AFFB4640	Rifugio CAI Saronno	Macugnaga, Piemonte, Italy	\N
178	0	0101000020E610000098DD9387857A2640A930B610E4584740	Rifugio Picco Ivigna	Scena, Trentino Alto Adige, Italy	\N
179	0	0101000020E61000003AE97DE36B8F1C404AEF1B5F7B8A4640	Rifugio Toesca	Bussoleno, Piemonte, Italy	\N
180	0	0101000020E6100000A913D044D8E02040382D78D1570C4740	Rifugio Al Cedo	Santa Maria Maggiore, Piemonte, Italy	\N
181	0	0101000020E6100000449D5ECE11661F4009ED8B3A29F34640	Capanna Gnifetti	Gressoney La Trinitè, Valle d?Aosta, Italy	\N
182	0	0101000020E6100000B8AE9811DE3E1E403A048E041AFC4640	Rifugio Aosta	Bionaz, Valle d?Aosta, Italy	\N
183	0	0101000020E6100000BBB31B22135525408EA8F523EA374740	Rifugio Cevedale	Pejo, Trentino Alto Adige, Italy	\N
184	0	0101000020E61000000D33349E08722340F0A485CB2A204740	Rifugio Ponti	Val Masino, Lombardia, Italy	\N
185	0	0101000020E6100000C46D7E0DD2B125405364085B47134740	Rifugio XII Apostoli	Stenico, Trentino Alto Adige, Italy	\N
186	0	0101000020E61000009F1C058882591B40DDD1FF722DE24640	Rifugio Elisabetta Soldini	Courmayeur, Valle d?Aosta, Italy	\N
187	0	0101000020E610000061D57994804F25409903A4C1291F4740	Rifugio Denza	Vermiglio, Trentino Alto Adige, Italy	\N
188	0	0101000020E61000000C1F115322F92A40338AE596560F4540	Rifugio Fonte Tavoloni 	Ovindoli, Abruzzo, Italy	\N
189	0	0101000020E610000037C2A2224EBF2840F2ED5D83BE4E4740	Rifugio Carducci	Auronzo di Cadore, Veneto, Italy	\N
190	0	0101000020E61000006FA53220D64E26400DE02D90A0044740	Rifugio Bindesi	Trento, Trentino Alto Adige, Italy	\N
191	0	0101000020E610000001C11C3D7ECB2D40C670D0B9365A4640	Mountain hut Miroslav Hirtz	53287 Jablanac, Ličko-senjska županija, Croatia	\N
192	0	0101000020E6100000398485EEED352C4098331D324C154740	Koca na Blegošu	4224 Gorenja vas, Slovenia	\N
193	0	0101000020E610000040F850A225BF1F400F441669E2594940	Wittener Hütte	Germany	\N
194	0	0101000020E610000000FDBE7FF3AA25409A99999999694740	Hochjoch-Hospiz	Austria	\N
195	0	0101000020E6100000D7A02FBDFD412640CDCCCCCCCCB44740	Meilerhütte	Germany	\N
196	0	0101000020E610000050C422861DA628406E85B01A4BC64740	Gaudeamushütte	Austria	\N
197	0	0101000020E6100000179CC1DF2F961940D5EB1681B15C4940	Rheydter Hütte	Germany	\N
198	0	0101000020E6100000FB66518EB8562C4057E883656C744940	Sektionshütte Krippen	Germany	\N
199	0	0101000020E61000001F7A839D234C2C40B45EF68814A34740	Neunkirchner Hütte	2620 Neunkirchen, Steiermark, Austria	\N
200	0	0101000020E61000009CE379FC2043E7BF8FC536A9682C4540	Refugio De Riglos	22808, Aragón, Spain	\N
201	0	0101000020E6100000563D4FC4941A2140EBB308E997564740	Salbithütte SAC	Uri, Switzerland	\N
202	0	0101000020E61000001D55C855B23A2040B8EB64DCCE424740	Finsteraarhornhütte SAC	Wallis, Switzerland	\N
203	0	0101000020E6100000DEFD765E1AE71D4038777A52B2FE4640	Cabane des Vignettes CAS	Wallis, Switzerland	\N
204	0	0101000020E6100000E769EE0B84312040FBE19FAF02504740	Glecksteinhütte SAC	Bern, Switzerland	\N
205	0	0101000020E6100000752B5D3C5F152240D9971BDB51454740	Länta-Hütte SAC	Graubünden, Switzerland	\N
206	0	0101000020E610000055ADDEFA26292040BAB9F14860214740	Monte-Leone-Hütte SAC	Wallis, Switzerland	\N
207	0	0101000020E6100000557F0CE8F9C222408F373B25D26E4740	Ringelspitzhütte SAC	Graubünden, Switzerland	\N
208	0	0101000020E6100000A4AA09A2EE0334408E23D6E253104640	Na poljanama Maljen	Maljen, Serbia	\N
209	0	0101000020E6100000A9DE1AD82A313440C5E6E3DA50114640	Dobra voda	Suvobor, Serbia	\N
210	0	0101000020E61000007250C24CDBFF2E402D095053CBC64640	Ivanova hiža	Karlovac town environment, Karlovačka, Croatia	\N
211	0	0101000020E6100000C6DCB5847CC02F40C746205ED7EB4640	Glavica	Medvednica, City of Zagreb, Croatia	\N
212	0	0101000020E6100000FFEC478AC8B83040D3F6AFAC34BD4540	Trpošnjik	Mosor, Splitsko-dalmatinska, Croatia	\N
213	0	0101000020E6100000C217265305932D40C4CE143AAFA54640	Bitorajka	Bitoraj, Primorsko-goranska, Croatia	\N
214	0	0101000020E6100000AB09A2EE0360304006D847A7AE084640	Zlatko Prgin	Dinara, Šibensko-kninska, Croatia	\N
215	0	0101000020E6100000D3872EA86F492E405C8FC2F528444640	Prpa	Velebit, Ličko-senjska, Croatia	\N
216	0	0101000020E6100000787FBC57AD5C2E408BFD65F7E43D4640	Ždrilo	Velebit, Ličko-senjska, Croatia	\N
217	0	0101000020E610000086032159C0F42D40B21188D7F59B4640	Miroslav Hirtz	Velika Kapela, Primorsko-goranska, Croatia	\N
218	0	0101000020E6100000A31EA2D11DAC3140462575029AC04640	Jezerce	Papuk, Požeško-slavonska, Croatia	\N
219	0	0101000020E61000003EE8D9ACFA4C2F405F0CE544BBE24640	Ivica Sudnik	Samoborska gora, Zagrebačka, Croatia	\N
220	0	0101000020E6100000AD3BCC4D8A7D2840CBDF185D39124640		23 Piazza Valentino, Settimo Zaccheo calabro, Italy	\N
221	0	0101000020E6100000AF5E454607602340EDF2AD0FEB6B4440		271 Strada Bonifazi, Ragone a mare, Italy	\N
222	0	0101000020E610000050BA3EBD63AA2840D5DBB0B7DE294640		5 Contrada Marotta, Palladio ligure, Italy	\N
223	0	0101000020E6100000E7204322C8042640F6AEE6A507F54540		0 Via Feleppa, Settimo Vidiano umbro, Italy	\N
224	0	0101000020E61000009F11B6E919B02140ABAC12D154364640		191 Piazza Menozzi, Quarto Tiburzio, Italy	\N
225	0	0101000020E61000009EBFBFF7ED2224402DAAEA8ABEE84640		4 Contrada Manzi, Marsella nell'emilia, Italy	\N
226	0	0101000020E6100000FF209221C76E274017844DF8002D4640		793 Borgo Fadda, Quarto Alvise sardo, Italy	\N
227	0	0101000020E6100000C2B28817FA8E2340D5809C8B1AB04640		109 Rotonda Fatima, Marciano umbro, Italy	\N
228	0	0101000020E6100000107BFC3960762540600A6A53D0274740		9 Strada Finotti, Quarto Italia umbro, Italy	\N
229	0	0101000020E6100000CF5AC0BAE0462B40B9ED314745E34640		0 Via Vaccaro, Ansovino veneto, Italy	\N
230	0	0101000020E610000048B42E7FCFC525403379B93E620B4740		235 Piazza Marian, Testa a mare, Italy	\N
231	0	0101000020E6100000E066F16261B42A4084E85AC52CF04640		4 Borgo Liverani, Viliana ligure, Italy	\N
232	0	0101000020E610000021263CFC90E62840C604EBEEF0074640		00 Rotonda Teresa, Massari lido, Italy	\N
233	0	0101000020E6100000CFB81567B161274070CFF3A78DA74640		1 Borgo Salvo, Settimo Livia, Italy	\N
234	0	0101000020E6100000C1F979F8D76F224054F0CAE48AB04640		344 Contrada Gabriele, Iginia del friuli, Italy	\N
235	0	0101000020E61000008248D0A975782B40741200D2EDC94640		29 Via Stefania, Bambina nell'emilia, Italy	\N
236	0	0101000020E6100000918B208436172940630E828E564E4540		03 Contrada Giacalone, Casula nell'emilia, Italy	\N
237	0	0101000020E610000023484A1F5F572240D37CDF09072C4640		753 Contrada Noemi, Quarto Alberta veneto, Italy	\N
238	0	0101000020E6100000A09339F130542140F7DBE8ADCB384740		3 Incrocio Ferrero, San Menardo sardo, Italy	\N
239	0	0101000020E6100000068A0E37967A2540DB1FDE29D3664540		6 Piazza Tristano, Duilio terme, Italy	\N
240	0	0101000020E6100000CF59B09EA4CE2640F18288D4B4434740		93 Incrocio Cellini, Cipolla del friuli, Italy	\N
241	0	0101000020E6100000C153C8957A5A26407541D8840FE14640		7 Contrada Incoronata, Visconti veneto, Italy	\N
242	0	0101000020E61000008577B988EF302140BAD3426E2B3D4740		1 Via Eleonora, Bianchi ligure, Italy	\N
243	0	0101000020E6100000589643E6259E2540B49487E013DD4540		397 Contrada Vichi, Borgo Germana nell'emilia, Italy	\N
244	0	0101000020E6100000249E4720B9702840B1F84D61A5124640		709 Via Barbato, Azara salentino, Italy	\N
245	0	0101000020E61000008B89CDC7B55926407EB4EED57D084740		092 Piazza Catarsi, San Teresa terme, Italy	\N
246	0	0101000020E6100000D8B969334EEB27402CF8C84164804540		137 Incrocio Ivone, Settimo Petronilla, Italy	\N
247	0	0101000020E610000061D394AEAAD4204012A6835039FC4640		339 Piazza Antino, Addolorata ligure, Italy	\N
248	0	0101000020E6100000B53C6AA741AC27408F0134A550B84640		51 Rotonda Ermenegarda, Borgo Prudenzio, Italy	\N
249	0	0101000020E6100000F78CE9AE91D52240ED48F59D5FE54640		0 Contrada Alessi, Ottonello laziale, Italy	\N
250	0	0101000020E6100000626DE75663902B4097FA1E9A1ED44640		68 Via Locci, San Gumesindo terme, Italy	\N
251	0	0101000020E6100000FFF9C78C011B2640DD706946501E4740		7 Rotonda Alessia, Gualtieri nell'emilia, Italy	\N
252	0	0101000020E61000009C363EEEB67E2740BC2363B5F9BA4640		1 Via Desiderato, Settimo Letizia, Italy	\N
253	0	0101000020E61000008A9466F3387C1E402B31CF4A5AE74640		5 Piazza Siricio, Lotito a mare, Italy	\N
254	0	0101000020E6100000F22895F084D22A404082870E26ED4440		660 Rotonda Tagliabue, Borgo Goffredo, Italy	\N
255	0	0101000020E61000007E1D386744712240C878399105CC4640		3 Rotonda Lotti, Cataldo terme, Italy	\N
256	0	0101000020E610000020D84C1993812240A475AFEEB30D4740		361 Via Izzi, Alessi lido, Italy	\N
257	0	0101000020E6100000242136FD7E2E26406E2AF7A7F91A4740		9 Via Cipolla, Quarto Benedetta, Italy	\N
258	0	0101000020E6100000485E8C37E8B927408860C1A2C7CA4640		77 Contrada Buccheri, Settimo Mansueto umbro, Italy	\N
259	0	0101000020E61000005E961BB1BB751E407379BD4571EF4640		744 Via Rodolfo, Ercoli veneto, Italy	\N
260	0	0101000020E6100000BE2ABC708CED2340366964A1E7DD4640		5 Via Nives, Sesto Cleopatra laziale, Italy	\N
261	0	0101000020E610000053B4722F302B2540E4DC26DC2B4D4740		1 Rotonda Urbano, San Ladislao umbro, Italy	\N
262	0	0101000020E61000009A97C3EE3B32254052B241CB5F574640		6 Borgo Toto, Sesto Cleopatra, Italy	\N
263	0	0101000020E6100000622D3E05C0782840F70BD17C29DE4640		219 Incrocio Leopardi, Settimo Renata veneto, Italy	\N
264	0	0101000020E6100000B05758703F782440773A4668BAB84640		6 Via Alcamo, Borgo Remondo salentino, Italy	\N
265	0	0101000020E610000011D20957F63B2640E6B8AEF3CA084740		9 Piazza Ildefonso, San Ionne, Italy	\N
266	0	0101000020E61000004704E3E0D2692C408514F2F741A74640		901 Rotonda Toscano, Crescenzia a mare, Italy	\N
267	0	0101000020E61000002F0ACC54D2C8264038FE9F1E36CA4640		5 Piazza Oliviera, Salemi umbro, Italy	\N
268	0	0101000020E610000046E80C31035E29405A46EA3D95E54640		34 Borgo Giannone, Quarto Gioia, Italy	\N
269	0	0101000020E6100000E4F90CA8376B2340ABA3F496BC5E4440		376 Incrocio Uranio, Croce a mare, Italy	\N
270	0	0101000020E6100000967DB2BD71ED26406F7319EDA7C14640		281 Strada Carlucci, Marino salentino, Italy	\N
271	0	0101000020E6100000FC68DDABFB5427401073EE1B04334740		9 Contrada Ferraiuolo, Borgo Mariella umbro, Italy	\N
272	0	0101000020E610000069965F611C5B2540B52792F991CA4540		239 Rotonda Venerio, Quarto Alina, Italy	\N
273	0	0101000020E6100000B4C6455ACF692740D8C523A765B04640		363 Incrocio Donata, Quarto Rainelda sardo, Italy	\N
274	0	0101000020E61000003B843B61D3CC1E40935742D202D44640		765 Incrocio Ermenegildo, Borgo Venusta, Italy	\N
275	0	0101000020E6100000C03FA54A9455284094347F4C6BE54640		958 Incrocio Celso, Lazzarini a mare, Italy	\N
276	0	0101000020E610000003FBF900EEEB1E40FA6184F068EE4640		11 Piazza Adelasia, Borgo Tancredi del friuli, Italy	\N
277	0	0101000020E610000007681140209E2640B177352F3D9D4640		30 Borgo Pascarella, Sesto Romilda sardo, Italy	\N
278	0	0101000020E6100000525F96766AFE23402A7C6C81F3EE4640		180 Strada Poggi, San Isaia, Italy	\N
279	0	0101000020E61000007319EDA7B5EF1E400B1060EC18EC4640		081 Contrada Adele, Settimo Igino laziale, Italy	\N
280	0	0101000020E6100000F86B578DCA1A284015E06014A9B14640		2 Incrocio Maltese, Perna laziale, Italy	\N
281	0	0101000020E6100000D634947FD2A12740811A081390584540		94 Contrada Greco, San Ghita nell'emilia, Italy	\N
282	0	0101000020E61000009D63E53C08EA2640B7FB0BF3D4DC4540		66 Strada Mangano, La Rosa sardo, Italy	\N
283	0	0101000020E6100000EA0E18DAEF9B2B40948444DAC6764640		94 Strada Aida, Pichler lido, Italy	\N
284	0	0101000020E610000014BCD7FFEFC62640BA66F2CD36DE4640		515 Incrocio Cucciniello, Raniero del friuli, Italy	\N
285	0	0101000020E610000009168733BFBE27405D4E098849354540		123 Contrada Cesaretti, Borgo Alfio terme, Italy	\N
286	0	0101000020E6100000462AE7E6763A2940ABB8CC446CE14440		51 Piazza Lonardi, Livia a mare, Italy	\N
287	0	0101000020E610000075EED176A7F62640A7F97486F3B24640		144 Incrocio Carponio, Quarto Baldomero, Italy	\N
288	0	0101000020E6100000F9A23D5E48F727405789C3E3ECE04640		28 Incrocio Anna, Borgo Godiva calabro, Italy	\N
289	0	0101000020E6100000731A587D64FD294065FED13769E64540		9 Contrada Lombardini, Dulina laziale, Italy	\N
290	0	0101000020E6100000ABC5F18D322421407D1FB3582FFA4640		1 Via Nerea, Barnaba salentino, Italy	\N
291	0	0101000020E610000035D252793B0228403A79ECC26AEA4640		33 Strada Grillo, Alcibiade salentino, Italy	\N
292	0	0101000020E6100000DD730580CFD02640F16261889CD44640		21 Borgo Cascio, Quarto Felicita calabro, Italy	\N
293	0	0101000020E61000006531564046E12040530E1C8645E74640		19 Borgo Zanetti, Borgo Isa, Italy	\N
294	0	0101000020E610000026B8A2DE9D5E2740311A434AFDDC4640		1 Contrada Adelmo, Lavinio veneto, Italy	\N
295	0	0101000020E61000000A5BFD22B27524407121EA99B95B4640		6 Strada Coniglio, Borgo Verecondo ligure, Italy	\N
296	0	0101000020E6100000C132DBBA40CE2240D0EFFB372F274740		06 Via Corinna, Eulalia umbro, Italy	\N
297	0	0101000020E6100000CA558737C6B91F40EB79ED88F9BD4640		662 Via Olinda, Prospera lido, Italy	\N
298	0	0101000020E61000006AEE320DD4F324401D098F9147B14640		37 Piazza Passeri, Quarto Concetto nell'emilia, Italy	\N
299	0	0101000020E610000044053D8A291B2140F0FACC599F5A4440		275 Rotonda Stella, San Melchiorre, Italy	\N
300	0	0101000020E61000002B1D07B9E6212040F08C11E4FBF04640		994 Rotonda Elia, Settimo Aresio, Italy	\N
301	0	0101000020E61000007BEDE3B21BB727403464E190B2DD4640		5 Borgo Bassi, San Corbiniano, Italy	\N
302	0	0101000020E6100000D8E9ACBB1EE91F40A0A932E774D04640		89 Piazza Ledda, Sesto Raffaele, Italy	\N
303	0	0101000020E61000009C8136DEC21B294063731FCA61894540		087 Rotonda Mottola, Settimo Giordano nell'emilia, Italy	\N
304	0	0101000020E6100000E3B08FA91680204076A0F3BF01E94640		86 Incrocio Polizzi, Benvenuto terme, Italy	\N
305	0	0101000020E6100000EE6EAF16E9832340C6F0225D7DCC4640		336 Via Ivano, Settimo Orsino salentino, Italy	\N
306	0	0101000020E6100000D81D41E037B02140C2F1214D61C54440		585 Borgo Puccio, Diodata sardo, Italy	\N
307	0	0101000020E6100000A807BB174E80284061BC8B9C2AD94640		929 Rotonda Campagna, San Clemente a mare, Italy	\N
308	0	0101000020E6100000FD18CE9085A322406C9CA80073DB4640		8 Contrada Manca, Vicari del friuli, Italy	\N
309	0	0101000020E6100000E39F635122672540E113A1C7DEDE4640		902 Via Ernesta, San Gioia calabro, Italy	\N
310	0	0101000020E610000098231A93B47928409916500361674640		22 Strada Baldassarre, Martorana umbro, Italy	\N
311	0	0101000020E6100000ABBCD3539A032740A544B7031AEF4640		944 Borgo Azelio, Quarto Nicoletta, Italy	\N
312	0	0101000020E61000001E424B0D239B2440D8D1DD1A7DA04640		238 Piazza Piazza, Borgo Iago calabro, Italy	\N
313	0	0101000020E6100000CF2CAE96E0891F405EB642FDD3234640		8 Contrada Dante, Romano calabro, Italy	\N
314	0	0101000020E6100000D7BDBACF96BC254007205AD020C34640		124 Contrada Liliana, Recchia calabro, Italy	\N
315	0	0101000020E6100000C96BCABA24832740A97E4A3A6FE54640		633 Strada Mercurio, Quarto Gualtiero calabro, Italy	\N
316	0	0101000020E6100000A8DAB80F8AC32940DF67017F9D1A4540		26 Borgo Orsini, Sesto Orsolina, Italy	\N
317	0	0101000020E6100000C272DFC556972640A4271BC528D24640		7 Rotonda Cherubino, San Sico, Italy	\N
318	0	0101000020E61000005F306E5974411E40EC3F21F1E13A4740		265 Contrada Davide, Borgo Baldo, Italy	\N
319	0	0101000020E61000006C109CE9142628401760C4E347124740		571 Piazza Tiziano, Sesto Ticone, Italy	\N
320	0	0101000020E610000044EC0214D9FD284012AC600AC5EE4440		120 Via Cristoforo Colombo, Roma, Italy	\N
321	0	0101000020E6100000B0FECF61BEF827406DFD99E6C2F24640		3 Contrada Macario, Giordano nell'emilia, Italy	\N
322	0	0101000020E6100000EBB76576CCAF26407B8FE9BFBD424640		51 Piazza Liccardo, Ettore calabro, Italy	\N
323	0	0101000020E6100000D6479682247220407379BD4571084740		5 Borgo Guerrino, Borgo Gherardo, Italy	\N
324	0	0101000020E610000097900F7A36872040AB251DE560074740		4 Borgo Doroteo, Cozzi a mare, Italy	\N
325	0	0101000020E61000000DABD3DC65C22740D32F116F9DE34640		01 Borgo Inzerillo, Giansante veneto, Italy	\N
326	0	0101000020E61000009FEE97AA0FCF27402834FF9E0E024740		7 Via Nardi, Settimo Liberto, Italy	\N
327	0	0101000020E6100000E417B90265622C40EFC0A50815E24440		791 Incrocio Senatore, Borgo Clarenzio sardo, Italy	\N
328	0	0101000020E6100000B2463D44A37B2540F3C011EEDF764540		40 Via Guastone, Sesto Ataleo umbro, Italy	\N
329	0	0101000020E6100000B6B0B84956A326409DC2A5BE87334740		6 Contrada Renzo, Quarto Gioacchina, Italy	\N
330	0	0101000020E6100000D56C2FB319AD2840823C16365EC04640		0 Rotonda Di Maro, Sirio a mare, Italy	\N
331	0	0101000020E610000076583C5002EE1E40E0CCF9731BE14640		79 Piazza Spanò, Sesto Elifio, Italy	\N
332	0	0101000020E6100000470EC7A98CC52840B6A73F564BE04640		1 Incrocio Battista, Paolino laziale, Italy	\N
333	0	0101000020E61000004DC00A4B97B91F4005C1E3DBBBF84540		935 Via Biondi, Castellani veneto, Italy	\N
334	0	0101000020E610000059EB7A585E182740106D1162780E4640		4 Contrada Secondina, Quinzio ligure, Italy	\N
335	0	0101000020E610000051D9B0A6B2581F4089B7CEBF5DE14640		67 Piazza Pagliai, Settimo Germano, Italy	\N
336	0	0101000020E6100000AD7603BB504F27406049A8CFC4374640		8 Incrocio Manilio, Settimo Ugolino, Italy	\N
337	0	0101000020E61000004692C5A28EF72640D32934B511794640		73 Piazza Benedetto, Irma terme, Italy	\N
338	0	0101000020E6100000068B790C45182740C3CB1D47BD774640		38 Contrada Guidetti, Scarpa terme, Italy	\N
339	0	0101000020E61000005CC0159A35C620401880A1A245F44640		23 Piazza Lorenza, Tavani sardo, Italy	\N
340	0	0101000020E6100000FA2D9512DD7227409453967C47234640		40 Strada Olimpio, Famiano lido, Italy	\N
341	0	0101000020E61000008ECD8E54DFA12B403562C1583A2D4540		719 Contrada Comito, Orlando salentino, Italy	\N
342	0	0101000020E610000020651FBF127F254034C06092257F4640		727 Contrada Noto, San Donna a mare, Italy	\N
343	0	0101000020E610000064BB31F3D36E22404F401361C3C24640		000 Incrocio Venturini, Amerigo ligure, Italy	\N
344	0	0101000020E6100000D160AEA0C47E2240E41824D813C04640		210 Incrocio Zumbo, Settimo Amadeo, Italy	\N
345	0	0101000020E61000006FD8B628B3B91E40086465EA64D64640		4 Piazza Isabella, Merli ligure, Italy	\N
346	0	0101000020E610000016CDB9CAC93E2140BC0E8B074A744640		9 Via Flaviano, Settimo Clodoveo, Italy	\N
347	0	0101000020E6100000B4064A65E54A274026DAFA8E86E14640		4 Incrocio Rondinone, Borgo Asterio laziale, Italy	\N
348	0	0101000020E61000000736F80CF26822405273034F6B9C4640		8 Strada Moira, Borgo Babila, Italy	\N
349	0	0101000020E6100000DF6124C511412140D11CFE3FF3744640		2 Strada Cipriano, San Lorena ligure, Italy	\N
350	0	0101000020E610000077ED77CD50412140CB243493B9744640		195 Incrocio Amata, Ferluga calabro, Italy	\N
351	0	0101000020E61000002E008DD2A5032D406B5CA4F55C204540		849 Via Batilda, Borgo Senofonte, Italy	\N
352	0	0101000020E61000004ED367075C6F1F403A57941282D64640		412 Borgo Mauro, Batilda salentino, Italy	\N
353	0	0101000020E61000006405BF0D316E1F409F07D22060D24640		0 Piazza Patrizia, Sesto Berengario veneto, Italy	\N
354	0	0101000020E61000006F4BE482334C2740A928A8F287304640		40 Rotonda Malco, Settimo Amalia veneto, Italy	\N
355	0	0101000020E61000005BC52CC59F522B40DB68A5B50EFA4640		3 Piazza Tirri, Marina salentino, Italy	\N
356	0	0101000020E61000000D5F155E383A21402BCC310F4F724640		63 Piazza Daidone, Carè terme, Italy	\N
357	0	0101000020E6100000E04158326C5D2140821C9430D3704640		48 Via Gaddini, Borgo Asella salentino, Italy	\N
358	0	0101000020E6100000C1F979F8D7071F404EFA319C21CD4640		566 Strada Servidio, Satta del friuli, Italy	\N
359	0	0101000020E61000000C97B0917F3921404C9C267D6B734640		9 Borgo Ausilia, Quarto Severa, Italy	\N
360	0	0101000020E6100000EFA18ED838742840FA10AF46D1764640		06 Piazza Storti, Bruno sardo, Italy	\N
361	0	0101000020E6100000B032BF3F4AC11E4019CD25B094D54640		634 Via Graziano, Orenzio calabro, Italy	\N
362	0	0101000020E610000039FBB9579CA829401D9C3EF152FC4440		122 Borgo Castelli, Quarto Verecondo lido, Italy	\N
363	0	0101000020E6100000440E5BC4C1F71E4071033E3F8C7E4640		025 Strada Adriano, Zennaro terme, Italy	\N
364	0	0101000020E6100000C69EE2DD36D82B400B8AD5D5D3E84640		3 Borgo Camillo, Marras lido, Italy	\N
365	0	0101000020E6100000888961E2EA131F4040E7244A31CD4640		506 Incrocio Carrozzo, Fidenzio terme, Italy	\N
366	0	0101000020E6100000E8F86871C6D81E40E7EBE86E8DD84640		68 Piazza Aristide, Quarto Amleto, Italy	\N
367	0	0101000020E610000024BF34FBF2301F405FCE6C57E8CB4640		012 Rotonda Barberis, Zucca umbro, Italy	\N
368	0	0101000020E61000000242902859C7254075988AE832F64540		2 Incrocio Vittori, Quarto Achille del friuli, Italy	\N
369	0	0101000020E61000005CEC5113D8AF1E405650ACAE9ED84640		80 Strada Drago, Giorgio veneto, Italy	\N
370	0	0101000020E6100000A6A84423E9E41E40BF20336145E14640		1 Incrocio Librizzi, Gangemi calabro, Italy	\N
371	0	0101000020E6100000F07A7AB6582B2740B1ADFAB726234640		6 Incrocio Benigna, Settimo Emmerico, Italy	\N
372	0	0101000020E61000002252D32EA6C91E404392B47636E94640		617 Strada Edvige, Lo Iacono lido, Italy	\N
373	0	0101000020E61000000BC336983C2C27405262D7F676234640		81 Incrocio Corrado, Quarto Benigno calabro, Italy	\N
374	0	0101000020E61000004F722C94F1E8264075F2D885D5064740		20 Rotonda Giannetti, Bianchi umbro, Italy	\N
375	0	0101000020E61000005C8BBBE6FA8F26407A4F8AFB343B4740		605 Rotonda Ciuffreda, Macchi laziale, Italy	\N
376	0	0101000020E61000007B9054956C0B28407BB5487FD4974640		2 Strada Sebastiano, Settimo Varo, Italy	\N
377	0	0101000020E6100000BE52F1DA00B72B40D21D1F8887274540		08 Incrocio Porziano, Sesto Gionata veneto, Italy	\N
378	0	0101000020E6100000A732D6485C052740FDD8243FE2394640		75 Piazza Amanzio, Quarto Agrippa, Italy	\N
379	0	0101000020E6100000AD94545C0B4D2240EE885462E8B94640		60 Borgo Aniello, San Robaldo nell'emilia, Italy	\N
380	0	0101000020E6100000333097F9B3641F40983BE93356DF4640		69 Via Ottaviani, Settimo Marianna, Italy	\N
381	0	0101000020E61000002B8AB2124E762740C1EA234B41314640		18 Piazza Cappelli, Rosa salentino, Italy	\N
382	0	0101000020E6100000905F8951219022403E5695229E864640		179 Via Aris, Sesto Ilario nell'emilia, Italy	\N
383	0	0101000020E610000096C1621E43E92640E580B80611044740		51 Incrocio Urso, Borgo Isacco lido, Italy	\N
384	0	0101000020E61000007090B52B99842B40E461461DC27E4640		342 Contrada Bianca, Fava terme, Italy	\N
385	0	0101000020E610000084B1CFAD219A26406BDECC43010E4740		95 Strada Pitzalis, Mazzone a mare, Italy	\N
386	0	0101000020E6100000CC1D47BDF13F2240A5A31CCC26824640		386 Via Estella, Dagoberto salentino, Italy	\N
387	0	0101000020E610000048E58123DCFF26407F7E294D94084740		2 Rotonda Isidoro, Sesto Elogio laziale, Italy	\N
388	0	0101000020E61000006B5A73918C1625409D7C1FB358204740		468 Contrada Daniela, Borgo Costante nell'emilia, Italy	\N
389	0	0101000020E6100000204F818241C01E40068B1E53D2D34640		4 Rotonda Villari, Settimo Dorotea calabro, Italy	\N
390	0	0101000020E6100000C0CBB161F2931E40B859BC5818D34640		946 Strada Cavallari, Settimo Alina nell'emilia, Italy	\N
391	0	0101000020E610000070DA4246F68B2C40A79C8AAFD1364740		7 Piazza Baldo, Dario ligure, Italy	\N
392	0	0101000020E6100000A9D5FC9D92882C4058FBE02131384740		03 Borgo Longhi, Borgo Bonito nell'emilia, Italy	\N
393	0	0101000020E6100000F74A0FF91DD1274067DC8AB3D8024740		560 Via Cirilla, Sammartino del friuli, Italy	\N
394	0	0101000020E61000004221A7542EE52C40A39BB3F457164740		1 Piazza Provenzano, Settimo Ludano, Italy	\N
395	0	0101000020E6100000D3D7987C586422408E7CB9AA47A84640		79 Rotonda Frau, Borgo Ionne, Italy	\N
396	0	0101000020E610000008CDAE7B2B8A2440E646EC6EF9664540		91 Borgo Giove, Sesto Ecclesio, Italy	\N
397	0	0101000020E610000081EB8A19E1CD26408A4457D8C2194640		68 Borgo Bacco, Bindi a mare, Italy	\N
398	0	0101000020E6100000B4CA4C69FD5122404A95CDC1D8134540		1 Borgo Ferroni, Gonerio salentino, Italy	\N
399	0	0101000020E6100000E4BD6A65C267264033260EEA6CBC4640		399 Incrocio Schiavo, Sesto Colmazio nell'emilia, Italy	\N
400	0	0101000020E610000071C0536DDCD325406C312E0BDCB14640		87 Strada Paolo, Asdrubale calabro, Italy	\N
401	0	0101000020E6100000B368F0ADFEEA2540D42AFA4333B54640		901 Borgo Adelasia, Emiliana sardo, Italy	\N
402	0	0101000020E61000005B2CA0AB08EA2740DE454E15422C4740		2 Piazza Sarti, Brunilde lido, Italy	\N
403	0	0101000020E61000009703988D2933274052EC0D63778A4640		489 Via Monte Grappa, Lendinara, Italy	\N
404	0	0101000020E61000005389FC44AF582940E7D2AEF83CCA4640		734 Rotonda Olivi, San Veridiana sardo, Italy	\N
405	0	0101000020E61000000236D6B441802C4025D5D237C46B4440		44 Via dei Greci, Napoli, Italy	\N
406	0	0101000020E610000073220BE24DBC2740A1E4C40DAE2D4740		292 Strada Omar, San Gianluca a mare, Italy	\N
407	0	0101000020E610000046B1DCD26AB02540072E45A808074740		559 Incrocio Bartolo, Borgo Furseo nell'emilia, Italy	\N
408	0	0101000020E6100000B17E7DBE77992240C0F858B043504440		9 Borgo Mastroianni, Settimo Isa terme, Italy	\N
409	0	0101000020E6100000EC3026FDBD2C27403B6AF1CE46024740		360 Strada Milan, Oggiano ligure, Italy	\N
410	0	0101000020E6100000996EC8F5A5712B40C576F700DD3C4740		00 Rotonda Euclide, San Regolo, Italy	\N
411	0	0101000020E6100000AA5DB818A8F922406B0DA5F622154440		902 Contrada Perra, Sebastiana nell'emilia, Italy	\N
412	0	0101000020E610000034B10AE58E682040CFC941BFA57A4440		32 Rotonda Iandolo, Settimo Ugolino, Italy	\N
413	0	0101000020E610000008D04AB5AABC2140800F5EBBB4374640		4 Borgo Biagini, Mautone nell'emilia, Italy	\N
414	0	0101000020E6100000B35DA10F967D2D408F49905BDD324740		17 Borgo Aldo, Moreno salentino, Italy	\N
415	0	0101000020E6100000852348A5D8C12840842458C114E24540		22 Incrocio Tarso, Cifarelli laziale, Italy	\N
416	0	0101000020E6100000BF5076E915252B40EA398EC4703B4740		974 Strada Melchiade, Alviero del friuli, Italy	\N
417	0	0101000020E6100000B956D6917EDA2B40DF707A72A8054540		00 Rotonda Sirio, Sesto Irene veneto, Italy	\N
418	0	0101000020E61000007889A02067742340DE2A3EF493CE4640		3 Borgo Annibale, Sesto Fedora, Italy	\N
419	0	0101000020E6100000235399BDC70C254059CFFF6101ED4540		056 Contrada Marzi, Quarto Fortunata, Italy	\N
420	0	0101000020E610000027F33405D7392640E75E16C90D2C4740		595 Strada Grosso, Settimo Gianmarco a mare, Italy	\N
421	0	0101000020E61000001C15EE4BECAC2A40DD11A9C4D02E4540		57 Strada Giudice, Mora veneto, Italy	\N
422	0	0101000020E6100000C1D4850E70E722408E6D63FDB0594540		6 Incrocio Gioele, Evremondo ligure, Italy	\N
423	0	0101000020E6100000E5BA849E28A826407E7D63BE723F4640		74 Via Valentina, Borgo Eriberto sardo, Italy	\N
424	0	0101000020E610000055B1E72109D11F4018CFA0A17FB14640		097 Strada Alaimo, Settimo Didimo, Italy	\N
425	0	0101000020E61000007DEFCA89D18E2640DB0B16985F354540		4 Incrocio Carbon, Eliano umbro, Italy	\N
426	0	0101000020E6100000BB6D9516E41D244002678412C1A94640		362 Rotonda Pelagia, Borgo Agostina sardo, Italy	\N
427	0	0101000020E6100000F67AF7C77BB52740FA449E245D4F4740		083 Piazza Ruggeri, La Porta del friuli, Italy	\N
428	0	0101000020E6100000DE68119BD960294098E8E225EEFB4440		15 Strada Pasquali, San Orsola terme, Italy	\N
429	0	0101000020E61000007ED3AA4CE7E52340C9CC052E8F254640		544 Contrada Loiacono, San Isidora lido, Italy	\N
430	0	0101000020E61000004EDF217B732E2240D3F4D901D7214540		891 Incrocio Giuseppe, Settimo Alma ligure, Italy	\N
431	0	0101000020E61000004377A45588CA264008951348E43C4640		831 Borgo Fleano, Sesto Fiorenzo del friuli, Italy	\N
432	0	0101000020E610000072593B40E6692840252D4B2A09EC4440		7 Piazza Martelli, Quarto Fosco calabro, Italy	\N
433	0	0101000020E610000023E7B3F281D7214072C8618B38C84640		13 Contrada Uriele, Vanessa terme, Italy	\N
434	0	0101000020E61000000C84AE8E2D752740A4897780272E4640		6 Strada Aquilino, Sesto Damaso salentino, Italy	\N
435	0	0101000020E6100000A63C5F58A33326408C811A63CCED4540		22 Via Venanzio, Angelica umbro, Italy	\N
436	0	0101000020E6100000CC0C1B65FD922840A42C8DA905C14640		8 Contrada Cruciani, Settimo Alamanno, Italy	\N
437	0	0101000020E61000007332CC64933F2740FEDDF1DC31254640		168 Incrocio Ivone, Pichler salentino, Italy	\N
438	0	0101000020E610000032D758784D462240743F4C67CC0B4740		3 Incrocio Daniele, Aleramo salentino, Italy	\N
439	0	0101000020E61000002B16BF29ACC825401AB6775787864540		358 Contrada Edilberto, Cassio lido, Italy	\N
440	0	0101000020E6100000FE00B562C9B62A4032CFA51364D94440		0 Rotonda Cornelia, San Maddalena lido, Italy	\N
441	0	0101000020E61000002AD890C9F3362640A3C629DFD80F4640		4 Via Gerasimo, Quarto Afro umbro, Italy	\N
442	0	0101000020E610000098F0958AD7422540F3DD52735E994640		912 Via D'Aleo, Pugliesi ligure, Italy	\N
443	0	0101000020E6100000451B36806D772640B99BF1C7FE074740		9 Borgo Paolo, Quarto Egidio lido, Italy	\N
444	0	0101000020E61000008948A8740B9027402B7D321015F14540		9 Rotonda Alma, Montanari laziale, Italy	\N
445	0	0101000020E6100000484B8A3496612B40F1F44A5986DF4640		596 Contrada Venusto, San Filomeno veneto, Italy	\N
446	0	0101000020E610000006240626DCE0264059631A97BBDC4640		62 Incrocio Iazzetta, Leo a mare, Italy	\N
447	0	0101000020E61000001A62067470422640EF6BC94F4FBD4540		4 Borgo Cinzia, Cunegonda a mare, Italy	\N
448	0	0101000020E6100000F0F1536694F425402F5D77A9C7134640		97 Borgo Elsa, San Consolata nell'emilia, Italy	\N
449	0	0101000020E6100000A5DAA7E3317F2240E75E16C90DEF4640		914 Incrocio Violi, Stefania nell'emilia, Italy	\N
450	0	0101000020E6100000D12E956D967D2C40126C5CFFAE6D4440		2 Contrada Cantoni, Vittoriano umbro, Italy	\N
451	0	0101000020E6100000DD6CBDF0941F27409F515F3BBDDA4640		183 Borgo Caio, Piana umbro, Italy	\N
452	0	0101000020E610000096EA025E66002640FA4E82ED16F44540		3 Strada Pagliuca, Borgo Fiorenziano, Italy	\N
453	0	0101000020E61000009DDE20B5E43C25407F83F6EAE39D4540		35 Contrada Brunilde, San Alessandro del friuli, Italy	\N
454	0	0101000020E6100000016E162F168E2340861BF0F9614A4440		8 Rotonda Onorio, Erardo laziale, Italy	\N
455	0	0101000020E61000009F32480BE1EA20405C8A50114CDA4640		279 Contrada Flora, Genesia sardo, Italy	\N
456	0	0101000020E6100000618841052C422B400938DFE3A78E4640		43 Contrada Roberto, Gillo veneto, Italy	\N
457	0	0101000020E6100000160F94803D132140276BD44334E04640		02 Borgo Galante, Costante salentino, Italy	\N
458	0	0101000020E610000097A13BD22A4C25401A80B2CE9DD44540		663 Contrada Mancini, Quarto Antea sardo, Italy	\N
459	0	0101000020E6100000AD904D4DDD3827405B632BC313B14540		677 Borgo Zani, San Enecone, Italy	\N
460	0	0101000020E610000071E82D1EDEEB2C405F93DA30AF824440		705 Borgo Paoletti, Settimo Giliola, Italy	\N
461	0	0101000020E6100000DA48C8F6109B1F40EE2AFFB5176E4640		38 Rotonda Desiderata, Calogera veneto, Italy	\N
462	0	0101000020E61000004D028A4798F02740C38366D7BD264640		173 Incrocio Sara, Quarto Eligio umbro, Italy	\N
463	0	0101000020E6100000BCB77DEAB38A2C404EF04DD3676E4440		66 Incrocio Francesca, Sesto Radolfo, Italy	\N
464	0	0101000020E6100000CBC80F4BB93126404793E6EA22FD4640		2 Incrocio Di Giuseppe, Zennaro lido, Italy	\N
465	0	0101000020E6100000A68E9FD7E925284065677682A2C64640		3 Contrada Mauro, Fabbri laziale, Italy	\N
466	0	0101000020E6100000407562C55F5D294091FC773359C24640		45 Incrocio Taziana, San Tullia, Italy	\N
467	0	0101000020E6100000CF328B506C4D244070D63B37C8184640		517 Strada Trapani, Reginaldo sardo, Italy	\N
468	0	0101000020E61000007E6E0D11DC1122409453967C47EB4640		9 Rotonda Favaro, Settimo Cordelia, Italy	\N
469	0	0101000020E610000043A44BA4D989204072A8DF85ADD34640		0 Rotonda Belvisi, Omar salentino, Italy	\N
470	0	0101000020E61000004371C79BFC022C404AF5F81807254540		62 Strada Piccoli, Militello a mare, Italy	\N
471	0	0101000020E61000009EA74B10BFA422400292FAFC41944440		89 Piazza Antigone, Baldo terme, Italy	\N
472	0	0101000020E61000000D88B59D5B012C40CF70B9B024144540		5 Rotonda Samona, San Vittoriano, Italy	\N
473	0	0101000020E610000059935D1F8CFE26407E6DA23B2D3B4640		624 Piazza Motta, Borgo Concordio terme, Italy	\N
474	0	0101000020E6100000D50451F7010829403B736AC2510D4640		80 Incrocio Amilcare, San Zabina laziale, Italy	\N
475	0	0101000020E6100000CD6152D735012740D65F6523C6394640		6 Incrocio Amerio, Quarto Cino, Italy	\N
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hike_track_points ("userHikeId", index, "pointId", datetime) FROM stdin;
\.


--
-- Data for Name: user_hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes (id, "userId", "hikeId", "startedAt", "updatedAt", "finishedAt", "psTotalKms", "psHighestAltitude", "psAltitudeRange", "psTotalTimeMinutes", "psAverageSpeed", "psAverageVerticalAscentSpeed", "maxElapsedTime", "weatherNotified", "unfinishedNotified") FROM stdin;
\.


--
-- Data for Name: user_hikes_track_points_user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes_track_points_user_hike_track_points ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash", approved, preferences, "plannedHikes") FROM stdin;
2	$2b$10$.9h1eR8UaCljB.WMZ93qLeInbOPxtP.5QTQxAJ3Rc4arRgLehVyvy	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N	t	\N	\N
4	$2b$10$L6.IYZfnr6Eu00mlbGVPceaVFNowfXgZbalKB9WLQpB9OfM31BRbO	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N	t	\N	\N
5	$2b$10$8CrGwmlPQi3WD9GxRjf4jeJVe2MtOqws/e8BJQgb4cYPHdRzUWOV2	Laura	Zurru	5	laura@emergency.it	\N	t	\N	t	\N	\N
1	$2b$10$xZCJijW9BS71Dm2SPE2Sju7Qwm4YF6LS.x.yUQhjMLdd4P8Jx65oW	German	Gorodnev	0	german@hiker.it	\N	t	\N	t	\N	\N
3	$2b$10$PZd0QeHzcdtlGQ4SezgkvOSwSvHnBor.FERyDqIBuDDF4cmIQuBgC	Vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N	t	\N	\N
6	$2b$10$BT5PciAaxQyAKD5wF86z0ORl9W8y.a8KimGjZ8TrZDkzEg6DQ.bli	Francesco	Grande	1	francesco@friend.it	\N	t	\N	t	\N	\N
7	$2b$10$fnrZ937CnqhlYltMyVuzdehHI0qgcmpYY6GBuoRz234lOlgad8r/.	Cloe	Caiazza	4	hutWorker0@gmail.com	\N	t	\N	t	\N	\N
8	$2b$10$Qw.NcrD5bb4hhmt042/D2.PRmh0Kt7eUw7syHLUq7zvfD43U9DWXy	Iginia	Manzi	4	hutWorker1@gmail.com	\N	t	\N	f	\N	\N
9	$2b$10$Nfaib1smwlh1/eb8XwKt1eXDKoVyEnDtVFdpSvbogC5hsleTCrphG	Ursicio	Mele	4	hutWorker2@gmail.com	\N	t	\N	t	\N	\N
10	$2b$10$4fJnSTy2q5Mt8HTt38Nxv.WD8CxG9RkkiBhgR5wFuYPtSF5LNEn5G	Basileo	Simeti	4	hutWorker3@gmail.com	\N	t	\N	f	\N	\N
11	$2b$10$7.fns18sX2lxvBZINpQ3O.IewjikFumunI4cX7goZkJ4y2aSUI/IG	Fidenzio	Dal Farra	4	hutWorker4@gmail.com	\N	t	\N	t	\N	\N
12	$2b$10$ygKYRHlGutq6tAXNK3u73Oe4hsi4s2d1UMC11NpA.zziQ3jcAsazW	Franco	Marchini	4	hutWorker5@gmail.com	\N	t	\N	f	\N	\N
13	$2b$10$kd3NTeKxBklZZixlQ3Hrj.hamaamB5FfBUjzQYbNaaFrzz..x.B4C	Teodolinda	Casella	4	hutWorker6@gmail.com	\N	t	\N	t	\N	\N
14	$2b$10$e4jsix9XZExFW80p1HgiWOvY8XWiPIkUQ866ybNRDIY0O2zI3pA9K	Giacomo	Cassano	4	hutWorker7@gmail.com	\N	t	\N	f	\N	\N
15	$2b$10$qtdvhBmGlmlMHJQpmfgNbuYbovV43STWU9REior75DOBKIsBxRiYm	Maria	Barberis	4	hutWorker8@gmail.com	\N	t	\N	t	\N	\N
16	$2b$10$PL6WoiU.IUDh5cYHrosogeePTt0iJPktT2SIvIiBDKtLQS0bGtmiO	Audace	Tagliabue	4	hutWorker9@gmail.com	\N	t	\N	f	\N	\N
17	$2b$10$yRNGvxmYDqyzXBv4Mg/.9uvW6MnvNk3PqqICN2fdVGzlH0i801Kte	Carolina	Sartori	4	hutWorker10@gmail.com	\N	t	\N	t	\N	\N
18	$2b$10$bgK.Dx/6PLiyeYFxP.Bo3eZuLdWjKSfUEOSx38G3s7VPGWXKv.UTW	Cesario	Picchi	4	hutWorker11@gmail.com	\N	t	\N	f	\N	\N
19	$2b$10$4/62aIpob2/n1Js6iNyGxO6fDjgjIhM1kGhu3gkpWDdad0g7er8L.	Lodovico	Di Maggio	4	hutWorker12@gmail.com	\N	t	\N	t	\N	\N
20	$2b$10$8dPsc4TJO9O1QmzdcrZRKOUeG6i9rkcZ88CqMQcJCI.VPN8GkJBN2	Ettore	Serena	4	hutWorker13@gmail.com	\N	t	\N	f	\N	\N
21	$2b$10$5vl/cD/MG1JgjaiuEy0m0OLZD/DSB9RpW9r/L4IOe683/k/U3ubqi	Siria	Riva	4	hutWorker14@gmail.com	\N	t	\N	t	\N	\N
22	$2b$10$cHG3pTBpmKS9oBxM3Z/uD.8UjDjCm809wZBmsuVmYvRlittOpcDbW	Romana	Acquaviva	4	hutWorker15@gmail.com	\N	t	\N	f	\N	\N
23	$2b$10$A0Dyl6/cKOciiXodhtlMJOQL6WAV3Sfr48lT9mUhEAT/jrmuKGJ.m	Geronimo	Alessandrini	4	hutWorker16@gmail.com	\N	t	\N	t	\N	\N
24	$2b$10$7LuuAXAbs4XqYKkZG9xkMuQhyKgkU7thOQ.lofN./LW8.30ht3Phq	Elia	Atzori	4	hutWorker17@gmail.com	\N	t	\N	f	\N	\N
25	$2b$10$YcmlW61g3vziqfFb7a5rEeov9KlzdaQmFvZ3mri3H9Ehv1JYzJdVS	Eterie	Innocenti	4	hutWorker18@gmail.com	\N	t	\N	t	\N	\N
26	$2b$10$317n.prSz8MmIqiXzmjX8.45lORmzDJ7jUG5o/PNuC0T8OE6kcmbO	Gervasio	Bassani	4	hutWorker19@gmail.com	\N	t	\N	f	\N	\N
27	$2b$10$e8ipiH/lXbXX8cjrPb9FyeA2lyJsWolKwKZJM03kt0KlHVHnO9cUW	Vincenza	Ligorio	4	hutWorker20@gmail.com	\N	t	\N	t	\N	\N
28	$2b$10$lo19vucSibpFH5uYw4jOYOdUMQDWWFU6IHRi0gtZ.jXp8MxI8HyKe	Zama	Fuoco	4	hutWorker21@gmail.com	\N	t	\N	f	\N	\N
29	$2b$10$1bg9f10tPVZm5IV3QxjdCOeTnEdof/c25wt6.n1UrEZgts3Cz/wWC	Selvaggia	Sanfilippo	4	hutWorker22@gmail.com	\N	t	\N	t	\N	\N
30	$2b$10$o6MVAtn4QRumBVizQ5BcHuTv9usjmSbuxjpT8O.EYDUd/SC97Pwya	Zama	Lanza	4	hutWorker23@gmail.com	\N	t	\N	f	\N	\N
31	$2b$10$TrAHmifEa8bkdfhuyLO.L.isaulnAv5FjzWSe4KAeg3D6F3ZlVb5y	Ferruccio	Pintus	4	hutWorker24@gmail.com	\N	t	\N	t	\N	\N
32	$2b$10$n4wngfqkafzb93SI/BZ5u.G7UtbGDMXc0SfNIabXQwXiHQJ7Z62uy	Salomone	Postiglione	4	hutWorker25@gmail.com	\N	t	\N	f	\N	\N
33	$2b$10$M3D4utxzEXCiNMg5mxbsxOmlJDTjsPLkeI3UchKka6u3qyE9je4b2	Amintore	Franzoni	4	hutWorker26@gmail.com	\N	t	\N	t	\N	\N
34	$2b$10$63zot6vK3ov0iLduSRgCjujymaQH9T5AbewXnsFvPmLXDhVBypBwy	Ebe	Cianci	4	hutWorker27@gmail.com	\N	t	\N	f	\N	\N
35	$2b$10$lzopQOkN3P3P0xKDiNNL1.th4Q1HtzSa.zVKR7pySi/54kU6l8xUa	Apollina	Campo	4	hutWorker28@gmail.com	\N	t	\N	t	\N	\N
36	$2b$10$irvk.La83l6fWAQ0JqrXbevCCt3yHEiwYn4oUfaveK2slAxycjCCa	Geltrude	Valente	4	hutWorker29@gmail.com	\N	t	\N	f	\N	\N
37	$2b$10$fFx9TUlK8cxYcBMreWhgeeP9H09xn0/zIw33IBr2DHfiVCEzerILW	Bonifacio	Baroni	4	hutWorker30@gmail.com	\N	t	\N	t	\N	\N
38	$2b$10$w9O66LBmXxC2xd1/.Tvq1Oy3aDIr8X3cfT75FJrJa7qIVXunumd8m	Mirella	Cabras	4	hutWorker31@gmail.com	\N	t	\N	f	\N	\N
39	$2b$10$O/O21tBV8yROT9SPYNu.le3eZeyVIKfjKOG6c6MljPXiY541X4Eku	Ariosto	Mauri	4	hutWorker32@gmail.com	\N	t	\N	t	\N	\N
40	$2b$10$6n3HB.rHaNuwoL98TVzmyefVQxHzDinpcu/UAs7i3G1vg.63VhqIq	Veronica	Fioretti	4	hutWorker33@gmail.com	\N	t	\N	f	\N	\N
41	$2b$10$kRAA1rfV4MN/Ewlfy.dgB.IjEpYstwGiN4wDdA59NcVkwvfHAFP4K	Mamante	Tomasello	4	hutWorker34@gmail.com	\N	t	\N	t	\N	\N
42	$2b$10$52Olc7qQdNXj7okA5iC1POrmg7XdPC12s5FezkYeCqYyEhOJJdLZS	Mimma	Strano	4	hutWorker35@gmail.com	\N	t	\N	f	\N	\N
43	$2b$10$vV7IAJRPstFUOU476/XxhuMIw6XIaLp4Cv/1U2qk.KAnyBpku2YZi	Fiorenza	D'Argenio	4	hutWorker36@gmail.com	\N	t	\N	t	\N	\N
44	$2b$10$//JAXVcyVormriAxpNDUXOAA4Zu2k5vHrUtaMTzkqf2Rij3K5jsB6	Bacco	Fedele	4	hutWorker37@gmail.com	\N	t	\N	f	\N	\N
45	$2b$10$uJU6ZQtH..8RkgQJyXwHMOxpbyx5gdwxLQGahK7.nRxv/4JjFABtq	Decimo	Paola	4	hutWorker38@gmail.com	\N	t	\N	t	\N	\N
46	$2b$10$EGQDyApzkcCTUgH3V1QE7eXHH/ZqWMnqZGvBdzoYyI6hXke83hW26	Elvezio	Prisco	4	hutWorker39@gmail.com	\N	t	\N	f	\N	\N
47	$2b$10$GT8MjEKvjZZym4oDwEUGG.2.h92/elRIsaA11UjJxznKV6C7yxxzi	Erminio	Lo Cascio	4	hutWorker40@gmail.com	\N	t	\N	t	\N	\N
48	$2b$10$AGKYnJ3NeYcgEkSwLOdQQ.Y0UV.i.mMCQ1DbC5j95VwIQXq2Qizs6	Graziana	Genovese	4	hutWorker41@gmail.com	\N	t	\N	f	\N	\N
49	$2b$10$2FaV7P3RMeNnkk/ejfcXW.0tFZXBAOjSTB5AfchYWLLebsAaeb3s6	Roberta	Bortot	4	hutWorker42@gmail.com	\N	t	\N	t	\N	\N
50	$2b$10$0gp5Sk5DOibBSXDRjvQCs.hfUi6DLZucko74aeaH8BcojwYUXNUeC	Addo	Frezza	4	hutWorker43@gmail.com	\N	t	\N	f	\N	\N
51	$2b$10$MZoyWIiLVZt5WkzpP36vx.ixatN0c9XWEYXdJttKxwBUIdsHNp8Gm	Ludovico	Miglio	4	hutWorker44@gmail.com	\N	t	\N	t	\N	\N
52	$2b$10$fSEdaKz27aguB5956ZpAjeM0O6ENOT/N0fN35T/oq1rBu5oUXDhHu	Marinella	Falcone	4	hutWorker45@gmail.com	\N	t	\N	f	\N	\N
53	$2b$10$gePhe1GUQUOu8hxcgg5iEOr7rXsu.YsGzTZapjviD7LQdd9ZSGmYq	Benigna	Iannone	4	hutWorker46@gmail.com	\N	t	\N	t	\N	\N
54	$2b$10$YS3.tmfIuBwgn98RtkDRouYGWP7MhJGb3Hj59SXyRKYH1s6wO3nxu	Zanobi	Savoca	4	hutWorker47@gmail.com	\N	t	\N	f	\N	\N
55	$2b$10$2YLfVIdEqYOESjqwa8pLMukNEsp1wlLbE07zCbdkig.d0cu1hytxa	Livino	Oliva	4	hutWorker48@gmail.com	\N	t	\N	t	\N	\N
56	$2b$10$xyzhOmyfNsf3PeX.Zij.3Oh9zMcQIgwytZjKJ5.lIca7fwguZAM2m	Eracla	Ippoliti	4	hutWorker49@gmail.com	\N	t	\N	f	\N	\N
57	$2b$10$F.zioyhRYcume1.lb5prQOJbbLykLo6z9m6kOb7ASuGhOttD6iwqq	Lodovica	Ghilardi	4	hutWorker50@gmail.com	\N	t	\N	t	\N	\N
58	$2b$10$hYsdWri/QL42wzS0BFi4MusK1gvW9mTjKQx6RYSa/wh5YK4z0UEgm	Siria	Garofalo	4	hutWorker51@gmail.com	\N	t	\N	f	\N	\N
59	$2b$10$cUDPtjxnx/qE3HZWVnpQW.kznoQdsrkZCF1Pwiqb6h6mWNf7XwbE2	Primo	Antonini	4	hutWorker52@gmail.com	\N	t	\N	t	\N	\N
60	$2b$10$gtuBQu7ypmqG80c4gnOvHODxZphwb8U6qawj1u1FsBzL/KWMxW4N2	Giambattista	Filippini	4	hutWorker53@gmail.com	\N	t	\N	f	\N	\N
61	$2b$10$n5DbvsmMNcyEOri9WFubW.CdgwLuT6Fx7Dm5VoGWuG.AiZGtb/zhW	Liboria	Pirrone	4	hutWorker54@gmail.com	\N	t	\N	t	\N	\N
62	$2b$10$wMCakl84ncq5PxLZnwkbZuo7KjmA75mfTejEXuFLpME36W19B.sD6	Zarina	Nava	4	hutWorker55@gmail.com	\N	t	\N	f	\N	\N
63	$2b$10$YQFfJl9y33kwegCy8bANeuAx4iXDt36AhT6ig0MZwMXRAJlGd1kQu	Amabile	Massa	4	hutWorker56@gmail.com	\N	t	\N	t	\N	\N
64	$2b$10$p/kvteDbR1b3ETd742sVnearvz6OQLaconh4lKo/kJ/eRR.F/Tl06	Loreno	Oliveri	4	hutWorker57@gmail.com	\N	t	\N	f	\N	\N
65	$2b$10$ePe4Vrt2UD36axGCNCKkoOFqx9O0sbiHWfGY8YkQXJ40JYkRPJAZy	Flavia	Polverino	4	hutWorker58@gmail.com	\N	t	\N	t	\N	\N
66	$2b$10$nR3V0bpV0WOmpqASdsI54ufVrknpuZSxEiO.OIiiap7pyNVJZrgcS	Donato	Ceccarini	4	hutWorker59@gmail.com	\N	t	\N	f	\N	\N
67	$2b$10$oXFeF8bA/TAZG2LUUSYN8O0KNg/k5vzmMBU/wRkJBHAc7Kl.2i5OG	Mancio	Cammarata	4	hutWorker60@gmail.com	\N	t	\N	t	\N	\N
68	$2b$10$FxqRPpaqPT.DUDtmUKD37.gGhSLl.2Mnh3Rq3m4/0BP.5pFCI5t7i	Otello	Gagliardi	4	hutWorker61@gmail.com	\N	t	\N	f	\N	\N
69	$2b$10$6EJjZZyQZyGIzM9Y7uCjxe3yhsmhoZ10.D6pyliGRQZ9H0sg2SdWW	Tabita	Signorile	4	hutWorker62@gmail.com	\N	t	\N	t	\N	\N
70	$2b$10$V1P5zwdBnmmaRSEH8e.e/.Pz3QeFbc1wAediUuJmNRA1IxmtdSK8e	Iginio	Loiacono	4	hutWorker63@gmail.com	\N	t	\N	f	\N	\N
71	$2b$10$Mr08bBmZPl1oaYg4Gn9JletYESE7Jx5OeJYLd6F63POK7kjnRTQPK	Carola	Pece	4	hutWorker64@gmail.com	\N	t	\N	t	\N	\N
72	$2b$10$ekK.00hUgXygYodAKGAAQORdoObMwFdZbeYttX9CKi0hzZY6mmSqK	Bertolfo	Gigliotti	4	hutWorker65@gmail.com	\N	t	\N	f	\N	\N
73	$2b$10$MNzYyOVYsxt5acsuyM.qyO926Rk.eFhgZzCA5jKtu2o10fsekvHxG	Omar	Barbarossa	4	hutWorker66@gmail.com	\N	t	\N	t	\N	\N
74	$2b$10$mtCFPx.tcRZuaMlfPLB01OtkjOa2LKl0vLc0VAymWbop9Ps3dJT.O	Leandro	Frigo	4	hutWorker67@gmail.com	\N	t	\N	f	\N	\N
75	$2b$10$iyPyGMFccE4XYOplF0H4gev.89q/2XyIazj7TxN4T34.NosX8XXDy	Sabino	Di Lorenzo	4	hutWorker68@gmail.com	\N	t	\N	t	\N	\N
76	$2b$10$nHI38bUvHJPvnrU2KevGTeb77Afg2wxqz4sMctIKbKYyWvgVK4tZu	Cirilla	Santarelli	4	hutWorker69@gmail.com	\N	t	\N	f	\N	\N
77	$2b$10$t6Lq5XJ5QkmsiOTA8xNE2.bu7eFOD.7dxJ6Q.NI733goLkBgUCXpu	Gabino	Polidori	4	hutWorker70@gmail.com	\N	t	\N	t	\N	\N
78	$2b$10$exkV5./jRbzpGOQ2jd3sC.zBrHprdtftjJA9jmQuDJW29IA1wIDUe	Abelardo	Ambrosino	4	hutWorker71@gmail.com	\N	t	\N	f	\N	\N
79	$2b$10$SuRdcYwcpyR9Bdpi8lV24.nCfyW1MoYY/Bv3aI3lDZ8FzrhARDbpu	Abaco	De Vito	4	hutWorker72@gmail.com	\N	t	\N	t	\N	\N
80	$2b$10$otI.lAS./MdndkDpZITmS.JMPOtKN0qCIkIukWBnzuVhcL0EuUiwa	Quintiliano	Coppola	4	hutWorker73@gmail.com	\N	t	\N	f	\N	\N
81	$2b$10$grwC1zdDlrXtT1riqAUZd.CasveTrSJb/h35mfzOuezYqF2C3ah3i	Maffeo	Sorrentino	4	hutWorker74@gmail.com	\N	t	\N	t	\N	\N
82	$2b$10$7lLMWPSbvoxeS1KYM/It5uxtBUKqze6NwpEVWtOfXlscwBxf/WgCe	Tea	Giaccio	4	hutWorker75@gmail.com	\N	t	\N	f	\N	\N
83	$2b$10$IDCtMk1aQDJpn2VfxKwGRuibd5sAPVHNxjC3a2KQi/gFvoJVqPKw.	Imelda	Siri	4	hutWorker76@gmail.com	\N	t	\N	t	\N	\N
84	$2b$10$D4jTZu88L7b8p.1B30A7PesXoOU7HNZ8R2R4Rb7UZncMg056yzR72	Antonia	Stanzione	4	hutWorker77@gmail.com	\N	t	\N	f	\N	\N
85	$2b$10$XpK9fXNyCXf0DCX53PeQ0ui3FgTjDVc6tirgvW/ZMUKJW/Xc8a8t2	Zoe	Guastone	4	hutWorker78@gmail.com	\N	t	\N	t	\N	\N
86	$2b$10$1bQe8hu6UR5uwZPspQXE2.xV5xyHeLT9bOgaRQRsDFylrRjvVnd/q	Monica	Matta	4	hutWorker79@gmail.com	\N	t	\N	f	\N	\N
87	$2b$10$84Y3hRKYAR7C9SXSekiGM.z2O.xSV0wJ..AbNRrjodtiA9r0SWRt.	Giotto	Palombo	4	hutWorker80@gmail.com	\N	t	\N	t	\N	\N
88	$2b$10$cDmQ5/d5IVq.Cup0kWnLRev8VNiIO16kk3wyNZfganPgnZkwHLgSK	Terzo	Benini	4	hutWorker81@gmail.com	\N	t	\N	f	\N	\N
89	$2b$10$jggztkbwh6xezFpyXQE2gOQtkX2LTcNKAAbzKMDLxSqawRQLH0WD.	Capitolina	Bresciani	4	hutWorker82@gmail.com	\N	t	\N	t	\N	\N
90	$2b$10$ruvsOlBgb8Y3mzBPGZs7nOCRiTwkSJiQ.brGPtEESbpLGVVk40t5O	Cesario	Vizziello	4	hutWorker83@gmail.com	\N	t	\N	f	\N	\N
91	$2b$10$F7Vdzb3/kLOnErK6mp97LeXPHm9MQqBNRuSVxwAhhRdGjguD92O9y	Rosa	Rigoni	4	hutWorker84@gmail.com	\N	t	\N	t	\N	\N
92	$2b$10$AFizYjUyKKtRgzbXEzGTl.YRQrgldqh8ltM.FFg.EzRdyug3Q.1mS	Giuseppina	Pandolfi	4	hutWorker85@gmail.com	\N	t	\N	f	\N	\N
93	$2b$10$LAY.I5fqF7pT0YrhbSy/yOjfBC8MkyAIqkVJi8hfltKEij0B74Y56	Crescenzia	Luciani	4	hutWorker86@gmail.com	\N	t	\N	t	\N	\N
94	$2b$10$YroJuaUC9OPbwfx8ygQAVOsAO6/Gz9Nl5V/iFOtI92UXFBJrDKqMS	Turi	Boscolo	4	hutWorker87@gmail.com	\N	t	\N	f	\N	\N
95	$2b$10$2DwkZ8rZ4JkiGqI9FF1D7eTwGQf.hBUFONdJ./6b5AGfqmtrNYTEi	Rosalia	Barberi	4	hutWorker88@gmail.com	\N	t	\N	t	\N	\N
96	$2b$10$Cya0tK43XfSFbBeYOUHXuOW0HEKSYm0uFAPjNIqAlBdy/lv/SwBAS	Bassilla	Rocca	4	hutWorker89@gmail.com	\N	t	\N	f	\N	\N
97	$2b$10$bQ7.ydAyMZzLCFOFM5/ffuGVuXHC5yO3KxasCi3Pr8F/4vZBu8ENG	Scolastica	Mosca	4	hutWorker90@gmail.com	\N	t	\N	t	\N	\N
98	$2b$10$T32qDxXz1g5Z7MbLD2A8HeSMZngzL92Fdmv7rErjauFgkAibnXmwy	Vittoria	Spadoni	4	hutWorker91@gmail.com	\N	t	\N	f	\N	\N
99	$2b$10$NnhDoULv9cV0JZC7r5Ki9eElNx7LApDxgGT7d16OfTIiJMsm6iYHG	Genesia	Montagna	4	hutWorker92@gmail.com	\N	t	\N	t	\N	\N
100	$2b$10$0b5pu.BInN7tzhtqNUv0DekN93gQwSZ9wnXiGIUqbuf4K6QCCkkoK	Rosanna	Olla	4	hutWorker93@gmail.com	\N	t	\N	f	\N	\N
101	$2b$10$9ygCj4NAPpp7uNudTpI3.uVNkurvIIG3MipJge454HmKfpqOLBv4O	Fiorella	Branca	4	hutWorker94@gmail.com	\N	t	\N	t	\N	\N
102	$2b$10$9UQzvCtHz3FprwcIRyGTQ.oFlh5dhYc4DxFLSTh6ZvYl0lDUnUjw.	Giocondo	Forlani	4	hutWorker95@gmail.com	\N	t	\N	f	\N	\N
103	$2b$10$TFhz1cMnWOzJBLNYfpN9j.b6GXAlorWMFB8t6Af7rsX0OqePiNJa.	Gianpaolo	Gamper	4	hutWorker96@gmail.com	\N	t	\N	t	\N	\N
104	$2b$10$q2DwtbbsmOn7GPLsQ4gj/OxynIAG/TNMytqoL6pWx4UC0JiF2o4S2	Perseo	Spinelli	4	hutWorker97@gmail.com	\N	t	\N	f	\N	\N
105	$2b$10$tJ49BkmbF0/W.VrvQyoJTO.agkpTgO0NHhuOI6It1fqNz6iS4yn/W	Brigida	Migliaccio	4	hutWorker98@gmail.com	\N	t	\N	t	\N	\N
106	$2b$10$WA8wRhOG2/kSpbUKvly7SOYnruD41lHvI.aMAXR6KRMWVoUWPXE4S	Corinna	Casano	4	hutWorker99@gmail.com	\N	t	\N	f	\N	\N
107	$2b$10$/RLibOjBvxYDwanmcz/diOCJB3aRU4chBvksfKzgsXvb11uoiPUVu	Ausilia	Pagani	4	hutWorker100@gmail.com	\N	t	\N	t	\N	\N
108	$2b$10$Zec/ejv8w5ubBkQUEoSMQeKvLXpanbGpTirTdTyHaQmL3KhSwHldm	Adelaide	Ruggiero	4	hutWorker101@gmail.com	\N	t	\N	f	\N	\N
109	$2b$10$1ekvbIqZ7BO5ZHFDmHDLVuV6z4YgvYEoORBDSu1FJO8jP3tlrs11C	Onorino	Cesaretti	4	hutWorker102@gmail.com	\N	t	\N	t	\N	\N
110	$2b$10$aThM3YxPC8mmXVjAN5ukYOvaCjBM0lpdJXfbQcDeIeQZC84m1USlK	Antonello	Marciano	4	hutWorker103@gmail.com	\N	t	\N	f	\N	\N
111	$2b$10$ij8PFgmvKtgcvEqD.sNR5.kH/BFJtuzy73dcZwQApOt.QswavswLy	Luce	Mingarelli	4	hutWorker104@gmail.com	\N	t	\N	t	\N	\N
112	$2b$10$Y8tplQo/3PpQ1ZIuFVKl1uh7kAoeIeimbsjXuL5obwRAAvLMMFOJ2	Venera	Malerba	4	hutWorker105@gmail.com	\N	t	\N	f	\N	\N
113	$2b$10$SmX7HumQKOjlPbzU1aw96OyZK5/Us0ThbPwrjpWIKLmxjHDvFdSoO	Dolores	Giannetti	4	hutWorker106@gmail.com	\N	t	\N	t	\N	\N
114	$2b$10$Bf.jrYqTFD2F5h66/AyH8O96tHm.L.thx38.UkrNnsZhtMlb7o54m	Lodovico	Lombardo	4	hutWorker107@gmail.com	\N	t	\N	f	\N	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 49, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 108, true);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 256, true);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 475, true);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_hikes_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

