--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$LHIBbSXHu..0yZYzSDxQU.cjKW5YIiY.QKZozfMh6pDL7vTxISofS',
    'Antonio',
    'Battipaglia',
    2,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$Nf0KK/8eD9Ot6JlYrfp1D.Vid0bxYRyhEDsMLFNG7j78pkPH1sti.',
    'Erfan',
    'Gholami',
    4,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$Nqs3fqSyFrQUA9lW1f2mueCJswMaKr0Xp/kCA/upHQD9Bfdr2nIEq',
    'Laura',
    'Zurru',
    5,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$svwyk67Pw6IsmJBt/jk/2e1twPOPjg4iiFEPiFEvTFeZxCEPy8uf2',
    'German',
    'Gorodnev',
    0,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$f0Lw/g2YJ0et9VuZcRGQjuVsGz2oIO5TLJFH2Cu.Nt12YuiJE6c42',
    'Vincenzo',
    'Sagristano',
    3,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    6,
    'francesco@friend.it',
    '$2b$10$mPAqKlAQWPSU/1CiJLXvt.AjHvpuFBGCNTVanmzRUlbP.w9wl/0m2',
    'Francesco',
    'Grande',
    1,
    true,
    true
  );
  

      CREATE OR REPLACE FUNCTION public.insert_hike(
        user_id integer,
        title varchar,
        difficulty integer,
        gpx_path varchar,
        country varchar,
        region varchar,
        province varchar,
        city varchar,
        length numeric(12,2),
        ascent numeric(12,2),
        expected_time integer,
        description varchar,
        pictures jsonb,
        start_point jsonb,
        end_point jsonb,
        reference_points jsonb
      )  RETURNS VOID AS
      $func$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hike"(
        2,
        'Amprimo',
        2,
        '/static/gpx/Amprimo.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        0.6,
        22.6,
        80,
        'Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.',
        '["/static/images/3.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.165559804,"lat":45.102780737}'::jsonb,
        '{"name":"End Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.14299586,"lat":45.099887898}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":7.164360252,"lat":45.102912389,"altitude":1256.852},{"name":"Ref Point 2","address":"","lon":7.158207147,"lat":45.102886551,"altitude":1283.605}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello Chateau Beaulard - Cotolivier - Vazon',
        1,
        '/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Beaulard',
        16,
        27.6,
        200,
        'Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.',
        '["/static/images/2.jpg"]'::jsonb,
        '{"name":"Start Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.772358,"lat":45.03205}'::jsonb,
        '{"name":"End Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.77234,"lat":45.032238}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'borgata ruà a cima di crosa',
        1,
        '/static/gpx/Borgata Ruà-Cima di Crosa (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Sampeyre',
        5387.070533803441,
        955.0963319999998,
        150,
        'Raggiungi la partenza del Sentiero per la Cima di Crosa impostando sul navigatore “Borgata Ruà – Becetto“.

Parcheggiata la macchina a Borgata Ruà (o se impossibilitati a trovare un parcheggio anche a Becetto, allungando di 10 minuti il giro), si prende il sentiero sulla sinistra, nei pressi di una cartina (INDICAZIONI CIMA DI CROSA).',
        '["/static/images/46.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia","lon":7.201825,"lat":44.596613}'::jsonb,
        '{"name":"End Point","address":"Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia","lon":7.177367,"lat":44.615185}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Colle della Gianna da Pian della Regina',
        2,
        '/static/gpx/Colle Della Gianna (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        3622.3230077193216,
        865.2000000000003,
        130,
        'Colle della Gianna at an altitude of approximately 2530m connects the Po Valley to the Pellice Valley allowing you to reach the Barbara Lowrie refuge, an ideal base for multi-day crossings.

It is advisable to carefully consult the weather forecasts especially for these areas frequently subject to very thick fog.

Being at moderately high altitudes in spring there is the possibility of finding tongues of snow that could make the ascent more difficult.',
        '["/static/images/37.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia","lon":7.114553963765502,"lat":44.70202149823308}'::jsonb,
        '{"name":"End Point","address":"Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia","lon":7.103742817416787,"lat":44.722054582089186}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Hike Zicher',
        3,
        '/static/gpx/Hike_Zicher (2).gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Craveggio',
        3221.31231047859,
        712.936152,
        120,
        'Lungo l’itinerario non è garantita la piena copertura telefonica
In periodo estivo, la parte finale può essere molto esposta al sole e richiedere fatica.
In condizioni di vento forte, è preferibile non proseguire
E’ possibile sviluppare un itinerario ad anello scendendo dal versante nord della montagna in direzione Bocchetta Sant’Antonio (ma attenzione ad un passaggio su rocce, soprattutto se ghiacciate).',
        '["/static/images/29.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia","lon":8.534505,"lat":46.147128}'::jsonb,
        '{"name":"End Point","address":"Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia","lon":8.534103,"lat":46.163437}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Usseaux Altro',
        2,
        '/static/gpx/Laghi_Albergian.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Usseaux',
        15636.670195666402,
        1366.7991943359375,
        150,
        'The flowering of Eriofori along the shores of the lake between July and August is interesting, making it very suggestive.',
        '["/static/images/40.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025457266718149,"lat":45.0393102876842}'::jsonb,
        '{"name":"End Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025509485974908,"lat":45.039591416716576}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Usseaux Altro',
        3,
        '/static/gpx/Laghi_Albergiani.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Usseaux',
        15636.670195666402,
        1366.7991943359375,
        150,
        'Itinerario vario e panoramico, non presenta particolari difficoltà ma per la lunghezza, il dislivello, la mancanza di punti di appoggio e la necessità di una certa capacità di orientamento su sentieri non sempre evidenti (specialmente per la variante in discesa) è consigliato a escursionisti allenati e esperti.',
        '["/static/images/42.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025457266718149,"lat":45.0393102876842}'::jsonb,
        '{"name":"End Point","address":"Laux, Usseaux, Torino, Piemonte, Italia","lon":7.025509485974908,"lat":45.039591416716576}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago Bianco',
        2,
        '/static/gpx/Lago Bianco.gpx',
        'Francia',
        'Auvergne-Rhone-Alpes',
        'Savoia',
        'Val-Cenis',
        3.5,
        22.9,
        210,
        'Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.

La diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.

La Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.

Si può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.',
        '["/static/images/1.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945681,"lat":45.223814}'::jsonb,
        '{"name":"End Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945581,"lat":45.224058}'::jsonb,
        '[{"name":"fountain","address":"","lon":6.940291,"lat":45.222543,"altitude":2027},{"name":"Peak","address":"","lon":6.937204,"lat":45.215867,"altitude":2131}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Lago dei 7 colori (lago gignoux)',
        2,
        '/static/gpx/Lago dei 7 colori (lago gignoux) (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Claviere',
        21358.82545547226,
        1087.900000000002,
        170,
        'Parcheggia a Claviere e dirigiti verso la strada comunale Valle Gimont che, dopo poco, si fa sterrata.

Lascia alla tua destra i cartelli che indicano il Lago Gignoux e prosegui risalendo le piste da sci.

Giunto a Sagna Longa noterai che la zona è di interesse sciistico, infatti ci sono numerosi arrivi di seggiovia. Segui le indicazioni per Colle Bercia, attraversa una chiesetta, dei caseggiati in pietra e prosegui per il largo sentiero.

L’intero percorso si sviluppa circondato dai bellissimi Monti della Luna ed è caratterizzato da una dolce e semicostante salita su terreno sterrato a tratti ghiaioso.

Superato il Colle Bercia continua sull’ampia carreggiata che ti conduce ad un valico nel quale noterai particolari conformazioni rocciose e una punta (Cima Saurel 2451 mt). Tieniti sul sentiero basso e supera il valico, che segna anche il confine con la Francia, dopo il quale troverai il lago immerso in una conca.',
        '["/static/images/51.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia","lon":6.749585,"lat":44.938467}'::jsonb,
        '{"name":"End Point","address":"Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia","lon":6.749585,"lat":44.938467}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago d''Afframont 1986 m',
        2,
        '/static/gpx/Lago di Afframont 1986 m.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Balme',
        4024.727690039548,
        810.8999999999994,
        120,
        'Una volta parcheggiata la macchina dirigiti verso il villaggio Albaron. Poco dopo i caseggiati ti troverai di fronte ad un impianto di risalita dismesso, a sinistra troverai un campetto da calcio, proprio dopo il campetto si intravedono i primi cartelli con le indicazioni per il Lago di Afframont. Il sentiero da seguire è il 213, ma lungo il tragitto troverai solo bandiere bianco/rosse e cartelli di legno che indicano la destinazione.

Si sale l’ex pista da sci e ci si addentra nel bosco. Il primo tratto rimane ombreggiato, mentre inizia a farsi sentire la salita. Ad un certo punto ci si affianca ad un ruscello, il Rio di Afframont, che scorre sulla sinistra e si supera con facilità in prossimità dei caseggiati in pietra (attenzione nei periodi di pioggia perché potrebbe essere impraticabile).',
        '["/static/images/52.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia","lon":7.223873427137733,"lat":45.30158649198711}'::jsonb,
        '{"name":"End Point","address":"Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia","lon":7.238771421834827,"lat":45.292359441518784}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Briccas da Borgata Brich 20/02/21',
        2,
        '/static/gpx/Monte Briccas da Brich (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        7580.49492167635,
        1049.2599999999993,
        110,
        'After leaving the car, we continue along the road, first paved and then dirt.

In case of little snow or high temperatures it is possible to cover the first 150m in altitude without snowshoes.

As soon as we hit the first snow, we put on our snowshoes and set off on a well-defined path that crosses a wood.

After having left the last huts behind us, we turn right towards the North/East near a GTA trail sign painted on a boulder.

From here, after the last bush, an enormous, very wide slope opens up before us which culminates right at our peak',
        '["/static/images/35.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia","lon":7.159385243430734,"lat":44.70842678099871}'::jsonb,
        '{"name":"End Point","address":"Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia","lon":7.158207753673196,"lat":44.708156045526266}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Monte Ferra Con Marco e Daniel',
        3,
        '/static/gpx/Monte Ferra (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cuneo',
        11664.786185753126,
        1472.7999999999993,
        150,
        'Fondamentali i bastoncini specialmente nella discesa dal Monte Ferra al lago Reisassa.

Unico punto di appoggio è il rifugio Melezè ad inizio itinerario (consigliamo di contattare direttamente la struttura per verificare giorni e orari di apertura)',
        '["/static/images/28.jpg"]'::jsonb,
        '{"name":"Start Point","address":"SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia","lon":6.982689192518592,"lat":44.57425086759031}'::jsonb,
        '{"name":"End Point","address":"SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia","lon":6.982647031545639,"lat":44.574263943359256}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Crissolo a Ghincia',
        2,
        '/static/gpx/Monte Granè (2).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        6229.073301997005,
        1024.7599999999993,
        200,
        'The Path to Monte Granè is a suggestive walk with a splendid view of Monviso (3841 m) and Viso Mozzo (3019 m).

Leave the car in the car park and continue to the left of the sports field where a splendid path immersed in the woods appears before us and after about 1.5 km you come to the dirt road which in summer leads to the Black Eagle refuge.

Continuing on the latter and having reached the refuge, continue along the Crissolo slopes to the end of the ski-lift where, just above the Ghincia Pastour hut, we will find a statue of the Madonna to indicate the end of the path to Monte Granè.

The return takes place along the same route as the outward journey.',
        '["/static/images/36.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.151954518631101,"lat":44.70016373321414}'::jsonb,
        '{"name":"End Point","address":"Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.121506668627262,"lat":44.688729643821716}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Montr Pigna da Prea',
        2,
        '/static/gpx/Monte Pigna Da Prea (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Roccaforte Mondovì',
        6588.816640728274,
        936.79,
        150,
        'Posteggiata la macchina nel parcheggio sotto l’abitato di Prea ci dirigiamo lungo la strada asfaltata situata sotto il cimitero, lasciandocelo sulla destra.

Appena incontriamo la prima neve possiamo allacciare le ciaspole e proseguire fino alla borgata di Sant’Anna di Prea. (Nei mesi invernali, con nevicate nella norma, la strada viene pulita fino al parcheggio quindi si può iniziare ad indossare le ciaspole fin da subito).

Subito dopo il cartello, all’ingresso di Sant’Anna di Prea, sulla destra vi è un magnifico sentiero immerso nel bosco che permette di tagliare la borgata accorciando la salita di circa 1 km.

Incrociando nuovamente la strada principale e percorrendo circa 3 km si giunge alla Baita Monte Pigna situata a metà degli impianti di Lurisia.',
        '["/static/images/47.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Pigna - Gardiola, Chiusa di Pesio, Cuneo, Piemonte, 12088, Italia","lon":7.738071503117681,"lat":44.27760533988476}'::jsonb,
        '{"name":"End Point","address":"","lon":7.702411115169525,"lat":44.25919541157782}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pian della Regina - Laghi del Monviso',
        2,
        '/static/gpx/Pian della Regina - Laghi del Monviso (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        10065.934631649065,
        842.6999999999998,
        130,
        'The excursion can start near the Po, parking the car in one of the many spaces available. Once you have crossed the stream, follow via Ruata.

To get your bearings in Crissolo, we suggest following the signs for "La Capanna" and ignoring the various detours on the left that follow the ski lifts. Before reaching the restaurant, you finally take the road, following the signs for Monte Tivoli.

The path climbs up into the wood (splendid during the autumn season) and crosses the Sbarme stream.',
        '["/static/images/32.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.117767,"lat":44.700645}'::jsonb,
        '{"name":"End Point","address":"Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia","lon":7.117535,"lat":44.700759}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Fenestrelle Escursionismo',
        2,
        '/static/gpx/Rif. Selleries.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        7281.87058844728,
        504.40087890625,
        120,
        'Itinerario di medio sviluppo con ampio panorama verso la Val Chisone.

Attenzione nella stagione invernale: la zona soggetta a valanghe in caso di abbondanti precipitazioni nevose, specialmente nella conca che precede il rifugio.

Informarsi sempre sullo stato della neve presso i gestori del rifugio o l’ufficio turistico di Fenestrelle.',
        '["/static/images/43.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia","lon":7.0737862307578325,"lat":45.03657284192741}'::jsonb,
        '{"name":"End Point","address":"Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia","lon":7.120104543864727,"lat":45.047753965482116}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Meira Garneri da Sampeyre',
        0,
        '/static/gpx/Rifugio Meira Garneri da Sampeyre (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Sampeyre',
        4156.23862253066,
        850.7600000000003,
        150,
        'Lascia l’auto nel parcheggio della seggiovia di Sampeyre.

Lasciato il parcheggio saliamo subito a destra degli impianti di risalita, dove alcuni cartelli rossi ci segnalano il sentiero attraverso il bosco.

Prendendo rapidamente quota, alla fine del primo tratto di boscoso, raggiungiamo la frazione Sodani dove possiamo osservare la bella chiesa affrescata.

Usciti dalla borgata proseguiamo nuovamente lungo il sentiero circondati da larici, faggi, betulle e dopo alcune deviazione, sempre ben segnalate, usciamo in una splendida radura.

Saliamo gli ultimi 200m a lato della pista o volendo possiamo proseguire più a destra incrociando la strada carrozzabile che nel periodo estivo porta al rifugio.',
        '["/static/images/45.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia","lon":7.180788516998291,"lat":44.57619898952544}'::jsonb,
        '{"name":"End Point","address":"Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia","lon":7.155619841068983,"lat":44.55683704465628}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per ROCCA PATANUA',
        2,
        '/static/gpx/Rocca Patanua da Prarotto (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Condove',
        4388.161778983409,
        923.6238601720527,
        200,
        'Itinerario interamente rivolto a Sud che normalmente si libera dalla neve già a inizio primavera.

(l’itinerario è stato svolto in periodo invernale, seguito scarsa e quasi totalmente assente copertura nevosa).',
        '["/static/images/28.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Alpe Tulivit, Condove, Torino, Piemonte, Italia","lon":7.237061262130737,"lat":45.14908790588379}'::jsonb,
        '{"name":"End Point","address":"Alpe Tulivit, Condove, Torino, Piemonte, Italia","lon":7.219639476388693,"lat":45.17825868912041}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Cima Durand-Colle Bauzano-Artesina',
        3,
        '/static/gpx/Senriero per Anello cima Durand, Colle Bauzano, Artesina (1) (1).gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Artesina',
        8085.211186643268,
        829.1299999999999,
        150,
        'Lasciata la macchina nello spazioso parcheggio di Artesina o nei posteggi vicino al bar Tana del Lupo, saliamo sulle piste dove possiamo subito infilare le ciaspole.

Procediamo per circa 400m sull’ampio sentiero in direzione Ovest (a destra) e dopo alcuni tornanti troviamo un bivio (a sinistra vi è la stradina che percorreremo al ritorno) dove proseguiamo sulla destra (sentiero F02) dirigendoci verso la Celletta, punto panoramico sulla valle Ellero.

Percorriamo il sentiero per Serra della Turra che ci porta prima a passare sotto la seggiovia e poi ad un pianoro dove troviamo la Baita della Turra, tappa ideale per un eventuale break o colazione.',
        '["/static/images/48.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia","lon":7.755467472597957,"lat":44.24691265448928}'::jsonb,
        '{"name":"End Point","address":"Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia","lon":7.754717627540231,"lat":44.246627166867256}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Quintino Sella e Viso Mozzo',
        1,
        '/static/gpx/Sentiero per Rifugio Quintino Sella e Viso Mozzo.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Crissolo',
        9039.751801123071,
        1090.660000000001,
        120,
        'The path does not present any difficulty, in case of rain, however, the climb is not recommended as the route is entirely on stony ground.

From up there you have a privileged view of a large part of the Monviso chain and the close distance to the Re di pietra is unique.',
        '["/static/images/31.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia","lon":7.094606207683682,"lat":44.70125044696033}'::jsonb,
        '{"name":"End Point","address":"Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia","lon":7.109863618388772,"lat":44.66575786471367}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Ss659 a Ss6591',
        3,
        '/static/gpx/Sentiero per Rupe del Gesso - CIASPOLE.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Formazzo',
        16969.02550810036,
        984.23046875,
        120,
        'Take the A26 motorway towards Gravellona Toce and follow it to the end. From there stay on the SS33 del Sempione passing Domodossola. At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls. There are unpaved parking lots just before the Centro Fondo Riale.',
        '["/static/images/38.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia","lon":8.41653149574995,"lat":46.41965291462839}'::jsonb,
        '{"name":"End Point","address":"Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia","lon":8.41653149574995,"lat":46.41965291462839}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Albogno-Pieve Margineta Mater',
        2,
        '/static/gpx/albogno-pieve-margineta-mater-27-8-21.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Albogno',
        11301.8785751773,
        1381.6880000000006,
        140,
        'Escursione senza molte difficoltà ideale per il periodo primaverile e autunnale. 
Dopo circa 2 ore di bosco si esce su delle creste molto panoramiche e semplici, il ritorno purtroppo viene fatto su un sentiero poco segnato sulla parte iniziale e ma man mano che si scende compiano sia segni e gli ometti.',
        '["/static/images/11.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia","lon":8.421405,"lat":46.139077}'::jsonb,
        '{"name":"End Point","address":"Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia","lon":8.421395,"lat":46.139111}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Alte Langhe Settentrionali - Cossano Belbo',
        2,
        '/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cossano Belbo',
        2.7,
        7,
        200,
        'Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.
Si svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.
Si imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.
Inizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.
Percorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. 
Seguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. 
Si procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante',
        '["/static/images/4.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199049,"lat":44.670379}'::jsonb,
        '{"name":"End Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199052,"lat":44.670377}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":8.214142,"lat":44.674545,"altitude":482.526},{"name":"Ref Point 2","address":"","lon":8.197792,"lat":44.668772,"altitude":242.585}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello per il Monte Freidour (PERLEVIEDELMONDO)',
        2,
        '/static/gpx/anello monte freidour (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'San Pietro Val Lemina',
        8503.263605697935,
        558.511400000002,
        150,
        'At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls.',
        '["/static/images/39.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia","lon":7.284098,"lat":44.96472}'::jsonb,
        '{"name":"End Point","address":"Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia","lon":7.284125,"lat":44.964785}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Anello Pieve di Ledro-Biacesa di Ledro-Rifugio Nino Pernici',
        2,
        '/static/gpx/anello-pieve-di-ledro-biacesa-di-ledro-rifugio-nino-pernici.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        42458.63040670248,
        23175.26399999994,
        320,
        'Anello sui monti a nord-est del Lago di Ledro, percorso in 3 giorni andando con molta calma, percorribile anche in 2. 
Alcuni tratti della prima metà del percorso sono attrezzati con scale e corde.',
        '["/static/images/14.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.73147,"lat":45.882851}'::jsonb,
        '{"name":"End Point","address":"Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731364,"lat":45.882702}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Anello sui colli imolesi: Dozza - Pieve S. Andrea',
        2,
        '/static/gpx/anello-sui-colli-imolesi-dozza-pieve-s-andrea-valsellustra-s.gpx',
        'Italia',
        'Emilia-Romagna',
        'Bologna',
        'Dozza',
        19320.58160760896,
        666.374,
        210,
        'Crossing the provincial road you can see the first of the various signs of the Camino di San Antonio that we will find along the way. We cross and begin a slow but constant climb alongside the fields, which will lead us to a beautiful panoramic view of the surrounding valleys. Paying attention to the crossroads, we continue until we cross the paved road again. In reality there is very little traffic... with a decent view of the Vena del Gesso Romagnola we arrive at the delightful village of Pieve Sant''Andrea (worth a quick detour), to then resume our journey. Be careful not to follow the path of Sant''Antonio, we descend rapidly (shortly after we find the Sorgente delle Accarisie on our left, already existing in Roman times) until we reach the small hamlet of Valsellustra. Here too we cross the road and follow the paved via delle Ville uphill to arrive at a first panoramic point over the surrounding gullies.',
        '["/static/images/21.jpg"]'::jsonb,
        '{"name":"Start Point","address":"5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia","lon":11.632106,"lat":44.359936}'::jsonb,
        '{"name":"End Point","address":"5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia","lon":11.63228,"lat":44.359936}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Campione Pieve Campione',
        2,
        '/static/gpx/campione-pieve-campione.gpx',
        'Italia',
        'Lombardia',
        'Brescia',
        'Campione del Garda',
        10764.501653316338,
        1852.4639999999995,
        300,
        'Campione Pieve Campione',
        '["/static/images/17.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia","lon":10.749084,"lat":45.752875}'::jsonb,
        '{"name":"End Point","address":"Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia","lon":10.749743,"lat":45.757881}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Casalfiumanese (BO) - Pieve di Sant''Andrea',
        2,
        '/static/gpx/casalfiumanese-bo-pieve-di-santandrea.gpx',
        'Italia',
        'Emilia-Romagna',
        'Bologna',
        'Casal Fiumese',
        15650.261397546863,
        838.3309999999993,
        210,
        'Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don''t die from the heat and the clouds filter the sun''s rays and allow you to better enjoy the landscapes',
        '["/static/images/24.jpg"]'::jsonb,
        '{"name":"Start Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616255,"lat":44.29726}'::jsonb,
        '{"name":"End Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616326,"lat":44.297235}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Casalfiumanese (BO) - Pieve di Sant''Andrea',
        2,
        '/static/gpx/casalfiumanese-bo-pieve.gpx',
        'Italia',
        'Emilia-romagna',
        'Bologna',
        'CasalFiumese',
        15650.261397546863,
        838.3309999999993,
        210,
        'Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don''t die from the heat and the clouds filter the sun''s rays and allow you to better enjoy the landscapes',
        '["/static/images/25.jpg"]'::jsonb,
        '{"name":"Start Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616255,"lat":44.29726}'::jsonb,
        '{"name":"End Point","address":"3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia","lon":11.616326,"lat":44.297235}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Cavriana pieve- Volta mantovana chiesetta Madonna dei Marchi',
        1,
        '/static/gpx/cavriana-pieve-volta-mantovana-chiesetta-madonna-dei-marchi.gpx',
        'Italia',
        'Lombardia',
        'Mantova',
        'Cavriana',
        17987.27359307591,
        651.414999999999,
        150,
        'Bellissima passeggiata con displivello',
        '["/static/images/13.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia","lon":10.613546,"lat":45.347279}'::jsonb,
        '{"name":"End Point","address":"Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia","lon":10.614472,"lat":45.347241}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":10.625996,"lat":45.345584,"altitude":130.117},{"name":"Ref Point 2","address":"","lon":10.633173,"lat":45.34138,"altitude":139.742},{"name":"Fontain","address":"","lon":10.647482,"lat":45.332552,"altitude":107.319}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per CIMA CIANTIPLAGNA',
        2,
        '/static/gpx/ciantiplagna.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Meana di Susa',
        5474.279781243261,
        791.5095210000009,
        140,
        'The route is safe and within everyone''s reach, even though you reach a relatively high altitude... for this reason it is good to take into account sudden changes in the weather (wind, rain, thick fog).

Due to the total absence of shading, I recommend sunscreen cream and adequate water supply.

In late spring it is still possible to find accumulations of snow which can make the ascent difficult, especially in the final stretch towards the summit.

For cheese lovers, I highly recommend a stop at the Pian dell''Alpe bergeria...',
        '["/static/images/41.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Cima Ciantiplagna, Strada militare del Colle dell''Assietta, Bergerie dell''Assietta, Usseaux, Torino, Piemonte, Italia","lon":7.053414,"lat":45.071918}'::jsonb,
        '{"name":"End Point","address":"Cima Ciantiplagna, Strada militare del Colle dell''Assietta, Bergerie dell''Assietta, Usseaux, Torino, Piemonte, Italia","lon":7.012962,"lat":45.072133}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Da Voltino a Pieve di Tremosine e ritorno',
        2,
        '/static/gpx/da-voltino-a-pieve-di-tremosine-e-ritorno.gpx',
        'Italia',
        'Lombardia',
        'Brescia',
        'Tremosine sul Garda',
        6588.816640728274,
        936.79,
        120,
        'Fa quasi paura ad avvicinarsi alla ringhiera. 
Vicino alla postazione panoramica presso il bar ristorante che ho fotografato, c''è l''inizio del sentiero per la discesa al Porto di Tremosine.C''è scritto che è consigliato per escursionisti esperti.',
        '["/static/images/15.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia","lon":10.764297,"lat":45.782504}'::jsonb,
        '{"name":"End Point","address":"Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia","lon":10.763028,"lat":45.782797}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Dalla chiesa romanica di San Pietro di Fenestrella alla abba...',
        2,
        '/static/gpx/dalla-chiesa-romanica-di-san-pietro-di-fenestrella-alla-abba.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Albugnano',
        13691.922955982358,
        584.9190000000001,
        150,
        'Chiesa di San Pietro de Fenestrella: 
La chiesa è situata nel cimitero di Albugnano. 
Essa ha affinità compositive con la Canonica di santa Maria di Vezzolano e deriverebbe il suo nome ,secondo alcuni,dalla insolita presenza di tre finestre nell’abside,secondo altri, sarebbe stata così denominata perchè situata nello stretto colle (una gola) compreso tra il rilievo collinare di Albugnano e il rilievo ove sorge il cimitero: 
Una specie di finestra aperta sulla valle sottostante.',
        '["/static/images/27.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia","lon":7.97125,"lat":45.077934}'::jsonb,
        '{"name":"End Point","address":"Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia","lon":7.971227,"lat":45.077991}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Gulo - Pieve Vergonte',
        1,
        '/static/gpx/gulo-pieve-vergonte.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Santa Maria',
        14496.863954985321,
        832.3479999999993,
        90,
        'Gulo - Pieve Vergonte',
        '["/static/images/9.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia","lon":8.248234,"lat":45.997598}'::jsonb,
        '{"name":"End Point","address":"Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia","lon":8.264287,"lat":46.004814}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Il giro del Montorfano: la chiesa romanica, il borgo e la ve...',
        2,
        '/static/gpx/il-giro-del-montorfano-la-chiesa-romanica-il-borgo-e-la-vett.gpx',
        'Italia',
        'Piemonte',
        'Verbano-Cusio-Ossola',
        'Bracchio',
        9623.856463002363,
        697.1199999999999,
        210,
        'Il giro del Montorfano: la chiesa romanica, il borgo e la vetta',
        '["/static/images/10.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia","lon":8.448922,"lat":45.960306}'::jsonb,
        '{"name":"End Point","address":"Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia","lon":8.448922,"lat":45.960306}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'La chiesa romanica di S. Vittore(anello Montemagno--Viarigi)',
        3,
        '/static/gpx/la-chiesa-romanica-di-s-vittoreanello-montemagno-viarigi.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montemagno',
        12572.716765417841,
        341.5519999999999,
        210,
        'Il percorso si svolge prevalentemente su sterrata. 
Esso non ha segnaletica ad eccezione dell’ultimo tratto (due km. circa) da località Madonna del Gombo fino a Montemagno. 
In questo tratto si incontra la segnaletica del sentiero n.507 della Regione Piemonte.',
        '["/static/images/6.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia","lon":8.323294,"lat":44.983183}'::jsonb,
        '{"name":"End Point","address":"Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia","lon":8.323553,"lat":44.983388}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'La pieve romanica di Piesenzana e la valle delle tartufaie',
        2,
        '/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montechiaro d''Asti',
        7.6,
        5.7,
        225,
        'Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. 
Circa 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. 
In regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. 
A Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). 
Contemporaneamente i ristoranti della zona propongono piatti a base di tartufi',
        '["/static/images/5.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.113224,"lat":45.007605}'::jsonb,
        '{"name":"End Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.11358,"lat":45.007557}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Le Paludi di Ostiglia Oasi del Busatello Sermide e Pieve',
        3,
        '/static/gpx/le-paludi-di-ostiglia-oasi-del-busatello-sermide-e-pieve-di-.gpx',
        'Italia',
        'Lombardia',
        'Mantova',
        'Pieve di Coriano',
        12572.716765417841,
        341.5519999999999,
        255,
        'La tradizione afferma che la chiesa fu costruita nel 1082, per volere di Matilde di Canossa. Questa attribuzione risale al 1612 nella Historia ecclesiastica di Mantova dove il Donesmondi attribuisce l''edificazione della chiesa a Matilde, assieme ad altre chiese del territorio. 
Il Donesmondi affermò questa data riprendendo l''iscrizione da una lapide presente sulla facciata della pieve, visibile ancora oggi, dove sta scritto "D.O.M. ET B. MARIAE V. IN COELUM ASSUMPTAE ERECTA A.D. 1082 A CONNTISSA MATHILDE". Secondo un''analisi storica questa lapide non può essere ritenuta originale dell''XI secolo, ma risale al cinquecento. L''ipotesi è che questa iscrizione si stata realizzata durante il restauro del 1538. 
Storicamente, quindi, non ci sono documenti che attestano una data certa di costruzione della chiesa, ma sulla base degli elementi architettonici si può affermare che la pieve venne eretta nell''XI secolo. 
La chiesa è in stile romanico, costruita in laterizio ed è composta da tre navat',
        '["/static/images/7.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia","lon":11.106454,"lat":45.035438}'::jsonb,
        '{"name":"End Point","address":"Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia","lon":11.106576,"lat":45.03596}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":11.109236,"lat":45.044962,"altitude":22.75},{"name":"Ref Point 2","address":"","lon":11.155368,"lat":45.034617,"altitude":35.551}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per il MONTE CUCETTO',
        2,
        '/static/gpx/monte cucetto.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Dubbione',
        2150.3010767004043,
        586.4262699999999,
        120,
        'Escursione Facile e, nella parte alta, molto panoramica; la cima offre una buona panoramica dei rilievi tra bassa Val Chisone e Val Sangone.

Lasciata l’auto, il sentiero parte in corrispondenza del tornante ed entra nel bosco in direzione Nord-Ovest; al primo bivio, proseguire dritto e seguire le indicazioni per “Cucetto”; il sentiero inizia a guadagnare quota abbastanza rapidamente e costantemente, sempre nel bosco.

Dopo una serie di tornantini la vegetazione inizierà a diradarsi e si inizierà a scorgere un bel panorama con il Monviso in bella mostra (se il meteo lo permette).',
        '["/static/images/50.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Pralamar, Pinasca, Torino, Piemonte, 10063, Italia","lon":7.243299,"lat":44.961979}'::jsonb,
        '{"name":"End Point","address":"Pralamar, Pinasca, Torino, Piemonte, 10063, Italia","lon":7.240229,"lat":44.977112}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Sentiero per il MONTE MURETTO',
        2,
        '/static/gpx/monte muretto.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Torino',
        2127.346730436805,
        277.51812700000005,
        200,
        'È presente un unico punto acqua nel luogo del parcheggio (fontana). Nella stessa piazzetta, al momento della recensione, è sempre aperto nei weekend un singolare bar allestito dentro un vecchio furgone.

Per chi cammina con bimbi e soprattutto cani, attenzione in primavera alla presenza di processionarie.',
        '["/static/images/44.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia","lon":7.31544,"lat":44.918242}'::jsonb,
        '{"name":"End Point","address":"Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia","lon":7.309893,"lat":44.929433}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pieve di Ledro - Monte Cocca',
        1,
        '/static/gpx/pieve-di-ledro-monte-cocca.gpx',
        'Italia',
        'Trentino Alto Adige',
        'Provincia di Trento',
        'Pieve di Ledro',
        8627.552532528542,
        1018.0050000000002,
        70,
        'Very challenging, but worth it! The view from the top is gorgeous! For the descent it is better to use sticks, or repeat the same route as the climb.',
        '["/static/images/20.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.730931,"lat":45.889379}'::jsonb,
        '{"name":"End Point","address":"Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731044,"lat":45.889397}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Pieve S. Stefano a Pian delle Capanne',
        2,
        '/static/gpx/pieve-s-stefano-a-pian-delle-capanne.gpx',
        'Italia',
        'Toscana',
        'Arezzo',
        'Pieve Santo Stefano',
        22430.396794868582,
        1004.4300000000019,
        150,
        'Causa pioggia e terreno scivoloso preso la 1º variante fino al passo Viamaggio poi proseguito ancora per la 2º variante. 
Bisogna calcolare circa 4 km in più.',
        '["/static/images/23.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Poggiolino delle Viole, Castellare, Pieve Santo Stefano, Arezzo, Toscana, 52036, Italia","lon":12.039528,"lat":43.670638}'::jsonb,
        '{"name":"End Point","address":"Bike Help, Pian della Capanna, Pieve Santo Stefano, Arezzo, Toscana, Italia","lon":12.150503,"lat":43.651402}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Piverone - Anello IV - “Via Romanica al Gesiun”',
        1,
        '/static/gpx/piverone-anello-iv-via-romanica-al-gesiun.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Pieverone',
        4857.311515489554,
        94.22999999999996,
        60,
        'Piverone - Anello IV - “Via Romanica al Gesiun”',
        '["/static/images/8.jpg"]'::jsonb,
        '{"name":"Start Point","address":"26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia","lon":8.00725,"lat":45.44783}'::jsonb,
        '{"name":"End Point","address":"26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia","lon":8.00696,"lat":45.44779}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Plois - Pieve d''Alpago',
        2,
        '/static/gpx/plois-pieve-dalpago.gpx',
        'Italia',
        'Veneto',
        'Belluno',
        'Pieve d''Alpegno',
        6588.816640728274,
        936.79,
        320,
        'percorso è tranquillamente percorribile',
        '["/static/images/19.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Municipio, Via Roma, Torres, Tignes, Pieve d''Alpago, Alpago, Belluno, Veneto, 32010, Italia","lon":12.360272,"lat":46.175025}'::jsonb,
        '{"name":"End Point","address":"Municipio, Via Roma, Torres, Tignes, Pieve d''Alpago, Alpago, Belluno, Veneto, 32010, Italia","lon":12.352636,"lat":46.167926}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Rifugio Galassi, forcella del ghiacciaio, Rifugio Antelao',
        2,
        '/static/gpx/rifugio-galassi-forcella-del-ghiacciaio-rifugio-antelao-piev.gpx',
        'Italia',
        'Veneto',
        'Belluno',
        'Belluno',
        6588.816640728274,
        936.79,
        200,
        'Quinta giornata Alta via N°4
Rifugio Galassi, forcella del ghiacciaio, Rifugio Antelao, Pieve di Cadore.',
        '["/static/images/18.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia","lon":12.261855,"lat":46.470487}'::jsonb,
        '{"name":"End Point","address":"Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia","lon":12.364278,"lat":46.426071}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Riva del Garda - Pieve di Ledro - Panchina',
        3,
        '/static/gpx/riva-del-garda-pieve-di-ledro-panchina.gpx',
        'Italia',
        'Trentino Alto Adige',
        'Provincia di Trento',
        'Sant''Alessandro',
        8085.211186643268,
        829.1299999999999,
        135,
        'Riva del Garda - Pieve di Ledro - Panchina',
        '["/static/images/16.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.853195,"lat":45.882925}'::jsonb,
        '{"name":"End Point","address":"Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia","lon":10.731102,"lat":45.88923}'::jsonb,
        '[{"name":"Peak","address":"","lon":10.853195,"lat":45.882925,"altitude":67.085},{"name":"Lake","address":"","lon":10.764528,"lat":45.873764,"altitude":712.069}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Sovicille delle Meraviglie - Villa Cetinale - Scala Santa',
        2,
        '/static/gpx/sovicille-delle-meraviglie-villa-cetinale-scala-santa-e-romi.gpx',
        'Italia',
        'Toscana',
        'Siena',
        'Sovicille',
        19553.110970430764,
        1298.215999999996,
        210,
        'Suggestivo anello con visita della pieve di Pernina e del parco di Villa Cetinale/Castello di Celsa aperti in occasione dell''evento Sovicille delle Meraviglie ottobre 2021',
        '["/static/images/26.jpg"]'::jsonb,
        '{"name":"Start Point","address":"4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia","lon":11.228176,"lat":43.279339}'::jsonb,
        '{"name":"End Point","address":"4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia","lon":11.228044,"lat":43.279294}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'BERGERIE DI VALLONCRO’',
        3,
        '/static/gpx/vallone di massello (1).gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Massello',
        5304.03695311155,
        958.8864720000013,
        150,
        'Open and shade-free environment: remember sunscreen; if the walk is too long, the plateau at the base of the waterfall still offers various possibilities for pleasant picnics.',
        '["/static/images/30.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia","lon":7.031857,"lat":44.964905}'::jsonb,
        '{"name":"End Point","address":"Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia","lon":6.997145,"lat":44.978063}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Ville Disunite - Anello Ghibullo - Villa Pasolini.',
        2,
        '/static/gpx/ville-disunite-anello-ghibullo-villa-pasolini-torre-albicini.gpx',
        'Italia',
        'Emilia-Romagna',
        'Ravenna',
        'Lognana',
        22696.477033711653,
        236.7130000000004,
        110,
        'The first stretch is entirely on the right bank of the Ronco, on the Via Romea Germanica. Then you enter the territory to go towards the center of the journey, the area of ​​San Pietro in Trento where, within two kilometres, you come across a medieval tower, a 9th century parish church with a fantastic crypt, the ruins of a large villa and a perfectly healthy 16th century villa.',
        '["/static/images/23.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia","lon":12.138685,"lat":44.343306}'::jsonb,
        '{"name":"End Point","address":"Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia","lon":12.139573,"lat":44.343643}'::jsonb,
        NULL
      );
    
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2),
        working_time_start time without time zone,
        working_time_end time without time zone,
        email varchar,
        phone_number varchar,
        pictures jsonb
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber",
      "pictures"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number,
      pictures
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        7,
        78::numeric(12,2),
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Frido Perrini',
        'http://repulsive-discovery.it',
        334.327,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Omero.Fiorentini66@gmail.com',
        '+394715638912',
        '["/static/images/d7182e6e-3537-4fc2-a7c4-fabf28a63997.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        3,
        37::numeric(12,2),
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Maura Orefice',
        'https://ultimate-drizzle.it',
        333.101,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Zita.Toti61@yahoo.it',
        '+391324399661',
        '["/static/images/2b777e31-65a0-4d21-8ee5-9733bdbaddc4.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        9,
        98::numeric(12,2),
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Andrea Bernasconi',
        'http://closed-nightlife.com',
        300.644,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Ersilia_Campanini@gmail.com',
        '+399098886821',
        '["/static/images/be79a065-3ab0-4686-91a9-50976d001809.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        8,
        66::numeric(12,2),
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Barnaba Gamper',
        'https://novel-beetle.org',
        266.221,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Regolo.Cossu@hotmail.com',
        '+399387057421',
        '["/static/images/eb6e8339-47b1-4918-b91a-cf755bff8dac.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        9,
        63::numeric(12,2),
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Ofelia Labate',
        'https://spanish-colt.it',
        322.816,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Ulstano_Amabile@yahoo.com',
        '+394236516424',
        '["/static/images/057d7442-e127-41ad-bd67-71fec6830eff.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        9,
        116::numeric(12,2),
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Beata Tumino',
        'http://flat-anyone.net',
        310.671,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Apollo.Crevatin@yahoo.it',
        '+395286535933',
        '["/static/images/d3830e90-6a66-44f3-ae72-485a31bab389.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        2,
        116::numeric(12,2),
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Sabrina Fantini',
        'http://delicious-yawl.com',
        292.327,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Esmeralda19@yahoo.it',
        '+390011620050',
        '["/static/images/fa77ab0d-06bc-4fc5-b034-816f4613f6be.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        6,
        139::numeric(12,2),
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Aristione Saporito',
        'https://noteworthy-pancreas.net',
        325.842,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Druina_Grandi@yahoo.it',
        '+393875914514',
        '["/static/images/2b777e31-65a0-4d21-8ee5-9733bdbaddc4.jpg","/static/images/0d6f9cdc-40f0-4939-9ced-8557ebc6045d.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        9,
        129::numeric(12,2),
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Taziana Scorza',
        'http://dizzy-chromolithograph.org',
        339.991,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Landolfo_DiFranco25@libero.it',
        '+399473171760',
        '["/static/images/bf149cc5-709d-41b2-aeb7-46bf260e52c9.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        6,
        144::numeric(12,2),
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Isotta Cozzolino',
        'https://limping-counseling.it',
        320.378,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Adriana.DiPaola@yahoo.it',
        '+391279086197',
        '["/static/images/2539ad1d-5101-43c7-bac8-183396547c4b.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        9,
        86::numeric(12,2),
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Elisea Doronzo',
        'https://unselfish-vane.it',
        321.436,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Venerando.Dini@hotmail.com',
        '+395780287234',
        '["/static/images/d3830e90-6a66-44f3-ae72-485a31bab389.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        5,
        146::numeric(12,2),
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Aratone Repetto',
        'https://dangerous-recommendation.it',
        328.882,
        '05:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Ponziano29@libero.it',
        '+399382684556',
        '["/static/images/b1e7e2b3-5b63-4ff9-9031-51753ff01987.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/0d6f9cdc-40f0-4939-9ced-8557ebc6045d.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        3,
        64::numeric(12,2),
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Eliano Mattia',
        'http://affectionate-poker.it',
        324.45,
        '09:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Leda_Colucci@libero.it',
        '+398490277794',
        '["/static/images/dc4d1ab2-2ea7-42a8-b87f-9c0cb53a6315.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/0d6f9cdc-40f0-4939-9ced-8557ebc6045d.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        9,
        116::numeric(12,2),
        'Vernagthütte',
        'Austria',
        'Dott. Tosca Mingarelli',
        'https://apprehensive-dredger.it',
        276.299,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Achille_Simonini79@libero.it',
        '+398257483994',
        '["/static/images/abfdceff-cbad-40e8-9766-e7b771d27f2b.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        1,
        121::numeric(12,2),
        'Wormser Hütte',
        'Austria',
        'Procopio Peruzzi',
        'https://tiny-wastebasket.net',
        284.326,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Eligio75@hotmail.com',
        '+395426232347',
        '["/static/images/bf149cc5-709d-41b2-aeb7-46bf260e52c9.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        5,
        45::numeric(12,2),
        'Biberacher Hütte',
        'Austria',
        'Crescenzia Beltrame',
        'http://stale-kick-off.it',
        316.396,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Batilda.Politi11@yahoo.it',
        '+390978289522',
        '["/static/images/dc4d1ab2-2ea7-42a8-b87f-9c0cb53a6315.jpg","/static/images/0d6f9cdc-40f0-4939-9ced-8557ebc6045d.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        6,
        104::numeric(12,2),
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Almiro Biancheri',
        'https://doting-plot.org',
        314.384,
        '03:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Amore_Martini@libero.it',
        '+392818266843',
        '["/static/images/d7182e6e-3537-4fc2-a7c4-fabf28a63997.jpg","/static/images/0d6f9cdc-40f0-4939-9ced-8557ebc6045d.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        4,
        37::numeric(12,2),
        'Hochwaldhütte',
        'Germany',
        'Sante Manzi',
        'https://awkward-commitment.org',
        317.999,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Adeodato_Monti8@libero.it',
        '+390444614099',
        '["/static/images/fa77ab0d-06bc-4fc5-b034-816f4613f6be.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        9,
        50::numeric(12,2),
        'Kölner Eifelhütte',
        'Germany',
        'Antigone Valentini',
        'https://spectacular-jazz.net',
        306.377,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Gioia_Spadoni55@yahoo.it',
        '+393728132891',
        '["/static/images/68aca8fa-132e-4558-85e9-99dcbd31ff57.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        3,
        70::numeric(12,2),
        'Madrisahütte',
        'Austria',
        'Sofronia Putzolu',
        'http://mealy-clapboard.org',
        295.795,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Greta.Giannone@yahoo.it',
        '+396385810180',
        '["/static/images/50560a2d-c211-447c-ac10-8c33a074c886.jpg","/static/images/0d6f9cdc-40f0-4939-9ced-8557ebc6045d.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        1,
        35::numeric(12,2),
        'Dresdner Hütte',
        'Austria',
        'Dott. Godiva Paolella',
        'https://indolent-tussle.org',
        331.869,
        '03:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Renzo_Pagliai45@email.it',
        '+391480367357',
        '["/static/images/50560a2d-c211-447c-ac10-8c33a074c886.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        3,
        110::numeric(12,2),
        'Fiderepasshütte',
        'Germany',
        'Giuliano Bongiovanni',
        'http://warm-headphones.it',
        333.289,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Nunzio.Marani@gmail.com',
        '+398709572602',
        '["/static/images/057d7442-e127-41ad-bd67-71fec6830eff.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        8,
        91::numeric(12,2),
        'Göppinger Hütte',
        'Austria',
        'Dott. Calcedonio Luciano',
        'https://jaded-niece.org',
        277.614,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Vodingo.Lodi63@yahoo.it',
        '+392008420439',
        '["/static/images/802d2078-ff6b-4055-8b8e-2991ba8fc47b.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        9,
        132::numeric(12,2),
        'Oberzalimhütte',
        'Austria',
        'Veriana Ferrigno',
        'https://nasty-amount.com',
        292.575,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Ermenegildo79@yahoo.com',
        '+398226651329',
        '["/static/images/fa77ab0d-06bc-4fc5-b034-816f4613f6be.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        3,
        89::numeric(12,2),
        'Rastkogelhütte',
        'Austria',
        'Clara Moscato',
        'https://unruly-pleasure.it',
        322.444,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Massimo80@hotmail.com',
        '+397929952915',
        '["/static/images/fa77ab0d-06bc-4fc5-b034-816f4613f6be.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/a1e750d9-adfc-4602-b6cc-a7c8e7b9b99d.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/0d6f9cdc-40f0-4939-9ced-8557ebc6045d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        7,
        113::numeric(12,2),
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Agapito Vincenzi',
        'http://slippery-hardship.net',
        272.238,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Giosuele_Marchini79@gmail.com',
        '+396400834453',
        '["/static/images/d3830e90-6a66-44f3-ae72-485a31bab389.jpg","/static/images/a1e750d9-adfc-4602-b6cc-a7c8e7b9b99d.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        8,
        36::numeric(12,2),
        'Kaltenberghütte',
        'Austria',
        'Concetta Mori',
        'http://adorable-muffin.org',
        316.662,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Stefano_Giaccio23@yahoo.com',
        '+399972360824',
        '["/static/images/dc4d1ab2-2ea7-42a8-b87f-9c0cb53a6315.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        2,
        127::numeric(12,2),
        'Schweinfurter Hütte',
        'Austria',
        'Alceo Napolitano',
        'http://usable-bricklaying.net',
        273.846,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Rainelda_Marsili38@yahoo.it',
        '+395899389103',
        '["/static/images/fa77ab0d-06bc-4fc5-b034-816f4613f6be.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        1,
        63::numeric(12,2),
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Catullo Del Monte',
        'https://notable-sweets.it',
        331.065,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Namazio.Miotto96@email.it',
        '+391661624341',
        '["/static/images/2b777e31-65a0-4d21-8ee5-9733bdbaddc4.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        3,
        70::numeric(12,2),
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Demostene Perri',
        'http://miserly-networking.it',
        307.655,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Agata82@yahoo.com',
        '+397130693210',
        '["/static/images/2b777e31-65a0-4d21-8ee5-9733bdbaddc4.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        6,
        116::numeric(12,2),
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Icilio Vitiello',
        'http://jovial-sweater.com',
        299.146,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Ester_Crippa@yahoo.it',
        '+395443533278',
        '["/static/images/032954e5-fcd2-4d4d-b733-0f048f7713bb.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        1,
        136::numeric(12,2),
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Ramiro Giugliano',
        'http://spiffy-weight.it',
        299.627,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Manlio.Lombardi3@libero.it',
        '+393386183361',
        '["/static/images/b1e7e2b3-5b63-4ff9-9031-51753ff01987.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        5,
        67::numeric(12,2),
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Grato Federici',
        'http://alive-innovation.com',
        322.365,
        '07:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Enzo.Citro81@yahoo.com',
        '+392195589479',
        '["/static/images/86ddef01-2fd2-4c28-9068-d9194c208c81.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        10,
        132::numeric(12,2),
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Orso Santori',
        'http://coarse-conversion.it',
        327.544,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Eliodoro_Petrarca29@hotmail.com',
        '+393367154001',
        '["/static/images/68aca8fa-132e-4558-85e9-99dcbd31ff57.jpg","/static/images/0d6f9cdc-40f0-4939-9ced-8557ebc6045d.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        10,
        131::numeric(12,2),
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Samanta Del Bianco',
        'https://limp-corruption.it',
        314.432,
        '03:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Massima50@email.it',
        '+397514697786',
        '["/static/images/be79a065-3ab0-4686-91a9-50976d001809.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        2,
        141::numeric(12,2),
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Diodata Basile',
        'https://proud-dragon.com',
        321.45,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Tecla_Taddei41@yahoo.com',
        '+393401808587',
        '["/static/images/d7182e6e-3537-4fc2-a7c4-fabf28a63997.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        4,
        109::numeric(12,2),
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Frontiniano Chiaravalle',
        'http://amazing-smolt.org',
        306.514,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Viola_Terlizzi66@yahoo.com',
        '+394576042191',
        '["/static/images/9403d204-e49e-4cba-a8e2-2e7dcd846434.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/a1e750d9-adfc-4602-b6cc-a7c8e7b9b99d.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        9,
        66::numeric(12,2),
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Ermelinda Amico',
        'https://tremendous-prophet.net',
        317.611,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Simeone13@libero.it',
        '+390934631366',
        '["/static/images/68aca8fa-132e-4558-85e9-99dcbd31ff57.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg","/static/images/a1e750d9-adfc-4602-b6cc-a7c8e7b9b99d.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        2,
        129::numeric(12,2),
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Lamberto Cinelli',
        'https://skeletal-barrel.net',
        277.141,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Secondina71@gmail.com',
        '+392134028561',
        '["/static/images/abfdceff-cbad-40e8-9766-e7b771d27f2b.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        8,
        49::numeric(12,2),
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Dott. Aristione Soldati',
        'http://abandoned-insect.net',
        291.595,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Tranquillo99@libero.it',
        '+393903596012',
        '["/static/images/abfdceff-cbad-40e8-9766-e7b771d27f2b.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        8,
        80::numeric(12,2),
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Marisa Orsini',
        'http://fatherly-pantology.com',
        329.722,
        '01:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Frontiniano_Coccia77@hotmail.com',
        '+392463052107',
        '["/static/images/d3830e90-6a66-44f3-ae72-485a31bab389.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        4,
        118::numeric(12,2),
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Benigna Celi',
        'https://haunting-bookmark.it',
        284.731,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Sidonio_Ciotola66@hotmail.com',
        '+395103516785',
        '["/static/images/b1e7e2b3-5b63-4ff9-9031-51753ff01987.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/0d6f9cdc-40f0-4939-9ced-8557ebc6045d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        6,
        96::numeric(12,2),
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Manilio Baiocco',
        'http://forthright-transformation.com',
        323.231,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Ascanio81@libero.it',
        '+392077352003',
        '["/static/images/abfdceff-cbad-40e8-9766-e7b771d27f2b.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        8,
        105::numeric(12,2),
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Melchiorre Tassi',
        'https://canine-boogeyman.org',
        282.601,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Alfredo_Pintus95@hotmail.com',
        '+394972344094',
        '["/static/images/057d7442-e127-41ad-bd67-71fec6830eff.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        6,
        147::numeric(12,2),
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Speranza Capecchi',
        'http://grandiose-collector.com',
        325.568,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Teodata61@yahoo.com',
        '+393035820455',
        '["/static/images/057d7442-e127-41ad-bd67-71fec6830eff.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        5,
        128::numeric(12,2),
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Severo Teresi',
        'http://unknown-scraper.org',
        306.888,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Edilberto59@gmail.com',
        '+397484203270',
        '["/static/images/802d2078-ff6b-4055-8b8e-2991ba8fc47b.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        9,
        37::numeric(12,2),
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Bonaventura Mascia',
        'https://emotional-sheath.org',
        297.729,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Alcide88@yahoo.it',
        '+390253461714',
        '["/static/images/9403d204-e49e-4cba-a8e2-2e7dcd846434.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        8,
        145::numeric(12,2),
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Editta Loiacono',
        'http://knowing-easel.org',
        302.144,
        '02:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Belina_Montanaro@yahoo.com',
        '+393548956514',
        '["/static/images/50560a2d-c211-447c-ac10-8c33a074c886.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        7,
        95::numeric(12,2),
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Cuniberto Feleppa',
        'https://silly-gem.com',
        339.461,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Magda89@libero.it',
        '+398840220024',
        '["/static/images/032954e5-fcd2-4d4d-b733-0f048f7713bb.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        5,
        67::numeric(12,2),
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Barsimeo De Vito',
        'http://ashamed-contingency.com',
        272.04,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Selvaggia_Caiazzo68@libero.it',
        '+394610038291',
        '["/static/images/86ddef01-2fd2-4c28-9068-d9194c208c81.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        3,
        124::numeric(12,2),
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Rutilo Proietti',
        'http://favorite-habitat.it',
        326.066,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Giuda.Viola29@libero.it',
        '+395083719094',
        '["/static/images/2b777e31-65a0-4d21-8ee5-9733bdbaddc4.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        6,
        122::numeric(12,2),
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Alfredo Pacifico',
        'https://deficient-shoulder.com',
        296.231,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Ugo.Mascolo9@hotmail.com',
        '+390233852413',
        '["/static/images/eb6e8339-47b1-4918-b91a-cf755bff8dac.jpg","/static/images/0d6f9cdc-40f0-4939-9ced-8557ebc6045d.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        1,
        73::numeric(12,2),
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Gisella Monterosso',
        'http://thirsty-puritan.org',
        264.72,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Vinebaldo_Agostini@libero.it',
        '+397248967958',
        '["/static/images/fa77ab0d-06bc-4fc5-b034-816f4613f6be.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        1,
        96::numeric(12,2),
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Petronilla Grange',
        'https://loose-deduction.org',
        284.025,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Pardo_Lazzaro56@hotmail.com',
        '+398426881362',
        '["/static/images/51673825-7eab-445a-ad45-14fd0709d3f6.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        5,
        71::numeric(12,2),
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Eriberto Pellegrino',
        'http://wee-insurgence.com',
        337.891,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Telica11@libero.it',
        '+397651994651',
        '["/static/images/eb6e8339-47b1-4918-b91a-cf755bff8dac.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        8,
        80::numeric(12,2),
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Cirilla Curcio',
        'http://kindly-daybed.it',
        261.379,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Tussio.Bentivoglio18@hotmail.com',
        '+393501174072',
        '["/static/images/d3830e90-6a66-44f3-ae72-485a31bab389.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        9,
        106::numeric(12,2),
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Chiara Guidetti',
        'https://sunny-mandate.com',
        295.291,
        '08:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Selene.Salemme@libero.it',
        '+397618906185',
        '["/static/images/057d7442-e127-41ad-bd67-71fec6830eff.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        2,
        89::numeric(12,2),
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Bartolomea Pezzella',
        'http://impressive-toga.org',
        261.813,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Saffo.Carrara@hotmail.com',
        '+395283045735',
        '["/static/images/50560a2d-c211-447c-ac10-8c33a074c886.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        8,
        101::numeric(12,2),
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Adalardo Damico',
        'http://demanding-cliff.com',
        294.773,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Icaro91@libero.it',
        '+399890175127',
        '["/static/images/51673825-7eab-445a-ad45-14fd0709d3f6.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        8,
        147::numeric(12,2),
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Cesare Impellizzeri',
        'http://well-made-misnomer.com',
        286.124,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Colomba38@email.it',
        '+394390550008',
        '["/static/images/2539ad1d-5101-43c7-bac8-183396547c4b.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        5,
        49::numeric(12,2),
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Baldovino Rambaldi',
        'http://venerated-wrong.it',
        304.269,
        '02:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Irmina21@gmail.com',
        '+396765443922',
        '["/static/images/eb6e8339-47b1-4918-b91a-cf755bff8dac.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        10,
        53::numeric(12,2),
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Tarcisio Randazzo',
        'http://tangible-poppy.com',
        332.355,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Apollonia44@yahoo.it',
        '+390003270558',
        '["/static/images/abfdceff-cbad-40e8-9766-e7b771d27f2b.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/a1e750d9-adfc-4602-b6cc-a7c8e7b9b99d.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        2,
        69::numeric(12,2),
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Gallicano Canino',
        'http://obvious-calf.com',
        280.181,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Nicola5@libero.it',
        '+392416751421',
        '["/static/images/2b777e31-65a0-4d21-8ee5-9733bdbaddc4.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        6,
        106::numeric(12,2),
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Adriana Ferrara',
        'http://immense-mukluk.com',
        332.247,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Genesio11@yahoo.com',
        '+394703920501',
        '["/static/images/2b777e31-65a0-4d21-8ee5-9733bdbaddc4.jpg","/static/images/0d6f9cdc-40f0-4939-9ced-8557ebc6045d.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        4,
        80::numeric(12,2),
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Ippolito Valente',
        'https://merry-cocktail.it',
        283.627,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Rosanna38@hotmail.com',
        '+394225670252',
        '["/static/images/9403d204-e49e-4cba-a8e2-2e7dcd846434.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        6,
        98::numeric(12,2),
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Maria Fusco',
        'https://impeccable-proceedings.it',
        335.213,
        '01:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Adelmo64@hotmail.com',
        '+398097190770',
        '["/static/images/2539ad1d-5101-43c7-bac8-183396547c4b.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        7,
        114::numeric(12,2),
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Letizia Marcon',
        'http://cylindrical-estrogen.it',
        316.764,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Radolfo.Magno20@hotmail.com',
        '+393331061939',
        '["/static/images/50560a2d-c211-447c-ac10-8c33a074c886.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        8,
        75::numeric(12,2),
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Sig. Cecco Canu',
        'http://agile-plover.it',
        264.02,
        '08:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Albino17@email.it',
        '+391764789514',
        '["/static/images/2539ad1d-5101-43c7-bac8-183396547c4b.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        9,
        57::numeric(12,2),
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Dott. Quirino Narciso',
        'http://excellent-golf.it',
        336.141,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Sarbello.Polidori@yahoo.com',
        '+393555922240',
        '["/static/images/dc4d1ab2-2ea7-42a8-b87f-9c0cb53a6315.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/a1e750d9-adfc-4602-b6cc-a7c8e7b9b99d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        6,
        69::numeric(12,2),
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Cointa Terlizzi',
        'https://disfigured-channel.org',
        300.06,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Mara.Mazzoleno@hotmail.com',
        '+391608346662',
        '["/static/images/b1e7e2b3-5b63-4ff9-9031-51753ff01987.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/a1e750d9-adfc-4602-b6cc-a7c8e7b9b99d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        5,
        115::numeric(12,2),
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Pelagia Ippolito',
        'https://awkward-daffodil.org',
        308.776,
        '05:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Casimira_Pagliai21@email.it',
        '+392401271673',
        '["/static/images/9403d204-e49e-4cba-a8e2-2e7dcd846434.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        8,
        105::numeric(12,2),
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Sempronio Napolitano',
        'http://memorable-forearm.it',
        319.648,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Elena6@hotmail.com',
        '+392185941688',
        '["/static/images/bf149cc5-709d-41b2-aeb7-46bf260e52c9.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        2,
        51::numeric(12,2),
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Aureliano Amerio',
        'http://shrill-destiny.com',
        336.49,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Erardo_Colucci@email.it',
        '+395659910701',
        '["/static/images/032954e5-fcd2-4d4d-b733-0f048f7713bb.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        5,
        71::numeric(12,2),
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Severo Malagoli',
        'https://winding-catch.net',
        297.036,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Eracla_Montalbano@yahoo.com',
        '+390584702260',
        '["/static/images/fa77ab0d-06bc-4fc5-b034-816f4613f6be.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        5,
        130::numeric(12,2),
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Aristide Gioacchini',
        'https://cheery-robin.it',
        282.843,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Gaudenzia76@email.it',
        '+391265239813',
        '["/static/images/fa77ab0d-06bc-4fc5-b034-816f4613f6be.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        3,
        137::numeric(12,2),
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Camelia Caccamo',
        'http://round-shakedown.com',
        299.834,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Polidoro92@libero.it',
        '+393801072098',
        '["/static/images/dc4d1ab2-2ea7-42a8-b87f-9c0cb53a6315.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        6,
        39::numeric(12,2),
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Nicla Galasso',
        'https://fixed-counselor.it',
        277.483,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Amaranto.Bertaccini88@gmail.com',
        '+390633825912',
        '["/static/images/dc4d1ab2-2ea7-42a8-b87f-9c0cb53a6315.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        4,
        97::numeric(12,2),
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Ilva Meloni',
        'http://previous-id.org',
        325.047,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Lazzaro.Matteucci@hotmail.com',
        '+394519983392',
        '["/static/images/b1e7e2b3-5b63-4ff9-9031-51753ff01987.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        2,
        37::numeric(12,2),
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Ing. Basilio Pagliai',
        'http://wealthy-gambling.org',
        268.88,
        '08:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Lea.DiMaggio@gmail.com',
        '+392566238865',
        '["/static/images/68aca8fa-132e-4558-85e9-99dcbd31ff57.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/a1e750d9-adfc-4602-b6cc-a7c8e7b9b99d.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        6,
        65::numeric(12,2),
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Ing. Verulo De Carolis',
        'http://bland-disarmament.it',
        318.826,
        '02:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Vezio.Luchetti@libero.it',
        '+395966366329',
        '["/static/images/abfdceff-cbad-40e8-9766-e7b771d27f2b.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        9,
        139::numeric(12,2),
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Elena Papa',
        'https://gray-charlatan.com',
        299.281,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Divo17@gmail.com',
        '+391058316184',
        '["/static/images/2539ad1d-5101-43c7-bac8-183396547c4b.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        10,
        57::numeric(12,2),
        'Wittener Hütte',
        'Germany',
        'Sig. Rolfo Zunino',
        'http://red-id.net',
        261.533,
        '05:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Coriolano27@gmail.com',
        '+391932090874',
        '["/static/images/51673825-7eab-445a-ad45-14fd0709d3f6.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        3,
        103::numeric(12,2),
        'Hochjoch-Hospiz',
        'Austria',
        'Pantaleo Gerace',
        'https://watery-inhibitor.org',
        274.574,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Lucilla_Martelli@libero.it',
        '+397560256851',
        '["/static/images/abfdceff-cbad-40e8-9766-e7b771d27f2b.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/0d6f9cdc-40f0-4939-9ced-8557ebc6045d.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        10,
        86::numeric(12,2),
        'Meilerhütte',
        'Germany',
        'Silvestro Lo Giudice',
        'https://messy-labourer.com',
        331.024,
        '07:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Crescenzia.Savini58@libero.it',
        '+390593997555',
        '["/static/images/802d2078-ff6b-4055-8b8e-2991ba8fc47b.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        2,
        128::numeric(12,2),
        'Gaudeamushütte',
        'Austria',
        'Innocenza Stella',
        'https://distant-caddy.it',
        309.001,
        '04:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Quasimodo_Pace@yahoo.com',
        '+397718302177',
        '["/static/images/eb6e8339-47b1-4918-b91a-cf755bff8dac.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        5,
        86::numeric(12,2),
        'Rheydter Hütte',
        'Germany',
        'Natalina Angelini',
        'http://mad-increase.org',
        277.78,
        '07:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Antioco50@hotmail.com',
        '+396615060408',
        '["/static/images/68aca8fa-132e-4558-85e9-99dcbd31ff57.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        6,
        52::numeric(12,2),
        'Sektionshütte Krippen',
        'Germany',
        'Guendalina Testa',
        'http://gleeful-dessert.it',
        309.057,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Editta.Piredda35@gmail.com',
        '+399200407797',
        '["/static/images/2539ad1d-5101-43c7-bac8-183396547c4b.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        8,
        106::numeric(12,2),
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Melania Tallone',
        'http://scratchy-technician.com',
        334.435,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Leonida_Dolce@yahoo.com',
        '+391773692760',
        '["/static/images/2b777e31-65a0-4d21-8ee5-9733bdbaddc4.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        10,
        113::numeric(12,2),
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Manilio Tortora',
        'https://giant-fetus.net',
        270.633,
        '08:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Privato.Ciotola@email.it',
        '+397249024123',
        '["/static/images/7d10c735-1063-4a3c-8f99-58358eea6fc5.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/a1e750d9-adfc-4602-b6cc-a7c8e7b9b99d.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        9,
        131::numeric(12,2),
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Ventura Di Dio',
        'http://majestic-monopoly.org',
        323.563,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Aida50@libero.it',
        '+396167871190',
        '["/static/images/032954e5-fcd2-4d4d-b733-0f048f7713bb.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        2,
        138::numeric(12,2),
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Oriana Provenzano',
        'https://jolly-pharmacopoeia.it',
        329.319,
        '02:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Geltrude.Pichler@yahoo.com',
        '+392123025106',
        '["/static/images/50560a2d-c211-447c-ac10-8c33a074c886.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        2,
        101::numeric(12,2),
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Ondina Ragone',
        'https://familiar-stump.it',
        261.189,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Saturnino11@yahoo.it',
        '+396770211639',
        '["/static/images/d7182e6e-3537-4fc2-a7c4-fabf28a63997.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        8,
        79::numeric(12,2),
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Leo Caricari',
        'https://important-leave.net',
        307.008,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Silvia.Chiacchio@email.it',
        '+395627389887',
        '["/static/images/50560a2d-c211-447c-ac10-8c33a074c886.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/a1e750d9-adfc-4602-b6cc-a7c8e7b9b99d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        2,
        98::numeric(12,2),
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Fortunata Vierin',
        'https://scared-cop.org',
        260.765,
        '04:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Cristiana62@yahoo.it',
        '+392856910259',
        '["/static/images/68aca8fa-132e-4558-85e9-99dcbd31ff57.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/0d6f9cdc-40f0-4939-9ced-8557ebc6045d.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        9,
        137::numeric(12,2),
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Elifio Bizzarri',
        'https://sturdy-supplier.com',
        307.128,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Ernesto.Campo18@libero.it',
        '+399210184733',
        '["/static/images/032954e5-fcd2-4d4d-b733-0f048f7713bb.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/0d6f9cdc-40f0-4939-9ced-8557ebc6045d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        6,
        61::numeric(12,2),
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Ing. Spartaco Bongiorno',
        'https://shady-sister.org',
        336.642,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Baldomero.Marziali85@gmail.com',
        '+398751677647',
        '["/static/images/2539ad1d-5101-43c7-bac8-183396547c4b.jpg","/static/images/62d46df9-a152-4f83-811d-71f6ae31ef39.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        3,
        149::numeric(12,2),
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Carlo Di Michele',
        'http://euphoric-wisteria.net',
        260.146,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Ursino79@gmail.com',
        '+399797128042',
        '["/static/images/b1e7e2b3-5b63-4ff9-9031-51753ff01987.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        6,
        135::numeric(12,2),
        'Dobra voda',
        'Suvobor, Serbia',
        'Giuliana Pacifico',
        'https://gray-codon.com',
        307.685,
        '08:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Ornella60@yahoo.it',
        '+392123139821',
        '["/static/images/be79a065-3ab0-4686-91a9-50976d001809.jpg","/static/images/a1e750d9-adfc-4602-b6cc-a7c8e7b9b99d.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        4,
        129::numeric(12,2),
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Vittore Contu',
        'http://guilty-bird-watcher.org',
        303.109,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Olindo88@gmail.com',
        '+394359770813',
        '["/static/images/b1e7e2b3-5b63-4ff9-9031-51753ff01987.jpg","/static/images/bb07e703-24a4-433b-b7d2-ded18f0309f5.jpg","/static/images/6a2d4899-5468-4c51-b61f-e7a0405fb52b.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        4,
        90::numeric(12,2),
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Mennone Belotti',
        'http://low-glucose.org',
        310.022,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Benito.Pedrazzini1@yahoo.com',
        '+399499764607',
        '["/static/images/d7182e6e-3537-4fc2-a7c4-fabf28a63997.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg","/static/images/a1e750d9-adfc-4602-b6cc-a7c8e7b9b99d.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        9,
        45::numeric(12,2),
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Panfilo Picco',
        'http://distant-kendo.it',
        326.693,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Eufebio.Secchi@libero.it',
        '+395807595538',
        '["/static/images/802d2078-ff6b-4055-8b8e-2991ba8fc47b.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg","/static/images/0670a5c2-128a-4c64-8648-e45b55aff35e.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        4,
        134::numeric(12,2),
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Ruperto Fedele',
        'https://bewitched-calcification.com',
        337.137,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Valeriana87@email.it',
        '+394958716394',
        '["/static/images/bf149cc5-709d-41b2-aeb7-46bf260e52c9.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        10,
        71::numeric(12,2),
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Eutalia Toti',
        'https://frozen-earthquake.org',
        308.158,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Iginio12@gmail.com',
        '+397858432548',
        '["/static/images/dc4d1ab2-2ea7-42a8-b87f-9c0cb53a6315.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/b50f3862-cd26-4447-889f-cbe0df64ee5b.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        6,
        113::numeric(12,2),
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Anselmo Cappelletti',
        'https://meek-earthquake.org',
        264.152,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Argimiro.Rosi59@gmail.com',
        '+399028282758',
        '["/static/images/dc4d1ab2-2ea7-42a8-b87f-9c0cb53a6315.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        4,
        79::numeric(12,2),
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Parmenio Sergi',
        'http://unusual-cane.it',
        321.08,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Loriana28@libero.it',
        '+391285948104',
        '["/static/images/802d2078-ff6b-4055-8b8e-2991ba8fc47b.jpg","/static/images/c0baca0c-d763-4297-8f65-40258e58b825.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/2981d431-38c5-47d7-91a0-6a7070a93a67.jpg","/static/images/a8c158db-f9d0-4f54-ab29-1aa7c75c3aaa.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        8,
        132::numeric(12,2),
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Rodolfo Pardini',
        'http://spiffy-camp.org',
        324.065,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Orsino30@yahoo.it',
        '+391309118925',
        '["/static/images/51673825-7eab-445a-ad45-14fd0709d3f6.jpg","/static/images/893cca4d-7039-4abc-afa0-e551acb0c7bd.jpg","/static/images/d0d81db2-c77e-4583-8505-c7ffda8960cb.jpg","/static/images/6c08a711-16ae-4186-a4b6-ca61677fb916.jpg","/static/images/a1e750d9-adfc-4602-b6cc-a7c8e7b9b99d.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        4,
        128::numeric(12,2),
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Alberico Restivo',
        'http://those-cherry.net',
        263.263,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Esa40@hotmail.com',
        '+395599684792',
        '["/static/images/dc4d1ab2-2ea7-42a8-b87f-9c0cb53a6315.jpg","/static/images/98f1370b-74b0-420c-99d4-f2fea1f8dc8a.jpg","/static/images/e7c147f1-a31c-400d-8d76-c0cfdb388db4.jpg","/static/images/005ff80b-4cd6-4cf9-b96c-9caaa279ee07.jpg","/static/images/8e6b88b6-f091-46b6-b2a8-0c1afbba75b4.jpg"]'::jsonb
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        2,
        103::numeric(12,2),
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Luce Panza',
        'https://bite-sized-poultry.org',
        304.95,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Colomba63@gmail.com',
        '+396433443955',
        '["/static/images/be79a065-3ab0-4686-91a9-50976d001809.jpg","/static/images/170dca60-4323-439f-a643-9dc3d12ec034.jpg","/static/images/a1e750d9-adfc-4602-b6cc-a7c8e7b9b99d.jpg","/static/images/9f35a876-de5d-4eb0-8555-b575ea17ada9.jpg","/static/images/6278e911-b457-432c-b3cf-5b3b67eb66f5.jpg"]'::jsonb
      );
    
  

      CREATE OR REPLACE FUNCTION public.insert_hut_worker(
        hwid integer,
        email varchar,
        password varchar,
        first_name varchar,
        last_name varchar,
        role integer,
        hut_id integer,
        approved boolean
      ) RETURNS VOID AS
      $func$
      DECLARE
        user_id integer;
      BEGIN
      INSERT INTO "public"."users" (
        "id",
        "email",
        "password",
        "firstName",
        "lastName",
        "role",
        "approved",
        "verified"
      ) VALUES(
        hwid, email, password, first_name, last_name, role, true, approved
      ) returning id into user_id;

      INSERT INTO "public"."hut-worker" (
        "userId",
        "hutId"
      ) VALUES ( user_id, hut_id);
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hut_worker"(
        7,
        'hutWorker0@gmail.com',
        '$2b$10$1zm8MApYVbilxBA9OC6O1.B0iWqMZVcdHBQb0EnsAQkFJe9WQI3IW',
        'Auberto',
        'Pascucci',
        4,
        1,
        true
      );
    

      select public."insert_hut_worker"(
        8,
        'hutWorker1@gmail.com',
        '$2b$10$UJ2SkrfTzEX3ZfLbAlZmb.sv9/lcF2n1QBIjYyKoYxgi1TpjaZROK',
        'Baldovino',
        'Barile',
        4,
        2,
        false
      );
    

      select public."insert_hut_worker"(
        9,
        'hutWorker2@gmail.com',
        '$2b$10$2Ejmtn59JoyscGvnKVq/MOXGZ5OpxWb1tj8OVmF.lAF.DalQR294G',
        'Davino',
        'Silvestro',
        4,
        3,
        true
      );
    

      select public."insert_hut_worker"(
        10,
        'hutWorker3@gmail.com',
        '$2b$10$WcwKRcf6VspVxZ7..dcez.h.NuLfcTx/iGjVAIELS.oQajKea5j0m',
        'Privato',
        'Zanon',
        4,
        4,
        false
      );
    

      select public."insert_hut_worker"(
        11,
        'hutWorker4@gmail.com',
        '$2b$10$eXbpiljz3LmWPLGT3oxo6OLtuGAiBCPl6iOi8TyHExGIyUl/EjTEa',
        'Colomba',
        'Pascale',
        4,
        5,
        true
      );
    

      select public."insert_hut_worker"(
        12,
        'hutWorker5@gmail.com',
        '$2b$10$lMCufmFuy5FyE98yFgA68eS6zydupjHcLyHc4drnYoW3MYkKl7h02',
        'Zenebio',
        'Motta',
        4,
        6,
        false
      );
    

      select public."insert_hut_worker"(
        13,
        'hutWorker6@gmail.com',
        '$2b$10$gSyfRZaVy2ErhxcBFoNYwOcz2D/gb6adKmvDPEzyt8eSxkQlA2dEK',
        'Cosma',
        'Campo',
        4,
        7,
        true
      );
    

      select public."insert_hut_worker"(
        14,
        'hutWorker7@gmail.com',
        '$2b$10$LtTEM/XiHSd5JezDrem.6O/dQ7XLOgYW/06KOaESevrKtWnJ/FLWq',
        'Ildefonso',
        'Ingrassia',
        4,
        8,
        false
      );
    

      select public."insert_hut_worker"(
        15,
        'hutWorker8@gmail.com',
        '$2b$10$93yjWj2jQDdw5AXqvJ9GKeb9Olli9X2AA1AAn0cpe4SEDibGsh62K',
        'Amelio',
        'Gobbi',
        4,
        9,
        true
      );
    

      select public."insert_hut_worker"(
        16,
        'hutWorker9@gmail.com',
        '$2b$10$k/Ygc5sHrTio82M6PQSl4OpvubaY/TvDe/jAcHZpCJBAe.1isL1gq',
        'Marciano',
        'Aiello',
        4,
        10,
        false
      );
    

      select public."insert_hut_worker"(
        17,
        'hutWorker10@gmail.com',
        '$2b$10$qNPY5QyD71Af27vcn/p8ne79H8WAI4iMB3.bfQIy42SGQqdkkIu5C',
        'Giuseppina',
        'Lo Bianco',
        4,
        11,
        true
      );
    

      select public."insert_hut_worker"(
        18,
        'hutWorker11@gmail.com',
        '$2b$10$mvKnrKYh2EXRZGb0kIROBu/g0tKyE.hqoaK8ySuiTQPa78qeW0QMq',
        'Celso',
        'Dalmasso',
        4,
        12,
        false
      );
    

      select public."insert_hut_worker"(
        19,
        'hutWorker12@gmail.com',
        '$2b$10$Np8bZQuUQtkMhGFXyLiEkefJrdXD9F3QdjRw/rP/VQkSsna3oFit.',
        'Iole',
        'Lupo',
        4,
        13,
        true
      );
    

      select public."insert_hut_worker"(
        20,
        'hutWorker13@gmail.com',
        '$2b$10$topBjFwMc1LQ4CSjGId89uKinTcuD9V1Zn2lS1m9d1IFhoCh5ouVS',
        'Guiscardo',
        'Cirelli',
        4,
        14,
        false
      );
    

      select public."insert_hut_worker"(
        21,
        'hutWorker14@gmail.com',
        '$2b$10$csSnNlYe4whWho3mxzWx3Oav07pcSyFfxSo8XCVg4DE4Vnt.OKVda',
        'Barnaba',
        'Magliocco',
        4,
        15,
        true
      );
    

      select public."insert_hut_worker"(
        22,
        'hutWorker15@gmail.com',
        '$2b$10$xYnLOkszNdwU2YOj5pPE1ubftIK/.kpYTn99sRbwFzsgUSRW6uIHy',
        'Gualtiero',
        'Faraone',
        4,
        16,
        false
      );
    

      select public."insert_hut_worker"(
        23,
        'hutWorker16@gmail.com',
        '$2b$10$pEA7O0Msv2EfjrgotkNHVeM3j7fBkJrGQnwIUE12ReM9nemogs4Qy',
        'Amauri',
        'Guidi',
        4,
        17,
        true
      );
    

      select public."insert_hut_worker"(
        24,
        'hutWorker17@gmail.com',
        '$2b$10$s68A8xS274edqfiWamoD6utdmuDUDA7BDMrlw4fLNyp.dVxLYgCri',
        'Fidenziano',
        'Felici',
        4,
        18,
        false
      );
    

      select public."insert_hut_worker"(
        25,
        'hutWorker18@gmail.com',
        '$2b$10$pspW5FPZEySje6nGALTWP.vM6IhEsSBcKQquGTZom6OlibvYfpYG.',
        'Bardomiano',
        'Manna',
        4,
        19,
        true
      );
    

      select public."insert_hut_worker"(
        26,
        'hutWorker19@gmail.com',
        '$2b$10$xkHLOF/PvmoxDUGkjMfoJu3ccA9.vCHJMcmvtJPgFtuZnE0MYpzR.',
        'Miranda',
        'Spanu',
        4,
        20,
        false
      );
    

      select public."insert_hut_worker"(
        27,
        'hutWorker20@gmail.com',
        '$2b$10$sGbLUX0A0jtxz2ND2Eywqu67ZBMmnpZMhvrkm3Yk/TpG8cHjOFLqq',
        'Agnese',
        'Latorre',
        4,
        21,
        true
      );
    

      select public."insert_hut_worker"(
        28,
        'hutWorker21@gmail.com',
        '$2b$10$j4JHzl8Slwax//e1oLEh7uaeHjB.6W30S4GcDIQjeEacmXJGZPgbi',
        'Agata',
        'Cusimano',
        4,
        22,
        false
      );
    

      select public."insert_hut_worker"(
        29,
        'hutWorker22@gmail.com',
        '$2b$10$ohnx2WnYfXYRcSc8bbI.3eti4JRslGpb6yWz/wbnFI07IB8vjUMBC',
        'Graziana',
        'Malizia',
        4,
        23,
        true
      );
    

      select public."insert_hut_worker"(
        30,
        'hutWorker23@gmail.com',
        '$2b$10$HffB3fMpADv5K6AjcQdzB.Ayv.WOJtUp5kxXUmWcYMRKR57NgjF3K',
        'Innocente',
        'Cinelli',
        4,
        24,
        false
      );
    

      select public."insert_hut_worker"(
        31,
        'hutWorker24@gmail.com',
        '$2b$10$jb6zn/16I3WCOp8ykTA7j.LYcvazrjBYmA4290yETxG9vZiKDRwx6',
        'Divo',
        'Baldacci',
        4,
        25,
        true
      );
    

      select public."insert_hut_worker"(
        32,
        'hutWorker25@gmail.com',
        '$2b$10$tvMtt0Bn7Tk.czloT.lbPeGz2rgemw8uqW25v51KeRO.xCsY84vfm',
        'Massimiliano',
        'Citro',
        4,
        26,
        false
      );
    

      select public."insert_hut_worker"(
        33,
        'hutWorker26@gmail.com',
        '$2b$10$ZrpmfSu4xTe/kTqzcTMtLetSD9bACSJHBlxOBAfYX.Wl.osFf/OiK',
        'Genesia',
        'Di Liberto',
        4,
        27,
        true
      );
    

      select public."insert_hut_worker"(
        34,
        'hutWorker27@gmail.com',
        '$2b$10$Kmd6sWh1B5KlDQVYhhuv7.h8g9e/bA6Cm/gnKxaJTiTF2dvMX7tiO',
        'Ione',
        'Canova',
        4,
        28,
        false
      );
    

      select public."insert_hut_worker"(
        35,
        'hutWorker28@gmail.com',
        '$2b$10$kQE23IHVJxh55ZgRB1xs6.UPsMNSalv3tBfIY7MthsXwiJ3D1Unga',
        'Gianpaolo',
        'Carminati',
        4,
        29,
        true
      );
    

      select public."insert_hut_worker"(
        36,
        'hutWorker29@gmail.com',
        '$2b$10$LqtZ5akJPuiCduXQJxCOm.5XD4Gtz3AxfI2owjO8n6xgxfcKSswzC',
        'Vedasto',
        'Ferri',
        4,
        30,
        false
      );
    

      select public."insert_hut_worker"(
        37,
        'hutWorker30@gmail.com',
        '$2b$10$35P8pN0MLfKJIgb4EsFK5eZWMSfpR3ZzuSvZ9y3uV4hQc7dSXwe2e',
        'Maria',
        'Casula',
        4,
        31,
        true
      );
    

      select public."insert_hut_worker"(
        38,
        'hutWorker31@gmail.com',
        '$2b$10$zgeemJ85ChVJwDc.UoFZZud3FzS7zlRDd4/Z0c11hB0gS5./TJVz2',
        'Genesio',
        'Simone',
        4,
        32,
        false
      );
    

      select public."insert_hut_worker"(
        39,
        'hutWorker32@gmail.com',
        '$2b$10$JH6tE1PmBUCxHJoJXLIuVO.Qy7fnIiJCyoRY0omUTcwv8A3N4/Li2',
        'Valeriana',
        'Girardi',
        4,
        33,
        true
      );
    

      select public."insert_hut_worker"(
        40,
        'hutWorker33@gmail.com',
        '$2b$10$VQ0h06hbiEA/GUmRR830R.xmDrrnKxwqXG75hJCZCSMyqUkPb/.7i',
        'Felicita',
        'Graziani',
        4,
        34,
        false
      );
    

      select public."insert_hut_worker"(
        41,
        'hutWorker34@gmail.com',
        '$2b$10$h0/mK4Pyqs5KMvBlrPgJ0uxlgfUhlF9aJIf56h2cQ5A5JC9hMXMIe',
        'Zoe',
        'D''Amato',
        4,
        35,
        true
      );
    

      select public."insert_hut_worker"(
        42,
        'hutWorker35@gmail.com',
        '$2b$10$VPU36UclnO73f/s7GCNXruWdFs9fdVib.NDEOMXYC.NH9bKNWVmOK',
        'Michele',
        'Calafiore',
        4,
        36,
        false
      );
    

      select public."insert_hut_worker"(
        43,
        'hutWorker36@gmail.com',
        '$2b$10$LJYOsD/cDhPQsxZF4wign.3vZQ5WbiDzQ/jroCXcAPhZbc6I/SeXi',
        'Romolo',
        'Nicastro',
        4,
        37,
        true
      );
    

      select public."insert_hut_worker"(
        44,
        'hutWorker37@gmail.com',
        '$2b$10$pFGkePc2BjzVhmzRwE.9VOSNI66KMZGP8TJm6w/W/oyeamelNi45S',
        'Soccorso',
        'Patruno',
        4,
        38,
        false
      );
    

      select public."insert_hut_worker"(
        45,
        'hutWorker38@gmail.com',
        '$2b$10$tnTRCXcNB2k/BMUgs8eBMeB5SwyWlLVKZLXyOEHGGB.iJCSXOBZ96',
        'Ludano',
        'Marchi',
        4,
        39,
        true
      );
    

      select public."insert_hut_worker"(
        46,
        'hutWorker39@gmail.com',
        '$2b$10$RS8l3h3lD2iy8.lfmoalzuC9kxU.EHCDs7uvG3gxyBy.QLiASv5NK',
        'Barbara',
        'Mancino',
        4,
        40,
        false
      );
    

      select public."insert_hut_worker"(
        47,
        'hutWorker40@gmail.com',
        '$2b$10$u7gujZqXlY61P4YNoG8cL.rp1jfY54ULlgZ81p22a6uwDcbdMM9f6',
        'Rainaldo',
        'Frigerio',
        4,
        41,
        true
      );
    

      select public."insert_hut_worker"(
        48,
        'hutWorker41@gmail.com',
        '$2b$10$uGQZd.XZI5mnyfjtrFg.jepDreYgvtpLmbXwjIiPLdJ8xjS2RQDvu',
        'Ilva',
        'Masucci',
        4,
        42,
        false
      );
    

      select public."insert_hut_worker"(
        49,
        'hutWorker42@gmail.com',
        '$2b$10$tFjb6Z.QxmhK/CrVJgCJz.KxSlYXyS1nO4k4w1MAFKUGvEfSfMKKC',
        'Erardo',
        'Gallo',
        4,
        43,
        true
      );
    

      select public."insert_hut_worker"(
        50,
        'hutWorker43@gmail.com',
        '$2b$10$P6kren02l59/ms3YJfyZmuhbX8B8takhnj3ybkBUjoXYdBtn9L7nC',
        'Saba',
        'Scrofani',
        4,
        44,
        false
      );
    

      select public."insert_hut_worker"(
        51,
        'hutWorker44@gmail.com',
        '$2b$10$3hNG0GHw6jVPTb9t0wIo5uZxtvA/QKRL2Qhws1WtgMXr3r.Md03yu',
        'Rita',
        'Torrisi',
        4,
        45,
        true
      );
    

      select public."insert_hut_worker"(
        52,
        'hutWorker45@gmail.com',
        '$2b$10$fzID167pQO2QEhkTxC1utOMzvmVNy3tucfA74Uiwa9gZev.7f5jdm',
        'Niniano',
        'Farin',
        4,
        46,
        false
      );
    

      select public."insert_hut_worker"(
        53,
        'hutWorker46@gmail.com',
        '$2b$10$L9fUf3A8dsZHlw6YgNsAQOJ86n4rQIZtoZMTvmnu9GZs3WR2tAI5K',
        'Ruggero',
        'Romanini',
        4,
        47,
        true
      );
    

      select public."insert_hut_worker"(
        54,
        'hutWorker47@gmail.com',
        '$2b$10$q6BdmR4LvNqw.iSlkbPRzeBOuEG1LDvFCapi7fcAoBTgHJvw.o5FO',
        'Odidone',
        'Castagna',
        4,
        48,
        false
      );
    

      select public."insert_hut_worker"(
        55,
        'hutWorker48@gmail.com',
        '$2b$10$4TlDAmaaBvD2qB.73xdVceOv/Ic6F9pFUlX71/WGvn8EdevAyNzDG',
        'Baldomero',
        'Ferri',
        4,
        49,
        true
      );
    

      select public."insert_hut_worker"(
        56,
        'hutWorker49@gmail.com',
        '$2b$10$A1Q6lDab3KJx6MoxEL7UsOCGo.7YHFqzSdWSvYAp7FWoTfKGM1MLy',
        'Giuliana',
        'Pacifici',
        4,
        50,
        false
      );
    

      select public."insert_hut_worker"(
        57,
        'hutWorker50@gmail.com',
        '$2b$10$xpkkzkhM5mpAqEQdHIfXo.czFDhAcAS3l//7mGskGxPdUFakHCE52',
        'Wanda',
        'Greco',
        4,
        51,
        true
      );
    

      select public."insert_hut_worker"(
        58,
        'hutWorker51@gmail.com',
        '$2b$10$Zg9GVBqdT0S6RmCRY86UAOjNWp48bCaJIVCJe/mvegydyreXEcqXW',
        'Agamennone',
        'Puca',
        4,
        52,
        false
      );
    

      select public."insert_hut_worker"(
        59,
        'hutWorker52@gmail.com',
        '$2b$10$oRMTKaxbGJVoeRaQtPoJme05oRu7rH4SVOfLbCj4a9XvTRZlM5BtK',
        'Tolomeo',
        'Farin',
        4,
        53,
        true
      );
    

      select public."insert_hut_worker"(
        60,
        'hutWorker53@gmail.com',
        '$2b$10$qMW22kNTWSuVicgBP4lcy.JIviMhu4To2LJd7yV.jCA4ySXImk4le',
        'Erminia',
        'Ruotolo',
        4,
        54,
        false
      );
    

      select public."insert_hut_worker"(
        61,
        'hutWorker54@gmail.com',
        '$2b$10$.BhN1YafVpve4QZ68YlhCO9HlEQYAeqySn3.xfSYAPRPZlOAQvvc6',
        'Elettra',
        'Pisani',
        4,
        55,
        true
      );
    

      select public."insert_hut_worker"(
        62,
        'hutWorker55@gmail.com',
        '$2b$10$TrQr2pKlV3TKnmhXIEaihewgCmAwBtmnaApkzjEZQDZo7gNkCft/q',
        'Eufemio',
        'Petralia',
        4,
        56,
        false
      );
    

      select public."insert_hut_worker"(
        63,
        'hutWorker56@gmail.com',
        '$2b$10$7b7mYQp0GhaBxki3.WXUcus7M5ClO2/FjJkZkOdfYA0ZGLfwIZtae',
        'Abbondanzio',
        'La Sala',
        4,
        57,
        true
      );
    

      select public."insert_hut_worker"(
        64,
        'hutWorker57@gmail.com',
        '$2b$10$PA5Y7zDCL.Afscq9sIsB1enQgNIHTitsMAAUjKQ0gA.gjBltHUB5a',
        'Sabato',
        'La Manna',
        4,
        58,
        false
      );
    

      select public."insert_hut_worker"(
        65,
        'hutWorker58@gmail.com',
        '$2b$10$JiXaGY0TI/5/lolV8wpZ9u7CTq/QI1i4HCEzTDPvqd5J2FEhqV1r2',
        'Ulfa',
        'Ducci',
        4,
        59,
        true
      );
    

      select public."insert_hut_worker"(
        66,
        'hutWorker59@gmail.com',
        '$2b$10$jrMcGm3yUQO2uUthAjpyOuCSeZIpmBWGhZPN4MFk0nl.cgai9jF6.',
        'Elmo',
        'Siragusa',
        4,
        60,
        false
      );
    

      select public."insert_hut_worker"(
        67,
        'hutWorker60@gmail.com',
        '$2b$10$IU3ghIyDThIMlYs6rKGHu.490FRaJQTihDzVDZ.4nbxHLeGFilypu',
        'Abramio',
        'Bernardi',
        4,
        61,
        true
      );
    

      select public."insert_hut_worker"(
        68,
        'hutWorker61@gmail.com',
        '$2b$10$eigSnR4EhGcMZUol3e5yV.IvQMvF1Lk7OP2KqnXIfrfvOQFRlfv9m',
        'Mirko',
        'Malizia',
        4,
        62,
        false
      );
    

      select public."insert_hut_worker"(
        69,
        'hutWorker62@gmail.com',
        '$2b$10$tXcuYMZmjVUEH1QSrNGpmuc4hq/0k3YLDDXaGdQyqQ55JQ16suQpW',
        'Dario',
        'Noto',
        4,
        63,
        true
      );
    

      select public."insert_hut_worker"(
        70,
        'hutWorker63@gmail.com',
        '$2b$10$HxX/OmVst9.v7.5n8Vc2h.Q/amCijCMVXjF3nolnAdtboyt/OxpYm',
        'Fernando',
        'Petrucci',
        4,
        64,
        false
      );
    

      select public."insert_hut_worker"(
        71,
        'hutWorker64@gmail.com',
        '$2b$10$4YMr7kGWhvuc7a6NtXXmue5ryGrSUMqSCaQPvgZYQsg00.3yVLmZm',
        'Zosima',
        'Grande',
        4,
        65,
        true
      );
    

      select public."insert_hut_worker"(
        72,
        'hutWorker65@gmail.com',
        '$2b$10$fXJpqtAlIyu3L.IKTPJS0u92virXbEvXOjwcaXCmcK2EKNC6E/0LW',
        'Luana',
        'Riccobono',
        4,
        66,
        false
      );
    

      select public."insert_hut_worker"(
        73,
        'hutWorker66@gmail.com',
        '$2b$10$bHoo5W.rk7UVgvcgqsE9TONlGbQWQrzQEK7UCXWOv3hOr7T2i/t.y',
        'Amone',
        'Sorce',
        4,
        67,
        true
      );
    

      select public."insert_hut_worker"(
        74,
        'hutWorker67@gmail.com',
        '$2b$10$7iiukvz.iNT7j7HcKdoWtu4i3qGYw4hhke.BuaElJG7ojvggzy7pa',
        'Evelina',
        'Scala',
        4,
        68,
        false
      );
    

      select public."insert_hut_worker"(
        75,
        'hutWorker68@gmail.com',
        '$2b$10$E7PEEALe6B2bIjS13ao8ZOAIcR6PYo42m0OK1O0aF9R7yG/nRBUdy',
        'Ponziano',
        'Signorile',
        4,
        69,
        true
      );
    

      select public."insert_hut_worker"(
        76,
        'hutWorker69@gmail.com',
        '$2b$10$L/KhVutg.sdpD7pr3UNdWeVrmQ0/MsqDV9kQzAPSaf.RLAkaQfnVu',
        'Cornelia',
        'Loffredo',
        4,
        70,
        false
      );
    

      select public."insert_hut_worker"(
        77,
        'hutWorker70@gmail.com',
        '$2b$10$ZA0MK2041DtN69U.nzQJEe9REM2UFsV0w5/63XOWhLrslYvzmVvuC',
        'Lieto',
        'Scorza',
        4,
        71,
        true
      );
    

      select public."insert_hut_worker"(
        78,
        'hutWorker71@gmail.com',
        '$2b$10$sDo9VidS0vk59xvKRCGt5O25pS5tB/SLctG6B0DjmKyeA4MtvdqUO',
        'Pardo',
        'Rambaldi',
        4,
        72,
        false
      );
    

      select public."insert_hut_worker"(
        79,
        'hutWorker72@gmail.com',
        '$2b$10$aqEJjBTyVnZsbM1r31j9QeaOCKI0iHMPk0JecBL9Rzazw8cZZrSH6',
        'Rosmunda',
        'Guglielmi',
        4,
        73,
        true
      );
    

      select public."insert_hut_worker"(
        80,
        'hutWorker73@gmail.com',
        '$2b$10$950qKP3vNTDk2mTdto0PSu.fSt1a3ewcqmL90MTKFVGHFF1Ttxyfe',
        'Ermenegarda',
        'Morabito',
        4,
        74,
        false
      );
    

      select public."insert_hut_worker"(
        81,
        'hutWorker74@gmail.com',
        '$2b$10$yUSMW/tqke4ggQ4LNowwauR7QxNpidxeDVThwbPH5C.SOFhHZ7Hte',
        'Gloria',
        'Marconi',
        4,
        75,
        true
      );
    

      select public."insert_hut_worker"(
        82,
        'hutWorker75@gmail.com',
        '$2b$10$ZlPMO5q/OGKTLZrpcgn4duhhqeYCcbyuClUBTsoWsv/PhPMyn6JLO',
        'Nicodemo',
        'Piazzolla',
        4,
        76,
        false
      );
    

      select public."insert_hut_worker"(
        83,
        'hutWorker76@gmail.com',
        '$2b$10$3dlwgUKg.E/KkKH6/ySyP.KEq0Bv.SoyQjVlIUtffzJNIVW5lB4XW',
        'Romoaldo',
        'Raneri',
        4,
        77,
        true
      );
    

      select public."insert_hut_worker"(
        84,
        'hutWorker77@gmail.com',
        '$2b$10$KDj8spJ3J91872DgW3XNA.24ZU9xgiGe5FisDxGI7fnICJumU6hdu',
        'Miranda',
        'Campoli',
        4,
        78,
        false
      );
    

      select public."insert_hut_worker"(
        85,
        'hutWorker78@gmail.com',
        '$2b$10$G3l7qKWMfPBqBXuCa/KpDet8S0mwu11my.Zg71FYuNBMW1URLheEm',
        'Aurelio',
        'Lorenzini',
        4,
        79,
        true
      );
    

      select public."insert_hut_worker"(
        86,
        'hutWorker79@gmail.com',
        '$2b$10$x.PjBCYKJ8Isp7w/Xv0Aqetdu.zMA2J4n0JCg5U32AC0X723oZQni',
        'Furseo',
        'Bevilacqua',
        4,
        80,
        false
      );
    

      select public."insert_hut_worker"(
        87,
        'hutWorker80@gmail.com',
        '$2b$10$0Kbc2ijB3gC4ZyigbTJZF.VfE1wTjWVFPSywRwoVXg5LgInfI1Tle',
        'Malco',
        'Coccia',
        4,
        81,
        true
      );
    

      select public."insert_hut_worker"(
        88,
        'hutWorker81@gmail.com',
        '$2b$10$xtjDXkkMsQRfFTrRp3CMr.mOOKovzTcWHcS.l4U167JA.cBaO/bJK',
        'Pollione',
        'Re',
        4,
        82,
        false
      );
    

      select public."insert_hut_worker"(
        89,
        'hutWorker82@gmail.com',
        '$2b$10$RdzV0tBZqTZvRMDm8Xe8oezcbxbe.4DTGckKmQ7G91t6ZtdXbu4fS',
        'Marinella',
        'Capone',
        4,
        83,
        true
      );
    

      select public."insert_hut_worker"(
        90,
        'hutWorker83@gmail.com',
        '$2b$10$ljrKpjU1RUDpzbVJdGHkQe5NRFIfBww4Mxx9viGNe6dZUiQPzqS0K',
        'Maiorico',
        'Polverino',
        4,
        84,
        false
      );
    

      select public."insert_hut_worker"(
        91,
        'hutWorker84@gmail.com',
        '$2b$10$.Aw24dwrEB2MH8rYo2kaMuQJ6winXYkLFSVL14sfLsqvCnx0OyZW2',
        'Renata',
        'Magnani',
        4,
        85,
        true
      );
    

      select public."insert_hut_worker"(
        92,
        'hutWorker85@gmail.com',
        '$2b$10$m0qyoLPsjE4fIgcPQQWLB.eMXarCIVoWgJVBSM.3nXysFVeKTpoju',
        'Virginia',
        'Alessandrini',
        4,
        86,
        false
      );
    

      select public."insert_hut_worker"(
        93,
        'hutWorker86@gmail.com',
        '$2b$10$Rz6wbO1X3eNj08MHdzFMMOzmFH7hppDSsFk5IestEo2gcYK3Km15q',
        'Aratone',
        'Malagoli',
        4,
        87,
        true
      );
    

      select public."insert_hut_worker"(
        94,
        'hutWorker87@gmail.com',
        '$2b$10$A7iyq7B/JnBPeF05aL4CKuuPDG8q7mJnxdVfGloBQvg5keBFcrMJG',
        'Arnaldo',
        'Valeri',
        4,
        88,
        false
      );
    

      select public."insert_hut_worker"(
        95,
        'hutWorker88@gmail.com',
        '$2b$10$GASyRIrxTshRPplVHM0Evu.1CkdN5o0zFmBmZxf6Dj0F2c71wM2de',
        'Quintilio',
        'Palla',
        4,
        89,
        true
      );
    

      select public."insert_hut_worker"(
        96,
        'hutWorker89@gmail.com',
        '$2b$10$OzYfJLJUBNyLJlwQqyLctOwuco3cL8pseS9MpS6xqv.XJG3DvmIIe',
        'Cordelia',
        'Barletta',
        4,
        90,
        false
      );
    

      select public."insert_hut_worker"(
        97,
        'hutWorker90@gmail.com',
        '$2b$10$9lUjAdpAOKSASZewzPGetucf8it8NErqOmmOQlQOYcSGhKz0zuAoG',
        'Carla',
        'Bongiorno',
        4,
        91,
        true
      );
    

      select public."insert_hut_worker"(
        98,
        'hutWorker91@gmail.com',
        '$2b$10$5Ab3ELWoZHKhQSe9WH5i0e7r.KK1fUEIY9nrycFHBnU0j2ury7Lfu',
        'Gilda',
        'Caccamo',
        4,
        92,
        false
      );
    

      select public."insert_hut_worker"(
        99,
        'hutWorker92@gmail.com',
        '$2b$10$0qRupdphB0KDMIg2ptMdGOzAm0YGKrtme54wuxqwieHc4JEc7/WAW',
        'Asterio',
        'Storti',
        4,
        93,
        true
      );
    

      select public."insert_hut_worker"(
        100,
        'hutWorker93@gmail.com',
        '$2b$10$pohztKT.Kr1jc0rA0Zra9uVJ1HW8iFZDh2NEauHo9i5f.sJE2kXxO',
        'Agata',
        'Vittori',
        4,
        94,
        false
      );
    

      select public."insert_hut_worker"(
        101,
        'hutWorker94@gmail.com',
        '$2b$10$Xdly98.ZNybnUUxYyq/KMeMuDC1wDVzDHwM6govpXcCzr5Qf.a.A6',
        'Pio',
        'Polese',
        4,
        95,
        true
      );
    

      select public."insert_hut_worker"(
        102,
        'hutWorker95@gmail.com',
        '$2b$10$Qi3xfRRV93Oj1Gax1y4YzuK8iCR.4KP0/F1Q1q5mJf4KGVdToCKwy',
        'Rosita',
        'Gandolfo',
        4,
        96,
        false
      );
    

      select public."insert_hut_worker"(
        103,
        'hutWorker96@gmail.com',
        '$2b$10$2j8A6tUVOepabklQngxJ9OvzYkZIBNt43RYLqnjOW3LotbdovEjc6',
        'Loris',
        'Maniscalco',
        4,
        97,
        true
      );
    

      select public."insert_hut_worker"(
        104,
        'hutWorker97@gmail.com',
        '$2b$10$D8NSft2hknXDJfTIVVeonutOP7/OkK7QjUqxaFKlEkOD50l59jD.q',
        'Siriano',
        'Mencarelli',
        4,
        98,
        false
      );
    

      select public."insert_hut_worker"(
        105,
        'hutWorker98@gmail.com',
        '$2b$10$E6FcV88oJhrmvZ4qtp3A2OltL1x3P6Tq9lYDQguB10IDUCaZBRlkG',
        'Annagrazia',
        'Capasso',
        4,
        99,
        true
      );
    

      select public."insert_hut_worker"(
        106,
        'hutWorker99@gmail.com',
        '$2b$10$HcNmoeJ2ZKEdmS2H3bg8p.9rBohuu0c43cokZzQmIlkiFQkmmxDyq',
        'Berenice',
        'Accardo',
        4,
        100,
        false
      );
    

      select public."insert_hut_worker"(
        107,
        'hutWorker100@gmail.com',
        '$2b$10$pjYHq7GoPnssvFjyggU9N.KYSkn/4G.nFZKRYXzICmXrNt2NQL8s2',
        'Euridice',
        'Schiavon',
        4,
        101,
        true
      );
    

      select public."insert_hut_worker"(
        108,
        'hutWorker101@gmail.com',
        '$2b$10$c.fof8o1wsl55VcdmbRO6.Nyu4tPApMWDnl.rzvExuZYo0nUPFnBW',
        'Leopardo',
        'Barretta',
        4,
        102,
        false
      );
    

      select public."insert_hut_worker"(
        109,
        'hutWorker102@gmail.com',
        '$2b$10$1pVtDSgIF23SaOdDi8mrdO70fopL0mSgBN0Otks6AQhTtB4B19fLC',
        'Amanda',
        'Maltese',
        4,
        103,
        true
      );
    

      select public."insert_hut_worker"(
        110,
        'hutWorker103@gmail.com',
        '$2b$10$vr1J7c8aspuyWsD0lB4aY.xoD3gN9oAvy3PpFiPxh.w3PKY3k/Upy',
        'Dolores',
        'Grange',
        4,
        104,
        false
      );
    

      select public."insert_hut_worker"(
        111,
        'hutWorker104@gmail.com',
        '$2b$10$znh2FX5uFkGdJMX8H234GuEaBfnizNKr/OKXEKn9BsD2.SK3GjI72',
        'Astrid',
        'Barsotti',
        4,
        105,
        true
      );
    

      select public."insert_hut_worker"(
        112,
        'hutWorker105@gmail.com',
        '$2b$10$pQxh.zyGbeR92m.Q9vdxROl5F.nK70bUujBB17b8.yURwnItO6M3i',
        'Franca',
        'Rocco',
        4,
        106,
        false
      );
    

      select public."insert_hut_worker"(
        113,
        'hutWorker106@gmail.com',
        '$2b$10$okqpFWdV23CfwkYxo.AY5ehfUz5lmuNl.ApamwS4MZiBLqH2gR9X2',
        'Martina',
        'Cerutti',
        4,
        107,
        true
      );
    

      select public."insert_hut_worker"(
        114,
        'hutWorker107@gmail.com',
        '$2b$10$sZe9/FD.9j4oaur1zkpUFugPIGzCJ/RL4tUFdbR09s5XgpmBU9qji',
        'Callisto',
        'Vezzoli',
        4,
        108,
        false
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '17 Rotonda Solange, San Dionigi ligure, Italy',
        'San Dionigi ligure',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        133,
        '45 Strada Ferro, Silverio a mare, Italy',
        'Silverio a mare',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        276,
        '65 Borgo Di Fazio, Sesto Giliola a mare, Italy',
        'Sesto Giliola a mare',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        41,
        '875 Piazza Serapione, San Umile, Italy',
        'San Umile',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        102,
        '743 Via Fiammetta, Notaro umbro, Italy',
        'Notaro umbro',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        80,
        '784 Contrada Canale, Preziosi umbro, Italy',
        'Preziosi umbro',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        105,
        '5 Piazza Piacentini, Macrì lido, Italy',
        'Macrì lido',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        82,
        '70 Contrada Kofler, Borgo Francesca, Italy',
        'Borgo Francesca',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        56,
        '826 Borgo Augusto, Sesto Innocente nell''emilia, Italy',
        'Sesto Innocente nell''emilia',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        184,
        '64 Piazza Micco, Bruno salentino, Italy',
        'Bruno salentino',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        182,
        '457 Rotonda Calabrese, San Gabriella a mare, Italy',
        'San Gabriella a mare',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        92,
        '66 Strada Papa, Settimo Ida, Italy',
        'Settimo Ida',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        267,
        '38 Strada Barra, Sesto Patrizio, Italy',
        'Sesto Patrizio',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        117,
        '38 Incrocio Lucchese, Graziella ligure, Italy',
        'Graziella ligure',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        243,
        '75 Via Napoleone, Borgo Orazio, Italy',
        'Borgo Orazio',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        276,
        '4 Borgo Greta, San Costanza salentino, Italy',
        'San Costanza salentino',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        81,
        '6 Strada Contu, Borgo Tabita, Italy',
        'Borgo Tabita',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        34,
        '8 Incrocio Scrofani, Gambino lido, Italy',
        'Gambino lido',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        140,
        '69 Rotonda Babini, Vedasto salentino, Italy',
        'Vedasto salentino',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        150,
        '2 Strada Ingrosso, Toto sardo, Italy',
        'Toto sardo',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        160,
        '09 Piazza Coretti, Tina lido, Italy',
        'Tina lido',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        96,
        '488 Borgo Palazzi, Sesto Benigna salentino, Italy',
        'Sesto Benigna salentino',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '297 Contrada Cecco, Peroni laziale, Italy',
        'Peroni laziale',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        113,
        '04 Via Zosimo, Lupi salentino, Italy',
        'Lupi salentino',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        221,
        '67 Borgo Caracciolo, Celano nell''emilia, Italy',
        'Celano nell''emilia',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        285,
        '26 Via Saponaro, Vitalico veneto, Italy',
        'Vitalico veneto',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        108,
        '1 Strada Caiazzo, Menodora laziale, Italy',
        'Menodora laziale',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        281,
        '8 Contrada Cristina, Bibiana umbro, Italy',
        'Bibiana umbro',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        115,
        '62 Rotonda Sergi, Settimo Ella, Italy',
        'Settimo Ella',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        67,
        '290 Via Crisafulli, Talarico terme, Italy',
        'Talarico terme',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        299,
        '0 Incrocio Crepaldi, Viliberto ligure, Italy',
        'Viliberto ligure',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        287,
        '63 Via Diocleziano, Pedroni laziale, Italy',
        'Pedroni laziale',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        192,
        '46 Via Cavallaro, San Agape, Italy',
        'San Agape',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '406 Borgo Tirri, Quarto Emiliano del friuli, Italy',
        'Quarto Emiliano del friuli',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        66,
        '371 Via Fosco, San Barbara a mare, Italy',
        'San Barbara a mare',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        107,
        '749 Via Innocente, Sesto Beatrice calabro, Italy',
        'Sesto Beatrice calabro',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        55,
        '3 Strada Indro, Settimo Bartolo, Italy',
        'Settimo Bartolo',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        150,
        '8 Incrocio Amato, Boris terme, Italy',
        'Boris terme',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        298,
        '07 Piazza Giacinto, San Guglielmo, Italy',
        'San Guglielmo',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        82,
        '797 Rotonda Prisco, Sesto Lidania sardo, Italy',
        'Sesto Lidania sardo',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '136 Incrocio Orsino, Sesto Mario, Italy',
        'Sesto Mario',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        180,
        '10 Incrocio Visani, Borgo Stiliano nell''emilia, Italy',
        'Borgo Stiliano nell''emilia',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        186,
        '64 Piazza Adriano, San Ugolina calabro, Italy',
        'San Ugolina calabro',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        153,
        '5 Via Tussio, Quarto Valter sardo, Italy',
        'Quarto Valter sardo',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        96,
        '9 Via Silvano, Quarto Maiorico lido, Italy',
        'Quarto Maiorico lido',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        133,
        '7 Rotonda Fabiola, Filippa del friuli, Italy',
        'Filippa del friuli',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        237,
        '396 Strada Babila, Ivan calabro, Italy',
        'Ivan calabro',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        175,
        '5 Via D''Elia, Settimo Vala, Italy',
        'Settimo Vala',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        280,
        '44 Strada Fortugno, Loiacono veneto, Italy',
        'Loiacono veneto',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        264,
        '9 Via Mignogna, Salvatore salentino, Italy',
        'Salvatore salentino',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        242,
        '7 Contrada Cecilio, Borgo Gioia a mare, Italy',
        'Borgo Gioia a mare',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '195 Borgo Prospero, Lo Iacono a mare, Italy',
        'Lo Iacono a mare',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        121,
        '98 Rotonda Di Giorgio, Settimo Bambina del friuli, Italy',
        'Settimo Bambina del friuli',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '25 Borgo D''Angelo, Bosi lido, Italy',
        'Bosi lido',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        175,
        '3 Rotonda Ivanoe, Lazzaro terme, Italy',
        'Lazzaro terme',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        261,
        '358 Via Orefice, Sesto Catena, Italy',
        'Sesto Catena',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        74,
        '49 Contrada Giacinta, Quarto Colmazio, Italy',
        'Quarto Colmazio',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        192,
        '990 Strada Casimiro, Borgo Tabita, Italy',
        'Borgo Tabita',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        80,
        '1 Rotonda Salis, Borgo Agapito, Italy',
        'Borgo Agapito',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        38,
        '911 Strada Rino, Lorella umbro, Italy',
        'Lorella umbro',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        247,
        '6 Rotonda Conte, San Cherubino sardo, Italy',
        'San Cherubino sardo',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        207,
        '8 Incrocio Martorana, Sesto Fazio a mare, Italy',
        'Sesto Fazio a mare',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        89,
        '7 Strada Ledda, Settimo Carmelo veneto, Italy',
        'Settimo Carmelo veneto',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        90,
        '28 Borgo Santi, Armida sardo, Italy',
        'Armida sardo',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        68,
        '16 Strada Verde, Rosa sardo, Italy',
        'Rosa sardo',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        114,
        '7 Incrocio Bartolini, Crescenzia lido, Italy',
        'Crescenzia lido',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        179,
        '1 Borgo Minerva, San Argelia, Italy',
        'San Argelia',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        111,
        '28 Strada Luchetti, Settimo Cinzia laziale, Italy',
        'Settimo Cinzia laziale',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        266,
        '186 Incrocio Mario, San Accursio del friuli, Italy',
        'San Accursio del friuli',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '8 Rotonda Ermes, Platone nell''emilia, Italy',
        'Platone nell''emilia',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        31,
        '59 Contrada Pericle, Libero umbro, Italy',
        'Libero umbro',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        117,
        '727 Strada Bandini, Violante umbro, Italy',
        'Violante umbro',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        161,
        '989 Strada Giacomo, Briano sardo, Italy',
        'Briano sardo',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        189,
        '3 Incrocio Franceschini, Eliano lido, Italy',
        'Eliano lido',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        268,
        '797 Piazza Torchia, Sesto Marina lido, Italy',
        'Sesto Marina lido',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        73,
        '593 Rotonda Clodoveo, Impellizzeri umbro, Italy',
        'Impellizzeri umbro',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        223,
        '0 Piazza Tazio, Settimo Adalfredo, Italy',
        'Settimo Adalfredo',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        193,
        '364 Borgo Iacopo, Quarto Endrigo veneto, Italy',
        'Quarto Endrigo veneto',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        49,
        '745 Borgo Brando, Sesto Vitalico, Italy',
        'Sesto Vitalico',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        130,
        '4 Strada Trevisan, Borgo Severino, Italy',
        'Borgo Severino',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        234,
        '50 Incrocio Malaspina, Sesto Pietro umbro, Italy',
        'Sesto Pietro umbro',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        101,
        '452 Rotonda Stefania, San Cosma, Italy',
        'San Cosma',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        52,
        '317 Via Moser, San Porziano sardo, Italy',
        'San Porziano sardo',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        79,
        '17 Piazza Morini, Sesto Linda, Italy',
        'Sesto Linda',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        104,
        '56 Strada Martina, Borgo Oddone, Italy',
        'Borgo Oddone',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        105,
        '913 Via Todaro, Alfonsa a mare, Italy',
        'Alfonsa a mare',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        69,
        '164 Strada Panzeri, Quarto Ilaria calabro, Italy',
        'Quarto Ilaria calabro',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        157,
        '6 Piazza Carponio, Settimo Filomeno calabro, Italy',
        'Settimo Filomeno calabro',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        58,
        '69 Contrada Lapo, Italo del friuli, Italy',
        'Italo del friuli',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        76,
        '92 Borgo Filippini, Averardo nell''emilia, Italy',
        'Averardo nell''emilia',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        84,
        '69 Contrada Genziano, San Spano del friuli, Italy',
        'San Spano del friuli',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        201,
        '175 Via Luce, Del Prete laziale, Italy',
        'Del Prete laziale',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        165,
        '64 Rotonda Marangon, Quarto Silvia, Italy',
        'Quarto Silvia',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        111,
        '998 Incrocio Aldobrando, San Benedetto, Italy',
        'San Benedetto',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        39,
        '0 Contrada Valter, Giovanni ligure, Italy',
        'Giovanni ligure',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        167,
        '37 Rotonda Turchi, San Aleandro, Italy',
        'San Aleandro',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        214,
        '29 Contrada Fiorelli, San Clara, Italy',
        'San Clara',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        245,
        '736 Contrada Vecchi, Pamela umbro, Italy',
        'Pamela umbro',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        144,
        '01 Strada Angelucci, Sesto Savina, Italy',
        'Sesto Savina',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        147,
        '0 Incrocio Valentini, Stiliano laziale, Italy',
        'Stiliano laziale',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        273,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        248,
        '6 Strada Schirru, Virone terme, Italy',
        'Virone terme',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        238,
        '9 Contrada Traini, Telchide calabro, Italy',
        'Telchide calabro',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        275,
        '8 Piazza Secondiano, Zunino sardo, Italy',
        'Zunino sardo',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        237,
        '7 Rotonda Torquato, Quarto Vidone terme, Italy',
        'Quarto Vidone terme',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        131,
        '6 Strada Petrella, Quarto Deanna, Italy',
        'Quarto Deanna',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        151,
        '817 Contrada Cuniberto, Luppi ligure, Italy',
        'Luppi ligure',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        262,
        '624 Contrada Gaudino, Settimo Alfreda, Italy',
        'Settimo Alfreda',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        56,
        '4 Piazza Archimede, Romualdo a mare, Italy',
        'Romualdo a mare',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        39,
        '9 Rotonda Emmerico, Generoso laziale, Italy',
        'Generoso laziale',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        248,
        '0 Contrada Luisa, San Teresa, Italy',
        'San Teresa',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        236,
        '836 Via Bernasconi, Cortese veneto, Italy',
        'Cortese veneto',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        259,
        '1 Via Schettino, Niceto del friuli, Italy',
        'Niceto del friuli',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        288,
        '3 Contrada Valfrido, Borgo Ursmaro, Italy',
        'Borgo Ursmaro',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        159,
        '884 Strada Angelica, Sesto Ivan laziale, Italy',
        'Sesto Ivan laziale',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        125,
        '867 Via Salvati, San Severiano, Italy',
        'San Severiano',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        231,
        '9 Via Fumagalli, Clodoveo ligure, Italy',
        'Clodoveo ligure',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        93,
        '50 Incrocio Eufemia, Pagliuca terme, Italy',
        'Pagliuca terme',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        248,
        '5 Rotonda Prospero, Manilio laziale, Italy',
        'Manilio laziale',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        250,
        '658 Contrada Ranolfo, Borgo Morena, Italy',
        'Borgo Morena',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        249,
        '23 Borgo Sinesio, Tina veneto, Italy',
        'Tina veneto',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        178,
        '8 Via Isa, Settimo Vanda laziale, Italy',
        'Settimo Vanda laziale',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        157,
        '443 Rotonda Ebe, Quarto Iago, Italy',
        'Quarto Iago',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        293,
        '983 Borgo Eloisa, Borgo Aniello, Italy',
        'Borgo Aniello',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        178,
        '4 Incrocio Viscardo, Vincenzo a mare, Italy',
        'Vincenzo a mare',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        112,
        '7 Piazza Minervino, Quarto Aldo, Italy',
        'Quarto Aldo',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '897 Borgo Sardina, Borgo Deodato, Italy',
        'Borgo Deodato',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        61,
        '667 Strada Lanteri, Borgo Moira lido, Italy',
        'Borgo Moira lido',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        117,
        '22 Borgo Erasmo, Tranquillo laziale, Italy',
        'Tranquillo laziale',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '87 Strada Gulino, Quarto Gentile, Italy',
        'Quarto Gentile',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '92 Rotonda Polizzi, Rino a mare, Italy',
        'Rino a mare',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        216,
        '7 Incrocio Ercolano, Achille calabro, Italy',
        'Achille calabro',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        274,
        '619 Piazza Eriberto, Sesto Amabile a mare, Italy',
        'Sesto Amabile a mare',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        42,
        '487 Via Lino, Quarto Geltrude lido, Italy',
        'Quarto Geltrude lido',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        92,
        '9 Borgo Milena, Settimo Socrate ligure, Italy',
        'Settimo Socrate ligure',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        205,
        '1 Contrada Priamo, Settimo Lorenza, Italy',
        'Settimo Lorenza',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '8 Via Riccio, Spagnuolo lido, Italy',
        'Spagnuolo lido',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '483 Strada Giovannelli, Calcedonio terme, Italy',
        'Calcedonio terme',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        193,
        '655 Borgo Oreste, Pastorino salentino, Italy',
        'Pastorino salentino',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '68 Via Picco, Borgo Attila, Italy',
        'Borgo Attila',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        184,
        '5 Incrocio Italia, Aimone umbro, Italy',
        'Aimone umbro',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        216,
        '4 Rotonda Gaia, Settimo Maruta sardo, Italy',
        'Settimo Maruta sardo',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        177,
        '88 Strada Caiazzo, Settimo Eliano ligure, Italy',
        'Settimo Eliano ligure',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        54,
        '2 Piazza Falcioni, Giraudo del friuli, Italy',
        'Giraudo del friuli',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        297,
        '47 Via Riccardo, Nives a mare, Italy',
        'Nives a mare',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        249,
        '81 Contrada Riva, Sesto Proteo ligure, Italy',
        'Sesto Proteo ligure',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        122,
        '75 Borgo Speranzio, Ermilo umbro, Italy',
        'Ermilo umbro',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        164,
        '544 Strada Delfina, San Valeriano sardo, Italy',
        'San Valeriano sardo',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        93,
        '31 Borgo Fedora, Marina lido, Italy',
        'Marina lido',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        151,
        '94 Rotonda Fermiano, Verde umbro, Italy',
        'Verde umbro',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        131,
        '46 Rotonda Annamaria, San Amedeo, Italy',
        'San Amedeo',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        55,
        '16 Contrada Scalzo, San Ilia sardo, Italy',
        'San Ilia sardo',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        26,
        '900 Piazza Capasso, Quarto Coreno, Italy',
        'Quarto Coreno',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        115,
        '8 Via Gineto, Borgo Concetto nell''emilia, Italy',
        'Borgo Concetto nell''emilia',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        281,
        '379 Strada Garimberto, Fortunato veneto, Italy',
        'Fortunato veneto',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        295,
        '9 Via Colella, Borgo Marita, Italy',
        'Borgo Marita',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        257,
        '7 Contrada Gionata, Di Benedetto salentino, Italy',
        'Di Benedetto salentino',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        279,
        '4 Incrocio Sammartano, Cesare terme, Italy',
        'Cesare terme',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        252,
        '213 Via Valente, Botta veneto, Italy',
        'Botta veneto',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        176,
        '987 Contrada Emilio, Crispino nell''emilia, Italy',
        'Crispino nell''emilia',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        271,
        '074 Incrocio Elia, Settimo Adelfo umbro, Italy',
        'Settimo Adelfo umbro',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        165,
        '1 Via Davide, Settimo Ugo del friuli, Italy',
        'Settimo Ugo del friuli',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        91,
        '67 Via La Monaca, Merli nell''emilia, Italy',
        'Merli nell''emilia',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        229,
        '0 Rotonda Apollonia, Quarto Fabio calabro, Italy',
        'Quarto Fabio calabro',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        173,
        '630 Contrada Bozzo, Saladino umbro, Italy',
        'Saladino umbro',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '18 Strada Sapienza, Borgo Ulrico salentino, Italy',
        'Borgo Ulrico salentino',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        109,
        '0 Via Bonifazi, Olla ligure, Italy',
        'Olla ligure',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        43,
        '7 Piazza Valerico, San Abdone, Italy',
        'San Abdone',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        299,
        '0 Incrocio Fidenziano, Luzzi terme, Italy',
        'Luzzi terme',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        180,
        '734 Strada Giuditta, Settimo Fidenzio a mare, Italy',
        'Settimo Fidenzio a mare',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        152,
        '208 Rotonda Molinaro, Sesto Eliano lido, Italy',
        'Sesto Eliano lido',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        157,
        '1 Piazza Santarossa, Borgo Fiorenziano, Italy',
        'Borgo Fiorenziano',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        263,
        '239 Strada Procopio, Piazzolla veneto, Italy',
        'Piazzolla veneto',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        272,
        '14 Contrada Visconti, Settimo Elita, Italy',
        'Settimo Elita',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        39,
        '2 Incrocio Manfredo, Scalia laziale, Italy',
        'Scalia laziale',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        287,
        '18 Piazza Nocerino, Cardini lido, Italy',
        'Cardini lido',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        250,
        '22 Rotonda Fleano, Di Pede terme, Italy',
        'Di Pede terme',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        132,
        '56 Incrocio Ileana, Quarto Emiliano, Italy',
        'Quarto Emiliano',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        193,
        '01 Borgo Zappia, Ermini calabro, Italy',
        'Ermini calabro',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        116,
        '30 Rotonda Tammaro, Sesto Emmerico, Italy',
        'Sesto Emmerico',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        206,
        '38 Incrocio Baldassarre, Graziano nell''emilia, Italy',
        'Graziano nell''emilia',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        193,
        '1 Via Galli, Borgo Tamara nell''emilia, Italy',
        'Borgo Tamara nell''emilia',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '6 Rotonda Gerardo, Quarto Ulfa, Italy',
        'Quarto Ulfa',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        139,
        '5 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        127,
        '682 Borgo Floris, Settimo Gianmarco terme, Italy',
        'Settimo Gianmarco terme',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        259,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        210,
        '35 Strada Anselmo, Sesto Guelfo umbro, Italy',
        'Sesto Guelfo umbro',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        51,
        '4 Borgo Erminio, Quarto Lidania a mare, Italy',
        'Quarto Lidania a mare',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        291,
        '458 Contrada Evaristo, Quarto Emanuele calabro, Italy',
        'Quarto Emanuele calabro',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        191,
        '175 Piazza Guarino, Guarnieri veneto, Italy',
        'Guarnieri veneto',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        89,
        '75 Contrada Pavone, San Laura calabro, Italy',
        'San Laura calabro',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        60,
        '057 Strada Latini, San Ruggero lido, Italy',
        'San Ruggero lido',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        153,
        '4 Via Icaro, Respicio umbro, Italy',
        'Respicio umbro',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        59,
        '358 Via Maresca, Petrone nell''emilia, Italy',
        'Petrone nell''emilia',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        266,
        '9 Piazza Loredana, Sesto Allegra nell''emilia, Italy',
        'Sesto Allegra nell''emilia',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        133,
        '4 Borgo Stefani, Editta sardo, Italy',
        'Editta sardo',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        78,
        '138 Rotonda Frasca, Damaso umbro, Italy',
        'Damaso umbro',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        144,
        '9 Rotonda Frontiniano, Borgo Vittoriano salentino, Italy',
        'Borgo Vittoriano salentino',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        282,
        '5 Incrocio Di Somma, Anatolia terme, Italy',
        'Anatolia terme',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        47,
        '4 Rotonda Efisio, Settimo Filippo, Italy',
        'Settimo Filippo',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        270,
        '31 Strada Valfrido, Serviliano veneto, Italy',
        'Serviliano veneto',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        236,
        '6 Via Francese, San Aristeo laziale, Italy',
        'San Aristeo laziale',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '7 Piazza Contini, Settimo Cecilio, Italy',
        'Settimo Cecilio',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        100,
        '387 Borgo Bellini, Quarto Zenobia a mare, Italy',
        'Quarto Zenobia a mare',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        176,
        '358 Contrada Caselli, Eligio salentino, Italy',
        'Eligio salentino',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        294,
        '8 Strada Alida, Sacchet sardo, Italy',
        'Sacchet sardo',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        159,
        '328 Piazza Tiano, Rubiano sardo, Italy',
        'Rubiano sardo',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        263,
        '54 Strada Carrozza, Settimo Wanda, Italy',
        'Settimo Wanda',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        204,
        '5 Contrada Isabella, Benigno calabro, Italy',
        'Benigno calabro',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        219,
        '9 Strada Corinna, Borgo Agnese, Italy',
        'Borgo Agnese',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        184,
        '3 Incrocio Polifemo, Settimo Onofrio a mare, Italy',
        'Settimo Onofrio a mare',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        165,
        '8 Piazza Moreno, Zanella terme, Italy',
        'Zanella terme',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '2 Strada Zena, Gerardo laziale, Italy',
        'Gerardo laziale',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        232,
        '708 Borgo Signorile, Deanna nell''emilia, Italy',
        'Deanna nell''emilia',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        118,
        '990 Rotonda Benedetta, Imelda veneto, Italy',
        'Imelda veneto',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        284,
        '577 Piazza Gisella, Nucera sardo, Italy',
        'Nucera sardo',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        150,
        '551 Contrada Celano, Quarto Gianpietro terme, Italy',
        'Quarto Gianpietro terme',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        256,
        '7 Borgo Cardella, Flora salentino, Italy',
        'Flora salentino',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        291,
        '8 Via Brignone, Motisi del friuli, Italy',
        'Motisi del friuli',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        272,
        '31 Borgo Sartor, Ampelio laziale, Italy',
        'Ampelio laziale',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        289,
        '275 Incrocio Visconti, San Pusicio sardo, Italy',
        'San Pusicio sardo',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '83 Borgo Dodato, Bernadetta lido, Italy',
        'Bernadetta lido',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        134,
        '56 Piazza Rosmunda, Melandri terme, Italy',
        'Melandri terme',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        29,
        '6 Incrocio Priamo, San Brando lido, Italy',
        'San Brando lido',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        284,
        '7 Piazza Liberato, Biondi veneto, Italy',
        'Biondi veneto',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        110,
        '9 Borgo Bosi, Silenzi laziale, Italy',
        'Silenzi laziale',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        55,
        '78 Piazza Moretto, Callisto laziale, Italy',
        'Callisto laziale',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        111,
        '3 Incrocio Di Santo, Madonna laziale, Italy',
        'Madonna laziale',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        235,
        '7 Rotonda Bove, Savino terme, Italy',
        'Savino terme',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        257,
        '24 Via Solocone, Quarto Isabella calabro, Italy',
        'Quarto Isabella calabro',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        217,
        '8 Via Gandolfo, Bove calabro, Italy',
        'Bove calabro',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        158,
        '0 Via Tullio, San Carmela, Italy',
        'San Carmela',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        297,
        '6 Piazza Reina, Sempronio ligure, Italy',
        'Sempronio ligure',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        181,
        '32 Contrada Del Gaudio, San Carmine lido, Italy',
        'San Carmine lido',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        229,
        '365 Strada Termine, Lodi salentino, Italy',
        'Lodi salentino',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        50,
        '3 Borgo Desdemona, Vivaldo salentino, Italy',
        'Vivaldo salentino',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        114,
        '72 Borgo Taziana, Novello calabro, Italy',
        'Novello calabro',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        167,
        '060 Contrada Lipari, Cini nell''emilia, Italy',
        'Cini nell''emilia',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        73,
        '529 Contrada Gusmeroli, Borgo Marilena, Italy',
        'Borgo Marilena',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        118,
        '9 Incrocio Felicia, Crippa calabro, Italy',
        'Crippa calabro',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        251,
        '3 Strada Aceto, Borgo Agostina terme, Italy',
        'Borgo Agostina terme',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        290,
        '07 Strada Adamo, San Gavino terme, Italy',
        'San Gavino terme',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        108,
        '36 Borgo Piscopo, Sesto Elisabetta veneto, Italy',
        'Sesto Elisabetta veneto',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        37,
        '695 Strada Sciacca, Liberto a mare, Italy',
        'Liberto a mare',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        102,
        '595 Via Nunziata, Eliana calabro, Italy',
        'Eliana calabro',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        41,
        '35 Incrocio Editta, Danilo nell''emilia, Italy',
        'Danilo nell''emilia',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        131,
        '0 Strada Matteo, Fabiola del friuli, Italy',
        'Fabiola del friuli',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        246,
        '9 Strada Palmieri, Spanu terme, Italy',
        'Spanu terme',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        212,
        '68 Rotonda Ticone, Borgo Eufronio nell''emilia, Italy',
        'Borgo Eufronio nell''emilia',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '24 Piazza Longo, Loretta umbro, Italy',
        'Loretta umbro',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        186,
        '255 Borgo Beata, Prisco veneto, Italy',
        'Prisco veneto',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        295,
        '2 Rotonda Luchetti, Settimo Cosima, Italy',
        'Settimo Cosima',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        263,
        '396 Borgo Campanini, Rampazzo veneto, Italy',
        'Rampazzo veneto',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        280,
        '37 Incrocio Boschetti, Monica calabro, Italy',
        'Monica calabro',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        143,
        '690 Piazza Celso, Fernando sardo, Italy',
        'Fernando sardo',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        144,
        '4 Contrada Agata, Vitiello lido, Italy',
        'Vitiello lido',
        'Italy',
        'Salerno',
        ''
      );
    
  