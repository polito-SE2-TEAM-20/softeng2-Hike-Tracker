--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: insert_hike(integer, character varying, integer, character varying, character varying, character varying, character varying, character varying, numeric, numeric, integer, character varying, jsonb, jsonb, jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hike(user_id integer, title character varying, difficulty integer, gpx_path character varying, country character varying, region character varying, province character varying, city character varying, length numeric, ascent numeric, expected_time integer, description character varying, pictures jsonb, start_point jsonb, end_point jsonb, reference_points jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'name')::varchar,
            (ref->>'address')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $$;


--
-- Name: insert_hut(integer, double precision, double precision, integer, numeric, character varying, character varying, character varying, character varying, numeric, time without time zone, time without time zone, character varying, character varying, jsonb, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut(user_id integer, lat double precision, lon double precision, number_of_beds integer, price numeric, title character varying, address character varying, owner_name character varying, website character varying, elevation numeric, working_time_start time without time zone, working_time_end time without time zone, email character varying, phone_number character varying, pictures jsonb, description character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber",
      "pictures",
      "description"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number,
      pictures,
      description
    );
    END
    $$;


--
-- Name: insert_hut_worker(integer, character varying, character varying, character varying, character varying, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut_worker(hwid integer, email character varying, password character varying, first_name character varying, last_name character varying, role integer, hut_id integer, approved boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$
      DECLARE
        user_id integer;
      BEGIN
      INSERT INTO "public"."users" (
        "id",
        "email",
        "password",
        "firstName",
        "lastName",
        "role",
        "verified",
        "approved"
      ) VALUES(
        hwid, email, password, first_name, last_name, role, true, approved
      ) returning id into user_id;

      INSERT INTO "public"."hut-worker" (
        "userId",
        "hutId"
      ) VALUES ( user_id, hut_id);
      END
      $$;


--
-- Name: insert_parking_lot(integer, double precision, double precision, character varying, integer, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_parking_lot(user_id integer, lat double precision, lon double precision, name character varying, max_cars integer, address character varying, city character varying, country character varying, region character varying, province character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: code-hike; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."code-hike" (code, "userHikeId") FROM stdin;
\.


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
1	1	0	5
1	2	100000	6
1	3	1	3
1	4	2	3
2	5	0	5
2	6	100000	6
3	7	0	5
3	8	100000	6
4	9	0	5
4	10	100000	6
5	11	0	5
5	12	100000	6
6	13	0	5
6	14	100000	6
7	15	0	5
7	16	100000	6
8	17	0	5
8	18	100000	6
8	19	1	3
8	20	2	3
9	21	0	5
9	22	100000	6
10	23	0	5
10	24	100000	6
11	25	0	5
11	26	100000	6
12	27	0	5
12	28	100000	6
13	29	0	5
13	30	100000	6
14	31	0	5
14	32	100000	6
15	33	0	5
15	34	100000	6
16	35	0	5
16	36	100000	6
17	37	0	5
17	38	100000	6
18	39	0	5
18	40	100000	6
19	41	0	5
19	42	100000	6
20	43	0	5
20	44	100000	6
21	45	0	5
21	46	100000	6
22	47	0	5
22	48	100000	6
23	49	0	5
23	50	100000	6
23	51	1	3
23	52	2	3
24	53	0	5
24	54	100000	6
25	55	0	5
25	56	100000	6
26	57	0	5
26	58	100000	6
27	59	0	5
27	60	100000	6
28	61	0	5
28	62	100000	6
29	63	0	5
29	64	100000	6
30	65	0	5
30	66	100000	6
30	67	1	3
30	68	2	3
30	69	3	3
31	70	0	5
31	71	100000	6
32	72	0	5
32	73	100000	6
33	74	0	5
33	75	100000	6
34	76	0	5
34	77	100000	6
35	78	0	5
35	79	100000	6
36	80	0	5
36	81	100000	6
37	82	0	5
37	83	100000	6
38	84	0	5
38	85	100000	6
38	86	1	3
38	87	2	3
39	88	0	5
39	89	100000	6
40	90	0	5
40	91	100000	6
41	92	0	5
41	93	100000	6
42	94	0	5
42	95	100000	6
43	96	0	5
43	97	100000	6
44	98	0	5
44	99	100000	6
45	100	0	5
45	101	100000	6
46	102	0	5
46	103	100000	6
46	104	1	3
46	105	2	3
47	106	0	5
47	107	100000	6
48	108	0	5
48	109	100000	6
49	110	0	5
49	111	100000	6
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country, condition, cause, pictures, "weatherStatus", "weatherDescription") FROM stdin;
1	2	9300.00	80	481.10	2	Amprimo	Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.	/static/gpx/Amprimo.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/3.jpg"]	0	
2	2	8700.00	200	583.70	1	Anello Chateau Beaulard - Cotolivier - Vazon	Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.	/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx	0.00	Piemonte	Torino	Beaulard	Italia	0		["/static/images/2.jpg"]	0	
3	2	5387.07	150	955.10	1	borgata ruà a cima di crosa	Raggiungi la partenza del Sentiero per la Cima di Crosa impostando sul navigatore “Borgata Ruà – Becetto“.\n\nParcheggiata la macchina a Borgata Ruà (o se impossibilitati a trovare un parcheggio anche a Becetto, allungando di 10 minuti il giro), si prende il sentiero sulla sinistra, nei pressi di una cartina (INDICAZIONI CIMA DI CROSA).	/static/gpx/Borgata Ruà-Cima di Crosa (1).gpx	0.00	Piemonte	Cuneo	Sampeyre	Italia	0		["/static/images/46.jpg"]	0	
4	2	3622.32	130	865.20	2	Colle della Gianna da Pian della Regina	Colle della Gianna at an altitude of approximately 2530m connects the Po Valley to the Pellice Valley allowing you to reach the Barbara Lowrie refuge, an ideal base for multi-day crossings.\n\nIt is advisable to carefully consult the weather forecasts especially for these areas frequently subject to very thick fog.\n\nBeing at moderately high altitudes in spring there is the possibility of finding tongues of snow that could make the ascent more difficult.	/static/gpx/Colle Della Gianna (1).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/37.jpg"]	0	
5	2	3221.31	120	712.94	3	Hike Zicher	Lungo l’itinerario non è garantita la piena copertura telefonica\nIn periodo estivo, la parte finale può essere molto esposta al sole e richiedere fatica.\nIn condizioni di vento forte, è preferibile non proseguire\nE’ possibile sviluppare un itinerario ad anello scendendo dal versante nord della montagna in direzione Bocchetta Sant’Antonio (ma attenzione ad un passaggio su rocce, soprattutto se ghiacciate).	/static/gpx/Hike_Zicher (2).gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Craveggio	Italia	0		["/static/images/29.jpg"]	0	
6	2	15636.67	150	1366.80	2	Usseaux Altro	The flowering of Eriofori along the shores of the lake between July and August is interesting, making it very suggestive.	/static/gpx/Laghi_Albergian.gpx	0.00	Piemonte	Torino	Usseaux	Italia	0		["/static/images/40.jpg"]	0	
7	2	15636.67	150	1366.80	3	Usseaux Altro	Itinerario vario e panoramico, non presenta particolari difficoltà ma per la lunghezza, il dislivello, la mancanza di punti di appoggio e la necessità di una certa capacità di orientamento su sentieri non sempre evidenti (specialmente per la variante in discesa) è consigliato a escursionisti allenati e esperti.	/static/gpx/Laghi_Albergiani.gpx	0.00	Piemonte	Torino	Usseaux	Italia	0		["/static/images/42.jpg"]	0	
8	2	8100.00	210	101.90	2	Lago Bianco	Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.\n\nLa diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.\n\nLa Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.\n\nSi può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.	/static/gpx/Lago Bianco.gpx	0.00	Auvergne-Rhone-Alpes	Savoia	Val-Cenis	Francia	0		["/static/images/1.jpg"]	0	
9	2	21358.83	170	1087.90	2	Lago dei 7 colori (lago gignoux)	Parcheggia a Claviere e dirigiti verso la strada comunale Valle Gimont che, dopo poco, si fa sterrata.\n\nLascia alla tua destra i cartelli che indicano il Lago Gignoux e prosegui risalendo le piste da sci.\n\nGiunto a Sagna Longa noterai che la zona è di interesse sciistico, infatti ci sono numerosi arrivi di seggiovia. Segui le indicazioni per Colle Bercia, attraversa una chiesetta, dei caseggiati in pietra e prosegui per il largo sentiero.\n\nL’intero percorso si sviluppa circondato dai bellissimi Monti della Luna ed è caratterizzato da una dolce e semicostante salita su terreno sterrato a tratti ghiaioso.\n\nSuperato il Colle Bercia continua sull’ampia carreggiata che ti conduce ad un valico nel quale noterai particolari conformazioni rocciose e una punta (Cima Saurel 2451 mt). Tieniti sul sentiero basso e supera il valico, che segna anche il confine con la Francia, dopo il quale troverai il lago immerso in una conca.	/static/gpx/Lago dei 7 colori (lago gignoux) (1).gpx	0.00	Piemonte	Torino	Claviere	Italia	0		["/static/images/51.jpg"]	0	
10	2	4024.73	120	810.90	2	Lago d'Afframont 1986 m	Una volta parcheggiata la macchina dirigiti verso il villaggio Albaron. Poco dopo i caseggiati ti troverai di fronte ad un impianto di risalita dismesso, a sinistra troverai un campetto da calcio, proprio dopo il campetto si intravedono i primi cartelli con le indicazioni per il Lago di Afframont. Il sentiero da seguire è il 213, ma lungo il tragitto troverai solo bandiere bianco/rosse e cartelli di legno che indicano la destinazione.\n\nSi sale l’ex pista da sci e ci si addentra nel bosco. Il primo tratto rimane ombreggiato, mentre inizia a farsi sentire la salita. Ad un certo punto ci si affianca ad un ruscello, il Rio di Afframont, che scorre sulla sinistra e si supera con facilità in prossimità dei caseggiati in pietra (attenzione nei periodi di pioggia perché potrebbe essere impraticabile).	/static/gpx/Lago di Afframont 1986 m.gpx	0.00	Piemonte	Torino	Balme	Italia	0		["/static/images/52.jpg"]	0	
11	2	7580.49	110	1049.26	2	Briccas da Borgata Brich 20/02/21	After leaving the car, we continue along the road, first paved and then dirt.\n\nIn case of little snow or high temperatures it is possible to cover the first 150m in altitude without snowshoes.\n\nAs soon as we hit the first snow, we put on our snowshoes and set off on a well-defined path that crosses a wood.\n\nAfter having left the last huts behind us, we turn right towards the North/East near a GTA trail sign painted on a boulder.\n\nFrom here, after the last bush, an enormous, very wide slope opens up before us which culminates right at our peak	/static/gpx/Monte Briccas da Brich (1).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/35.jpg"]	0	
12	2	11664.79	150	1472.80	3	Monte Ferra Con Marco e Daniel	Fondamentali i bastoncini specialmente nella discesa dal Monte Ferra al lago Reisassa.\n\nUnico punto di appoggio è il rifugio Melezè ad inizio itinerario (consigliamo di contattare direttamente la struttura per verificare giorni e orari di apertura)	/static/gpx/Monte Ferra (1).gpx	0.00	Piemonte	Cuneo	Cuneo	Italia	0		["/static/images/28.jpg"]	0	
13	2	6229.07	200	1024.76	2	Da Crissolo a Ghincia	The Path to Monte Granè is a suggestive walk with a splendid view of Monviso (3841 m) and Viso Mozzo (3019 m).\n\nLeave the car in the car park and continue to the left of the sports field where a splendid path immersed in the woods appears before us and after about 1.5 km you come to the dirt road which in summer leads to the Black Eagle refuge.\n\nContinuing on the latter and having reached the refuge, continue along the Crissolo slopes to the end of the ski-lift where, just above the Ghincia Pastour hut, we will find a statue of the Madonna to indicate the end of the path to Monte Granè.\n\nThe return takes place along the same route as the outward journey.	/static/gpx/Monte Granè (2).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/36.jpg"]	0	
14	2	6588.82	150	936.79	2	Montr Pigna da Prea	Posteggiata la macchina nel parcheggio sotto l’abitato di Prea ci dirigiamo lungo la strada asfaltata situata sotto il cimitero, lasciandocelo sulla destra.\n\nAppena incontriamo la prima neve possiamo allacciare le ciaspole e proseguire fino alla borgata di Sant’Anna di Prea. (Nei mesi invernali, con nevicate nella norma, la strada viene pulita fino al parcheggio quindi si può iniziare ad indossare le ciaspole fin da subito).\n\nSubito dopo il cartello, all’ingresso di Sant’Anna di Prea, sulla destra vi è un magnifico sentiero immerso nel bosco che permette di tagliare la borgata accorciando la salita di circa 1 km.\n\nIncrociando nuovamente la strada principale e percorrendo circa 3 km si giunge alla Baita Monte Pigna situata a metà degli impianti di Lurisia.	/static/gpx/Monte Pigna Da Prea (1).gpx	0.00	Piemonte	Cuneo	Roccaforte Mondovì	Italia	0		["/static/images/47.jpg"]	0	
15	2	10065.93	130	842.70	2	Pian della Regina - Laghi del Monviso	The excursion can start near the Po, parking the car in one of the many spaces available. Once you have crossed the stream, follow via Ruata.\n\nTo get your bearings in Crissolo, we suggest following the signs for "La Capanna" and ignoring the various detours on the left that follow the ski lifts. Before reaching the restaurant, you finally take the road, following the signs for Monte Tivoli.\n\nThe path climbs up into the wood (splendid during the autumn season) and crosses the Sbarme stream.	/static/gpx/Pian della Regina - Laghi del Monviso (1).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/32.jpg"]	0	
16	2	7281.87	120	504.40	2	Fenestrelle Escursionismo	Itinerario di medio sviluppo con ampio panorama verso la Val Chisone.\n\nAttenzione nella stagione invernale: la zona soggetta a valanghe in caso di abbondanti precipitazioni nevose, specialmente nella conca che precede il rifugio.\n\nInformarsi sempre sullo stato della neve presso i gestori del rifugio o l’ufficio turistico di Fenestrelle.	/static/gpx/Rif. Selleries.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/43.jpg"]	0	
17	2	4156.24	150	850.76	0	Rifugio Meira Garneri da Sampeyre	Lascia l’auto nel parcheggio della seggiovia di Sampeyre.\n\nLasciato il parcheggio saliamo subito a destra degli impianti di risalita, dove alcuni cartelli rossi ci segnalano il sentiero attraverso il bosco.\n\nPrendendo rapidamente quota, alla fine del primo tratto di boscoso, raggiungiamo la frazione Sodani dove possiamo osservare la bella chiesa affrescata.\n\nUsciti dalla borgata proseguiamo nuovamente lungo il sentiero circondati da larici, faggi, betulle e dopo alcune deviazione, sempre ben segnalate, usciamo in una splendida radura.\n\nSaliamo gli ultimi 200m a lato della pista o volendo possiamo proseguire più a destra incrociando la strada carrozzabile che nel periodo estivo porta al rifugio.	/static/gpx/Rifugio Meira Garneri da Sampeyre (1).gpx	0.00	Piemonte	Cuneo	Sampeyre	Italia	0		["/static/images/45.jpg"]	0	
18	2	4388.16	200	923.62	2	Sentiero per ROCCA PATANUA	Itinerario interamente rivolto a Sud che normalmente si libera dalla neve già a inizio primavera.\n\n(l’itinerario è stato svolto in periodo invernale, seguito scarsa e quasi totalmente assente copertura nevosa).	/static/gpx/Rocca Patanua da Prarotto (1).gpx	0.00	Piemonte	Torino	Condove	Italia	0		["/static/images/28.jpg"]	0	
19	2	8085.21	150	829.13	3	Cima Durand-Colle Bauzano-Artesina	Lasciata la macchina nello spazioso parcheggio di Artesina o nei posteggi vicino al bar Tana del Lupo, saliamo sulle piste dove possiamo subito infilare le ciaspole.\n\nProcediamo per circa 400m sull’ampio sentiero in direzione Ovest (a destra) e dopo alcuni tornanti troviamo un bivio (a sinistra vi è la stradina che percorreremo al ritorno) dove proseguiamo sulla destra (sentiero F02) dirigendoci verso la Celletta, punto panoramico sulla valle Ellero.\n\nPercorriamo il sentiero per Serra della Turra che ci porta prima a passare sotto la seggiovia e poi ad un pianoro dove troviamo la Baita della Turra, tappa ideale per un eventuale break o colazione.	/static/gpx/Senriero per Anello cima Durand, Colle Bauzano, Artesina (1) (1).gpx	0.00	Piemonte	Cuneo	Artesina	Italia	0		["/static/images/48.jpg"]	0	
20	2	9039.75	120	1090.66	1	Rifugio Quintino Sella e Viso Mozzo	The path does not present any difficulty, in case of rain, however, the climb is not recommended as the route is entirely on stony ground.\n\nFrom up there you have a privileged view of a large part of the Monviso chain and the close distance to the Re di pietra is unique.	/static/gpx/Sentiero per Rifugio Quintino Sella e Viso Mozzo.gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/31.jpg"]	0	
21	2	16969.03	120	984.23	3	Da Ss659 a Ss6591	Take the A26 motorway towards Gravellona Toce and follow it to the end. From there stay on the SS33 del Sempione passing Domodossola. At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls. There are unpaved parking lots just before the Centro Fondo Riale.	/static/gpx/Sentiero per Rupe del Gesso - CIASPOLE.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Formazzo	Italia	0		["/static/images/38.jpg"]	0	
22	2	11301.88	140	1381.69	2	Albogno-Pieve Margineta Mater	Escursione senza molte difficoltà ideale per il periodo primaverile e autunnale. \nDopo circa 2 ore di bosco si esce su delle creste molto panoramiche e semplici, il ritorno purtroppo viene fatto su un sentiero poco segnato sulla parte iniziale e ma man mano che si scende compiano sia segni e gli ometti.	/static/gpx/albogno-pieve-margineta-mater-27-8-21.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Albogno	Italia	0		["/static/images/11.jpg"]	0	
37	2	6500.00	225	78.00	2	La pieve romanica di Piesenzana e la valle delle tartufaie	Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. \nCirca 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. \nIn regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. \nA Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). \nContemporaneamente i ristoranti della zona propongono piatti a base di tartufi	/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx	0.00	Piemonte	Asti	Montechiaro d'Asti	Italia	0		["/static/images/5.jpg"]	0	
23	2	5400.00	200	913.60	2	Alte Langhe Settentrionali - Cossano Belbo	Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.\nSi svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.\nSi imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.\nInizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.\nPercorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. \nSeguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. \nSi procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante	/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx	0.00	Piemonte	Cuneo	Cossano Belbo	Italia	0		["/static/images/4.jpg"]	0	
24	2	8503.26	150	558.51	2	Anello per il Monte Freidour (PERLEVIEDELMONDO)	At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls.	/static/gpx/anello monte freidour (1).gpx	0.00	Piemonte	Torino	San Pietro Val Lemina	Italia	0		["/static/images/39.jpg"]	0	
25	2	42458.63	320	23175.26	2	Anello Pieve di Ledro-Biacesa di Ledro-Rifugio Nino Pernici	Anello sui monti a nord-est del Lago di Ledro, percorso in 3 giorni andando con molta calma, percorribile anche in 2. \nAlcuni tratti della prima metà del percorso sono attrezzati con scale e corde.	/static/gpx/anello-pieve-di-ledro-biacesa-di-ledro-rifugio-nino-pernici.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/14.jpg"]	0	
26	2	19320.58	210	666.37	2	Anello sui colli imolesi: Dozza - Pieve S. Andrea	Crossing the provincial road you can see the first of the various signs of the Camino di San Antonio that we will find along the way. We cross and begin a slow but constant climb alongside the fields, which will lead us to a beautiful panoramic view of the surrounding valleys. Paying attention to the crossroads, we continue until we cross the paved road again. In reality there is very little traffic... with a decent view of the Vena del Gesso Romagnola we arrive at the delightful village of Pieve Sant'Andrea (worth a quick detour), to then resume our journey. Be careful not to follow the path of Sant'Antonio, we descend rapidly (shortly after we find the Sorgente delle Accarisie on our left, already existing in Roman times) until we reach the small hamlet of Valsellustra. Here too we cross the road and follow the paved via delle Ville uphill to arrive at a first panoramic point over the surrounding gullies.	/static/gpx/anello-sui-colli-imolesi-dozza-pieve-s-andrea-valsellustra-s.gpx	0.00	Emilia-Romagna	Bologna	Dozza	Italia	0		["/static/images/21.jpg"]	0	
27	2	10764.50	300	1852.46	2	Campione Pieve Campione	Campione Pieve Campione	/static/gpx/campione-pieve-campione.gpx	0.00	Lombardia	Brescia	Campione del Garda	Italia	0		["/static/images/17.jpg"]	0	
28	2	15650.26	210	838.33	2	Casalfiumanese (BO) - Pieve di Sant'Andrea	Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don't die from the heat and the clouds filter the sun's rays and allow you to better enjoy the landscapes	/static/gpx/casalfiumanese-bo-pieve-di-santandrea.gpx	0.00	Emilia-Romagna	Bologna	Casal Fiumese	Italia	0		["/static/images/24.jpg"]	0	
29	2	15650.26	210	838.33	2	Casalfiumanese (BO) - Pieve di Sant'Andrea	Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don't die from the heat and the clouds filter the sun's rays and allow you to better enjoy the landscapes	/static/gpx/casalfiumanese-bo-pieve.gpx	0.00	Emilia-romagna	Bologna	CasalFiumese	Italia	0		["/static/images/25.jpg"]	0	
30	2	17987.27	150	651.41	1	Cavriana pieve- Volta mantovana chiesetta Madonna dei Marchi	Bellissima passeggiata con displivello	/static/gpx/cavriana-pieve-volta-mantovana-chiesetta-madonna-dei-marchi.gpx	0.00	Lombardia	Mantova	Cavriana	Italia	0		["/static/images/13.jpg"]	0	
31	2	5474.28	140	791.51	2	Sentiero per CIMA CIANTIPLAGNA	The route is safe and within everyone's reach, even though you reach a relatively high altitude... for this reason it is good to take into account sudden changes in the weather (wind, rain, thick fog).\n\nDue to the total absence of shading, I recommend sunscreen cream and adequate water supply.\n\nIn late spring it is still possible to find accumulations of snow which can make the ascent difficult, especially in the final stretch towards the summit.\n\nFor cheese lovers, I highly recommend a stop at the Pian dell'Alpe bergeria...	/static/gpx/ciantiplagna.gpx	0.00	Piemonte	Torino	Meana di Susa	Italia	0		["/static/images/41.jpg"]	0	
32	2	6588.82	120	936.79	2	Da Voltino a Pieve di Tremosine e ritorno	Fa quasi paura ad avvicinarsi alla ringhiera. \nVicino alla postazione panoramica presso il bar ristorante che ho fotografato, c'è l'inizio del sentiero per la discesa al Porto di Tremosine.C'è scritto che è consigliato per escursionisti esperti.	/static/gpx/da-voltino-a-pieve-di-tremosine-e-ritorno.gpx	0.00	Lombardia	Brescia	Tremosine sul Garda	Italia	0		["/static/images/15.jpg"]	0	
33	2	13691.92	150	584.92	2	Dalla chiesa romanica di San Pietro di Fenestrella alla abba...	Chiesa di San Pietro de Fenestrella: \nLa chiesa è situata nel cimitero di Albugnano. \nEssa ha affinità compositive con la Canonica di santa Maria di Vezzolano e deriverebbe il suo nome ,secondo alcuni,dalla insolita presenza di tre finestre nell’abside,secondo altri, sarebbe stata così denominata perchè situata nello stretto colle (una gola) compreso tra il rilievo collinare di Albugnano e il rilievo ove sorge il cimitero: \nUna specie di finestra aperta sulla valle sottostante.	/static/gpx/dalla-chiesa-romanica-di-san-pietro-di-fenestrella-alla-abba.gpx	0.00	Piemonte	Asti	Albugnano	Italia	0		["/static/images/27.jpg"]	0	
34	2	14496.86	90	832.35	1	Gulo - Pieve Vergonte	Gulo - Pieve Vergonte	/static/gpx/gulo-pieve-vergonte.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Santa Maria	Italia	0		["/static/images/9.jpg"]	0	
35	2	9623.86	210	697.12	2	Il giro del Montorfano: la chiesa romanica, il borgo e la ve...	Il giro del Montorfano: la chiesa romanica, il borgo e la vetta	/static/gpx/il-giro-del-montorfano-la-chiesa-romanica-il-borgo-e-la-vett.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Bracchio	Italia	0		["/static/images/10.jpg"]	0	
36	2	12572.72	210	341.55	3	La chiesa romanica di S. Vittore(anello Montemagno--Viarigi)	Il percorso si svolge prevalentemente su sterrata. \nEsso non ha segnaletica ad eccezione dell’ultimo tratto (due km. circa) da località Madonna del Gombo fino a Montemagno. \nIn questo tratto si incontra la segnaletica del sentiero n.507 della Regione Piemonte.	/static/gpx/la-chiesa-romanica-di-s-vittoreanello-montemagno-viarigi.gpx	0.00	Piemonte	Asti	Montemagno	Italia	0		["/static/images/6.jpg"]	0	
38	2	12572.72	255	341.55	3	Le Paludi di Ostiglia Oasi del Busatello Sermide e Pieve	La tradizione afferma che la chiesa fu costruita nel 1082, per volere di Matilde di Canossa. Questa attribuzione risale al 1612 nella Historia ecclesiastica di Mantova dove il Donesmondi attribuisce l'edificazione della chiesa a Matilde, assieme ad altre chiese del territorio. \nIl Donesmondi affermò questa data riprendendo l'iscrizione da una lapide presente sulla facciata della pieve, visibile ancora oggi, dove sta scritto "D.O.M. ET B. MARIAE V. IN COELUM ASSUMPTAE ERECTA A.D. 1082 A CONNTISSA MATHILDE". Secondo un'analisi storica questa lapide non può essere ritenuta originale dell'XI secolo, ma risale al cinquecento. L'ipotesi è che questa iscrizione si stata realizzata durante il restauro del 1538. \nStoricamente, quindi, non ci sono documenti che attestano una data certa di costruzione della chiesa, ma sulla base degli elementi architettonici si può affermare che la pieve venne eretta nell'XI secolo. \nLa chiesa è in stile romanico, costruita in laterizio ed è composta da tre navat	/static/gpx/le-paludi-di-ostiglia-oasi-del-busatello-sermide-e-pieve-di-.gpx	0.00	Lombardia	Mantova	Pieve di Coriano	Italia	0		["/static/images/7.jpg"]	0	
39	2	2150.30	120	586.43	2	Sentiero per il MONTE CUCETTO	Escursione Facile e, nella parte alta, molto panoramica; la cima offre una buona panoramica dei rilievi tra bassa Val Chisone e Val Sangone.\n\nLasciata l’auto, il sentiero parte in corrispondenza del tornante ed entra nel bosco in direzione Nord-Ovest; al primo bivio, proseguire dritto e seguire le indicazioni per “Cucetto”; il sentiero inizia a guadagnare quota abbastanza rapidamente e costantemente, sempre nel bosco.\n\nDopo una serie di tornantini la vegetazione inizierà a diradarsi e si inizierà a scorgere un bel panorama con il Monviso in bella mostra (se il meteo lo permette).	/static/gpx/monte cucetto.gpx	0.00	Piemonte	Torino	Dubbione	Italia	0		["/static/images/50.jpg"]	0	
40	2	2127.35	200	277.52	2	Sentiero per il MONTE MURETTO	È presente un unico punto acqua nel luogo del parcheggio (fontana). Nella stessa piazzetta, al momento della recensione, è sempre aperto nei weekend un singolare bar allestito dentro un vecchio furgone.\n\nPer chi cammina con bimbi e soprattutto cani, attenzione in primavera alla presenza di processionarie.	/static/gpx/monte muretto.gpx	0.00	Piemonte	Torino	Torino	Italia	0		["/static/images/44.jpg"]	0	
41	2	8627.55	70	1018.01	1	Pieve di Ledro - Monte Cocca	Very challenging, but worth it! The view from the top is gorgeous! For the descent it is better to use sticks, or repeat the same route as the climb.	/static/gpx/pieve-di-ledro-monte-cocca.gpx	0.00	Trentino Alto Adige	Provincia di Trento	Pieve di Ledro	Italia	0		["/static/images/20.jpg"]	0	
42	2	22430.40	150	1004.43	2	Pieve S. Stefano a Pian delle Capanne	Causa pioggia e terreno scivoloso preso la 1º variante fino al passo Viamaggio poi proseguito ancora per la 2º variante. \nBisogna calcolare circa 4 km in più.	/static/gpx/pieve-s-stefano-a-pian-delle-capanne.gpx	0.00	Toscana	Arezzo	Pieve Santo Stefano	Italia	0		["/static/images/23.jpg"]	0	
43	2	4857.31	60	94.23	1	Piverone - Anello IV - “Via Romanica al Gesiun”	Piverone - Anello IV - “Via Romanica al Gesiun”	/static/gpx/piverone-anello-iv-via-romanica-al-gesiun.gpx	0.00	Piemonte	Torino	Pieverone	Italia	0		["/static/images/8.jpg"]	0	
44	2	6588.82	320	936.79	2	Plois - Pieve d'Alpago	percorso è tranquillamente percorribile	/static/gpx/plois-pieve-dalpago.gpx	0.00	Veneto	Belluno	Pieve d'Alpegno	Italia	0		["/static/images/19.jpg"]	0	
45	2	6588.82	200	936.79	2	Rifugio Galassi, forcella del ghiacciaio, Rifugio Antelao	Quinta giornata Alta via N°4\nRifugio Galassi, forcella del ghiacciaio, Rifugio Antelao, Pieve di Cadore.	/static/gpx/rifugio-galassi-forcella-del-ghiacciaio-rifugio-antelao-piev.gpx	0.00	Veneto	Belluno	Belluno	Italia	0		["/static/images/18.jpg"]	0	
46	2	8085.21	135	829.13	3	Riva del Garda - Pieve di Ledro - Panchina	Riva del Garda - Pieve di Ledro - Panchina	/static/gpx/riva-del-garda-pieve-di-ledro-panchina.gpx	0.00	Trentino Alto Adige	Provincia di Trento	Sant'Alessandro	Italia	0		["/static/images/16.jpg"]	0	
47	2	19553.11	210	1298.22	2	Sovicille delle Meraviglie - Villa Cetinale - Scala Santa	Suggestivo anello con visita della pieve di Pernina e del parco di Villa Cetinale/Castello di Celsa aperti in occasione dell'evento Sovicille delle Meraviglie ottobre 2021	/static/gpx/sovicille-delle-meraviglie-villa-cetinale-scala-santa-e-romi.gpx	0.00	Toscana	Siena	Sovicille	Italia	0		["/static/images/26.jpg"]	0	
48	2	5304.04	150	958.89	3	BERGERIE DI VALLONCRO’	Open and shade-free environment: remember sunscreen; if the walk is too long, the plateau at the base of the waterfall still offers various possibilities for pleasant picnics.	/static/gpx/vallone di massello (1).gpx	0.00	Piemonte	Torino	Massello	Italia	0		["/static/images/30.jpg"]	0	
49	2	22696.48	110	236.71	2	Ville Disunite - Anello Ghibullo - Villa Pasolini.	The first stretch is entirely on the right bank of the Ronco, on the Via Romea Germanica. Then you enter the territory to go towards the center of the journey, the area of ​​San Pietro in Trento where, within two kilometres, you come across a medieval tower, a 9th century parish church with a fantastic crypt, the ruins of a large villa and a perfectly healthy 16th century villa.	/static/gpx/ville-disunite-anello-ghibullo-villa-pasolini-torre-albicini.gpx	0.00	Emilia-Romagna	Ravenna	Lognana	Italia	0		["/static/images/23.jpg"]	0	
\.


--
-- Data for Name: hut-worker; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."hut-worker" ("userId", "hutId") FROM stdin;
7	1
8	2
9	3
10	4
11	5
12	6
13	7
14	8
15	9
16	10
17	11
18	12
19	13
20	14
21	15
22	16
23	17
24	18
25	19
26	20
27	21
28	22
29	23
30	24
31	25
32	26
33	27
34	28
35	29
36	30
37	31
38	32
39	33
40	34
41	35
42	36
43	37
44	38
45	39
46	40
47	41
48	42
49	43
50	44
51	45
52	46
53	47
54	48
55	49
56	50
57	51
58	52
59	53
60	54
61	55
62	56
63	57
64	58
65	59
66	60
67	61
68	62
69	63
70	64
71	65
72	66
73	67
74	68
75	69
76	70
77	71
78	72
79	73
80	74
81	75
82	76
83	77
84	78
85	79
86	80
87	81
88	82
89	83
90	84
91	85
92	86
93	87
94	88
95	89
96	90
97	91
98	92
99	93
100	94
101	95
102	96
103	97
104	98
105	99
106	100
107	101
108	102
109	103
110	104
111	105
112	106
113	107
114	108
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website, elevation, pictures, description, "workingTimeStart", "workingTimeEnd", "phoneNumber", email) FROM stdin;
1	112	1	120.00	Edmund-Graf-Hütte	2	Sig. Giuseppina Campisi	http://understated-truth.org	277.71	["/static/images/94072c68-40d4-4987-9b04-538fd16420d2.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg"]	Quam corrupti recusandae cumque error beatae ducimus consectetur.\nDeserunt beatae unde voluptas tempore.\nQuibusdam ab atque totam eum.\nNesciunt fuga impedit numquam quod accusantium.\nRepellat molestiae ipsum doloremque neque inventore doloremque accusantium animi deserunt.	09:00:00	19:00:00	+394288553615	Iona_Palmisano@hotmail.com
2	113	7	57.00	Dr.Hernaus-Stöckl	2	Guenda Forlani	https://firsthand-hill.com	323.17	["/static/images/0d76968e-1a08-415d-aaa7-0b7edaa1aef0.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]	Similique ipsum autem libero pariatur quisquam eum numquam sapiente.\nFacilis ad officia quidem eum perspiciatis mollitia possimus.\nVoluptas quidem modi.\nAccusamus inventore accusantium laborum facere assumenda sed adipisci.	05:00:00	18:00:00	+397370757749	Mimma.Demurtas14@email.it
3	114	10	114.00	Amstettner Hütte	2	Umile Luise	https://damaged-trowel.com	320.77	["/static/images/94072c68-40d4-4987-9b04-538fd16420d2.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg"]	Magni consequatur ex.\nSint sint exercitationem aliquid voluptate voluptates.\nRepellat dolorum esse dolor provident.\nUllam a magnam provident laboriosam fugit.	02:00:00	23:00:00	+391213199796	Natalina15@yahoo.it
4	115	5	110.00	Hochleckenhaus	2	Efrem Mazzoleno	https://greedy-lady.it	328.13	["/static/images/cc09fac1-266b-4032-9864-7e652f27929c.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg"]	Magni inventore voluptatum rem vitae vitae labore enim consequuntur delectus.\nMagnam amet labore tempora suscipit ea.\nSuscipit quia ex.\nAut deserunt corrupti ut nam animi.\nSit exercitationem ipsum alias occaecati voluptatem.	08:00:00	18:00:00	+393219150027	Ermes63@yahoo.it
5	116	9	104.00	Kampthalerhütte	2	Gervasio Dell'Amico	http://appropriate-surfboard.com	276.52	["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg"]	Autem asperiores distinctio perspiciatis ut et sapiente voluptas explicabo aspernatur.\nError nobis itaque.\nTenetur repellat dolorum reiciendis velit laboriosam quasi tempore a.\nEnim suscipit quo consequuntur doloribus fuga commodi ab.	03:00:00	20:00:00	+395436001957	Mirocleto_Liuzzi@email.it
6	117	3	49.00	Lambacher Hütte	2	Arabella Nicolosi	http://abandoned-fascia.org	303.23	["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]	Nulla culpa officia reprehenderit eveniet.\nEa eius accusantium.	02:00:00	23:00:00	+392461790988	Amerigo_Recchia@yahoo.it
7	118	4	147.00	Lustenauer Hütte	2	Capitolina Carlucci	http://torn-gloom.com	299.15	["/static/images/8765fd5b-1e43-4aa4-b7d3-1e21c02555d6.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg"]	Explicabo fugiat debitis.\nSapiente voluptate vero dolor at consectetur recusandae.	06:00:00	18:00:00	+394035010454	Walter_Quaranta@yahoo.com
8	119	6	117.00	Gablonzer Hütte	2	Veriana Rinaldi	https://fantastic-gemsbok.net	314.48	["/static/images/b6a44f8c-a9ac-4f1b-84cb-41910e38cc6e.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg"]	Molestiae sint vitae dolorum officiis omnis reiciendis et ullam.\nAt consectetur suscipit error sapiente explicabo quod sint debitis.\nQuis laborum fugiat.\nNon cumque illo.\nExercitationem nulla nemo officiis sint veniam non dicta.	08:00:00	19:00:00	+397601805945	Amanzio_Morini@yahoo.com
9	120	8	75.00	Katafygio «Flampouri»	2	Sigfrido Paci	http://actual-crib.com	315.19	["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg"]	Aperiam reprehenderit eos explicabo at inventore.\nQuisquam sit molestias earum minima repellendus minima quas non.\nDucimus aspernatur et adipisci officia alias sapiente iste illo autem.\nItaque nulla possimus ducimus nam facilis porro illo dolorum sapiente.\nQuo iste commodi.	07:00:00	20:00:00	+392534092387	Valerico1@hotmail.com
10	121	10	61.00	Simonyhütte	2	Aldo Serpa	http://criminal-airplane.org	280.24	["/static/images/1c178114-d7fd-414a-9eef-1a1cac332f83.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg"]	Delectus similique incidunt ex necessitatibus consequatur recusandae iusto autem.\nCorrupti officia fugit vel blanditiis enim dolore itaque iusto sequi.\nAt provident alias inventore officiis commodi asperiores.\nAperiam molestiae distinctio.\nAt ratione nobis.	04:00:00	23:00:00	+395850396582	Otello_Caggiano66@yahoo.it
11	122	9	66.00	Vinzenz-Tollinger-Hütte	2	Gilberto Vitiello	http://visible-merchandise.org	290.83	["/static/images/36742880-4fbc-4208-a6b6-3ec7290c112d.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]	Suscipit nihil non nulla.\nDolore reiciendis optio.\nEum voluptatibus odio odit veniam.	09:00:00	22:00:00	+398446716366	Carmen_DiGaetano2@yahoo.it
24	135	2	69.00	Oberzalimhütte	2	Sibilla Malavasi	http://jaded-defeat.org	273.61	["/static/images/fbcdf907-68c2-4ed1-999a-81601551aa5d.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg"]	Ipsum consequatur magni dignissimos magnam assumenda labore facere.\nInventore quae natus fuga libero praesentium.	08:00:00	19:00:00	+396708820610	Letizia_Ciulla@libero.it
12	123	4	43.00	Ottokar-Kernstock-Haus	2	Bartolomeo Massari	https://expensive-intentionality.org	285.44	["/static/images/9156aa5a-9192-446f-9f5e-7fe51ffbf7c6.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg"]	Officiis deserunt tempore recusandae minus ipsa provident exercitationem.\nTemporibus quia excepturi quo dignissimos odit iure natus.\nDignissimos cumque dignissimos eaque quisquam tempore harum veritatis et corporis.	07:00:00	21:00:00	+394733297563	Veronica_Ferranti78@gmail.com
13	124	3	55.00	Reisseckhütte	2	Ildebrando Novelli	https://worst-genre.org	318.40	["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]	Laudantium non mollitia dolor exercitationem.\nAsperiores soluta debitis modi repudiandae accusantium minus dolores.	05:00:00	23:00:00	+395679757529	Zelinda59@gmail.com
14	125	7	145.00	Vernagthütte	2	Aronne Benvenuti	http://black-and-white-cornet.org	274.50	["/static/images/b6a44f8c-a9ac-4f1b-84cb-41910e38cc6e.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg"]	Nisi quidem aspernatur provident reiciendis temporibus alias.\nIusto fugit voluptatibus.\nQuis odio aperiam est expedita nisi nisi quos.	04:00:00	22:00:00	+390039091970	Umile17@yahoo.it
15	126	5	63.00	Wormser Hütte	2	Nadia Sanna	https://portly-digit.net	324.47	["/static/images/380dce13-b063-4641-bbf2-173987d94f64.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg"]	Quas quibusdam voluptas aliquam praesentium minima necessitatibus iusto unde modi.\nQuis ea officiis cumque reiciendis corporis ut expedita.\nNon maxime explicabo minima repellat eum molestias.\nCumque officia aliquid enim distinctio inventore.	06:00:00	22:00:00	+393889384785	Casimiro83@yahoo.it
16	127	4	51.00	Biberacher Hütte	2	Galatea Mazzini	http://passionate-mainland.net	324.71	["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg"]	Recusandae odit laboriosam veritatis natus distinctio.\nRepudiandae eaque explicabo maiores.\nQuasi ab labore.\nEum error repellat esse molestiae ad consectetur unde illo.	08:00:00	18:00:00	+394520211766	Elia.Florio@yahoo.it
17	128	2	80.00	Katafygio «1777»	2	Unna Soro	http://warmhearted-input.net	336.66	["/static/images/71595344-e22a-4095-9bca-112353382c7c.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg"]	Atque nam sunt dolorum odio nisi.\nTenetur laborum cum aperiam explicabo pariatur at sequi.\nAut corporis impedit dolore voluptatem nemo iure animi maxime.	06:00:00	19:00:00	+391282905021	Tea93@yahoo.it
18	129	3	96.00	Hochwaldhütte	2	Amauri Mercuri	https://defenseless-spark.net	306.09	["/static/images/0d76968e-1a08-415d-aaa7-0b7edaa1aef0.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg"]	Impedit architecto harum itaque optio cupiditate ipsa.\nRecusandae provident mollitia aperiam quod ut.\nQuia ex magnam blanditiis.	07:00:00	20:00:00	+391933476222	Ermenegilda13@gmail.com
19	130	5	39.00	Kölner Eifelhütte	2	Sandra Vichi	http://key-accomplishment.com	271.04	["/static/images/fbcdf907-68c2-4ed1-999a-81601551aa5d.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg"]	Enim sint in harum alias recusandae nulla illo praesentium.\nSuscipit ex blanditiis ipsam laborum reprehenderit laudantium.\nQuo explicabo rerum rerum consequuntur vero debitis officia minus ducimus.\nLaborum cupiditate laudantium delectus officiis iste impedit ex.	07:00:00	21:00:00	+393676323547	Clemente.Perugini@gmail.com
20	131	8	45.00	Madrisahütte	2	Graziella Cocco	https://right-equity.it	281.19	["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg"]	Quasi inventore autem fugit iure itaque dolorum fugiat quo sequi.\nPerspiciatis quidem ea quaerat commodi laboriosam consectetur itaque.\nNon soluta quam qui esse earum.\nVeritatis laborum laboriosam.	08:00:00	23:00:00	+391224323172	Gordiano.Cavalieri@hotmail.com
21	132	3	46.00	Dresdner Hütte	2	Babila Bevilacqua	https://front-tunnel.net	267.33	["/static/images/b6a44f8c-a9ac-4f1b-84cb-41910e38cc6e.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg"]	A cumque ducimus aliquid saepe blanditiis explicabo eum quaerat.\nBeatae consectetur sit ipsa nam accusamus.\nSequi aperiam dolorum occaecati molestiae corporis omnis.	02:00:00	21:00:00	+399003743167	Agesilao_Ranucci@email.it
22	133	3	97.00	Fiderepasshütte	2	Aureliano Micco	http://junior-wrecker.com	313.56	["/static/images/3f6d2aea-9d16-4208-84e9-d54ed4d72045.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]	Sequi ad quae consequatur sequi voluptatum quos aperiam quaerat.\nOdio consequatur ut similique.\nA quibusdam esse.\nEum asperiores rerum corporis facilis.\nDistinctio et quam reprehenderit esse fugit.	04:00:00	21:00:00	+397854963922	Apollo.Saccone@hotmail.com
23	134	2	82.00	Göppinger Hütte	2	Giuliano Di Lascio	https://unsung-favor.net	267.57	["/static/images/cc09fac1-266b-4032-9864-7e652f27929c.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg"]	Id ea mollitia occaecati corporis commodi.\nLaboriosam nulla quo delectus.	09:00:00	19:00:00	+399219795847	Birino_Santarsiero@email.it
25	136	3	136.00	Rastkogelhütte	2	Cuzia Orlandi	https://aromatic-doctorate.net	313.94	["/static/images/380dce13-b063-4641-bbf2-173987d94f64.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg"]	Voluptas eveniet distinctio.\nIllum quam animi excepturi doloremque dolorem.\nNulla quod sequi.\nQuod officia voluptate harum nobis rerum.	04:00:00	20:00:00	+399184708049	Clorinda_Scopece28@email.it
26	137	5	102.00	Ansbacher Skihütte im Allgäu	2	Sonia Blanc	https://yellowish-jelly.org	279.07	["/static/images/36742880-4fbc-4208-a6b6-3ec7290c112d.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg"]	Itaque quisquam excepturi quaerat iste soluta atque velit.\nFuga atque consequatur minus similique sed placeat laudantium praesentium.\nIste mollitia corrupti tenetur fuga rerum.\nMollitia placeat sint neque commodi suscipit.	06:00:00	18:00:00	+397367188396	Narseo75@yahoo.com
27	138	1	106.00	Kaltenberghütte	2	Ambrosiano De Fazio	https://thin-paramedic.it	270.76	["/static/images/b6a44f8c-a9ac-4f1b-84cb-41910e38cc6e.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg"]	Magni dolores nemo accusamus ipsa aperiam aliquid cumque.\nIusto reiciendis sunt sint doloremque laborum accusamus.\nPorro suscipit facere sequi.\nNulla eveniet nemo modi maiores iure.	01:00:00	18:00:00	+399792520789	Giona23@gmail.com
28	139	10	146.00	Schweinfurter Hütte	2	Albano Puca	http://bountiful-valley.com	331.93	["/static/images/b6a44f8c-a9ac-4f1b-84cb-41910e38cc6e.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg"]	Dicta quaerat rem recusandae neque consequuntur cumque ipsum quaerat.\nCorrupti maiores incidunt quod.\nAmet voluptatem vero veniam.\nInventore nemo sint facilis necessitatibus adipisci deleniti alias.\nSaepe velit porro incidunt tempora excepturi.	05:00:00	20:00:00	+398508383856	Galeazzo_Talarico@yahoo.com
29	140	5	125.00	Katafygio «Vardousion»	2	Dulina Mancini	https://inexperienced-faith.org	306.91	["/static/images/fbcdf907-68c2-4ed1-999a-81601551aa5d.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg"]	Aliquam corrupti vel quisquam.\nNecessitatibus corporis accusamus.\nNesciunt blanditiis sit illum unde magni expedita maxime.\nNon corrupti rem quidem quia at ut.\nEos corporis mollitia magnam ducimus quos voluptates voluptatem fugit doloremque.	04:00:00	19:00:00	+397114293377	Antonio_Latorre@email.it
30	141	9	149.00	Kocbekov dom na Korošici	2	Luana Piccinini	https://artistic-robe.net	270.04	["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg"]	Ratione nobis dignissimos sunt iure dolorum vel libero nesciunt.\nExpedita eos aliquid illo mollitia.\nIure at error.\nId explicabo quas pariatur omnis veritatis fugiat.\nQuo fugit iste odit suscipit.	01:00:00	19:00:00	+398889443602	Maria21@hotmail.com
31	142	3	124.00	Planinski dom Rašiške cete na Rašici	2	Sabina Bergamasco	https://yellow-pentagon.net	333.44	["/static/images/729d360a-2e24-4b59-869a-1086080537d7.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]	Voluptates dolorum saepe reprehenderit laudantium hic eaque nemo voluptatem accusantium.\nTempora quod in minus vitae eligendi.\nQuia excepturi quam.\nVoluptatibus aut corporis quo in ut repellendus consequuntur.	06:00:00	23:00:00	+395170340788	Amore_Buonomo@yahoo.com
32	143	1	126.00	Prešernova koca na Stolu	2	Ing. Felicia Paolicelli	https://advanced-vibration.net	309.26	["/static/images/8765fd5b-1e43-4aa4-b7d3-1e21c02555d6.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg"]	Quibusdam nihil cumque ex.\nEst assumenda placeat pariatur nesciunt ex.\nIpsa veniam quia laboriosam.\nQuam reiciendis culpa sit commodi.\nPossimus voluptatibus culpa laudantium cumque cupiditate ratione alias.	03:00:00	19:00:00	+392990001669	Luciana_Ferracuti@email.it
33	144	2	101.00	Planinski dom na Mrzlici	2	Medoro Cerri	http://gracious-incidence.net	316.21	["/static/images/fbeba133-9be3-4029-a690-3c1f0d35db2c.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]	Accusantium quaerat animi id distinctio repellat unde ipsam possimus maiores.\nQuas animi ex doloribus placeat ipsa repellendus possimus accusamus.	01:00:00	23:00:00	+392328755300	Ionne68@email.it
34	145	8	126.00	Koca na Planini nad Vrhniko	2	Dott. Verano La Porta	http://stale-premeditation.org	323.80	["/static/images/729d360a-2e24-4b59-869a-1086080537d7.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]	Enim ducimus eius explicabo alias.\nExcepturi voluptatum reiciendis voluptate dicta facere nihil natus eius.	02:00:00	20:00:00	+398929733939	Betta.Melillo@hotmail.com
35	146	10	69.00	Zavetišce gorske straže na Jelencih	2	Elvino Vitale	http://brilliant-infrastructure.net	277.93	["/static/images/71595344-e22a-4095-9bca-112353382c7c.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg"]	Reprehenderit adipisci enim repellat hic animi necessitatibus quas.\nPlaceat alias nesciunt.\nNobis eos vero sed aliquid ipsa a aliquam ex et.\nFacilis cupiditate delectus nihil deleniti.\nIllo quasi iure delectus corrupti modi perspiciatis ullam nisi iste.	07:00:00	23:00:00	+399109259816	Tiberio39@yahoo.it
36	147	7	50.00	Planinski dom na Gori	2	Soave Chiacchio	https://grizzled-website.org	299.65	["/static/images/e6b68bd4-d913-4dcb-ab5a-364d13775e8d.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg"]	Aspernatur aut unde ducimus.\nTempora dolorem perferendis.\nPerferendis ducimus asperiores laboriosam quod.\nSoluta quod aliquam harum quos enim velit modi.	06:00:00	19:00:00	+392357774403	Evelina.DiDomenico22@gmail.com
37	148	6	90.00	Bregarjevo zavetišce na planini Viševnik	2	Dr. Placida Di Tullio	https://aching-weight.net	267.96	["/static/images/1c178114-d7fd-414a-9eef-1a1cac332f83.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg"]	Velit eum porro a cupiditate.\nSed ex suscipit nam cum.	04:00:00	23:00:00	+392814059202	Gualtiero.Maresca4@libero.it
38	149	6	43.00	Koca pod Bogatinom	2	Silvestro Latorre	http://graceful-arena.org	304.99	["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg"]	Quaerat error cum eum quod fuga consequatur.\nQuaerat explicabo alias accusamus aspernatur doloremque.\nFacilis ullam recusandae vero iste numquam provident.	09:00:00	19:00:00	+395549613019	Cecilio76@yahoo.com
39	150	9	93.00	Pogacnikov dom na Kriških podih	2	Adelberto Liuzzi	https://fluid-emerald.it	321.37	["/static/images/36742880-4fbc-4208-a6b6-3ec7290c112d.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg"]	Fugit sequi expedita atque cumque.\nRepudiandae nostrum minus.	09:00:00	20:00:00	+392933905939	Martino_DiFelice@yahoo.com
40	151	4	91.00	Dom na Smrekovcu	2	Claudia Grasso	http://wobbly-trader.net	278.81	["/static/images/b6a44f8c-a9ac-4f1b-84cb-41910e38cc6e.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg"]	Quaerat ducimus sequi architecto et facilis.\nNulla omnis inventore atque.\nLaborum enim excepturi recusandae neque ad.\nReprehenderit occaecati esse sequi delectus assumenda blanditiis ipsa ea.	08:00:00	19:00:00	+391996148989	Palatino_Chirico@yahoo.com
41	152	3	81.00	Refuge Du Chatelleret	2	Acacio Prato	https://bitter-trench.com	261.20	["/static/images/3f6d2aea-9d16-4208-84e9-d54ed4d72045.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]	Modi facere facilis cumque quo mollitia.\nSapiente inventore minima dolor optio sapiente quaerat excepturi nobis.\nUllam vitae ut unde minus amet ad.\nNumquam sapiente corporis dicta vero eum accusamus vel.\nAsperiores odio recusandae recusandae nihil nulla temporibus unde sequi error.	02:00:00	19:00:00	+396152830375	Dina_LoPinto@gmail.com
42	153	7	65.00	Refuge De Chalance	2	Minerva Antonacci	http://organic-river.org	337.04	["/static/images/36742880-4fbc-4208-a6b6-3ec7290c112d.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg"]	Aliquid quasi quasi nihil voluptates.\nNulla quae eveniet a ex.	07:00:00	21:00:00	+390932012816	Maria_Chiodi@yahoo.it
43	154	4	45.00	Refuge Des Bans	2	Ing. Ausilio Ramella	https://zesty-hydroxyl.net	269.29	["/static/images/71595344-e22a-4095-9bca-112353382c7c.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg"]	Quod corporis iure.\nDelectus atque quo perspiciatis quia sed.\nArchitecto non at sequi necessitatibus odit doloremque.	05:00:00	23:00:00	+396442796913	Libero16@gmail.com
44	155	5	83.00	Refuge De Pombie	2	Sisto Orlando	http://defensive-share.net	286.41	["/static/images/0d76968e-1a08-415d-aaa7-0b7edaa1aef0.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg"]	Porro perspiciatis odio dicta.\nTenetur mollitia dolorum eius id nihil occaecati illum repellat totam.\nIllo molestiae velit labore.	03:00:00	18:00:00	+393592493410	Gianpietro.Capizzi28@hotmail.com
45	156	3	115.00	Refuge De Larribet	2	Nazario Gerace	https://sturdy-lever.net	322.34	["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]	Atque sunt architecto dolore odio.\nLaboriosam ratione odit consectetur dolorem voluptatum nam sequi veritatis.\nNesciunt asperiores vitae rerum voluptates quod asperiores.\nIpsam nisi nobis quasi inventore.	07:00:00	23:00:00	+399251087879	Galatea.Tonelli84@libero.it
46	157	5	120.00	Refuge Du Mont Pourri	2	Dr. Valeriana Amato	https://proud-ophthalmologist.net	266.43	["/static/images/729d360a-2e24-4b59-869a-1086080537d7.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg"]	Harum officiis assumenda numquam.\nEos aut dolorum adipisci ut.	02:00:00	19:00:00	+396703639826	Bonifacio20@hotmail.com
47	158	7	42.00	Refuge De La Dent D?Oche	2	Alfonso Cecchini	http://idiotic-staircase.net	292.72	["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg"]	Molestiae quas mollitia rem.\nIure atque officiis fugiat accusamus.\nItaque facere vero nobis aliquid dignissimos hic.\nNecessitatibus sequi voluptas fuga maxime enim.	01:00:00	18:00:00	+392994707206	Bastiano_Rallo@gmail.com
48	159	8	91.00	Bergseehütte SAC	2	Domenica Cannella	http://animated-guideline.org	336.40	["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg"]	Minima excepturi quia commodi ratione ipsa iste laborum vero commodi.\nSimilique quod consequatur.\nUllam quod pariatur.\nVeritatis alias doloremque cupiditate non vitae.	07:00:00	19:00:00	+399877560972	Rainelda5@email.it
49	160	9	67.00	Bivouac au Col de la Dent Blanche CAS	2	Enecone De Cristofaro	https://international-rooster.net	325.82	["/static/images/94072c68-40d4-4987-9b04-538fd16420d2.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]	Ullam occaecati repellat et temporibus est illum.\nAperiam distinctio doloribus laboriosam pariatur aut labore harum reiciendis accusamus.\nTotam fugiat impedit harum a.\nEsse quod quibusdam quaerat.	08:00:00	22:00:00	+391841078655	Igor.Caporaso33@libero.it
50	161	4	57.00	Salbitschijenbiwak SAC	2	Giambattista Piga	http://beautiful-change.org	309.22	["/static/images/36742880-4fbc-4208-a6b6-3ec7290c112d.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]	Accusantium magnam odio quam.\nDolores occaecati ducimus facere corrupti id maxime velit soluta vitae.\nAt odit expedita sapiente veritatis saepe quas eos quam.\nDolores explicabo quam reiciendis modi odit blanditiis dolore.	02:00:00	19:00:00	+390082039914	Adrione_Reale28@yahoo.it
51	162	10	59.00	Spannorthütte SAC	2	Sostrato Vailati	https://buttery-cymbal.net	296.55	["/static/images/831a8347-cb69-4cd2-909e-73c60f704db3.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg"]	Aspernatur magni et beatae earum harum nam natus maiores vero.\nVoluptatum praesentium quas dolor dolorum quibusdam ipsam dignissimos.\nConsequatur veritatis eveniet.	06:00:00	21:00:00	+396678121121	Sapiente77@hotmail.com
52	163	2	82.00	Cabane Arpitettaz CAS	2	Adrione Zanella	http://exemplary-bit.com	281.20	["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]	Fugit vitae corporis quod voluptates laudantium repellat dolorem eius.\nVoluptatem hic maiores qui vitae doloremque nobis quidem.\nEa tempore nesciunt nihil iusto.\nDelectus adipisci accusantium fugiat.\nRatione in ratione velit consectetur nulla.	01:00:00	20:00:00	+390343160829	Fernando99@hotmail.com
53	164	7	131.00	Refugio De Lizara	2	Eliana Antonucci	http://silly-grassland.it	299.60	["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]	Vero voluptates alias blanditiis quae minima fugiat saepe ad sint.\nAd eveniet odio animi recusandae dignissimos nihil ipsa ad totam.	02:00:00	22:00:00	+395728512617	Costanza20@email.it
54	165	10	56.00	Albergue De Montfalcó	2	Gedeone Rubino	https://valuable-impropriety.org	320.81	["/static/images/36742880-4fbc-4208-a6b6-3ec7290c112d.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg"]	Unde alias voluptate eos.\nQuibusdam magnam officia provident neque asperiores aspernatur repudiandae reiciendis.\nDeleniti eaque sequi eveniet rem deleniti reprehenderit.	01:00:00	19:00:00	+398293556642	Eliano71@yahoo.it
55	166	8	79.00	El Molonillo/Peña Partida	2	Giada Quarta	https://excitable-fiesta.net	290.73	["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg"]	Cum magni natus deleniti a tenetur.\nRecusandae voluptatibus laborum eaque quod est distinctio repellat hic.\nCumque reprehenderit qui.\nNeque modi omnis voluptatem temporibus laboriosam animi distinctio beatae nostrum.\nIllum corporis excepturi cumque dicta.	05:00:00	19:00:00	+393527098996	Alessio.Massimi@email.it
56	167	10	46.00	La Campiñuela	2	Sig. Guiscardo Barbagallo	https://unhappy-screenwriting.com	282.57	["/static/images/71595344-e22a-4095-9bca-112353382c7c.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]	Praesentium aliquid omnis fugiat alias labore deserunt.\nNam alias harum similique facilis a nemo.\nAliquam veniam rerum odio.	01:00:00	23:00:00	+395817024924	Teodoro_Ranieri@yahoo.com
57	168	10	146.00	Titov Vrv	2	Ing. Venusto Principato	http://truthful-indigence.it	288.36	["/static/images/1c178114-d7fd-414a-9eef-1a1cac332f83.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg"]	Eius impedit facere nulla consequuntur eaque porro.\nCumque assumenda maiores quo.	07:00:00	18:00:00	+399640456768	Fabiola42@hotmail.com
58	169	2	102.00	Rifugio Franchetti	2	Francesco Ferranti	https://essential-essence.net	276.91	["/static/images/fbeba133-9be3-4029-a690-3c1f0d35db2c.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg"]	Odio laborum architecto delectus odio voluptatibus consequuntur vero.\nBlanditiis tempora saepe deleniti.\nQuas temporibus placeat quam rerum tempora dolores illo adipisci.	08:00:00	20:00:00	+391653431168	Letterio_DiLiberto@libero.it
59	170	3	59.00	Rifugio Semenza	2	Antonella Spadoni	http://miserable-try.com	312.91	["/static/images/0d76968e-1a08-415d-aaa7-0b7edaa1aef0.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg"]	Animi illo corrupti explicabo tempore quos natus.\nIllo occaecati suscipit molestiae doloremque illo nisi sapiente.\nPraesentium dolor quidem sequi magnam quas eius quas aliquid architecto.	07:00:00	20:00:00	+397225528247	Elda_Gianni@yahoo.it
60	171	10	59.00	Rifugio Città di Mortara 	2	Cronida Biondi	http://angelic-min.org	322.63	["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg"]	Recusandae eos doloremque possimus dolor in eius sunt corrupti.\nAd nulla quod placeat sed illum.	01:00:00	21:00:00	+396912763737	Evidio.Petralia17@libero.it
61	172	8	75.00	Rifugio Andolla	2	Dott. Vezio Iuliano	http://wan-bull.com	302.75	["/static/images/831a8347-cb69-4cd2-909e-73c60f704db3.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]	Doloribus laboriosam perspiciatis quis quidem.\nNostrum quis quia itaque quisquam vero quos aliquam in aperiam.\nDistinctio iusto deleniti officia eligendi voluptas consequuntur laboriosam accusantium.	06:00:00	21:00:00	+391627698790	Antonio.DeBonis@yahoo.com
62	173	2	103.00	Rifugio Forte dei Marmi	2	Antonio Platania	https://interesting-lymphocyte.org	299.42	["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg"]	Illo repellendus id deserunt eos neque expedita distinctio architecto facere.\nMolestias sapiente quas quod earum quod molestias.	05:00:00	22:00:00	+393193509855	Norina89@libero.it
63	174	6	126.00	Rifugio Berti	2	Dr. Marcello Bisio	https://required-pegboard.it	320.44	["/static/images/fbcdf907-68c2-4ed1-999a-81601551aa5d.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg"]	Excepturi a id repudiandae eligendi minima qui laborum aut quos.\nEnim ipsa ex suscipit sed.\nProvident necessitatibus alias nesciunt nesciunt iure nisi voluptatum.\nQuasi optio deleniti illum ipsa sit aspernatur.	04:00:00	18:00:00	+399733759315	Alfonsa.Evangelista@libero.it
64	175	7	82.00	Rifugio Premuda	2	Gianmario Nanni	https://hot-morsel.net	301.38	["/static/images/380dce13-b063-4641-bbf2-173987d94f64.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg"]	Repellat ea dolorum voluptatibus veniam.\nSunt possimus a quo in.\nFuga consequuntur doloribus placeat.	09:00:00	21:00:00	+393417935220	Mirco.Frigerio@hotmail.com
65	176	8	100.00	Rifugio Elisa	2	Postumio Fantozzi	https://menacing-impact.com	272.65	["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg"]	Libero corrupti consectetur nulla hic eaque quam.\nNisi saepe non corrupti vero a distinctio expedita officia.	02:00:00	23:00:00	+399664121546	Leonio.Iacovino0@gmail.com
66	177	2	35.00	Rifugio CAI Saronno	2	Cunegonda Mattei	https://acceptable-board.net	283.68	["/static/images/9156aa5a-9192-446f-9f5e-7fe51ffbf7c6.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]	Nihil dolorum corrupti accusantium magni nulla alias laborum harum libero.\nEarum deserunt ab fuga recusandae hic minus corrupti.\nNobis nulla culpa qui.\nVitae quis sapiente.	09:00:00	23:00:00	+393999311810	Cleofe.Oggiano@gmail.com
67	178	9	58.00	Rifugio Picco Ivigna	2	Rainelda Campana	http://vain-hotdog.net	291.15	["/static/images/cc09fac1-266b-4032-9864-7e652f27929c.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg"]	Vero cum incidunt.\nDeserunt laudantium suscipit enim praesentium voluptatum omnis quidem totam pariatur.\nVero quis voluptas iste perferendis qui atque iste quis esse.\nEos nulla rerum voluptatibus possimus quisquam ullam commodi assumenda iure.\nBlanditiis culpa quis dolore hic debitis cupiditate.	08:00:00	22:00:00	+393935547156	Settimio.Iacovino@hotmail.com
68	179	8	86.00	Rifugio Toesca	2	Sefora Ceccarini	http://shrill-noodle.net	314.74	["/static/images/729d360a-2e24-4b59-869a-1086080537d7.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]	Quam quibusdam dignissimos harum quia ut ea illo nulla.\nDebitis corrupti iusto voluptatem quam earum.\nMolestias neque earum distinctio unde facilis adipisci quod perferendis atque.	05:00:00	22:00:00	+391131553895	Geronzio.Villani@yahoo.it
69	180	6	85.00	Rifugio Al Cedo	2	Marzia Toscano	https://wide-eyed-kidney.net	325.28	["/static/images/94072c68-40d4-4987-9b04-538fd16420d2.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg"]	Libero asperiores aperiam natus.\nSimilique modi at veritatis sunt repellat maxime nihil repudiandae corporis.\nMagni id tenetur amet tempore.\nExercitationem modi porro.	01:00:00	18:00:00	+398262442241	Zenone.Ambrosino@libero.it
70	181	3	107.00	Capanna Gnifetti	2	Mirta Cappello	http://bountiful-proof-reader.net	308.07	["/static/images/71595344-e22a-4095-9bca-112353382c7c.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg"]	Asperiores quo minima ad accusamus.\nVoluptatibus incidunt aspernatur sed.\nAd nesciunt maiores aut repudiandae est blanditiis tempore consequatur.	09:00:00	19:00:00	+399546044257	Adriana48@yahoo.it
71	182	10	79.00	Rifugio Aosta	2	Alvise Spadaro	http://edible-coverage.net	291.77	["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg"]	Possimus natus porro officiis.\nError pariatur earum id.\nMagni aliquid adipisci fuga vero cumque quas.\nOccaecati unde quisquam maiores quibusdam assumenda perferendis iste officiis distinctio.	03:00:00	20:00:00	+393295971063	Ghita_Musumeci@yahoo.com
72	183	3	130.00	Rifugio Cevedale	2	Amore Santangelo	http://elderly-genius.it	324.56	["/static/images/84c2223b-e884-43a7-a5e4-3f4cc417f6ba.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg"]	Repudiandae perferendis omnis sunt ipsum ab et eos.\nAutem cumque exercitationem error quas nam corporis.\nLibero dolorum enim nam quos occaecati molestiae provident recusandae.	09:00:00	18:00:00	+397859138996	Erasmo98@gmail.com
73	184	5	84.00	Rifugio Ponti	2	Iona Cremonesi	http://studious-knee.com	269.59	["/static/images/9156aa5a-9192-446f-9f5e-7fe51ffbf7c6.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]	Saepe cupiditate minima minus id consequuntur harum doloremque.\nSapiente facere exercitationem necessitatibus necessitatibus ut esse quo voluptatem nihil.	06:00:00	19:00:00	+390622664254	Gerolamo.Ferrara@yahoo.com
74	185	3	144.00	Rifugio XII Apostoli	2	Benedetto Simula	https://parched-match.net	330.39	["/static/images/e6b68bd4-d913-4dcb-ab5a-364d13775e8d.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg"]	Omnis perferendis non minus pariatur reiciendis qui dolorum sequi quas.\nDistinctio placeat ipsam dolorum veritatis rerum eos cupiditate suscipit.\nAssumenda nam ex iure sapiente quidem harum.\nIncidunt amet nostrum atque facere quibusdam blanditiis.	05:00:00	23:00:00	+396401895714	Landolfo.Perrini59@yahoo.it
75	186	10	132.00	Rifugio Elisabetta Soldini	2	Adriano Visani	http://worst-atm.com	322.90	["/static/images/94072c68-40d4-4987-9b04-538fd16420d2.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg"]	Nam recusandae vero ea.\nMagni facilis vitae sequi molestias nemo aspernatur perferendis.\nEius natus nulla hic placeat delectus cumque sint voluptatem.\nIusto fugit soluta ipsa molestiae alias necessitatibus quibusdam dolores.\nTempore magni debitis.	02:00:00	21:00:00	+390228088721	Diocleziano_Boscaino14@yahoo.com
76	187	7	56.00	Rifugio Denza	2	Dott. Diletta Di Tommaso	http://witty-cloak.org	274.21	["/static/images/9156aa5a-9192-446f-9f5e-7fe51ffbf7c6.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg"]	Repudiandae aliquid labore veritatis totam ea ad temporibus quae.\nQuasi nulla doloribus.\nRecusandae ad ipsum debitis cupiditate qui repudiandae.	06:00:00	20:00:00	+399100736152	Zeno_Antonini96@yahoo.com
77	188	6	123.00	Rifugio Fonte Tavoloni 	2	Guendalina Vallone	http://content-intent.net	293.64	["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg"]	Quia quisquam asperiores accusantium architecto repellat aliquam dolorem et.\nConsequuntur dignissimos laboriosam cupiditate quaerat vero.\nUllam officiis necessitatibus vel quasi.	04:00:00	23:00:00	+394273379238	Aristide_Amoruso91@yahoo.com
78	189	3	36.00	Rifugio Carducci	2	Godeberta Abbate	https://oblong-uplift.net	279.61	["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg"]	Officiis fugiat sed expedita unde maxime esse earum voluptatibus.\nIpsum tempora architecto velit.\nAb possimus nulla voluptate mollitia.\nDolorem aut quis pariatur quam vero modi.	08:00:00	22:00:00	+396528359519	Calpurnia_Salerno94@hotmail.com
79	190	6	92.00	Rifugio Bindesi	2	Acrisio Foti	https://rotten-tabernacle.org	279.23	["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg"]	Quidem doloribus eum.\nSuscipit quisquam eum at.	04:00:00	23:00:00	+392920263043	Spano_Gasparini@yahoo.it
80	191	3	148.00	Mountain hut Miroslav Hirtz	2	Ondina Brunetti	https://windy-dinosaur.it	305.13	["/static/images/b6a44f8c-a9ac-4f1b-84cb-41910e38cc6e.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg"]	Veniam facilis sequi.\nOdit debitis sint excepturi saepe iste possimus.	01:00:00	18:00:00	+395444883638	Nicodemo.Corsi@hotmail.com
81	192	4	55.00	Koca na Blegošu	2	Narseo Agostini	http://unhealthy-harmonica.net	315.64	["/static/images/fbcdf907-68c2-4ed1-999a-81601551aa5d.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]	Dolorum quaerat repudiandae quas voluptate quod ipsam tenetur debitis illum.\nAut dignissimos est.\nNesciunt vel quidem sapiente.\nAliquid ab saepe adipisci omnis sunt aut pariatur perspiciatis.	08:00:00	19:00:00	+390430054273	Leonio31@libero.it
82	193	4	92.00	Wittener Hütte	2	Ezio Cioffi	http://alarmed-puggle.org	323.34	["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg"]	Facilis veniam occaecati est inventore earum consequatur suscipit illo accusamus.\nAmet doloribus officiis inventore.\nDelectus ab saepe dolores id velit fugiat adipisci.\nNihil quasi perspiciatis quia placeat.	07:00:00	22:00:00	+390099702386	Adelaide.Todaro@gmail.com
83	194	8	91.00	Hochjoch-Hospiz	2	Menodora Saponaro	https://honorable-kick.com	296.46	["/static/images/729d360a-2e24-4b59-869a-1086080537d7.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg"]	Expedita commodi eaque molestias sapiente similique eum rerum.\nEx reiciendis laborum adipisci expedita nam.	09:00:00	21:00:00	+399287867236	Fiore.Picco@hotmail.com
84	195	2	90.00	Meilerhütte	2	Devota Nicolosi	https://spicy-roundabout.net	313.95	["/static/images/fbeba133-9be3-4029-a690-3c1f0d35db2c.jpg", "/static/images/15938b64-f4ef-41e5-bcb7-72b2e26fd58c.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg"]	Accusamus veritatis pariatur dolores.\nOdit esse cupiditate exercitationem ipsa enim beatae.\nFuga aliquid a quos veritatis.	03:00:00	20:00:00	+396326012548	Mennone_DelPrete40@yahoo.com
85	196	5	138.00	Gaudeamushütte	2	Valter Malagoli	http://helpful-sanctuary.net	315.89	["/static/images/84c2223b-e884-43a7-a5e4-3f4cc417f6ba.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]	Blanditiis aut aspernatur similique officia.\nInventore similique dolor eligendi explicabo mollitia architecto voluptate dolorem.	06:00:00	19:00:00	+390395828803	Olimpio21@gmail.com
86	197	6	42.00	Rheydter Hütte	2	Zenobio Turco	http://hilarious-alphabet.org	286.77	["/static/images/fbeba133-9be3-4029-a690-3c1f0d35db2c.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg"]	Doloribus architecto illum error.\nDebitis odit provident laboriosam repudiandae expedita voluptatem molestiae rerum.\nConsequatur officia eum ducimus deleniti modi illo iusto eveniet.	02:00:00	23:00:00	+395891804954	Liberio.Bellotti@email.it
87	198	4	75.00	Sektionshütte Krippen	2	Democrito Nanni	http://traumatic-tailbud.it	294.87	["/static/images/380dce13-b063-4641-bbf2-173987d94f64.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg"]	Incidunt nisi magni dignissimos.\nAnimi ipsum suscipit aliquam a omnis.\nQuae recusandae dignissimos in id laborum doloribus quia.\nQuas aperiam nobis sed vero possimus laboriosam sint quisquam.	02:00:00	20:00:00	+399149883882	Venere_Giorgio47@yahoo.com
88	199	10	56.00	Neunkirchner Hütte	2	Ramiro Santo	http://kindly-carnation.org	302.87	["/static/images/4cc5da9a-5166-433a-ac7e-d73b42c71cda.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg"]	Eius quod laudantium ab voluptate deleniti quaerat est magni mollitia.\nPlaceat repellat aliquam error.\nAutem commodi fugit dicta cupiditate eveniet tempore omnis ipsa.\nModi dolores nihil veritatis non natus.	04:00:00	22:00:00	+392320867083	Abele62@libero.it
89	200	5	118.00	Refugio De Riglos	2	Alfreda Gianni	https://yellow-jazz.net	268.24	["/static/images/1c178114-d7fd-414a-9eef-1a1cac332f83.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]	Tenetur autem quasi alias.\nPerspiciatis harum voluptatem similique.\nIn minus dicta harum veniam recusandae.	05:00:00	22:00:00	+392111055683	Vilfredo_Catellani52@yahoo.com
90	201	2	72.00	Salbithütte SAC	2	Gianmario Schifano	https://bare-snowstorm.it	300.60	["/static/images/1c178114-d7fd-414a-9eef-1a1cac332f83.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg"]	Culpa debitis officia deleniti iusto fugiat itaque.\nCum a accusamus aliquam.\nQuas fugiat molestias natus iure iste vitae asperiores numquam maiores.\nTotam pariatur voluptas in.	06:00:00	20:00:00	+390191909666	Esuperio4@email.it
91	202	4	137.00	Finsteraarhornhütte SAC	2	Annunziata Andrisani	https://hollow-paperback.net	277.93	["/static/images/63ae91a6-9e69-411c-9f26-4abd66c57f68.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg"]	Temporibus aut neque consequuntur.\nSunt sed minus quam reprehenderit quas neque vitae quae.	09:00:00	22:00:00	+399115893400	Querano.LaRosa3@gmail.com
92	203	10	105.00	Cabane des Vignettes CAS	2	Dr. Azzurra Flacco	https://cruel-snowstorm.net	318.85	["/static/images/cc09fac1-266b-4032-9864-7e652f27929c.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/69a56a64-7923-426e-b913-1f723ce88363.jpg"]	Doloribus sapiente quisquam aut cumque illum nam rerum totam quia.\nPariatur minus perspiciatis dolor sit molestias adipisci pariatur quibusdam placeat.	06:00:00	23:00:00	+395660392410	Namazio9@gmail.com
93	204	5	137.00	Glecksteinhütte SAC	2	Nazario Rea	https://stained-press.net	323.10	["/static/images/9156aa5a-9192-446f-9f5e-7fe51ffbf7c6.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg"]	Porro hic dolore labore velit aperiam similique.\nUt nemo cupiditate qui corrupti tempore dolores tenetur laudantium.	02:00:00	22:00:00	+397395873025	Salomone_DAvino@yahoo.it
94	205	2	93.00	Länta-Hütte SAC	2	Tecla Feliziani	http://curly-eavesdropper.net	331.46	["/static/images/71595344-e22a-4095-9bca-112353382c7c.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]	Omnis eius laboriosam officia.\nVoluptates omnis repellat tempore incidunt doloremque.\nPariatur sunt assumenda.	03:00:00	18:00:00	+395396747319	Rosamunda.Polizzi@gmail.com
95	206	2	131.00	Monte-Leone-Hütte SAC	2	Adriano Ventimiglia	https://adept-usage.net	323.47	["/static/images/cc09fac1-266b-4032-9864-7e652f27929c.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg"]	Molestias doloremque veniam.\nA sed voluptatibus corporis dolor officia fuga quas doloribus libero.\nNam amet natus quae.\nIure excepturi facere saepe vel aliquid.	02:00:00	22:00:00	+390451591752	Venceslao72@hotmail.com
96	207	8	148.00	Ringelspitzhütte SAC	2	Gaudenzia Bertani	http://neat-sexuality.net	303.68	["/static/images/1c178114-d7fd-414a-9eef-1a1cac332f83.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg"]	Doloribus ullam cupiditate.\nVeritatis esse alias neque.	06:00:00	20:00:00	+396869101684	Ugolino17@gmail.com
97	208	4	114.00	Na poljanama Maljen	2	Amelia Aiello	http://keen-postage.com	314.65	["/static/images/831a8347-cb69-4cd2-909e-73c60f704db3.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]	Totam quas reprehenderit.\nReiciendis amet velit autem quia amet sunt iste nemo.\nPossimus rerum harum ea unde.\nVitae nam commodi inventore tempore.\nIste architecto perferendis placeat ut eius possimus ratione.	09:00:00	22:00:00	+398462693649	Eliana.Amato12@libero.it
98	209	8	115.00	Dobra voda	2	Sibilla Biagi	http://fumbling-cemetery.net	323.65	["/static/images/3f6d2aea-9d16-4208-84e9-d54ed4d72045.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg", "/static/images/41cce592-c250-4744-86f2-0a9c0ad6d8ec.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg"]	Deleniti officiis vel illum consequuntur ducimus.\nSapiente mollitia itaque occaecati reprehenderit deleniti vitae nulla neque.	05:00:00	22:00:00	+396907078740	Parmenio.Spadoni73@libero.it
99	210	9	115.00	Ivanova hiža	2	Marana Bressan	https://practical-wrestler.com	301.94	["/static/images/36742880-4fbc-4208-a6b6-3ec7290c112d.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg"]	Officiis dignissimos voluptatibus itaque dicta placeat nihil commodi corrupti laboriosam.\nIpsum perspiciatis cupiditate debitis minima.\nHarum fuga laborum molestiae doloremque libero nam ipsam molestias nobis.	01:00:00	20:00:00	+395887566671	Carola_Campana14@libero.it
100	211	4	63.00	Glavica	2	Consolata Betti	http://admired-thrill.org	275.44	["/static/images/380dce13-b063-4641-bbf2-173987d94f64.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg", "/static/images/fe974833-d199-4930-a743-101adf12d243.jpg", "/static/images/03c0dddf-0a09-4061-899b-9eb1deb6d7cf.jpg"]	Nam omnis aspernatur blanditiis architecto odit quos doloremque.\nNam eos beatae labore voluptas minima sed.\nVelit saepe cum nam magnam.	06:00:00	22:00:00	+390443948691	Danio11@hotmail.com
101	212	4	131.00	Trpošnjik	2	Crocefisso De Luca	https://satisfied-kitten.it	321.50	["/static/images/71595344-e22a-4095-9bca-112353382c7c.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg"]	Laboriosam iure est incidunt.\nA quod perferendis accusantium corrupti perspiciatis quia porro consequatur perferendis.\nQuidem nostrum quis dignissimos molestias a dolorum.\nVoluptates voluptatibus alias libero tenetur nisi eligendi fuga possimus.\nSapiente enim repellendus nisi.	08:00:00	18:00:00	+393253876375	Cleandro42@yahoo.it
102	213	3	134.00	Bitorajka	2	Brando Lo Giudice	http://downright-vintner.org	274.16	["/static/images/1c178114-d7fd-414a-9eef-1a1cac332f83.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg"]	Pariatur est iure quod expedita quae.\nDebitis iusto odit facere odio cumque ab dicta dolorem.\nConsequatur sint placeat dolorem ipsam quam veniam.	07:00:00	18:00:00	+396808293122	Amalia0@yahoo.com
103	214	9	89.00	Zlatko Prgin	2	Dott. Gedeone Tralli	https://afraid-borrowing.it	282.67	["/static/images/0d76968e-1a08-415d-aaa7-0b7edaa1aef0.jpg", "/static/images/42d70440-be61-4bc2-aef3-512a134cc1e6.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/2da36762-9325-40e0-a32f-b083267b3888.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg"]	Pariatur nesciunt alias architecto tenetur.\nFacere eveniet temporibus nam.\nOdio praesentium dolores cumque odio nisi modi.\nDolorem voluptatibus sapiente ad dolore quod perferendis neque.	04:00:00	20:00:00	+397398692334	Emiliano_Mosti31@libero.it
104	215	10	149.00	Prpa	2	Nazzareno Turchi	https://robust-encirclement.org	273.57	["/static/images/fbcdf907-68c2-4ed1-999a-81601551aa5d.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/7f2af718-5e88-4ad6-9bf2-d220a037f449.jpg"]	Veritatis sequi ut earum.\nNon laboriosam nisi libero dolor magnam qui voluptas.\nPraesentium quaerat voluptate quibusdam eos delectus sunt harum quae sit.\nAnimi praesentium voluptas fugit quia vitae officia.	06:00:00	23:00:00	+392343964724	Alberta74@yahoo.it
105	216	10	69.00	Ždrilo	2	Elia Demurtas	http://charming-coach.com	283.10	["/static/images/8765fd5b-1e43-4aa4-b7d3-1e21c02555d6.jpg", "/static/images/843ce8ed-397b-4a91-b968-feaf0c4d062f.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg"]	Labore eius quo incidunt adipisci eius.\nEt consectetur accusantium in eveniet impedit ipsam quo aliquam.\nOptio vero sed reiciendis veniam.\nCumque sint facilis illum odio esse beatae modi nam.\nTotam pariatur atque necessitatibus quidem deserunt veniam perspiciatis porro numquam.	02:00:00	21:00:00	+397452420567	Antonella.Natale@hotmail.com
106	217	2	104.00	Miroslav Hirtz	2	Soccorso Crescenzi	https://menacing-sailing.com	315.48	["/static/images/0d76968e-1a08-415d-aaa7-0b7edaa1aef0.jpg", "/static/images/6160751f-ae85-48fd-9ab1-16b6116687ef.jpg", "/static/images/ca31f75e-b1ec-4b44-a758-e316642bb286.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/32c57dc4-3219-43ee-b3f2-bcc07ff67b60.jpg"]	Delectus nisi aspernatur error.\nOccaecati consectetur delectus.\nArchitecto libero aliquam.	03:00:00	23:00:00	+394021262887	Savino_Zuliani85@hotmail.com
107	218	10	116.00	Jezerce	2	Lucio Sorrentino	http://colorless-linseed.com	272.42	["/static/images/2fc04ca5-8e76-4d64-b437-47637cc616ae.jpg", "/static/images/289518b4-a4e4-47f2-94d2-9140b7b039ae.jpg", "/static/images/37a9b673-bf9e-4c5e-8d18-4adf939409e5.jpg", "/static/images/87b8babd-9d65-4ac9-b3b6-ba68d69a595c.jpg", "/static/images/e54253ad-f9d8-4862-bc28-2516ff27a246.jpg"]	Officia commodi a perferendis est corrupti tempore enim nisi earum.\nTotam quibusdam odio rerum consectetur facilis fugiat natus.\nCommodi quis animi recusandae pariatur quia.	07:00:00	22:00:00	+394108858621	Odorico_Traverso@yahoo.it
108	219	4	127.00	Ivica Sudnik	2	Fulgenzio Zappacosta	https://abandoned-android.net	320.98	["/static/images/831a8347-cb69-4cd2-909e-73c60f704db3.jpg", "/static/images/53e865c4-5f9e-48d4-ae04-4f8c318d118b.jpg", "/static/images/d6fa4298-e6b4-4953-a97b-c3b291e7638d.jpg", "/static/images/2e6cc878-045d-4a1d-9aee-357bdfab6d93.jpg", "/static/images/ea248ca8-a1a6-4ded-b6c2-4e83512957a6.jpg"]	Dignissimos ea facere laboriosam optio odio.\nQuia commodi ipsum nostrum iste omnis ab sit nihil.\nOdit ratione esse odit eaque cum quisquam qui incidunt.\nExpedita eius modi saepe.\nSapiente voluptate fugiat repellendus.	04:00:00	18:00:00	+396816250544	Valter_Paris@hotmail.com
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
1	220	72	2	Italy	Foggia		Quarto Batilda calabro
2	221	169	2	Italy	Parma		Borgo Ranolfo
3	222	299	2	Italy	Firenze		Osmondo laziale
4	223	119	2	Italy	Prato		Borgo Calogero del friuli
5	224	39	2	Italy	Siracusa		Borgo Cristiano
6	225	63	2	Italy	Ancona		Quarto Luana
7	226	54	2	Italy	Cuneo		Pircher a mare
8	227	166	2	Italy	Siena		Giaccio sardo
9	228	155	2	Italy	Trapani		Butera ligure
10	229	98	2	Italy	Imperia		Borgo Ulfo nell'emilia
11	230	70	2	Italy	Asti		Quarto Gionata
12	231	154	2	Italy	Torino		Borgo Elisa lido
13	232	38	2	Italy	Pesaro e Urbino		Cerise sardo
14	233	64	2	Italy	Modena		Volpe del friuli
15	234	31	2	Italy	Sassari		Settimo Pammachio del friuli
16	235	149	2	Italy	Como		Caserta nell'emilia
17	236	64	2	Italy	Vibo Valentia		Borgo Efisio
18	237	173	2	Italy	Barletta-Andria-Trani		Sesto Bastiano salentino
19	238	73	2	Italy	Brescia		Caiazza laziale
20	239	144	2	Italy	Olbia-Tempio		Albano calabro
21	240	113	2	Italy	Torino		Quarto Maurizio
22	241	287	2	Italy	Pistoia		Sesto Ninfa
23	242	6	2	Italy	Forlì-Cesena		Trasea laziale
24	243	39	2	Italy	Modena		Borgo Ottilia
25	244	197	2	Italy	Pavia		Borgo Floriana
26	245	158	2	Italy	Medio Campidano		Sacchetti del friuli
27	246	274	2	Italy	Bari		Settimo Fiorenziano
28	247	248	2	Italy	Brindisi		Antonella laziale
29	248	95	2	Italy	Pordenone		Sesto Platone nell'emilia
30	249	31	2	Italy	Aosta		Vittore umbro
31	250	148	2	Italy	Mantova		Borgo Plutarco
32	251	162	2	Italy	Agrigento		San Nestore terme
33	252	83	2	Italy	Sondrio		Borgo Vincenzo umbro
34	253	5	2	Italy	Genova		Quarto Goffredo
35	254	92	2	Italy	Potenza		Settimo Smeralda
36	255	208	2	Italy	Salerno		Sesto Pancrazio terme
37	256	260	2	Italy	Agrigento		Silvestro veneto
38	257	248	2	Italy	Siena		Benvenuti ligure
39	258	270	2	Italy	Piacenza		Settimo Flaviana calabro
40	259	197	2	Italy	Vicenza		Asterio a mare
41	260	20	2	Italy	Belluno		Fernanda lido
42	261	275	2	Italy	Vibo Valentia		Riccio sardo
43	262	56	2	Italy	Medio Campidano		Delle Monache del friuli
44	263	217	2	Italy	Vicenza		Valente veneto
45	264	240	2	Italy	Biella		Eva veneto
46	265	191	2	Italy	Messina		Quarto Veronica
47	266	90	2	Italy	Pisa		Fabiano lido
48	267	117	2	Italy	Verona		Onesto ligure
49	268	273	2	Italy	Isernia		Bianchini laziale
50	269	211	2	Italy	Teramo		Borgo Ettore del friuli
51	270	201	2	Italy	Oristano		Settimo Solocone
52	271	11	2	Italy	Matera		Quarto Guenda terme
53	272	126	2	Italy	L'Aquila		Veridiana del friuli
54	273	8	2	Italy	Cosenza		Gustavo ligure
55	274	128	2	Italy	Varese		Borgo Alcibiade
56	275	227	2	Italy	Padova		Borgo Bonifacio veneto
57	276	208	2	Italy	Salerno		Quarto Gilberto lido
58	277	251	2	Italy	Fermo		Settimo Prudenzia
59	278	74	2	Italy	Perugia		Lelia umbro
60	279	59	2	Italy	Siena		Sesto Scolastica
61	280	137	2	Italy	Bologna		Leo veneto
62	281	283	2	Italy	Mantova		Lori lido
63	282	120	2	Italy	Pesaro e Urbino		Quarto Iolanda nell'emilia
64	283	64	2	Italy	Pisa		Gianmarco nell'emilia
65	284	131	2	Italy	Rovigo		Quarto Debora
66	285	143	2	Italy	Bolzano		Amintore a mare
67	286	135	2	Italy	Parma		Biancheri ligure
68	287	263	2	Italy	Pavia		Emiliana ligure
69	288	48	2	Italy	Ancona		Matranga laziale
70	289	15	2	Italy	L'Aquila		Borgo Fidenziano
71	290	47	2	Italy	Reggio Emilia		Anselmo lido
72	291	263	2	Italy	Lodi		San Uriele terme
73	292	265	2	Italy	La Spezia		Selvaggia umbro
74	293	74	2	Italy	Potenza		Ampelio del friuli
75	294	93	2	Italy	Medio Campidano		Borgo Godeberta umbro
76	295	146	2	Italy	Firenze		San Aleardo nell'emilia
77	296	27	2	Italy	Sondrio		Quarto Matroniano
78	297	72	2	Italy	Campobasso		Cesare salentino
79	298	176	2	Italy	Piacenza		Borgo Uberto del friuli
80	299	94	2	Italy	Isernia		San Gionata
81	300	114	2	Italy	Arezzo		Borgo Fiore
82	301	269	2	Italy	L'Aquila		Fernando del friuli
83	302	96	2	Italy	Barletta-Andria-Trani		Politi a mare
84	303	170	2	Italy	Brescia		Amatore ligure
85	304	228	2	Italy	Chieti		Di Francesco salentino
86	305	222	2	Italy	Ragusa		Quarto Nadia del friuli
87	306	300	2	Italy	Piacenza		San Maura terme
88	307	270	2	Italy	Vicenza		Quarto Fosco
89	308	75	2	Italy	La Spezia		Sesto Matroniano
90	309	116	2	Italy	Udine		Frigerio salentino
91	310	70	2	Italy	Brindisi		Pellegrino lido
92	311	203	2	Italy	Aosta		Borgo Clodomiro
93	312	28	2	Italy	Carbonia-Iglesias		San Tazio salentino
94	313	72	2	Italy	Piacenza		Torresi terme
95	314	150	2	Italy	Bari		Quarto Alessio ligure
96	315	160	2	Italy	Chieti		Omar a mare
97	316	137	2	Italy	Trento		Sesto Orsola
98	317	26	2	Italy	Teramo		Desdemona terme
99	318	291	2	Italy	Lecco		Settimo Rosalinda umbro
100	319	208	2	Italy	Pistoia		Sesto Piergiorgio salentino
101	320	110	2	Italy	Massa-Carrara		Roma
102	321	258	2	Italy	Reggio Calabria		Narciso laziale
103	322	180	2	Italy	Taranto		Peleo calabro
104	323	26	2	Italy	Verona		Sesto Rolfo
105	324	187	2	Italy	Caltanissetta		Sesto Graziano salentino
106	325	178	2	Italy	Lecce		Settimo Costante del friuli
107	326	190	2	Italy	L'Aquila		Sesto Bardomiano
108	327	185	2	Italy	Bolzano		Lai umbro
109	328	63	2	Italy	Terni		Settimo Almiro veneto
110	329	81	2	Italy	Ancona		Borgo Stiriaco
111	330	37	2	Italy	Cagliari		San Radolfo sardo
112	331	45	2	Italy	Forlì-Cesena		Sesto Ivan
113	332	89	2	Italy	Roma		Di Lecce lido
114	333	143	2	Italy	Vibo Valentia		Sibilla terme
115	334	104	2	Italy	Pistoia		Rocco calabro
116	335	74	2	Italy	Carbonia-Iglesias		Murgia salentino
117	336	130	2	Italy	Fermo		San Fabio calabro
118	337	224	2	Italy	Venezia		San Luminosa terme
119	338	233	2	Italy	Caltanissetta		Sesto Arduino
120	339	69	2	Italy	Fermo		Auro terme
121	340	136	2	Italy	Mantova		Quarto Vivaldo laziale
122	341	266	2	Italy	Macerata		Sesto Luciana umbro
123	342	119	2	Italy	Messina		Borgo Amando
124	343	149	2	Italy	Pescara		Gavino laziale
125	344	230	2	Italy	Pordenone		Settimo Geminiano lido
126	345	66	2	Italy	Rieti		Quarto Nina terme
127	346	1	2	Italy	Monza e della Brianza		San Adelfo sardo
128	347	35	2	Italy	Cagliari		Di Marzio nell'emilia
129	348	231	2	Italy	Lodi		Adolfo a mare
130	349	1	2	Italy	Padova		Settimo Addolorata
131	350	1	2	Italy	Arezzo		Settimo Telchide
132	351	26	2	Italy	Siena		Romolo salentino
133	352	104	2	Italy	Gorizia		Di Giovanni sardo
134	353	176	2	Italy	Messina		Bellomo lido
135	354	54	2	Italy	Potenza		Lelia ligure
136	355	100	2	Italy	Massa-Carrara		Settimo Girardo lido
137	356	1	2	Italy	Macerata		San Orlando sardo
138	357	1	2	Italy	Como		Quarto Aleramo umbro
139	358	103	2	Italy	Brescia		Sesto Auro terme
140	359	1	2	Italy	Bolzano		San Artemisa
141	360	97	2	Italy	Perugia		Luchetti sardo
142	361	37	2	Italy	Avellino		Quarto Ulfa
143	362	128	2	Italy	Siena		Gerasimo sardo
144	363	118	2	Italy	Crotone		Ausiliatrice salentino
145	364	45	2	Italy	Brescia		Quarto Callisto nell'emilia
146	365	126	2	Italy	Vibo Valentia		Cecchetti terme
147	366	246	2	Italy	Grosseto		Borgo Platone
148	367	153	2	Italy	Trento		De Marco laziale
149	368	168	2	Italy	Teramo		Carloni del friuli
150	369	212	2	Italy	Potenza		Settimo Prudenzio sardo
151	370	277	2	Italy	Fermo		Settimo Emmerico laziale
152	371	48	2	Italy	Crotone		Settimo Luminosa
153	372	208	2	Italy	Siracusa		Litterio umbro
154	373	139	2	Italy	Palermo		Settimo Eufebio umbro
155	374	155	2	Italy	Trieste		Quarto Consolata sardo
156	375	48	2	Italy	Brescia		Borgo Eleuterio
157	376	191	2	Italy	Verona		Cleopatra nell'emilia
158	377	77	2	Italy	Brescia		San Carlo
159	378	260	2	Italy	La Spezia		Quarto Porzia
160	379	272	2	Italy	Olbia-Tempio		Baldassarre ligure
161	380	179	2	Italy	Milano		Quarto Candida terme
162	381	124	2	Italy	Nuoro		Borgo Furio
163	382	78	2	Italy	Foggia		Miglio lido
164	383	138	2	Italy	Massa-Carrara		Coreno salentino
165	384	223	2	Italy	Messina		Tacconi del friuli
166	385	30	2	Italy	Forlì-Cesena		San Edvige umbro
167	386	226	2	Italy	Prato		Sesto Casto
168	387	270	2	Italy	Pavia		San Zabina veneto
169	388	246	2	Italy	Prato		Lo Bianco calabro
170	389	180	2	Italy	Enna		Settimo Rufo
171	390	279	2	Italy	Brescia		Pani laziale
172	391	297	2	Italy	Aosta		Borgo Gianpaolo
173	392	271	2	Italy	Modena		San Sidonio
174	393	174	2	Italy	Ferrara		San Virginio del friuli
175	394	42	2	Italy	Imperia		Indro sardo
176	395	95	2	Italy	Catanzaro		Fortugno ligure
177	396	111	2	Italy	Pavia		Preziosi lido
178	397	192	2	Italy	Pordenone		San Mario
179	398	176	2	Italy	Brindisi		Quarto Pacomio laziale
180	399	63	2	Italy	Salerno		Cusumano lido
181	400	294	2	Italy	Sondrio		Quarto Barbara
182	401	275	2	Italy	Avellino		Gigliola lido
183	402	6	2	Italy	Prato		Volpe nell'emilia
184	403	184	2	Italy	Treviso		Lendinara
185	404	75	2	Italy	Lucca		San Martina veneto
186	405	295	2	Italy	Lodi		Napoli
187	406	102	2	Italy	Lucca		Settimo Sofronia calabro
188	407	115	2	Italy	Forlì-Cesena		Venerando calabro
189	408	230	2	Italy	Roma		Quarto Bonaventura sardo
190	409	273	2	Italy	Forlì-Cesena		San Manilio del friuli
191	410	47	2	Italy	Fermo		Grassi del friuli
192	411	209	2	Italy	Arezzo		Marini salentino
193	412	223	2	Italy	Verona		Sesto Annabella laziale
194	413	244	2	Italy	Vicenza		San Zenone
195	414	243	2	Italy	Ferrara		Lazzari del friuli
196	415	40	2	Italy	Enna		Paterniano calabro
197	416	243	2	Italy	Palermo		Leonida nell'emilia
198	417	217	2	Italy	Trieste		Glenda lido
199	418	251	2	Italy	Olbia-Tempio		San Sviturno
200	419	126	2	Italy	Savona		Remigio umbro
201	420	118	2	Italy	Savona		Guida sardo
202	421	252	2	Italy	Crotone		Sesto Furseo
203	422	410	2	Italy	Enna		Ulfo terme
204	423	212	2	Italy	Vicenza		Settimo Flaviana umbro
205	424	84	2	Italy	Cuneo		Sesto Scolastica laziale
206	425	39	2	Italy	Aosta		San Iginio terme
207	426	119	2	Italy	Milano		Pisciotta veneto
208	427	227	2	Italy	Bolzano		Serapione sardo
209	428	121	2	Italy	Cremona		Sesto Porziano lido
210	429	110	2	Italy	Napoli		Schiavo calabro
211	430	269	2	Italy	Lecco		Sesto Lapo ligure
212	431	109	2	Italy	Crotone		Manca a mare
213	432	9	2	Italy	Torino		Melchiorre veneto
214	433	215	2	Italy	Sondrio		Mirella sardo
215	434	194	2	Italy	Perugia		Ghilardi terme
216	435	139	2	Italy	Messina		Sesto Alvise veneto
217	436	213	2	Italy	Roma		Cabras a mare
218	437	286	2	Italy	Sassari		San Fiorenza laziale
219	438	157	2	Italy	La Spezia		Borgo Demetrio ligure
220	439	84	2	Italy	Rimini		Michelucci del friuli
221	440	297	2	Italy	Carbonia-Iglesias		Gualtieri laziale
222	441	3	2	Italy	Brindisi		Settimo Samanta sardo
223	442	214	2	Italy	Piacenza		Settimo Ampelio
224	443	233	2	Italy	Aosta		Di Maro salentino
225	444	161	2	Italy	Lecco		Godeberta ligure
226	445	166	2	Italy	Catania		Sesto Amerigo
227	446	220	2	Italy	Trento		San Catullo
228	447	253	2	Italy	Vibo Valentia		Dolce ligure
229	448	250	2	Italy	Agrigento		Edda salentino
230	449	104	2	Italy	Pavia		Simoni lido
231	450	269	2	Italy	Catanzaro		Sesto Camilla
232	451	212	2	Italy	Pisa		Demurtas sardo
233	452	298	2	Italy	Vicenza		Alamanno a mare
234	453	243	2	Italy	Pordenone		Diana umbro
235	454	29	2	Italy	Enna		Sesto Nina umbro
236	455	235	2	Italy	Savona		Sesto Cristoforo ligure
237	456	143	2	Italy	Firenze		Barbato nell'emilia
238	457	61	2	Italy	Milano		Olivi umbro
239	458	74	2	Italy	Messina		Quarto Cristaldo
240	459	233	2	Italy	Enna		San Alcide
241	460	184	2	Italy	Caltanissetta		Oliviero salentino
242	461	77	2	Italy	Cuneo		Quarto Venusto umbro
243	462	80	2	Italy	Verona		Boni veneto
244	463	183	2	Italy	Macerata		Quarto Desdemona veneto
245	464	101	2	Italy	Olbia-Tempio		Brigandì sardo
246	465	237	2	Italy	Treviso		Sesto Evangelina
247	466	139	2	Italy	Benevento		Sesto Giustiniano umbro
248	467	114	2	Italy	Sondrio		Saffiro a mare
249	468	286	2	Italy	Reggio Emilia		Settimo Giusta
250	469	9	2	Italy	Ancona		Gianotti sardo
251	470	275	2	Italy	Pavia		Egisto nell'emilia
252	471	48	2	Italy	Ogliastra		Dafne salentino
253	472	124	2	Italy	Catania		San Riccarda salentino
254	473	231	2	Italy	Venezia		Quarto Icilio
255	474	263	2	Italy	Biella		San Elita a mare
256	475	238	2	Italy	Barletta-Andria-Trani		Sesto Fabiana
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address, altitude) FROM stdin;
1	0	0101000020E610000043D95E8288A91C40720950EB278D4640	Start Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
2	0	0101000020E610000051A7B8816D921C408D966B20C98C4640	End Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
3	0	0101000020E6100000C668CC0D4EA81C40DA8DB03B2C8D4640	Ref Point 1		1256.85
4	0	0101000020E6100000116FE90D01A21C4022DFF1622B8D4640	Ref Point 2		1283.61
5	0	0101000020E61000004337FB03E5161B401CEBE2361A844640	Start Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
6	0	0101000020E61000001092054CE0161B401FD8F15F20844640	End Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
7	0	0101000020E6100000910F7A36ABCE1C4029AF95D05D4C4640	Start Point	Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia	\N
8	0	0101000020E6100000FC8EE1B19FB51C40B0FECF61BE4E4640	End Point	Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia	\N
9	0	0101000020E6100000000060A24D751C40000028D7DB594640	Start Point	Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia	\N
10	0	0101000020E61000000000A08E3B6A1C400000D8486C5C4640	End Point	Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia	\N
11	0	0101000020E6100000D218ADA3AA112140B7291E17D5124740	Start Point	Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia	\N
12	0	0101000020E61000001764CBF2751121406AFAEC80EB144740	End Point	Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia	\N
13	0	0101000020E610000000004078111A1C400000981E08854640	Start Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
14	0	0101000020E61000000000A0281F1A1C400000E05411854640	End Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
15	0	0101000020E610000000004078111A1C400000981E08854640	Start Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
16	0	0101000020E61000000000A0281F1A1C400000E05411854640	End Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
17	0	0101000020E610000058CB9D9960C81B408731E9EFA59C4640	Start Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
18	0	0101000020E61000003BE0BA6246C81B401E34BBEEAD9C4640	End Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
19	0	0101000020E61000007EE4D6A4DBC21B40147AFD497C9C4640	fountain		2027.00
20	0	0101000020E6100000B7B8C667B2BF1B4090A4A487A19B4640	Peak		2131.00
21	0	0101000020E6100000E449D23593FF1A4008B0C8AF1F784640	Start Point	Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia	\N
22	0	0101000020E6100000E449D23593FF1A4008B0C8AF1F784640	End Point	Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia	\N
23	0	0101000020E6100000010060133FE51C400000DC629AA64640	Start Point	Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia	\N
24	0	0101000020E61000000100E07E80F41C400000C0086CA54640	End Point	Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia	\N
25	0	0101000020E61000000000A0E235A31C40000090BAAD5A4640	Start Point	Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia	\N
26	0	0101000020E61000000000A03601A21C40000078DBA45A4640	End Point	Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia	\N
27	0	0101000020E61000000000601346EE1B4000006C0D81494640	Start Point	SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia	\N
28	0	0101000020E6100000000000063BEE1B4000001C7B81494640	End Point	SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia	\N
29	0	0101000020E6100000000020F7999B1C40000018F79E594640	Start Point	Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
30	0	0101000020E61000000000803E6C7C1C400000004B28584640	End Point	Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
31	0	0101000020E610000001002004C9F31E400000609288234640	Start Point	Pigna - Gardiola, Chiusa di Pesio, Cuneo, Piemonte, 12088, Italia	\N
32	0	0101000020E6100000000000DC44CF1E400000B4502D214640	End Point		\N
33	0	0101000020E61000002F3196E997781C408F8D40BCAE594640	Start Point	Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
34	0	0101000020E61000009C8A54185B781C4057B08D78B2594640	End Point	Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
35	0	0101000020E61000000000209E8E4B1C4000003C6BAE844640	Start Point	Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia	\N
36	0	0101000020E6100000000080AFFC7A1C4000004CCD1C864640	End Point	Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia	\N
37	0	0101000020E6100000000000A020B91C40000074E3C0494640	Start Point	Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia	\N
38	0	0101000020E61000000000C0CE5A9F1C400000B06F46474640	End Point	Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia	\N
39	0	0101000020E610000000000030C0F21C400000005015934640	Start Point	Alpe Tulivit, Condove, Torino, Piemonte, Italia	\N
40	0	0101000020E61000000000C02BE9E01C400000442ED1964640	End Point	Alpe Tulivit, Condove, Torino, Piemonte, Italia	\N
41	0	0101000020E61000000000E04399051F40000078D59A1F4640	Start Point	Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia	\N
42	0	0101000020E61000000000A0B2D4041F400000A07A911F4640	End Point	Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia	\N
43	0	0101000020E610000000002073E0601C4000001C93C2594640	Start Point	Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia	\N
44	0	0101000020E61000000000A01680701C400000C08D37554640	End Point	Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia	\N
45	0	0101000020E61000000000C09D43D520400000CC2FB7354740	Start Point	Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia	\N
46	0	0101000020E61000000000C09D43D520400000CC2FB7354740	End Point	Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia	\N
47	0	0101000020E6100000E4BD6A65C2D720401A506F46CD114740	Start Point	Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia	\N
48	0	0101000020E61000005665DF15C1D72040C6C1A563CE114740	End Point	Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia	\N
49	0	0101000020E61000005F9A22C0E96520406C76A4FACE554640	Start Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
50	0	0101000020E61000002368CC24EA652040CC7EDDE9CE554640	End Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
51	0	0101000020E61000006B662D05A46D20401557957D57564640	Ref Point 1		482.53
52	0	0101000020E610000024D236FE44652040813D26529A554640	Ref Point 2		242.59
53	0	0101000020E6100000A06F0B96EA221D4008E6E8F17B7B4640	Start Point	Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia	\N
54	0	0101000020E61000006DE7FBA9F1221D40EF552B137E7B4640	End Point	Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia	\N
55	0	0101000020E61000009F02603C83762540D61EF64201F14640	Start Point	Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
56	0	0101000020E610000088F19A5775762540910E0F61FCF04640	End Point	Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
57	0	0101000020E6100000F435CB65A343274097530262122E4640	Start Point	5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia	\N
58	0	0101000020E61000006BD44334BA43274097530262122E4640	End Point	5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia	\N
59	0	0101000020E6100000EAE923F0877F2540EE7C3F355EE04640	Start Point	Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia	\N
60	0	0101000020E610000053CF8250DE7F254040A19E3E02E14640	End Point	Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia	\N
61	0	0101000020E610000033FE7DC6853B274059349D9D0C264640	Start Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
62	0	0101000020E61000005859DB148F3B2740001DE6CB0B264640	End Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
63	0	0101000020E610000033FE7DC6853B274059349D9D0C264640	Start Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
64	0	0101000020E61000005859DB148F3B2740001DE6CB0B264640	End Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
65	0	0101000020E6100000E82E89B3223A254036CB65A373AC4640	Start Point	Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia	\N
66	0	0101000020E61000008C9DF0129C3A2540486AA16472AC4640	End Point	Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia	\N
67	0	0101000020E610000088DA368C82402540AC02B5183CAC4640	Ref Point 1		130.12
68	0	0101000020E6100000A06B5F402F44254016C1FF56B2AB4640	Ref Point 2		139.74
69	0	0101000020E6100000527FBDC2824B2540151C5E1091AA4640	Fontain		107.32
70	0	0101000020E61000001C98DC28B2361C4032FFE89B34894640	Start Point	Cima Ciantiplagna, Strada militare del Colle dell'Assietta, Bergerie dell'Assietta, Usseaux, Torino, Piemonte, Italia	\N
71	0	0101000020E6100000EE5C18E9450D1C402FFB75A73B894640	End Point	Cima Ciantiplagna, Strada militare del Colle dell'Assietta, Bergerie dell'Assietta, Usseaux, Torino, Piemonte, Italia	\N
72	0	0101000020E6100000A0DCB6EF518725409E7E501729E44640	Start Point	Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia	\N
73	0	0101000020E610000055DD239BAB86254016342DB132E44640	End Point	Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia	\N
74	0	0101000020E6100000C3F5285C8FE21F408C9FC6BDF9894640	Start Point	Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia	\N
75	0	0101000020E610000001F8A75489E21F40F030ED9BFB894640	End Point	Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia	\N
76	0	0101000020E6100000B282DF86187F20400B47904AB1FF4640	Start Point	Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia	\N
77	0	0101000020E610000012842BA0508720400F48C2BE9D004740	End Point	Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia	\N
78	0	0101000020E6100000EAE8B81AD9E520408813984EEBFA4640	Start Point	Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia	\N
79	0	0101000020E6100000EAE8B81AD9E520408813984EEBFA4640	End Point	Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia	\N
80	0	0101000020E61000006EFC89CA86A52040D87DC7F0D87D4640	Start Point	Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia	\N
81	0	0101000020E61000009E0B23BDA8A52040B1A371A8DF7D4640	End Point	Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia	\N
82	0	0101000020E61000009F3E027FF83920409E245D33F9804640	Start Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
83	0	0101000020E610000099F56228273A20408DEDB5A0F7804640	End Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
84	0	0101000020E6100000880E81238136264090847D3B89844640	Start Point	Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia	\N
85	0	0101000020E6100000B6132521913626406AFB57569A844640	End Point	Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia	\N
86	0	0101000020E61000007A17EFC7ED37264008C89750C1854640	Ref Point 1		22.75
87	0	0101000020E61000009AB0FD648C4F26405C7171546E844640	Ref Point 2		35.55
88	0	0101000020E61000001899805F23F91C402A38BC20227B4640	Start Point	Pralamar, Pinasca, Torino, Piemonte, 10063, Italia	\N
89	0	0101000020E610000001344A97FEF51C40BB438A01127D4640	End Point	Pralamar, Pinasca, Torino, Piemonte, 10063, Italia	\N
90	0	0101000020E6100000A5660FB402431D4025E82FF488754640	Start Point	Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia	\N
91	0	0101000020E61000008D093197543D1D405E6919A9F7764640	End Point	Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia	\N
92	0	0101000020E6100000E14389963C762540E55FCB2BD7F14640	Start Point	Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
93	0	0101000020E6100000C2DF2F664B7625408C14CAC2D7F14640	End Point	Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
94	0	0101000020E6100000768D96033D14284038BA4A77D7D54540	Start Point	Via Poggiolino delle Viole, Castellare, Pieve Santo Stefano, Arezzo, Toscana, 52036, Italia	\N
95	0	0101000020E610000058E6ADBA0E4D28404546072461D34540	End Point	Bike Help, Pian della Capanna, Pieve Santo Stefano, Arezzo, Toscana, Italia	\N
96	0	0101000020E6100000C1CAA145B60320407715527E52B94640	Start Point	26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia	\N
97	0	0101000020E6100000A4C2D84290032040E8BCC62E51B94640	End Point	26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia	\N
98	0	0101000020E61000003B54539275B82840BF7D1D3867164740	Start Point	Municipio, Via Roma, Torres, Tignes, Pieve d'Alpago, Alpago, Belluno, Veneto, 32010, Italia	\N
99	0	0101000020E6100000D6C8AEB48CB42840F51263997E154740	End Point	Municipio, Via Roma, Torres, Tignes, Pieve d'Alpago, Alpago, Belluno, Veneto, 32010, Italia	\N
100	0	0101000020E61000009296CADB11862840B91803EB383C4740	Start Point	Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia	\N
101	0	0101000020E6100000F94D61A582BA28401363997E89364740	End Point	Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia	\N
102	0	0101000020E6100000B0389CF9D5B4254010E9B7AF03F14640	Start Point	Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
170	0	0101000020E610000052E2299ABDFA2840518B1C7D27114740	Rifugio Semenza	Tambre, Veneto, Italy	\N
103	0	0101000020E61000009414580053762540A04FE449D2F14640	End Point	Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
104	0	0101000020E6100000B0389CF9D5B4254010E9B7AF03F14640	Peak		67.09
105	0	0101000020E6100000A9C0C936708725400936AE7FD7EF4640	Lake		712.07
106	0	0101000020E6100000D576137CD3742640A9BF5E61C1A34540	Start Point	4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia	\N
107	0	0101000020E61000001A19E42EC274264009FCE1E7BFA34540	End Point	4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia	\N
108	0	0101000020E61000003D98141F9F201C409A5FCD01827B4640	Start Point	Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia	\N
109	0	0101000020E6100000CC7A319413FD1B40BD361B2B317D4640	End Point	Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia	\N
110	0	0101000020E61000003BE466B801472840A2427573F12B4640	Start Point	Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia	\N
111	0	0101000020E610000029CFBC1C76472840EA3F6B7EFC2B4640	End Point	Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia	\N
112	0	0101000020E61000002D64979723B62440C66F2527958D4740	Edmund-Graf-Hütte	6574 Pettneu am Arlberg, Tyrol, Austria	\N
113	0	0101000020E6100000455BF9D0380E2A4056DBD4F478794740	Dr.Hernaus-Stöckl	9020 Klagenfurt, Kärnten, Austria	\N
114	0	0101000020E61000003AD4CD22968A2D406DAF4FF575F14740	Amstettner Hütte	3340 Waidhofen an der Ybbs, Niederösterreich, Austria	\N
115	0	0101000020E61000003470C88518362B404F23C0A11DEA4740	Hochleckenhaus	4853 Steinbach am Attersee, Oberösterreich, Austria	\N
116	0	0101000020E6100000745CA7EA5C3230400E95C9F10B114840	Kampthalerhütte	2384 Breitenfurt bei Wien, Niederösterreich, Austria	\N
117	0	0101000020E610000059E5350827672B402FB2862AC2D34740	Lambacher Hütte	4822 Bad Goisern, Oberösterreich, Austria	\N
118	0	0101000020E610000019FDD2643FA62340662869A087B24740	Lustenauer Hütte	6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria	\N
119	0	0101000020E610000036849931B0F52A4014BD78F039C44740	Gablonzer Hütte	4825 Gosau-Hintertal, Oberösterreich, Austria	\N
120	0	0101000020E6100000202F5A3629BF3740D489BAC5B2144340	Katafygio «Flampouri»	136 72 Acharnes, Attica region, Greece	\N
121	0	0101000020E6100000103E4BA24D3F2B40F731169C1AC04740	Simonyhütte	4830 Hallstatt, Oberösterreich, Austria	\N
122	0	0101000020E610000033190145D5182740BF9048EBDFA04740	Vinzenz-Tollinger-Hütte	6060 Hall in Tirol, Tyrol, Austria	\N
123	0	0101000020E61000001F1E0B5901B82E4091BFCBF1EAB34740	Ottokar-Kernstock-Haus	8600 Bruck an der Mur, Steiermark, Austria	\N
124	0	0101000020E610000018E4FB977DBF2A40D6A3B4422D754740	Reisseckhütte	9814 Mühldorf, Mölltal, Kärnten, Austria	\N
125	0	0101000020E61000007B116DC7D4A52540C0401020436D4740	Vernagthütte	Austria	\N
126	0	0101000020E6100000286211C30EF323407EC9C6832D884740	Wormser Hütte	Austria	\N
127	0	0101000020E6100000999CDA19A60E24406CD097DEFEA04740	Biberacher Hütte	Austria	\N
128	0	0101000020E610000007BC276AC4133740DDF934DDA1A84440	Katafygio «1777»	620 55 Kerkini, Central Macedonia region, Greece	\N
129	0	0101000020E6100000D5AF743E3C0B2A40E6E786A6EC704840	Hochwaldhütte	Germany	\N
130	0	0101000020E6100000C2FBAA5CA8EC19408FC536A968544940	Kölner Eifelhütte	Germany	\N
131	0	0101000020E6100000323CF6B358D223401763601DC7794740	Madrisahütte	Austria	\N
132	0	0101000020E6100000313F373465472640CDC98B4CC07F4740	Dresdner Hütte	Austria	\N
133	0	0101000020E6100000CDCCCCCCCC6C24403E07962364A84740	Fiderepasshütte	Germany	\N
134	0	0101000020E6100000B727486C77172440A9DDAF027C9B4740	Göppinger Hütte	Austria	\N
135	0	0101000020E6100000A379008BFC622340C7629B54348A4740	Oberzalimhütte	Austria	\N
136	0	0101000020E610000013B70A62A0932740B3B45373B99D4740	Rastkogelhütte	Austria	\N
137	0	0101000020E61000009D2D20B41E0E2440D54F49E70DC24740	Ansbacher Skihütte im Allgäu	Germany	\N
138	0	0101000020E610000009E066F16249244097E13FDD408F4740	Kaltenberghütte	Austria	\N
139	0	0101000020E61000000AD7A3703D0A2640E277D32D3B944740	Schweinfurter Hütte	Austria	\N
140	0	0101000020E61000006DC438245A213640DA172BC5E9574340	Katafygio «Vardousion»	330 53 Delphi, Central Greece region, Greece	\N
141	0	0101000020E6100000630F270F8F472D40336D62F5852D4740	Kocbekov dom na Korošici	3334 Luče, Mozirje, Slovenia	\N
142	0	0101000020E6100000D1F5D08072062D40D25C9F20CE114740	Planinski dom Rašiške cete na Rašici	1211 Ljubljana, Šmartno, Slovenia	\N
143	0	0101000020E6100000F70F966F85592C40971550C935374740	Prešernova koca na Stolu	4274 Žirovnica, Slovenia	\N
144	0	0101000020E6100000AA5C8F5FCB372E408E6CD71919184740	Planinski dom na Mrzlici	3302 Griže, Slovenia	\N
145	0	0101000020E6100000651A4D2EC6802C40577A6D3656FC4640	Koca na Planini nad Vrhniko	1360 Vrhnika, Slovenia	\N
146	0	0101000020E6100000245DF94DDD322C4077DAB7E6D0144740	Zavetišce gorske straže na Jelencih	0, -, Slovenia	\N
147	0	0101000020E6100000313F3734656F2E406F7F2E1A32264740	Planinski dom na Gori	Šentjungert, 3310 Žalec, Slovenia	\N
148	0	0101000020E610000098F2E7FC90A22B40C7CBA2C928274740	Bregarjevo zavetišce na planini Viševnik	4265 Bohinjsko jezero, Slovenia	\N
149	0	0101000020E610000091860959CC862B401635F33FD4244740	Koca pod Bogatinom	4265 Bohinjsko jezero, Slovenia	\N
150	0	0101000020E6100000678B3942E5992B40007F639573334740	Pogacnikov dom na Kriških podih	5232 Soca, Slovenia	\N
151	0	0101000020E610000008F580BBE4CC2D402A9C0F95E7344740	Dom na Smrekovcu	3325 Šoštanj, Slovenia	\N
152	0	0101000020E610000073F6CE68AB32194060E811A3E77C4640	Refuge Du Chatelleret	38520 Saint Christophe En Oisans, Isère, France	\N
153	0	0101000020E610000084622B685AF218408177F2E9B16B4640	Refuge De Chalance	5800 La Chapelle En Valgaudemar, Hautes-Alpes, France	\N
154	0	0101000020E6100000963D096CCE711940AE7FD767CE6A4640	Refuge Des Bans	5290 Vallouise, Hautes-Alpes, France	\N
155	0	0101000020E6100000DEAB5626FC52DBBFAED689CBF16A4540	Refuge De Pombie	65400 Laruns, Pyrénées-Atlantiques, France	\N
156	0	0101000020E6100000A69C2FF65E7CD2BFA9F92AF9D86D4540	Refuge De Larribet	65400 Arrens, Marsous, Hautes-Pyrénées, France	\N
157	0	0101000020E61000009CA6CF0EB84E1B401232906797C34640	Refuge Du Mont Pourri	73210 Peisey Nancroix, Savoie, France	\N
158	0	0101000020E6100000C712D6C6D8E91A40BF81C98D222D4740	Refuge De La Dent D?Oche	74500 Bernex, Haute-Savoie, France	\N
159	0	0101000020E6100000BEBDCA2243F820405620D41E27544740	Bergseehütte SAC	Uri, Switzerland	\N
160	0	0101000020E6100000CDD5732CA96D1E40F591820D5C054740	Bivouac au Col de la Dent Blanche CAS	Wallis, Switzerland	\N
161	0	0101000020E610000060F1FE571F0C2140D6BA5B328C564740	Salbitschijenbiwak SAC	Uri, Switzerland	\N
162	0	0101000020E610000084EAC5BE53052140F224048A5C664740	Spannorthütte SAC	Uri, Switzerland	\N
163	0	0101000020E6100000827FB24EBCB71E406113E452EB0C4740	Cabane Arpitettaz CAS	Wallis, Switzerland	\N
164	0	0101000020E61000008A75AA7CCF48E4BF588BF447BD614540	Refugio De Lizara	22730, Aragón, Spain	\N
165	0	0101000020E6100000AE56C01909F8E43F58DB5E1CA6064540	Albergue De Montfalcó	22585 Tolva, Aragón, Spain	\N
166	0	0101000020E61000000A4CFFBF1E610AC08B780953B6904240	El Molonillo/Peña Partida	18160 Güejar Sierra, Andalucía, Spain	\N
167	0	0101000020E610000029110100A92D0AC0F39F054F27844240	La Campiñuela	18417 Trévelez, Andalucía, Spain	\N
168	0	0101000020E61000008E79782A3BCC3440BEAE152301FF4440	Titov Vrv	Tetovo, Municipality of Tetovo, North Macedonia	\N
169	0	0101000020E6100000A2EC2DE57C212B40C7F143A5113D4540	Rifugio Franchetti	Pietracamela, Abruzzo, Italy	\N
171	0	0101000020E6100000A197F67244A31F40313D06D094EE4640	Rifugio Città di Mortara 	Alagna Valsesia, Piemonte, Italy	\N
172	0	0101000020E61000006E39F29B1D242040AB1ED555260C4740	Rifugio Andolla	Antrona Schieranico, Piemonte, Italy	\N
173	0	0101000020E61000000AD80E46ECAB2440B70BCD751AFF4540	Rifugio Forte dei Marmi	Stazzema, Toscana, Italy	\N
174	0	0101000020E6100000A88B14CAC2CF284038D66AB4C1504740	Rifugio Berti	Comelico Superiore, Veneto, Italy	\N
175	0	0101000020E610000071B43E4052BB2B406FE70CD649CF4640	Rifugio Premuda	San Dorligo della Valle, Friuli Venezia Giulia, Italy	\N
176	0	0101000020E61000006CCF2C0950C32240191BBAD91FF84640	Rifugio Elisa	Mandello del Lario, Lombardia, Italy	\N
177	0	0101000020E6100000A5BDC11726B31F40F90FE9B7AFFB4640	Rifugio CAI Saronno	Macugnaga, Piemonte, Italy	\N
178	0	0101000020E610000098DD9387857A2640A930B610E4584740	Rifugio Picco Ivigna	Scena, Trentino Alto Adige, Italy	\N
179	0	0101000020E61000003AE97DE36B8F1C404AEF1B5F7B8A4640	Rifugio Toesca	Bussoleno, Piemonte, Italy	\N
180	0	0101000020E6100000A913D044D8E02040382D78D1570C4740	Rifugio Al Cedo	Santa Maria Maggiore, Piemonte, Italy	\N
181	0	0101000020E6100000449D5ECE11661F4009ED8B3A29F34640	Capanna Gnifetti	Gressoney La Trinitè, Valle d?Aosta, Italy	\N
182	0	0101000020E6100000B8AE9811DE3E1E403A048E041AFC4640	Rifugio Aosta	Bionaz, Valle d?Aosta, Italy	\N
183	0	0101000020E6100000BBB31B22135525408EA8F523EA374740	Rifugio Cevedale	Pejo, Trentino Alto Adige, Italy	\N
184	0	0101000020E61000000D33349E08722340F0A485CB2A204740	Rifugio Ponti	Val Masino, Lombardia, Italy	\N
185	0	0101000020E6100000C46D7E0DD2B125405364085B47134740	Rifugio XII Apostoli	Stenico, Trentino Alto Adige, Italy	\N
186	0	0101000020E61000009F1C058882591B40DDD1FF722DE24640	Rifugio Elisabetta Soldini	Courmayeur, Valle d?Aosta, Italy	\N
187	0	0101000020E610000061D57994804F25409903A4C1291F4740	Rifugio Denza	Vermiglio, Trentino Alto Adige, Italy	\N
188	0	0101000020E61000000C1F115322F92A40338AE596560F4540	Rifugio Fonte Tavoloni 	Ovindoli, Abruzzo, Italy	\N
189	0	0101000020E610000037C2A2224EBF2840F2ED5D83BE4E4740	Rifugio Carducci	Auronzo di Cadore, Veneto, Italy	\N
190	0	0101000020E61000006FA53220D64E26400DE02D90A0044740	Rifugio Bindesi	Trento, Trentino Alto Adige, Italy	\N
191	0	0101000020E610000001C11C3D7ECB2D40C670D0B9365A4640	Mountain hut Miroslav Hirtz	53287 Jablanac, Ličko-senjska županija, Croatia	\N
192	0	0101000020E6100000398485EEED352C4098331D324C154740	Koca na Blegošu	4224 Gorenja vas, Slovenia	\N
193	0	0101000020E610000040F850A225BF1F400F441669E2594940	Wittener Hütte	Germany	\N
194	0	0101000020E610000000FDBE7FF3AA25409A99999999694740	Hochjoch-Hospiz	Austria	\N
195	0	0101000020E6100000D7A02FBDFD412640CDCCCCCCCCB44740	Meilerhütte	Germany	\N
196	0	0101000020E610000050C422861DA628406E85B01A4BC64740	Gaudeamushütte	Austria	\N
197	0	0101000020E6100000179CC1DF2F961940D5EB1681B15C4940	Rheydter Hütte	Germany	\N
198	0	0101000020E6100000FB66518EB8562C4057E883656C744940	Sektionshütte Krippen	Germany	\N
199	0	0101000020E61000001F7A839D234C2C40B45EF68814A34740	Neunkirchner Hütte	2620 Neunkirchen, Steiermark, Austria	\N
200	0	0101000020E61000009CE379FC2043E7BF8FC536A9682C4540	Refugio De Riglos	22808, Aragón, Spain	\N
201	0	0101000020E6100000563D4FC4941A2140EBB308E997564740	Salbithütte SAC	Uri, Switzerland	\N
202	0	0101000020E61000001D55C855B23A2040B8EB64DCCE424740	Finsteraarhornhütte SAC	Wallis, Switzerland	\N
203	0	0101000020E6100000DEFD765E1AE71D4038777A52B2FE4640	Cabane des Vignettes CAS	Wallis, Switzerland	\N
204	0	0101000020E6100000E769EE0B84312040FBE19FAF02504740	Glecksteinhütte SAC	Bern, Switzerland	\N
205	0	0101000020E6100000752B5D3C5F152240D9971BDB51454740	Länta-Hütte SAC	Graubünden, Switzerland	\N
206	0	0101000020E610000055ADDEFA26292040BAB9F14860214740	Monte-Leone-Hütte SAC	Wallis, Switzerland	\N
207	0	0101000020E6100000557F0CE8F9C222408F373B25D26E4740	Ringelspitzhütte SAC	Graubünden, Switzerland	\N
208	0	0101000020E6100000A4AA09A2EE0334408E23D6E253104640	Na poljanama Maljen	Maljen, Serbia	\N
209	0	0101000020E6100000A9DE1AD82A313440C5E6E3DA50114640	Dobra voda	Suvobor, Serbia	\N
210	0	0101000020E61000007250C24CDBFF2E402D095053CBC64640	Ivanova hiža	Karlovac town environment, Karlovačka, Croatia	\N
211	0	0101000020E6100000C6DCB5847CC02F40C746205ED7EB4640	Glavica	Medvednica, City of Zagreb, Croatia	\N
212	0	0101000020E6100000FFEC478AC8B83040D3F6AFAC34BD4540	Trpošnjik	Mosor, Splitsko-dalmatinska, Croatia	\N
213	0	0101000020E6100000C217265305932D40C4CE143AAFA54640	Bitorajka	Bitoraj, Primorsko-goranska, Croatia	\N
214	0	0101000020E6100000AB09A2EE0360304006D847A7AE084640	Zlatko Prgin	Dinara, Šibensko-kninska, Croatia	\N
215	0	0101000020E6100000D3872EA86F492E405C8FC2F528444640	Prpa	Velebit, Ličko-senjska, Croatia	\N
216	0	0101000020E6100000787FBC57AD5C2E408BFD65F7E43D4640	Ždrilo	Velebit, Ličko-senjska, Croatia	\N
217	0	0101000020E610000086032159C0F42D40B21188D7F59B4640	Miroslav Hirtz	Velika Kapela, Primorsko-goranska, Croatia	\N
218	0	0101000020E6100000A31EA2D11DAC3140462575029AC04640	Jezerce	Papuk, Požeško-slavonska, Croatia	\N
219	0	0101000020E61000003EE8D9ACFA4C2F405F0CE544BBE24640	Ivica Sudnik	Samoborska gora, Zagrebačka, Croatia	\N
220	0	0101000020E6100000AD3BCC4D8A7D2840CBDF185D39124640		71 Strada Corsi, Quarto Batilda calabro, Italy	\N
221	0	0101000020E6100000AF5E454607602340EDF2AD0FEB6B4440		20 Borgo Spadaro, Borgo Ranolfo, Italy	\N
222	0	0101000020E610000050BA3EBD63AA2840D5DBB0B7DE294640		563 Borgo Fiammetta, Osmondo laziale, Italy	\N
223	0	0101000020E6100000E7204322C8042640F6AEE6A507F54540		0 Piazza Corti, Borgo Calogero del friuli, Italy	\N
224	0	0101000020E61000009F11B6E919B02140ABAC12D154364640		385 Via Ione, Borgo Cristiano, Italy	\N
225	0	0101000020E61000009EBFBFF7ED2224402DAAEA8ABEE84640		08 Contrada Sanna, Quarto Luana, Italy	\N
226	0	0101000020E6100000FF209221C76E274017844DF8002D4640		143 Rotonda Laurentino, Pircher a mare, Italy	\N
227	0	0101000020E6100000C2B28817FA8E2340D5809C8B1AB04640		54 Rotonda Serena, Giaccio sardo, Italy	\N
228	0	0101000020E6100000107BFC3960762540600A6A53D0274740		6 Incrocio Mauro, Butera ligure, Italy	\N
229	0	0101000020E6100000CF5AC0BAE0462B40B9ED314745E34640		41 Rotonda Ermenegildo, Borgo Ulfo nell'emilia, Italy	\N
230	0	0101000020E610000048B42E7FCFC525403379B93E620B4740		6 Piazza Adalberto, Quarto Gionata, Italy	\N
231	0	0101000020E6100000E066F16261B42A4084E85AC52CF04640		997 Rotonda Marchetti, Borgo Elisa lido, Italy	\N
232	0	0101000020E610000021263CFC90E62840C604EBEEF0074640		80 Incrocio Carini, Cerise sardo, Italy	\N
233	0	0101000020E6100000CFB81567B161274070CFF3A78DA74640		120 Via Catania, Volpe del friuli, Italy	\N
234	0	0101000020E6100000C1F979F8D76F224054F0CAE48AB04640		103 Borgo Germana, Settimo Pammachio del friuli, Italy	\N
235	0	0101000020E61000008248D0A975782B40741200D2EDC94640		9 Incrocio Trasea, Caserta nell'emilia, Italy	\N
236	0	0101000020E6100000918B208436172940630E828E564E4540		89 Rotonda Pavan, Borgo Efisio, Italy	\N
237	0	0101000020E610000023484A1F5F572240D37CDF09072C4640		484 Contrada Accardo, Sesto Bastiano salentino, Italy	\N
238	0	0101000020E6100000A09339F130542140F7DBE8ADCB384740		21 Rotonda Viale, Caiazza laziale, Italy	\N
239	0	0101000020E6100000068A0E37967A2540DB1FDE29D3664540		497 Borgo Oggiano, Albano calabro, Italy	\N
240	0	0101000020E6100000CF59B09EA4CE2640F18288D4B4434740		93 Via Tornatore, Quarto Maurizio, Italy	\N
241	0	0101000020E6100000C153C8957A5A26407541D8840FE14640		9 Via Renzo, Sesto Ninfa, Italy	\N
242	0	0101000020E61000008577B988EF302140BAD3426E2B3D4740		767 Via Carini, Trasea laziale, Italy	\N
243	0	0101000020E6100000589643E6259E2540B49487E013DD4540		940 Strada Adalfredo, Borgo Ottilia, Italy	\N
244	0	0101000020E6100000249E4720B9702840B1F84D61A5124640		231 Borgo Mazzotti, Borgo Floriana, Italy	\N
245	0	0101000020E61000008B89CDC7B55926407EB4EED57D084740		840 Rotonda Benigna, Sacchetti del friuli, Italy	\N
246	0	0101000020E6100000D8B969334EEB27402CF8C84164804540		845 Incrocio Evangelisti, Settimo Fiorenziano, Italy	\N
247	0	0101000020E610000061D394AEAAD4204012A6835039FC4640		416 Piazza Frau, Antonella laziale, Italy	\N
248	0	0101000020E6100000B53C6AA741AC27408F0134A550B84640		952 Contrada Desogus, Sesto Platone nell'emilia, Italy	\N
249	0	0101000020E6100000F78CE9AE91D52240ED48F59D5FE54640		3 Incrocio Pirrone, Vittore umbro, Italy	\N
250	0	0101000020E6100000626DE75663902B4097FA1E9A1ED44640		6 Piazza Lipari, Borgo Plutarco, Italy	\N
251	0	0101000020E6100000FFF9C78C011B2640DD706946501E4740		3 Borgo Edvige, San Nestore terme, Italy	\N
252	0	0101000020E61000009C363EEEB67E2740BC2363B5F9BA4640		6 Incrocio Nestore, Borgo Vincenzo umbro, Italy	\N
253	0	0101000020E61000008A9466F3387C1E402B31CF4A5AE74640		76 Incrocio Gianni, Quarto Goffredo, Italy	\N
254	0	0101000020E6100000F22895F084D22A404082870E26ED4440		8 Borgo Cucciniello, Settimo Smeralda, Italy	\N
255	0	0101000020E61000007E1D386744712240C878399105CC4640		4 Incrocio Cozzani, Sesto Pancrazio terme, Italy	\N
256	0	0101000020E610000020D84C1993812240A475AFEEB30D4740		222 Borgo Di Marzio, Silvestro veneto, Italy	\N
257	0	0101000020E6100000242136FD7E2E26406E2AF7A7F91A4740		25 Contrada Cirilla, Benvenuti ligure, Italy	\N
258	0	0101000020E6100000485E8C37E8B927408860C1A2C7CA4640		5 Borgo Monaci, Settimo Flaviana calabro, Italy	\N
259	0	0101000020E61000005E961BB1BB751E407379BD4571EF4640		798 Piazza Luongo, Asterio a mare, Italy	\N
260	0	0101000020E6100000BE2ABC708CED2340366964A1E7DD4640		46 Via Cavalli, Fernanda lido, Italy	\N
261	0	0101000020E610000053B4722F302B2540E4DC26DC2B4D4740		6 Rotonda Verano, Riccio sardo, Italy	\N
262	0	0101000020E61000009A97C3EE3B32254052B241CB5F574640		36 Incrocio Messalina, Delle Monache del friuli, Italy	\N
263	0	0101000020E6100000622D3E05C0782840F70BD17C29DE4640		800 Borgo Cristiano, Valente veneto, Italy	\N
264	0	0101000020E6100000B05758703F782440773A4668BAB84640		0 Borgo Torquato, Eva veneto, Italy	\N
265	0	0101000020E610000011D20957F63B2640E6B8AEF3CA084740		110 Strada Zedda, Quarto Veronica, Italy	\N
266	0	0101000020E61000004704E3E0D2692C408514F2F741A74640		52 Piazza Rosario, Fabiano lido, Italy	\N
267	0	0101000020E61000002F0ACC54D2C8264038FE9F1E36CA4640		8 Incrocio Giusti, Onesto ligure, Italy	\N
268	0	0101000020E610000046E80C31035E29405A46EA3D95E54640		432 Incrocio Candela, Bianchini laziale, Italy	\N
269	0	0101000020E6100000E4F90CA8376B2340ABA3F496BC5E4440		998 Via Moira, Borgo Ettore del friuli, Italy	\N
270	0	0101000020E6100000967DB2BD71ED26406F7319EDA7C14640		1 Borgo Serapione, Settimo Solocone, Italy	\N
271	0	0101000020E6100000FC68DDABFB5427401073EE1B04334740		77 Piazza Spiga, Quarto Guenda terme, Italy	\N
272	0	0101000020E610000069965F611C5B2540B52792F991CA4540		7 Piazza Elaide, Veridiana del friuli, Italy	\N
273	0	0101000020E6100000B4C6455ACF692740D8C523A765B04640		623 Borgo Uguccione, Gustavo ligure, Italy	\N
274	0	0101000020E61000003B843B61D3CC1E40935742D202D44640		82 Strada Cerri, Borgo Alcibiade, Italy	\N
275	0	0101000020E6100000C03FA54A9455284094347F4C6BE54640		44 Rotonda Cavriani, Borgo Bonifacio veneto, Italy	\N
276	0	0101000020E610000003FBF900EEEB1E40FA6184F068EE4640		33 Rotonda Cerrani, Quarto Gilberto lido, Italy	\N
277	0	0101000020E610000007681140209E2640B177352F3D9D4640		07 Borgo Polese, Settimo Prudenzia, Italy	\N
278	0	0101000020E6100000525F96766AFE23402A7C6C81F3EE4640		18 Incrocio Prudenzio, Lelia umbro, Italy	\N
279	0	0101000020E61000007319EDA7B5EF1E400B1060EC18EC4640		9 Rotonda Bertolini, Sesto Scolastica, Italy	\N
280	0	0101000020E6100000F86B578DCA1A284015E06014A9B14640		16 Contrada Loreti, Leo veneto, Italy	\N
281	0	0101000020E6100000D634947FD2A12740811A081390584540		489 Contrada Mariotti, Lori lido, Italy	\N
282	0	0101000020E61000009D63E53C08EA2640B7FB0BF3D4DC4540		595 Via Stabile, Quarto Iolanda nell'emilia, Italy	\N
283	0	0101000020E6100000EA0E18DAEF9B2B40948444DAC6764640		55 Borgo Sepe, Gianmarco nell'emilia, Italy	\N
284	0	0101000020E610000014BCD7FFEFC62640BA66F2CD36DE4640		29 Via Flavio, Quarto Debora, Italy	\N
285	0	0101000020E610000009168733BFBE27405D4E098849354540		585 Rotonda Boris, Amintore a mare, Italy	\N
286	0	0101000020E6100000462AE7E6763A2940ABB8CC446CE14440		11 Contrada Granà, Biancheri ligure, Italy	\N
287	0	0101000020E610000075EED176A7F62640A7F97486F3B24640		92 Contrada Fulgenzio, Emiliana ligure, Italy	\N
288	0	0101000020E6100000F9A23D5E48F727405789C3E3ECE04640		99 Piazza Doro, Matranga laziale, Italy	\N
289	0	0101000020E6100000731A587D64FD294065FED13769E64540		912 Via Gigliotti, Borgo Fidenziano, Italy	\N
290	0	0101000020E6100000ABC5F18D322421407D1FB3582FFA4640		73 Strada Gedeone, Anselmo lido, Italy	\N
291	0	0101000020E610000035D252793B0228403A79ECC26AEA4640		6 Incrocio Salvucci, San Uriele terme, Italy	\N
292	0	0101000020E6100000DD730580CFD02640F16261889CD44640		89 Contrada De Sanctis, Selvaggia umbro, Italy	\N
293	0	0101000020E61000006531564046E12040530E1C8645E74640		69 Borgo Gertrude, Ampelio del friuli, Italy	\N
294	0	0101000020E610000026B8A2DE9D5E2740311A434AFDDC4640		59 Piazza Belvisi, Borgo Godeberta umbro, Italy	\N
295	0	0101000020E61000000A5BFD22B27524407121EA99B95B4640		080 Piazza Duilio, San Aleardo nell'emilia, Italy	\N
296	0	0101000020E6100000C132DBBA40CE2240D0EFFB372F274740		8 Contrada Anselmo, Quarto Matroniano, Italy	\N
297	0	0101000020E6100000CA558737C6B91F40EB79ED88F9BD4640		679 Strada Marchesan, Cesare salentino, Italy	\N
298	0	0101000020E61000006AEE320DD4F324401D098F9147B14640		9 Incrocio Adelfo, Borgo Uberto del friuli, Italy	\N
299	0	0101000020E610000044053D8A291B2140F0FACC599F5A4440		80 Borgo Teogene, San Gionata, Italy	\N
300	0	0101000020E61000002B1D07B9E6212040F08C11E4FBF04640		67 Borgo Villani, Borgo Fiore, Italy	\N
301	0	0101000020E61000007BEDE3B21BB727403464E190B2DD4640		083 Rotonda Averardo, Fernando del friuli, Italy	\N
302	0	0101000020E6100000D8E9ACBB1EE91F40A0A932E774D04640		258 Via Vidone, Politi a mare, Italy	\N
303	0	0101000020E61000009C8136DEC21B294063731FCA61894540		54 Via Fulberto, Amatore ligure, Italy	\N
304	0	0101000020E6100000E3B08FA91680204076A0F3BF01E94640		350 Incrocio Spadafora, Di Francesco salentino, Italy	\N
305	0	0101000020E6100000EE6EAF16E9832340C6F0225D7DCC4640		25 Borgo Eleonora, Quarto Nadia del friuli, Italy	\N
306	0	0101000020E6100000D81D41E037B02140C2F1214D61C54440		3 Rotonda Onorio, San Maura terme, Italy	\N
307	0	0101000020E6100000A807BB174E80284061BC8B9C2AD94640		763 Strada Paolo, Quarto Fosco, Italy	\N
308	0	0101000020E6100000FD18CE9085A322406C9CA80073DB4640		138 Contrada Ivanoe, Sesto Matroniano, Italy	\N
309	0	0101000020E6100000E39F635122672540E113A1C7DEDE4640		748 Piazza Indelicato, Frigerio salentino, Italy	\N
310	0	0101000020E610000098231A93B47928409916500361674640		7 Borgo Corsi, Pellegrino lido, Italy	\N
311	0	0101000020E6100000ABBCD3539A032740A544B7031AEF4640		24 Borgo Gusmeroli, Borgo Clodomiro, Italy	\N
312	0	0101000020E61000001E424B0D239B2440D8D1DD1A7DA04640		463 Via Doda, San Tazio salentino, Italy	\N
313	0	0101000020E6100000CF2CAE96E0891F405EB642FDD3234640		7 Piazza Marano, Torresi terme, Italy	\N
314	0	0101000020E6100000D7BDBACF96BC254007205AD020C34640		000 Strada Ulpiano, Quarto Alessio ligure, Italy	\N
315	0	0101000020E6100000C96BCABA24832740A97E4A3A6FE54640		84 Piazza Tina, Omar a mare, Italy	\N
316	0	0101000020E6100000A8DAB80F8AC32940DF67017F9D1A4540		04 Rotonda Pasini, Sesto Orsola, Italy	\N
317	0	0101000020E6100000C272DFC556972640A4271BC528D24640		11 Contrada Sempronio, Desdemona terme, Italy	\N
318	0	0101000020E61000005F306E5974411E40EC3F21F1E13A4740		3 Borgo Sigismondo, Settimo Rosalinda umbro, Italy	\N
319	0	0101000020E61000006C109CE9142628401760C4E347124740		1 Via Paolo, Sesto Piergiorgio salentino, Italy	\N
320	0	0101000020E610000044EC0214D9FD284012AC600AC5EE4440		120 Via Cristoforo Colombo, Roma, Italy	\N
321	0	0101000020E6100000B0FECF61BEF827406DFD99E6C2F24640		110 Rotonda Procopio, Narciso laziale, Italy	\N
322	0	0101000020E6100000EBB76576CCAF26407B8FE9BFBD424640		397 Borgo Narsete, Peleo calabro, Italy	\N
323	0	0101000020E6100000D6479682247220407379BD4571084740		35 Rotonda Scalise, Sesto Rolfo, Italy	\N
324	0	0101000020E610000097900F7A36872040AB251DE560074740		30 Piazza Consiglio, Sesto Graziano salentino, Italy	\N
325	0	0101000020E61000000DABD3DC65C22740D32F116F9DE34640		888 Via Medugno, Settimo Costante del friuli, Italy	\N
326	0	0101000020E61000009FEE97AA0FCF27402834FF9E0E024740		107 Incrocio Pecora, Sesto Bardomiano, Italy	\N
327	0	0101000020E6100000E417B90265622C40EFC0A50815E24440		3 Incrocio Boschetti, Lai umbro, Italy	\N
328	0	0101000020E6100000B2463D44A37B2540F3C011EEDF764540		42 Rotonda Vulpiano, Settimo Almiro veneto, Italy	\N
329	0	0101000020E6100000B6B0B84956A326409DC2A5BE87334740		980 Incrocio Raniero, Borgo Stiriaco, Italy	\N
330	0	0101000020E6100000D56C2FB319AD2840823C16365EC04640		54 Piazza Grandi, San Radolfo sardo, Italy	\N
331	0	0101000020E610000076583C5002EE1E40E0CCF9731BE14640		087 Strada Saccone, Sesto Ivan, Italy	\N
332	0	0101000020E6100000470EC7A98CC52840B6A73F564BE04640		950 Via Barbiero, Di Lecce lido, Italy	\N
333	0	0101000020E61000004DC00A4B97B91F4005C1E3DBBBF84540		828 Incrocio Virginio, Sibilla terme, Italy	\N
334	0	0101000020E610000059EB7A585E182740106D1162780E4640		66 Incrocio Paolo, Rocco calabro, Italy	\N
335	0	0101000020E610000051D9B0A6B2581F4089B7CEBF5DE14640		0 Strada Calabrese, Murgia salentino, Italy	\N
336	0	0101000020E6100000AD7603BB504F27406049A8CFC4374640		2 Rotonda Guiberto, San Fabio calabro, Italy	\N
337	0	0101000020E61000004692C5A28EF72640D32934B511794640		732 Borgo Chiara, San Luminosa terme, Italy	\N
338	0	0101000020E6100000068B790C45182740C3CB1D47BD774640		915 Via Romina, Sesto Arduino, Italy	\N
339	0	0101000020E61000005CC0159A35C620401880A1A245F44640		1 Incrocio Ippoliti, Auro terme, Italy	\N
340	0	0101000020E6100000FA2D9512DD7227409453967C47234640		116 Via Vascotto, Quarto Vivaldo laziale, Italy	\N
341	0	0101000020E61000008ECD8E54DFA12B403562C1583A2D4540		420 Borgo Grimaldi, Sesto Luciana umbro, Italy	\N
342	0	0101000020E610000020651FBF127F254034C06092257F4640		677 Via Lentini, Borgo Amando, Italy	\N
343	0	0101000020E610000064BB31F3D36E22404F401361C3C24640		168 Via Mazzi, Gavino laziale, Italy	\N
344	0	0101000020E6100000D160AEA0C47E2240E41824D813C04640		38 Rotonda Bove, Settimo Geminiano lido, Italy	\N
345	0	0101000020E61000006FD8B628B3B91E40086465EA64D64640		414 Contrada Carrozza, Quarto Nina terme, Italy	\N
346	0	0101000020E610000016CDB9CAC93E2140BC0E8B074A744640		31 Borgo Violante, San Adelfo sardo, Italy	\N
347	0	0101000020E6100000B4064A65E54A274026DAFA8E86E14640		17 Via Sebastiano, Di Marzio nell'emilia, Italy	\N
348	0	0101000020E61000000736F80CF26822405273034F6B9C4640		664 Via Carletti, Adolfo a mare, Italy	\N
349	0	0101000020E6100000DF6124C511412140D11CFE3FF3744640		679 Via Costanza, Settimo Addolorata, Italy	\N
350	0	0101000020E610000077ED77CD50412140CB243493B9744640		65 Rotonda Isacco, Settimo Telchide, Italy	\N
351	0	0101000020E61000002E008DD2A5032D406B5CA4F55C204540		45 Piazza Pastore, Romolo salentino, Italy	\N
352	0	0101000020E61000004ED367075C6F1F403A57941282D64640		60 Incrocio Alceo, Di Giovanni sardo, Italy	\N
353	0	0101000020E61000006405BF0D316E1F409F07D22060D24640		929 Contrada Matilde, Bellomo lido, Italy	\N
354	0	0101000020E61000006F4BE482334C2740A928A8F287304640		50 Strada Urso, Lelia ligure, Italy	\N
355	0	0101000020E61000005BC52CC59F522B40DB68A5B50EFA4640		157 Incrocio Lieto, Settimo Girardo lido, Italy	\N
356	0	0101000020E61000000D5F155E383A21402BCC310F4F724640		9 Incrocio Fausto, San Orlando sardo, Italy	\N
357	0	0101000020E6100000E04158326C5D2140821C9430D3704640		61 Piazza Blanc, Quarto Aleramo umbro, Italy	\N
358	0	0101000020E6100000C1F979F8D7071F404EFA319C21CD4640		0 Borgo Annagrazia, Sesto Auro terme, Italy	\N
359	0	0101000020E61000000C97B0917F3921404C9C267D6B734640		434 Strada Cicchetti, San Artemisa, Italy	\N
360	0	0101000020E6100000EFA18ED838742840FA10AF46D1764640		5 Borgo Alberico, Luchetti sardo, Italy	\N
361	0	0101000020E6100000B032BF3F4AC11E4019CD25B094D54640		983 Contrada Bertaccini, Quarto Ulfa, Italy	\N
362	0	0101000020E610000039FBB9579CA829401D9C3EF152FC4440		38 Borgo Orfeo, Gerasimo sardo, Italy	\N
363	0	0101000020E6100000440E5BC4C1F71E4071033E3F8C7E4640		9 Strada Fadda, Ausiliatrice salentino, Italy	\N
364	0	0101000020E6100000C69EE2DD36D82B400B8AD5D5D3E84640		24 Via Sammartino, Quarto Callisto nell'emilia, Italy	\N
365	0	0101000020E6100000888961E2EA131F4040E7244A31CD4640		67 Piazza Davoli, Cecchetti terme, Italy	\N
366	0	0101000020E6100000E8F86871C6D81E40E7EBE86E8DD84640		630 Piazza Donata, Borgo Platone, Italy	\N
367	0	0101000020E610000024BF34FBF2301F405FCE6C57E8CB4640		253 Borgo Ranieri, De Marco laziale, Italy	\N
368	0	0101000020E61000000242902859C7254075988AE832F64540		38 Piazza Iorio, Carloni del friuli, Italy	\N
369	0	0101000020E61000005CEC5113D8AF1E405650ACAE9ED84640		7 Borgo Caricari, Settimo Prudenzio sardo, Italy	\N
370	0	0101000020E6100000A6A84423E9E41E40BF20336145E14640		27 Borgo Famiano, Settimo Emmerico laziale, Italy	\N
371	0	0101000020E6100000F07A7AB6582B2740B1ADFAB726234640		02 Incrocio Remo, Settimo Luminosa, Italy	\N
372	0	0101000020E61000002252D32EA6C91E404392B47636E94640		8 Incrocio Velio, Litterio umbro, Italy	\N
373	0	0101000020E61000000BC336983C2C27405262D7F676234640		6 Via Sviturno, Settimo Eufebio umbro, Italy	\N
374	0	0101000020E61000004F722C94F1E8264075F2D885D5064740		531 Contrada Menconi, Quarto Consolata sardo, Italy	\N
375	0	0101000020E61000005C8BBBE6FA8F26407A4F8AFB343B4740		028 Via Oderico, Borgo Eleuterio, Italy	\N
376	0	0101000020E61000007B9054956C0B28407BB5487FD4974640		148 Rotonda Alessandra, Cleopatra nell'emilia, Italy	\N
377	0	0101000020E6100000BE52F1DA00B72B40D21D1F8887274540		45 Via Cataldi, San Carlo, Italy	\N
378	0	0101000020E6100000A732D6485C052740FDD8243FE2394640		29 Strada Orenzio, Quarto Porzia, Italy	\N
379	0	0101000020E6100000AD94545C0B4D2240EE885462E8B94640		9 Piazza Nappi, Baldassarre ligure, Italy	\N
380	0	0101000020E6100000333097F9B3641F40983BE93356DF4640		34 Piazza Urbano, Quarto Candida terme, Italy	\N
381	0	0101000020E61000002B8AB2124E762740C1EA234B41314640		290 Incrocio Bologna, Borgo Furio, Italy	\N
382	0	0101000020E6100000905F8951219022403E5695229E864640		4 Incrocio Balestra, Miglio lido, Italy	\N
383	0	0101000020E610000096C1621E43E92640E580B80611044740		922 Strada Butera, Coreno salentino, Italy	\N
384	0	0101000020E61000007090B52B99842B40E461461DC27E4640		1 Incrocio Giorgia, Tacconi del friuli, Italy	\N
385	0	0101000020E610000084B1CFAD219A26406BDECC43010E4740		68 Borgo Giovanna, San Edvige umbro, Italy	\N
386	0	0101000020E6100000CC1D47BDF13F2240A5A31CCC26824640		11 Incrocio Corazza, Sesto Casto, Italy	\N
387	0	0101000020E610000048E58123DCFF26407F7E294D94084740		59 Contrada Ciani, San Zabina veneto, Italy	\N
388	0	0101000020E61000006B5A73918C1625409D7C1FB358204740		52 Strada Rollo, Lo Bianco calabro, Italy	\N
389	0	0101000020E6100000204F818241C01E40068B1E53D2D34640		1 Piazza Ancilla, Settimo Rufo, Italy	\N
390	0	0101000020E6100000C0CBB161F2931E40B859BC5818D34640		84 Via Crea, Pani laziale, Italy	\N
391	0	0101000020E610000070DA4246F68B2C40A79C8AAFD1364740		608 Piazza Beniamino, Borgo Gianpaolo, Italy	\N
392	0	0101000020E6100000A9D5FC9D92882C4058FBE02131384740		0 Piazza Golinelli, San Sidonio, Italy	\N
393	0	0101000020E6100000F74A0FF91DD1274067DC8AB3D8024740		85 Rotonda Corinna, San Virginio del friuli, Italy	\N
394	0	0101000020E61000004221A7542EE52C40A39BB3F457164740		95 Piazza Carrozza, Indro sardo, Italy	\N
395	0	0101000020E6100000D3D7987C586422408E7CB9AA47A84640		42 Rotonda Ciuffreda, Fortugno ligure, Italy	\N
396	0	0101000020E610000008CDAE7B2B8A2440E646EC6EF9664540		10 Rotonda Narciso, Preziosi lido, Italy	\N
397	0	0101000020E610000081EB8A19E1CD26408A4457D8C2194640		1 Strada Colangelo, San Mario, Italy	\N
398	0	0101000020E6100000B4CA4C69FD5122404A95CDC1D8134540		5 Incrocio Aquino, Quarto Pacomio laziale, Italy	\N
399	0	0101000020E6100000E4BD6A65C267264033260EEA6CBC4640		6 Borgo Ester, Cusumano lido, Italy	\N
400	0	0101000020E610000071C0536DDCD325406C312E0BDCB14640		8 Piazza Buongiorno, Quarto Barbara, Italy	\N
401	0	0101000020E6100000B368F0ADFEEA2540D42AFA4333B54640		417 Strada Indro, Gigliola lido, Italy	\N
402	0	0101000020E61000005B2CA0AB08EA2740DE454E15422C4740		7 Borgo Parodi, Volpe nell'emilia, Italy	\N
403	0	0101000020E61000009703988D2933274052EC0D63778A4640		95 Via Monte Grappa, Lendinara, Italy	\N
404	0	0101000020E61000005389FC44AF582940E7D2AEF83CCA4640		560 Rotonda Liverani, San Martina veneto, Italy	\N
405	0	0101000020E61000000236D6B441802C4025D5D237C46B4440		44 Via dei Greci, Napoli, Italy	\N
406	0	0101000020E610000073220BE24DBC2740A1E4C40DAE2D4740		6 Piazza Enzo, Settimo Sofronia calabro, Italy	\N
407	0	0101000020E610000046B1DCD26AB02540072E45A808074740		560 Via Corazza, Venerando calabro, Italy	\N
408	0	0101000020E6100000B17E7DBE77992240C0F858B043504440		115 Piazza Indelicato, Quarto Bonaventura sardo, Italy	\N
409	0	0101000020E6100000EC3026FDBD2C27403B6AF1CE46024740		110 Contrada Icaro, San Manilio del friuli, Italy	\N
410	0	0101000020E6100000996EC8F5A5712B40C576F700DD3C4740		079 Incrocio Destro, Grassi del friuli, Italy	\N
411	0	0101000020E6100000AA5DB818A8F922406B0DA5F622154440		03 Contrada Gianpaolo, Marini salentino, Italy	\N
412	0	0101000020E610000034B10AE58E682040CFC941BFA57A4440		99 Via Ascanio, Sesto Annabella laziale, Italy	\N
413	0	0101000020E610000008D04AB5AABC2140800F5EBBB4374640		51 Contrada Perseo, San Zenone, Italy	\N
414	0	0101000020E6100000B35DA10F967D2D408F49905BDD324740		0 Rotonda Quieta, Lazzari del friuli, Italy	\N
415	0	0101000020E6100000852348A5D8C12840842458C114E24540		5 Rotonda Taddei, Paterniano calabro, Italy	\N
416	0	0101000020E6100000BF5076E915252B40EA398EC4703B4740		195 Rotonda Martino, Leonida nell'emilia, Italy	\N
417	0	0101000020E6100000B956D6917EDA2B40DF707A72A8054540		801 Contrada Satta, Glenda lido, Italy	\N
418	0	0101000020E61000007889A02067742340DE2A3EF493CE4640		85 Contrada Raimondo, San Sviturno, Italy	\N
419	0	0101000020E6100000235399BDC70C254059CFFF6101ED4540		5 Rotonda Martina, Remigio umbro, Italy	\N
420	0	0101000020E610000027F33405D7392640E75E16C90D2C4740		96 Strada Delogu, Guida sardo, Italy	\N
421	0	0101000020E61000001C15EE4BECAC2A40DD11A9C4D02E4540		78 Strada Carella, Sesto Furseo, Italy	\N
422	0	0101000020E6100000C1D4850E70E722408E6D63FDB0594540		47 Borgo Mario, Ulfo terme, Italy	\N
423	0	0101000020E6100000E5BA849E28A826407E7D63BE723F4640		10 Rotonda Capoccia, Settimo Flaviana umbro, Italy	\N
424	0	0101000020E610000055B1E72109D11F4018CFA0A17FB14640		00 Strada Giulio, Sesto Scolastica laziale, Italy	\N
425	0	0101000020E61000007DEFCA89D18E2640DB0B16985F354540		3 Contrada Pagliuca, San Iginio terme, Italy	\N
426	0	0101000020E6100000BB6D9516E41D244002678412C1A94640		6 Rotonda Maggiore, Pisciotta veneto, Italy	\N
427	0	0101000020E6100000F67AF7C77BB52740FA449E245D4F4740		2 Borgo Casto, Serapione sardo, Italy	\N
428	0	0101000020E6100000DE68119BD960294098E8E225EEFB4440		22 Borgo Agnese, Sesto Porziano lido, Italy	\N
429	0	0101000020E61000007ED3AA4CE7E52340C9CC052E8F254640		62 Incrocio Radolfo, Schiavo calabro, Italy	\N
430	0	0101000020E61000004EDF217B732E2240D3F4D901D7214540		3 Piazza Lazzari, Sesto Lapo ligure, Italy	\N
431	0	0101000020E61000004377A45588CA264008951348E43C4640		57 Contrada Fiorini, Manca a mare, Italy	\N
432	0	0101000020E610000072593B40E6692840252D4B2A09EC4440		05 Via Gagliano, Melchiorre veneto, Italy	\N
433	0	0101000020E610000023E7B3F281D7214072C8618B38C84640		9 Strada Signorelli, Mirella sardo, Italy	\N
434	0	0101000020E61000000C84AE8E2D752740A4897780272E4640		8 Borgo Elettra, Ghilardi terme, Italy	\N
435	0	0101000020E6100000A63C5F58A33326408C811A63CCED4540		72 Rotonda Malatesta, Sesto Alvise veneto, Italy	\N
436	0	0101000020E6100000CC0C1B65FD922840A42C8DA905C14640		074 Via Boscaino, Cabras a mare, Italy	\N
437	0	0101000020E61000007332CC64933F2740FEDDF1DC31254640		981 Strada Ariele, San Fiorenza laziale, Italy	\N
438	0	0101000020E610000032D758784D462240743F4C67CC0B4740		750 Rotonda Cavaliere, Borgo Demetrio ligure, Italy	\N
439	0	0101000020E61000002B16BF29ACC825401AB6775787864540		1 Piazza Giambattista, Michelucci del friuli, Italy	\N
440	0	0101000020E6100000FE00B562C9B62A4032CFA51364D94440		36 Incrocio Leonida, Gualtieri laziale, Italy	\N
441	0	0101000020E61000002AD890C9F3362640A3C629DFD80F4640		150 Rotonda Cancellieri, Settimo Samanta sardo, Italy	\N
442	0	0101000020E610000098F0958AD7422540F3DD52735E994640		07 Via Fabbricatore, Settimo Ampelio, Italy	\N
443	0	0101000020E6100000451B36806D772640B99BF1C7FE074740		98 Rotonda Luigi, Di Maro salentino, Italy	\N
444	0	0101000020E61000008948A8740B9027402B7D321015F14540		8 Strada Siciliano, Godeberta ligure, Italy	\N
445	0	0101000020E6100000484B8A3496612B40F1F44A5986DF4640		95 Strada Ciccarelli, Sesto Amerigo, Italy	\N
446	0	0101000020E610000006240626DCE0264059631A97BBDC4640		26 Borgo Navarra, San Catullo, Italy	\N
447	0	0101000020E61000001A62067470422640EF6BC94F4FBD4540		729 Rotonda Testa, Dolce ligure, Italy	\N
448	0	0101000020E6100000F0F1536694F425402F5D77A9C7134640		315 Rotonda Piccione, Edda salentino, Italy	\N
449	0	0101000020E6100000A5DAA7E3317F2240E75E16C90DEF4640		525 Incrocio Pibiri, Simoni lido, Italy	\N
450	0	0101000020E6100000D12E956D967D2C40126C5CFFAE6D4440		66 Strada Mantovani, Sesto Camilla, Italy	\N
451	0	0101000020E6100000DD6CBDF0941F27409F515F3BBDDA4640		099 Rotonda Mari, Demurtas sardo, Italy	\N
452	0	0101000020E610000096EA025E66002640FA4E82ED16F44540		4 Incrocio Crea, Alamanno a mare, Italy	\N
453	0	0101000020E61000009DDE20B5E43C25407F83F6EAE39D4540		0 Rotonda Chiacchio, Diana umbro, Italy	\N
454	0	0101000020E6100000016E162F168E2340861BF0F9614A4440		0 Strada Nerea, Sesto Nina umbro, Italy	\N
455	0	0101000020E61000009F32480BE1EA20405C8A50114CDA4640		19 Incrocio Santarelli, Sesto Cristoforo ligure, Italy	\N
456	0	0101000020E6100000618841052C422B400938DFE3A78E4640		6 Piazza Santarelli, Barbato nell'emilia, Italy	\N
457	0	0101000020E6100000160F94803D132140276BD44334E04640		78 Rotonda Bonazzi, Olivi umbro, Italy	\N
458	0	0101000020E610000097A13BD22A4C25401A80B2CE9DD44540		36 Contrada Grange, Quarto Cristaldo, Italy	\N
459	0	0101000020E6100000AD904D4DDD3827405B632BC313B14540		00 Via Malaspina, San Alcide, Italy	\N
460	0	0101000020E610000071E82D1EDEEB2C405F93DA30AF824440		6 Via Bertolini, Oliviero salentino, Italy	\N
461	0	0101000020E6100000DA48C8F6109B1F40EE2AFFB5176E4640		14 Piazza Serena, Quarto Venusto umbro, Italy	\N
462	0	0101000020E61000004D028A4798F02740C38366D7BD264640		957 Via Abenzio, Boni veneto, Italy	\N
463	0	0101000020E6100000BCB77DEAB38A2C404EF04DD3676E4440		9 Piazza Panetta, Quarto Desdemona veneto, Italy	\N
464	0	0101000020E6100000CBC80F4BB93126404793E6EA22FD4640		0 Incrocio Dario, Brigandì sardo, Italy	\N
465	0	0101000020E6100000A68E9FD7E925284065677682A2C64640		547 Contrada Ismaele, Sesto Evangelina, Italy	\N
466	0	0101000020E6100000407562C55F5D294091FC773359C24640		07 Borgo Fischetti, Sesto Giustiniano umbro, Italy	\N
467	0	0101000020E6100000CF328B506C4D244070D63B37C8184640		157 Via Ciulla, Saffiro a mare, Italy	\N
468	0	0101000020E61000007E6E0D11DC1122409453967C47EB4640		476 Via Corrado, Settimo Giusta, Italy	\N
469	0	0101000020E610000043A44BA4D989204072A8DF85ADD34640		473 Strada Medardo, Gianotti sardo, Italy	\N
470	0	0101000020E61000004371C79BFC022C404AF5F81807254540		5 Incrocio Zanon, Egisto nell'emilia, Italy	\N
471	0	0101000020E61000009EA74B10BFA422400292FAFC41944440		8 Via Gioele, Dafne salentino, Italy	\N
472	0	0101000020E61000000D88B59D5B012C40CF70B9B024144540		02 Incrocio Graziella, San Riccarda salentino, Italy	\N
473	0	0101000020E610000059935D1F8CFE26407E6DA23B2D3B4640		396 Piazza Edilberto, Quarto Icilio, Italy	\N
474	0	0101000020E6100000D50451F7010829403B736AC2510D4640		022 Piazza Sosteneo, San Elita a mare, Italy	\N
475	0	0101000020E6100000CD6152D735012740D65F6523C6394640		167 Borgo Isidoro, Sesto Fabiana, Italy	\N
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hike_track_points ("userHikeId", index, "pointId", datetime) FROM stdin;
\.


--
-- Data for Name: user_hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes (id, "userId", "hikeId", "startedAt", "updatedAt", "finishedAt", "psTotalKms", "psHighestAltitude", "psAltitudeRange", "psTotalTimeMinutes", "psAverageSpeed", "psAverageVerticalAscentSpeed", "maxElapsedTime", "weatherNotified", "unfinishedNotified") FROM stdin;
\.


--
-- Data for Name: user_hikes_track_points_user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes_track_points_user_hike_track_points ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash", approved, preferences, "plannedHikes") FROM stdin;
2	$2b$10$2A8zS8PpFpKUyaAlJpgsx.11KKXzJb08Gt2pq/0EHGOXojY2lnGlC	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N	t	\N	\N
4	$2b$10$LRMiB6LpVXDglh80HtXpW.KFmnlxZu4/MRlnEM99/NE1Z4fJpWm0i	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N	t	\N	\N
5	$2b$10$cNgHjgkrJUhaFc7ESXHQMeCv5eZE/aMEdJp6lMlN5N3fngscaKuHm	Laura	Zurru	5	laura@emergency.it	\N	t	\N	t	\N	\N
1	$2b$10$qSYnqVEscI2PG9Al2wv4JOuhGoHko4B99lCLv7gHhjHShkMJ1A5Sy	German	Gorodnev	0	german@hiker.it	\N	t	\N	t	\N	\N
3	$2b$10$zT1NnqSVj8Tzq9zNM6.Mx.qL/XgotmdRgiBwshGzolQKyul8MIssK	Vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N	t	\N	\N
6	$2b$10$bel6eUcsi2CTpQwk4DQ8vecUtxYOcBA.vkWyAv0kTOfsxwUm83KN6	Francesco	Grande	1	francesco@friend.it	\N	t	\N	t	\N	\N
7	$2b$10$GZcJRxk1KtlU3wCWfjnlGuwZQ8iB5fUaXI0PggKMpde24Ndbg7cH6	Gherardo	Papapietro	4	hutWorker0@gmail.com	\N	t	\N	t	\N	\N
8	$2b$10$8iOJYgqRkCsi5BlZGPTuguuj/KOEPKqkqivJXRGnI2n4nJrvvbMnW	Pantaleone	Paradiso	4	hutWorker1@gmail.com	\N	t	\N	f	\N	\N
9	$2b$10$mIEqFOHRWbho4CKGbP5vnOCiXT1bFS2IgqLR7Yfzs26K/Pwi.u95K	Luciana	Soldati	4	hutWorker2@gmail.com	\N	t	\N	t	\N	\N
10	$2b$10$aRevCMhnyurbMY4cOGrXcuuypXBTIS9wTQYwBfUZwMgHprBfx9yPC	Almiro	Rinaldi	4	hutWorker3@gmail.com	\N	t	\N	f	\N	\N
11	$2b$10$Q8JGIHgJvhPBKs2I/WKz.OcwbnSpTa7mO1HpGPSb2DKAdfCfKZ7Na	Adalgiso	Catalano	4	hutWorker4@gmail.com	\N	t	\N	t	\N	\N
12	$2b$10$qxKykdI.qnyYTyoYCC3IFOpGYVd4StvEY5HQWQVP5lEJ62a63Egl2	Ausilia	Nobili	4	hutWorker5@gmail.com	\N	t	\N	f	\N	\N
13	$2b$10$pSoAvyEkPX7H/ctxtJwWiOUpwrzyCg2khCRHT1/Ulo93d92a/d6Nu	Doriano	Farina	4	hutWorker6@gmail.com	\N	t	\N	t	\N	\N
14	$2b$10$2QAanr5synevdi/kzwncC.r9LgtYakgOz8MEsl2oDiae0UGD/4Pqa	Ildefonso	Pozzi	4	hutWorker7@gmail.com	\N	t	\N	f	\N	\N
15	$2b$10$bHkEGNHXiDUorMcVDFQR6Ohg9fMwvv08c1MoRFwHickYal/V5P4Ta	Edvige	Sammartino	4	hutWorker8@gmail.com	\N	t	\N	t	\N	\N
16	$2b$10$PlOalGfnXVFC.zUD19ZrNeM5eKiTUtU81uy3ojXHOlxjAYG/IskX6	Pomponio	Castagna	4	hutWorker9@gmail.com	\N	t	\N	f	\N	\N
17	$2b$10$GHM2e5/gS8aA90OMDaitEuOABKZk3quSzKhY9bJbT0PEeSdvqoT86	Palladia	Favara	4	hutWorker10@gmail.com	\N	t	\N	t	\N	\N
18	$2b$10$56LNVxRRBnlZg1UmhPb.zek.oGaxfVGPor9ysOF3IBtzGyytLHZZm	Romero	Testa	4	hutWorker11@gmail.com	\N	t	\N	f	\N	\N
19	$2b$10$m0cAPP9FyuSm5bgVHoN1R.ZGKzr.s1978o1NeCcCz0xDNqNjlABUu	Semiramide	Cavalli	4	hutWorker12@gmail.com	\N	t	\N	t	\N	\N
20	$2b$10$MxFqthoVIZP7Iu/Ff.ny1u7wf6JCFxWXh6QLFVwEDrDpUc/iL5n1K	Debora	Di Tommaso	4	hutWorker13@gmail.com	\N	t	\N	f	\N	\N
21	$2b$10$hqPcOwh5IXeW47Np8VEtZ.lxiPvGjXduOQkfgYUGdWC1xRWWbTfmO	Acrisio	Di Pasquale	4	hutWorker14@gmail.com	\N	t	\N	t	\N	\N
22	$2b$10$2euQ2X4VsAJoHQrLE1MmieM0axu/Kv4TbRNj.uz1oj6NXRyeDwqMi	Deodata	Bernardini	4	hutWorker15@gmail.com	\N	t	\N	f	\N	\N
23	$2b$10$3lJqVjA3zolK9W1rx1gabehKLt54n6DLQs3fs.pds76WNtle6XUy6	Santina	Bovolenta	4	hutWorker16@gmail.com	\N	t	\N	t	\N	\N
24	$2b$10$e9vV/486KtjdwNZpXdeT/.n8A8xb8hyu81lI.9g26G4VQCTPDkO7G	Postumio	Buzzi	4	hutWorker17@gmail.com	\N	t	\N	f	\N	\N
25	$2b$10$PmnnKj/ZgL7961H8sM7l2.JEI0s14Rd0zneGssLbiP1Yy6T4zv27G	Coreno	Saracino	4	hutWorker18@gmail.com	\N	t	\N	t	\N	\N
26	$2b$10$YktrgNqF3xyWNytFYN6Za..w3JkkLEZah3gZ3qbjzV7nMqx5//Bpq	Genesia	La Porta	4	hutWorker19@gmail.com	\N	t	\N	f	\N	\N
27	$2b$10$r9lk4rKUa.g29.wXUwwnS.kequur34ZS1Z2TBBxvon6qnljEsvNrW	Adria	Falbo	4	hutWorker20@gmail.com	\N	t	\N	t	\N	\N
28	$2b$10$.1nouSmAKfe6OYfIRCAOaOlJLppqCZGv4yjcnw6KE/Rk0KmWUBh7u	Onorata	Rondoni	4	hutWorker21@gmail.com	\N	t	\N	f	\N	\N
29	$2b$10$C9o.JCffaYMVorY/1VgtruDct/wAucwYAvsFn2nTsHLNaFLxphnja	Dacio	Penna	4	hutWorker22@gmail.com	\N	t	\N	t	\N	\N
30	$2b$10$HHNwI.Zps57vP0J9m9bwNeNpVfZC0rq13ZOVB5dFe7m3ABlelBCXK	Vladimiro	Fiorucci	4	hutWorker23@gmail.com	\N	t	\N	f	\N	\N
31	$2b$10$pHx1X.NOyi5/bI56G.tQ/uuiuodlLpM/ajpZ1cKiV3guBrSosS8He	Marcella	Minniti	4	hutWorker24@gmail.com	\N	t	\N	t	\N	\N
32	$2b$10$qLve7bRo9ZuX6eYi9G0Lu.kkbg3qXispqPQl1dbUxddQP9xPb3WC2	Amina	Sucameli	4	hutWorker25@gmail.com	\N	t	\N	f	\N	\N
33	$2b$10$IJG6zJEFPPfG6ntI/PDHGOL8zcT6qDEG8w8Q4lr2X1mQNFHpeNvKa	Adria	Bernardini	4	hutWorker26@gmail.com	\N	t	\N	t	\N	\N
34	$2b$10$Ptzc5OIhzcTzWlye7J9tEuTJjvH/emGUiNOZjaTBbwAkTcOmbxGAS	Ricario	Buongiorno	4	hutWorker27@gmail.com	\N	t	\N	f	\N	\N
35	$2b$10$kO4fMI3vTgZ/pw5QZUO3uO5F5nuOqKtsBSIFnbw7yvi5qcOzDC3W6	Baldomero	Simeoli	4	hutWorker28@gmail.com	\N	t	\N	t	\N	\N
36	$2b$10$8rP1peFVlRL0VJXS3wxYnOv6n34yQJ6.LyLK.smVuSmdiPKqY5M9W	Gabino	Tassi	4	hutWorker29@gmail.com	\N	t	\N	f	\N	\N
37	$2b$10$lJbDo1UT0pEM7YJVxo80e.rnBDU35o6Jw/Jb5j.7xuI..RIaqkq1O	Irma	Errante	4	hutWorker30@gmail.com	\N	t	\N	t	\N	\N
38	$2b$10$jOeqKoU0Ym1tpdYFcoDw5epqcIW3yHuAERpp0AY698w7stFBA38J2	Ermelinda	Farella	4	hutWorker31@gmail.com	\N	t	\N	f	\N	\N
39	$2b$10$opL6CtWhZGNK.2mjVKaB9uLK/2kqbqgKTlyl9yaMV.bvgdFzPEW16	Eutalio	Amico	4	hutWorker32@gmail.com	\N	t	\N	t	\N	\N
40	$2b$10$xK5anhBnk0pWYztSAQtRzeBl4zgLVRGkHtNdKUq0A3JPuojDt4lDO	Brunilde	Giovannelli	4	hutWorker33@gmail.com	\N	t	\N	f	\N	\N
41	$2b$10$ZHok6PJfXTUquuHJXSBCHeSZDBNy/X9GmcgpCKfH9O0Cg7yEpmi0G	Reginaldo	Boscolo	4	hutWorker34@gmail.com	\N	t	\N	t	\N	\N
42	$2b$10$o7IscPQ0QHfuMLufCEr7vu962IljBMUXApxkzbE/zUvBeV9Ugwgli	Tea	Montalto	4	hutWorker35@gmail.com	\N	t	\N	f	\N	\N
43	$2b$10$jpblk4hbexbMkas9LfsKJeybkkpKTpdWGfvLvwOjj0emHLGkHCe5i	Dulina	Garifo	4	hutWorker36@gmail.com	\N	t	\N	t	\N	\N
44	$2b$10$Mjpyg9iy32FF6zoPc1St7O.I6TO0NZ0yD81I7XcgjcPJWA0uZcaqu	Ersilia	Di Domenico	4	hutWorker37@gmail.com	\N	t	\N	f	\N	\N
45	$2b$10$3Q1dIm3IwcBU7.CbYDxvX.wqiCjynHAiCmgxunwVIV/J9G.KaY/DC	Abenzio	Congiu	4	hutWorker38@gmail.com	\N	t	\N	t	\N	\N
46	$2b$10$clp6sK55y2xWZHvgEkpPrOLHup0hnzmyyPVpB0BsPFvAJvgZE1E9K	Lucio	Kofler	4	hutWorker39@gmail.com	\N	t	\N	f	\N	\N
47	$2b$10$eHhIVA9IFWi0rhtd1.XrAONOqe4mepMpgk0asqWwB4soahWQUBSmy	Tarcisio	Parisi	4	hutWorker40@gmail.com	\N	t	\N	t	\N	\N
48	$2b$10$wuxQ2PEHb9GMHJycKxIB0egDC0aFW6NAKP.LbOAFrHCmJBdUE.MN6	Simone	Albanese	4	hutWorker41@gmail.com	\N	t	\N	f	\N	\N
49	$2b$10$.bnQY6YRagcpMw1YaxpuQ.yJDWbwlvpgSatRRKScIhhBpxq5PAGQO	Romualdo	Battaglia	4	hutWorker42@gmail.com	\N	t	\N	t	\N	\N
50	$2b$10$1tsWkNilnjvp0F4V0ZLQqeaf8lg2LYkIzYiYayvWN1HH5F8TQeBh2	Erardo	Baldassarre	4	hutWorker43@gmail.com	\N	t	\N	f	\N	\N
51	$2b$10$J62W1HubnIYuoASv09rcgesi/e4A20QoQJfhihQMLOoAYHqAWXbj6	Desiderata	Battistini	4	hutWorker44@gmail.com	\N	t	\N	t	\N	\N
52	$2b$10$7MXEj2M/RIZH0irYu7PqbufQDWkAvlyGGj4D7fAIBYQPjO51PdS6K	Teodolinda	Fantozzi	4	hutWorker45@gmail.com	\N	t	\N	f	\N	\N
53	$2b$10$db4e3.fP8r/GRZCy/dH/lOWIb2DEJ4ach37HTvL7ANSTdeyE.u68y	Alessia	Salerno	4	hutWorker46@gmail.com	\N	t	\N	t	\N	\N
54	$2b$10$MKXEd0Q6ErKbqByor94gvuZNXPrpNQLORseYR2rQ10N/rPsWQzEPe	Rolfo	Spagnuolo	4	hutWorker47@gmail.com	\N	t	\N	f	\N	\N
55	$2b$10$y.fAmjbcTMibtjqkpxuwjuf1wpxfuAwulCbkfj/S0aVGCVg4Lkb1i	Alberto	Tomaselli	4	hutWorker48@gmail.com	\N	t	\N	t	\N	\N
56	$2b$10$fr/Svemcsi/bVTLMi49Cwu6epeckP0ZgBt71o9el6Atv/npF.JZoG	Donatella	Venturelli	4	hutWorker49@gmail.com	\N	t	\N	f	\N	\N
57	$2b$10$ZVM4Y84ixXjZbGPI18O7POvPVADp6PKuuFAQYB757MNLbCkx73pqq	Abbondanzio	Lari	4	hutWorker50@gmail.com	\N	t	\N	t	\N	\N
58	$2b$10$gefLbBWOYYyE.DRULrUf0.ASHV135a.Y8zI/dn5G7.NFg6fBkvgx.	Zosima	Ratti	4	hutWorker51@gmail.com	\N	t	\N	f	\N	\N
59	$2b$10$LMxXJuKiixiRjkIKwhM3MO0TlfD0cCi8lyKEL/0yZlgADdI3tP7.C	Sandro	Zamboni	4	hutWorker52@gmail.com	\N	t	\N	t	\N	\N
60	$2b$10$dGr.Q.K9LEBfiPdULsaLiOgp5vbn2Arzq6wJSrcXw0y6eZ5koP.ei	Semplicio	Graziani	4	hutWorker53@gmail.com	\N	t	\N	f	\N	\N
61	$2b$10$snnxGKwKyVBIAS9L7vhe/uzns5XKAR6WiN3yE1MJQHkzN7t4n1aF6	Rosamunda	Di Francesco	4	hutWorker54@gmail.com	\N	t	\N	t	\N	\N
62	$2b$10$LWl6zTN0XZ6/oJf4xmlV8e0WrFdpGtth7WPcJEh4Tq3skAuHIs3ti	Ilenia	Barra	4	hutWorker55@gmail.com	\N	t	\N	f	\N	\N
63	$2b$10$U1Y5igLARMmh.8XeMHxVceNI011oLqWk1HED1eHXFAKU/s4ZuSguy	Ferdinando	Dal Farra	4	hutWorker56@gmail.com	\N	t	\N	t	\N	\N
64	$2b$10$od4vEe1o0n5ZzefDAdyno.X504aLR.TBS0lEAyBDf1VpLo9/7uz7q	Agenore	Liccardo	4	hutWorker57@gmail.com	\N	t	\N	f	\N	\N
65	$2b$10$fP3dvyVD47lTjs/1Pd3UX.c1fbGpozqxt6SVWUQQlCSDgr9paCk9y	Sansone	Ippolito	4	hutWorker58@gmail.com	\N	t	\N	t	\N	\N
66	$2b$10$pwNnnu1JiElKB1kS/Bg2MOmtyZUbfUbHCMP0xbhbWeWwt9AyRW44a	Cuzia	Marrone	4	hutWorker59@gmail.com	\N	t	\N	f	\N	\N
67	$2b$10$QaCP8vetoZl1EoQSA7969eqQmpk7Zph3RVbtnwZMgsr7usX5p/Zcy	Elide	Capitani	4	hutWorker60@gmail.com	\N	t	\N	t	\N	\N
68	$2b$10$3usQipqKq7lXTOT.o/DmXetCdB4t6gMmGewxXUaNbnD5Tq0a44L.O	Marita	Ancona	4	hutWorker61@gmail.com	\N	t	\N	f	\N	\N
69	$2b$10$2NrZjvpIzBOFyweTnHR2reeXuZDAmuOyiN6duYCvXOUkLN7bZ78wu	Santo	Casadei	4	hutWorker62@gmail.com	\N	t	\N	t	\N	\N
70	$2b$10$CXWXXmvofo4wgbYWJSoHteMXq1eKPJ0P9x3yMwuDbW20eaeJKq4nm	Siria	Sanna	4	hutWorker63@gmail.com	\N	t	\N	f	\N	\N
71	$2b$10$SV2F.7AHUleOPucUlHW1KeP4V43koz8nblp2CUSQH9RsX2axT.Qwa	Aida	Scorza	4	hutWorker64@gmail.com	\N	t	\N	t	\N	\N
72	$2b$10$VEGnrTVkJgJ3EFpW/9yD3e9SNW1sqQmkejfa21Mv4TNT5BM/DlQaW	Gregorio	Sebastiani	4	hutWorker65@gmail.com	\N	t	\N	f	\N	\N
73	$2b$10$Szg0WRx4j7NeawS.ozDR6eaWE0NpazHhACsxMGGV9HCPHrbHSEs2a	Orsola	Franzoni	4	hutWorker66@gmail.com	\N	t	\N	t	\N	\N
74	$2b$10$3HnswvGUfmrfnfnRI8/nBujAVlJIEBN3zXvEpw3S/GlqMIwjbgfuu	Vinebaldo	Acquaviva	4	hutWorker67@gmail.com	\N	t	\N	f	\N	\N
75	$2b$10$hybhxerU.QMFjdAP9Rvat.s0mtamk30MEei.0Z2QrlJP3f78CzRLa	Guenda	Cecere	4	hutWorker68@gmail.com	\N	t	\N	t	\N	\N
76	$2b$10$ilO3gi4NcO/lNjRNFGkN3.gB2jxnjKz.CCSJmG5TE3WItEz7NfEJm	Norina	Chiavacci	4	hutWorker69@gmail.com	\N	t	\N	f	\N	\N
77	$2b$10$HLYMoomRLywOAGSXslxghO4UaKfF804yQaWw9jt2mwtT/D.NOf3.q	Anita	Ambrosio	4	hutWorker70@gmail.com	\N	t	\N	t	\N	\N
78	$2b$10$VDN2jw0E7zYdTUNxOMwJ2eMeO4D9Wlw1kY/b9e0hJp8BwvL.P95rO	Enrica	Casu	4	hutWorker71@gmail.com	\N	t	\N	f	\N	\N
79	$2b$10$k4rrAPQWZ4rJkbec6bwJOOe2ZC6beH1NXMKNS/gcyhjnVlxdFoJVO	Amintore	Pittalis	4	hutWorker72@gmail.com	\N	t	\N	t	\N	\N
80	$2b$10$pUN6/nWWqFYRgNyUTb5E8.J.4gmpsMnmeaSuWbLxeD3ED/.N9NSw6	Goffredo	Peroni	4	hutWorker73@gmail.com	\N	t	\N	f	\N	\N
81	$2b$10$BjO4cO9HGmdj77p.aNLV6ehhzdu0umsu0QnyKBCuViiBapra28Qpm	Polidoro	Genchi	4	hutWorker74@gmail.com	\N	t	\N	t	\N	\N
82	$2b$10$0LDbDxNBfVXe8T75X0dBHeUAnxa73ANmTC33lRip0CRkV4qtkGPG.	Morena	Bongiovanni	4	hutWorker75@gmail.com	\N	t	\N	f	\N	\N
83	$2b$10$pEwptKY/Cn4B/x9M0f1c6e.QGkt8iMWG61OlxUMFRDosVlHFco64m	Moira	Cirelli	4	hutWorker76@gmail.com	\N	t	\N	t	\N	\N
84	$2b$10$74obwZueE7v8qbzIBzt2qOMUb9dPS/2m.HUsbD47Pv.Fm8Udxaesq	Arturo	Boi	4	hutWorker77@gmail.com	\N	t	\N	f	\N	\N
85	$2b$10$EOZF6dk4fc4wXRqiNqW53urzoLyJUONMBFMlbl1dahOUY5NxJPZ7i	Scolastica	Carminati	4	hutWorker78@gmail.com	\N	t	\N	t	\N	\N
86	$2b$10$dwjcpADjnWiK33beEkBepuBkcbOfiv9kC2w1DNuYwSUa3Ra6N4o2C	Carmen	Polito	4	hutWorker79@gmail.com	\N	t	\N	f	\N	\N
87	$2b$10$eFM6lE3/eDPmXXqmZyN0xudMkt0FOiv/Y1wZzh956fqY.rBbhgSue	Germano	Cattani	4	hutWorker80@gmail.com	\N	t	\N	t	\N	\N
88	$2b$10$okvDvvF1KA8XFtuLoOnIpe1V1mJ58ex5QO/R9X8KwTukxnpX9DAU2	Onofrio	Pratesi	4	hutWorker81@gmail.com	\N	t	\N	f	\N	\N
89	$2b$10$MPmWkDOMwS.geG/L4.sfluGaThXT5kE/9nMn7UM8gQUZEcCnrDCR6	Raffaele	Mecca	4	hutWorker82@gmail.com	\N	t	\N	t	\N	\N
90	$2b$10$gmm2bVaaP6/tkPxuHHQwxOseg11ZvQADxUwc6HNojyFCaiBs/2CzW	Giuditta	Scopece	4	hutWorker83@gmail.com	\N	t	\N	f	\N	\N
91	$2b$10$G5YH5K9JGg4c4p.Nqv5chu8vi0H/g27lQldkKW9Zz6.xcL4qNkb3W	Rosanna	Forconi	4	hutWorker84@gmail.com	\N	t	\N	t	\N	\N
92	$2b$10$xOnpFS25zczaRJ2N18g0z.t2jvau3yrUfoBe6aLLNRUYBET39m7gG	Eva	Russo	4	hutWorker85@gmail.com	\N	t	\N	f	\N	\N
93	$2b$10$2SAIqNv6oUtl3KzVGxISuuGvjbstZjPvy3kGsQKvlRKOaHCnudZ1S	Mariano	Granato	4	hutWorker86@gmail.com	\N	t	\N	t	\N	\N
94	$2b$10$cZ2QEHyVkVApRiu8n/DrtOLPU0ua.3mjr3Pp.gbgr3PEHOt7jL.Oi	Vladimiro	Calabrese	4	hutWorker87@gmail.com	\N	t	\N	f	\N	\N
95	$2b$10$LR4.HaHEgcYqnJc77w/B6uy1Fj5wee0bzc20wVRfOvZJQcN9EMyTK	Geltrude	Sabia	4	hutWorker88@gmail.com	\N	t	\N	t	\N	\N
96	$2b$10$2nrAVW7vkOg/Yw8M1vESCepm76WpvPPO3Zv13n8lXzk93m0IhLCnK	Gualberto	De Bonis	4	hutWorker89@gmail.com	\N	t	\N	f	\N	\N
97	$2b$10$q7uxEi92lXtOXyLbajkujeFoG8akAgneuit3gN2gq7RZ14rFFIsCy	Deodata	Bressan	4	hutWorker90@gmail.com	\N	t	\N	t	\N	\N
98	$2b$10$mUykz7PZDG8or7F8OGUIBObxEDxBVQ.5GArmu/Jd5.yzoFrGbqFgO	Omero	Ferro	4	hutWorker91@gmail.com	\N	t	\N	f	\N	\N
99	$2b$10$TqGxvlnzaLeoD239uphbtevXeV.jSd0xbanHFC0NxocICnvD/hcVW	Ermenegilda	Mura	4	hutWorker92@gmail.com	\N	t	\N	t	\N	\N
100	$2b$10$zzhN922DYJ.CBtvIQMNBR.uiaO91E9GQKSF.GNPyUdwowNVom3/gi	Severa	Maugeri	4	hutWorker93@gmail.com	\N	t	\N	f	\N	\N
101	$2b$10$GRqOT/JFFtSJZT75ZQiBK.voukT3/VRG2jf7aaE2sk5AKncaKSdq6	Cosima	Pizzuti	4	hutWorker94@gmail.com	\N	t	\N	t	\N	\N
102	$2b$10$.TEhM11bxlGQmJdIql.pCe0z3GSPN3gluxIpZQSacYFZCrHAYGFdO	Ruperto	Balestra	4	hutWorker95@gmail.com	\N	t	\N	f	\N	\N
103	$2b$10$2H5IjZarM03FTCR6Kt68ouDNHJL3xX1VXZmpZZ2EtLWyoUtbzqUTq	Vespasiano	Di Martino	4	hutWorker96@gmail.com	\N	t	\N	t	\N	\N
104	$2b$10$WN7C4Zk7ZYJhUPxnhgGUkur8uH4MmJn6TQO24uib7nKq3wlWYm8vu	Giacobbe	Passarelli	4	hutWorker97@gmail.com	\N	t	\N	f	\N	\N
105	$2b$10$T5i1dvAcibPtuS4fGshFF.ZWZt76K2wiKSbXOxT/SHVEMwo2v6wje	Tolomeo	Gusmeroli	4	hutWorker98@gmail.com	\N	t	\N	t	\N	\N
106	$2b$10$qamx8mKTRY7ZedUgDwYEx.YmkefHoFA/3TrxpDJNJy3konxSZD7ju	Filomena	Gioacchini	4	hutWorker99@gmail.com	\N	t	\N	f	\N	\N
107	$2b$10$zgJ5qUMF8OxYm.wCBt0bIu2ZckGAMt47jVvutTkpO7lW98g07UwLy	Cleandro	Spanu	4	hutWorker100@gmail.com	\N	t	\N	t	\N	\N
108	$2b$10$z3WoI6pBVLfhPSXBfBC01uZqwVxfwlo2uOrYwlvaYWEJ9YmtCtli6	Filippo	Fiorentino	4	hutWorker101@gmail.com	\N	t	\N	f	\N	\N
109	$2b$10$dGpamwsN7QhsPNwz2mmUD.k4usy4XA.6HqSYKtb26daK216SD6uC6	Sidonio	Margiotta	4	hutWorker102@gmail.com	\N	t	\N	t	\N	\N
110	$2b$10$s926u71J5qEMojmT2mrYfeHLmtGLRFz/2/v5fmrT5xzyth3aBVGyy	Lucia	Iotti	4	hutWorker103@gmail.com	\N	t	\N	f	\N	\N
111	$2b$10$P/TbxMEdb2wXEpfkd5WS5OZsJbZD3UQdL3SYeMhP4oG4UuasKeyAO	Isacco	Del Gaudio	4	hutWorker104@gmail.com	\N	t	\N	t	\N	\N
112	$2b$10$NBoW4gkei.NXuIAFiusX5.Hc6W5kT5seHz.alzOhEr2OVtUb9E31i	Giuditta	Casadio	4	hutWorker105@gmail.com	\N	t	\N	f	\N	\N
113	$2b$10$z6HFm49.lIHC3Fya2HT1Z.2GYIwf.X5B30cYxb7p1y3I52NDUWHu2	Zenaide	Pedrotti	4	hutWorker106@gmail.com	\N	t	\N	t	\N	\N
114	$2b$10$V9D/Tvai/Qcq4/V0c3UzT.ULBdDZ/e9ssrN3ExZjrWsROxUqMRt3y	Valeriana	Lombardi	4	hutWorker107@gmail.com	\N	t	\N	f	\N	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 49, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 108, true);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 256, true);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 475, true);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_hikes_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

