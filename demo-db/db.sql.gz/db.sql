--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
1	4	0	0
1	5	1	0
2	6	0	0
2	7	1	0
2	8	2	0
2	9	3	0
2	10	4	0
2	11	5	0
2	12	6	0
2	13	7	0
2	14	8	0
2	15	9	0
2	16	10	0
2	17	11	0
2	18	12	0
2	19	13	0
2	20	14	0
2	21	15	0
2	22	16	0
2	23	17	0
2	24	18	0
2	25	19	0
2	26	20	0
2	27	21	0
2	28	22	0
2	29	23	0
2	30	24	0
2	31	25	0
2	32	26	0
2	33	27	0
2	34	28	0
2	35	29	0
2	36	30	0
2	37	31	0
2	38	32	0
2	39	33	0
2	40	34	0
2	41	35	0
2	42	36	0
2	43	37	0
2	44	38	0
2	45	39	0
2	46	40	0
2	47	41	0
2	48	42	0
2	49	43	0
2	50	44	0
2	51	45	0
2	52	46	0
2	53	47	0
2	54	48	0
2	55	49	0
2	56	50	0
2	57	51	0
2	58	52	0
2	59	53	0
2	60	54	0
2	61	55	0
2	62	56	0
2	63	57	0
2	64	58	0
2	65	59	0
2	66	60	0
2	67	61	0
2	68	62	0
2	69	63	0
2	70	64	0
2	71	65	0
2	72	66	0
2	73	67	0
2	74	68	0
2	75	69	0
2	76	70	0
2	77	71	0
2	78	72	0
2	79	73	0
2	80	74	0
2	81	75	0
2	82	76	0
2	83	77	0
2	84	78	0
2	85	79	0
2	86	80	0
2	87	81	0
2	88	82	0
2	89	83	0
2	90	84	0
2	91	85	0
2	92	86	0
2	93	87	0
2	94	88	0
2	95	89	0
2	96	90	0
2	97	91	0
2	98	92	0
2	99	93	0
2	100	94	0
2	101	95	0
2	102	96	0
2	103	97	0
2	104	98	0
2	105	99	0
2	106	100	0
2	107	101	0
2	108	102	0
2	109	103	0
2	110	104	0
2	111	105	0
2	112	106	0
2	113	107	0
2	114	108	0
2	115	109	0
2	116	110	0
2	117	111	0
2	118	112	0
2	119	113	0
2	120	114	0
2	121	115	0
2	122	116	0
2	123	117	0
2	124	118	0
2	125	119	0
2	126	120	0
2	127	121	0
2	128	122	0
2	129	123	0
2	130	124	0
2	131	125	0
2	132	126	0
2	133	127	0
2	134	128	0
2	135	129	0
2	136	130	0
2	137	131	0
2	138	132	0
2	139	133	0
2	140	134	0
2	141	135	0
2	142	136	0
2	143	137	0
2	144	138	0
2	145	139	0
2	146	140	0
2	147	141	0
2	148	142	0
2	149	143	0
2	150	144	0
2	151	145	0
2	152	146	0
2	153	147	0
2	154	148	0
2	155	149	0
2	156	150	0
2	157	151	0
2	158	152	0
2	159	153	0
2	160	154	0
2	161	155	0
2	162	156	0
2	163	157	0
2	164	158	0
2	165	159	0
2	166	160	0
2	167	161	0
2	168	162	0
2	169	163	0
2	170	164	0
2	171	165	0
2	172	166	0
2	173	167	0
2	174	168	0
2	175	169	0
2	176	170	0
2	177	171	0
2	178	172	0
2	179	173	0
2	180	174	0
2	181	175	0
2	182	176	0
2	183	177	0
2	184	178	0
2	185	179	0
2	186	180	0
2	187	181	0
2	188	182	0
2	189	183	0
2	190	184	0
2	191	185	0
2	192	186	0
2	193	187	0
2	194	188	0
2	195	189	0
2	196	190	0
2	197	191	0
2	198	192	0
2	199	193	0
2	200	194	0
2	201	195	0
2	202	196	0
2	203	197	0
2	204	198	0
2	205	199	0
2	206	200	0
2	207	201	0
2	208	202	0
2	209	203	0
2	210	204	0
2	211	205	0
2	212	206	0
2	213	207	0
2	214	208	0
2	215	209	0
2	216	210	0
2	217	211	0
2	218	212	0
2	219	213	0
2	220	214	0
2	221	215	0
2	222	216	0
2	223	217	0
2	224	218	0
2	225	219	0
2	226	220	0
2	227	221	0
2	228	222	0
2	229	223	0
2	230	224	0
2	231	225	0
2	232	226	0
2	233	227	0
2	234	228	0
2	235	229	0
2	236	230	0
2	237	231	0
2	238	232	0
2	239	233	0
2	240	234	0
2	241	235	0
2	242	236	0
2	243	237	0
2	244	238	0
2	245	239	0
2	246	240	0
2	247	241	0
2	248	242	0
2	249	243	0
2	250	244	0
2	251	245	0
2	252	246	0
2	253	247	0
2	254	248	0
2	255	249	0
2	256	250	0
2	257	251	0
2	258	252	0
2	259	253	0
2	260	254	0
2	261	255	0
2	262	256	0
2	263	257	0
2	264	258	0
2	265	259	0
2	266	260	0
2	267	261	0
2	268	262	0
2	269	263	0
2	270	264	0
2	271	265	0
2	272	266	0
2	273	267	0
2	274	268	0
2	275	269	0
2	276	270	0
2	277	271	0
2	278	272	0
2	279	273	0
2	280	274	0
2	281	275	0
2	282	276	0
2	283	277	0
2	284	278	0
2	285	279	0
2	286	280	0
2	287	281	0
2	288	282	0
2	289	283	0
2	290	284	0
2	291	285	0
2	292	286	0
2	293	287	0
2	294	288	0
2	295	289	0
2	296	290	0
2	297	291	0
3	298	0	0
3	299	1	0
3	300	2	0
3	301	3	0
3	302	4	0
3	303	5	0
3	304	6	0
3	305	7	0
3	306	8	0
3	307	9	0
3	308	10	0
3	309	11	0
3	310	12	0
3	311	13	0
3	312	14	0
3	313	15	0
3	314	16	0
3	315	17	0
3	316	18	0
3	317	19	0
3	318	20	0
3	319	21	0
3	320	22	0
3	321	23	0
3	322	24	0
3	323	25	0
3	324	26	0
3	325	27	0
3	326	28	0
3	327	29	0
3	328	30	0
3	329	31	0
3	330	32	0
3	331	33	0
3	332	34	0
3	333	35	0
3	334	36	0
3	335	37	0
3	336	38	0
3	337	39	0
3	338	40	0
3	339	41	0
3	340	42	0
3	341	43	0
3	342	44	0
3	343	45	0
3	344	46	0
3	345	47	0
3	346	48	0
3	347	49	0
3	348	50	0
3	349	51	0
3	350	52	0
3	351	53	0
3	352	54	0
3	353	55	0
3	354	56	0
3	355	57	0
3	356	58	0
3	357	59	0
3	358	60	0
3	359	61	0
3	360	62	0
3	361	63	0
3	362	64	0
3	363	65	0
3	364	66	0
3	365	67	0
3	366	68	0
3	367	69	0
3	368	70	0
3	369	71	0
3	370	72	0
3	371	73	0
3	372	74	0
3	373	75	0
3	374	76	0
3	375	77	0
3	376	78	0
3	377	79	0
3	378	80	0
3	379	81	0
3	380	82	0
3	381	83	0
3	382	84	0
3	383	85	0
3	384	86	0
3	385	87	0
3	386	88	0
3	387	89	0
3	388	90	0
3	389	91	0
3	390	92	0
3	391	93	0
3	392	94	0
3	393	95	0
3	394	96	0
3	395	97	0
3	396	98	0
3	397	99	0
3	398	100	0
3	399	101	0
3	400	102	0
3	401	103	0
3	402	104	0
3	403	105	0
3	404	106	0
3	405	107	0
3	406	108	0
3	407	109	0
3	408	110	0
3	409	111	0
3	410	112	0
3	411	113	0
3	412	114	0
3	413	115	0
3	414	116	0
3	415	117	0
3	416	118	0
3	417	119	0
3	418	120	0
3	419	121	0
3	420	122	0
3	421	123	0
3	422	124	0
3	423	125	0
3	424	126	0
3	425	127	0
3	426	128	0
3	427	129	0
3	428	130	0
3	429	131	0
3	430	132	0
3	431	133	0
3	432	134	0
3	433	135	0
3	434	136	0
3	435	137	0
3	436	138	0
3	437	139	0
3	438	140	0
3	439	141	0
3	440	142	0
3	441	143	0
3	442	144	0
3	443	145	0
3	444	146	0
3	445	147	0
3	446	148	0
3	447	149	0
3	448	150	0
3	449	151	0
3	450	152	0
3	451	153	0
3	452	154	0
3	453	155	0
3	454	156	0
3	455	157	0
3	456	158	0
3	457	159	0
3	458	160	0
3	459	161	0
3	460	162	0
3	461	163	0
3	462	164	0
3	463	165	0
3	464	166	0
3	465	167	0
3	466	168	0
3	467	169	0
3	468	170	0
3	469	171	0
3	470	172	0
3	471	173	0
3	472	174	0
3	473	175	0
3	474	176	0
3	475	177	0
3	476	178	0
3	477	179	0
3	478	180	0
3	479	181	0
3	480	182	0
3	481	183	0
3	482	184	0
3	483	185	0
3	484	186	0
3	485	187	0
3	486	188	0
3	487	189	0
3	488	190	0
3	489	191	0
3	490	192	0
3	491	193	0
3	492	194	0
3	493	195	0
3	494	196	0
3	495	197	0
3	496	198	0
3	497	199	0
3	498	200	0
3	499	201	0
3	500	202	0
3	501	203	0
3	502	204	0
3	503	205	0
3	504	206	0
3	505	207	0
3	506	208	0
3	507	209	0
3	508	210	0
3	509	211	0
3	510	212	0
3	511	213	0
3	512	214	0
3	513	215	0
3	514	216	0
3	515	217	0
3	516	218	0
3	517	219	0
3	518	220	0
3	519	221	0
3	520	222	0
3	521	223	0
3	522	224	0
3	523	225	0
3	524	226	0
3	525	227	0
3	526	228	0
3	527	229	0
3	528	230	0
3	529	231	0
3	530	232	0
3	531	233	0
3	532	234	0
3	533	235	0
3	534	236	0
3	535	237	0
3	536	238	0
3	537	239	0
3	538	240	0
3	539	241	0
3	540	242	0
3	541	243	0
3	542	244	0
3	543	245	0
3	544	246	0
3	545	247	0
3	546	248	0
3	547	249	0
3	548	250	0
3	549	251	0
3	550	252	0
3	551	253	0
3	552	254	0
3	553	255	0
3	554	256	0
3	555	257	0
3	556	258	0
3	557	259	0
3	558	260	0
3	559	261	0
3	560	262	0
3	561	263	0
3	562	264	0
3	563	265	0
3	564	266	0
3	565	267	0
3	566	268	0
3	567	269	0
3	568	270	0
3	569	271	0
3	570	272	0
3	571	273	0
3	572	274	0
3	573	275	0
3	574	276	0
3	575	277	0
3	576	278	0
3	577	279	0
3	578	280	0
3	579	281	0
3	580	282	0
3	581	283	0
3	582	284	0
3	583	285	0
3	584	286	0
3	585	287	0
3	586	288	0
3	587	289	0
3	588	290	0
3	589	291	0
4	590	0	0
4	591	1	0
4	592	2	0
4	593	3	0
4	594	4	0
4	595	5	0
4	596	6	0
4	597	7	0
4	598	8	0
4	599	9	0
4	600	10	0
4	601	11	0
4	602	12	0
4	603	13	0
4	604	14	0
4	605	15	0
4	606	16	0
4	607	17	0
4	608	18	0
4	609	19	0
4	610	20	0
4	611	21	0
4	612	22	0
4	613	23	0
4	614	24	0
4	615	25	0
4	616	26	0
4	617	27	0
4	618	28	0
4	619	29	0
4	620	30	0
4	621	31	0
4	622	32	0
4	623	33	0
4	624	34	0
4	625	35	0
4	626	36	0
4	627	37	0
4	628	38	0
4	629	39	0
4	630	40	0
4	631	41	0
4	632	42	0
4	633	43	0
4	634	44	0
4	635	45	0
4	636	46	0
4	637	47	0
4	638	48	0
4	639	49	0
4	640	50	0
4	641	51	0
4	642	52	0
4	643	53	0
4	644	54	0
4	645	55	0
4	646	56	0
4	647	57	0
4	648	58	0
4	649	59	0
4	650	60	0
4	651	61	0
4	652	62	0
4	653	63	0
4	654	64	0
4	655	65	0
4	656	66	0
4	657	67	0
4	658	68	0
4	659	69	0
4	660	70	0
4	661	71	0
4	662	72	0
4	663	73	0
4	664	74	0
4	665	75	0
4	666	76	0
4	667	77	0
4	668	78	0
4	669	79	0
4	670	80	0
4	671	81	0
4	672	82	0
4	673	83	0
4	674	84	0
4	675	85	0
4	676	86	0
4	677	87	0
4	678	88	0
4	679	89	0
4	680	90	0
4	681	91	0
4	682	92	0
4	683	93	0
4	684	94	0
4	685	95	0
4	686	96	0
4	687	97	0
4	688	98	0
4	689	99	0
4	690	100	0
4	691	101	0
4	692	102	0
4	693	103	0
4	694	104	0
4	695	105	0
4	696	106	0
4	697	107	0
4	698	108	0
4	699	109	0
4	700	110	0
4	701	111	0
4	702	112	0
4	703	113	0
4	704	114	0
4	705	115	0
4	706	116	0
4	707	117	0
4	708	118	0
4	709	119	0
4	710	120	0
4	711	121	0
4	712	122	0
4	713	123	0
4	714	124	0
4	715	125	0
4	716	126	0
4	717	127	0
4	718	128	0
4	719	129	0
4	720	130	0
4	721	131	0
4	722	132	0
4	723	133	0
4	724	134	0
4	725	135	0
4	726	136	0
4	727	137	0
4	728	138	0
4	729	139	0
4	730	140	0
4	731	141	0
4	732	142	0
4	733	143	0
4	734	144	0
4	735	145	0
4	736	146	0
4	737	147	0
4	738	148	0
4	739	149	0
4	740	150	0
4	741	151	0
4	742	152	0
4	743	153	0
4	744	154	0
4	745	155	0
4	746	156	0
4	747	157	0
4	748	158	0
4	749	159	0
4	750	160	0
4	751	161	0
4	752	162	0
4	753	163	0
4	754	164	0
4	755	165	0
4	756	166	0
4	757	167	0
4	758	168	0
4	759	169	0
4	760	170	0
4	761	171	0
4	762	172	0
4	763	173	0
4	764	174	0
4	765	175	0
4	766	176	0
4	767	177	0
4	768	178	0
4	769	179	0
4	770	180	0
4	771	181	0
4	772	182	0
4	773	183	0
4	774	184	0
4	775	185	0
4	776	186	0
4	777	187	0
4	778	188	0
4	779	189	0
4	780	190	0
4	781	191	0
4	782	192	0
4	783	193	0
4	784	194	0
4	785	195	0
4	786	196	0
4	787	197	0
4	788	198	0
4	789	199	0
4	790	200	0
4	791	201	0
4	792	202	0
4	793	203	0
4	794	204	0
4	795	205	0
4	796	206	0
4	797	207	0
4	798	208	0
4	799	209	0
4	800	210	0
4	801	211	0
4	802	212	0
4	803	213	0
4	804	214	0
4	805	215	0
4	806	216	0
4	807	217	0
4	808	218	0
4	809	219	0
4	810	220	0
4	811	221	0
4	812	222	0
4	813	223	0
4	814	224	0
4	815	225	0
4	816	226	0
4	817	227	0
4	818	228	0
4	819	229	0
4	820	230	0
4	821	231	0
4	822	232	0
4	823	233	0
4	824	234	0
4	825	235	0
4	826	236	0
4	827	237	0
4	828	238	0
4	829	239	0
4	830	240	0
4	831	241	0
4	832	242	0
4	833	243	0
4	834	244	0
4	835	245	0
4	836	246	0
4	837	247	0
4	838	248	0
4	839	249	0
4	840	250	0
4	841	251	0
4	842	252	0
4	843	253	0
4	844	254	0
4	845	255	0
4	846	256	0
4	847	257	0
4	848	258	0
4	849	259	0
4	850	260	0
4	851	261	0
4	852	262	0
4	853	263	0
4	854	264	0
4	855	265	0
4	856	266	0
4	857	267	0
4	858	268	0
4	859	269	0
4	860	270	0
4	861	271	0
4	862	272	0
4	863	273	0
4	864	274	0
4	865	275	0
4	866	276	0
4	867	277	0
4	868	278	0
4	869	279	0
4	870	280	0
4	871	281	0
4	872	282	0
4	873	283	0
4	874	284	0
4	875	285	0
4	876	286	0
4	877	287	0
4	878	288	0
4	879	289	0
4	880	290	0
4	881	291	0
5	882	0	0
5	883	1	0
5	884	2	0
5	885	3	0
5	886	4	0
5	887	5	0
5	888	6	0
5	889	7	0
5	890	8	0
5	891	9	0
5	892	10	0
5	893	11	0
5	894	12	0
5	895	13	0
5	896	14	0
5	897	15	0
5	898	16	0
5	899	17	0
5	900	18	0
5	901	19	0
5	902	20	0
5	903	21	0
5	904	22	0
5	905	23	0
5	906	24	0
5	907	25	0
5	908	26	0
5	909	27	0
5	910	28	0
5	911	29	0
5	912	30	0
5	913	31	0
5	914	32	0
5	915	33	0
5	916	34	0
5	917	35	0
5	918	36	0
5	919	37	0
5	920	38	0
5	921	39	0
5	922	40	0
5	923	41	0
5	924	42	0
5	925	43	0
5	926	44	0
5	927	45	0
5	928	46	0
5	929	47	0
5	930	48	0
5	931	49	0
5	932	50	0
5	933	51	0
5	934	52	0
5	935	53	0
5	936	54	0
5	937	55	0
5	938	56	0
5	939	57	0
5	940	58	0
5	941	59	0
5	942	60	0
5	943	61	0
5	944	62	0
5	945	63	0
5	946	64	0
5	947	65	0
5	948	66	0
5	949	67	0
5	950	68	0
5	951	69	0
5	952	70	0
5	953	71	0
5	954	72	0
5	955	73	0
5	956	74	0
5	957	75	0
5	958	76	0
5	959	77	0
5	960	78	0
5	961	79	0
5	962	80	0
5	963	81	0
5	964	82	0
5	965	83	0
5	966	84	0
5	967	85	0
5	968	86	0
5	969	87	0
5	970	88	0
5	971	89	0
5	972	90	0
5	973	91	0
5	974	92	0
5	975	93	0
5	976	94	0
5	977	95	0
5	978	96	0
5	979	97	0
5	980	98	0
5	981	99	0
5	982	100	0
5	983	101	0
5	984	102	0
5	985	103	0
5	986	104	0
5	987	105	0
5	988	106	0
5	989	107	0
5	990	108	0
5	991	109	0
5	992	110	0
5	993	111	0
5	994	112	0
5	995	113	0
5	996	114	0
5	997	115	0
5	998	116	0
5	999	117	0
5	1000	118	0
5	1001	119	0
5	1002	120	0
5	1003	121	0
5	1004	122	0
5	1005	123	0
5	1006	124	0
5	1007	125	0
5	1008	126	0
5	1009	127	0
5	1010	128	0
5	1011	129	0
5	1012	130	0
5	1013	131	0
5	1014	132	0
5	1015	133	0
5	1016	134	0
5	1017	135	0
5	1018	136	0
5	1019	137	0
5	1020	138	0
5	1021	139	0
5	1022	140	0
5	1023	141	0
5	1024	142	0
5	1025	143	0
5	1026	144	0
5	1027	145	0
5	1028	146	0
5	1029	147	0
5	1030	148	0
5	1031	149	0
5	1032	150	0
5	1033	151	0
5	1034	152	0
5	1035	153	0
5	1036	154	0
5	1037	155	0
5	1038	156	0
5	1039	157	0
5	1040	158	0
5	1041	159	0
5	1042	160	0
5	1043	161	0
5	1044	162	0
5	1045	163	0
5	1046	164	0
5	1047	165	0
5	1048	166	0
5	1049	167	0
5	1050	168	0
5	1051	169	0
5	1052	170	0
5	1053	171	0
5	1054	172	0
5	1055	173	0
5	1056	174	0
5	1057	175	0
5	1058	176	0
5	1059	177	0
5	1060	178	0
5	1061	179	0
5	1062	180	0
5	1063	181	0
5	1064	182	0
5	1065	183	0
5	1066	184	0
5	1067	185	0
5	1068	186	0
5	1069	187	0
5	1070	188	0
5	1071	189	0
5	1072	190	0
5	1073	191	0
5	1074	192	0
5	1075	193	0
5	1076	194	0
5	1077	195	0
5	1078	196	0
5	1079	197	0
5	1080	198	0
5	1081	199	0
5	1082	200	0
5	1083	201	0
5	1084	202	0
5	1085	203	0
5	1086	204	0
5	1087	205	0
5	1088	206	0
5	1089	207	0
5	1090	208	0
5	1091	209	0
5	1092	210	0
5	1093	211	0
5	1094	212	0
5	1095	213	0
5	1096	214	0
5	1097	215	0
5	1098	216	0
5	1099	217	0
5	1100	218	0
5	1101	219	0
5	1102	220	0
5	1103	221	0
5	1104	222	0
5	1105	223	0
5	1106	224	0
5	1107	225	0
5	1108	226	0
5	1109	227	0
5	1110	228	0
5	1111	229	0
5	1112	230	0
5	1113	231	0
5	1114	232	0
5	1115	233	0
5	1116	234	0
5	1117	235	0
5	1118	236	0
5	1119	237	0
5	1120	238	0
5	1121	239	0
5	1122	240	0
5	1123	241	0
5	1124	242	0
5	1125	243	0
5	1126	244	0
5	1127	245	0
5	1128	246	0
5	1129	247	0
5	1130	248	0
5	1131	249	0
5	1132	250	0
5	1133	251	0
5	1134	252	0
5	1135	253	0
5	1136	254	0
5	1137	255	0
5	1138	256	0
5	1139	257	0
5	1140	258	0
5	1141	259	0
5	1142	260	0
5	1143	261	0
5	1144	262	0
5	1145	263	0
5	1146	264	0
5	1147	265	0
5	1148	266	0
5	1149	267	0
5	1150	268	0
5	1151	269	0
5	1152	270	0
5	1153	271	0
5	1154	272	0
5	1155	273	0
5	1156	274	0
5	1157	275	0
5	1158	276	0
5	1159	277	0
5	1160	278	0
5	1161	279	0
5	1162	280	0
5	1163	281	0
5	1164	282	0
5	1165	283	0
5	1166	284	0
5	1167	285	0
5	1168	286	0
5	1169	287	0
5	1170	288	0
5	1171	289	0
5	1172	290	0
5	1173	291	0
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country) FROM stdin;
1	1	0.00	0	2147.78	0	t		/static/gpx/57bbb2d1-602f-406b-8a85-4a36125e1d53.gpx	16.31				
2	1	0.00	0	2750.54	0	t		/static/gpx/dd5ace0e-f7c4-4afc-b38c-c147e74e313a.gpx	4564.89				
3	1	0.00	0	2750.54	0	t		/static/gpx/22848d1a-e2fb-403d-881b-568abc3c1b2d.gpx	4564.89				
4	1	1.00	1	1.00	0	t	sasa	/static/gpx/b444fab7-1bee-4491-9681-208816d22a0a.gpx	4564.89				
5	1	1.00	1	1.00	1	1	1w1qsq1	/static/gpx/2bd87cab-35c7-4648-aa9e-2535bc90c4b4.gpx	4564.89				
6	1	1.00	1	1.00	1	1	1w1qsq1	/static/gpx/2bd87cab-35c7-4648-aa9e-2535bc90c4b4.gpx	4555.00				
7	2	0.00	0	0.00	2	Airline Trail - Detour		/static/gpx/001_Airline_Trail___Detour.gpx	0.00				USA
8	2	0.00	0	0.00	2	Airline Trail		/static/gpx/002_Airline_Trail.gpx	0.00				USA
9	2	0.00	0	0.00	2	Colchester Railroad		/static/gpx/003_Colchester_Railroad.gpx	0.00				USA
10	2	0.00	0	0.00	2	Willimantic Flower Bridge		/static/gpx/004_Willimantic_Flower_Bridge.gpx	0.00				USA
11	2	0.00	0	0.00	2	Willimantic Pedestrian Bridge		/static/gpx/005_Willimantic_Pedestrian_Bridge.gpx	0.00				USA
12	2	0.00	0	0.00	2	Two Sister'S Preserve Loop Trail		/static/gpx/006_Two_Sister_S_Preserve_Loop_Trail.gpx	0.00				USA
13	2	0.00	0	0.00	1	Putnam River Trail		/static/gpx/007_Putnam_River_Trail.gpx	0.00				USA
14	2	0.00	0	0.00	2	Airline Trail Bypass		/static/gpx/008_Airline_Trail_Bypass.gpx	0.00				USA
15	2	0.00	0	0.00	2	Indian Neck		/static/gpx/009_Indian_Neck.gpx	0.00				USA
16	2	0.00	0	0.00	1	Stony Creek		/static/gpx/010_Stony_Creek.gpx	0.00				USA
17	2	0.00	0	0.00	1	Quarry-Westwoods		/static/gpx/011_Quarry_Westwoods.gpx	0.00				USA
18	2	0.00	0	0.00	1	Short Beach		/static/gpx/012_Short_Beach.gpx	0.00				USA
19	2	0.00	0	0.00	2	Charter Oak Greenway		/static/gpx/013_Charter_Oak_Greenway.gpx	0.00				USA
20	2	0.00	0	0.00	0	Bissell Greenway		/static/gpx/014_Bissell_Greenway.gpx	0.00				USA
21	2	0.00	0	0.00	1	Riverfront Trail System		/static/gpx/015_Riverfront_Trail_System.gpx	0.00				USA
22	2	0.00	0	0.00	2	Millers Pond Park Trail		/static/gpx/016_Millers_Pond_Park_Trail.gpx	0.00				USA
23	2	0.00	0	0.00	2	Mattabesett Trail		/static/gpx/017_Mattabesett_Trail.gpx	0.00				USA
24	2	0.00	0	0.00	2	Jefferson Park Trail		/static/gpx/018_Jefferson_Park_Trail.gpx	0.00				USA
25	2	0.00	0	0.00	2	Cockaponset Trail		/static/gpx/019_Cockaponset_Trail.gpx	0.00				USA
26	2	0.00	0	0.00	1	Mt. Nebo Park		/static/gpx/020_Mt__Nebo_Park.gpx	0.00				USA
27	2	0.00	0	0.00	2	 		/static/gpx/021__.gpx	0.00				USA
28	2	0.00	0	0.00	2	Proposed Trail		/static/gpx/022_Proposed_Trail.gpx	0.00				USA
29	2	0.00	0	0.00	2	Blinnshed Ridge Trail		/static/gpx/023_Blinnshed_Ridge_Trail.gpx	0.00				USA
30	2	0.00	0	0.00	2	Neck River Trail		/static/gpx/024_Neck_River_Trail.gpx	0.00				USA
31	2	0.00	0	0.00	2	Unnamed Trail		/static/gpx/025_Unnamed_Trail.gpx	0.00				USA
32	2	0.00	0	0.00	2	Oil Mill Brook Trail		/static/gpx/026_Oil_Mill_Brook_Trail.gpx	0.00				USA
33	2	0.00	0	0.00	2	Chatfield Trail		/static/gpx/027_Chatfield_Trail.gpx	0.00				USA
34	2	0.00	0	0.00	2	Unamed Trail		/static/gpx/028_Unamed_Trail.gpx	0.00				USA
35	2	0.00	0	0.00	2	Lost Pond Trail		/static/gpx/029_Lost_Pond_Trail.gpx	0.00				USA
36	2	0.00	0	0.00	2	Ccc Camp Hadley Trail		/static/gpx/030_Ccc_Camp_Hadley_Trail.gpx	0.00				USA
37	2	0.00	0	0.00	2	Double Loop Trail		/static/gpx/031_Double_Loop_Trail.gpx	0.00				USA
38	2	0.00	0	0.00	2	Over Brook Trail		/static/gpx/032_Over_Brook_Trail.gpx	0.00				USA
39	2	0.00	0	0.00	2	Cockaponset Forest Trail		/static/gpx/033_Cockaponset_Forest_Trail.gpx	0.00				USA
40	2	0.00	0	0.00	2	Pattaconk Trail		/static/gpx/034_Pattaconk_Trail.gpx	0.00				USA
41	2	0.00	0	0.00	2	Westwoods Forest Trail		/static/gpx/035_Westwoods_Forest_Trail.gpx	0.00				USA
42	2	0.00	0	0.00	2	Blinnshed Loop Trail		/static/gpx/036_Blinnshed_Loop_Trail.gpx	0.00				USA
43	2	0.00	0	0.00	2	Unnamed Tsail		/static/gpx/037_Unnamed_Tsail.gpx	0.00				USA
44	2	0.00	0	0.00	2	Messerschmidt Wma Trail		/static/gpx/038_Messerschmidt_Wma_Trail.gpx	0.00				USA
45	2	0.00	0	0.00	2	Westwoods Nature Trail		/static/gpx/039_Westwoods_Nature_Trail.gpx	0.00				USA
46	2	0.00	0	0.00	2	Enduro		/static/gpx/040_Enduro.gpx	0.00				USA
47	2	0.00	0	0.00	2	Land Trust Trail		/static/gpx/041_Land_Trust_Trail.gpx	0.00				USA
48	2	0.00	0	0.00	0	Beaver Brook Park Trail		/static/gpx/042_Beaver_Brook_Park_Trail.gpx	0.00				USA
49	2	0.00	0	0.00	1	Housatonic Forest Trail		/static/gpx/043_Housatonic_Forest_Trail.gpx	0.00				USA
50	2	0.00	0	0.00	2	Farmington Canal Trail		/static/gpx/044_Farmington_Canal_Trail.gpx	0.00				USA
51	2	0.00	0	0.00	0	Beckley Furnace Park Path		/static/gpx/045_Beckley_Furnace_Park_Path.gpx	0.00				USA
52	2	0.00	0	0.00	2	Farmington River Trail		/static/gpx/046_Farmington_River_Trail.gpx	0.00				USA
53	2	0.00	0	0.00	0	Farminton Canal Trail		/static/gpx/047_Farminton_Canal_Trail.gpx	0.00				USA
54	2	0.00	0	0.00	2	Farminton River Trail		/static/gpx/048_Farminton_River_Trail.gpx	0.00				USA
55	2	0.00	0	0.00	2	Hop River Trail		/static/gpx/049_Hop_River_Trail.gpx	0.00				USA
56	2	0.00	0	0.00	2	Hoprivertrail - Detouraround316		/static/gpx/050_Hoprivertrail___Detouraround316.gpx	0.00				USA
57	2	0.00	0	0.00	1	Hop River Trail - Long Hill Rd.		/static/gpx/051_Hop_River_Trail___Long_Hill_Rd_.gpx	0.00				USA
58	2	0.00	0	0.00	2	Hop River Trail - Rockville Spur		/static/gpx/052_Hop_River_Trail___Rockville_Spur.gpx	0.00				USA
59	2	0.00	0	0.00	2	Housatonic Rail Trail		/static/gpx/053_Housatonic_Rail_Trail.gpx	0.00				USA
60	2	0.00	0	0.00	2	Middletown Bikeway		/static/gpx/054_Middletown_Bikeway.gpx	0.00				USA
61	2	0.00	0	0.00	2	Mattabesett Trolley Trail		/static/gpx/055_Mattabesett_Trolley_Trail.gpx	0.00				USA
62	2	0.00	0	0.00	2	Moosup Valley State Park Trail		/static/gpx/056_Moosup_Valley_State_Park_Trail.gpx	0.00				USA
63	2	0.00	0	0.00	2	Quinnebaug River Trail		/static/gpx/057_Quinnebaug_River_Trail.gpx	0.00				USA
64	2	0.00	0	0.00	0	Tracey Road Trail		/static/gpx/058_Tracey_Road_Trail.gpx	0.00				USA
65	2	0.00	0	0.00	0	Trolley Trail		/static/gpx/059_Trolley_Trail.gpx	0.00				USA
66	2	0.00	0	0.00	2	Quinnebaug Hatchery Trail		/static/gpx/060_Quinnebaug_Hatchery_Trail.gpx	0.00				USA
67	2	0.00	0	0.00	2	Hopeville Park Trail		/static/gpx/061_Hopeville_Park_Trail.gpx	0.00				USA
68	2	0.00	0	0.00	2	Hopeville Park Path		/static/gpx/062_Hopeville_Park_Path.gpx	0.00				USA
69	2	0.00	0	0.00	2	Nehantic Trail		/static/gpx/063_Nehantic_Trail.gpx	0.00				USA
70	2	0.00	0	0.00	2	Camp Columbia Trail		/static/gpx/064_Camp_Columbia_Trail.gpx	0.00				USA
71	2	0.00	0	0.00	1	Shelton Land Trust Trail		/static/gpx/065_Shelton_Land_Trust_Trail.gpx	0.00				USA
72	2	0.00	0	0.00	0	Dinosaur Park Sidewalk		/static/gpx/066_Dinosaur_Park_Sidewalk.gpx	0.00				USA
73	2	0.00	0	0.00	2	Dinosaur Park Trail		/static/gpx/067_Dinosaur_Park_Trail.gpx	0.00				USA
74	2	0.00	0	0.00	0	Access Road		/static/gpx/068_Access_Road.gpx	0.00				USA
75	2	0.00	0	0.00	0	Day Pond Park Path		/static/gpx/069_Day_Pond_Park_Path.gpx	0.00				USA
76	2	0.00	0	0.00	1	Day Pond Park Trail		/static/gpx/070_Day_Pond_Park_Trail.gpx	0.00				USA
77	2	0.00	0	0.00	0	Salmon River Trail		/static/gpx/071_Salmon_River_Trail.gpx	0.00				USA
78	2	0.00	0	0.00	2	Salmon River Trial		/static/gpx/072_Salmon_River_Trial.gpx	0.00				USA
79	2	0.00	0	0.00	2	Dennis Hill Park Trail		/static/gpx/073_Dennis_Hill_Park_Trail.gpx	0.00				USA
80	2	0.00	0	0.00	0	Railroad Trail		/static/gpx/074_Railroad_Trail.gpx	0.00				USA
81	2	0.00	0	0.00	1	Gillette Castle Trail		/static/gpx/075_Gillette_Castle_Trail.gpx	0.00				USA
82	2	0.00	0	0.00	1	Kent Falls Park Path		/static/gpx/076_Kent_Falls_Park_Path.gpx	0.00				USA
83	2	0.00	0	0.00	0	Kent Falls Park Trail		/static/gpx/077_Kent_Falls_Park_Trail.gpx	0.00				USA
84	2	0.00	0	0.00	1	Lovers Leap Park Trail		/static/gpx/078_Lovers_Leap_Park_Trail.gpx	0.00				USA
85	2	0.00	0	0.00	1	Enders Forest Trail		/static/gpx/079_Enders_Forest_Trail.gpx	0.00				USA
86	2	0.00	0	0.00	0	Gay City Park Path		/static/gpx/080_Gay_City_Park_Path.gpx	0.00				USA
87	2	0.00	0	0.00	1	Gay City Park Trail		/static/gpx/081_Gay_City_Park_Trail.gpx	0.00				USA
88	2	0.00	0	0.00	1	Split Rock Trail		/static/gpx/082_Split_Rock_Trail.gpx	0.00				USA
89	2	0.00	0	0.00	0	Gillette Castle Path		/static/gpx/083_Gillette_Castle_Path.gpx	0.00				USA
90	2	0.00	0	0.00	0	Great Pond Forest Trail		/static/gpx/084_Great_Pond_Forest_Trail.gpx	0.00				USA
91	2	0.00	0	0.00	0	Haddam Meadows Park Trail		/static/gpx/085_Haddam_Meadows_Park_Trail.gpx	0.00				USA
92	2	0.00	0	0.00	2	Haley Farm Park Trail		/static/gpx/086_Haley_Farm_Park_Trail.gpx	0.00				USA
93	2	0.00	0	0.00	0	Hammonasset Park Path		/static/gpx/087_Hammonasset_Park_Path.gpx	0.00				USA
94	2	0.00	0	0.00	1	Nature Trail		/static/gpx/088_Nature_Trail.gpx	0.00				USA
95	2	0.00	0	0.00	1	Hammonasset Bike Path		/static/gpx/089_Hammonasset_Bike_Path.gpx	0.00				USA
96	2	0.00	0	0.00	0	Hammonasset Park Boardwalk		/static/gpx/090_Hammonasset_Park_Boardwalk.gpx	0.00				USA
97	2	0.00	0	0.00	0	Meigs Point Jetty		/static/gpx/091_Meigs_Point_Jetty.gpx	0.00				USA
98	2	0.00	0	0.00	0	Willard Island Nature Trail		/static/gpx/092_Willard_Island_Nature_Trail.gpx	0.00				USA
99	2	0.00	0	0.00	2	Moraine Nature Trail		/static/gpx/093_Moraine_Nature_Trail.gpx	0.00				USA
100	2	0.00	0	0.00	0	Haystack Park Trail		/static/gpx/094_Haystack_Park_Trail.gpx	0.00				USA
101	2	0.00	0	0.00	1	Higganum Reservoir Park Trail		/static/gpx/095_Higganum_Reservoir_Park_Trail.gpx	0.00				USA
102	2	0.00	0	0.00	0	Appalachian Trail		/static/gpx/096_Appalachian_Trail.gpx	0.00				USA
103	2	0.00	0	0.00	2	Mohawk Trail		/static/gpx/097_Mohawk_Trail.gpx	0.00				USA
104	2	0.00	0	0.00	2	Pine Knob Loop		/static/gpx/098_Pine_Knob_Loop.gpx	0.00				USA
105	2	0.00	0	0.00	0	Appalachian/Pine Knob Loop		/static/gpx/099_Appalachian_Pine_Knob_Loop.gpx	0.00				USA
106	2	0.00	0	0.00	1	White Mountain Trail		/static/gpx/100_White_Mountain_Trail.gpx	0.00				USA
107	2	0.00	0	0.00	1	River Trail		/static/gpx/101_River_Trail.gpx	0.00				USA
108	2	0.00	0	0.00	2	Hurd Park Trail		/static/gpx/102_Hurd_Park_Trail.gpx	0.00				USA
109	2	0.00	0	0.00	1	Hurd Park Path		/static/gpx/103_Hurd_Park_Path.gpx	0.00				USA
110	2	0.00	0	0.00	2	Paugussett Trail		/static/gpx/104_Paugussett_Trail.gpx	0.00				USA
111	2	0.00	0	0.00	0	Waterfall Trail		/static/gpx/105_Waterfall_Trail.gpx	0.00				USA
112	2	0.00	0	0.00	1	Paugussett Trail Connector		/static/gpx/106_Paugussett_Trail_Connector.gpx	0.00				USA
113	2	0.00	0	0.00	2	Minetto Park Trail		/static/gpx/107_Minetto_Park_Trail.gpx	0.00				USA
114	2	0.00	0	0.00	2	Coincident Macedonia Brook Rd		/static/gpx/108_Coincident_Macedonia_Brook_Rd.gpx	0.00				USA
115	2	0.00	0	0.00	1	Coincident Weber Road		/static/gpx/109_Coincident_Weber_Road.gpx	0.00				USA
116	2	0.00	0	0.00	2	Macedonia Ridge Trail		/static/gpx/110_Macedonia_Ridge_Trail.gpx	0.00				USA
117	2	0.00	0	0.00	2	Cobble Mountain Trail		/static/gpx/111_Cobble_Mountain_Trail.gpx	0.00				USA
118	2	0.00	0	0.00	0	Shenipsit Trail		/static/gpx/112_Shenipsit_Trail.gpx	0.00				USA
119	2	0.00	0	0.00	2	Meshomasic Forest Trail		/static/gpx/113_Meshomasic_Forest_Trail.gpx	0.00				USA
120	2	0.00	0	0.00	2	Crest Trail		/static/gpx/114_Crest_Trail.gpx	0.00				USA
121	2	0.00	0	0.00	1	Campground Trail		/static/gpx/115_Campground_Trail.gpx	0.00				USA
122	2	0.00	0	0.00	1	Brook Trail		/static/gpx/116_Brook_Trail.gpx	0.00				USA
123	2	0.00	0	0.00	1	Kettletown Park Trail		/static/gpx/117_Kettletown_Park_Trail.gpx	0.00				USA
124	2	0.00	0	0.00	2	North Ridge Trail		/static/gpx/118_North_Ridge_Trail.gpx	0.00				USA
125	2	0.00	0	0.00	1	North Ridge Loop Trail		/static/gpx/119_North_Ridge_Loop_Trail.gpx	0.00				USA
126	2	0.00	0	0.00	0	Miller Brook Connector Trail		/static/gpx/120_Miller_Brook_Connector_Trail.gpx	0.00				USA
127	2	0.00	0	0.00	2	Miller Trail		/static/gpx/121_Miller_Trail.gpx	0.00				USA
128	2	0.00	0	0.00	2	Miller Trail Spur		/static/gpx/122_Miller_Trail_Spur.gpx	0.00				USA
129	2	0.00	0	0.00	1	Pomperaug Trail		/static/gpx/123_Pomperaug_Trail.gpx	0.00				USA
130	2	0.00	0	0.00	1	Brook Trail Access		/static/gpx/124_Brook_Trail_Access.gpx	0.00				USA
131	2	0.00	0	0.00	0	Waramaug Lake Park Trail		/static/gpx/125_Waramaug_Lake_Park_Trail.gpx	0.00				USA
132	2	0.00	0	0.00	0	Well Groomed Trail		/static/gpx/126_Well_Groomed_Trail.gpx	0.00				USA
133	2	0.00	0	0.00	1	Mashamoquet Brook Park Trail		/static/gpx/127_Mashamoquet_Brook_Park_Trail.gpx	0.00				USA
134	2	0.00	0	0.00	1	Shenipsit Trail Spur		/static/gpx/128_Shenipsit_Trail_Spur.gpx	0.00				USA
135	2	0.00	0	0.00	0	Shenipsit		/static/gpx/129_Shenipsit.gpx	0.00				USA
136	2	0.00	0	0.00	0	Nassahegon Forest Trail		/static/gpx/130_Nassahegon_Forest_Trail.gpx	0.00				USA
137	2	0.00	0	0.00	1	Tunxis Trail		/static/gpx/131_Tunxis_Trail.gpx	0.00				USA
138	2	0.00	0	0.00	0	Black Spruce Bog Trail		/static/gpx/132_Black_Spruce_Bog_Trail.gpx	0.00				USA
139	2	0.00	0	0.00	2	Mohawk Forest Trail		/static/gpx/133_Mohawk_Forest_Trail.gpx	0.00				USA
140	2	0.00	0	0.00	2	Ethan Allen Youth Trail		/static/gpx/134_Ethan_Allen_Youth_Trail.gpx	0.00				USA
141	2	0.00	0	0.00	0	Punch Brook Trail		/static/gpx/135_Punch_Brook_Trail.gpx	0.00				USA
142	2	0.00	0	0.00	0	Red Cedar Lake Trail		/static/gpx/136_Red_Cedar_Lake_Trail.gpx	0.00				USA
143	2	0.00	0	0.00	0	Under Mountain Trail		/static/gpx/137_Under_Mountain_Trail.gpx	0.00				USA
144	2	0.00	0	0.00	1	Mount Tom Trail		/static/gpx/138_Mount_Tom_Trail.gpx	0.00				USA
145	2	0.00	0	0.00	2	Naugatuck Trail		/static/gpx/139_Naugatuck_Trail.gpx	0.00				USA
146	2	0.00	0	0.00	1	Nehantic Forest Trail		/static/gpx/140_Nehantic_Forest_Trail.gpx	0.00				USA
147	2	0.00	0	0.00	2	Naugatuck Forest Trail		/static/gpx/141_Naugatuck_Forest_Trail.gpx	0.00				USA
148	2	0.00	0	0.00	2	Naugatuck Spur		/static/gpx/142_Naugatuck_Spur.gpx	0.00				USA
149	2	0.00	0	0.00	1	Whitemore Trail		/static/gpx/143_Whitemore_Trail.gpx	0.00				USA
150	2	0.00	0	0.00	1	Quinnipiac Trail		/static/gpx/144_Quinnipiac_Trail.gpx	0.00				USA
151	2	0.00	0	0.00	2	Nehantic Forest Trai		/static/gpx/145_Nehantic_Forest_Trai.gpx	0.00				USA
152	2	0.00	0	0.00	2	Nepaug Forest Trail		/static/gpx/146_Nepaug_Forest_Trail.gpx	0.00				USA
153	2	0.00	0	0.00	1	Naugatuck		/static/gpx/147_Naugatuck.gpx	0.00				USA
154	2	0.00	0	0.00	2	Nyantaquit Trail		/static/gpx/148_Nyantaquit_Trail.gpx	0.00				USA
155	2	0.00	0	0.00	1	Tipping Rock Loop Trail		/static/gpx/149_Tipping_Rock_Loop_Trail.gpx	0.00				USA
156	2	0.00	0	0.00	2	Valley Outlook Trail		/static/gpx/150_Valley_Outlook_Trail.gpx	0.00				USA
157	2	0.00	0	0.00	1	Shelter 4 Loop Trail		/static/gpx/151_Shelter_4_Loop_Trail.gpx	0.00				USA
158	2	0.00	0	0.00	0	Osbornedale Park Trail		/static/gpx/152_Osbornedale_Park_Trail.gpx	0.00				USA
159	2	0.00	0	0.00	1	Unnamed		/static/gpx/153_Unnamed.gpx	0.00				USA
160	2	0.00	0	0.00	1	Paugnut Forest Trail		/static/gpx/154_Paugnut_Forest_Trail.gpx	0.00				USA
161	2	0.00	0	0.00	0	Charles L Pack Trail		/static/gpx/155_Charles_L_Pack_Trail.gpx	0.00				USA
162	2	0.00	0	0.00	2	Peoples Forest Trail		/static/gpx/156_Peoples_Forest_Trail.gpx	0.00				USA
163	2	0.00	0	0.00	2	Putnam Memorial Trail		/static/gpx/157_Putnam_Memorial_Trail.gpx	0.00				USA
164	2	0.00	0	0.00	1	Platt Hill Park Trail		/static/gpx/158_Platt_Hill_Park_Trail.gpx	0.00				USA
165	2	0.00	0	0.00	2	Metacomet Trail		/static/gpx/159_Metacomet_Trail.gpx	0.00				USA
166	2	0.00	0	0.00	0	Metacomet Trail Bypass		/static/gpx/160_Metacomet_Trail_Bypass.gpx	0.00				USA
167	2	0.00	0	0.00	0	Penwood Park Trail		/static/gpx/161_Penwood_Park_Trail.gpx	0.00				USA
168	2	0.00	0	0.00	2	Quadick Park Path		/static/gpx/162_Quadick_Park_Path.gpx	0.00				USA
169	2	0.00	0	0.00	1	Quadick Red Trail		/static/gpx/163_Quadick_Red_Trail.gpx	0.00				USA
170	2	0.00	0	0.00	2	Pootatuck Forest Trail		/static/gpx/164_Pootatuck_Forest_Trail.gpx	0.00				USA
171	2	0.00	0	0.00	2	River Highland Park Trail		/static/gpx/165_River_Highland_Park_Trail.gpx	0.00				USA
172	2	0.00	0	0.00	1	Tunxis		/static/gpx/166_Tunxis.gpx	0.00				USA
173	2	0.00	0	0.00	0	Old Furnace Trail		/static/gpx/167_Old_Furnace_Trail.gpx	0.00				USA
174	2	0.00	0	0.00	2	Old Furnace Park Trail		/static/gpx/168_Old_Furnace_Park_Trail.gpx	0.00				USA
175	2	0.00	0	0.00	0	Kestral Trail		/static/gpx/169_Kestral_Trail.gpx	0.00				USA
176	2	0.00	0	0.00	2	Warbler Trail		/static/gpx/170_Warbler_Trail.gpx	0.00				USA
177	2	0.00	0	0.00	2	Muir Trail		/static/gpx/171_Muir_Trail.gpx	0.00				USA
178	2	0.00	0	0.00	0	Shadow Pond Nature Trail		/static/gpx/172_Shadow_Pond_Nature_Trail.gpx	0.00				USA
179	2	0.00	0	0.00	0	Jesse Gerard Trail		/static/gpx/173_Jesse_Gerard_Trail.gpx	0.00				USA
180	2	0.00	0	0.00	1	Robert Ross Trail		/static/gpx/174_Robert_Ross_Trail.gpx	0.00				USA
181	2	0.00	0	0.00	0	Agnes Bowen Trail		/static/gpx/175_Agnes_Bowen_Trail.gpx	0.00				USA
182	2	0.00	0	0.00	0	Elliot Bronson Trail		/static/gpx/176_Elliot_Bronson_Trail.gpx	0.00				USA
183	2	0.00	0	0.00	1	Walt Landgraf Trail		/static/gpx/177_Walt_Landgraf_Trail.gpx	0.00				USA
184	2	0.00	0	0.00	0	Squantz Pond Park Trail		/static/gpx/178_Squantz_Pond_Park_Trail.gpx	0.00				USA
185	2	0.00	0	0.00	2	Putnam Memorial Museum Trail		/static/gpx/179_Putnam_Memorial_Museum_Trail.gpx	0.00				USA
186	2	0.00	0	0.00	0	Quinnipiac Park Trail		/static/gpx/180_Quinnipiac_Park_Trail.gpx	0.00				USA
187	2	0.00	0	0.00	2	Boardwalk		/static/gpx/181_Boardwalk.gpx	0.00				USA
188	2	0.00	0	0.00	2	Rocky Neck Park Sidewalk		/static/gpx/182_Rocky_Neck_Park_Sidewalk.gpx	0.00				USA
189	2	0.00	0	0.00	2	Rocky Neck Park Path		/static/gpx/183_Rocky_Neck_Park_Path.gpx	0.00				USA
190	2	0.00	0	0.00	1	Rocky Neck Park Trail		/static/gpx/184_Rocky_Neck_Park_Trail.gpx	0.00				USA
191	2	0.00	0	0.00	0	Rope Swing		/static/gpx/185_Rope_Swing.gpx	0.00				USA
192	2	0.00	0	0.00	0	Sherwood Island Park Path		/static/gpx/186_Sherwood_Island_Park_Path.gpx	0.00				USA
193	2	0.00	0	0.00	2	Sleeping Giant Park Trail		/static/gpx/187_Sleeping_Giant_Park_Trail.gpx	0.00				USA
194	2	0.00	0	0.00	0	Sherwood Island Nature Trail		/static/gpx/188_Sherwood_Island_Nature_Trail.gpx	0.00				USA
195	2	0.00	0	0.00	2	Sleeping Giant Park Path		/static/gpx/189_Sleeping_Giant_Park_Path.gpx	0.00				USA
196	2	0.00	0	0.00	2	Tower Trail		/static/gpx/190_Tower_Trail.gpx	0.00				USA
197	2	0.00	0	0.00	2	Quinnipiac Trail Spur		/static/gpx/191_Quinnipiac_Trail_Spur.gpx	0.00				USA
198	2	0.00	0	0.00	2	Southford Falls Park Trail		/static/gpx/192_Southford_Falls_Park_Trail.gpx	0.00				USA
199	2	0.00	0	0.00	2	Tunxis Forest Trail		/static/gpx/193_Tunxis_Forest_Trail.gpx	0.00				USA
200	2	0.00	0	0.00	2	Sleeping Giant Trail		/static/gpx/194_Sleeping_Giant_Trail.gpx	0.00				USA
201	2	0.00	0	0.00	0	Stratton Brook Park Path		/static/gpx/195_Stratton_Brook_Park_Path.gpx	0.00				USA
202	2	0.00	0	0.00	1	Bike Trail		/static/gpx/196_Bike_Trail.gpx	0.00				USA
203	2	0.00	0	0.00	1	Stratton Brook Park Trail		/static/gpx/197_Stratton_Brook_Park_Trail.gpx	0.00				USA
204	2	0.00	0	0.00	1	Simsbury Park Trail		/static/gpx/198_Simsbury_Park_Trail.gpx	0.00				USA
205	2	0.00	0	0.00	0	Wolcott Trail		/static/gpx/199_Wolcott_Trail.gpx	0.00				USA
206	2	0.00	0	0.00	0	Madden Fyler Pond Trail		/static/gpx/200_Madden_Fyler_Pond_Trail.gpx	0.00				USA
207	2	0.00	0	0.00	0	Sunny Brook Park Trail		/static/gpx/201_Sunny_Brook_Park_Trail.gpx	0.00				USA
208	2	0.00	0	0.00	2	Fadoir Spring Trail		/static/gpx/202_Fadoir_Spring_Trail.gpx	0.00				USA
209	2	0.00	0	0.00	0	Fadoir Trail		/static/gpx/203_Fadoir_Trail.gpx	0.00				USA
210	2	0.00	0	0.00	1	Walnut Mountain Trail		/static/gpx/204_Walnut_Mountain_Trail.gpx	0.00				USA
211	2	0.00	0	0.00	0	Wolcott		/static/gpx/205_Wolcott.gpx	0.00				USA
212	2	0.00	0	0.00	1	Old Metacomet Trail		/static/gpx/206_Old_Metacomet_Trail.gpx	0.00				USA
213	2	0.00	0	0.00	1	Talcott Mountain Park Trail		/static/gpx/207_Talcott_Mountain_Park_Trail.gpx	0.00				USA
214	2	0.00	0	0.00	2	Falls Brook Trail		/static/gpx/208_Falls_Brook_Trail.gpx	0.00				USA
215	2	0.00	0	0.00	2	Whittemore Glen Trail		/static/gpx/209_Whittemore_Glen_Trail.gpx	0.00				USA
216	2	0.00	0	0.00	0	Wharton Brook Park Trail		/static/gpx/210_Wharton_Brook_Park_Trail.gpx	0.00				USA
217	2	0.00	0	0.00	1	Larkin Bridle Trail		/static/gpx/211_Larkin_Bridle_Trail.gpx	0.00				USA
218	2	0.00	0	0.00	0	Bluff Point Bike Path		/static/gpx/212_Bluff_Point_Bike_Path.gpx	0.00				USA
219	2	0.00	0	0.00	2	Bluff Point Trail		/static/gpx/213_Bluff_Point_Trail.gpx	0.00				USA
220	2	0.00	0	0.00	2	Hrt - Main Street Spur		/static/gpx/214_Hrt___Main_Street_Spur.gpx	0.00				USA
221	2	0.00	0	0.00	2	Laurel Brook Trail		/static/gpx/215_Laurel_Brook_Trail.gpx	0.00				USA
222	2	0.00	0	0.00	2	Wadsworth Falls Park Trail		/static/gpx/216_Wadsworth_Falls_Park_Trail.gpx	0.00				USA
223	2	0.00	0	0.00	2	White Birch Trail		/static/gpx/217_White_Birch_Trail.gpx	0.00				USA
224	2	0.00	0	0.00	2	Red Cedar Trail		/static/gpx/218_Red_Cedar_Trail.gpx	0.00				USA
225	2	0.00	0	0.00	2	Little Falls Trail		/static/gpx/219_Little_Falls_Trail.gpx	0.00				USA
226	2	0.00	0	0.00	2	Deer Trail		/static/gpx/220_Deer_Trail.gpx	0.00				USA
227	2	0.00	0	0.00	2	Rockfall Land Trust Trail		/static/gpx/221_Rockfall_Land_Trust_Trail.gpx	0.00				USA
228	2	0.00	0	0.00	2	Bridge Trail		/static/gpx/222_Bridge_Trail.gpx	0.00				USA
229	2	0.00	0	0.00	2	Main Trail		/static/gpx/223_Main_Trail.gpx	0.00				USA
230	2	0.00	0	0.00	2	American Legion Forest Trail		/static/gpx/224_American_Legion_Forest_Trail.gpx	0.00				USA
231	2	0.00	0	0.00	2	Turkey Vultures Ledges Trail		/static/gpx/225_Turkey_Vultures_Ledges_Trail.gpx	0.00				USA
232	2	0.00	0	0.00	2	Henry R Buck Trail		/static/gpx/226_Henry_R_Buck_Trail.gpx	0.00				USA
233	2	0.00	0	0.00	2	Mashapaug Pond View Trail		/static/gpx/227_Mashapaug_Pond_View_Trail.gpx	0.00				USA
234	2	0.00	0	0.00	2	Bigelow Hollow Park Trail		/static/gpx/228_Bigelow_Hollow_Park_Trail.gpx	0.00				USA
235	2	0.00	0	0.00	2	Breakneck Pond View Trail		/static/gpx/229_Breakneck_Pond_View_Trail.gpx	0.00				USA
236	2	0.00	0	0.00	2	East Ridge Trail		/static/gpx/230_East_Ridge_Trail.gpx	0.00				USA
237	2	0.00	0	0.00	2	Bigelow Pond Loop Trail		/static/gpx/231_Bigelow_Pond_Loop_Trail.gpx	0.00				USA
238	2	0.00	0	0.00	2	Ridge Trail		/static/gpx/232_Ridge_Trail.gpx	0.00				USA
239	2	0.00	0	0.00	2	Nipmuck Trail		/static/gpx/233_Nipmuck_Trail.gpx	0.00				USA
240	2	0.00	0	0.00	2	Mattatuck Trail		/static/gpx/234_Mattatuck_Trail.gpx	0.00				USA
241	2	0.00	0	0.00	2	Black Rock Park Trail		/static/gpx/235_Black_Rock_Park_Trail.gpx	0.00				USA
242	2	0.00	0	0.00	2	Poquonnock River Walk		/static/gpx/236_Poquonnock_River_Walk.gpx	0.00				USA
243	2	0.00	0	0.00	1	Kempf & Shenipsit Trail		/static/gpx/237_Kempf___Shenipsit_Trail.gpx	0.00				USA
244	2	0.00	0	0.00	0	Kempf Trail		/static/gpx/238_Kempf_Trail.gpx	0.00				USA
245	2	0.00	0	0.00	2	Railroad Bed		/static/gpx/239_Railroad_Bed.gpx	0.00				USA
246	2	0.00	0	0.00	1	Mohegan Trail		/static/gpx/240_Mohegan_Trail.gpx	0.00				USA
247	2	0.00	0	0.00	2	Burr Pond Park Trail		/static/gpx/241_Burr_Pond_Park_Trail.gpx	0.00				USA
248	2	0.00	0	0.00	1	Burr Pond Park Path		/static/gpx/242_Burr_Pond_Park_Path.gpx	0.00				USA
249	2	0.00	0	0.00	0	Campbell Falls Trail		/static/gpx/243_Campbell_Falls_Trail.gpx	0.00				USA
250	2	0.00	0	0.00	2	Deep Woods Trail		/static/gpx/244_Deep_Woods_Trail.gpx	0.00				USA
251	2	0.00	0	0.00	2	Chimney Trail		/static/gpx/245_Chimney_Trail.gpx	0.00				USA
252	2	0.00	0	0.00	2	Chimney Connector Trail		/static/gpx/246_Chimney_Connector_Trail.gpx	0.00				USA
253	2	0.00	0	0.00	2	East Woods Trail		/static/gpx/247_East_Woods_Trail.gpx	0.00				USA
254	2	0.00	0	0.00	2	East Woods Connector Trail		/static/gpx/248_East_Woods_Connector_Trail.gpx	0.00				USA
255	2	0.00	0	0.00	2	Covered Bridge Connector Trail		/static/gpx/249_Covered_Bridge_Connector_Trail.gpx	0.00				USA
256	2	0.00	0	0.00	2	Covered Bridge Trail		/static/gpx/250_Covered_Bridge_Trail.gpx	0.00				USA
257	2	0.00	0	0.00	2	Lookout Trail		/static/gpx/251_Lookout_Trail.gpx	0.00				USA
258	2	0.00	0	0.00	2	Chatfield Hollow Park Trail		/static/gpx/252_Chatfield_Hollow_Park_Trail.gpx	0.00				USA
259	2	0.00	0	0.00	2	Lookout Spur Trail		/static/gpx/253_Lookout_Spur_Trail.gpx	0.00				USA
260	2	0.00	0	0.00	2	Chimney Spur Trail		/static/gpx/254_Chimney_Spur_Trail.gpx	0.00				USA
261	2	0.00	0	0.00	2	Deep Woods Access Trail		/static/gpx/255_Deep_Woods_Access_Trail.gpx	0.00				USA
262	2	0.00	0	0.00	2	West Crest Trail		/static/gpx/256_West_Crest_Trail.gpx	0.00				USA
263	2	0.00	0	0.00	2	Chatfield Park Path		/static/gpx/257_Chatfield_Park_Path.gpx	0.00				USA
264	2	0.00	0	0.00	2	Pond Trail		/static/gpx/258_Pond_Trail.gpx	0.00				USA
265	2	0.00	0	0.00	0	Paul F Wildermann		/static/gpx/259_Paul_F_Wildermann.gpx	0.00				USA
266	2	0.00	0	0.00	2	Cockaponset Forest Path		/static/gpx/260_Cockaponset_Forest_Path.gpx	0.00				USA
267	2	0.00	0	0.00	2	Kay Fullerton Trail		/static/gpx/261_Kay_Fullerton_Trail.gpx	0.00				USA
268	2	0.00	0	0.00	0	Quinimay Trail		/static/gpx/262_Quinimay_Trail.gpx	0.00				USA
269	2	0.00	0	0.00	2	Cowboy Way Trail		/static/gpx/263_Cowboy_Way_Trail.gpx	0.00				USA
270	2	0.00	0	0.00	2	Muck Rock Road Trail		/static/gpx/264_Muck_Rock_Road_Trail.gpx	0.00				USA
271	2	0.00	0	0.00	2	Weber Road Trail		/static/gpx/265_Weber_Road_Trail.gpx	0.00				USA
272	2	0.00	0	0.00	2	Beechnut Bog Trail		/static/gpx/266_Beechnut_Bog_Trail.gpx	0.00				USA
273	2	0.00	0	0.00	2	Wood Road Trail		/static/gpx/267_Wood_Road_Trail.gpx	0.00				USA
274	2	0.00	0	0.00	2	Bumpy Hill Road Trail		/static/gpx/268_Bumpy_Hill_Road_Trail.gpx	0.00				USA
275	2	0.00	0	0.00	2	Kristens Way Trail		/static/gpx/269_Kristens_Way_Trail.gpx	0.00				USA
276	2	0.00	0	0.00	2	Messerschmidt Lane Trail		/static/gpx/270_Messerschmidt_Lane_Trail.gpx	0.00				USA
277	2	0.00	0	0.00	2	Tower Hill Connector Trail		/static/gpx/271_Tower_Hill_Connector_Trail.gpx	0.00				USA
278	2	0.00	0	0.00	2	Mattabesset Trail		/static/gpx/272_Mattabesset_Trail.gpx	0.00				USA
279	2	0.00	0	0.00	2	Mattabasset Trail		/static/gpx/273_Mattabasset_Trail.gpx	0.00				USA
280	2	0.00	0	0.00	2	Old Mattebesset Trail		/static/gpx/274_Old_Mattebesset_Trail.gpx	0.00				USA
281	2	0.00	0	0.00	2	Huntington Park Trail		/static/gpx/275_Huntington_Park_Trail.gpx	0.00				USA
282	2	0.00	0	0.00	2	Huntington Ridge Trail		/static/gpx/276_Huntington_Ridge_Trail.gpx	0.00				USA
283	2	0.00	0	0.00	2	Aspetuck Valley Trail		/static/gpx/277_Aspetuck_Valley_Trail.gpx	0.00				USA
284	2	0.00	0	0.00	2	Vista Trail		/static/gpx/278_Vista_Trail.gpx	0.00				USA
285	2	0.00	0	0.00	2	Devils Hopyard Park Trail		/static/gpx/279_Devils_Hopyard_Park_Trail.gpx	0.00				USA
286	2	0.00	0	0.00	2	Witch Hazel/Millington Trail		/static/gpx/280_Witch_Hazel_Millington_Trail.gpx	0.00				USA
287	2	0.00	0	0.00	2	Millington Trail		/static/gpx/281_Millington_Trail.gpx	0.00				USA
288	2	0.00	0	0.00	2	Loop Trail		/static/gpx/282_Loop_Trail.gpx	0.00				USA
289	2	0.00	0	0.00	2	Witch Hazel Trail		/static/gpx/283_Witch_Hazel_Trail.gpx	0.00				USA
290	2	0.00	0	0.00	2	Woodcutters Trail		/static/gpx/284_Woodcutters_Trail.gpx	0.00				USA
291	2	0.00	0	0.00	2	Chapman Falls Trail		/static/gpx/285_Chapman_Falls_Trail.gpx	0.00				USA
292	2	0.00	0	0.00	2	Devils Oven Spur Trail		/static/gpx/286_Devils_Oven_Spur_Trail.gpx	0.00				USA
293	2	0.00	0	0.00	2	Maxs Trail		/static/gpx/287_Maxs_Trail.gpx	0.00				USA
294	2	0.00	0	0.00	1	Machimoodus Park Trail		/static/gpx/288_Machimoodus_Park_Trail.gpx	0.00				USA
295	2	0.00	0	0.00	0	Fishermans Trail		/static/gpx/289_Fishermans_Trail.gpx	0.00				USA
296	2	0.00	0	0.00	2	Ccc Trail		/static/gpx/290_Ccc_Trail.gpx	0.00				USA
297	2	0.00	0	0.00	2	Natchaug Trail		/static/gpx/291_Natchaug_Trail.gpx	0.00				USA
298	2	0.00	0	0.00	2	Natchaug Forest Trail		/static/gpx/292_Natchaug_Forest_Trail.gpx	0.00				USA
299	2	0.00	0	0.00	2	Goodwin Forest Trail		/static/gpx/293_Goodwin_Forest_Trail.gpx	0.00				USA
300	2	0.00	0	0.00	2	Pine Acres Pond Trail		/static/gpx/294_Pine_Acres_Pond_Trail.gpx	0.00				USA
301	2	0.00	0	0.00	2	Brown Hill Pond Trail		/static/gpx/295_Brown_Hill_Pond_Trail.gpx	0.00				USA
302	2	0.00	0	0.00	2	Yellow White Loop Trail		/static/gpx/296_Yellow_White_Loop_Trail.gpx	0.00				USA
303	2	0.00	0	0.00	2	Red Yellow Connector Trail		/static/gpx/297_Red_Yellow_Connector_Trail.gpx	0.00				USA
304	2	0.00	0	0.00	2	Governor'S Island Trail		/static/gpx/298_Governor_S_Island_Trail.gpx	0.00				USA
305	2	0.00	0	0.00	2	Goodwin Foresttrail		/static/gpx/299_Goodwin_Foresttrail.gpx	0.00				USA
306	2	0.00	0	0.00	2	Forest Discovery Trail		/static/gpx/300_Forest_Discovery_Trail.gpx	0.00				USA
307	2	0.00	0	0.00	2	Goodwin Heritage Trail		/static/gpx/301_Goodwin_Heritage_Trail.gpx	0.00				USA
308	2	0.00	0	0.00	2	Crest		/static/gpx/302_Crest.gpx	0.00				USA
309	2	0.00	0	0.00	1	Mansfield Hollow Park Trail		/static/gpx/303_Mansfield_Hollow_Park_Trail.gpx	0.00				USA
310	2	0.00	0	0.00	1	Nipmuck Trail - East Branch		/static/gpx/304_Nipmuck_Trail___East_Branch.gpx	0.00				USA
311	2	0.00	0	0.00	0	Nipmuck Alternate		/static/gpx/305_Nipmuck_Alternate.gpx	0.00				USA
312	2	0.00	0	0.00	1	Mashamoquet Brook Nature Trail		/static/gpx/306_Mashamoquet_Brook_Nature_Trail.gpx	0.00				USA
313	2	0.00	0	0.00	2	Nipmuck Forest Trail		/static/gpx/307_Nipmuck_Forest_Trail.gpx	0.00				USA
314	2	0.00	0	0.00	2	Morey Pond Trail		/static/gpx/308_Morey_Pond_Trail.gpx	0.00				USA
315	2	0.00	0	0.00	2	Nipmuck Foreat Trail		/static/gpx/309_Nipmuck_Foreat_Trail.gpx	0.00				USA
316	2	0.00	0	0.00	2	Pharisee Rock Trail		/static/gpx/310_Pharisee_Rock_Trail.gpx	0.00				USA
317	2	0.00	0	0.00	2	Pachaug Forest Trail		/static/gpx/311_Pachaug_Forest_Trail.gpx	0.00				USA
318	2	0.00	0	0.00	2	Pachaug Trail		/static/gpx/312_Pachaug_Trail.gpx	0.00				USA
319	2	0.00	0	0.00	2	Canonicus Trail		/static/gpx/313_Canonicus_Trail.gpx	0.00				USA
320	2	0.00	0	0.00	2	Pachaug		/static/gpx/314_Pachaug.gpx	0.00				USA
321	2	0.00	0	0.00	2	Laurel Loop Trail		/static/gpx/315_Laurel_Loop_Trail.gpx	0.00				USA
322	2	0.00	0	0.00	2	Pachaug/Nehantic Connector		/static/gpx/316_Pachaug_Nehantic_Connector.gpx	0.00				USA
323	2	0.00	0	0.00	2	Pachaug/Tippecansett Connector		/static/gpx/317_Pachaug_Tippecansett_Connector.gpx	0.00				USA
324	2	0.00	0	0.00	2	Nehantic/Pachaug Connector		/static/gpx/318_Nehantic_Pachaug_Connector.gpx	0.00				USA
325	2	0.00	0	0.00	2	Quinebaug/Pachaug Connector		/static/gpx/319_Quinebaug_Pachaug_Connector.gpx	0.00				USA
326	2	0.00	0	0.00	2	Quinebaug Trail		/static/gpx/320_Quinebaug_Trail.gpx	0.00				USA
327	2	0.00	0	0.00	2	Pachaug/Narragansett Connector		/static/gpx/321_Pachaug_Narragansett_Connector.gpx	0.00				USA
328	2	0.00	0	0.00	2	Narragansett Trail		/static/gpx/322_Narragansett_Trail.gpx	0.00				USA
329	2	0.00	0	0.00	2	Green Falls Loop Trail		/static/gpx/323_Green_Falls_Loop_Trail.gpx	0.00				USA
330	2	0.00	0	0.00	2	Green Falls Water Access Trail		/static/gpx/324_Green_Falls_Water_Access_Trail.gpx	0.00				USA
331	2	0.00	0	0.00	2	Freeman Trail		/static/gpx/325_Freeman_Trail.gpx	0.00				USA
332	2	0.00	0	0.00	2	Tippecansett Trail		/static/gpx/326_Tippecansett_Trail.gpx	0.00				USA
333	2	0.00	0	0.00	2	Tippecansett/Freeman Trail		/static/gpx/327_Tippecansett_Freeman_Trail.gpx	0.00				USA
334	2	0.00	0	0.00	2	Green Falls Pond Trail		/static/gpx/328_Green_Falls_Pond_Trail.gpx	0.00				USA
335	2	0.00	0	0.00	2	Nehantic/Pachaug Trail		/static/gpx/329_Nehantic_Pachaug_Trail.gpx	0.00				USA
336	2	0.00	0	0.00	2	Phillips Pond Spur Trail		/static/gpx/330_Phillips_Pond_Spur_Trail.gpx	0.00				USA
337	2	0.00	0	0.00	2	Quinebaug/Nehantic Connector		/static/gpx/331_Quinebaug_Nehantic_Connector.gpx	0.00				USA
338	2	0.00	0	0.00	1	Nehantic/Quinebaug Connector		/static/gpx/332_Nehantic_Quinebaug_Connector.gpx	0.00				USA
339	2	0.00	0	0.00	0	Patagansett Trail		/static/gpx/333_Patagansett_Trail.gpx	0.00				USA
340	2	0.00	0	0.00	2	Paugussett Forest Trail		/static/gpx/334_Paugussett_Forest_Trail.gpx	0.00				USA
341	2	0.00	0	0.00	2	Zoar Trail		/static/gpx/335_Zoar_Trail.gpx	0.00				USA
342	2	0.00	0	0.00	2	Lillinonah Trail		/static/gpx/336_Lillinonah_Trail.gpx	0.00				USA
343	2	0.00	0	0.00	2	Zoar Trail (Old)		/static/gpx/337_Zoar_Trail__Old_.gpx	0.00				USA
344	2	0.00	0	0.00	2	Upper Gussy Trail		/static/gpx/338_Upper_Gussy_Trail.gpx	0.00				USA
345	2	0.00	0	0.00	2	Pierrepont Park Trail		/static/gpx/339_Pierrepont_Park_Trail.gpx	0.00				USA
346	2	0.00	0	0.00	2	Shenipsit Forest Trail		/static/gpx/340_Shenipsit_Forest_Trail.gpx	0.00				USA
347	2	0.00	0	0.00	2	Quary Trail		/static/gpx/341_Quary_Trail.gpx	0.00				USA
348	2	0.00	0	0.00	2	Shenipsit Forest Road		/static/gpx/342_Shenipsit_Forest_Road.gpx	0.00				USA
349	2	0.00	0	0.00	2	Topsmead Forest Trail		/static/gpx/343_Topsmead_Forest_Trail.gpx	0.00				USA
350	2	0.00	0	0.00	2	Edith M Chase Ecology Trail		/static/gpx/344_Edith_M_Chase_Ecology_Trail.gpx	0.00				USA
351	2	0.00	0	0.00	2	Bernard H Stairs Trail		/static/gpx/345_Bernard_H_Stairs_Trail.gpx	0.00				USA
352	2	0.00	0	0.00	2	West Rock Park Trail		/static/gpx/346_West_Rock_Park_Trail.gpx	0.00				USA
353	2	0.00	0	0.00	2	West Rock Summit Trail		/static/gpx/347_West_Rock_Summit_Trail.gpx	0.00				USA
354	2	0.00	0	0.00	2	Regicides Trail		/static/gpx/348_Regicides_Trail.gpx	0.00				USA
355	2	0.00	0	0.00	1	Sanford Feeder Trail		/static/gpx/349_Sanford_Feeder_Trail.gpx	0.00				USA
356	2	0.00	0	0.00	2	North Summit Trail		/static/gpx/350_North_Summit_Trail.gpx	0.00				USA
357	2	0.00	0	0.00	2	Westville Feeder Trail		/static/gpx/351_Westville_Feeder_Trail.gpx	0.00				USA
358	2	0.00	0	0.00	1	West Rock Park Road		/static/gpx/352_West_Rock_Park_Road.gpx	0.00				USA
359	2	0.00	0	0.00	0	Bennetts Pond Trail		/static/gpx/353_Bennetts_Pond_Trail.gpx	0.00				USA
360	2	0.00	0	0.00	0	Ives Trail		/static/gpx/354_Ives_Trail.gpx	0.00				USA
361	2	0.00	0	0.00	1	Ridgefield Open Space Trail		/static/gpx/355_Ridgefield_Open_Space_Trail.gpx	0.00				USA
362	2	0.00	0	0.00	1	George Dudley Seymour Park Trail		/static/gpx/356_George_Dudley_Seymour_Park_Trail.gpx	0.00				USA
363	2	0.00	0	0.00	1	Grta		/static/gpx/357_Grta.gpx	0.00				USA
364	2	0.00	0	0.00	0	Mohegan Forest Trail		/static/gpx/358_Mohegan_Forest_Trail.gpx	0.00				USA
365	2	0.00	0	0.00	1	Mount Bushnell Trail		/static/gpx/359_Mount_Bushnell_Trail.gpx	0.00				USA
366	2	0.00	0	0.00	2	Nye Holman Trail		/static/gpx/360_Nye_Holman_Trail.gpx	0.00				USA
367	2	0.00	0	0.00	2	Al'S Trail		/static/gpx/361_Al_S_Trail.gpx	0.00				USA
368	2	0.00	0	0.00	2	Salt Rock State Park Trail		/static/gpx/362_Salt_Rock_State_Park_Trail.gpx	0.00				USA
369	2	0.00	0	0.00	2	Scantic River Trail		/static/gpx/363_Scantic_River_Trail.gpx	0.00				USA
370	2	0.00	0	0.00	0	Scantic River Park Trail		/static/gpx/364_Scantic_River_Park_Trail.gpx	0.00				USA
371	2	0.00	0	0.00	0	Scantic Park Access		/static/gpx/365_Scantic_Park_Access.gpx	0.00				USA
372	2	0.00	0	0.00	1	Sunrise Park Trail		/static/gpx/366_Sunrise_Park_Trail.gpx	0.00				USA
373	2	0.00	0	0.00	1	Kitchel Trail		/static/gpx/367_Kitchel_Trail.gpx	0.00				USA
374	2	0.00	0	0.00	0	Old Driveway		/static/gpx/368_Old_Driveway.gpx	0.00				USA
375	2	0.00	0	0.00	1	Kitchel		/static/gpx/369_Kitchel.gpx	0.00				USA
376	2	0.00	0	0.00	2	Driveway		/static/gpx/370_Driveway.gpx	0.00				USA
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website) FROM stdin;
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address) FROM stdin;
1	0	0101000020E61000000000000000002840F6285C8FC2554A40	\N	\N
2	0	0101000020E6100000F6285C8FC2F535C09A99999999095040	\N	\N
3	0	0101000020E6100000F6285C8FC2F535C09A99999999095040	\N	\N
4	0	0101000020E6100000C39B35785F551C40E4D70FB1C1964640	\N	\N
5	0	0101000020E61000009C36E33444551C4041446ADAC5964640	\N	\N
6	0	0101000020E6100000C39B35785F551C40E4D70FB1C1964640	\N	\N
7	0	0101000020E61000009C36E33444551C4041446ADAC5964640	\N	\N
8	0	0101000020E6100000E67805A227551C40E09F5225CA964640	\N	\N
9	0	0101000020E610000008AD872F13551C4007978E39CF964640	\N	\N
10	0	0101000020E6100000D5EAABAB02551C40E1F08288D4964640	\N	\N
11	0	0101000020E6100000F701486DE2541C404A0B9755D8964640	\N	\N
12	0	0101000020E61000001AFCFD62B6541C40122EE411DC964640	\N	\N
13	0	0101000020E6100000E71C3C139A541C40EC87D860E1964640	\N	\N
14	0	0101000020E61000003CD9CD8C7E541C4090A0F831E6964640	\N	\N
15	0	0101000020E610000064CA87A06A541C40BD546CCCEB964640	\N	\N
16	0	0101000020E6100000E2B19FC552541C4032E9EFA5F0964640	\N	\N
17	0	0101000020E61000002C11A8FE41541C40055262D7F6964640	\N	\N
18	0	0101000020E61000001BBD1AA034541C40A96A82A8FB964640	\N	\N
19	0	0101000020E610000081CD397826541C4000E65AB400974640	\N	\N
20	0	0101000020E61000000F09DFFB1B541C402C9ACE4E06974640	\N	\N
21	0	0101000020E610000065FF3C0D18541C40E21DE0490B974640	\N	\N
22	0	0101000020E6100000041BD7BFEB531C405BB6D61709974640	\N	\N
23	0	0101000020E6100000541A31B3CF531C402E02637D03974640	\N	\N
24	0	0101000020E610000038691A14CD531C40DE770C8FFD964640	\N	\N
25	0	0101000020E6100000F48C7DC9C6531C40B1C398F4F7964640	\N	\N
26	0	0101000020E61000000A647616BD531C40BF0D315EF3964640	\N	\N
27	0	0101000020E610000071917BBABA531C409816F549EE964640	\N	\N
28	0	0101000020E6100000DD989EB0C4531C401EC539EAE8964640	\N	\N
29	0	0101000020E6100000BBB6B75B92531C40FAEE5696E8964640	\N	\N
30	0	0101000020E61000008E7747C66A531C408DD0CFD4EB964640	\N	\N
31	0	0101000020E6100000C765DCD440531C40AF3E1EFAEE964640	\N	\N
32	0	0101000020E610000089EFC4AC17531C40F5824F73F2964640	\N	\N
33	0	0101000020E61000009ACFB9DBF5521C406A4B1DE4F5964640	\N	\N
34	0	0101000020E61000000C207C28D1521C4056444DF4F9964640	\N	\N
35	0	0101000020E61000006D567DAEB6521C4090DAC4C9FD964640	\N	\N
36	0	0101000020E6100000F017B325AB521C4034F3E49A02974640	\N	\N
37	0	0101000020E61000003A94A12AA6521C4085B1852007974640	\N	\N
38	0	0101000020E610000018CFA0A17F521C402541B8020A974640	\N	\N
39	0	0101000020E61000005C548B8862521C405ED72FD80D974640	\N	\N
40	0	0101000020E6100000730E9E094D521C40A9D898D711974640	\N	\N
41	0	0101000020E6100000183E22A644521C40E92B483316974640	\N	\N
42	0	0101000020E6100000CF87670932521C40580394861A974640	\N	\N
43	0	0101000020E6100000857AFA08FC511C40E09EE74F1B974640	\N	\N
44	0	0101000020E61000000262122EE4511C402CA0504F1F974640	\N	\N
45	0	0101000020E61000002A1900AAB8511C400C1F115322974640	\N	\N
46	0	0101000020E6100000DB6B41EF8D511C40F94B8BFA24974640	\N	\N
47	0	0101000020E6100000E78EFE976B511C400F0C207C28974640	\N	\N
48	0	0101000020E6100000E7374C3448511C4001F6D1A92B974640	\N	\N
49	0	0101000020E6100000D0ECBAB722511C40836C59BE2E974640	\N	\N
50	0	0101000020E61000006A85E97B0D511C40B05417F032974640	\N	\N
51	0	0101000020E61000006A85E97B0D511C40909F8D5C37974640	\N	\N
52	0	0101000020E61000008179C8940F511C40416667D13B974640	\N	\N
53	0	0101000020E6100000AF27BA2EFC501C403ECA880B40974640	\N	\N
54	0	0101000020E61000006BF46A80D2501C400DDE57E542974640	\N	\N
55	0	0101000020E610000060234910AE501C408F54DFF945974640	\N	\N
56	0	0101000020E61000007C7DAD4B8D501C40ECC039234A974640	\N	\N
57	0	0101000020E6100000E353008C67501C409DBB5D2F4D974640	\N	\N
58	0	0101000020E61000001002F22554501C403C17467A51974640	\N	\N
59	0	0101000020E61000000B28D4D347501C402DCDAD1056974640	\N	\N
60	0	0101000020E61000003E76172829501C40F6EFFACC59974640	\N	\N
61	0	0101000020E61000006CEA3C2AFE4F1C40EFCA2E185C974640	\N	\N
62	0	0101000020E610000044F9821612501C40100533A660974640	\N	\N
63	0	0101000020E61000005B79C9FFE44F1C40396403E962974640	\N	\N
64	0	0101000020E6100000BC92E4B9BE4F1C40496760E465974640	\N	\N
65	0	0101000020E6100000B1FB8EE1B14F1C4029B2D6506A974640	\N	\N
66	0	0101000020E6100000E4141DC9E54F1C40761BD47E6B974640	\N	\N
67	0	0101000020E6100000B6A0F7C610501C40D4BB783F6E974640	\N	\N
68	0	0101000020E6100000C72E51BD35501C40B43A394371974640	\N	\N
69	0	0101000020E610000093E00D6954501C40CAFACDC474974640	\N	\N
70	0	0101000020E610000044334FAE29501C409351651877974640	\N	\N
71	0	0101000020E610000033880FECF84F1C40B6F3FDD478974640	\N	\N
72	0	0101000020E6100000EF54C03DCF4F1C4091B586527B974640	\N	\N
73	0	0101000020E6100000C79DD2C1FA4F1C40DDEA39E97D974640	\N	\N
74	0	0101000020E6100000DEE8633E20501C40A0504F1F81974640	\N	\N
75	0	0101000020E610000066DB696B44501C4004AE2B6684974640	\N	\N
76	0	0101000020E6100000BB287AE063501C407976F9D687974640	\N	\N
77	0	0101000020E61000000AB952CF82501C408388D4B48B974640	\N	\N
78	0	0101000020E6100000321EA5129E501C40BD1E4C8A8F974640	\N	\N
79	0	0101000020E61000004EECA17DAC501C40CCED5EEE93974640	\N	\N
80	0	0101000020E6100000876BB587BD501C404D309C6B98974640	\N	\N
81	0	0101000020E610000087C267EBE0501C40E01115AA9B974640	\N	\N
82	0	0101000020E6100000815CE2C803511C4079B0C56E9F974640	\N	\N
83	0	0101000020E6100000D0ECBAB722511C40D05FE811A3974640	\N	\N
84	0	0101000020E61000001AC05B2041511C40B79BE09BA6974640	\N	\N
85	0	0101000020E61000006493FC885F511C4020B6F468AA974640	\N	\N
86	0	0101000020E61000003602F1BA7E511C40D76D50FBAD974640	\N	\N
87	0	0101000020E6100000ECBFCE4D9B511C40B1FB8EE1B1974640	\N	\N
88	0	0101000020E6100000F2D3B837BF511C4008ABB184B5974640	\N	\N
89	0	0101000020E6100000AD6BB41CE8511C4019AE0E80B8974640	\N	\N
90	0	0101000020E6100000240A2DEBFE511C4064AF777FBC974640	\N	\N
91	0	0101000020E610000046B247A819521C40CDC98B4CC0974640	\N	\N
92	0	0101000020E61000009642209738521C408481E7DEC3974640	\N	\N
93	0	0101000020E6100000B8EA3A5453521C403448C153C8974640	\N	\N
94	0	0101000020E6100000C93EC8B260521C40B58AFED0CC974640	\N	\N
95	0	0101000020E61000001895D40968521C40C5591135D1974640	\N	\N
96	0	0101000020E61000002F6CCD565E521C4004ADC090D5974640	\N	\N
97	0	0101000020E6100000FCC6D79E59521C4085EFFD0DDA974640	\N	\N
98	0	0101000020E6100000E0DBF4673F521C40BE8575E3DD974640	\N	\N
99	0	0101000020E610000002F390291F521C4063D2DF4BE1974640	\N	\N
100	0	0101000020E610000052F2EA1C03521C402CF52C08E5974640	\N	\N
101	0	0101000020E6100000855D143DF0511C40B8E52329E9974640	\N	\N
102	0	0101000020E61000000EBF9B6ED9511C408BFD65F7E4974640	\N	\N
103	0	0101000020E6100000CA8B4CC0AF511C4080B74082E2974640	\N	\N
104	0	0101000020E61000009772BED87B511C40A4C16D6DE1974640	\N	\N
105	0	0101000020E61000008C84B69C4B511C4086747808E3974640	\N	\N
106	0	0101000020E61000002B14E97E4E511C40D732198EE7974640	\N	\N
107	0	0101000020E6100000B43BA41820511C404D2F3196E9974640	\N	\N
108	0	0101000020E61000007C65DEAAEB501C40D6FECEF6E8974640	\N	\N
109	0	0101000020E6100000D1E7A38CB8501C40A7AE7C96E7974640	\N	\N
110	0	0101000020E6100000A9BC1DE1B4501C40C9E88024EC974640	\N	\N
111	0	0101000020E610000071033E3F8C501C406878B306EF974640	\N	\N
112	0	0101000020E6100000C616821C94501C40183F8D7BF3974640	\N	\N
113	0	0101000020E610000055185B0872501C401D9430D3F6974640	\N	\N
114	0	0101000020E61000002D793C2D3F501C402942EA76F6974640	\N	\N
115	0	0101000020E61000001C42959A3D501C40D908C4EBFA974640	\N	\N
116	0	0101000020E610000088B839950C501C40DA3C0E83F9974640	\N	\N
117	0	0101000020E61000007250C24CDB4F1C40BC57AD4CF8974640	\N	\N
118	0	0101000020E610000017299485AF4F1C407A008BFCFA974640	\N	\N
119	0	0101000020E6100000736891ED7C4F1C408C9FC6BDF9974640	\N	\N
120	0	0101000020E610000083F6EAE3A14F1C4090F46915FD974640	\N	\N
121	0	0101000020E61000004580D3BB784F1C40DC291DACFF974640	\N	\N
122	0	0101000020E6100000840EBA84434F1C4024D6E25300984640	\N	\N
123	0	0101000020E610000035B8AD2D3C4F1C40042159C004984640	\N	\N
124	0	0101000020E6100000A12E52280B4F1C4003ED0E2906984640	\N	\N
125	0	0101000020E6100000FC6D4F90D84E1C40A9A10DC006984640	\N	\N
126	0	0101000020E610000024D3A1D3F34E1C4012BC218D0A984640	\N	\N
127	0	0101000020E610000040A19E3E024F1C40C382FB010F984640	\N	\N
128	0	0101000020E6100000E6965643E24E1C40AF7B2B1213984640	\N	\N
129	0	0101000020E6100000BEF73768AF4E1C40C6A354C213984640	\N	\N
130	0	0101000020E6100000CA54C1A8A44E1C4088D51F6118984640	\N	\N
131	0	0101000020E6100000029A081B9E4E1C40399CF9D51C984640	\N	\N
132	0	0101000020E6100000C440D7BE804E1C4001BF469220984640	\N	\N
133	0	0101000020E61000006FD6E07D554E1C400057B26323984640	\N	\N
134	0	0101000020E6100000D0D2156C234E1C40F965304624984640	\N	\N
135	0	0101000020E6100000533D997FF44D1C409FE6E44526984640	\N	\N
136	0	0101000020E6100000B439CE6DC24D1C40511553E927984640	\N	\N
137	0	0101000020E610000026FE28EACC4D1C4060E4654D2C984640	\N	\N
138	0	0101000020E6100000AE0D15E3FC4D1C4036E9B6442E984640	\N	\N
139	0	0101000020E61000003CA06CCA154E1C40E0F2583332984640	\N	\N
140	0	0101000020E6100000A8C4758C2B4E1C409D67EC4B36984640	\N	\N
141	0	0101000020E6100000E7A90EB9194E1C409BCB0D863A984640	\N	\N
142	0	0101000020E610000064575A46EA4D1C40EDF1423A3C984640	\N	\N
143	0	0101000020E61000004832AB77B84D1C40C9E7154F3D984640	\N	\N
144	0	0101000020E610000054C90050C54D1C406743FE9941984640	\N	\N
145	0	0101000020E61000001BA19FA9D74D1C40069FE6E445984640	\N	\N
146	0	0101000020E61000009D9CA1B8E34D1C40757632384A984640	\N	\N
147	0	0101000020E6100000158DB5BFB34D1C4068942EFD4B984640	\N	\N
148	0	0101000020E61000007689EAAD814D1C40DFC4909C4C984640	\N	\N
149	0	0101000020E6100000492D944C4E4D1C401AF7E6374C984640	\N	\N
150	0	0101000020E6100000274BADF71B4D1C4085798F334D984640	\N	\N
151	0	0101000020E6100000164ED2FC314D1C4042EE224C51984640	\N	\N
152	0	0101000020E6100000E31C75745C4D1C40ED2B0FD253984640	\N	\N
153	0	0101000020E6100000D82E6D382C4D1C40E606431D56984640	\N	\N
154	0	0101000020E6100000D8BAD408FD4C1C404A9869FB57984640	\N	\N
155	0	0101000020E6100000E92B4833164D1C40842EE1D05B984640	\N	\N
156	0	0101000020E6100000556D37C1374D1C400B62A06B5F984640	\N	\N
157	0	0101000020E61000002D7C7DAD4B4D1C40A9BD88B663984640	\N	\N
158	0	0101000020E6100000D102B4AD664D1C40B3CF639467984640	\N	\N
159	0	0101000020E6100000D13C80457E4D1C402E55698B6B984640	\N	\N
160	0	0101000020E6100000BA6587F8874D1C400EA0DFF76F984640	\N	\N
161	0	0101000020E610000010E84CDA544D1C40B58828266F984640	\N	\N
162	0	0101000020E61000006B9BE271514D1C40A73E90BC73984640	\N	\N
163	0	0101000020E6100000D102B4AD664D1C4063B323D577984640	\N	\N
164	0	0101000020E610000038BC2022354D1C403563D17476984640	\N	\N
165	0	0101000020E610000016F71F990E4D1C40018A912573984640	\N	\N
166	0	0101000020E610000000AC8E1CE94C1C403E247CEF6F984640	\N	\N
167	0	0101000020E6100000B6BB07E8BE4C1C40C26A2C616D984640	\N	\N
168	0	0101000020E6100000B69E211CB34C1C40314278B471984640	\N	\N
169	0	0101000020E610000094F6065F984C1C40CAE0287975984640	\N	\N
170	0	0101000020E6100000284696CCB14C1C40D4F2035779984640	\N	\N
171	0	0101000020E61000003F575BB1BF4C1C40A2D288997D984640	\N	\N
172	0	0101000020E6100000944DB9C2BB4C1C405299620E82984640	\N	\N
173	0	0101000020E6100000B01BB62DCA4C1C40853E58C686984640	\N	\N
174	0	0101000020E610000022FDF675E04C1C40D13FC1C58A984640	\N	\N
175	0	0101000020E610000055850662D94C1C4063EDEF6C8F984640	\N	\N
176	0	0101000020E610000072361D01DC4C1C40E42F2DEA93984640	\N	\N
177	0	0101000020E61000004A0B9755D84C1C4065726A6798984640	\N	\N
178	0	0101000020E6100000D8800871E54C1C4003CE52B29C984640	\N	\N
179	0	0101000020E61000004F029B73F04C1C40139D6516A1984640	\N	\N
180	0	0101000020E610000099B85510034D1C40A08D5C37A5984640	\N	\N
181	0	0101000020E610000082E15CC30C4D1C4080D8D2A3A9984640	\N	\N
182	0	0101000020E61000009F9273620F4D1C4083F92B64AE984640	\N	\N
183	0	0101000020E610000005DD5ED2184D1C40C24CDBBFB2984640	\N	\N
184	0	0101000020E61000003E3F8C101E4D1C40E486DF4DB7984640	\N	\N
185	0	0101000020E61000001631EC30264D1C40944DB9C2BB984640	\N	\N
186	0	0101000020E6100000FAB9A1293B4D1C4092B1DAFCBF984640	\N	\N
187	0	0101000020E61000008272DBBE474D1C4001892650C4984640	\N	\N
188	0	0101000020E6100000A41AF67B624D1C409A27D714C8984640	\N	\N
189	0	0101000020E61000004E417E36724D1C40978BF84ECC984640	\N	\N
190	0	0101000020E6100000BB48A12C7C4D1C40D7DEA7AAD0984640	\N	\N
191	0	0101000020E6100000F984ECBC8D4D1C405721E527D5984640	\N	\N
192	0	0101000020E610000010B3976DA74D1C4091B75CFDD8984640	\N	\N
193	0	0101000020E610000026FE28EACC4D1C40B325AB22DC984640	\N	\N
194	0	0101000020E6100000923F1878EE4D1C40F969DC9BDF984640	\N	\N
195	0	0101000020E6100000D6726726184E1C40C87DAB75E2984640	\N	\N
196	0	0101000020E6100000D6E6FF55474E1C40F699B33EE5984640	\N	\N
197	0	0101000020E6100000E1B721C66B4E1C40B9FFC874E8984640	\N	\N
198	0	0101000020E61000005890662C9A4E1C405E807D74EA984640	\N	\N
199	0	0101000020E6100000FC5069C4CC4E1C40EDD808C4EB984640	\N	\N
200	0	0101000020E6100000D4997B48F84E1C4057276728EE984640	\N	\N
201	0	0101000020E61000007920B248134F1C4031B5A50EF2984640	\N	\N
202	0	0101000020E61000004BAC8C463E4F1C40DCF29194F4984640	\N	\N
203	0	0101000020E61000004B033FAA614F1C40B1C398F4F7984640	\N	\N
204	0	0101000020E6100000670B08AD874F1C40F607CA6DFB984640	\N	\N
205	0	0101000020E61000002843554CA54F1C40BF2A172AFF984640	\N	\N
206	0	0101000020E6100000BCAFCA85CA4F1C40111D024702994640	\N	\N
207	0	0101000020E610000044A2D0B2EE4F1C400307B47405994640	\N	\N
208	0	0101000020E61000000BB43BA418501C40F0332E1C08994640	\N	\N
209	0	0101000020E6100000F433F5BA45501C401893FE5E0A994640	\N	\N
210	0	0101000020E6100000103CBEBD6B501C40F911BF620D994640	\N	\N
211	0	0101000020E6100000B5C2F4BD86501C40D39FFD4811994640	\N	\N
212	0	0101000020E6100000F31B261AA4501C40FBCA83F414994640	\N	\N
213	0	0101000020E610000010070951BE501C4005DD5ED218994640	\N	\N
214	0	0101000020E610000004C765DCD4501C40C251F2EA1C994640	\N	\N
215	0	0101000020E61000002104E44BA8501C40793D98141F994640	\N	\N
216	0	0101000020E61000008D7A884677501C4044300E2E1D994640	\N	\N
217	0	0101000020E6100000E3FC4D2844501C40A438471D1D994640	\N	\N
218	0	0101000020E6100000AB2688BA0F501C406249B9FB1C994640	\N	\N
219	0	0101000020E610000094BE1072DE4F1C40DF3653211E994640	\N	\N
220	0	0101000020E6100000F0FD0DDAAB4F1C401A69A9BC1D994640	\N	\N
221	0	0101000020E6100000CE1B2785794F1C40C70E2A711D994640	\N	\N
222	0	0101000020E6100000A67C08AA464F1C4015AC71361D994640	\N	\N
223	0	0101000020E610000062BD512B4C4F1C40666A12BC21994640	\N	\N
224	0	0101000020E610000095EEAEB3214F1C40357EE19524994640	\N	\N
225	0	0101000020E6100000F12DAC1BEF4E1C4094861A8524994640	\N	\N
226	0	0101000020E6100000C4D155BABB4E1C40F94B8BFA24994640	\N	\N
227	0	0101000020E610000025CE8AA8894E1C402313F06B24994640	\N	\N
228	0	0101000020E61000001F9DBAF2594E1C40C3D66CE525994640	\N	\N
229	0	0101000020E6100000093543AA284E1C401CEE23B726994640	\N	\N
230	0	0101000020E6100000ED0F94DBF64D1C40B728B34126994640	\N	\N
231	0	0101000020E6100000E8DEC325C74D1C40AA46AF0628994640	\N	\N
232	0	0101000020E61000003D618907944D1C4050FBAD9D28994640	\N	\N
233	0	0101000020E61000007192E68F694D1C40BA490C022B994640	\N	\N
234	0	0101000020E6100000C614AC71364D1C401F0F7D772B994640	\N	\N
235	0	0101000020E61000009F758D96034D1C403D2828452B994640	\N	\N
236	0	0101000020E610000077D66EBBD04C1C40A2ED98BA2B994640	\N	\N
237	0	0101000020E6100000E97DE36BCF4C1C402330D63730994640	\N	\N
238	0	0101000020E6100000E3DD91B1DA4C1C40C748F60835994640	\N	\N
239	0	0101000020E610000099B85510034D1C4007D0EFFB37994640	\N	\N
240	0	0101000020E6100000C7DADFD91E4D1C4070EA03C93B994640	\N	\N
241	0	0101000020E61000009E060C923E4D1C406891ED7C3F994640	\N	\N
242	0	0101000020E6100000100533A6604D1C406DE690D442994640	\N	\N
243	0	0101000020E610000098F738D3844D1C40304CA60A46994640	\N	\N
244	0	0101000020E6100000871744A4A64D1C4087FBC8AD49994640	\N	\N
245	0	0101000020E61000000A6AF816D64D1C404A95287B4B994640	\N	\N
246	0	0101000020E610000081423D7D044E1C40DEAAEB504D994640	\N	\N
247	0	0101000020E6100000B91803EB384E1C409C8713984E994640	\N	\N
248	0	0101000020E61000003691990B5C4E1C405FED28CE51994640	\N	\N
249	0	0101000020E6100000CFD72C978D4E1C408E3D7B2E53994640	\N	\N
250	0	0101000020E6100000417FA1478C4E1C403E0455A357994640	\N	\N
251	0	0101000020E6100000E19A3BFA5F4E1C4037DF88EE59994640	\N	\N
252	0	0101000020E6100000E17D552E544E1C40D63A71395E994640	\N	\N
253	0	0101000020E61000007BF99D26334E1C40DA8F149161994640	\N	\N
254	0	0101000020E610000097AAB4C5354E1C402B4EB51666994640	\N	\N
255	0	0101000020E6100000ED832C0B264E1C4029B2D6506A994640	\N	\N
256	0	0101000020E610000064744012F64D1C408786C5A86B994640	\N	\N
257	0	0101000020E610000070EEAF1EF74D1C4008C9022670994640	\N	\N
258	0	0101000020E6100000B9DE3653214E1C404293C49272994640	\N	\N
259	0	0101000020E6100000D6389B8E004E1C401764CBF275994640	\N	\N
260	0	0101000020E61000006F4562821A4E1C40807EDFBF79994640	\N	\N
261	0	0101000020E61000004DF4F928234E1C40904DF2237E994640	\N	\N
262	0	0101000020E6100000A8FE4124434E1C407689EAAD81994640	\N	\N
263	0	0101000020E610000058A835CD3B4E1C40C7478B3386994640	\N	\N
264	0	0101000020E6100000B935E9B6444E1C40CB68E4F38A994640	\N	\N
265	0	0101000020E6100000253D0CAD4E4E1C402E9276A38F994640	\N	\N
266	0	0101000020E6100000DBC01DA8534E1C404FCC7A3194994640	\N	\N
267	0	0101000020E6100000B98C9B1A684E1C40BEA3C68498994640	\N	\N
268	0	0101000020E6100000C4E9245B5D4E1C402D7B12D89C994640	\N	\N
269	0	0101000020E610000036AE7FD7674E1C403C4A253CA1994640	\N	\N
270	0	0101000020E610000058E20165534E1C40DBA50D87A5994640	\N	\N
271	0	0101000020E6100000F2B4FCC0554E1C40BBF083F3A9994640	\N	\N
272	0	0101000020E6100000CAA65CE15D4E1C40DC2A8881AE994640	\N	\N
273	0	0101000020E61000009CDB847B654E1C408DF161F6B2994640	\N	\N
274	0	0101000020E6100000DBFAE93F6B4E1C40AE2B6684B7994640	\N	\N
275	0	0101000020E6100000BE66B96C744E1C40ED7E15E0BB994640	\N	\N
276	0	0101000020E610000063D009A1834E1C405C566133C0994640	\N	\N
277	0	0101000020E61000004C16F71F994E1C40E9465854C4994640	\N	\N
278	0	0101000020E610000041D653ABAF4E1C4064CC5D4BC8994640	\N	\N
279	0	0101000020E6100000B857E6ADBA4E1C404417D4B7CC994640	\N	\N
280	0	0101000020E6100000C9AB730CC84E1C40B3EE1F0BD1994640	\N	\N
281	0	0101000020E61000002499D53BDC4E1C4040DF162CD5994640	\N	\N
282	0	0101000020E6100000C9022670EB4E1C403D433866D9994640	\N	\N
283	0	0101000020E6100000E5B33C0FEE4E1C40EE0912DBDD994640	\N	\N
284	0	0101000020E6100000FCFECD8B134F1C4010786000E1994640	\N	\N
285	0	0101000020E610000002D9EBDD1F4F1C4061360186E5994640	\N	\N
286	0	0101000020E610000001F6D1A92B4F1C40FF91E9D0E9994640	\N	\N
287	0	0101000020E61000000DFCA886FD4E1C40349F73B7EB994640	\N	\N
288	0	0101000020E6100000EBAA402D064F1C40E4654D2CF0994640	\N	\N
289	0	0101000020E61000002F4D11E0F44E1C4042D2A755F4994640	\N	\N
290	0	0101000020E6100000F1845E7F124F1C403A799109F8994640	\N	\N
291	0	0101000020E61000007F349C32374F1C409DD66D50FB994640	\N	\N
292	0	0101000020E6100000950B957F2D4F1C40BF1072DEFF994640	\N	\N
293	0	0101000020E6100000C8CD70033E4F1C401C7DCC07049A4640	\N	\N
294	0	0101000020E610000023D8B8FE5D4F1C40323D6189079A4640	\N	\N
295	0	0101000020E6100000E5B8533A584F1C40E2033BFE0B9A4640	\N	\N
296	0	0101000020E6100000F0DB10E3354F1C400D33349E089A4640	\N	\N
297	0	0101000020E6100000C9B08A37324F1C40705CC64D0D9A4640	\N	\N
298	0	0101000020E6100000C39B35785F551C40E4D70FB1C1964640	\N	\N
299	0	0101000020E61000009C36E33444551C4041446ADAC5964640	\N	\N
300	0	0101000020E6100000E67805A227551C40E09F5225CA964640	\N	\N
301	0	0101000020E610000008AD872F13551C4007978E39CF964640	\N	\N
302	0	0101000020E6100000D5EAABAB02551C40E1F08288D4964640	\N	\N
303	0	0101000020E6100000F701486DE2541C404A0B9755D8964640	\N	\N
304	0	0101000020E61000001AFCFD62B6541C40122EE411DC964640	\N	\N
305	0	0101000020E6100000E71C3C139A541C40EC87D860E1964640	\N	\N
306	0	0101000020E61000003CD9CD8C7E541C4090A0F831E6964640	\N	\N
307	0	0101000020E610000064CA87A06A541C40BD546CCCEB964640	\N	\N
308	0	0101000020E6100000E2B19FC552541C4032E9EFA5F0964640	\N	\N
309	0	0101000020E61000002C11A8FE41541C40055262D7F6964640	\N	\N
310	0	0101000020E61000001BBD1AA034541C40A96A82A8FB964640	\N	\N
311	0	0101000020E610000081CD397826541C4000E65AB400974640	\N	\N
312	0	0101000020E61000000F09DFFB1B541C402C9ACE4E06974640	\N	\N
313	0	0101000020E610000065FF3C0D18541C40E21DE0490B974640	\N	\N
314	0	0101000020E6100000041BD7BFEB531C405BB6D61709974640	\N	\N
315	0	0101000020E6100000541A31B3CF531C402E02637D03974640	\N	\N
316	0	0101000020E610000038691A14CD531C40DE770C8FFD964640	\N	\N
317	0	0101000020E6100000F48C7DC9C6531C40B1C398F4F7964640	\N	\N
318	0	0101000020E61000000A647616BD531C40BF0D315EF3964640	\N	\N
319	0	0101000020E610000071917BBABA531C409816F549EE964640	\N	\N
320	0	0101000020E6100000DD989EB0C4531C401EC539EAE8964640	\N	\N
321	0	0101000020E6100000BBB6B75B92531C40FAEE5696E8964640	\N	\N
322	0	0101000020E61000008E7747C66A531C408DD0CFD4EB964640	\N	\N
323	0	0101000020E6100000C765DCD440531C40AF3E1EFAEE964640	\N	\N
324	0	0101000020E610000089EFC4AC17531C40F5824F73F2964640	\N	\N
325	0	0101000020E61000009ACFB9DBF5521C406A4B1DE4F5964640	\N	\N
326	0	0101000020E61000000C207C28D1521C4056444DF4F9964640	\N	\N
327	0	0101000020E61000006D567DAEB6521C4090DAC4C9FD964640	\N	\N
328	0	0101000020E6100000F017B325AB521C4034F3E49A02974640	\N	\N
329	0	0101000020E61000003A94A12AA6521C4085B1852007974640	\N	\N
330	0	0101000020E610000018CFA0A17F521C402541B8020A974640	\N	\N
331	0	0101000020E61000005C548B8862521C405ED72FD80D974640	\N	\N
332	0	0101000020E6100000730E9E094D521C40A9D898D711974640	\N	\N
333	0	0101000020E6100000183E22A644521C40E92B483316974640	\N	\N
334	0	0101000020E6100000CF87670932521C40580394861A974640	\N	\N
335	0	0101000020E6100000857AFA08FC511C40E09EE74F1B974640	\N	\N
336	0	0101000020E61000000262122EE4511C402CA0504F1F974640	\N	\N
337	0	0101000020E61000002A1900AAB8511C400C1F115322974640	\N	\N
338	0	0101000020E6100000DB6B41EF8D511C40F94B8BFA24974640	\N	\N
339	0	0101000020E6100000E78EFE976B511C400F0C207C28974640	\N	\N
340	0	0101000020E6100000E7374C3448511C4001F6D1A92B974640	\N	\N
341	0	0101000020E6100000D0ECBAB722511C40836C59BE2E974640	\N	\N
342	0	0101000020E61000006A85E97B0D511C40B05417F032974640	\N	\N
343	0	0101000020E61000006A85E97B0D511C40909F8D5C37974640	\N	\N
344	0	0101000020E61000008179C8940F511C40416667D13B974640	\N	\N
345	0	0101000020E6100000AF27BA2EFC501C403ECA880B40974640	\N	\N
346	0	0101000020E61000006BF46A80D2501C400DDE57E542974640	\N	\N
347	0	0101000020E610000060234910AE501C408F54DFF945974640	\N	\N
348	0	0101000020E61000007C7DAD4B8D501C40ECC039234A974640	\N	\N
349	0	0101000020E6100000E353008C67501C409DBB5D2F4D974640	\N	\N
350	0	0101000020E61000001002F22554501C403C17467A51974640	\N	\N
351	0	0101000020E61000000B28D4D347501C402DCDAD1056974640	\N	\N
352	0	0101000020E61000003E76172829501C40F6EFFACC59974640	\N	\N
353	0	0101000020E61000006CEA3C2AFE4F1C40EFCA2E185C974640	\N	\N
354	0	0101000020E610000044F9821612501C40100533A660974640	\N	\N
355	0	0101000020E61000005B79C9FFE44F1C40396403E962974640	\N	\N
356	0	0101000020E6100000BC92E4B9BE4F1C40496760E465974640	\N	\N
357	0	0101000020E6100000B1FB8EE1B14F1C4029B2D6506A974640	\N	\N
358	0	0101000020E6100000E4141DC9E54F1C40761BD47E6B974640	\N	\N
359	0	0101000020E6100000B6A0F7C610501C40D4BB783F6E974640	\N	\N
360	0	0101000020E6100000C72E51BD35501C40B43A394371974640	\N	\N
361	0	0101000020E610000093E00D6954501C40CAFACDC474974640	\N	\N
362	0	0101000020E610000044334FAE29501C409351651877974640	\N	\N
363	0	0101000020E610000033880FECF84F1C40B6F3FDD478974640	\N	\N
364	0	0101000020E6100000EF54C03DCF4F1C4091B586527B974640	\N	\N
365	0	0101000020E6100000C79DD2C1FA4F1C40DDEA39E97D974640	\N	\N
366	0	0101000020E6100000DEE8633E20501C40A0504F1F81974640	\N	\N
367	0	0101000020E610000066DB696B44501C4004AE2B6684974640	\N	\N
368	0	0101000020E6100000BB287AE063501C407976F9D687974640	\N	\N
369	0	0101000020E61000000AB952CF82501C408388D4B48B974640	\N	\N
370	0	0101000020E6100000321EA5129E501C40BD1E4C8A8F974640	\N	\N
371	0	0101000020E61000004EECA17DAC501C40CCED5EEE93974640	\N	\N
372	0	0101000020E6100000876BB587BD501C404D309C6B98974640	\N	\N
373	0	0101000020E610000087C267EBE0501C40E01115AA9B974640	\N	\N
374	0	0101000020E6100000815CE2C803511C4079B0C56E9F974640	\N	\N
375	0	0101000020E6100000D0ECBAB722511C40D05FE811A3974640	\N	\N
376	0	0101000020E61000001AC05B2041511C40B79BE09BA6974640	\N	\N
377	0	0101000020E61000006493FC885F511C4020B6F468AA974640	\N	\N
378	0	0101000020E61000003602F1BA7E511C40D76D50FBAD974640	\N	\N
379	0	0101000020E6100000ECBFCE4D9B511C40B1FB8EE1B1974640	\N	\N
380	0	0101000020E6100000F2D3B837BF511C4008ABB184B5974640	\N	\N
381	0	0101000020E6100000AD6BB41CE8511C4019AE0E80B8974640	\N	\N
382	0	0101000020E6100000240A2DEBFE511C4064AF777FBC974640	\N	\N
383	0	0101000020E610000046B247A819521C40CDC98B4CC0974640	\N	\N
384	0	0101000020E61000009642209738521C408481E7DEC3974640	\N	\N
385	0	0101000020E6100000B8EA3A5453521C403448C153C8974640	\N	\N
386	0	0101000020E6100000C93EC8B260521C40B58AFED0CC974640	\N	\N
387	0	0101000020E61000001895D40968521C40C5591135D1974640	\N	\N
388	0	0101000020E61000002F6CCD565E521C4004ADC090D5974640	\N	\N
389	0	0101000020E6100000FCC6D79E59521C4085EFFD0DDA974640	\N	\N
390	0	0101000020E6100000E0DBF4673F521C40BE8575E3DD974640	\N	\N
391	0	0101000020E610000002F390291F521C4063D2DF4BE1974640	\N	\N
392	0	0101000020E610000052F2EA1C03521C402CF52C08E5974640	\N	\N
393	0	0101000020E6100000855D143DF0511C40B8E52329E9974640	\N	\N
394	0	0101000020E61000000EBF9B6ED9511C408BFD65F7E4974640	\N	\N
395	0	0101000020E6100000CA8B4CC0AF511C4080B74082E2974640	\N	\N
396	0	0101000020E61000009772BED87B511C40A4C16D6DE1974640	\N	\N
397	0	0101000020E61000008C84B69C4B511C4086747808E3974640	\N	\N
398	0	0101000020E61000002B14E97E4E511C40D732198EE7974640	\N	\N
399	0	0101000020E6100000B43BA41820511C404D2F3196E9974640	\N	\N
400	0	0101000020E61000007C65DEAAEB501C40D6FECEF6E8974640	\N	\N
401	0	0101000020E6100000D1E7A38CB8501C40A7AE7C96E7974640	\N	\N
402	0	0101000020E6100000A9BC1DE1B4501C40C9E88024EC974640	\N	\N
403	0	0101000020E610000071033E3F8C501C406878B306EF974640	\N	\N
404	0	0101000020E6100000C616821C94501C40183F8D7BF3974640	\N	\N
405	0	0101000020E610000055185B0872501C401D9430D3F6974640	\N	\N
406	0	0101000020E61000002D793C2D3F501C402942EA76F6974640	\N	\N
407	0	0101000020E61000001C42959A3D501C40D908C4EBFA974640	\N	\N
408	0	0101000020E610000088B839950C501C40DA3C0E83F9974640	\N	\N
409	0	0101000020E61000007250C24CDB4F1C40BC57AD4CF8974640	\N	\N
410	0	0101000020E610000017299485AF4F1C407A008BFCFA974640	\N	\N
411	0	0101000020E6100000736891ED7C4F1C408C9FC6BDF9974640	\N	\N
412	0	0101000020E610000083F6EAE3A14F1C4090F46915FD974640	\N	\N
413	0	0101000020E61000004580D3BB784F1C40DC291DACFF974640	\N	\N
414	0	0101000020E6100000840EBA84434F1C4024D6E25300984640	\N	\N
415	0	0101000020E610000035B8AD2D3C4F1C40042159C004984640	\N	\N
416	0	0101000020E6100000A12E52280B4F1C4003ED0E2906984640	\N	\N
417	0	0101000020E6100000FC6D4F90D84E1C40A9A10DC006984640	\N	\N
418	0	0101000020E610000024D3A1D3F34E1C4012BC218D0A984640	\N	\N
419	0	0101000020E610000040A19E3E024F1C40C382FB010F984640	\N	\N
420	0	0101000020E6100000E6965643E24E1C40AF7B2B1213984640	\N	\N
421	0	0101000020E6100000BEF73768AF4E1C40C6A354C213984640	\N	\N
422	0	0101000020E6100000CA54C1A8A44E1C4088D51F6118984640	\N	\N
423	0	0101000020E6100000029A081B9E4E1C40399CF9D51C984640	\N	\N
424	0	0101000020E6100000C440D7BE804E1C4001BF469220984640	\N	\N
425	0	0101000020E61000006FD6E07D554E1C400057B26323984640	\N	\N
426	0	0101000020E6100000D0D2156C234E1C40F965304624984640	\N	\N
427	0	0101000020E6100000533D997FF44D1C409FE6E44526984640	\N	\N
428	0	0101000020E6100000B439CE6DC24D1C40511553E927984640	\N	\N
429	0	0101000020E610000026FE28EACC4D1C4060E4654D2C984640	\N	\N
430	0	0101000020E6100000AE0D15E3FC4D1C4036E9B6442E984640	\N	\N
431	0	0101000020E61000003CA06CCA154E1C40E0F2583332984640	\N	\N
432	0	0101000020E6100000A8C4758C2B4E1C409D67EC4B36984640	\N	\N
433	0	0101000020E6100000E7A90EB9194E1C409BCB0D863A984640	\N	\N
434	0	0101000020E610000064575A46EA4D1C40EDF1423A3C984640	\N	\N
435	0	0101000020E61000004832AB77B84D1C40C9E7154F3D984640	\N	\N
436	0	0101000020E610000054C90050C54D1C406743FE9941984640	\N	\N
437	0	0101000020E61000001BA19FA9D74D1C40069FE6E445984640	\N	\N
438	0	0101000020E61000009D9CA1B8E34D1C40757632384A984640	\N	\N
439	0	0101000020E6100000158DB5BFB34D1C4068942EFD4B984640	\N	\N
440	0	0101000020E61000007689EAAD814D1C40DFC4909C4C984640	\N	\N
441	0	0101000020E6100000492D944C4E4D1C401AF7E6374C984640	\N	\N
442	0	0101000020E6100000274BADF71B4D1C4085798F334D984640	\N	\N
443	0	0101000020E6100000164ED2FC314D1C4042EE224C51984640	\N	\N
444	0	0101000020E6100000E31C75745C4D1C40ED2B0FD253984640	\N	\N
445	0	0101000020E6100000D82E6D382C4D1C40E606431D56984640	\N	\N
446	0	0101000020E6100000D8BAD408FD4C1C404A9869FB57984640	\N	\N
447	0	0101000020E6100000E92B4833164D1C40842EE1D05B984640	\N	\N
448	0	0101000020E6100000556D37C1374D1C400B62A06B5F984640	\N	\N
449	0	0101000020E61000002D7C7DAD4B4D1C40A9BD88B663984640	\N	\N
450	0	0101000020E6100000D102B4AD664D1C40B3CF639467984640	\N	\N
451	0	0101000020E6100000D13C80457E4D1C402E55698B6B984640	\N	\N
452	0	0101000020E6100000BA6587F8874D1C400EA0DFF76F984640	\N	\N
453	0	0101000020E610000010E84CDA544D1C40B58828266F984640	\N	\N
454	0	0101000020E61000006B9BE271514D1C40A73E90BC73984640	\N	\N
455	0	0101000020E6100000D102B4AD664D1C4063B323D577984640	\N	\N
456	0	0101000020E610000038BC2022354D1C403563D17476984640	\N	\N
457	0	0101000020E610000016F71F990E4D1C40018A912573984640	\N	\N
458	0	0101000020E610000000AC8E1CE94C1C403E247CEF6F984640	\N	\N
459	0	0101000020E6100000B6BB07E8BE4C1C40C26A2C616D984640	\N	\N
460	0	0101000020E6100000B69E211CB34C1C40314278B471984640	\N	\N
461	0	0101000020E610000094F6065F984C1C40CAE0287975984640	\N	\N
462	0	0101000020E6100000284696CCB14C1C40D4F2035779984640	\N	\N
463	0	0101000020E61000003F575BB1BF4C1C40A2D288997D984640	\N	\N
464	0	0101000020E6100000944DB9C2BB4C1C405299620E82984640	\N	\N
465	0	0101000020E6100000B01BB62DCA4C1C40853E58C686984640	\N	\N
466	0	0101000020E610000022FDF675E04C1C40D13FC1C58A984640	\N	\N
467	0	0101000020E610000055850662D94C1C4063EDEF6C8F984640	\N	\N
468	0	0101000020E610000072361D01DC4C1C40E42F2DEA93984640	\N	\N
469	0	0101000020E61000004A0B9755D84C1C4065726A6798984640	\N	\N
470	0	0101000020E6100000D8800871E54C1C4003CE52B29C984640	\N	\N
471	0	0101000020E61000004F029B73F04C1C40139D6516A1984640	\N	\N
472	0	0101000020E610000099B85510034D1C40A08D5C37A5984640	\N	\N
473	0	0101000020E610000082E15CC30C4D1C4080D8D2A3A9984640	\N	\N
474	0	0101000020E61000009F9273620F4D1C4083F92B64AE984640	\N	\N
475	0	0101000020E610000005DD5ED2184D1C40C24CDBBFB2984640	\N	\N
476	0	0101000020E61000003E3F8C101E4D1C40E486DF4DB7984640	\N	\N
477	0	0101000020E61000001631EC30264D1C40944DB9C2BB984640	\N	\N
478	0	0101000020E6100000FAB9A1293B4D1C4092B1DAFCBF984640	\N	\N
479	0	0101000020E61000008272DBBE474D1C4001892650C4984640	\N	\N
480	0	0101000020E6100000A41AF67B624D1C409A27D714C8984640	\N	\N
481	0	0101000020E61000004E417E36724D1C40978BF84ECC984640	\N	\N
482	0	0101000020E6100000BB48A12C7C4D1C40D7DEA7AAD0984640	\N	\N
483	0	0101000020E6100000F984ECBC8D4D1C405721E527D5984640	\N	\N
484	0	0101000020E610000010B3976DA74D1C4091B75CFDD8984640	\N	\N
485	0	0101000020E610000026FE28EACC4D1C40B325AB22DC984640	\N	\N
486	0	0101000020E6100000923F1878EE4D1C40F969DC9BDF984640	\N	\N
487	0	0101000020E6100000D6726726184E1C40C87DAB75E2984640	\N	\N
488	0	0101000020E6100000D6E6FF55474E1C40F699B33EE5984640	\N	\N
489	0	0101000020E6100000E1B721C66B4E1C40B9FFC874E8984640	\N	\N
490	0	0101000020E61000005890662C9A4E1C405E807D74EA984640	\N	\N
491	0	0101000020E6100000FC5069C4CC4E1C40EDD808C4EB984640	\N	\N
492	0	0101000020E6100000D4997B48F84E1C4057276728EE984640	\N	\N
493	0	0101000020E61000007920B248134F1C4031B5A50EF2984640	\N	\N
494	0	0101000020E61000004BAC8C463E4F1C40DCF29194F4984640	\N	\N
495	0	0101000020E61000004B033FAA614F1C40B1C398F4F7984640	\N	\N
496	0	0101000020E6100000670B08AD874F1C40F607CA6DFB984640	\N	\N
497	0	0101000020E61000002843554CA54F1C40BF2A172AFF984640	\N	\N
498	0	0101000020E6100000BCAFCA85CA4F1C40111D024702994640	\N	\N
499	0	0101000020E610000044A2D0B2EE4F1C400307B47405994640	\N	\N
500	0	0101000020E61000000BB43BA418501C40F0332E1C08994640	\N	\N
501	0	0101000020E6100000F433F5BA45501C401893FE5E0A994640	\N	\N
502	0	0101000020E6100000103CBEBD6B501C40F911BF620D994640	\N	\N
503	0	0101000020E6100000B5C2F4BD86501C40D39FFD4811994640	\N	\N
504	0	0101000020E6100000F31B261AA4501C40FBCA83F414994640	\N	\N
505	0	0101000020E610000010070951BE501C4005DD5ED218994640	\N	\N
506	0	0101000020E610000004C765DCD4501C40C251F2EA1C994640	\N	\N
507	0	0101000020E61000002104E44BA8501C40793D98141F994640	\N	\N
508	0	0101000020E61000008D7A884677501C4044300E2E1D994640	\N	\N
509	0	0101000020E6100000E3FC4D2844501C40A438471D1D994640	\N	\N
510	0	0101000020E6100000AB2688BA0F501C406249B9FB1C994640	\N	\N
511	0	0101000020E610000094BE1072DE4F1C40DF3653211E994640	\N	\N
512	0	0101000020E6100000F0FD0DDAAB4F1C401A69A9BC1D994640	\N	\N
513	0	0101000020E6100000CE1B2785794F1C40C70E2A711D994640	\N	\N
514	0	0101000020E6100000A67C08AA464F1C4015AC71361D994640	\N	\N
515	0	0101000020E610000062BD512B4C4F1C40666A12BC21994640	\N	\N
516	0	0101000020E610000095EEAEB3214F1C40357EE19524994640	\N	\N
517	0	0101000020E6100000F12DAC1BEF4E1C4094861A8524994640	\N	\N
518	0	0101000020E6100000C4D155BABB4E1C40F94B8BFA24994640	\N	\N
519	0	0101000020E610000025CE8AA8894E1C402313F06B24994640	\N	\N
520	0	0101000020E61000001F9DBAF2594E1C40C3D66CE525994640	\N	\N
521	0	0101000020E6100000093543AA284E1C401CEE23B726994640	\N	\N
522	0	0101000020E6100000ED0F94DBF64D1C40B728B34126994640	\N	\N
523	0	0101000020E6100000E8DEC325C74D1C40AA46AF0628994640	\N	\N
524	0	0101000020E61000003D618907944D1C4050FBAD9D28994640	\N	\N
525	0	0101000020E61000007192E68F694D1C40BA490C022B994640	\N	\N
526	0	0101000020E6100000C614AC71364D1C401F0F7D772B994640	\N	\N
527	0	0101000020E61000009F758D96034D1C403D2828452B994640	\N	\N
528	0	0101000020E610000077D66EBBD04C1C40A2ED98BA2B994640	\N	\N
529	0	0101000020E6100000E97DE36BCF4C1C402330D63730994640	\N	\N
530	0	0101000020E6100000E3DD91B1DA4C1C40C748F60835994640	\N	\N
531	0	0101000020E610000099B85510034D1C4007D0EFFB37994640	\N	\N
532	0	0101000020E6100000C7DADFD91E4D1C4070EA03C93B994640	\N	\N
533	0	0101000020E61000009E060C923E4D1C406891ED7C3F994640	\N	\N
534	0	0101000020E6100000100533A6604D1C406DE690D442994640	\N	\N
535	0	0101000020E610000098F738D3844D1C40304CA60A46994640	\N	\N
536	0	0101000020E6100000871744A4A64D1C4087FBC8AD49994640	\N	\N
537	0	0101000020E61000000A6AF816D64D1C404A95287B4B994640	\N	\N
538	0	0101000020E610000081423D7D044E1C40DEAAEB504D994640	\N	\N
539	0	0101000020E6100000B91803EB384E1C409C8713984E994640	\N	\N
540	0	0101000020E61000003691990B5C4E1C405FED28CE51994640	\N	\N
541	0	0101000020E6100000CFD72C978D4E1C408E3D7B2E53994640	\N	\N
542	0	0101000020E6100000417FA1478C4E1C403E0455A357994640	\N	\N
543	0	0101000020E6100000E19A3BFA5F4E1C4037DF88EE59994640	\N	\N
544	0	0101000020E6100000E17D552E544E1C40D63A71395E994640	\N	\N
545	0	0101000020E61000007BF99D26334E1C40DA8F149161994640	\N	\N
546	0	0101000020E610000097AAB4C5354E1C402B4EB51666994640	\N	\N
547	0	0101000020E6100000ED832C0B264E1C4029B2D6506A994640	\N	\N
548	0	0101000020E610000064744012F64D1C408786C5A86B994640	\N	\N
549	0	0101000020E610000070EEAF1EF74D1C4008C9022670994640	\N	\N
550	0	0101000020E6100000B9DE3653214E1C404293C49272994640	\N	\N
551	0	0101000020E6100000D6389B8E004E1C401764CBF275994640	\N	\N
552	0	0101000020E61000006F4562821A4E1C40807EDFBF79994640	\N	\N
553	0	0101000020E61000004DF4F928234E1C40904DF2237E994640	\N	\N
554	0	0101000020E6100000A8FE4124434E1C407689EAAD81994640	\N	\N
555	0	0101000020E610000058A835CD3B4E1C40C7478B3386994640	\N	\N
556	0	0101000020E6100000B935E9B6444E1C40CB68E4F38A994640	\N	\N
557	0	0101000020E6100000253D0CAD4E4E1C402E9276A38F994640	\N	\N
558	0	0101000020E6100000DBC01DA8534E1C404FCC7A3194994640	\N	\N
559	0	0101000020E6100000B98C9B1A684E1C40BEA3C68498994640	\N	\N
560	0	0101000020E6100000C4E9245B5D4E1C402D7B12D89C994640	\N	\N
561	0	0101000020E610000036AE7FD7674E1C403C4A253CA1994640	\N	\N
562	0	0101000020E610000058E20165534E1C40DBA50D87A5994640	\N	\N
563	0	0101000020E6100000F2B4FCC0554E1C40BBF083F3A9994640	\N	\N
564	0	0101000020E6100000CAA65CE15D4E1C40DC2A8881AE994640	\N	\N
565	0	0101000020E61000009CDB847B654E1C408DF161F6B2994640	\N	\N
566	0	0101000020E6100000DBFAE93F6B4E1C40AE2B6684B7994640	\N	\N
567	0	0101000020E6100000BE66B96C744E1C40ED7E15E0BB994640	\N	\N
568	0	0101000020E610000063D009A1834E1C405C566133C0994640	\N	\N
569	0	0101000020E61000004C16F71F994E1C40E9465854C4994640	\N	\N
570	0	0101000020E610000041D653ABAF4E1C4064CC5D4BC8994640	\N	\N
571	0	0101000020E6100000B857E6ADBA4E1C404417D4B7CC994640	\N	\N
572	0	0101000020E6100000C9AB730CC84E1C40B3EE1F0BD1994640	\N	\N
573	0	0101000020E61000002499D53BDC4E1C4040DF162CD5994640	\N	\N
574	0	0101000020E6100000C9022670EB4E1C403D433866D9994640	\N	\N
575	0	0101000020E6100000E5B33C0FEE4E1C40EE0912DBDD994640	\N	\N
576	0	0101000020E6100000FCFECD8B134F1C4010786000E1994640	\N	\N
577	0	0101000020E610000002D9EBDD1F4F1C4061360186E5994640	\N	\N
578	0	0101000020E610000001F6D1A92B4F1C40FF91E9D0E9994640	\N	\N
579	0	0101000020E61000000DFCA886FD4E1C40349F73B7EB994640	\N	\N
580	0	0101000020E6100000EBAA402D064F1C40E4654D2CF0994640	\N	\N
581	0	0101000020E61000002F4D11E0F44E1C4042D2A755F4994640	\N	\N
582	0	0101000020E6100000F1845E7F124F1C403A799109F8994640	\N	\N
583	0	0101000020E61000007F349C32374F1C409DD66D50FB994640	\N	\N
584	0	0101000020E6100000950B957F2D4F1C40BF1072DEFF994640	\N	\N
585	0	0101000020E6100000C8CD70033E4F1C401C7DCC07049A4640	\N	\N
586	0	0101000020E610000023D8B8FE5D4F1C40323D6189079A4640	\N	\N
587	0	0101000020E6100000E5B8533A584F1C40E2033BFE0B9A4640	\N	\N
588	0	0101000020E6100000F0DB10E3354F1C400D33349E089A4640	\N	\N
589	0	0101000020E6100000C9B08A37324F1C40705CC64D0D9A4640	\N	\N
590	0	0101000020E6100000C39B35785F551C40E4D70FB1C1964640	\N	\N
591	0	0101000020E61000009C36E33444551C4041446ADAC5964640	\N	\N
592	0	0101000020E6100000E67805A227551C40E09F5225CA964640	\N	\N
593	0	0101000020E610000008AD872F13551C4007978E39CF964640	\N	\N
594	0	0101000020E6100000D5EAABAB02551C40E1F08288D4964640	\N	\N
595	0	0101000020E6100000F701486DE2541C404A0B9755D8964640	\N	\N
596	0	0101000020E61000001AFCFD62B6541C40122EE411DC964640	\N	\N
597	0	0101000020E6100000E71C3C139A541C40EC87D860E1964640	\N	\N
598	0	0101000020E61000003CD9CD8C7E541C4090A0F831E6964640	\N	\N
599	0	0101000020E610000064CA87A06A541C40BD546CCCEB964640	\N	\N
600	0	0101000020E6100000E2B19FC552541C4032E9EFA5F0964640	\N	\N
601	0	0101000020E61000002C11A8FE41541C40055262D7F6964640	\N	\N
602	0	0101000020E61000001BBD1AA034541C40A96A82A8FB964640	\N	\N
603	0	0101000020E610000081CD397826541C4000E65AB400974640	\N	\N
604	0	0101000020E61000000F09DFFB1B541C402C9ACE4E06974640	\N	\N
605	0	0101000020E610000065FF3C0D18541C40E21DE0490B974640	\N	\N
606	0	0101000020E6100000041BD7BFEB531C405BB6D61709974640	\N	\N
607	0	0101000020E6100000541A31B3CF531C402E02637D03974640	\N	\N
608	0	0101000020E610000038691A14CD531C40DE770C8FFD964640	\N	\N
609	0	0101000020E6100000F48C7DC9C6531C40B1C398F4F7964640	\N	\N
610	0	0101000020E61000000A647616BD531C40BF0D315EF3964640	\N	\N
611	0	0101000020E610000071917BBABA531C409816F549EE964640	\N	\N
612	0	0101000020E6100000DD989EB0C4531C401EC539EAE8964640	\N	\N
613	0	0101000020E6100000BBB6B75B92531C40FAEE5696E8964640	\N	\N
614	0	0101000020E61000008E7747C66A531C408DD0CFD4EB964640	\N	\N
615	0	0101000020E6100000C765DCD440531C40AF3E1EFAEE964640	\N	\N
616	0	0101000020E610000089EFC4AC17531C40F5824F73F2964640	\N	\N
617	0	0101000020E61000009ACFB9DBF5521C406A4B1DE4F5964640	\N	\N
618	0	0101000020E61000000C207C28D1521C4056444DF4F9964640	\N	\N
619	0	0101000020E61000006D567DAEB6521C4090DAC4C9FD964640	\N	\N
620	0	0101000020E6100000F017B325AB521C4034F3E49A02974640	\N	\N
621	0	0101000020E61000003A94A12AA6521C4085B1852007974640	\N	\N
622	0	0101000020E610000018CFA0A17F521C402541B8020A974640	\N	\N
623	0	0101000020E61000005C548B8862521C405ED72FD80D974640	\N	\N
624	0	0101000020E6100000730E9E094D521C40A9D898D711974640	\N	\N
625	0	0101000020E6100000183E22A644521C40E92B483316974640	\N	\N
626	0	0101000020E6100000CF87670932521C40580394861A974640	\N	\N
627	0	0101000020E6100000857AFA08FC511C40E09EE74F1B974640	\N	\N
628	0	0101000020E61000000262122EE4511C402CA0504F1F974640	\N	\N
629	0	0101000020E61000002A1900AAB8511C400C1F115322974640	\N	\N
630	0	0101000020E6100000DB6B41EF8D511C40F94B8BFA24974640	\N	\N
631	0	0101000020E6100000E78EFE976B511C400F0C207C28974640	\N	\N
632	0	0101000020E6100000E7374C3448511C4001F6D1A92B974640	\N	\N
633	0	0101000020E6100000D0ECBAB722511C40836C59BE2E974640	\N	\N
634	0	0101000020E61000006A85E97B0D511C40B05417F032974640	\N	\N
635	0	0101000020E61000006A85E97B0D511C40909F8D5C37974640	\N	\N
636	0	0101000020E61000008179C8940F511C40416667D13B974640	\N	\N
637	0	0101000020E6100000AF27BA2EFC501C403ECA880B40974640	\N	\N
638	0	0101000020E61000006BF46A80D2501C400DDE57E542974640	\N	\N
639	0	0101000020E610000060234910AE501C408F54DFF945974640	\N	\N
640	0	0101000020E61000007C7DAD4B8D501C40ECC039234A974640	\N	\N
641	0	0101000020E6100000E353008C67501C409DBB5D2F4D974640	\N	\N
642	0	0101000020E61000001002F22554501C403C17467A51974640	\N	\N
643	0	0101000020E61000000B28D4D347501C402DCDAD1056974640	\N	\N
644	0	0101000020E61000003E76172829501C40F6EFFACC59974640	\N	\N
645	0	0101000020E61000006CEA3C2AFE4F1C40EFCA2E185C974640	\N	\N
646	0	0101000020E610000044F9821612501C40100533A660974640	\N	\N
647	0	0101000020E61000005B79C9FFE44F1C40396403E962974640	\N	\N
648	0	0101000020E6100000BC92E4B9BE4F1C40496760E465974640	\N	\N
649	0	0101000020E6100000B1FB8EE1B14F1C4029B2D6506A974640	\N	\N
650	0	0101000020E6100000E4141DC9E54F1C40761BD47E6B974640	\N	\N
651	0	0101000020E6100000B6A0F7C610501C40D4BB783F6E974640	\N	\N
652	0	0101000020E6100000C72E51BD35501C40B43A394371974640	\N	\N
653	0	0101000020E610000093E00D6954501C40CAFACDC474974640	\N	\N
654	0	0101000020E610000044334FAE29501C409351651877974640	\N	\N
655	0	0101000020E610000033880FECF84F1C40B6F3FDD478974640	\N	\N
656	0	0101000020E6100000EF54C03DCF4F1C4091B586527B974640	\N	\N
657	0	0101000020E6100000C79DD2C1FA4F1C40DDEA39E97D974640	\N	\N
658	0	0101000020E6100000DEE8633E20501C40A0504F1F81974640	\N	\N
659	0	0101000020E610000066DB696B44501C4004AE2B6684974640	\N	\N
660	0	0101000020E6100000BB287AE063501C407976F9D687974640	\N	\N
661	0	0101000020E61000000AB952CF82501C408388D4B48B974640	\N	\N
662	0	0101000020E6100000321EA5129E501C40BD1E4C8A8F974640	\N	\N
663	0	0101000020E61000004EECA17DAC501C40CCED5EEE93974640	\N	\N
664	0	0101000020E6100000876BB587BD501C404D309C6B98974640	\N	\N
665	0	0101000020E610000087C267EBE0501C40E01115AA9B974640	\N	\N
666	0	0101000020E6100000815CE2C803511C4079B0C56E9F974640	\N	\N
667	0	0101000020E6100000D0ECBAB722511C40D05FE811A3974640	\N	\N
668	0	0101000020E61000001AC05B2041511C40B79BE09BA6974640	\N	\N
669	0	0101000020E61000006493FC885F511C4020B6F468AA974640	\N	\N
670	0	0101000020E61000003602F1BA7E511C40D76D50FBAD974640	\N	\N
671	0	0101000020E6100000ECBFCE4D9B511C40B1FB8EE1B1974640	\N	\N
672	0	0101000020E6100000F2D3B837BF511C4008ABB184B5974640	\N	\N
673	0	0101000020E6100000AD6BB41CE8511C4019AE0E80B8974640	\N	\N
674	0	0101000020E6100000240A2DEBFE511C4064AF777FBC974640	\N	\N
675	0	0101000020E610000046B247A819521C40CDC98B4CC0974640	\N	\N
676	0	0101000020E61000009642209738521C408481E7DEC3974640	\N	\N
677	0	0101000020E6100000B8EA3A5453521C403448C153C8974640	\N	\N
678	0	0101000020E6100000C93EC8B260521C40B58AFED0CC974640	\N	\N
679	0	0101000020E61000001895D40968521C40C5591135D1974640	\N	\N
680	0	0101000020E61000002F6CCD565E521C4004ADC090D5974640	\N	\N
681	0	0101000020E6100000FCC6D79E59521C4085EFFD0DDA974640	\N	\N
682	0	0101000020E6100000E0DBF4673F521C40BE8575E3DD974640	\N	\N
683	0	0101000020E610000002F390291F521C4063D2DF4BE1974640	\N	\N
684	0	0101000020E610000052F2EA1C03521C402CF52C08E5974640	\N	\N
685	0	0101000020E6100000855D143DF0511C40B8E52329E9974640	\N	\N
686	0	0101000020E61000000EBF9B6ED9511C408BFD65F7E4974640	\N	\N
687	0	0101000020E6100000CA8B4CC0AF511C4080B74082E2974640	\N	\N
688	0	0101000020E61000009772BED87B511C40A4C16D6DE1974640	\N	\N
689	0	0101000020E61000008C84B69C4B511C4086747808E3974640	\N	\N
690	0	0101000020E61000002B14E97E4E511C40D732198EE7974640	\N	\N
691	0	0101000020E6100000B43BA41820511C404D2F3196E9974640	\N	\N
692	0	0101000020E61000007C65DEAAEB501C40D6FECEF6E8974640	\N	\N
693	0	0101000020E6100000D1E7A38CB8501C40A7AE7C96E7974640	\N	\N
694	0	0101000020E6100000A9BC1DE1B4501C40C9E88024EC974640	\N	\N
695	0	0101000020E610000071033E3F8C501C406878B306EF974640	\N	\N
696	0	0101000020E6100000C616821C94501C40183F8D7BF3974640	\N	\N
697	0	0101000020E610000055185B0872501C401D9430D3F6974640	\N	\N
698	0	0101000020E61000002D793C2D3F501C402942EA76F6974640	\N	\N
699	0	0101000020E61000001C42959A3D501C40D908C4EBFA974640	\N	\N
700	0	0101000020E610000088B839950C501C40DA3C0E83F9974640	\N	\N
701	0	0101000020E61000007250C24CDB4F1C40BC57AD4CF8974640	\N	\N
702	0	0101000020E610000017299485AF4F1C407A008BFCFA974640	\N	\N
703	0	0101000020E6100000736891ED7C4F1C408C9FC6BDF9974640	\N	\N
704	0	0101000020E610000083F6EAE3A14F1C4090F46915FD974640	\N	\N
705	0	0101000020E61000004580D3BB784F1C40DC291DACFF974640	\N	\N
706	0	0101000020E6100000840EBA84434F1C4024D6E25300984640	\N	\N
707	0	0101000020E610000035B8AD2D3C4F1C40042159C004984640	\N	\N
708	0	0101000020E6100000A12E52280B4F1C4003ED0E2906984640	\N	\N
709	0	0101000020E6100000FC6D4F90D84E1C40A9A10DC006984640	\N	\N
710	0	0101000020E610000024D3A1D3F34E1C4012BC218D0A984640	\N	\N
711	0	0101000020E610000040A19E3E024F1C40C382FB010F984640	\N	\N
712	0	0101000020E6100000E6965643E24E1C40AF7B2B1213984640	\N	\N
713	0	0101000020E6100000BEF73768AF4E1C40C6A354C213984640	\N	\N
714	0	0101000020E6100000CA54C1A8A44E1C4088D51F6118984640	\N	\N
715	0	0101000020E6100000029A081B9E4E1C40399CF9D51C984640	\N	\N
716	0	0101000020E6100000C440D7BE804E1C4001BF469220984640	\N	\N
717	0	0101000020E61000006FD6E07D554E1C400057B26323984640	\N	\N
718	0	0101000020E6100000D0D2156C234E1C40F965304624984640	\N	\N
719	0	0101000020E6100000533D997FF44D1C409FE6E44526984640	\N	\N
720	0	0101000020E6100000B439CE6DC24D1C40511553E927984640	\N	\N
721	0	0101000020E610000026FE28EACC4D1C4060E4654D2C984640	\N	\N
722	0	0101000020E6100000AE0D15E3FC4D1C4036E9B6442E984640	\N	\N
723	0	0101000020E61000003CA06CCA154E1C40E0F2583332984640	\N	\N
724	0	0101000020E6100000A8C4758C2B4E1C409D67EC4B36984640	\N	\N
725	0	0101000020E6100000E7A90EB9194E1C409BCB0D863A984640	\N	\N
726	0	0101000020E610000064575A46EA4D1C40EDF1423A3C984640	\N	\N
727	0	0101000020E61000004832AB77B84D1C40C9E7154F3D984640	\N	\N
728	0	0101000020E610000054C90050C54D1C406743FE9941984640	\N	\N
729	0	0101000020E61000001BA19FA9D74D1C40069FE6E445984640	\N	\N
730	0	0101000020E61000009D9CA1B8E34D1C40757632384A984640	\N	\N
731	0	0101000020E6100000158DB5BFB34D1C4068942EFD4B984640	\N	\N
732	0	0101000020E61000007689EAAD814D1C40DFC4909C4C984640	\N	\N
733	0	0101000020E6100000492D944C4E4D1C401AF7E6374C984640	\N	\N
734	0	0101000020E6100000274BADF71B4D1C4085798F334D984640	\N	\N
735	0	0101000020E6100000164ED2FC314D1C4042EE224C51984640	\N	\N
736	0	0101000020E6100000E31C75745C4D1C40ED2B0FD253984640	\N	\N
737	0	0101000020E6100000D82E6D382C4D1C40E606431D56984640	\N	\N
738	0	0101000020E6100000D8BAD408FD4C1C404A9869FB57984640	\N	\N
739	0	0101000020E6100000E92B4833164D1C40842EE1D05B984640	\N	\N
740	0	0101000020E6100000556D37C1374D1C400B62A06B5F984640	\N	\N
741	0	0101000020E61000002D7C7DAD4B4D1C40A9BD88B663984640	\N	\N
742	0	0101000020E6100000D102B4AD664D1C40B3CF639467984640	\N	\N
743	0	0101000020E6100000D13C80457E4D1C402E55698B6B984640	\N	\N
744	0	0101000020E6100000BA6587F8874D1C400EA0DFF76F984640	\N	\N
745	0	0101000020E610000010E84CDA544D1C40B58828266F984640	\N	\N
746	0	0101000020E61000006B9BE271514D1C40A73E90BC73984640	\N	\N
747	0	0101000020E6100000D102B4AD664D1C4063B323D577984640	\N	\N
748	0	0101000020E610000038BC2022354D1C403563D17476984640	\N	\N
749	0	0101000020E610000016F71F990E4D1C40018A912573984640	\N	\N
750	0	0101000020E610000000AC8E1CE94C1C403E247CEF6F984640	\N	\N
751	0	0101000020E6100000B6BB07E8BE4C1C40C26A2C616D984640	\N	\N
752	0	0101000020E6100000B69E211CB34C1C40314278B471984640	\N	\N
753	0	0101000020E610000094F6065F984C1C40CAE0287975984640	\N	\N
754	0	0101000020E6100000284696CCB14C1C40D4F2035779984640	\N	\N
755	0	0101000020E61000003F575BB1BF4C1C40A2D288997D984640	\N	\N
756	0	0101000020E6100000944DB9C2BB4C1C405299620E82984640	\N	\N
757	0	0101000020E6100000B01BB62DCA4C1C40853E58C686984640	\N	\N
758	0	0101000020E610000022FDF675E04C1C40D13FC1C58A984640	\N	\N
759	0	0101000020E610000055850662D94C1C4063EDEF6C8F984640	\N	\N
760	0	0101000020E610000072361D01DC4C1C40E42F2DEA93984640	\N	\N
761	0	0101000020E61000004A0B9755D84C1C4065726A6798984640	\N	\N
762	0	0101000020E6100000D8800871E54C1C4003CE52B29C984640	\N	\N
763	0	0101000020E61000004F029B73F04C1C40139D6516A1984640	\N	\N
764	0	0101000020E610000099B85510034D1C40A08D5C37A5984640	\N	\N
765	0	0101000020E610000082E15CC30C4D1C4080D8D2A3A9984640	\N	\N
766	0	0101000020E61000009F9273620F4D1C4083F92B64AE984640	\N	\N
767	0	0101000020E610000005DD5ED2184D1C40C24CDBBFB2984640	\N	\N
768	0	0101000020E61000003E3F8C101E4D1C40E486DF4DB7984640	\N	\N
769	0	0101000020E61000001631EC30264D1C40944DB9C2BB984640	\N	\N
770	0	0101000020E6100000FAB9A1293B4D1C4092B1DAFCBF984640	\N	\N
771	0	0101000020E61000008272DBBE474D1C4001892650C4984640	\N	\N
772	0	0101000020E6100000A41AF67B624D1C409A27D714C8984640	\N	\N
773	0	0101000020E61000004E417E36724D1C40978BF84ECC984640	\N	\N
774	0	0101000020E6100000BB48A12C7C4D1C40D7DEA7AAD0984640	\N	\N
775	0	0101000020E6100000F984ECBC8D4D1C405721E527D5984640	\N	\N
776	0	0101000020E610000010B3976DA74D1C4091B75CFDD8984640	\N	\N
777	0	0101000020E610000026FE28EACC4D1C40B325AB22DC984640	\N	\N
778	0	0101000020E6100000923F1878EE4D1C40F969DC9BDF984640	\N	\N
779	0	0101000020E6100000D6726726184E1C40C87DAB75E2984640	\N	\N
780	0	0101000020E6100000D6E6FF55474E1C40F699B33EE5984640	\N	\N
781	0	0101000020E6100000E1B721C66B4E1C40B9FFC874E8984640	\N	\N
782	0	0101000020E61000005890662C9A4E1C405E807D74EA984640	\N	\N
783	0	0101000020E6100000FC5069C4CC4E1C40EDD808C4EB984640	\N	\N
784	0	0101000020E6100000D4997B48F84E1C4057276728EE984640	\N	\N
785	0	0101000020E61000007920B248134F1C4031B5A50EF2984640	\N	\N
786	0	0101000020E61000004BAC8C463E4F1C40DCF29194F4984640	\N	\N
787	0	0101000020E61000004B033FAA614F1C40B1C398F4F7984640	\N	\N
788	0	0101000020E6100000670B08AD874F1C40F607CA6DFB984640	\N	\N
789	0	0101000020E61000002843554CA54F1C40BF2A172AFF984640	\N	\N
790	0	0101000020E6100000BCAFCA85CA4F1C40111D024702994640	\N	\N
791	0	0101000020E610000044A2D0B2EE4F1C400307B47405994640	\N	\N
792	0	0101000020E61000000BB43BA418501C40F0332E1C08994640	\N	\N
793	0	0101000020E6100000F433F5BA45501C401893FE5E0A994640	\N	\N
794	0	0101000020E6100000103CBEBD6B501C40F911BF620D994640	\N	\N
795	0	0101000020E6100000B5C2F4BD86501C40D39FFD4811994640	\N	\N
796	0	0101000020E6100000F31B261AA4501C40FBCA83F414994640	\N	\N
797	0	0101000020E610000010070951BE501C4005DD5ED218994640	\N	\N
798	0	0101000020E610000004C765DCD4501C40C251F2EA1C994640	\N	\N
799	0	0101000020E61000002104E44BA8501C40793D98141F994640	\N	\N
800	0	0101000020E61000008D7A884677501C4044300E2E1D994640	\N	\N
801	0	0101000020E6100000E3FC4D2844501C40A438471D1D994640	\N	\N
802	0	0101000020E6100000AB2688BA0F501C406249B9FB1C994640	\N	\N
803	0	0101000020E610000094BE1072DE4F1C40DF3653211E994640	\N	\N
804	0	0101000020E6100000F0FD0DDAAB4F1C401A69A9BC1D994640	\N	\N
805	0	0101000020E6100000CE1B2785794F1C40C70E2A711D994640	\N	\N
806	0	0101000020E6100000A67C08AA464F1C4015AC71361D994640	\N	\N
807	0	0101000020E610000062BD512B4C4F1C40666A12BC21994640	\N	\N
808	0	0101000020E610000095EEAEB3214F1C40357EE19524994640	\N	\N
809	0	0101000020E6100000F12DAC1BEF4E1C4094861A8524994640	\N	\N
810	0	0101000020E6100000C4D155BABB4E1C40F94B8BFA24994640	\N	\N
811	0	0101000020E610000025CE8AA8894E1C402313F06B24994640	\N	\N
812	0	0101000020E61000001F9DBAF2594E1C40C3D66CE525994640	\N	\N
813	0	0101000020E6100000093543AA284E1C401CEE23B726994640	\N	\N
814	0	0101000020E6100000ED0F94DBF64D1C40B728B34126994640	\N	\N
815	0	0101000020E6100000E8DEC325C74D1C40AA46AF0628994640	\N	\N
816	0	0101000020E61000003D618907944D1C4050FBAD9D28994640	\N	\N
817	0	0101000020E61000007192E68F694D1C40BA490C022B994640	\N	\N
818	0	0101000020E6100000C614AC71364D1C401F0F7D772B994640	\N	\N
819	0	0101000020E61000009F758D96034D1C403D2828452B994640	\N	\N
820	0	0101000020E610000077D66EBBD04C1C40A2ED98BA2B994640	\N	\N
821	0	0101000020E6100000E97DE36BCF4C1C402330D63730994640	\N	\N
822	0	0101000020E6100000E3DD91B1DA4C1C40C748F60835994640	\N	\N
823	0	0101000020E610000099B85510034D1C4007D0EFFB37994640	\N	\N
824	0	0101000020E6100000C7DADFD91E4D1C4070EA03C93B994640	\N	\N
825	0	0101000020E61000009E060C923E4D1C406891ED7C3F994640	\N	\N
826	0	0101000020E6100000100533A6604D1C406DE690D442994640	\N	\N
827	0	0101000020E610000098F738D3844D1C40304CA60A46994640	\N	\N
828	0	0101000020E6100000871744A4A64D1C4087FBC8AD49994640	\N	\N
829	0	0101000020E61000000A6AF816D64D1C404A95287B4B994640	\N	\N
830	0	0101000020E610000081423D7D044E1C40DEAAEB504D994640	\N	\N
831	0	0101000020E6100000B91803EB384E1C409C8713984E994640	\N	\N
832	0	0101000020E61000003691990B5C4E1C405FED28CE51994640	\N	\N
833	0	0101000020E6100000CFD72C978D4E1C408E3D7B2E53994640	\N	\N
834	0	0101000020E6100000417FA1478C4E1C403E0455A357994640	\N	\N
835	0	0101000020E6100000E19A3BFA5F4E1C4037DF88EE59994640	\N	\N
836	0	0101000020E6100000E17D552E544E1C40D63A71395E994640	\N	\N
837	0	0101000020E61000007BF99D26334E1C40DA8F149161994640	\N	\N
838	0	0101000020E610000097AAB4C5354E1C402B4EB51666994640	\N	\N
839	0	0101000020E6100000ED832C0B264E1C4029B2D6506A994640	\N	\N
840	0	0101000020E610000064744012F64D1C408786C5A86B994640	\N	\N
841	0	0101000020E610000070EEAF1EF74D1C4008C9022670994640	\N	\N
842	0	0101000020E6100000B9DE3653214E1C404293C49272994640	\N	\N
843	0	0101000020E6100000D6389B8E004E1C401764CBF275994640	\N	\N
844	0	0101000020E61000006F4562821A4E1C40807EDFBF79994640	\N	\N
845	0	0101000020E61000004DF4F928234E1C40904DF2237E994640	\N	\N
846	0	0101000020E6100000A8FE4124434E1C407689EAAD81994640	\N	\N
847	0	0101000020E610000058A835CD3B4E1C40C7478B3386994640	\N	\N
848	0	0101000020E6100000B935E9B6444E1C40CB68E4F38A994640	\N	\N
849	0	0101000020E6100000253D0CAD4E4E1C402E9276A38F994640	\N	\N
850	0	0101000020E6100000DBC01DA8534E1C404FCC7A3194994640	\N	\N
851	0	0101000020E6100000B98C9B1A684E1C40BEA3C68498994640	\N	\N
852	0	0101000020E6100000C4E9245B5D4E1C402D7B12D89C994640	\N	\N
853	0	0101000020E610000036AE7FD7674E1C403C4A253CA1994640	\N	\N
854	0	0101000020E610000058E20165534E1C40DBA50D87A5994640	\N	\N
855	0	0101000020E6100000F2B4FCC0554E1C40BBF083F3A9994640	\N	\N
856	0	0101000020E6100000CAA65CE15D4E1C40DC2A8881AE994640	\N	\N
857	0	0101000020E61000009CDB847B654E1C408DF161F6B2994640	\N	\N
858	0	0101000020E6100000DBFAE93F6B4E1C40AE2B6684B7994640	\N	\N
859	0	0101000020E6100000BE66B96C744E1C40ED7E15E0BB994640	\N	\N
860	0	0101000020E610000063D009A1834E1C405C566133C0994640	\N	\N
861	0	0101000020E61000004C16F71F994E1C40E9465854C4994640	\N	\N
862	0	0101000020E610000041D653ABAF4E1C4064CC5D4BC8994640	\N	\N
863	0	0101000020E6100000B857E6ADBA4E1C404417D4B7CC994640	\N	\N
864	0	0101000020E6100000C9AB730CC84E1C40B3EE1F0BD1994640	\N	\N
865	0	0101000020E61000002499D53BDC4E1C4040DF162CD5994640	\N	\N
866	0	0101000020E6100000C9022670EB4E1C403D433866D9994640	\N	\N
867	0	0101000020E6100000E5B33C0FEE4E1C40EE0912DBDD994640	\N	\N
868	0	0101000020E6100000FCFECD8B134F1C4010786000E1994640	\N	\N
869	0	0101000020E610000002D9EBDD1F4F1C4061360186E5994640	\N	\N
870	0	0101000020E610000001F6D1A92B4F1C40FF91E9D0E9994640	\N	\N
871	0	0101000020E61000000DFCA886FD4E1C40349F73B7EB994640	\N	\N
872	0	0101000020E6100000EBAA402D064F1C40E4654D2CF0994640	\N	\N
873	0	0101000020E61000002F4D11E0F44E1C4042D2A755F4994640	\N	\N
874	0	0101000020E6100000F1845E7F124F1C403A799109F8994640	\N	\N
875	0	0101000020E61000007F349C32374F1C409DD66D50FB994640	\N	\N
876	0	0101000020E6100000950B957F2D4F1C40BF1072DEFF994640	\N	\N
877	0	0101000020E6100000C8CD70033E4F1C401C7DCC07049A4640	\N	\N
878	0	0101000020E610000023D8B8FE5D4F1C40323D6189079A4640	\N	\N
879	0	0101000020E6100000E5B8533A584F1C40E2033BFE0B9A4640	\N	\N
880	0	0101000020E6100000F0DB10E3354F1C400D33349E089A4640	\N	\N
881	0	0101000020E6100000C9B08A37324F1C40705CC64D0D9A4640	\N	\N
882	0	0101000020E6100000C39B35785F551C40E4D70FB1C1964640	\N	\N
883	0	0101000020E61000009C36E33444551C4041446ADAC5964640	\N	\N
884	0	0101000020E6100000E67805A227551C40E09F5225CA964640	\N	\N
885	0	0101000020E610000008AD872F13551C4007978E39CF964640	\N	\N
886	0	0101000020E6100000D5EAABAB02551C40E1F08288D4964640	\N	\N
887	0	0101000020E6100000F701486DE2541C404A0B9755D8964640	\N	\N
888	0	0101000020E61000001AFCFD62B6541C40122EE411DC964640	\N	\N
889	0	0101000020E6100000E71C3C139A541C40EC87D860E1964640	\N	\N
890	0	0101000020E61000003CD9CD8C7E541C4090A0F831E6964640	\N	\N
891	0	0101000020E610000064CA87A06A541C40BD546CCCEB964640	\N	\N
892	0	0101000020E6100000E2B19FC552541C4032E9EFA5F0964640	\N	\N
893	0	0101000020E61000002C11A8FE41541C40055262D7F6964640	\N	\N
894	0	0101000020E61000001BBD1AA034541C40A96A82A8FB964640	\N	\N
895	0	0101000020E610000081CD397826541C4000E65AB400974640	\N	\N
896	0	0101000020E61000000F09DFFB1B541C402C9ACE4E06974640	\N	\N
897	0	0101000020E610000065FF3C0D18541C40E21DE0490B974640	\N	\N
898	0	0101000020E6100000041BD7BFEB531C405BB6D61709974640	\N	\N
899	0	0101000020E6100000541A31B3CF531C402E02637D03974640	\N	\N
900	0	0101000020E610000038691A14CD531C40DE770C8FFD964640	\N	\N
901	0	0101000020E6100000F48C7DC9C6531C40B1C398F4F7964640	\N	\N
902	0	0101000020E61000000A647616BD531C40BF0D315EF3964640	\N	\N
903	0	0101000020E610000071917BBABA531C409816F549EE964640	\N	\N
904	0	0101000020E6100000DD989EB0C4531C401EC539EAE8964640	\N	\N
905	0	0101000020E6100000BBB6B75B92531C40FAEE5696E8964640	\N	\N
906	0	0101000020E61000008E7747C66A531C408DD0CFD4EB964640	\N	\N
907	0	0101000020E6100000C765DCD440531C40AF3E1EFAEE964640	\N	\N
908	0	0101000020E610000089EFC4AC17531C40F5824F73F2964640	\N	\N
909	0	0101000020E61000009ACFB9DBF5521C406A4B1DE4F5964640	\N	\N
910	0	0101000020E61000000C207C28D1521C4056444DF4F9964640	\N	\N
911	0	0101000020E61000006D567DAEB6521C4090DAC4C9FD964640	\N	\N
912	0	0101000020E6100000F017B325AB521C4034F3E49A02974640	\N	\N
913	0	0101000020E61000003A94A12AA6521C4085B1852007974640	\N	\N
914	0	0101000020E610000018CFA0A17F521C402541B8020A974640	\N	\N
915	0	0101000020E61000005C548B8862521C405ED72FD80D974640	\N	\N
916	0	0101000020E6100000730E9E094D521C40A9D898D711974640	\N	\N
917	0	0101000020E6100000183E22A644521C40E92B483316974640	\N	\N
918	0	0101000020E6100000CF87670932521C40580394861A974640	\N	\N
919	0	0101000020E6100000857AFA08FC511C40E09EE74F1B974640	\N	\N
920	0	0101000020E61000000262122EE4511C402CA0504F1F974640	\N	\N
921	0	0101000020E61000002A1900AAB8511C400C1F115322974640	\N	\N
922	0	0101000020E6100000DB6B41EF8D511C40F94B8BFA24974640	\N	\N
923	0	0101000020E6100000E78EFE976B511C400F0C207C28974640	\N	\N
924	0	0101000020E6100000E7374C3448511C4001F6D1A92B974640	\N	\N
925	0	0101000020E6100000D0ECBAB722511C40836C59BE2E974640	\N	\N
926	0	0101000020E61000006A85E97B0D511C40B05417F032974640	\N	\N
927	0	0101000020E61000006A85E97B0D511C40909F8D5C37974640	\N	\N
928	0	0101000020E61000008179C8940F511C40416667D13B974640	\N	\N
929	0	0101000020E6100000AF27BA2EFC501C403ECA880B40974640	\N	\N
930	0	0101000020E61000006BF46A80D2501C400DDE57E542974640	\N	\N
931	0	0101000020E610000060234910AE501C408F54DFF945974640	\N	\N
932	0	0101000020E61000007C7DAD4B8D501C40ECC039234A974640	\N	\N
933	0	0101000020E6100000E353008C67501C409DBB5D2F4D974640	\N	\N
934	0	0101000020E61000001002F22554501C403C17467A51974640	\N	\N
935	0	0101000020E61000000B28D4D347501C402DCDAD1056974640	\N	\N
936	0	0101000020E61000003E76172829501C40F6EFFACC59974640	\N	\N
937	0	0101000020E61000006CEA3C2AFE4F1C40EFCA2E185C974640	\N	\N
938	0	0101000020E610000044F9821612501C40100533A660974640	\N	\N
939	0	0101000020E61000005B79C9FFE44F1C40396403E962974640	\N	\N
940	0	0101000020E6100000BC92E4B9BE4F1C40496760E465974640	\N	\N
941	0	0101000020E6100000B1FB8EE1B14F1C4029B2D6506A974640	\N	\N
942	0	0101000020E6100000E4141DC9E54F1C40761BD47E6B974640	\N	\N
943	0	0101000020E6100000B6A0F7C610501C40D4BB783F6E974640	\N	\N
944	0	0101000020E6100000C72E51BD35501C40B43A394371974640	\N	\N
945	0	0101000020E610000093E00D6954501C40CAFACDC474974640	\N	\N
946	0	0101000020E610000044334FAE29501C409351651877974640	\N	\N
947	0	0101000020E610000033880FECF84F1C40B6F3FDD478974640	\N	\N
948	0	0101000020E6100000EF54C03DCF4F1C4091B586527B974640	\N	\N
949	0	0101000020E6100000C79DD2C1FA4F1C40DDEA39E97D974640	\N	\N
950	0	0101000020E6100000DEE8633E20501C40A0504F1F81974640	\N	\N
951	0	0101000020E610000066DB696B44501C4004AE2B6684974640	\N	\N
952	0	0101000020E6100000BB287AE063501C407976F9D687974640	\N	\N
953	0	0101000020E61000000AB952CF82501C408388D4B48B974640	\N	\N
954	0	0101000020E6100000321EA5129E501C40BD1E4C8A8F974640	\N	\N
955	0	0101000020E61000004EECA17DAC501C40CCED5EEE93974640	\N	\N
956	0	0101000020E6100000876BB587BD501C404D309C6B98974640	\N	\N
957	0	0101000020E610000087C267EBE0501C40E01115AA9B974640	\N	\N
958	0	0101000020E6100000815CE2C803511C4079B0C56E9F974640	\N	\N
959	0	0101000020E6100000D0ECBAB722511C40D05FE811A3974640	\N	\N
960	0	0101000020E61000001AC05B2041511C40B79BE09BA6974640	\N	\N
961	0	0101000020E61000006493FC885F511C4020B6F468AA974640	\N	\N
962	0	0101000020E61000003602F1BA7E511C40D76D50FBAD974640	\N	\N
963	0	0101000020E6100000ECBFCE4D9B511C40B1FB8EE1B1974640	\N	\N
964	0	0101000020E6100000F2D3B837BF511C4008ABB184B5974640	\N	\N
965	0	0101000020E6100000AD6BB41CE8511C4019AE0E80B8974640	\N	\N
966	0	0101000020E6100000240A2DEBFE511C4064AF777FBC974640	\N	\N
967	0	0101000020E610000046B247A819521C40CDC98B4CC0974640	\N	\N
968	0	0101000020E61000009642209738521C408481E7DEC3974640	\N	\N
969	0	0101000020E6100000B8EA3A5453521C403448C153C8974640	\N	\N
970	0	0101000020E6100000C93EC8B260521C40B58AFED0CC974640	\N	\N
971	0	0101000020E61000001895D40968521C40C5591135D1974640	\N	\N
972	0	0101000020E61000002F6CCD565E521C4004ADC090D5974640	\N	\N
973	0	0101000020E6100000FCC6D79E59521C4085EFFD0DDA974640	\N	\N
974	0	0101000020E6100000E0DBF4673F521C40BE8575E3DD974640	\N	\N
975	0	0101000020E610000002F390291F521C4063D2DF4BE1974640	\N	\N
976	0	0101000020E610000052F2EA1C03521C402CF52C08E5974640	\N	\N
977	0	0101000020E6100000855D143DF0511C40B8E52329E9974640	\N	\N
978	0	0101000020E61000000EBF9B6ED9511C408BFD65F7E4974640	\N	\N
979	0	0101000020E6100000CA8B4CC0AF511C4080B74082E2974640	\N	\N
980	0	0101000020E61000009772BED87B511C40A4C16D6DE1974640	\N	\N
981	0	0101000020E61000008C84B69C4B511C4086747808E3974640	\N	\N
982	0	0101000020E61000002B14E97E4E511C40D732198EE7974640	\N	\N
983	0	0101000020E6100000B43BA41820511C404D2F3196E9974640	\N	\N
984	0	0101000020E61000007C65DEAAEB501C40D6FECEF6E8974640	\N	\N
985	0	0101000020E6100000D1E7A38CB8501C40A7AE7C96E7974640	\N	\N
986	0	0101000020E6100000A9BC1DE1B4501C40C9E88024EC974640	\N	\N
987	0	0101000020E610000071033E3F8C501C406878B306EF974640	\N	\N
988	0	0101000020E6100000C616821C94501C40183F8D7BF3974640	\N	\N
989	0	0101000020E610000055185B0872501C401D9430D3F6974640	\N	\N
990	0	0101000020E61000002D793C2D3F501C402942EA76F6974640	\N	\N
991	0	0101000020E61000001C42959A3D501C40D908C4EBFA974640	\N	\N
992	0	0101000020E610000088B839950C501C40DA3C0E83F9974640	\N	\N
993	0	0101000020E61000007250C24CDB4F1C40BC57AD4CF8974640	\N	\N
994	0	0101000020E610000017299485AF4F1C407A008BFCFA974640	\N	\N
995	0	0101000020E6100000736891ED7C4F1C408C9FC6BDF9974640	\N	\N
996	0	0101000020E610000083F6EAE3A14F1C4090F46915FD974640	\N	\N
997	0	0101000020E61000004580D3BB784F1C40DC291DACFF974640	\N	\N
998	0	0101000020E6100000840EBA84434F1C4024D6E25300984640	\N	\N
999	0	0101000020E610000035B8AD2D3C4F1C40042159C004984640	\N	\N
1000	0	0101000020E6100000A12E52280B4F1C4003ED0E2906984640	\N	\N
1001	0	0101000020E6100000FC6D4F90D84E1C40A9A10DC006984640	\N	\N
1002	0	0101000020E610000024D3A1D3F34E1C4012BC218D0A984640	\N	\N
1003	0	0101000020E610000040A19E3E024F1C40C382FB010F984640	\N	\N
1004	0	0101000020E6100000E6965643E24E1C40AF7B2B1213984640	\N	\N
1005	0	0101000020E6100000BEF73768AF4E1C40C6A354C213984640	\N	\N
1006	0	0101000020E6100000CA54C1A8A44E1C4088D51F6118984640	\N	\N
1007	0	0101000020E6100000029A081B9E4E1C40399CF9D51C984640	\N	\N
1008	0	0101000020E6100000C440D7BE804E1C4001BF469220984640	\N	\N
1009	0	0101000020E61000006FD6E07D554E1C400057B26323984640	\N	\N
1010	0	0101000020E6100000D0D2156C234E1C40F965304624984640	\N	\N
1011	0	0101000020E6100000533D997FF44D1C409FE6E44526984640	\N	\N
1012	0	0101000020E6100000B439CE6DC24D1C40511553E927984640	\N	\N
1013	0	0101000020E610000026FE28EACC4D1C4060E4654D2C984640	\N	\N
1014	0	0101000020E6100000AE0D15E3FC4D1C4036E9B6442E984640	\N	\N
1015	0	0101000020E61000003CA06CCA154E1C40E0F2583332984640	\N	\N
1016	0	0101000020E6100000A8C4758C2B4E1C409D67EC4B36984640	\N	\N
1017	0	0101000020E6100000E7A90EB9194E1C409BCB0D863A984640	\N	\N
1018	0	0101000020E610000064575A46EA4D1C40EDF1423A3C984640	\N	\N
1019	0	0101000020E61000004832AB77B84D1C40C9E7154F3D984640	\N	\N
1020	0	0101000020E610000054C90050C54D1C406743FE9941984640	\N	\N
1021	0	0101000020E61000001BA19FA9D74D1C40069FE6E445984640	\N	\N
1022	0	0101000020E61000009D9CA1B8E34D1C40757632384A984640	\N	\N
1023	0	0101000020E6100000158DB5BFB34D1C4068942EFD4B984640	\N	\N
1024	0	0101000020E61000007689EAAD814D1C40DFC4909C4C984640	\N	\N
1025	0	0101000020E6100000492D944C4E4D1C401AF7E6374C984640	\N	\N
1026	0	0101000020E6100000274BADF71B4D1C4085798F334D984640	\N	\N
1027	0	0101000020E6100000164ED2FC314D1C4042EE224C51984640	\N	\N
1028	0	0101000020E6100000E31C75745C4D1C40ED2B0FD253984640	\N	\N
1029	0	0101000020E6100000D82E6D382C4D1C40E606431D56984640	\N	\N
1030	0	0101000020E6100000D8BAD408FD4C1C404A9869FB57984640	\N	\N
1031	0	0101000020E6100000E92B4833164D1C40842EE1D05B984640	\N	\N
1032	0	0101000020E6100000556D37C1374D1C400B62A06B5F984640	\N	\N
1033	0	0101000020E61000002D7C7DAD4B4D1C40A9BD88B663984640	\N	\N
1034	0	0101000020E6100000D102B4AD664D1C40B3CF639467984640	\N	\N
1035	0	0101000020E6100000D13C80457E4D1C402E55698B6B984640	\N	\N
1036	0	0101000020E6100000BA6587F8874D1C400EA0DFF76F984640	\N	\N
1037	0	0101000020E610000010E84CDA544D1C40B58828266F984640	\N	\N
1038	0	0101000020E61000006B9BE271514D1C40A73E90BC73984640	\N	\N
1039	0	0101000020E6100000D102B4AD664D1C4063B323D577984640	\N	\N
1040	0	0101000020E610000038BC2022354D1C403563D17476984640	\N	\N
1041	0	0101000020E610000016F71F990E4D1C40018A912573984640	\N	\N
1042	0	0101000020E610000000AC8E1CE94C1C403E247CEF6F984640	\N	\N
1043	0	0101000020E6100000B6BB07E8BE4C1C40C26A2C616D984640	\N	\N
1044	0	0101000020E6100000B69E211CB34C1C40314278B471984640	\N	\N
1045	0	0101000020E610000094F6065F984C1C40CAE0287975984640	\N	\N
1046	0	0101000020E6100000284696CCB14C1C40D4F2035779984640	\N	\N
1047	0	0101000020E61000003F575BB1BF4C1C40A2D288997D984640	\N	\N
1048	0	0101000020E6100000944DB9C2BB4C1C405299620E82984640	\N	\N
1049	0	0101000020E6100000B01BB62DCA4C1C40853E58C686984640	\N	\N
1050	0	0101000020E610000022FDF675E04C1C40D13FC1C58A984640	\N	\N
1051	0	0101000020E610000055850662D94C1C4063EDEF6C8F984640	\N	\N
1052	0	0101000020E610000072361D01DC4C1C40E42F2DEA93984640	\N	\N
1053	0	0101000020E61000004A0B9755D84C1C4065726A6798984640	\N	\N
1054	0	0101000020E6100000D8800871E54C1C4003CE52B29C984640	\N	\N
1055	0	0101000020E61000004F029B73F04C1C40139D6516A1984640	\N	\N
1056	0	0101000020E610000099B85510034D1C40A08D5C37A5984640	\N	\N
1057	0	0101000020E610000082E15CC30C4D1C4080D8D2A3A9984640	\N	\N
1058	0	0101000020E61000009F9273620F4D1C4083F92B64AE984640	\N	\N
1059	0	0101000020E610000005DD5ED2184D1C40C24CDBBFB2984640	\N	\N
1060	0	0101000020E61000003E3F8C101E4D1C40E486DF4DB7984640	\N	\N
1061	0	0101000020E61000001631EC30264D1C40944DB9C2BB984640	\N	\N
1062	0	0101000020E6100000FAB9A1293B4D1C4092B1DAFCBF984640	\N	\N
1063	0	0101000020E61000008272DBBE474D1C4001892650C4984640	\N	\N
1064	0	0101000020E6100000A41AF67B624D1C409A27D714C8984640	\N	\N
1065	0	0101000020E61000004E417E36724D1C40978BF84ECC984640	\N	\N
1066	0	0101000020E6100000BB48A12C7C4D1C40D7DEA7AAD0984640	\N	\N
1067	0	0101000020E6100000F984ECBC8D4D1C405721E527D5984640	\N	\N
1068	0	0101000020E610000010B3976DA74D1C4091B75CFDD8984640	\N	\N
1069	0	0101000020E610000026FE28EACC4D1C40B325AB22DC984640	\N	\N
1070	0	0101000020E6100000923F1878EE4D1C40F969DC9BDF984640	\N	\N
1071	0	0101000020E6100000D6726726184E1C40C87DAB75E2984640	\N	\N
1072	0	0101000020E6100000D6E6FF55474E1C40F699B33EE5984640	\N	\N
1073	0	0101000020E6100000E1B721C66B4E1C40B9FFC874E8984640	\N	\N
1074	0	0101000020E61000005890662C9A4E1C405E807D74EA984640	\N	\N
1075	0	0101000020E6100000FC5069C4CC4E1C40EDD808C4EB984640	\N	\N
1076	0	0101000020E6100000D4997B48F84E1C4057276728EE984640	\N	\N
1077	0	0101000020E61000007920B248134F1C4031B5A50EF2984640	\N	\N
1078	0	0101000020E61000004BAC8C463E4F1C40DCF29194F4984640	\N	\N
1079	0	0101000020E61000004B033FAA614F1C40B1C398F4F7984640	\N	\N
1080	0	0101000020E6100000670B08AD874F1C40F607CA6DFB984640	\N	\N
1081	0	0101000020E61000002843554CA54F1C40BF2A172AFF984640	\N	\N
1082	0	0101000020E6100000BCAFCA85CA4F1C40111D024702994640	\N	\N
1083	0	0101000020E610000044A2D0B2EE4F1C400307B47405994640	\N	\N
1084	0	0101000020E61000000BB43BA418501C40F0332E1C08994640	\N	\N
1085	0	0101000020E6100000F433F5BA45501C401893FE5E0A994640	\N	\N
1086	0	0101000020E6100000103CBEBD6B501C40F911BF620D994640	\N	\N
1087	0	0101000020E6100000B5C2F4BD86501C40D39FFD4811994640	\N	\N
1088	0	0101000020E6100000F31B261AA4501C40FBCA83F414994640	\N	\N
1089	0	0101000020E610000010070951BE501C4005DD5ED218994640	\N	\N
1090	0	0101000020E610000004C765DCD4501C40C251F2EA1C994640	\N	\N
1091	0	0101000020E61000002104E44BA8501C40793D98141F994640	\N	\N
1092	0	0101000020E61000008D7A884677501C4044300E2E1D994640	\N	\N
1093	0	0101000020E6100000E3FC4D2844501C40A438471D1D994640	\N	\N
1094	0	0101000020E6100000AB2688BA0F501C406249B9FB1C994640	\N	\N
1095	0	0101000020E610000094BE1072DE4F1C40DF3653211E994640	\N	\N
1096	0	0101000020E6100000F0FD0DDAAB4F1C401A69A9BC1D994640	\N	\N
1097	0	0101000020E6100000CE1B2785794F1C40C70E2A711D994640	\N	\N
1098	0	0101000020E6100000A67C08AA464F1C4015AC71361D994640	\N	\N
1099	0	0101000020E610000062BD512B4C4F1C40666A12BC21994640	\N	\N
1100	0	0101000020E610000095EEAEB3214F1C40357EE19524994640	\N	\N
1101	0	0101000020E6100000F12DAC1BEF4E1C4094861A8524994640	\N	\N
1102	0	0101000020E6100000C4D155BABB4E1C40F94B8BFA24994640	\N	\N
1103	0	0101000020E610000025CE8AA8894E1C402313F06B24994640	\N	\N
1104	0	0101000020E61000001F9DBAF2594E1C40C3D66CE525994640	\N	\N
1105	0	0101000020E6100000093543AA284E1C401CEE23B726994640	\N	\N
1106	0	0101000020E6100000ED0F94DBF64D1C40B728B34126994640	\N	\N
1107	0	0101000020E6100000E8DEC325C74D1C40AA46AF0628994640	\N	\N
1108	0	0101000020E61000003D618907944D1C4050FBAD9D28994640	\N	\N
1109	0	0101000020E61000007192E68F694D1C40BA490C022B994640	\N	\N
1110	0	0101000020E6100000C614AC71364D1C401F0F7D772B994640	\N	\N
1111	0	0101000020E61000009F758D96034D1C403D2828452B994640	\N	\N
1112	0	0101000020E610000077D66EBBD04C1C40A2ED98BA2B994640	\N	\N
1113	0	0101000020E6100000E97DE36BCF4C1C402330D63730994640	\N	\N
1114	0	0101000020E6100000E3DD91B1DA4C1C40C748F60835994640	\N	\N
1115	0	0101000020E610000099B85510034D1C4007D0EFFB37994640	\N	\N
1116	0	0101000020E6100000C7DADFD91E4D1C4070EA03C93B994640	\N	\N
1117	0	0101000020E61000009E060C923E4D1C406891ED7C3F994640	\N	\N
1118	0	0101000020E6100000100533A6604D1C406DE690D442994640	\N	\N
1119	0	0101000020E610000098F738D3844D1C40304CA60A46994640	\N	\N
1120	0	0101000020E6100000871744A4A64D1C4087FBC8AD49994640	\N	\N
1121	0	0101000020E61000000A6AF816D64D1C404A95287B4B994640	\N	\N
1122	0	0101000020E610000081423D7D044E1C40DEAAEB504D994640	\N	\N
1123	0	0101000020E6100000B91803EB384E1C409C8713984E994640	\N	\N
1124	0	0101000020E61000003691990B5C4E1C405FED28CE51994640	\N	\N
1125	0	0101000020E6100000CFD72C978D4E1C408E3D7B2E53994640	\N	\N
1126	0	0101000020E6100000417FA1478C4E1C403E0455A357994640	\N	\N
1127	0	0101000020E6100000E19A3BFA5F4E1C4037DF88EE59994640	\N	\N
1128	0	0101000020E6100000E17D552E544E1C40D63A71395E994640	\N	\N
1129	0	0101000020E61000007BF99D26334E1C40DA8F149161994640	\N	\N
1130	0	0101000020E610000097AAB4C5354E1C402B4EB51666994640	\N	\N
1131	0	0101000020E6100000ED832C0B264E1C4029B2D6506A994640	\N	\N
1132	0	0101000020E610000064744012F64D1C408786C5A86B994640	\N	\N
1133	0	0101000020E610000070EEAF1EF74D1C4008C9022670994640	\N	\N
1134	0	0101000020E6100000B9DE3653214E1C404293C49272994640	\N	\N
1135	0	0101000020E6100000D6389B8E004E1C401764CBF275994640	\N	\N
1136	0	0101000020E61000006F4562821A4E1C40807EDFBF79994640	\N	\N
1137	0	0101000020E61000004DF4F928234E1C40904DF2237E994640	\N	\N
1138	0	0101000020E6100000A8FE4124434E1C407689EAAD81994640	\N	\N
1139	0	0101000020E610000058A835CD3B4E1C40C7478B3386994640	\N	\N
1140	0	0101000020E6100000B935E9B6444E1C40CB68E4F38A994640	\N	\N
1141	0	0101000020E6100000253D0CAD4E4E1C402E9276A38F994640	\N	\N
1142	0	0101000020E6100000DBC01DA8534E1C404FCC7A3194994640	\N	\N
1143	0	0101000020E6100000B98C9B1A684E1C40BEA3C68498994640	\N	\N
1144	0	0101000020E6100000C4E9245B5D4E1C402D7B12D89C994640	\N	\N
1145	0	0101000020E610000036AE7FD7674E1C403C4A253CA1994640	\N	\N
1146	0	0101000020E610000058E20165534E1C40DBA50D87A5994640	\N	\N
1147	0	0101000020E6100000F2B4FCC0554E1C40BBF083F3A9994640	\N	\N
1148	0	0101000020E6100000CAA65CE15D4E1C40DC2A8881AE994640	\N	\N
1149	0	0101000020E61000009CDB847B654E1C408DF161F6B2994640	\N	\N
1150	0	0101000020E6100000DBFAE93F6B4E1C40AE2B6684B7994640	\N	\N
1151	0	0101000020E6100000BE66B96C744E1C40ED7E15E0BB994640	\N	\N
1152	0	0101000020E610000063D009A1834E1C405C566133C0994640	\N	\N
1153	0	0101000020E61000004C16F71F994E1C40E9465854C4994640	\N	\N
1154	0	0101000020E610000041D653ABAF4E1C4064CC5D4BC8994640	\N	\N
1155	0	0101000020E6100000B857E6ADBA4E1C404417D4B7CC994640	\N	\N
1156	0	0101000020E6100000C9AB730CC84E1C40B3EE1F0BD1994640	\N	\N
1157	0	0101000020E61000002499D53BDC4E1C4040DF162CD5994640	\N	\N
1158	0	0101000020E6100000C9022670EB4E1C403D433866D9994640	\N	\N
1159	0	0101000020E6100000E5B33C0FEE4E1C40EE0912DBDD994640	\N	\N
1160	0	0101000020E6100000FCFECD8B134F1C4010786000E1994640	\N	\N
1161	0	0101000020E610000002D9EBDD1F4F1C4061360186E5994640	\N	\N
1162	0	0101000020E610000001F6D1A92B4F1C40FF91E9D0E9994640	\N	\N
1163	0	0101000020E61000000DFCA886FD4E1C40349F73B7EB994640	\N	\N
1164	0	0101000020E6100000EBAA402D064F1C40E4654D2CF0994640	\N	\N
1165	0	0101000020E61000002F4D11E0F44E1C4042D2A755F4994640	\N	\N
1166	0	0101000020E6100000F1845E7F124F1C403A799109F8994640	\N	\N
1167	0	0101000020E61000007F349C32374F1C409DD66D50FB994640	\N	\N
1168	0	0101000020E6100000950B957F2D4F1C40BF1072DEFF994640	\N	\N
1169	0	0101000020E6100000C8CD70033E4F1C401C7DCC07049A4640	\N	\N
1170	0	0101000020E610000023D8B8FE5D4F1C40323D6189079A4640	\N	\N
1171	0	0101000020E6100000E5B8533A584F1C40E2033BFE0B9A4640	\N	\N
1172	0	0101000020E6100000F0DB10E3354F1C400D33349E089A4640	\N	\N
1173	0	0101000020E6100000C9B08A37324F1C40705CC64D0D9A4640	\N	\N
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash") FROM stdin;
1				2	test@test.com	\N	f	\N
2	$2b$10$w53zf1BpafPwPxfyVY.HSuD6TYK1K8tQEo7bKD/ZWaHiAb0sUeoC.	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N
4	$2b$10$MvcSSTPKT4deuYGizasjXuoAXiK5yzjfDRLmQvviABaRGzjm9UHKy	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N
5	$2b$10$juUW3ATDfrE2VHfgTVX4.elRtdBTCWdruw1vnPnTDrUMMnUqeYWR2	Laura	Zurru	5	laura@emergency.it	\N	t	\N
3	$2b$10$9qNqebiQxus6rzOh5hoTsOt1VoJ7Yc6UyKUlRmg3zJ2siGt/C6X2W	vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 376, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 1, false);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 1, false);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 1173, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: hike_points PK_7fc686c35c52228d8494a7c4947; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_7fc686c35c52228d8494a7c4947" PRIMARY KEY ("hikeId", "pointId");


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

