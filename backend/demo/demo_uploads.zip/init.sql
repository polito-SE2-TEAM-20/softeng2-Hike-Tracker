--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$l2aGdrtRwdg5Ns8btoaTDeh0O0c0Sj9WLOO2doxKsuBZ5sge.5eYK',
    'Antonio',
    'Battipaglia',
    2,
    true
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$p8eNgZI463cwxcdbU1eQuu54.gq6wivuLcqnyNmwWOx7jrJqI4DvS',
    'Erfan',
    'Gholami',
    4,
    true
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$pN86ixOrLTvLSbp2d1/8qexLBmj0RrRuqatMUhooFp3hr.MtQNBES',
    'Laura',
    'Zurru',
    5,
    true
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$B9SmKe2eKywAdTsV8DKVnugDzBmaUQ8XeWbB7RnJy0a/WEGOv40NG',
    'German',
    'Gorodnev',
    0,
    true
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$KJCV8GtnaVFQoZ.GEr.Yzu3Cq5VTF0UnEEzVpeYERDo4FpkydXVlC',
    'vincenzo',
    'Sagristano',
    3,
    true
    true
  );
  

      CREATE OR REPLACE FUNCTION public.insert_hike(
        user_id integer,
        title varchar,
        difficulty integer,
        gpx_path varchar,
        country varchar,
        region varchar,
        province varchar,
        city varchar,
        length numeric(12,2),
        ascent numeric(12,2),
        expected_time integer,
        description varchar,
        pictures jsonb,
        start_point jsonb,
        end_point jsonb,
        reference_points jsonb
      )  RETURNS VOID AS
      $func$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hike"(
        2,
        'Amprimo',
        2,
        '/static/gpx/Amprimo.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        0.8,
        8.9,
        80,
        'Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.',
        '["/static/images/3.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.165559804,"lat":45.102780737}'::jsonb,
        '{"name":"End Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.14299586,"lat":45.099887898}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":7.164360252,"lat":45.102912389,"altitude":1256.852},{"name":"Ref Point 2","address":"","lon":7.158207147,"lat":45.102886551,"altitude":1283.605}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello Chateau Beaulard - Cotolivier - Vazon',
        1,
        '/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Beaulard',
        18.9,
        25,
        200,
        'Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.',
        '["/static/images/2.jpg"]'::jsonb,
        '{"name":"Start Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.772358,"lat":45.03205}'::jsonb,
        '{"name":"End Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.77234,"lat":45.032238}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago Bianco',
        2,
        '/static/gpx/Lago Bianco.gpx',
        'Francia',
        'Auvergne-Rhone-Alpes',
        'Savoia',
        'Val-Cenis',
        14.7,
        21.6,
        210,
        'Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.

La diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.

La Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.

Si può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.',
        '["/static/images/1.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945681,"lat":45.223814}'::jsonb,
        '{"name":"End Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945581,"lat":45.224058}'::jsonb,
        '[{"name":"fountain","address":"","lon":6.940291,"lat":45.222543,"altitude":2027},{"name":"Peak","address":"","lon":6.937204,"lat":45.215867,"altitude":2131}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Alte Langhe Settentrionali - Cossano Belbo',
        2,
        '/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cossano Belbo',
        6.7,
        5.6,
        200,
        'Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.
Si svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.
Si imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.
Inizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.
Percorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. 
Seguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. 
Si procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante',
        '["/static/images/4.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199049,"lat":44.670379}'::jsonb,
        '{"name":"End Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199052,"lat":44.670377}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":8.214142,"lat":44.674545,"altitude":482.526},{"name":"Ref Point 2","address":"","lon":8.197792,"lat":44.668772,"altitude":242.585}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'La pieve romanica di Piesenzana e la valle delle tartufaie',
        2,
        '/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montechiaro d''Asti',
        4.2,
        25.4,
        225,
        'Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. 
Circa 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. 
In regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. 
A Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). 
Contemporaneamente i ristoranti della zona propongono piatti a base di tartufi',
        '["/static/images/5.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.113224,"lat":45.007605}'::jsonb,
        '{"name":"End Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.11358,"lat":45.007557}'::jsonb,
        NULL
      );
    
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2),
        working_time_start time without time zone,
        working_time_end time without time zone,
        email varchar,
        phone_number varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        8,
        120::numeric(12,2),
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Alessandra Lorenzini',
        'http://barren-ethyl.it',
        316.871,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Volfango.Miccoli22@email.it',
        '+394683577164'
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        10,
        129::numeric(12,2),
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Aldo Caradonna',
        'https://delectable-heroine.it',
        325.42,
        '08:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Romeo_Solinas85@yahoo.com',
        '+396481491589'
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        3,
        90::numeric(12,2),
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Ilaria Scardino',
        'https://milky-garter.org',
        332.908,
        '03:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Agnese79@hotmail.com',
        '+393721844482'
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        4,
        93::numeric(12,2),
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Cornelia Privitera',
        'http://metallic-tribe.net',
        321.357,
        '03:00:00'::time without time zone,
        '09:00:00'::time without time zone,
        'Diocleziano_Mauri@hotmail.com',
        '+393468019888'
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        1,
        90::numeric(12,2),
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Odidone Crisci',
        'http://trusting-disembodiment.org',
        276.904,
        '05:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Bonaldo.Cruciani@yahoo.it',
        '+395221827408'
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        3,
        122::numeric(12,2),
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Fausto Cozzi',
        'http://instructive-daily.net',
        266.857,
        '06:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Tesifonte.Casella@yahoo.com',
        '+395436250888'
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        8,
        125::numeric(12,2),
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Ortensio Denaro',
        'http://feline-hull.org',
        316.942,
        '02:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Ermete_Cingolani96@yahoo.com',
        '+398901210930'
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        5,
        112::numeric(12,2),
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Ing. Seconda Sannino',
        'http://popular-macrame.net',
        275.941,
        '02:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Loredana_Pezzi@email.it',
        '+390300900591'
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        7,
        112::numeric(12,2),
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Erenia Campanile',
        'http://mundane-socialism.com',
        266.299,
        '05:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Carmen94@yahoo.com',
        '+391544261604'
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        1,
        47::numeric(12,2),
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Ulfa Caggiano',
        'http://elegant-step-grandmother.it',
        334.607,
        '04:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Aleramo67@gmail.com',
        '+394000754850'
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        2,
        77::numeric(12,2),
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Andrea Altieri',
        'http://modest-interpretation.it',
        290.859,
        '02:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Colombo_Cordioli@gmail.com',
        '+392093352938'
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        5,
        76::numeric(12,2),
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Fleano Buccheri',
        'http://stable-underwriting.com',
        269.453,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Prudenzio80@email.it',
        '+396007992792'
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        9,
        140::numeric(12,2),
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Brigitta Torre',
        'https://rapid-tambourine.com',
        320.18,
        '04:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Ulfa59@gmail.com',
        '+395516439702'
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        7,
        81::numeric(12,2),
        'Vernagthütte',
        'Austria',
        'Ildebrando Liguori',
        'http://blue-bikini.com',
        291.473,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Fiammetta.Mazzarella@yahoo.it',
        '+398429352730'
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        8,
        144::numeric(12,2),
        'Wormser Hütte',
        'Austria',
        'Donatella Bodini',
        'https://productive-mention.com',
        318.897,
        '07:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Filiberto_DiPaolo@yahoo.com',
        '+398208913179'
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        3,
        83::numeric(12,2),
        'Biberacher Hütte',
        'Austria',
        'Benigna Masciandaro',
        'https://heavenly-mineral.com',
        274.925,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Cristina83@gmail.com',
        '+390397476778'
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        8,
        66::numeric(12,2),
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Lazzaro Bini',
        'https://good-natured-custard.com',
        279.611,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Viliana.Grassi@hotmail.com',
        '+396344674113'
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        4,
        120::numeric(12,2),
        'Hochwaldhütte',
        'Germany',
        'Natalia Gandolfo',
        'https://acceptable-road.net',
        309.731,
        '08:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Fiorenza93@gmail.com',
        '+391146593844'
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        8,
        69::numeric(12,2),
        'Kölner Eifelhütte',
        'Germany',
        'Asia Marelli',
        'https://lame-glut.com',
        305.779,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Prospero_Ruggiero@email.it',
        '+396339572170'
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        8,
        112::numeric(12,2),
        'Madrisahütte',
        'Austria',
        'Fortunato Buonomo',
        'http://authorized-undershirt.com',
        274.126,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Ido57@yahoo.it',
        '+396023391399'
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        3,
        82::numeric(12,2),
        'Dresdner Hütte',
        'Austria',
        'Roberto Bono',
        'http://wide-vein.org',
        263.587,
        '07:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Ancilla.Taormina37@email.it',
        '+396633458826'
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        10,
        61::numeric(12,2),
        'Fiderepasshütte',
        'Germany',
        'Diletta Silvestrini',
        'http://milky-temper.org',
        290.689,
        '04:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Giove49@libero.it',
        '+395630847494'
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        4,
        119::numeric(12,2),
        'Göppinger Hütte',
        'Austria',
        'Sig. Sirio Sannino',
        'https://mealy-everybody.net',
        266.788,
        '09:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Giovanni_Tretola37@yahoo.com',
        '+398504280523'
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        4,
        72::numeric(12,2),
        'Oberzalimhütte',
        'Austria',
        'Gianmaria Tumbarello',
        'http://blissful-table.net',
        298.083,
        '03:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Liboria_Martini18@gmail.com',
        '+394212170678'
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        1,
        88::numeric(12,2),
        'Rastkogelhütte',
        'Austria',
        'Prospera Pedrotti',
        'http://reckless-transport.com',
        290.388,
        '02:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Giulia.Caricari81@yahoo.it',
        '+392013228919'
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        10,
        120::numeric(12,2),
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Ulfa Signorini',
        'http://primary-spending.org',
        308.9,
        '01:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Virginia.DiMarzio@email.it',
        '+392264485130'
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        1,
        97::numeric(12,2),
        'Kaltenberghütte',
        'Austria',
        'Duilio Mancinelli',
        'https://realistic-endothelium.net',
        274.634,
        '07:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Ugo_Ragusa@yahoo.it',
        '+399591973762'
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        3,
        60::numeric(12,2),
        'Schweinfurter Hütte',
        'Austria',
        'Filiberto Branca',
        'http://worried-fun.net',
        271.972,
        '07:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Emma44@gmail.com',
        '+398163383161'
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        5,
        58::numeric(12,2),
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Clemenzia Fichera',
        'https://innocent-coke.org',
        265.086,
        '02:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Leo57@libero.it',
        '+391684411150'
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        8,
        57::numeric(12,2),
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Ginevra Mirabella',
        'https://heavy-deliberation.it',
        333.572,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Serapione.Spanu@email.it',
        '+398241579208'
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        5,
        127::numeric(12,2),
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Fedro Di Marzio',
        'https://dirty-underpants.org',
        271.668,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Pusicio62@yahoo.com',
        '+396605144178'
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        4,
        119::numeric(12,2),
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Donna Piga',
        'https://irritating-anagram.it',
        305.66,
        '05:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Onorino.Tomasi15@gmail.com',
        '+391995147550'
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        9,
        147::numeric(12,2),
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Arminio Errichiello',
        'http://rigid-shallows.org',
        312.433,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Onorino_DAmore@yahoo.com',
        '+399292227219'
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        3,
        135::numeric(12,2),
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Orfeo Quarta',
        'http://close-carnation.net',
        275.143,
        '09:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Giuditta91@email.it',
        '+396146497989'
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        6,
        81::numeric(12,2),
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Maffeo Mollica',
        'http://fumbling-charlatan.it',
        261.075,
        '02:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Urdino_Ferrarini97@gmail.com',
        '+392692105617'
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        3,
        117::numeric(12,2),
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Fabrizio Ammoscato',
        'http://distorted-interviewer.org',
        280.089,
        '06:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Cassiopea.Capogna@email.it',
        '+392636537968'
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        1,
        132::numeric(12,2),
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Marianna Zullo',
        'http://fast-coyote.net',
        333.584,
        '03:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Proserpina.Biagi@yahoo.com',
        '+398089852257'
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        5,
        50::numeric(12,2),
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Alina Mastroianni',
        'http://sympathetic-influx.it',
        310.144,
        '08:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Liberto_Semeraro@gmail.com',
        '+391986855093'
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        1,
        102::numeric(12,2),
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Saba Biggi',
        'http://sentimental-patrol.net',
        280.133,
        '06:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Arialdo.Cavalli@yahoo.it',
        '+392355071961'
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        3,
        146::numeric(12,2),
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Giuliana Trombetta',
        'https://competent-capitalism.net',
        336.568,
        '04:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Giancarlo.Schiavon@yahoo.it',
        '+397531683582'
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        1,
        72::numeric(12,2),
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Baldomero Raffa',
        'https://educated-headphones.com',
        313.875,
        '04:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Brancaleone89@hotmail.com',
        '+399604332475'
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        8,
        50::numeric(12,2),
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Rebecca Evangelisti',
        'http://impossible-subset.com',
        311.637,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Gavino.Govoni@gmail.com',
        '+398012149681'
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        1,
        72::numeric(12,2),
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Veriana Lori',
        'https://majestic-flax.net',
        320.007,
        '06:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Floriana.Cozzani@hotmail.com',
        '+393265396450'
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        2,
        135::numeric(12,2),
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Adelasia Ratti',
        'https://stylish-refund.org',
        277.745,
        '08:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Procopio77@email.it',
        '+397562730272'
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        4,
        67::numeric(12,2),
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Eva Giacomelli',
        'https://wry-section.com',
        286.979,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Muziano62@yahoo.com',
        '+393572062501'
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        5,
        39::numeric(12,2),
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Consolata Tiberti',
        'http://uniform-stool.net',
        301.162,
        '05:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Gedeone.Toti21@yahoo.it',
        '+390080593341'
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        2,
        64::numeric(12,2),
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Filiberto Sanna',
        'https://superior-co-producer.it',
        275.609,
        '04:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Illidio59@yahoo.com',
        '+399165020674'
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        1,
        61::numeric(12,2),
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Bartolomea Grosso',
        'https://tangible-comb.it',
        307.474,
        '09:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Manetto_Epifani74@gmail.com',
        '+394427865762'
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        2,
        84::numeric(12,2),
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Onesta Spataro',
        'https://formal-weedkiller.org',
        288.449,
        '07:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Aurelia80@gmail.com',
        '+391467761945'
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        5,
        73::numeric(12,2),
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Giorgio Carella',
        'https://dark-heater.org',
        281.72,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Aristo.Vailati8@email.it',
        '+391625690746'
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        10,
        150::numeric(12,2),
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Pammachio Pedrotti',
        'http://failing-beheading.it',
        320.986,
        '08:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Teodora74@yahoo.it',
        '+396432103553'
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        9,
        143::numeric(12,2),
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Matroniano Paolini',
        'https://sunny-flair.org',
        318.441,
        '06:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Lorella_Puglisi89@gmail.com',
        '+393656329638'
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        6,
        137::numeric(12,2),
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Raffaella Tretola',
        'https://homely-framework.it',
        278.455,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Ortensia_Tallone@email.it',
        '+390843404872'
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        3,
        40::numeric(12,2),
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Prisca Pandolfi',
        'http://elated-igloo.it',
        322.588,
        '03:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Betta_Tarantino@libero.it',
        '+391172299056'
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        9,
        69::numeric(12,2),
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Ermenegilda Labate',
        'https://thin-herbs.it',
        265.675,
        '09:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Tulliano99@libero.it',
        '+394103515608'
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        8,
        65::numeric(12,2),
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Estella Chianese',
        'http://unlawful-grouper.org',
        309.896,
        '02:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Leonardo.Gandolfo@hotmail.com',
        '+395540393143'
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        7,
        147::numeric(12,2),
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Oliviera Macchia',
        'https://silly-deodorant.org',
        309.654,
        '02:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Ciriaco_DeCarlo6@yahoo.com',
        '+393653196320'
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        8,
        119::numeric(12,2),
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Addo Campana',
        'http://tired-state.com',
        339.32,
        '02:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Uguccione.Caccamo34@libero.it',
        '+397194718086'
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        8,
        121::numeric(12,2),
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Leopoldo Santamaria',
        'http://intelligent-circumference.com',
        313.738,
        '07:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Galileo_Scala39@libero.it',
        '+395270227991'
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        5,
        81::numeric(12,2),
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Ermenegilda Brignone',
        'https://unfortunate-news.org',
        290.228,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Renata_DiGrezia6@yahoo.it',
        '+396279537715'
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        9,
        102::numeric(12,2),
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Antioco Iacovone',
        'https://low-embellishment.org',
        312.744,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Concetto_Morra@yahoo.com',
        '+394625684775'
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        4,
        124::numeric(12,2),
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Debora Capelli',
        'http://growling-permit.org',
        339.302,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Godiva_Marcucci@yahoo.it',
        '+399288402376'
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        2,
        52::numeric(12,2),
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Maiorico D''Andrea',
        'http://pink-liquidity.com',
        271.711,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Gillo92@email.it',
        '+393071449120'
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        5,
        113::numeric(12,2),
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Aurelia Martines',
        'http://happy-go-lucky-kebab.it',
        293.192,
        '02:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Beato_Piccione33@yahoo.it',
        '+397616431869'
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        3,
        112::numeric(12,2),
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Giuda Pastore',
        'http://dark-banana.net',
        319.943,
        '04:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Quinziano81@gmail.com',
        '+394745638222'
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        2,
        39::numeric(12,2),
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Uriele Pinna',
        'https://enormous-medal.org',
        302.863,
        '02:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Stiriaco_Tretola@yahoo.com',
        '+390148731667'
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        10,
        49::numeric(12,2),
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Emiliana Doria',
        'https://sore-anklet.net',
        312.749,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Edelberga79@yahoo.it',
        '+396050595737'
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        8,
        96::numeric(12,2),
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Dr. Zefiro Giusti',
        'https://enlightened-reorganisation.com',
        281.597,
        '02:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Eliodoro45@gmail.com',
        '+393903491122'
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        7,
        67::numeric(12,2),
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Melania Santilli',
        'http://pointless-yahoo.net',
        324.898,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Climaco67@yahoo.it',
        '+391319145233'
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        4,
        123::numeric(12,2),
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Clarenzio Carlucci',
        'http://forked-finance.it',
        298.982,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Pierluigi87@hotmail.com',
        '+395106314648'
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        1,
        89::numeric(12,2),
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Tito Parodi',
        'http://poor-lantern.com',
        323.027,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Gino.Capponi@yahoo.com',
        '+391495061728'
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        10,
        46::numeric(12,2),
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Costanzo Golinelli',
        'http://quizzical-flame.net',
        285.129,
        '03:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Dione.Foti@gmail.com',
        '+391033084127'
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        2,
        41::numeric(12,2),
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Capitolina Barbera',
        'https://wide-eyed-foodstuffs.it',
        303.756,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Eufemio94@yahoo.it',
        '+391715696756'
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        6,
        136::numeric(12,2),
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Piera Liotta',
        'http://mushy-adverb.com',
        294.548,
        '01:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Moreno.Campanile@email.it',
        '+398849357330'
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        9,
        144::numeric(12,2),
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Bonagiunta Lippi',
        'http://rude-jail.it',
        328.79,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Bonagiunta_Fabbri@libero.it',
        '+398019533061'
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        4,
        127::numeric(12,2),
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Sig. Vanna Chianese',
        'https://gross-ammunition.net',
        318.083,
        '04:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Deodato.Tedeschi@hotmail.com',
        '+394835319803'
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        2,
        73::numeric(12,2),
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Neiva Cottone',
        'http://giving-dimple.org',
        289.81,
        '04:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Gianuario_Medugno@gmail.com',
        '+396577596280'
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        7,
        147::numeric(12,2),
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Marianna Cottone',
        'http://criminal-wolf.net',
        311.379,
        '07:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Zabina.Rotundo29@hotmail.com',
        '+399708035701'
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        9,
        50::numeric(12,2),
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Dina Pizzuti',
        'https://distorted-lunchroom.net',
        301.85,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Domiziano.Stella@gmail.com',
        '+393060061226'
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        5,
        40::numeric(12,2),
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Tulliano Acquadro',
        'http://dismal-opponent.com',
        275.348,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Crescenzio_DAmato@hotmail.com',
        '+391325141852'
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        4,
        60::numeric(12,2),
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Ermenegildo Puggioni',
        'https://insecure-resale.org',
        281.151,
        '05:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Antea_DiDomenico59@yahoo.com',
        '+391721281431'
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        7,
        51::numeric(12,2),
        'Wittener Hütte',
        'Germany',
        'Arrigo Cabras',
        'http://insidious-gadget.org',
        325.798,
        '08:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Euseo_Finotti1@libero.it',
        '+390223127122'
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        8,
        73::numeric(12,2),
        'Hochjoch-Hospiz',
        'Austria',
        'Sebastiana Lamacchia',
        'https://orange-millstone.org',
        331.393,
        '01:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Lea_Carboni@email.it',
        '+395657738182'
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        10,
        70::numeric(12,2),
        'Meilerhütte',
        'Germany',
        'Bassilla Pellicanò',
        'https://dry-burden.com',
        265.209,
        '06:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Gherardo50@gmail.com',
        '+397351834796'
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        5,
        140::numeric(12,2),
        'Gaudeamushütte',
        'Austria',
        'Adelardo Senatore',
        'http://marvelous-isogloss.com',
        263.365,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Giada.Caiazzo97@gmail.com',
        '+397051973686'
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        2,
        121::numeric(12,2),
        'Rheydter Hütte',
        'Germany',
        'Greta Calafiore',
        'https://itchy-chamber.it',
        315.549,
        '01:00:00'::time without time zone,
        '08:00:00'::time without time zone,
        'Loris10@hotmail.com',
        '+399299919538'
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        4,
        79::numeric(12,2),
        'Sektionshütte Krippen',
        'Germany',
        'Gomberto Canu',
        'http://neglected-stick.org',
        266.906,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Miranda_Narcisi@libero.it',
        '+399446307365'
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        1,
        84::numeric(12,2),
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Carla Santoni',
        'http://ignorant-filing.org',
        271.934,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Genesia_Venturi31@hotmail.com',
        '+399618498662'
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        9,
        104::numeric(12,2),
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Incoronata Bellucci',
        'http://wonderful-secretariat.net',
        300.295,
        '04:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Divo69@libero.it',
        '+393678875525'
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        6,
        72::numeric(12,2),
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Virone Pavan',
        'http://drab-ironclad.com',
        288.763,
        '05:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Iorio_Govoni82@hotmail.com',
        '+390008309902'
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        7,
        136::numeric(12,2),
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Averardo Di Lascio',
        'https://far-off-straw.net',
        319.26,
        '08:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Diocleziano_Celentano21@libero.it',
        '+392712623194'
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        2,
        114::numeric(12,2),
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Tiberio Vinci',
        'https://trivial-polyester.org',
        332.715,
        '08:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Biagio.Caputo29@yahoo.it',
        '+390617427602'
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        10,
        81::numeric(12,2),
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Abbondanza Gamba',
        'https://colorless-outside.org',
        263.69,
        '02:00:00'::time without time zone,
        '09:00:00'::time without time zone,
        'Romualdo78@gmail.com',
        '+390743774980'
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        4,
        46::numeric(12,2),
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Ing. Sante Vitali',
        'http://muffled-chaise.org',
        326.808,
        '06:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Onesta52@gmail.com',
        '+396211662052'
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        8,
        128::numeric(12,2),
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Ing. Ermanno Manzi',
        'http://pleased-mother.net',
        333.783,
        '08:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Bianca_Pece@yahoo.it',
        '+398439387853'
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        3,
        104::numeric(12,2),
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Medardo Mancino',
        'https://entire-dressing.net',
        307.07,
        '02:00:00'::time without time zone,
        '08:00:00'::time without time zone,
        'Luigi.Crispino@email.it',
        '+391423764579'
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        4,
        114::numeric(12,2),
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Adalardo Cecere',
        'http://granular-peek.net',
        334.259,
        '05:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Querano14@libero.it',
        '+399395211894'
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        1,
        97::numeric(12,2),
        'Dobra voda',
        'Suvobor, Serbia',
        'Torquato Tassinari',
        'https://nonstop-carpeting.it',
        293.531,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Quartilla.Giudice84@email.it',
        '+394871425999'
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        1,
        71::numeric(12,2),
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Romilda Giampaolo',
        'http://grand-diet.org',
        337.167,
        '06:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Apuleio79@gmail.com',
        '+396371271189'
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        9,
        66::numeric(12,2),
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Dr. Teudosia Gigliotti',
        'http://juvenile-pate.net',
        295.796,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Accursio.Improta@hotmail.com',
        '+390414517304'
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        2,
        148::numeric(12,2),
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Cassiano Cardia',
        'https://annual-journalist.com',
        267.792,
        '01:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Marino.Pandolfi34@libero.it',
        '+398513210527'
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        5,
        42::numeric(12,2),
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Baldo Crisci',
        'https://gracious-visitor.net',
        336.772,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Enecone55@yahoo.com',
        '+399390345867'
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        9,
        45::numeric(12,2),
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Geronzio Nobili',
        'https://snappy-catcher.com',
        295.645,
        '01:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Mia_Corrao70@libero.it',
        '+396011801984'
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        1,
        38::numeric(12,2),
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Accursio Simonetti',
        'http://lost-museum.net',
        286.266,
        '03:00:00'::time without time zone,
        '09:00:00'::time without time zone,
        'Zabina_Balducci4@hotmail.com',
        '+393346735442'
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        7,
        97::numeric(12,2),
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Aida Palmisano',
        'http://shy-pianist.net',
        285.872,
        '06:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Leonilda_Saladino@libero.it',
        '+392370793385'
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        2,
        115::numeric(12,2),
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Devota Solinas',
        'http://opulent-expansion.org',
        302.139,
        '02:00:00'::time without time zone,
        '09:00:00'::time without time zone,
        'Porziano.Iazzetta@yahoo.com',
        '+392150978092'
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        1,
        56::numeric(12,2),
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Ulpiano Salerno',
        'https://dreary-fries.it',
        334.579,
        '09:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Minerva_Ferraiuolo35@yahoo.it',
        '+399096802712'
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        7,
        132::numeric(12,2),
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Dr. Pierangelo De Blasi',
        'http://medical-subexpression.com',
        325.081,
        '07:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Ilva26@email.it',
        '+394407640872'
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '333 Contrada Lino, Vito a mare, Italy',
        'Vito a mare',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        162,
        '4 Rotonda Ildefonso, Cascone a mare, Italy',
        'Cascone a mare',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        136,
        '8 Via Zunino, Celi veneto, Italy',
        'Celi veneto',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        30,
        '1 Strada Adina, Quarto Tazio a mare, Italy',
        'Quarto Tazio a mare',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        185,
        '657 Strada Cipriano, Sesto Palmira del friuli, Italy',
        'Sesto Palmira del friuli',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        228,
        '6 Contrada Martino, San Giadero, Italy',
        'San Giadero',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        54,
        '19 Incrocio Favara, Gennaro del friuli, Italy',
        'Gennaro del friuli',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        140,
        '4 Piazza Coreno, San Porfirio, Italy',
        'San Porfirio',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        75,
        '491 Incrocio Mastroianni, Cesare terme, Italy',
        'Cesare terme',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        162,
        '84 Incrocio Loddo, Borgo Narciso, Italy',
        'Borgo Narciso',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        28,
        '1 Borgo D''Amore, Settimo Ulisse, Italy',
        'Settimo Ulisse',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        166,
        '2 Incrocio Palazzi, Quarto Bartolomeo, Italy',
        'Quarto Bartolomeo',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        265,
        '31 Via Iezzi, Filomeno laziale, Italy',
        'Filomeno laziale',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        80,
        '038 Via Domezio, Dante terme, Italy',
        'Dante terme',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        80,
        '2 Piazza Califano, Daria a mare, Italy',
        'Daria a mare',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        29,
        '63 Borgo Rosselli, Marolo ligure, Italy',
        'Marolo ligure',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        170,
        '462 Borgo Dino, Sesto Alessia del friuli, Italy',
        'Sesto Alessia del friuli',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        35,
        '29 Contrada Pacini, San Pancario, Italy',
        'San Pancario',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        208,
        '928 Strada Nocera, Micillo umbro, Italy',
        'Micillo umbro',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        177,
        '98 Strada Prudenzia, Agenore del friuli, Italy',
        'Agenore del friuli',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        148,
        '3 Piazza Luca, Quarto Ataleo, Italy',
        'Quarto Ataleo',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        39,
        '46 Strada Calabrò, Quarto Bino nell''emilia, Italy',
        'Quarto Bino nell''emilia',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '63 Piazza Paola, Borgo Ercole a mare, Italy',
        'Borgo Ercole a mare',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        55,
        '93 Borgo Silenzi, Califano salentino, Italy',
        'Califano salentino',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        149,
        '8 Borgo Pammachio, Remo a mare, Italy',
        'Remo a mare',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        58,
        '82 Via Galatea, San Oronzo del friuli, Italy',
        'San Oronzo del friuli',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        252,
        '5 Borgo Iginia, Eugenio laziale, Italy',
        'Eugenio laziale',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        127,
        '76 Rotonda Sorbello, Giraudo del friuli, Italy',
        'Giraudo del friuli',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        122,
        '98 Rotonda Elettra, San Benigno a mare, Italy',
        'San Benigno a mare',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        212,
        '620 Borgo Pivetta, Tedeschi umbro, Italy',
        'Tedeschi umbro',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        111,
        '399 Strada Elio, Quarto Sostene terme, Italy',
        'Quarto Sostene terme',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        186,
        '97 Piazza Ischirione, Festuccia ligure, Italy',
        'Festuccia ligure',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        215,
        '949 Piazza Beltramo, Barsotti del friuli, Italy',
        'Barsotti del friuli',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '208 Via Acquaviva, Pascali a mare, Italy',
        'Pascali a mare',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        30,
        '9 Incrocio Rossana, Borgo Anita, Italy',
        'Borgo Anita',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        192,
        '49 Contrada Bruzzone, Evodio salentino, Italy',
        'Evodio salentino',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        107,
        '2 Via Di Fiore, Marini terme, Italy',
        'Marini terme',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        88,
        '5 Borgo Gianluca, Feliciano terme, Italy',
        'Feliciano terme',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        279,
        '707 Rotonda Cicchetti, Margiotta a mare, Italy',
        'Margiotta a mare',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        236,
        '786 Borgo Zago, Ariberto salentino, Italy',
        'Ariberto salentino',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '70 Borgo Mancuso, Anatolia nell''emilia, Italy',
        'Anatolia nell''emilia',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        250,
        '33 Incrocio Sara, Placida del friuli, Italy',
        'Placida del friuli',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        94,
        '5 Via Morreale, Borgo Orio a mare, Italy',
        'Borgo Orio a mare',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        204,
        '88 Strada Livino, Sesto Leonardo del friuli, Italy',
        'Sesto Leonardo del friuli',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        78,
        '1 Borgo Cozzi, Fiorenza salentino, Italy',
        'Fiorenza salentino',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        106,
        '40 Strada D''Onofrio, Sesto Clemente, Italy',
        'Sesto Clemente',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        295,
        '3 Contrada Malco, Euseo veneto, Italy',
        'Euseo veneto',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        77,
        '644 Rotonda Antigone, Leoni calabro, Italy',
        'Leoni calabro',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        110,
        '391 Strada Tamara, Settimo Diocleziano, Italy',
        'Settimo Diocleziano',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        283,
        '3 Rotonda Remo, Palombo calabro, Italy',
        'Palombo calabro',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        223,
        '2 Rotonda Castaldo, Pisani del friuli, Italy',
        'Pisani del friuli',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '79 Borgo Celeste, Settimo Adria calabro, Italy',
        'Settimo Adria calabro',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        115,
        '51 Contrada Pinto, Quarto Ave ligure, Italy',
        'Quarto Ave ligure',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '9 Rotonda Franzoni, Paone terme, Italy',
        'Paone terme',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        168,
        '0 Borgo Pomponio, Napolitano laziale, Italy',
        'Napolitano laziale',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        173,
        '568 Via Ada, San Aurelio salentino, Italy',
        'San Aurelio salentino',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        291,
        '0 Piazza Scalia, Quarto Cataldo, Italy',
        'Quarto Cataldo',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        226,
        '4 Incrocio Callegari, Ciacio a mare, Italy',
        'Ciacio a mare',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        105,
        '508 Via Gabriella, Settimo Tarso terme, Italy',
        'Settimo Tarso terme',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        157,
        '451 Strada Porzia, Bulgarelli laziale, Italy',
        'Bulgarelli laziale',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        136,
        '298 Contrada Colonna, Ermini terme, Italy',
        'Ermini terme',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        131,
        '644 Borgo Saverio, Crispino a mare, Italy',
        'Crispino a mare',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        25,
        '71 Rotonda Cremona, Nanni a mare, Italy',
        'Nanni a mare',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        244,
        '3 Via Samuele, Settimo Alamanno, Italy',
        'Settimo Alamanno',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        105,
        '51 Strada Chiaravalle, San Pasquale, Italy',
        'San Pasquale',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        186,
        '12 Rotonda Ferracuti, Sartor ligure, Italy',
        'Sartor ligure',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        267,
        '80 Piazza Melandri, Mauro veneto, Italy',
        'Mauro veneto',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        192,
        '526 Contrada Prato, Clemente calabro, Italy',
        'Clemente calabro',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        200,
        '13 Incrocio Sabatini, Marcelli nell''emilia, Italy',
        'Marcelli nell''emilia',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '1 Piazza Abelardo, San Mauro calabro, Italy',
        'San Mauro calabro',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        247,
        '41 Piazza Romani, Borgo Simone, Italy',
        'Borgo Simone',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        118,
        '998 Rotonda Amelio, Sesto Eliseo, Italy',
        'Sesto Eliseo',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        158,
        '732 Via Scherini, Ilva ligure, Italy',
        'Ilva ligure',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        114,
        '0 Rotonda Turibio, Quarto Mirta laziale, Italy',
        'Quarto Mirta laziale',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        176,
        '589 Incrocio Valeriana, Sesto Eliana salentino, Italy',
        'Sesto Eliana salentino',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        90,
        '9 Rotonda Ambrogio, Bruzzone laziale, Italy',
        'Bruzzone laziale',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        166,
        '2 Incrocio Clorinda, Chilà veneto, Italy',
        'Chilà veneto',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        53,
        '8 Via Deodato, Settimo Elvira umbro, Italy',
        'Settimo Elvira umbro',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        250,
        '676 Incrocio Pardini, Denaro laziale, Italy',
        'Denaro laziale',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        93,
        '08 Via Sergi, Barbero sardo, Italy',
        'Barbero sardo',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        216,
        '5 Contrada Belli, Borgo Nicea sardo, Italy',
        'Borgo Nicea sardo',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        275,
        '40 Rotonda Diodoro, Quarto Spartaco calabro, Italy',
        'Quarto Spartaco calabro',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        67,
        '514 Contrada Cusumano, Quarto Sesto nell''emilia, Italy',
        'Quarto Sesto nell''emilia',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        133,
        '870 Incrocio Nicastro, San Cristaldo, Italy',
        'San Cristaldo',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        234,
        '5 Rotonda Barile, Oliva del friuli, Italy',
        'Oliva del friuli',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        228,
        '92 Rotonda Nunziata, San Danio umbro, Italy',
        'San Danio umbro',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        294,
        '341 Contrada Gianmaria, Borgo Reginaldo umbro, Italy',
        'Borgo Reginaldo umbro',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        119,
        '2 Piazza Aciscolo, Marchesi sardo, Italy',
        'Marchesi sardo',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        113,
        '6 Strada Iuliano, Norma umbro, Italy',
        'Norma umbro',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        157,
        '4 Via Noemi, Sesto Narciso, Italy',
        'Sesto Narciso',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        144,
        '44 Strada D''Elia, Polverino lido, Italy',
        'Polverino lido',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        193,
        '695 Borgo Tarantino, San Belina, Italy',
        'San Belina',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        261,
        '863 Incrocio Manzo, Settimo Costanzo, Italy',
        'Settimo Costanzo',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        46,
        '57 Via Everardo, Settimo Sico calabro, Italy',
        'Settimo Sico calabro',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        276,
        '319 Piazza Pani, Costantini lido, Italy',
        'Costantini lido',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        179,
        '5 Strada Oliva, Settimo Cassio veneto, Italy',
        'Settimo Cassio veneto',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        88,
        '55 Strada Menodora, Decimo nell''emilia, Italy',
        'Decimo nell''emilia',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        233,
        '09 Strada Eliseo, Padula del friuli, Italy',
        'Padula del friuli',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        239,
        '4 Via Elogio, Sesto Amadeo, Italy',
        'Sesto Amadeo',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        63,
        '4 Contrada Tiberti, San Ermes a mare, Italy',
        'San Ermes a mare',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        298,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        250,
        '96 Borgo Domiziano, Quarto Archippo umbro, Italy',
        'Quarto Archippo umbro',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        159,
        '1 Incrocio Graziani, Patrone salentino, Italy',
        'Patrone salentino',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        138,
        '4 Borgo Donato, Sesto Vodingo a mare, Italy',
        'Sesto Vodingo a mare',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        237,
        '58 Contrada Milena, Quarto Gioia lido, Italy',
        'Quarto Gioia lido',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        282,
        '5 Borgo Sinesio, San Antonella, Italy',
        'San Antonella',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        36,
        '5 Strada Dolores, Paganelli a mare, Italy',
        'Paganelli a mare',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        165,
        '6 Via Bertolussi, Sesto Onorata laziale, Italy',
        'Sesto Onorata laziale',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        267,
        '50 Strada Alda, Quarto Sibilla, Italy',
        'Quarto Sibilla',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        93,
        '073 Via Guerra, De Maio lido, Italy',
        'De Maio lido',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        297,
        '1 Incrocio Marcella, Borgo Livino calabro, Italy',
        'Borgo Livino calabro',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        223,
        '6 Contrada Elisabetta, Settimo Dalmazio, Italy',
        'Settimo Dalmazio',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        62,
        '9 Piazza Ornella, Quarto Ilia lido, Italy',
        'Quarto Ilia lido',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        138,
        '281 Borgo Rocco, Borgo Fabiola, Italy',
        'Borgo Fabiola',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        74,
        '6 Incrocio Peleo, Simeti a mare, Italy',
        'Simeti a mare',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        182,
        '9 Via Calcedonio, San Ermanno, Italy',
        'San Ermanno',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        276,
        '344 Rotonda Calpurnia, Gregorio del friuli, Italy',
        'Gregorio del friuli',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        101,
        '91 Piazza De Carolis, Borgo Genesia, Italy',
        'Borgo Genesia',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        224,
        '8 Incrocio Barbarulo, Sesto Vanda calabro, Italy',
        'Sesto Vanda calabro',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        103,
        '0 Strada Gabriele, Borgo Melania ligure, Italy',
        'Borgo Melania ligure',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        226,
        '9 Contrada Manfredi, Borgo Devota, Italy',
        'Borgo Devota',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        72,
        '1 Borgo Bacci, Ciro a mare, Italy',
        'Ciro a mare',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        215,
        '499 Borgo Vitale, Settimo Beronico ligure, Italy',
        'Settimo Beronico ligure',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        74,
        '30 Strada Di Marzio, Quarto Vittorio umbro, Italy',
        'Quarto Vittorio umbro',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        200,
        '5 Strada Deanna, Sesto Tiziano, Italy',
        'Sesto Tiziano',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        55,
        '944 Contrada Gerasimo, Melis veneto, Italy',
        'Melis veneto',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '8 Contrada Caronte, Vidiano terme, Italy',
        'Vidiano terme',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        143,
        '5 Piazza Tirri, Quarto Genoveffa nell''emilia, Italy',
        'Quarto Genoveffa nell''emilia',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        258,
        '67 Piazza Fiori, Settimo Ilda salentino, Italy',
        'Settimo Ilda salentino',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '94 Incrocio Zenobia, Quarto Clarenzio nell''emilia, Italy',
        'Quarto Clarenzio nell''emilia',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '871 Borgo Vissia, Cappai calabro, Italy',
        'Cappai calabro',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        292,
        '81 Piazza Virginio, Giovanna nell''emilia, Italy',
        'Giovanna nell''emilia',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        228,
        '3 Contrada Cozzolino, Torchia ligure, Italy',
        'Torchia ligure',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        206,
        '462 Borgo Zappalà, Carrus nell''emilia, Italy',
        'Carrus nell''emilia',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        209,
        '35 Incrocio Narseo, Pellegrino sardo, Italy',
        'Pellegrino sardo',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        257,
        '751 Via Clelia, Rapuano calabro, Italy',
        'Rapuano calabro',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '953 Piazza De Col, Baldassarre laziale, Italy',
        'Baldassarre laziale',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '4 Piazza Raffaella, Beato laziale, Italy',
        'Beato laziale',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        180,
        '1 Strada Cora, San Marisa, Italy',
        'San Marisa',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '9 Contrada Casale, Eliano ligure, Italy',
        'Eliano ligure',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        155,
        '12 Piazza Marrazzo, Sesto Lancilotto, Italy',
        'Sesto Lancilotto',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        186,
        '4 Via Elvezio, Settimo Gaglioffo laziale, Italy',
        'Settimo Gaglioffo laziale',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        251,
        '7 Borgo Simeoni, Settimo Tito lido, Italy',
        'Settimo Tito lido',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        58,
        '041 Strada Scarano, Apollinare veneto, Italy',
        'Apollinare veneto',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        276,
        '103 Piazza Santoni, Quarto Serafino, Italy',
        'Quarto Serafino',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        40,
        '171 Contrada Palano, Quarto Furio sardo, Italy',
        'Quarto Furio sardo',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        187,
        '1 Rotonda Silvana, Sesto Feliciano laziale, Italy',
        'Sesto Feliciano laziale',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        171,
        '8 Strada Dorotea, Gundelinda ligure, Italy',
        'Gundelinda ligure',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        157,
        '589 Strada Iago, Sesto Trasea, Italy',
        'Sesto Trasea',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        75,
        '3 Incrocio Di Marino, Venanzio a mare, Italy',
        'Venanzio a mare',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        167,
        '91 Piazza Ferdinando, Pariggiano calabro, Italy',
        'Pariggiano calabro',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        212,
        '115 Incrocio Cherubini, Borgo Giusto calabro, Italy',
        'Borgo Giusto calabro',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        145,
        '9 Strada Amore, Ambrosino del friuli, Italy',
        'Ambrosino del friuli',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        149,
        '7 Contrada Piscitelli, Turi nell''emilia, Italy',
        'Turi nell''emilia',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        194,
        '029 Piazza Alcide, Teodoto laziale, Italy',
        'Teodoto laziale',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        217,
        '30 Rotonda Bellini, Anselmo lido, Italy',
        'Anselmo lido',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        140,
        '09 Via Cattaneo, Benini terme, Italy',
        'Benini terme',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        279,
        '9 Strada Grimaldi, Lo Giudice salentino, Italy',
        'Lo Giudice salentino',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        298,
        '7 Rotonda Lo Piccolo, Lia del friuli, Italy',
        'Lia del friuli',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        160,
        '8 Via Almerigo, Sesto Floriana calabro, Italy',
        'Sesto Floriana calabro',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        83,
        '89 Strada Orietta, Borgo Carmela, Italy',
        'Borgo Carmela',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        182,
        '60 Piazza Agata, San Orsola, Italy',
        'San Orsola',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        291,
        '3 Via Guastone, Giannelli a mare, Italy',
        'Giannelli a mare',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        167,
        '055 Rotonda Valeri, Ilda umbro, Italy',
        'Ilda umbro',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        276,
        '6 Incrocio Fancello, Casadio veneto, Italy',
        'Casadio veneto',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '772 Rotonda Lattanzi, Romolo del friuli, Italy',
        'Romolo del friuli',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        64,
        '333 Borgo Fiorenziano, Evandro terme, Italy',
        'Evandro terme',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        282,
        '14 Incrocio Savoia, Quarto Dario laziale, Italy',
        'Quarto Dario laziale',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        124,
        '5 Strada Lo Pinto, Settimo Zoe, Italy',
        'Settimo Zoe',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        168,
        '117 Piazza Tomaselli, Siracusa del friuli, Italy',
        'Siracusa del friuli',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        36,
        '8 Strada Pio, Quarto Celinia sardo, Italy',
        'Quarto Celinia sardo',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        166,
        '6 Rotonda Giachi, Pianese veneto, Italy',
        'Pianese veneto',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        84,
        '4 Strada Bonaventura, Santoni del friuli, Italy',
        'Santoni del friuli',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        178,
        '255 Borgo Aleramo, Quarto Ireneo salentino, Italy',
        'Quarto Ireneo salentino',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        235,
        '3 Borgo Barbagallo, Settimo Palmira a mare, Italy',
        'Settimo Palmira a mare',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        92,
        '045 Via Elimena, Settimo Fiorenza salentino, Italy',
        'Settimo Fiorenza salentino',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        54,
        '02 Contrada Clelia, Settimo Adele, Italy',
        'Settimo Adele',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        236,
        '17 Rotonda Ermes, Zefiro del friuli, Italy',
        'Zefiro del friuli',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        226,
        '6 Incrocio Matroniano, San Erardo laziale, Italy',
        'San Erardo laziale',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        52,
        '265 Incrocio Iannucci, San Giliola sardo, Italy',
        'San Giliola sardo',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        235,
        '2 Piazza Savini, San Vissia umbro, Italy',
        'San Vissia umbro',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        255,
        '9 Contrada Chiara, Quarto Abbondanzio, Italy',
        'Quarto Abbondanzio',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '983 Rotonda Secondina, Ilaria del friuli, Italy',
        'Ilaria del friuli',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        42,
        '42 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        214,
        '772 Contrada Ludovica, Prisca sardo, Italy',
        'Prisca sardo',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        182,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        289,
        '32 Rotonda Venera, Mina umbro, Italy',
        'Mina umbro',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        88,
        '967 Contrada Baldassarre, Tolomeo del friuli, Italy',
        'Tolomeo del friuli',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        273,
        '66 Strada Sabbatini, Silvestrini ligure, Italy',
        'Silvestrini ligure',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        278,
        '49 Incrocio Federico, Sesto Berenice sardo, Italy',
        'Sesto Berenice sardo',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        124,
        '16 Borgo Stanzione, Borgo Ovidio salentino, Italy',
        'Borgo Ovidio salentino',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        268,
        '2 Via Recchia, Laurentino calabro, Italy',
        'Laurentino calabro',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        61,
        '682 Incrocio Cleopatra, Irma ligure, Italy',
        'Irma ligure',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        151,
        '97 Piazza Aidano, Borgo Adeodato, Italy',
        'Borgo Adeodato',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        187,
        '485 Rotonda Grasso, Pagliai laziale, Italy',
        'Pagliai laziale',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        265,
        '15 Strada Tina, Settimo Minervino umbro, Italy',
        'Settimo Minervino umbro',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        241,
        '119 Borgo Bruschi, Anacleto del friuli, Italy',
        'Anacleto del friuli',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        106,
        '1 Incrocio Egisto, Quasimodo ligure, Italy',
        'Quasimodo ligure',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        280,
        '3 Piazza Carmelo, Borgo Agostina calabro, Italy',
        'Borgo Agostina calabro',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        232,
        '3 Rotonda Guastone, Luciano umbro, Italy',
        'Luciano umbro',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        162,
        '12 Contrada Liotta, Sesto Ione, Italy',
        'Sesto Ione',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        124,
        '38 Contrada D''Argenio, Bonaldo calabro, Italy',
        'Bonaldo calabro',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '01 Strada Celentano, Innocente ligure, Italy',
        'Innocente ligure',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        70,
        '73 Via Ventura, Borgo Enimia, Italy',
        'Borgo Enimia',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        283,
        '739 Borgo La Manna, Modica terme, Italy',
        'Modica terme',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        170,
        '883 Via Lucarini, Notaro ligure, Italy',
        'Notaro ligure',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        192,
        '94 Piazza Sara, Daniela nell''emilia, Italy',
        'Daniela nell''emilia',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        137,
        '889 Via Gustavo, Antezza umbro, Italy',
        'Antezza umbro',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        173,
        '568 Strada Bedini, Borgo Gianmaria lido, Italy',
        'Borgo Gianmaria lido',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        103,
        '41 Via Gonzaga, San Eraclide, Italy',
        'San Eraclide',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        63,
        '5 Via Fortunato, Ridolfi salentino, Italy',
        'Ridolfi salentino',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        75,
        '09 Borgo Urbano, Giuliano salentino, Italy',
        'Giuliano salentino',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '0 Piazza Fabbri, Strano nell''emilia, Italy',
        'Strano nell''emilia',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        176,
        '59 Incrocio Severa, Settimo Flora, Italy',
        'Settimo Flora',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        142,
        '5 Incrocio Marzi, Matarazzo laziale, Italy',
        'Matarazzo laziale',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        90,
        '962 Strada Palmazio, Sesto Isabella, Italy',
        'Sesto Isabella',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        289,
        '3 Via Contini, Montefusco laziale, Italy',
        'Montefusco laziale',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        123,
        '644 Piazza Pardini, Gulino calabro, Italy',
        'Gulino calabro',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        135,
        '54 Borgo Ansovino, Serafina nell''emilia, Italy',
        'Serafina nell''emilia',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        282,
        '043 Rotonda Franco, Pacifico nell''emilia, Italy',
        'Pacifico nell''emilia',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        83,
        '21 Contrada Patrone, Settimo Ilia lido, Italy',
        'Settimo Ilia lido',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '21 Piazza Masi, Carta a mare, Italy',
        'Carta a mare',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        205,
        '4 Rotonda Azara, Pirrello salentino, Italy',
        'Pirrello salentino',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        239,
        '410 Contrada Barbera, Veronese del friuli, Italy',
        'Veronese del friuli',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        51,
        '61 Rotonda Gherardo, Quarto Bartolomea terme, Italy',
        'Quarto Bartolomea terme',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        135,
        '609 Via Perugini, Verecondo calabro, Italy',
        'Verecondo calabro',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        76,
        '743 Incrocio Fasano, Loriana ligure, Italy',
        'Loriana ligure',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        282,
        '9 Rotonda Ardito, Vulmaro salentino, Italy',
        'Vulmaro salentino',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        40,
        '78 Borgo Amerigo, San Lazzaro, Italy',
        'San Lazzaro',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        277,
        '1 Via Romero, Quarto Dora a mare, Italy',
        'Quarto Dora a mare',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        217,
        '013 Incrocio Matteo, San Bonaldo terme, Italy',
        'San Bonaldo terme',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        73,
        '94 Strada Pancrazio, Fabiano veneto, Italy',
        'Fabiano veneto',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        86,
        '52 Incrocio Manetto, Settimo Ivan, Italy',
        'Settimo Ivan',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        173,
        '08 Borgo Ercolano, Sesto Fedora, Italy',
        'Sesto Fedora',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        44,
        '2 Incrocio Elisabetta, Frido sardo, Italy',
        'Frido sardo',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        206,
        '311 Piazza Prencipe, Settimo Barbarigo, Italy',
        'Settimo Barbarigo',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        190,
        '4 Piazza Tullio, Sidonio del friuli, Italy',
        'Sidonio del friuli',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        115,
        '30 Incrocio Paolini, Sesto Ermenegarda, Italy',
        'Sesto Ermenegarda',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        241,
        '0 Via Verdiana, Settimo Cassio, Italy',
        'Settimo Cassio',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        35,
        '58 Incrocio Paradiso, Filomeno laziale, Italy',
        'Filomeno laziale',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        108,
        '5 Rotonda Carbone, Vito umbro, Italy',
        'Vito umbro',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        296,
        '412 Incrocio Battistini, Quarto Attilio ligure, Italy',
        'Quarto Attilio ligure',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        143,
        '10 Piazza Ermenegilda, Leopardo lido, Italy',
        'Leopardo lido',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        206,
        '4 Incrocio Giasone, Quarto Donato salentino, Italy',
        'Quarto Donato salentino',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        222,
        '5 Incrocio Rosalinda, Giusta a mare, Italy',
        'Giusta a mare',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        56,
        '65 Borgo Cancelliere, San Marinella a mare, Italy',
        'San Marinella a mare',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        59,
        '1 Strada Di Ciocco, Diomede laziale, Italy',
        'Diomede laziale',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        264,
        '20 Contrada Duilio, Settimo Gennaro, Italy',
        'Settimo Gennaro',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        42,
        '682 Incrocio Lelia, Gerasimo salentino, Italy',
        'Gerasimo salentino',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '6 Strada Caiazzo, Romeo ligure, Italy',
        'Romeo ligure',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        251,
        '26 Contrada Ataleo, Evangelina ligure, Italy',
        'Evangelina ligure',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        270,
        '01 Borgo Elvia, Ligorio terme, Italy',
        'Ligorio terme',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        233,
        '4 Contrada Pedrotti, Settimo Lavinia a mare, Italy',
        'Settimo Lavinia a mare',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        201,
        '7 Via Caporaso, Lidia salentino, Italy',
        'Lidia salentino',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        229,
        '8 Incrocio Adelberto, Gianuario umbro, Italy',
        'Gianuario umbro',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        216,
        '0 Piazza Fiorelli, Romano del friuli, Italy',
        'Romano del friuli',
        'Italy',
        'Bolzano',
        ''
      );
    
  