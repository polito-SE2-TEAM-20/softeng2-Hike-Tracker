--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: insert_hike(integer, character varying, integer, character varying, character varying, character varying, character varying, character varying, numeric, numeric, integer, character varying, jsonb, jsonb, jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hike(user_id integer, title character varying, difficulty integer, gpx_path character varying, country character varying, region character varying, province character varying, city character varying, length numeric, ascent numeric, expected_time integer, description character varying, pictures jsonb, start_point jsonb, end_point jsonb, reference_points jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $$;


--
-- Name: insert_hut(integer, double precision, double precision, integer, numeric, character varying, character varying, character varying, character varying, numeric, time without time zone, time without time zone, character varying, character varying, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut(user_id integer, lat double precision, lon double precision, number_of_beds integer, price numeric, title character varying, address character varying, owner_name character varying, website character varying, elevation numeric, working_time_start time without time zone, working_time_end time without time zone, email character varying, phone_number character varying, pictures jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber",
      "pictures"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number,
      pictures
    );
    END
    $$;


--
-- Name: insert_hut_worker(integer, character varying, character varying, character varying, character varying, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut_worker(hwid integer, email character varying, password character varying, first_name character varying, last_name character varying, role integer, hut_id integer, approved boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$
      DECLARE
        user_id integer;
      BEGIN
      INSERT INTO "public"."users" (
        "id",
        "email",
        "password",
        "firstName",
        "lastName",
        "role",
        "verified",
        "approved"
      ) VALUES(
        hwid, email, password, first_name, last_name, role, true, approved
      ) returning id into user_id;

      INSERT INTO "public"."hut-worker" (
        "userId",
        "hutId"
      ) VALUES ( user_id, hut_id);
      END
      $$;


--
-- Name: insert_parking_lot(integer, double precision, double precision, character varying, integer, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_parking_lot(user_id integer, lat double precision, lon double precision, name character varying, max_cars integer, address character varying, city character varying, country character varying, region character varying, province character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: code-hike; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."code-hike" (code, "userHikeId") FROM stdin;
\.


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
1	1	0	5
1	2	100000	6
1	3	1	3
1	4	2	3
2	5	0	5
2	6	100000	6
3	7	0	5
3	8	100000	6
4	9	0	5
4	10	100000	6
5	11	0	5
5	12	100000	6
6	13	0	5
6	14	100000	6
7	15	0	5
7	16	100000	6
8	17	0	5
8	18	100000	6
8	19	1	3
8	20	2	3
9	21	0	5
9	22	100000	6
10	23	0	5
10	24	100000	6
11	25	0	5
11	26	100000	6
12	27	0	5
12	28	100000	6
13	29	0	5
13	30	100000	6
14	31	0	5
14	32	100000	6
15	33	0	5
15	34	100000	6
16	35	0	5
16	36	100000	6
17	37	0	5
17	38	100000	6
18	39	0	5
18	40	100000	6
19	41	0	5
19	42	100000	6
20	43	0	5
20	44	100000	6
21	45	0	5
21	46	100000	6
22	47	0	5
22	48	100000	6
23	49	0	5
23	50	100000	6
23	51	1	3
23	52	2	3
24	53	0	5
24	54	100000	6
25	55	0	5
25	56	100000	6
26	57	0	5
26	58	100000	6
27	59	0	5
27	60	100000	6
28	61	0	5
28	62	100000	6
29	63	0	5
29	64	100000	6
30	65	0	5
30	66	100000	6
30	67	1	3
30	68	2	3
30	69	3	3
31	70	0	5
31	71	100000	6
32	72	0	5
32	73	100000	6
33	74	0	5
33	75	100000	6
34	76	0	5
34	77	100000	6
35	78	0	5
35	79	100000	6
36	80	0	5
36	81	100000	6
37	82	0	5
37	83	100000	6
38	84	0	5
38	85	100000	6
38	86	1	3
38	87	2	3
39	88	0	5
39	89	100000	6
40	90	0	5
40	91	100000	6
41	92	0	5
41	93	100000	6
42	94	0	5
42	95	100000	6
43	96	0	5
43	97	100000	6
44	98	0	5
44	99	100000	6
45	100	0	5
45	101	100000	6
46	102	0	5
46	103	100000	6
46	104	1	3
46	105	2	3
47	106	0	5
47	107	100000	6
48	108	0	5
48	109	100000	6
49	110	0	5
49	111	100000	6
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country, condition, cause, pictures, "weatherStatus", "weatherDescription") FROM stdin;
1	2	0.70	80	23.20	2	Amprimo	Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.	/static/gpx/Amprimo.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/3.jpg"]	0	
2	2	8.20	200	22.00	1	Anello Chateau Beaulard - Cotolivier - Vazon	Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.	/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx	0.00	Piemonte	Torino	Beaulard	Italia	0		["/static/images/2.jpg"]	0	
3	2	5387.07	150	955.10	1	borgata ruà a cima di crosa	Raggiungi la partenza del Sentiero per la Cima di Crosa impostando sul navigatore “Borgata Ruà – Becetto“.\n\nParcheggiata la macchina a Borgata Ruà (o se impossibilitati a trovare un parcheggio anche a Becetto, allungando di 10 minuti il giro), si prende il sentiero sulla sinistra, nei pressi di una cartina (INDICAZIONI CIMA DI CROSA).	/static/gpx/Borgata Ruà-Cima di Crosa (1).gpx	0.00	Piemonte	Cuneo	Sampeyre	Italia	0		["/static/images/46.jpg"]	0	
4	2	3622.32	130	865.20	2	Colle della Gianna da Pian della Regina	Colle della Gianna at an altitude of approximately 2530m connects the Po Valley to the Pellice Valley allowing you to reach the Barbara Lowrie refuge, an ideal base for multi-day crossings.\n\nIt is advisable to carefully consult the weather forecasts especially for these areas frequently subject to very thick fog.\n\nBeing at moderately high altitudes in spring there is the possibility of finding tongues of snow that could make the ascent more difficult.	/static/gpx/Colle Della Gianna (1).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/37.jpg"]	0	
5	2	3221.31	120	712.94	3	Hike Zicher	Lungo l’itinerario non è garantita la piena copertura telefonica\nIn periodo estivo, la parte finale può essere molto esposta al sole e richiedere fatica.\nIn condizioni di vento forte, è preferibile non proseguire\nE’ possibile sviluppare un itinerario ad anello scendendo dal versante nord della montagna in direzione Bocchetta Sant’Antonio (ma attenzione ad un passaggio su rocce, soprattutto se ghiacciate).	/static/gpx/Hike_Zicher (2).gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Craveggio	Italia	0		["/static/images/29.jpg"]	0	
6	2	15636.67	150	1366.80	2	Usseaux Altro	The flowering of Eriofori along the shores of the lake between July and August is interesting, making it very suggestive.	/static/gpx/Laghi_Albergian.gpx	0.00	Piemonte	Torino	Usseaux	Italia	0		["/static/images/40.jpg"]	0	
7	2	15636.67	150	1366.80	3	Usseaux Altro	Itinerario vario e panoramico, non presenta particolari difficoltà ma per la lunghezza, il dislivello, la mancanza di punti di appoggio e la necessità di una certa capacità di orientamento su sentieri non sempre evidenti (specialmente per la variante in discesa) è consigliato a escursionisti allenati e esperti.	/static/gpx/Laghi_Albergiani.gpx	0.00	Piemonte	Torino	Usseaux	Italia	0		["/static/images/42.jpg"]	0	
8	2	9.30	210	13.00	2	Lago Bianco	Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.\n\nLa diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.\n\nLa Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.\n\nSi può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.	/static/gpx/Lago Bianco.gpx	0.00	Auvergne-Rhone-Alpes	Savoia	Val-Cenis	Francia	0		["/static/images/1.jpg"]	0	
9	2	21358.83	170	1087.90	2	Lago dei 7 colori (lago gignoux)	Parcheggia a Claviere e dirigiti verso la strada comunale Valle Gimont che, dopo poco, si fa sterrata.\n\nLascia alla tua destra i cartelli che indicano il Lago Gignoux e prosegui risalendo le piste da sci.\n\nGiunto a Sagna Longa noterai che la zona è di interesse sciistico, infatti ci sono numerosi arrivi di seggiovia. Segui le indicazioni per Colle Bercia, attraversa una chiesetta, dei caseggiati in pietra e prosegui per il largo sentiero.\n\nL’intero percorso si sviluppa circondato dai bellissimi Monti della Luna ed è caratterizzato da una dolce e semicostante salita su terreno sterrato a tratti ghiaioso.\n\nSuperato il Colle Bercia continua sull’ampia carreggiata che ti conduce ad un valico nel quale noterai particolari conformazioni rocciose e una punta (Cima Saurel 2451 mt). Tieniti sul sentiero basso e supera il valico, che segna anche il confine con la Francia, dopo il quale troverai il lago immerso in una conca.	/static/gpx/Lago dei 7 colori (lago gignoux) (1).gpx	0.00	Piemonte	Torino	Claviere	Italia	0		["/static/images/51.jpg"]	0	
10	2	4024.73	120	810.90	2	Lago d'Afframont 1986 m	Una volta parcheggiata la macchina dirigiti verso il villaggio Albaron. Poco dopo i caseggiati ti troverai di fronte ad un impianto di risalita dismesso, a sinistra troverai un campetto da calcio, proprio dopo il campetto si intravedono i primi cartelli con le indicazioni per il Lago di Afframont. Il sentiero da seguire è il 213, ma lungo il tragitto troverai solo bandiere bianco/rosse e cartelli di legno che indicano la destinazione.\n\nSi sale l’ex pista da sci e ci si addentra nel bosco. Il primo tratto rimane ombreggiato, mentre inizia a farsi sentire la salita. Ad un certo punto ci si affianca ad un ruscello, il Rio di Afframont, che scorre sulla sinistra e si supera con facilità in prossimità dei caseggiati in pietra (attenzione nei periodi di pioggia perché potrebbe essere impraticabile).	/static/gpx/Lago di Afframont 1986 m.gpx	0.00	Piemonte	Torino	Balme	Italia	0		["/static/images/52.jpg"]	0	
11	2	7580.49	110	1049.26	2	Briccas da Borgata Brich 20/02/21	After leaving the car, we continue along the road, first paved and then dirt.\n\nIn case of little snow or high temperatures it is possible to cover the first 150m in altitude without snowshoes.\n\nAs soon as we hit the first snow, we put on our snowshoes and set off on a well-defined path that crosses a wood.\n\nAfter having left the last huts behind us, we turn right towards the North/East near a GTA trail sign painted on a boulder.\n\nFrom here, after the last bush, an enormous, very wide slope opens up before us which culminates right at our peak	/static/gpx/Monte Briccas da Brich (1).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/35.jpg"]	0	
12	2	11664.79	150	1472.80	3	Monte Ferra Con Marco e Daniel	Fondamentali i bastoncini specialmente nella discesa dal Monte Ferra al lago Reisassa.\n\nUnico punto di appoggio è il rifugio Melezè ad inizio itinerario (consigliamo di contattare direttamente la struttura per verificare giorni e orari di apertura)	/static/gpx/Monte Ferra (1).gpx	0.00	Piemonte	Cuneo	Cuneo	Italia	0		["/static/images/28.jpg"]	0	
13	2	6229.07	200	1024.76	2	Da Crissolo a Ghincia	The Path to Monte Granè is a suggestive walk with a splendid view of Monviso (3841 m) and Viso Mozzo (3019 m).\n\nLeave the car in the car park and continue to the left of the sports field where a splendid path immersed in the woods appears before us and after about 1.5 km you come to the dirt road which in summer leads to the Black Eagle refuge.\n\nContinuing on the latter and having reached the refuge, continue along the Crissolo slopes to the end of the ski-lift where, just above the Ghincia Pastour hut, we will find a statue of the Madonna to indicate the end of the path to Monte Granè.\n\nThe return takes place along the same route as the outward journey.	/static/gpx/Monte Granè (2).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/36.jpg"]	0	
14	2	6588.82	150	936.79	2	Montr Pigna da Prea	Posteggiata la macchina nel parcheggio sotto l’abitato di Prea ci dirigiamo lungo la strada asfaltata situata sotto il cimitero, lasciandocelo sulla destra.\n\nAppena incontriamo la prima neve possiamo allacciare le ciaspole e proseguire fino alla borgata di Sant’Anna di Prea. (Nei mesi invernali, con nevicate nella norma, la strada viene pulita fino al parcheggio quindi si può iniziare ad indossare le ciaspole fin da subito).\n\nSubito dopo il cartello, all’ingresso di Sant’Anna di Prea, sulla destra vi è un magnifico sentiero immerso nel bosco che permette di tagliare la borgata accorciando la salita di circa 1 km.\n\nIncrociando nuovamente la strada principale e percorrendo circa 3 km si giunge alla Baita Monte Pigna situata a metà degli impianti di Lurisia.	/static/gpx/Monte Pigna Da Prea (1).gpx	0.00	Piemonte	Cuneo	Roccaforte Mondovì	Italia	0		["/static/images/47.jpg"]	0	
15	2	10065.93	130	842.70	2	Pian della Regina - Laghi del Monviso	The excursion can start near the Po, parking the car in one of the many spaces available. Once you have crossed the stream, follow via Ruata.\n\nTo get your bearings in Crissolo, we suggest following the signs for "La Capanna" and ignoring the various detours on the left that follow the ski lifts. Before reaching the restaurant, you finally take the road, following the signs for Monte Tivoli.\n\nThe path climbs up into the wood (splendid during the autumn season) and crosses the Sbarme stream.	/static/gpx/Pian della Regina - Laghi del Monviso (1).gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/32.jpg"]	0	
16	2	7281.87	120	504.40	2	Fenestrelle Escursionismo	Itinerario di medio sviluppo con ampio panorama verso la Val Chisone.\n\nAttenzione nella stagione invernale: la zona soggetta a valanghe in caso di abbondanti precipitazioni nevose, specialmente nella conca che precede il rifugio.\n\nInformarsi sempre sullo stato della neve presso i gestori del rifugio o l’ufficio turistico di Fenestrelle.	/static/gpx/Rif. Selleries.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/43.jpg"]	0	
17	2	4156.24	150	850.76	0	Rifugio Meira Garneri da Sampeyre	Lascia l’auto nel parcheggio della seggiovia di Sampeyre.\n\nLasciato il parcheggio saliamo subito a destra degli impianti di risalita, dove alcuni cartelli rossi ci segnalano il sentiero attraverso il bosco.\n\nPrendendo rapidamente quota, alla fine del primo tratto di boscoso, raggiungiamo la frazione Sodani dove possiamo osservare la bella chiesa affrescata.\n\nUsciti dalla borgata proseguiamo nuovamente lungo il sentiero circondati da larici, faggi, betulle e dopo alcune deviazione, sempre ben segnalate, usciamo in una splendida radura.\n\nSaliamo gli ultimi 200m a lato della pista o volendo possiamo proseguire più a destra incrociando la strada carrozzabile che nel periodo estivo porta al rifugio.	/static/gpx/Rifugio Meira Garneri da Sampeyre (1).gpx	0.00	Piemonte	Cuneo	Sampeyre	Italia	0		["/static/images/45.jpg"]	0	
18	2	4388.16	200	923.62	2	Sentiero per ROCCA PATANUA	Itinerario interamente rivolto a Sud che normalmente si libera dalla neve già a inizio primavera.\n\n(l’itinerario è stato svolto in periodo invernale, seguito scarsa e quasi totalmente assente copertura nevosa).	/static/gpx/Rocca Patanua da Prarotto (1).gpx	0.00	Piemonte	Torino	Condove	Italia	0		["/static/images/28.jpg"]	0	
19	2	8085.21	150	829.13	3	Cima Durand-Colle Bauzano-Artesina	Lasciata la macchina nello spazioso parcheggio di Artesina o nei posteggi vicino al bar Tana del Lupo, saliamo sulle piste dove possiamo subito infilare le ciaspole.\n\nProcediamo per circa 400m sull’ampio sentiero in direzione Ovest (a destra) e dopo alcuni tornanti troviamo un bivio (a sinistra vi è la stradina che percorreremo al ritorno) dove proseguiamo sulla destra (sentiero F02) dirigendoci verso la Celletta, punto panoramico sulla valle Ellero.\n\nPercorriamo il sentiero per Serra della Turra che ci porta prima a passare sotto la seggiovia e poi ad un pianoro dove troviamo la Baita della Turra, tappa ideale per un eventuale break o colazione.	/static/gpx/Senriero per Anello cima Durand, Colle Bauzano, Artesina (1) (1).gpx	0.00	Piemonte	Cuneo	Artesina	Italia	0		["/static/images/48.jpg"]	0	
20	2	9039.75	120	1090.66	1	Rifugio Quintino Sella e Viso Mozzo	The path does not present any difficulty, in case of rain, however, the climb is not recommended as the route is entirely on stony ground.\n\nFrom up there you have a privileged view of a large part of the Monviso chain and the close distance to the Re di pietra is unique.	/static/gpx/Sentiero per Rifugio Quintino Sella e Viso Mozzo.gpx	0.00	Piemonte	Cuneo	Crissolo	Italia	0		["/static/images/31.jpg"]	0	
21	2	16969.03	120	984.23	3	Da Ss659 a Ss6591	Take the A26 motorway towards Gravellona Toce and follow it to the end. From there stay on the SS33 del Sempione passing Domodossola. At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls. There are unpaved parking lots just before the Centro Fondo Riale.	/static/gpx/Sentiero per Rupe del Gesso - CIASPOLE.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Formazzo	Italia	0		["/static/images/38.jpg"]	0	
22	2	11301.88	140	1381.69	2	Albogno-Pieve Margineta Mater	Escursione senza molte difficoltà ideale per il periodo primaverile e autunnale. \nDopo circa 2 ore di bosco si esce su delle creste molto panoramiche e semplici, il ritorno purtroppo viene fatto su un sentiero poco segnato sulla parte iniziale e ma man mano che si scende compiano sia segni e gli ometti.	/static/gpx/albogno-pieve-margineta-mater-27-8-21.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Albogno	Italia	0		["/static/images/11.jpg"]	0	
37	2	3.10	225	21.10	2	La pieve romanica di Piesenzana e la valle delle tartufaie	Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. \nCirca 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. \nIn regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. \nA Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). \nContemporaneamente i ristoranti della zona propongono piatti a base di tartufi	/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx	0.00	Piemonte	Asti	Montechiaro d'Asti	Italia	0		["/static/images/5.jpg"]	0	
23	2	7.50	200	16.70	2	Alte Langhe Settentrionali - Cossano Belbo	Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.\nSi svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.\nSi imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.\nInizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.\nPercorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. \nSeguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. \nSi procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante	/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx	0.00	Piemonte	Cuneo	Cossano Belbo	Italia	0		["/static/images/4.jpg"]	0	
24	2	8503.26	150	558.51	2	Anello per il Monte Freidour (PERLEVIEDELMONDO)	At km 128 of the SS33 exit towards Crodo. Take the SS659 following it in the direction of Formazza for its entire length until you reach the town of Riale which is located after the Toce waterfalls.	/static/gpx/anello monte freidour (1).gpx	0.00	Piemonte	Torino	San Pietro Val Lemina	Italia	0		["/static/images/39.jpg"]	0	
25	2	42458.63	320	23175.26	2	Anello Pieve di Ledro-Biacesa di Ledro-Rifugio Nino Pernici	Anello sui monti a nord-est del Lago di Ledro, percorso in 3 giorni andando con molta calma, percorribile anche in 2. \nAlcuni tratti della prima metà del percorso sono attrezzati con scale e corde.	/static/gpx/anello-pieve-di-ledro-biacesa-di-ledro-rifugio-nino-pernici.gpx	0.00	Piemonte	Torino	Bussoleno	Italia	0		["/static/images/14.jpg"]	0	
26	2	19320.58	210	666.37	2	Anello sui colli imolesi: Dozza - Pieve S. Andrea	Crossing the provincial road you can see the first of the various signs of the Camino di San Antonio that we will find along the way. We cross and begin a slow but constant climb alongside the fields, which will lead us to a beautiful panoramic view of the surrounding valleys. Paying attention to the crossroads, we continue until we cross the paved road again. In reality there is very little traffic... with a decent view of the Vena del Gesso Romagnola we arrive at the delightful village of Pieve Sant'Andrea (worth a quick detour), to then resume our journey. Be careful not to follow the path of Sant'Antonio, we descend rapidly (shortly after we find the Sorgente delle Accarisie on our left, already existing in Roman times) until we reach the small hamlet of Valsellustra. Here too we cross the road and follow the paved via delle Ville uphill to arrive at a first panoramic point over the surrounding gullies.	/static/gpx/anello-sui-colli-imolesi-dozza-pieve-s-andrea-valsellustra-s.gpx	0.00	Emilia-Romagna	Bologna	Dozza	Italia	0		["/static/images/21.jpg"]	0	
27	2	10764.50	300	1852.46	2	Campione Pieve Campione	Campione Pieve Campione	/static/gpx/campione-pieve-campione.gpx	0.00	Lombardia	Brescia	Campione del Garda	Italia	0		["/static/images/17.jpg"]	0	
28	2	15650.26	210	838.33	2	Casalfiumanese (BO) - Pieve di Sant'Andrea	Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don't die from the heat and the clouds filter the sun's rays and allow you to better enjoy the landscapes	/static/gpx/casalfiumanese-bo-pieve-di-santandrea.gpx	0.00	Emilia-Romagna	Bologna	Casal Fiumese	Italia	0		["/static/images/24.jpg"]	0	
29	2	15650.26	210	838.33	2	Casalfiumanese (BO) - Pieve di Sant'Andrea	Nice challenging trek in the section up to Croara but very beautiful; done in autumn you don't die from the heat and the clouds filter the sun's rays and allow you to better enjoy the landscapes	/static/gpx/casalfiumanese-bo-pieve.gpx	0.00	Emilia-romagna	Bologna	CasalFiumese	Italia	0		["/static/images/25.jpg"]	0	
30	2	17987.27	150	651.41	1	Cavriana pieve- Volta mantovana chiesetta Madonna dei Marchi	Bellissima passeggiata con displivello	/static/gpx/cavriana-pieve-volta-mantovana-chiesetta-madonna-dei-marchi.gpx	0.00	Lombardia	Mantova	Cavriana	Italia	0		["/static/images/13.jpg"]	0	
31	2	5474.28	140	791.51	2	Sentiero per CIMA CIANTIPLAGNA	The route is safe and within everyone's reach, even though you reach a relatively high altitude... for this reason it is good to take into account sudden changes in the weather (wind, rain, thick fog).\n\nDue to the total absence of shading, I recommend sunscreen cream and adequate water supply.\n\nIn late spring it is still possible to find accumulations of snow which can make the ascent difficult, especially in the final stretch towards the summit.\n\nFor cheese lovers, I highly recommend a stop at the Pian dell'Alpe bergeria...	/static/gpx/ciantiplagna.gpx	0.00	Piemonte	Torino	Meana di Susa	Italia	0		["/static/images/41.jpg"]	0	
32	2	6588.82	120	936.79	2	Da Voltino a Pieve di Tremosine e ritorno	Fa quasi paura ad avvicinarsi alla ringhiera. \nVicino alla postazione panoramica presso il bar ristorante che ho fotografato, c'è l'inizio del sentiero per la discesa al Porto di Tremosine.C'è scritto che è consigliato per escursionisti esperti.	/static/gpx/da-voltino-a-pieve-di-tremosine-e-ritorno.gpx	0.00	Lombardia	Brescia	Tremosine sul Garda	Italia	0		["/static/images/15.jpg"]	0	
33	2	13691.92	150	584.92	2	Dalla chiesa romanica di San Pietro di Fenestrella alla abba...	Chiesa di San Pietro de Fenestrella: \nLa chiesa è situata nel cimitero di Albugnano. \nEssa ha affinità compositive con la Canonica di santa Maria di Vezzolano e deriverebbe il suo nome ,secondo alcuni,dalla insolita presenza di tre finestre nell’abside,secondo altri, sarebbe stata così denominata perchè situata nello stretto colle (una gola) compreso tra il rilievo collinare di Albugnano e il rilievo ove sorge il cimitero: \nUna specie di finestra aperta sulla valle sottostante.	/static/gpx/dalla-chiesa-romanica-di-san-pietro-di-fenestrella-alla-abba.gpx	0.00	Piemonte	Asti	Albugnano	Italia	0		["/static/images/27.jpg"]	0	
34	2	14496.86	90	832.35	1	Gulo - Pieve Vergonte	Gulo - Pieve Vergonte	/static/gpx/gulo-pieve-vergonte.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Santa Maria	Italia	0		["/static/images/9.jpg"]	0	
35	2	9623.86	210	697.12	2	Il giro del Montorfano: la chiesa romanica, il borgo e la ve...	Il giro del Montorfano: la chiesa romanica, il borgo e la vetta	/static/gpx/il-giro-del-montorfano-la-chiesa-romanica-il-borgo-e-la-vett.gpx	0.00	Piemonte	Verbano-Cusio-Ossola	Bracchio	Italia	0		["/static/images/10.jpg"]	0	
36	2	12572.72	210	341.55	3	La chiesa romanica di S. Vittore(anello Montemagno--Viarigi)	Il percorso si svolge prevalentemente su sterrata. \nEsso non ha segnaletica ad eccezione dell’ultimo tratto (due km. circa) da località Madonna del Gombo fino a Montemagno. \nIn questo tratto si incontra la segnaletica del sentiero n.507 della Regione Piemonte.	/static/gpx/la-chiesa-romanica-di-s-vittoreanello-montemagno-viarigi.gpx	0.00	Piemonte	Asti	Montemagno	Italia	0		["/static/images/6.jpg"]	0	
38	2	12572.72	255	341.55	3	Le Paludi di Ostiglia Oasi del Busatello Sermide e Pieve	La tradizione afferma che la chiesa fu costruita nel 1082, per volere di Matilde di Canossa. Questa attribuzione risale al 1612 nella Historia ecclesiastica di Mantova dove il Donesmondi attribuisce l'edificazione della chiesa a Matilde, assieme ad altre chiese del territorio. \nIl Donesmondi affermò questa data riprendendo l'iscrizione da una lapide presente sulla facciata della pieve, visibile ancora oggi, dove sta scritto "D.O.M. ET B. MARIAE V. IN COELUM ASSUMPTAE ERECTA A.D. 1082 A CONNTISSA MATHILDE". Secondo un'analisi storica questa lapide non può essere ritenuta originale dell'XI secolo, ma risale al cinquecento. L'ipotesi è che questa iscrizione si stata realizzata durante il restauro del 1538. \nStoricamente, quindi, non ci sono documenti che attestano una data certa di costruzione della chiesa, ma sulla base degli elementi architettonici si può affermare che la pieve venne eretta nell'XI secolo. \nLa chiesa è in stile romanico, costruita in laterizio ed è composta da tre navat	/static/gpx/le-paludi-di-ostiglia-oasi-del-busatello-sermide-e-pieve-di-.gpx	0.00	Lombardia	Mantova	Pieve di Coriano	Italia	0		["/static/images/7.jpg"]	0	
39	2	2150.30	120	586.43	2	Sentiero per il MONTE CUCETTO	Escursione Facile e, nella parte alta, molto panoramica; la cima offre una buona panoramica dei rilievi tra bassa Val Chisone e Val Sangone.\n\nLasciata l’auto, il sentiero parte in corrispondenza del tornante ed entra nel bosco in direzione Nord-Ovest; al primo bivio, proseguire dritto e seguire le indicazioni per “Cucetto”; il sentiero inizia a guadagnare quota abbastanza rapidamente e costantemente, sempre nel bosco.\n\nDopo una serie di tornantini la vegetazione inizierà a diradarsi e si inizierà a scorgere un bel panorama con il Monviso in bella mostra (se il meteo lo permette).	/static/gpx/monte cucetto.gpx	0.00	Piemonte	Torino	Dubbione	Italia	0		["/static/images/50.jpg"]	0	
40	2	2127.35	200	277.52	2	Sentiero per il MONTE MURETTO	È presente un unico punto acqua nel luogo del parcheggio (fontana). Nella stessa piazzetta, al momento della recensione, è sempre aperto nei weekend un singolare bar allestito dentro un vecchio furgone.\n\nPer chi cammina con bimbi e soprattutto cani, attenzione in primavera alla presenza di processionarie.	/static/gpx/monte muretto.gpx	0.00	Piemonte	Torino	Torino	Italia	0		["/static/images/44.jpg"]	0	
41	2	8627.55	70	1018.01	1	Pieve di Ledro - Monte Cocca	Very challenging, but worth it! The view from the top is gorgeous! For the descent it is better to use sticks, or repeat the same route as the climb.	/static/gpx/pieve-di-ledro-monte-cocca.gpx	0.00	Trentino Alto Adige	Provincia di Trento	Pieve di Ledro	Italia	0		["/static/images/20.jpg"]	0	
42	2	22430.40	150	1004.43	2	Pieve S. Stefano a Pian delle Capanne	Causa pioggia e terreno scivoloso preso la 1º variante fino al passo Viamaggio poi proseguito ancora per la 2º variante. \nBisogna calcolare circa 4 km in più.	/static/gpx/pieve-s-stefano-a-pian-delle-capanne.gpx	0.00	Toscana	Arezzo	Pieve Santo Stefano	Italia	0		["/static/images/23.jpg"]	0	
43	2	4857.31	60	94.23	1	Piverone - Anello IV - “Via Romanica al Gesiun”	Piverone - Anello IV - “Via Romanica al Gesiun”	/static/gpx/piverone-anello-iv-via-romanica-al-gesiun.gpx	0.00	Piemonte	Torino	Pieverone	Italia	0		["/static/images/8.jpg"]	0	
44	2	6588.82	320	936.79	2	Plois - Pieve d'Alpago	percorso è tranquillamente percorribile	/static/gpx/plois-pieve-dalpago.gpx	0.00	Veneto	Belluno	Pieve d'Alpegno	Italia	0		["/static/images/19.jpg"]	0	
45	2	6588.82	200	936.79	2	Rifugio Galassi, forcella del ghiacciaio, Rifugio Antelao	Quinta giornata Alta via N°4\nRifugio Galassi, forcella del ghiacciaio, Rifugio Antelao, Pieve di Cadore.	/static/gpx/rifugio-galassi-forcella-del-ghiacciaio-rifugio-antelao-piev.gpx	0.00	Veneto	Belluno	Belluno	Italia	0		["/static/images/18.jpg"]	0	
46	2	8085.21	135	829.13	3	Riva del Garda - Pieve di Ledro - Panchina	Riva del Garda - Pieve di Ledro - Panchina	/static/gpx/riva-del-garda-pieve-di-ledro-panchina.gpx	0.00	Trentino Alto Adige	Provincia di Trento	Sant'Alessandro	Italia	0		["/static/images/16.jpg"]	0	
47	2	19553.11	210	1298.22	2	Sovicille delle Meraviglie - Villa Cetinale - Scala Santa	Suggestivo anello con visita della pieve di Pernina e del parco di Villa Cetinale/Castello di Celsa aperti in occasione dell'evento Sovicille delle Meraviglie ottobre 2021	/static/gpx/sovicille-delle-meraviglie-villa-cetinale-scala-santa-e-romi.gpx	0.00	Toscana	Siena	Sovicille	Italia	0		["/static/images/26.jpg"]	0	
48	2	5304.04	150	958.89	3	BERGERIE DI VALLONCRO’	Open and shade-free environment: remember sunscreen; if the walk is too long, the plateau at the base of the waterfall still offers various possibilities for pleasant picnics.	/static/gpx/vallone di massello (1).gpx	0.00	Piemonte	Torino	Massello	Italia	0		["/static/images/30.jpg"]	0	
49	2	22696.48	110	236.71	2	Ville Disunite - Anello Ghibullo - Villa Pasolini.	The first stretch is entirely on the right bank of the Ronco, on the Via Romea Germanica. Then you enter the territory to go towards the center of the journey, the area of ​​San Pietro in Trento where, within two kilometres, you come across a medieval tower, a 9th century parish church with a fantastic crypt, the ruins of a large villa and a perfectly healthy 16th century villa.	/static/gpx/ville-disunite-anello-ghibullo-villa-pasolini-torre-albicini.gpx	0.00	Emilia-Romagna	Ravenna	Lognana	Italia	0		["/static/images/23.jpg"]	0	
\.


--
-- Data for Name: hut-worker; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."hut-worker" ("userId", "hutId") FROM stdin;
7	1
8	2
9	3
10	4
11	5
12	6
13	7
14	8
15	9
16	10
17	11
18	12
19	13
20	14
21	15
22	16
23	17
24	18
25	19
26	20
27	21
28	22
29	23
30	24
31	25
32	26
33	27
34	28
35	29
36	30
37	31
38	32
39	33
40	34
41	35
42	36
43	37
44	38
45	39
46	40
47	41
48	42
49	43
50	44
51	45
52	46
53	47
54	48
55	49
56	50
57	51
58	52
59	53
60	54
61	55
62	56
63	57
64	58
65	59
66	60
67	61
68	62
69	63
70	64
71	65
72	66
73	67
74	68
75	69
76	70
77	71
78	72
79	73
80	74
81	75
82	76
83	77
84	78
85	79
86	80
87	81
88	82
89	83
90	84
91	85
92	86
93	87
94	88
95	89
96	90
97	91
98	92
99	93
100	94
101	95
102	96
103	97
104	98
105	99
106	100
107	101
108	102
109	103
110	104
111	105
112	106
113	107
114	108
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website, elevation, pictures, description, "workingTimeStart", "workingTimeEnd", "phoneNumber", email) FROM stdin;
1	112	2	100.00	Edmund-Graf-Hütte	2	Dr. Cleo Pedrazzini	http://skinny-context.net	274.87	["/static/images/0f68f939-1081-45c4-88f1-1c6240d0b402.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg"]		07:00:00	22:00:00	+396477681179	Sabrina.Monaco1@libero.it
2	113	2	60.00	Dr.Hernaus-Stöckl	2	Socrate Santini	http://bubbly-commonsense.org	322.20	["/static/images/c3704bc1-511d-4d88-8554-edb5bcbd5b74.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg"]		02:00:00	18:00:00	+393859731489	Tirone21@hotmail.com
3	114	8	52.00	Amstettner Hütte	2	Neiva Cortese	https://dense-guilty.net	337.33	["/static/images/0671e710-77e3-41ad-ac94-973a8aa4d10e.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg"]		04:00:00	19:00:00	+392822151553	Graziano31@gmail.com
4	115	3	41.00	Hochleckenhaus	2	Edvige Cipriano	https://prestigious-compassion.it	291.77	["/static/images/67c24cb6-647b-434e-a296-40a071d11211.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg"]		07:00:00	21:00:00	+390008999831	Lautone1@gmail.com
5	116	3	42.00	Kampthalerhütte	2	Paola Siri	https://motionless-ferret.net	319.64	["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg"]		02:00:00	20:00:00	+395568481870	Uriele63@email.it
6	117	10	48.00	Lambacher Hütte	2	Priamo Cenni	https://some-noon.net	308.75	["/static/images/67c24cb6-647b-434e-a296-40a071d11211.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg"]		05:00:00	19:00:00	+390436493428	Tarso_DAngeli41@yahoo.com
7	118	1	55.00	Lustenauer Hütte	2	Sig. Colmanno Di Ciocco	http://alienated-anywhere.net	286.63	["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]		06:00:00	19:00:00	+397308624175	Desiderato_Verme@yahoo.com
8	119	9	81.00	Gablonzer Hütte	2	Protasio Femina	http://cylindrical-endive.net	275.71	["/static/images/0f68f939-1081-45c4-88f1-1c6240d0b402.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg"]		08:00:00	23:00:00	+399331825008	Ursino_Bressan@libero.it
9	120	1	136.00	Katafygio «Flampouri»	2	Foca Barra	https://present-schooner.it	313.48	["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg"]		03:00:00	22:00:00	+399592823690	Vedasto30@hotmail.com
10	121	6	82.00	Simonyhütte	2	Ing. Dafne Di Rocco	http://snarling-ring.net	277.54	["/static/images/6d3e3fa9-dedb-4c76-8d2e-1efd1026617d.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]		01:00:00	20:00:00	+398273080275	Porziano.Pianigiani2@gmail.com
11	122	4	44.00	Vinzenz-Tollinger-Hütte	2	Dionisia Benatti	https://weepy-scent.it	332.61	["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg"]		02:00:00	20:00:00	+399738237125	Ramiro45@yahoo.com
12	123	9	149.00	Ottokar-Kernstock-Haus	2	Nunziata Rapuano	https://crafty-gossip.org	300.42	["/static/images/872ff603-5819-4c1c-a4bc-cee33e1db7dd.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg"]		01:00:00	19:00:00	+392770103757	Adelmo_Bandini@hotmail.com
13	124	1	102.00	Reisseckhütte	2	Alba Cottone	https://filthy-platinum.com	299.50	["/static/images/4451e87f-0108-4fd7-872b-fa91671f8104.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg"]		06:00:00	20:00:00	+398530063453	Fernando_Fonti40@yahoo.it
14	125	5	79.00	Vernagthütte	2	Eva Boschi	https://some-emanate.com	300.42	["/static/images/6618e934-60ac-4e23-ab86-d8dd255db78d.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg"]		07:00:00	18:00:00	+397606217964	Ginevra_Vecchi@libero.it
15	126	1	101.00	Wormser Hütte	2	Ulberto Cascio	http://flamboyant-scrambled.it	310.45	["/static/images/95ab3575-30d3-4c94-a91f-0f2bac28e717.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg"]		06:00:00	18:00:00	+391064788618	Filippo.Farina@yahoo.it
16	127	5	117.00	Biberacher Hütte	2	Ettore Sorrentino	http://carefree-gold.com	302.80	["/static/images/22233684-687e-4f05-832d-2edc726209fb.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg"]		05:00:00	23:00:00	+392926156719	Damiana.Giardina72@gmail.com
17	128	6	69.00	Katafygio «1777»	2	Sig. Vissia Loi	https://amazing-vintner.it	267.71	["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]		02:00:00	23:00:00	+399406527950	Arturo.Zanella84@email.it
18	129	8	137.00	Hochwaldhütte	2	Vera Bulgarelli	https://tempting-screwdriver.it	312.96	["/static/images/0f68f939-1081-45c4-88f1-1c6240d0b402.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg"]		03:00:00	18:00:00	+396503212968	Damocle_Silvestro@libero.it
19	130	5	50.00	Kölner Eifelhütte	2	Beata Castiglioni	https://first-mortise.net	294.39	["/static/images/872ff603-5819-4c1c-a4bc-cee33e1db7dd.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg"]		06:00:00	22:00:00	+399668925231	Giuda_Garofalo56@email.it
20	131	7	129.00	Madrisahütte	2	Romilda Carrieri	http://valuable-self-confidence.it	317.75	["/static/images/dc748eef-5832-462c-b8ea-565a7beb4298.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg"]		04:00:00	19:00:00	+393312416945	Manuela.Palladino@hotmail.com
21	132	7	114.00	Dresdner Hütte	2	Remo Vecchi	https://frugal-calorie.it	336.54	["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg"]		03:00:00	22:00:00	+399559148306	Venanzio6@email.it
22	133	10	124.00	Fiderepasshütte	2	Fernanda Baldi	https://vengeful-eyelid.net	312.97	["/static/images/c3704bc1-511d-4d88-8554-edb5bcbd5b74.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg"]		07:00:00	23:00:00	+390410672257	Illuminato69@email.it
23	134	9	69.00	Göppinger Hütte	2	Marta Capriotti	https://subdued-conflict.it	287.19	["/static/images/7bb60d4d-4477-40ff-8ad1-39ff877f826b.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]		08:00:00	18:00:00	+392104014652	Protasio_Gatta50@yahoo.com
24	135	7	46.00	Oberzalimhütte	2	Pantaleone Gandolfo	https://grandiose-bonus.org	290.64	["/static/images/0f68f939-1081-45c4-88f1-1c6240d0b402.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg"]		08:00:00	22:00:00	+390932027900	Eliano.Maresca@gmail.com
25	136	2	111.00	Rastkogelhütte	2	Rachele Ferroni	http://unacceptable-lotion.it	316.15	["/static/images/9333cf6d-3c60-4462-a815-09ea3a54fbaf.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg"]		09:00:00	18:00:00	+397340527958	Angelo45@yahoo.it
26	137	2	63.00	Ansbacher Skihütte im Allgäu	2	Bartolo Maione	http://fragrant-leadership.net	289.53	["/static/images/872ff603-5819-4c1c-a4bc-cee33e1db7dd.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg"]		04:00:00	23:00:00	+395403199549	Cantidio80@email.it
27	138	3	81.00	Kaltenberghütte	2	Brigida De Meo	https://delightful-offset.org	268.27	["/static/images/c4b3fba9-e26e-4fb0-a093-78dac6a2f062.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg"]		05:00:00	23:00:00	+391346038164	Coronato.Salis35@hotmail.com
28	139	9	99.00	Schweinfurter Hütte	2	Eugenio Fava	https://yummy-buddy.com	267.08	["/static/images/c4b3fba9-e26e-4fb0-a093-78dac6a2f062.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg"]		05:00:00	23:00:00	+399539954735	Angelo_Battaglia73@gmail.com
29	140	5	136.00	Katafygio «Vardousion»	2	Malco Zappia	https://required-gemsbok.it	267.25	["/static/images/dc748eef-5832-462c-b8ea-565a7beb4298.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg"]		09:00:00	21:00:00	+398389378545	Semplicio94@libero.it
30	141	2	97.00	Kocbekov dom na Korošici	2	Tobia Tortorici	https://reasonable-toll.org	276.46	["/static/images/eb0a64be-eeba-49fb-b952-227f7ad04a48.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg"]		03:00:00	18:00:00	+393802662367	Sicuro_Speranza@yahoo.it
31	142	7	135.00	Planinski dom Rašiške cete na Rašici	2	Dr. Rosamunda Marega	https://hoarse-trek.org	308.84	["/static/images/9333cf6d-3c60-4462-a815-09ea3a54fbaf.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg"]		06:00:00	18:00:00	+393441588001	Loreno45@libero.it
32	143	9	120.00	Prešernova koca na Stolu	2	Ventura Panzeri	https://squeaky-egg.com	269.15	["/static/images/7bb60d4d-4477-40ff-8ad1-39ff877f826b.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg"]		09:00:00	19:00:00	+393577936454	Amerigo19@hotmail.com
33	144	8	83.00	Planinski dom na Mrzlici	2	Servidio Restivo	https://infinite-menopause.com	308.64	["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg"]		09:00:00	23:00:00	+394099778080	Ivano_Casali60@yahoo.it
34	145	1	139.00	Koca na Planini nad Vrhniko	2	Zena Luciano	https://elegant-rifle.it	304.78	["/static/images/6618e934-60ac-4e23-ab86-d8dd255db78d.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg"]		02:00:00	23:00:00	+396439505466	Erardo8@yahoo.it
35	146	1	99.00	Zavetišce gorske straže na Jelencih	2	Catena Vitali	https://indelible-pat.com	336.12	["/static/images/0671e710-77e3-41ad-ac94-973a8aa4d10e.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg"]		02:00:00	21:00:00	+397571728324	Immacolata.Lucarelli38@hotmail.com
36	147	5	67.00	Planinski dom na Gori	2	Clara Pellegrino	http://impractical-landing.net	273.67	["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg"]		06:00:00	20:00:00	+391017052480	Fermo.Macr@hotmail.com
37	148	8	70.00	Bregarjevo zavetišce na planini Viševnik	2	Debora Vuillermoz	http://glorious-insight.it	327.94	["/static/images/95ab3575-30d3-4c94-a91f-0f2bac28e717.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg"]		09:00:00	19:00:00	+391078441442	Ulstano.Barra91@yahoo.it
38	149	9	57.00	Koca pod Bogatinom	2	Ing. Terzo Nocerino	https://delicious-kneejerk.it	293.07	["/static/images/eb0a64be-eeba-49fb-b952-227f7ad04a48.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg"]		09:00:00	20:00:00	+399291961277	Ilva78@hotmail.com
39	150	7	130.00	Pogacnikov dom na Kriških podih	2	Dott. Clinio Ravaioli	https://doting-ischemia.org	280.49	["/static/images/9333cf6d-3c60-4462-a815-09ea3a54fbaf.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg"]		05:00:00	21:00:00	+391622215321	Vilfredo_Floridia80@hotmail.com
40	151	8	66.00	Dom na Smrekovcu	2	Luciano Mora	http://demanding-leadership.org	295.33	["/static/images/0f68f939-1081-45c4-88f1-1c6240d0b402.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg"]		09:00:00	21:00:00	+394180735251	Quinzio_Lari@email.it
41	152	3	145.00	Refuge Du Chatelleret	2	Vito Cardia	https://wiry-electrocardiogram.org	278.98	["/static/images/67c24cb6-647b-434e-a296-40a071d11211.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg"]		04:00:00	20:00:00	+392308289684	Uberto.Pani14@yahoo.it
42	153	8	103.00	Refuge De Chalance	2	Endrigo Cuzzocrea	http://impartial-loop.it	313.40	["/static/images/6618e934-60ac-4e23-ab86-d8dd255db78d.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg"]		08:00:00	22:00:00	+397210865856	Corbiniano.Nota64@yahoo.it
43	154	8	124.00	Refuge Des Bans	2	Audace Panza	https://clever-anniversary.com	319.73	["/static/images/9333cf6d-3c60-4462-a815-09ea3a54fbaf.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg"]		06:00:00	21:00:00	+398548079655	Aristarco_Giordano@yahoo.com
44	155	2	62.00	Refuge De Pombie	2	Cristina Ambrosini	https://indolent-report.it	289.64	["/static/images/9333cf6d-3c60-4462-a815-09ea3a54fbaf.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg"]		04:00:00	19:00:00	+399565289614	Verulo.Micco@hotmail.com
45	156	4	76.00	Refuge De Larribet	2	Lorenza Renna	http://conscious-republican.com	311.80	["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg"]		04:00:00	23:00:00	+396831826511	Lorenza_Schiavone@hotmail.com
46	157	6	48.00	Refuge Du Mont Pourri	2	Leonia Perrotta	https://whirlwind-optimization.net	279.70	["/static/images/eb0a64be-eeba-49fb-b952-227f7ad04a48.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg"]		05:00:00	22:00:00	+399284366863	Doriano.Colantuono@gmail.com
47	158	2	138.00	Refuge De La Dent D?Oche	2	Dott. Aiace Salatiello	https://watchful-visor.it	333.58	["/static/images/0671e710-77e3-41ad-ac94-973a8aa4d10e.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg"]		07:00:00	19:00:00	+394438043314	Lisa.Semprini@gmail.com
48	159	9	96.00	Bergseehütte SAC	2	Veronica Anelli	http://favorable-enthusiasm.com	310.29	["/static/images/9333cf6d-3c60-4462-a815-09ea3a54fbaf.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg"]		02:00:00	19:00:00	+399968972020	Elsa_Giorgi@email.it
49	160	3	50.00	Bivouac au Col de la Dent Blanche CAS	2	Anna Martini	https://thoughtful-ruler.it	272.36	["/static/images/7bb60d4d-4477-40ff-8ad1-39ff877f826b.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg"]		02:00:00	22:00:00	+394125424129	Icaro.Zanetti51@email.it
50	161	3	106.00	Salbitschijenbiwak SAC	2	Gemma Baldini	https://cultivated-selling.it	273.83	["/static/images/c4b3fba9-e26e-4fb0-a093-78dac6a2f062.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg"]		06:00:00	18:00:00	+390699931041	Verdiana_Paolucci@email.it
51	162	7	50.00	Spannorthütte SAC	2	Aresio Piva	http://authorized-annual.net	283.91	["/static/images/dc748eef-5832-462c-b8ea-565a7beb4298.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]		05:00:00	21:00:00	+392888430430	Aurelia_Giustra35@email.it
52	163	3	52.00	Cabane Arpitettaz CAS	2	Gabriella Modica	https://plastic-surge.org	335.60	["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg"]		08:00:00	20:00:00	+395879803717	Liberto_Rizza84@gmail.com
53	164	10	147.00	Refugio De Lizara	2	Adone Siino	https://calm-reflection.org	299.24	["/static/images/4451e87f-0108-4fd7-872b-fa91671f8104.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg"]		09:00:00	19:00:00	+392409622118	Pupolo.Bruno@yahoo.it
54	165	2	68.00	Albergue De Montfalcó	2	Margherita Petronio	https://shiny-colloquy.it	277.04	["/static/images/22233684-687e-4f05-832d-2edc726209fb.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg"]		09:00:00	21:00:00	+398840025832	Valfrido92@yahoo.it
55	166	7	150.00	El Molonillo/Peña Partida	2	Ladislao Zagaria	http://voluminous-actor.com	270.11	["/static/images/67c24cb6-647b-434e-a296-40a071d11211.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg"]		05:00:00	23:00:00	+399191553686	Verano.Ciuffreda@libero.it
56	167	3	139.00	La Campiñuela	2	Glenda Capuano	https://big-interject.org	285.88	["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg"]		03:00:00	23:00:00	+393970679851	Gentile_Campus@gmail.com
57	168	3	133.00	Titov Vrv	2	Armando Verme	https://best-scent.it	280.36	["/static/images/67c24cb6-647b-434e-a296-40a071d11211.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg"]		01:00:00	22:00:00	+397195737803	Ornella.Mazza@email.it
58	169	8	122.00	Rifugio Franchetti	2	Niniano Coretti	https://kosher-reflection.it	296.91	["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg"]		09:00:00	21:00:00	+397011225410	Calogero.Riggio@gmail.com
59	170	7	103.00	Rifugio Semenza	2	Ilva Cappelletti	https://frayed-shootdown.it	281.90	["/static/images/bcb89119-072b-4034-b2f6-5df38bfbd34c.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg"]		02:00:00	23:00:00	+399168275353	Teodora27@hotmail.com
60	171	5	49.00	Rifugio Città di Mortara 	2	Adelmo Maggiani	http://overjoyed-diary.org	288.48	["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg"]		01:00:00	18:00:00	+395202280767	Cesare_Scalia78@yahoo.com
61	172	1	147.00	Rifugio Andolla	2	Morena Campus	https://snappy-rose.net	301.81	["/static/images/872ff603-5819-4c1c-a4bc-cee33e1db7dd.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg"]		06:00:00	22:00:00	+399430423800	Nicola.Martucci13@email.it
62	173	8	134.00	Rifugio Forte dei Marmi	2	Aciscolo Greco	https://tragic-plastic.it	330.85	["/static/images/67c24cb6-647b-434e-a296-40a071d11211.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg"]		06:00:00	19:00:00	+392805906490	Zabedeo_Paone68@hotmail.com
63	174	5	47.00	Rifugio Berti	2	Domezio Sacchet	http://fatherly-gas.it	323.76	["/static/images/c4b3fba9-e26e-4fb0-a093-78dac6a2f062.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg"]		08:00:00	21:00:00	+399994171649	Bertolfo40@yahoo.com
64	175	1	125.00	Rifugio Premuda	2	Alfio Critelli	https://potable-vengeance.it	318.39	["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg"]		09:00:00	18:00:00	+394496907698	Crocefisso58@libero.it
65	176	2	88.00	Rifugio Elisa	2	Costante Di Nardo	https://fatal-celsius.com	322.74	["/static/images/bcb89119-072b-4034-b2f6-5df38bfbd34c.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg"]		05:00:00	23:00:00	+397575587345	Dorotea_Caretti12@yahoo.it
66	177	8	66.00	Rifugio CAI Saronno	2	Fosco Musumeci	https://untrue-exterior.it	284.55	["/static/images/7bb60d4d-4477-40ff-8ad1-39ff877f826b.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg"]		09:00:00	22:00:00	+398282452440	Gioventino.Cinelli35@email.it
67	178	8	112.00	Rifugio Picco Ivigna	2	Celinia Bodini	http://fixed-snack.org	274.94	["/static/images/4451e87f-0108-4fd7-872b-fa91671f8104.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg"]		03:00:00	22:00:00	+391734924363	Gaetano7@yahoo.it
68	179	5	107.00	Rifugio Toesca	2	Liborio Baraldi	http://equal-inhibitor.it	327.85	["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg"]		03:00:00	20:00:00	+394378843882	Ivanoe19@libero.it
69	180	2	45.00	Rifugio Al Cedo	2	Berenice Liccardo	https://pointless-cell.it	298.11	["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg"]		04:00:00	21:00:00	+392723698779	Graziella66@gmail.com
70	181	4	63.00	Capanna Gnifetti	2	Olimpia Ciccone	http://fearless-characterization.it	267.22	["/static/images/6d3e3fa9-dedb-4c76-8d2e-1efd1026617d.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg"]		02:00:00	20:00:00	+392760127484	Archimede12@libero.it
71	182	7	42.00	Rifugio Aosta	2	Giambattista Pedrazzini	http://scrawny-dependent.net	276.97	["/static/images/3abd12a2-ca82-4d5e-b93f-c4bf780d74b3.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]		04:00:00	20:00:00	+394320077149	Carlotta_Massari@gmail.com
72	183	8	119.00	Rifugio Cevedale	2	Dr. Artemisa Paola	https://rural-future.org	285.50	["/static/images/eb0a64be-eeba-49fb-b952-227f7ad04a48.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg"]		01:00:00	22:00:00	+395653224954	Unna.Marra@yahoo.it
73	184	10	82.00	Rifugio Ponti	2	Oderico Criscenti	https://tender-grandfather.it	284.00	["/static/images/4451e87f-0108-4fd7-872b-fa91671f8104.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]		04:00:00	22:00:00	+392172272328	Samona.Ferrigno@gmail.com
74	185	1	48.00	Rifugio XII Apostoli	2	Ildegarda De Gregorio	https://front-lawn.it	324.07	["/static/images/872ff603-5819-4c1c-a4bc-cee33e1db7dd.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg"]		04:00:00	19:00:00	+391791291755	Rubiano_Natale@yahoo.it
75	186	2	123.00	Rifugio Elisabetta Soldini	2	Concordio Postiglione	https://profitable-accelerant.com	280.80	["/static/images/dc748eef-5832-462c-b8ea-565a7beb4298.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg"]		09:00:00	23:00:00	+392372949725	Tarquinia46@gmail.com
76	187	2	50.00	Rifugio Denza	2	Ella Cascone	http://sophisticated-hearth.net	266.15	["/static/images/3abd12a2-ca82-4d5e-b93f-c4bf780d74b3.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg"]		06:00:00	21:00:00	+391085712642	Zaira_Morra@yahoo.com
77	188	7	124.00	Rifugio Fonte Tavoloni 	2	Oscar Pizzitola	http://constant-complicity.com	304.00	["/static/images/4451e87f-0108-4fd7-872b-fa91671f8104.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg"]		09:00:00	22:00:00	+399019271725	Romualdo.Zanetti@gmail.com
78	189	3	55.00	Rifugio Carducci	2	Cremenzio Turchi	http://weekly-noon.com	319.84	["/static/images/3abd12a2-ca82-4d5e-b93f-c4bf780d74b3.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg"]		01:00:00	20:00:00	+398894518618	Vedasto86@libero.it
79	190	5	135.00	Rifugio Bindesi	2	Giorgio Passeri	http://worrisome-officer.it	281.15	["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg"]		09:00:00	23:00:00	+397076493339	Concetta.Ferrarini@email.it
80	191	10	46.00	Mountain hut Miroslav Hirtz	2	Alfonsa Motisi	http://cluttered-yin.it	314.25	["/static/images/22233684-687e-4f05-832d-2edc726209fb.jpg", "/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg"]		03:00:00	23:00:00	+398678541747	Dolores_Petrone43@yahoo.it
81	192	3	121.00	Koca na Blegošu	2	Donna Caterino	http://prize-tanker.com	336.36	["/static/images/22233684-687e-4f05-832d-2edc726209fb.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg"]		07:00:00	23:00:00	+392735740271	Cassandra.Clemente@gmail.com
82	193	8	69.00	Wittener Hütte	2	Franca Dell'Amico	https://strong-inglenook.com	280.81	["/static/images/0671e710-77e3-41ad-ac94-973a8aa4d10e.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg"]		02:00:00	21:00:00	+394103633449	Luana.Saccone@hotmail.com
83	194	8	55.00	Hochjoch-Hospiz	2	Venusta Iannone	http://dental-meteorology.it	303.43	["/static/images/bcb89119-072b-4034-b2f6-5df38bfbd34c.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg"]		07:00:00	18:00:00	+398655320033	Teudosia.Galluzzo@gmail.com
84	195	1	86.00	Meilerhütte	2	Milo Orlandi	https://sinful-washtub.com	268.31	["/static/images/95ab3575-30d3-4c94-a91f-0f2bac28e717.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg"]		04:00:00	23:00:00	+390139104946	Clemenzia.Femina@email.it
85	196	6	104.00	Gaudeamushütte	2	Armida Pierro	http://energetic-following.net	282.71	["/static/images/3abd12a2-ca82-4d5e-b93f-c4bf780d74b3.jpg", "/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]		06:00:00	22:00:00	+396725429882	Casimiro_DeAngelis@email.it
86	197	2	97.00	Rheydter Hütte	2	Tiziano Lo Presti	http://elementary-pasture.org	296.72	["/static/images/0671e710-77e3-41ad-ac94-973a8aa4d10e.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg"]		01:00:00	23:00:00	+391229668017	Floriano58@libero.it
87	198	10	102.00	Sektionshütte Krippen	2	Flora Pratesi	http://boring-log.com	321.86	["/static/images/c4b3fba9-e26e-4fb0-a093-78dac6a2f062.jpg", "/static/images/ed08003f-38ee-45e4-8d4a-cfc96c9ea3bb.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg"]		06:00:00	23:00:00	+395503747794	Minerva_Pastorino85@libero.it
88	199	8	120.00	Neunkirchner Hütte	2	Mattia Zanella	https://dazzling-mean.com	279.34	["/static/images/3abd12a2-ca82-4d5e-b93f-c4bf780d74b3.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg"]		02:00:00	20:00:00	+395268989475	Uliva.Atzeni@yahoo.it
89	200	1	83.00	Refugio De Riglos	2	Gemma Femina	https://funny-singular.it	298.65	["/static/images/872ff603-5819-4c1c-a4bc-cee33e1db7dd.jpg", "/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg"]		06:00:00	19:00:00	+394703791166	Angelica8@yahoo.it
90	201	4	139.00	Salbithütte SAC	2	Dr. Astianatte De Vita	https://educated-songbird.com	274.97	["/static/images/6d3e3fa9-dedb-4c76-8d2e-1efd1026617d.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg"]		08:00:00	19:00:00	+395532391540	Beata69@gmail.com
91	202	9	119.00	Finsteraarhornhütte SAC	2	Dott. Taziano Matteucci	https://massive-earplug.it	321.44	["/static/images/eb0a64be-eeba-49fb-b952-227f7ad04a48.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg"]		07:00:00	23:00:00	+395379570686	Ebe.Marinucci68@gmail.com
92	203	7	61.00	Cabane des Vignettes CAS	2	Marcella Fior	http://terrific-river.net	323.54	["/static/images/c3704bc1-511d-4d88-8554-edb5bcbd5b74.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg"]		06:00:00	18:00:00	+394528378236	Settimio_Zaccaro34@email.it
93	204	4	136.00	Glecksteinhütte SAC	2	Rosa Cardinale	https://easy-going-fifth.it	279.70	["/static/images/6d3e3fa9-dedb-4c76-8d2e-1efd1026617d.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg"]		03:00:00	22:00:00	+397142222411	Tesifonte73@gmail.com
94	205	9	118.00	Länta-Hütte SAC	2	Giuliana Iaria	http://beloved-moose.org	276.38	["/static/images/bcb89119-072b-4034-b2f6-5df38bfbd34c.jpg", "/static/images/aa2d3102-0d7b-4b4c-9e53-34dce19269db.jpg", "/static/images/a1a7bc1d-635a-47fe-9b54-79107f0a33f4.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg"]		05:00:00	22:00:00	+393840787903	Odorico.Vannini25@yahoo.it
95	206	2	116.00	Monte-Leone-Hütte SAC	2	Sefora Montanaro	http://deserted-afoul.it	275.30	["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg"]		07:00:00	23:00:00	+390740904391	Ruggero67@libero.it
96	207	7	42.00	Ringelspitzhütte SAC	2	Fabiana La Sala	https://darling-stepdaughter.org	286.33	["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg"]		08:00:00	19:00:00	+392617763619	Daria_Sartor14@yahoo.it
97	208	9	137.00	Na poljanama Maljen	2	Dr. Caronte Praticò	https://corrupt-netbook.net	269.92	["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg", "/static/images/9bb9d0e9-1a01-4201-b2b6-a7118fd83a00.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/fb264f6f-f43b-4695-8c2c-fe1e47a84442.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg"]		03:00:00	18:00:00	+390116918349	Miriam.Montagner@yahoo.it
98	209	6	36.00	Dobra voda	2	Cirino Ferri	http://jam-packed-nickname.org	301.78	["/static/images/67c24cb6-647b-434e-a296-40a071d11211.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg"]		07:00:00	23:00:00	+391443339759	Caterina_Caccavo@email.it
99	210	9	80.00	Ivanova hiža	2	Genesio Barletta	http://second-hand-zampone.org	271.53	["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg"]		08:00:00	18:00:00	+395080902700	Venerando.Saccone@yahoo.it
100	211	4	135.00	Glavica	2	Diego Lippi	http://showy-scorn.net	323.03	["/static/images/6618e934-60ac-4e23-ab86-d8dd255db78d.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg"]		04:00:00	18:00:00	+399153148071	Pericle_Vinci@yahoo.com
101	212	2	93.00	Trpošnjik	2	Prudenzio Tralli	https://aggravating-fillet.it	290.38	["/static/images/dc748eef-5832-462c-b8ea-565a7beb4298.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg"]		04:00:00	21:00:00	+395189514248	Matteo.Simeoni58@yahoo.it
102	213	7	49.00	Bitorajka	2	Nives Prato	http://creative-keyboard.net	336.27	["/static/images/383e5b6f-61e6-4eac-8c11-14aa9c75f9ff.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg"]		09:00:00	19:00:00	+399706861320	Leonida.Passeri36@yahoo.it
103	214	3	129.00	Zlatko Prgin	2	Secondiano Celentano	https://short-term-feeding.it	302.23	["/static/images/1a6da898-d9f5-4978-bf9c-88d09d03e650.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg", "/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg", "/static/images/1f0b8656-356f-4c5c-a6c9-d07f874d4ff3.jpg"]		09:00:00	20:00:00	+395563203954	Alboino.Pascarella12@libero.it
104	215	5	79.00	Prpa	2	Ing. Brigida Vailati	https://cute-weedkiller.net	275.98	["/static/images/0671e710-77e3-41ad-ac94-973a8aa4d10e.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/3bee0f7c-8761-49aa-bd54-5533ba315adf.jpg", "/static/images/21674aec-f929-48b2-abce-cbcd6560d65a.jpg"]		09:00:00	22:00:00	+390883084561	Fabio90@yahoo.com
105	216	4	93.00	Ždrilo	2	Annabella Migliore	https://famous-diversity.it	328.03	["/static/images/083cd259-aa14-42d6-bb05-561a22ba2d33.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/c6f33835-8e9e-42ff-b5e5-c2b10ddc1e2e.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg"]		06:00:00	19:00:00	+398728865165	Raide.Liccardo83@libero.it
106	217	9	73.00	Miroslav Hirtz	2	Macaria Pappalardo	http://defensive-timbale.net	277.33	["/static/images/c4b3fba9-e26e-4fb0-a093-78dac6a2f062.jpg", "/static/images/7b65bb37-0937-40cb-aafe-e9e7c29c6e2d.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/15a1c9ac-4459-4221-a342-0ca03d00da38.jpg", "/static/images/14494b13-3ee2-4cb5-802d-c0c5a165997c.jpg"]		01:00:00	22:00:00	+399146824130	Ortensio_Mosca63@gmail.com
107	218	4	131.00	Jezerce	2	Teresa Di Pede	https://entire-tailspin.it	308.18	["/static/images/95ab3575-30d3-4c94-a91f-0f2bac28e717.jpg", "/static/images/d84917be-22f3-4945-9b8d-7ac6c3820967.jpg", "/static/images/aa70e129-7383-4ac3-8ee6-c3ddea79497c.jpg", "/static/images/32b6cafb-115a-4471-976d-666bab459aa9.jpg", "/static/images/25327f8d-bd06-44a5-984a-bc932b5059a8.jpg"]		09:00:00	18:00:00	+398230459591	Selene_Ghilardi86@yahoo.com
108	219	4	67.00	Ivica Sudnik	2	Apollina Tirelli	http://kindly-rabbi.net	334.66	["/static/images/dc748eef-5832-462c-b8ea-565a7beb4298.jpg", "/static/images/b5412fa7-0918-4b9d-9b65-9481f20cdc77.jpg", "/static/images/17d42c56-834e-40c0-b265-fc38494b6d64.jpg", "/static/images/49b2fca2-4635-4f04-9771-1c5ec81e9fb3.jpg", "/static/images/41b4d352-309b-4de3-bb5f-40180c89e7a9.jpg"]		09:00:00	21:00:00	+399515051730	Ulstano.Casali51@libero.it
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
1	220	72	2	Italy	Catania		Borgo Giosu� salentino
2	221	150	2	Italy	Ascoli Piceno		Vinebaldo veneto
3	222	198	2	Italy	Reggio Emilia		Sesto Rainelda sardo
4	223	203	2	Italy	Salerno		Comito veneto
5	224	26	2	Italy	Pisa		Emmerico laziale
6	225	253	2	Italy	Savona		Settimo Godeberta
7	226	149	2	Italy	Siena		Malizia terme
8	227	291	2	Italy	Barletta-Andria-Trani		Sesto Beato ligure
9	228	140	2	Italy	Imperia		Settimo Costanza
10	229	223	2	Italy	Prato		Sesto Nazario
11	230	111	2	Italy	Pistoia		Renda salentino
12	231	253	2	Italy	Teramo		Pascali nell'emilia
13	232	57	2	Italy	Verbano-Cusio-Ossola		Guida lido
14	233	275	2	Italy	Arezzo		Borgo Severiano
15	234	47	2	Italy	L'Aquila		Liotta umbro
16	235	67	2	Italy	Monza e della Brianza		Chessa a mare
17	236	157	2	Italy	Messina		Luciano ligure
18	237	57	2	Italy	Genova		Giulitta lido
19	238	181	2	Italy	Belluno		Severino umbro
20	239	106	2	Italy	Udine		Olindo laziale
21	240	209	2	Italy	Messina		Furio ligure
22	241	253	2	Italy	Siracusa		Settimo Emma
23	242	6	2	Italy	Rovigo		Iacono ligure
24	243	136	2	Italy	Cosenza		Balboni laziale
25	244	36	2	Italy	Ancona		San Ansaldo
26	245	169	2	Italy	Salerno		Genesia salentino
27	246	183	2	Italy	Verona		Salis terme
28	247	234	2	Italy	Taranto		Sansone ligure
29	248	207	2	Italy	Benevento		Quarto Gesualdo a mare
30	249	52	2	Italy	Lecco		Di Caccamo nell'emilia
31	250	280	2	Italy	Chieti		Nazario salentino
32	251	30	2	Italy	Ragusa		Villani del friuli
33	252	27	2	Italy	Milano		Sesto Mimma laziale
34	253	5	2	Italy	Olbia-Tempio		Plutarco laziale
35	254	232	2	Italy	Teramo		Batilda umbro
36	255	86	2	Italy	Catanzaro		Quarto Costanza calabro
37	256	255	2	Italy	Vibo Valentia		Borgo Piergiorgio lido
38	257	238	2	Italy	Pesaro e Urbino		San Artemisa sardo
39	258	160	2	Italy	Monza e della Brianza		Settimo Fosco
40	259	27	2	Italy	Rieti		Macario terme
41	260	20	2	Italy	Cuneo		Fiorentino a mare
42	261	167	2	Italy	Macerata		Motta sardo
43	262	166	2	Italy	Asti		Colella sardo
44	263	170	2	Italy	Reggio Calabria		Settimo Milena
45	264	26	2	Italy	Sassari		Colonna sardo
46	265	217	2	Italy	Pordenone		San Everardo
47	266	294	2	Italy	Viterbo		Sesto Eugenia
48	267	179	2	Italy	Treviso		Sesto Azeglio
49	268	34	2	Italy	Brindisi		Settimo Cleo
50	269	111	2	Italy	Ancona		Sardina salentino
51	270	253	2	Italy	Genova		Di Maria salentino
52	271	11	2	Italy	Lucca		Mollica ligure
53	272	170	2	Italy	Chieti		San Bruto
54	273	8	2	Italy	Ancona		Maffeo ligure
55	274	214	2	Italy	Alessandria		Erenia calabro
56	275	72	2	Italy	Napoli		Borgo Ambrogio salentino
57	276	133	2	Italy	Modena		Borgo Emidio
58	277	136	2	Italy	Palermo		Sesto Claudio
59	278	240	2	Italy	Frosinone		Sesto Umberto umbro
60	279	230	2	Italy	Trapani		Sesto Cleopatra
61	280	282	2	Italy	Taranto		Sesto Morgana
62	281	31	2	Italy	Pesaro e Urbino		Tanzi ligure
63	282	132	2	Italy	Palermo		Quarto Adalberto del friuli
64	283	198	2	Italy	Sassari		Settimo Ischirione veneto
65	284	244	2	Italy	Ravenna		San Proserpina
66	285	94	2	Italy	Sondrio		Mirabella calabro
67	286	217	2	Italy	Arezzo		Palombi terme
68	287	243	2	Italy	Pavia		Sesto Griselda terme
69	288	50	2	Italy	Varese		San Temistocle salentino
70	289	15	2	Italy	Piacenza		Luciano a mare
71	290	290	2	Italy	Vibo Valentia		Adelaide veneto
72	291	224	2	Italy	Lucca		Carrieri a mare
73	292	162	2	Italy	Salerno		Quarto Zarina
74	293	70	2	Italy	Rovigo		Borgo Amando
75	294	253	2	Italy	Crotone		Surano terme
76	295	283	2	Italy	Nuoro		Borgo Antonella lido
77	296	27	2	Italy	Vibo Valentia		Quarto Speranzio nell'emilia
78	297	241	2	Italy	Latina		San Pardo
79	298	266	2	Italy	Trapani		Quarto Giadero lido
80	299	25	2	Italy	Livorno		Calò lido
81	300	223	2	Italy	Brescia		Sesto Gianmaria a mare
82	301	161	2	Italy	Asti		Teodoto lido
83	302	78	2	Italy	Savona		Borgo Abibo lido
84	303	252	2	Italy	Cremona		Oreste a mare
85	304	116	2	Italy	Enna		Di Tommaso terme
86	305	207	2	Italy	Torino		San Beatrice salentino
87	306	293	2	Italy	Enna		Farella laziale
88	307	109	2	Italy	Enna		San Ivo
89	308	82	2	Italy	Nuoro		Quarto Crescenzia del friuli
90	309	183	2	Italy	Foggia		San Desiderato veneto
91	310	270	2	Italy	Novara		Petrucci veneto
92	311	36	2	Italy	Ascoli Piceno		Oreste lido
93	312	185	2	Italy	Reggio Calabria		Santo nell'emilia
94	313	97	2	Italy	Cremona		Barsaba lido
95	314	85	2	Italy	Oristano		Lorenza terme
96	315	122	2	Italy	Potenza		Baiocco sardo
97	316	190	2	Italy	Verona		Quarto Teodoto laziale
98	317	55	2	Italy	Chieti		Sesto Ermenegilda laziale
99	318	276	2	Italy	Alessandria		Sesto Giosu�
100	319	133	2	Italy	Genova		Puca terme
101	320	283	2	Italy	Nuoro		Roma
102	321	113	2	Italy	Reggio Emilia		Telemaco nell'emilia
103	322	200	2	Italy	Reggio Calabria		Carminati a mare
104	323	118	2	Italy	Chieti		Signorile nell'emilia
105	324	281	2	Italy	Treviso		Quarto Dionisia
106	325	56	2	Italy	Aosta		Quarto Flaviana calabro
107	326	155	2	Italy	Messina		Vittore calabro
108	327	52	2	Italy	Belluno		Giusto veneto
109	328	270	2	Italy	Cuneo		Borgo Geminiano nell'emilia
110	329	55	2	Italy	Reggio Calabria		Settimo Candido ligure
111	330	242	2	Italy	Vercelli		Doronzo ligure
112	331	292	2	Italy	Trieste		Falzone calabro
113	332	250	2	Italy	Aosta		Borgo Serafina laziale
114	333	157	2	Italy	Firenze		Quarto Luigi
115	334	137	2	Italy	Milano		Ippolito del friuli
116	335	265	2	Italy	Novara		Borgo Violante umbro
117	336	180	2	Italy	Trapani		Masala terme
118	337	35	2	Italy	Napoli		Izzi del friuli
119	338	74	2	Italy	Biella		Borgo Marisa
120	339	50	2	Italy	Foggia		Settimo Argo
121	340	208	2	Italy	Pistoia		Cattaneo laziale
122	341	254	2	Italy	L'Aquila		Settimo Silvio sardo
123	342	256	2	Italy	Taranto		Termine a mare
124	343	282	2	Italy	Barletta-Andria-Trani		Valerico veneto
125	344	132	2	Italy	Verona		Quarto Genesio
126	345	278	2	Italy	Mantova		Settimo Siria
127	346	1	2	Italy	Belluno		La Monaca umbro
128	347	131	2	Italy	Sassari		Quarto Rosita
129	348	78	2	Italy	Piacenza		Albina calabro
130	349	1	2	Italy	Verbano-Cusio-Ossola		Sesto Fabio
131	350	1	2	Italy	Brescia		Tamara del friuli
132	351	271	2	Italy	Savona		Vladimiro laziale
133	352	245	2	Italy	Firenze		San Giobbe
134	353	49	2	Italy	Pordenone		Quarto Tiziana umbro
135	354	170	2	Italy	Avellino		Settimo Ilda
136	355	30	2	Italy	Taranto		Sesto Appia ligure
137	356	1	2	Italy	Belluno		Mulè a mare
138	357	1	2	Italy	Imperia		Doroteo ligure
139	358	90	2	Italy	Crotone		Indelicato sardo
140	359	1	2	Italy	Massa-Carrara		Giadero a mare
141	360	209	2	Italy	Asti		Corinna a mare
142	361	35	2	Italy	Lecce		Pisu ligure
143	362	174	2	Italy	Chieti		Quarto Agnese
144	363	178	2	Italy	Milano		Cataldo veneto
145	364	266	2	Italy	Bari		Sesto Carlo terme
146	365	128	2	Italy	Caserta		Cammarata laziale
147	366	125	2	Italy	Carbonia-Iglesias		Adelchi veneto
148	367	102	2	Italy	Roma		Quarto Tarquinia umbro
149	368	278	2	Italy	Pesaro e Urbino		Paola lido
150	369	172	2	Italy	Livorno		Calpurnia umbro
151	370	281	2	Italy	Verona		San Volfango laziale
152	371	29	2	Italy	Bolzano		Sesto Taziana
153	372	207	2	Italy	Rimini		Di Somma laziale
154	373	210	2	Italy	Ferrara		San Ione calabro
155	374	189	2	Italy	Siracusa		Edgardo sardo
156	375	82	2	Italy	Brindisi		Di Giuseppe a mare
157	376	103	2	Italy	Benevento		Sesto Odidone
158	377	164	2	Italy	Verbano-Cusio-Ossola		Borgo Mirella lido
159	378	225	2	Italy	La Spezia		Miranda salentino
160	379	235	2	Italy	Terni		Borgo Verulo
161	380	105	2	Italy	Siena		Grange del friuli
162	381	204	2	Italy	Udine		Severino lido
163	382	119	2	Italy	Venezia		San Savina
164	383	208	2	Italy	Viterbo		Sesto Cleopatra del friuli
165	384	263	2	Italy	Isernia		Borgo Carla salentino
166	385	30	2	Italy	Grosseto		Settimo Afro
167	386	135	2	Italy	Catanzaro		San Garimberto
168	387	288	2	Italy	Bologna		San Liberto sardo
169	388	49	2	Italy	Pavia		Castellana lido
170	389	222	2	Italy	Parma		Benigna nell'emilia
171	390	149	2	Italy	Cuneo		Borgo Michele
172	391	256	2	Italy	Vibo Valentia		Righi ligure
173	392	211	2	Italy	Cuneo		San Aristo del friuli
174	393	174	2	Italy	Parma		Barbieri umbro
175	394	300	2	Italy	Prato		Conti calabro
176	395	255	2	Italy	Milano		Rondoni terme
177	396	227	2	Italy	Cuneo		Leonardi terme
178	397	110	2	Italy	Brescia		Cerullo umbro
179	398	182	2	Italy	Reggio Emilia		San Oriana
180	399	161	2	Italy	Nuoro		Borgo Erico
181	400	52	2	Italy	Taranto		Violi a mare
182	401	27	2	Italy	Pavia		Settimo Melissa
183	402	6	2	Italy	Ascoli Piceno		Lo Piccolo del friuli
184	403	148	2	Italy	Caltanissetta		Lendinara
185	404	158	2	Italy	Ravenna		San Lanfranco umbro
186	405	171	2	Italy	L'Aquila		Napoli
187	406	256	2	Italy	Pisa		San Gigliola a mare
188	407	73	2	Italy	Verona		Liliana lido
189	408	221	2	Italy	Rieti		San Massimiliano
190	409	150	2	Italy	Torino		Zambuto del friuli
191	410	291	2	Italy	Torino		Quarto Divo
192	411	32	2	Italy	Vercelli		San Alina a mare
193	412	204	2	Italy	Pesaro e Urbino		San Guendalina
194	413	270	2	Italy	Prato		Settimo Maffeo
195	414	206	2	Italy	Foggia		Remondo calabro
196	415	173	2	Italy	Como		San Bindo
197	416	102	2	Italy	Caltanissetta		Eliano calabro
198	417	276	2	Italy	Lucca		Nicotra a mare
199	418	273	2	Italy	Messina		Sesto Moreno
200	419	250	2	Italy	Brescia		Laezza del friuli
201	420	63	2	Italy	Nuoro		Indelicato umbro
202	421	237	2	Italy	Cagliari		Genesio calabro
203	422	410	2	Italy	Ancona		La Malfa del friuli
204	423	297	2	Italy	Trapani		Settimo Quirino del friuli
205	424	62	2	Italy	Novara		Borgo Sidonio ligure
206	425	281	2	Italy	Belluno		Pircher ligure
207	426	234	2	Italy	Terni		Cavallini lido
208	427	207	2	Italy	Grosseto		Borgo Iorio calabro
209	428	84	2	Italy	Olbia-Tempio		Sesto Fedora
210	429	103	2	Italy	Ogliastra		Quarto Valtena
211	430	158	2	Italy	Varese		Guerriero umbro
212	431	81	2	Italy	Ravenna		Quarto Dionisio
213	432	9	2	Italy	Terni		Bertoldo umbro
214	433	179	2	Italy	Ascoli Piceno		Tassi salentino
215	434	117	2	Italy	Novara		Neri laziale
216	435	172	2	Italy	Lucca		Quarto Eros lido
217	436	166	2	Italy	Siracusa		San Albano
218	437	109	2	Italy	Cosenza		Mazzone a mare
219	438	100	2	Italy	Agrigento		Settimo Telemaco
220	439	295	2	Italy	Ferrara		Borgo Beronico
221	440	90	2	Italy	La Spezia		Sesto Clodomiro ligure
222	441	3	2	Italy	Cagliari		Gesualdo del friuli
223	442	52	2	Italy	Vibo Valentia		Borgo Galatea terme
224	443	158	2	Italy	Mantova		Valerico terme
225	444	106	2	Italy	Macerata		Sesto Caronte umbro
226	445	130	2	Italy	Barletta-Andria-Trani		Falchi sardo
227	446	271	2	Italy	Pistoia		Oronzo veneto
228	447	147	2	Italy	Lecco		Lombardo ligure
229	448	280	2	Italy	Messina		Arena sardo
230	449	80	2	Italy	Chieti		Quarto Minerva terme
231	450	288	2	Italy	Reggio Emilia		Egidio veneto
232	451	146	2	Italy	Roma		Borgo Icilio
233	452	55	2	Italy	Firenze		Amadeo umbro
234	453	53	2	Italy	Parma		Domenico lido
235	454	154	2	Italy	Venezia		Agape terme
236	455	291	2	Italy	Pordenone		Poletti del friuli
237	456	123	2	Italy	Arezzo		Quarto Menelao ligure
238	457	173	2	Italy	Treviso		San Gentile veneto
239	458	250	2	Italy	Medio Campidano		Cino salentino
240	459	246	2	Italy	Cuneo		D'Avino calabro
241	460	72	2	Italy	Messina		Quarto Camillo a mare
242	461	290	2	Italy	Rieti		Benigna sardo
243	462	94	2	Italy	Macerata		Di Michele laziale
244	463	135	2	Italy	Brescia		Borgo Eufronio del friuli
245	464	74	2	Italy	Biella		Caiazzo nell'emilia
246	465	124	2	Italy	Torino		Settimo Graziella a mare
247	466	238	2	Italy	Arezzo		Quarto Eugenio
248	467	55	2	Italy	Macerata		Archimede salentino
249	468	211	2	Italy	Potenza		San Bonifacio umbro
250	469	9	2	Italy	Savona		Didimo sardo
251	470	162	2	Italy	Prato		Borgo Saul lido
252	471	236	2	Italy	Foggia		Ezio laziale
253	472	27	2	Italy	Olbia-Tempio		Perini ligure
254	473	183	2	Italy	Cosenza		San Noemi
255	474	32	2	Italy	Reggio Emilia		Quarto Emiliano
256	475	155	2	Italy	Como		Lidio umbro
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address, altitude) FROM stdin;
1	0	0101000020E610000043D95E8288A91C40720950EB278D4640	Start Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
2	0	0101000020E610000051A7B8816D921C408D966B20C98C4640	End Point	Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia	\N
3	0	0101000020E6100000C668CC0D4EA81C40DA8DB03B2C8D4640		Ref Point 1	1256.85
4	0	0101000020E6100000116FE90D01A21C4022DFF1622B8D4640		Ref Point 2	1283.61
5	0	0101000020E61000004337FB03E5161B401CEBE2361A844640	Start Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
6	0	0101000020E61000001092054CE0161B401FD8F15F20844640	End Point	San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia	\N
7	0	0101000020E6100000910F7A36ABCE1C4029AF95D05D4C4640	Start Point	Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia	\N
8	0	0101000020E6100000FC8EE1B19FB51C40B0FECF61BE4E4640	End Point	Sorgente PIca, U3, Sampeyre, Cuneo, Piemonte, Italia	\N
9	0	0101000020E6100000000060A24D751C40000028D7DB594640	Start Point	Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia	\N
10	0	0101000020E61000000000A08E3B6A1C400000D8486C5C4640	End Point	Fonte Malt di Viso, Via Pian del Re, Pian del Re, Crissolo, Cuneo, Piemonte, Italia	\N
11	0	0101000020E6100000D218ADA3AA112140B7291E17D5124740	Start Point	Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia	\N
12	0	0101000020E61000001764CBF2751121406AFAEC80EB144740	End Point	Villette, Verbano-Cusio-Ossola, Piemonte, 28856, Italia	\N
13	0	0101000020E610000000004078111A1C400000981E08854640	Start Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
14	0	0101000020E61000000000A0281F1A1C400000E05411854640	End Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
15	0	0101000020E610000000004078111A1C400000981E08854640	Start Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
16	0	0101000020E61000000000A0281F1A1C400000E05411854640	End Point	Laux, Usseaux, Torino, Piemonte, Italia	\N
17	0	0101000020E610000058CB9D9960C81B408731E9EFA59C4640	Start Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
18	0	0101000020E61000003BE0BA6246C81B401E34BBEEAD9C4640	End Point	Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia	\N
19	0	0101000020E61000007EE4D6A4DBC21B40147AFD497C9C4640		fountain	2027.00
20	0	0101000020E6100000B7B8C667B2BF1B4090A4A487A19B4640		Peak	2131.00
21	0	0101000020E6100000E449D23593FF1A4008B0C8AF1F784640	Start Point	Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia	\N
22	0	0101000020E6100000E449D23593FF1A4008B0C8AF1F784640	End Point	Claviere tourist information, Via Nazionale, Claviere, Torino, Piemonte, Italia	\N
23	0	0101000020E6100000010060133FE51C400000DC629AA64640	Start Point	Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia	\N
24	0	0101000020E61000000100E07E80F41C400000C0086CA54640	End Point	Alpe del Lago, Balme, Unione Montana di Comuni delle Valli di Lanzo, Ceronda e Casternone, Torino, Piemonte, Italia	\N
25	0	0101000020E61000000000A0E235A31C40000090BAAD5A4640	Start Point	Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia	\N
26	0	0101000020E61000000000A03601A21C40000078DBA45A4640	End Point	Strada Comunale Frazione Ciampagna, Bertolini, Crissolo, Cuneo, Piemonte, Italia	\N
27	0	0101000020E61000000000601346EE1B4000006C0D81494640	Start Point	SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia	\N
28	0	0101000020E6100000000000063BEE1B4000001C7B81494640	End Point	SP256, Grange Culet, Bellino, Cuneo, Piemonte, Italia	\N
29	0	0101000020E6100000000020F7999B1C40000018F79E594640	Start Point	Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
30	0	0101000020E61000000000803E6C7C1C400000004B28584640	End Point	Ghincia Pastour, Sentiero della salute, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
31	0	0101000020E610000001002004C9F31E400000609288234640	Start Point	Pigna - Gardiola, Chiusa di Pesio, Cuneo, Piemonte, 12088, Italia	\N
32	0	0101000020E6100000000000DC44CF1E400000B4502D214640	End Point		\N
33	0	0101000020E61000002F3196E997781C408F8D40BCAE594640	Start Point	Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
34	0	0101000020E61000009C8A54185B781C4057B08D78B2594640	End Point	Piazzale Pian della Regina, Pian Regina, Pian della Regina, Crissolo, Cuneo, Piemonte, Italia	\N
35	0	0101000020E61000000000209E8E4B1C4000003C6BAE844640	Start Point	Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia	\N
36	0	0101000020E6100000000080AFFC7A1C4000004CCD1C864640	End Point	Rifugio Selleries, Sentiero Agostino Benedetto, Grange Sors, Roure, Torino, Piemonte, Italia	\N
37	0	0101000020E6100000000000A020B91C40000074E3C0494640	Start Point	Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia	\N
38	0	0101000020E61000000000C0CE5A9F1C400000B06F46474640	End Point	Meira Garneri, Colle Sampeyre - Sampeyre, Sampeyre, Cuneo, Piemonte, Italia	\N
39	0	0101000020E610000000000030C0F21C400000005015934640	Start Point	Alpe Tulivit, Condove, Torino, Piemonte, Italia	\N
40	0	0101000020E61000000000C02BE9E01C400000442ED1964640	End Point	Alpe Tulivit, Condove, Torino, Piemonte, Italia	\N
41	0	0101000020E61000000000E04399051F40000078D59A1F4640	Start Point	Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia	\N
42	0	0101000020E61000000000A0B2D4041F400000A07A911F4640	End Point	Via Ceresole, Artesina, Frabosa Sottana, Cuneo, Piemonte, Italia	\N
43	0	0101000020E610000000002073E0601C4000001C93C2594640	Start Point	Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia	\N
44	0	0101000020E61000000000A01680701C400000C08D37554640	End Point	Rifugio Quintino Sella, Sentiero Ezio Nicoli, Crissolo, Cuneo, Piemonte, Italia	\N
45	0	0101000020E61000000000C09D43D520400000CC2FB7354740	Start Point	Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia	\N
46	0	0101000020E61000000000C09D43D520400000CC2FB7354740	End Point	Itinérando - Via Sbrinz, SS659, Riale, Formazza, Verbano-Cusio-Ossola, Piemonte, 28863, Italia	\N
47	0	0101000020E6100000E4BD6A65C2D720401A506F46CD114740	Start Point	Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia	\N
48	0	0101000020E61000005665DF15C1D72040C6C1A563CE114740	End Point	Sagrogno, Albogno, Druogno, Verbano-Cusio-Ossola, Piemonte, 28857, Italia	\N
49	0	0101000020E61000005F9A22C0E96520406C76A4FACE554640	Start Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
50	0	0101000020E61000002368CC24EA652040CC7EDDE9CE554640	End Point	Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia	\N
51	0	0101000020E61000006B662D05A46D20401557957D57564640		Ref Point 1	482.53
52	0	0101000020E610000024D236FE44652040813D26529A554640		Ref Point 2	242.59
53	0	0101000020E6100000A06F0B96EA221D4008E6E8F17B7B4640	Start Point	Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia	\N
54	0	0101000020E61000006DE7FBA9F1221D40EF552B137E7B4640	End Point	Dairin, San Pietro Val Lemina, Torino, Piemonte, Italia	\N
55	0	0101000020E61000009F02603C83762540D61EF64201F14640	Start Point	Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
56	0	0101000020E610000088F19A5775762540910E0F61FCF04640	End Point	Torrente Massangla, Via Alzer, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
57	0	0101000020E6100000F435CB65A343274097530262122E4640	Start Point	5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia	\N
58	0	0101000020E61000006BD44334BA43274097530262122E4640	End Point	5, Via Calanco, Dozza, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40060, Italia	\N
59	0	0101000020E6100000EAE923F0877F2540EE7C3F355EE04640	Start Point	Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia	\N
60	0	0101000020E610000053CF8250DE7F254040A19E3E02E14640	End Point	Strada Statale 45bis Gardesana Occidentale, Pregasio, Campione del Garda, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, Italia	\N
61	0	0101000020E610000033FE7DC6853B274059349D9D0C264640	Start Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
62	0	0101000020E61000005859DB148F3B2740001DE6CB0B264640	End Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
63	0	0101000020E610000033FE7DC6853B274059349D9D0C264640	Start Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
64	0	0101000020E61000005859DB148F3B2740001DE6CB0B264640	End Point	3, Via Giovanni ventitreesimo, Ceredola, Casalfiumanese, Nuovo Circondario Imolese, Bologna, Emilia-Romagna, 40020, Italia	\N
65	0	0101000020E6100000E82E89B3223A254036CB65A373AC4640	Start Point	Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia	\N
66	0	0101000020E61000008C9DF0129C3A2540486AA16472AC4640	End Point	Via Santi Martiri, Cascina Amadei, Cavriana, Mantova, Lombardia, 46069, Italia	\N
67	0	0101000020E610000088DA368C82402540AC02B5183CAC4640		Ref Point 1	130.12
68	0	0101000020E6100000A06B5F402F44254016C1FF56B2AB4640		Ref Point 2	139.74
69	0	0101000020E6100000527FBDC2824B2540151C5E1091AA4640		Fontain	107.32
70	0	0101000020E61000001C98DC28B2361C4032FFE89B34894640	Start Point	Cima Ciantiplagna, Strada militare del Colle dell'Assietta, Bergerie dell'Assietta, Usseaux, Torino, Piemonte, Italia	\N
71	0	0101000020E6100000EE5C18E9450D1C402FFB75A73B894640	End Point	Cima Ciantiplagna, Strada militare del Colle dell'Assietta, Bergerie dell'Assietta, Usseaux, Torino, Piemonte, Italia	\N
72	0	0101000020E6100000A0DCB6EF518725409E7E501729E44640	Start Point	Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia	\N
73	0	0101000020E610000055DD239BAB86254016342DB132E44640	End Point	Chiesa di San Lorenzo, Via Alessandro Volta, Ustecchio, Tremosine sul Garda, Comunità Montana Parco Alto Garda bresciano, Brescia, Lombardia, 37018, Italia	\N
74	0	0101000020E6100000C3F5285C8FE21F408C9FC6BDF9894640	Start Point	Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia	\N
75	0	0101000020E610000001F8A75489E21F40F030ED9BFB894640	End Point	Piazza Cavalier Serra, Albugnano, Asti, Piemonte, 14022, Italia	\N
76	0	0101000020E6100000B282DF86187F20400B47904AB1FF4640	Start Point	Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia	\N
77	0	0101000020E610000012842BA0508720400F48C2BE9D004740	End Point	Via Giulio Pastore, Santa Maria, Pieve Vergonte, Bannio Anzino, Verbano-Cusio-Ossola, Piemonte, 28885, Italia	\N
78	0	0101000020E6100000EAE8B81AD9E520408813984EEBFA4640	Start Point	Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia	\N
79	0	0101000020E6100000EAE8B81AD9E520408813984EEBFA4640	End Point	Piazza Camillo Benso Conte di Cavour, Bracchio, Mergozzo, Valstrona, Verbano-Cusio-Ossola, Piemonte, 28802, Italia	\N
80	0	0101000020E61000006EFC89CA86A52040D87DC7F0D87D4640	Start Point	Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia	\N
81	0	0101000020E61000009E0B23BDA8A52040B1A371A8DF7D4640	End Point	Poste Italiane, 16, Via Mezzena, Montemagno, Asti, Piemonte, 14030, Italia	\N
82	0	0101000020E61000009F3E027FF83920409E245D33F9804640	Start Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
83	0	0101000020E610000099F56228273A20408DEDB5A0F7804640	End Point	Piazza della Pace, Piazza del Mercato, Montechiaro d'Asti, Asti, Piemonte, 14025, Italia	\N
84	0	0101000020E6100000880E81238136264090847D3B89844640	Start Point	Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia	\N
85	0	0101000020E6100000B6132521913626406AFB57569A844640	End Point	Via Verdi, Corte Bugno, Pieve di Coriano, Borgo Mantovano, Mantova, Lombardia, 46020, Italia	\N
86	0	0101000020E61000007A17EFC7ED37264008C89750C1854640		Ref Point 1	22.75
87	0	0101000020E61000009AB0FD648C4F26405C7171546E844640		Ref Point 2	35.55
88	0	0101000020E61000001899805F23F91C402A38BC20227B4640	Start Point	Pralamar, Pinasca, Torino, Piemonte, 10063, Italia	\N
89	0	0101000020E610000001344A97FEF51C40BB438A01127D4640	End Point	Pralamar, Pinasca, Torino, Piemonte, 10063, Italia	\N
90	0	0101000020E6100000A5660FB402431D4025E82FF488754640	Start Point	Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia	\N
91	0	0101000020E61000008D093197543D1D405E6919A9F7764640	End Point	Madonna della Neve, Via Giuseppe Verdi, Ribetti, Roletto, Torino, Piemonte, 10064, Italia	\N
92	0	0101000020E6100000E14389963C762540E55FCB2BD7F14640	Start Point	Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
93	0	0101000020E6100000C2DF2F664B7625408C14CAC2D7F14640	End Point	Hotel Sport, Via Pier Antonio Cassoni, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
94	0	0101000020E6100000768D96033D14284038BA4A77D7D54540	Start Point	Via Poggiolino delle Viole, Castellare, Pieve Santo Stefano, Arezzo, Toscana, 52036, Italia	\N
95	0	0101000020E610000058E6ADBA0E4D28404546072461D34540	End Point	Bike Help, Pian della Capanna, Pieve Santo Stefano, Arezzo, Toscana, Italia	\N
96	0	0101000020E6100000C1CAA145B60320407715527E52B94640	Start Point	26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia	\N
97	0	0101000020E6100000A4C2D84290032040E8BCC62E51B94640	End Point	26, Via Giovanni Flecchia, Piverone, Torino, Piemonte, 10010, Italia	\N
98	0	0101000020E61000003B54539275B82840BF7D1D3867164740	Start Point	Municipio, Via Roma, Torres, Tignes, Pieve d'Alpago, Alpago, Belluno, Veneto, 32010, Italia	\N
99	0	0101000020E6100000D6C8AEB48CB42840F51263997E154740	End Point	Municipio, Via Roma, Torres, Tignes, Pieve d'Alpago, Alpago, Belluno, Veneto, 32010, Italia	\N
100	0	0101000020E61000009296CADB11862840B91803EB383C4740	Start Point	Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia	\N
101	0	0101000020E6100000F94D61A582BA28401363997E89364740	End Point	Via Regia, Tai di Cadore, Pieve di Cadore, Belluno, Veneto, 32040, Italia	\N
102	0	0101000020E6100000B0389CF9D5B4254010E9B7AF03F14640	Start Point	Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
170	0	0101000020E610000052E2299ABDFA2840518B1C7D27114740	Rifugio Semenza	Tambre, Veneto, Italy	\N
103	0	0101000020E61000009414580053762540A04FE449D2F14640	End Point	Parcheggio Pieve, Via Capitan Rabaglia, Pieve di Ledro, Ledro, Comunità Alto Garda e Ledro, Provincia di Trento, Trentino-Alto Adige, 38067, Italia	\N
104	0	0101000020E6100000B0389CF9D5B4254010E9B7AF03F14640		Peak	67.09
105	0	0101000020E6100000A9C0C936708725400936AE7FD7EF4640		Lake	712.07
106	0	0101000020E6100000D576137CD3742640A9BF5E61C1A34540	Start Point	4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia	\N
107	0	0101000020E61000001A19E42EC274264009FCE1E7BFA34540	End Point	4, Via delle Fonti, La Compagnia, Sovicille, Siena, Toscana, 53018, Italia	\N
108	0	0101000020E61000003D98141F9F201C409A5FCD01827B4640	Start Point	Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia	\N
109	0	0101000020E6100000CC7A319413FD1B40BD361B2B317D4640	End Point	Sentiero Bergerie Valloncrò-Monte Pelvo, Bergerie di Valloncrò, Massello, Torino, Piemonte, Italia	\N
110	0	0101000020E61000003BE466B801472840A2427573F12B4640	Start Point	Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia	\N
111	0	0101000020E610000029CFBC1C76472840EA3F6B7EFC2B4640	End Point	Via Argine desto Ronco, Ghibullo, Longana, Ravenna, Emilia-Romagna, 48124, Italia	\N
112	0	0101000020E61000002D64979723B62440C66F2527958D4740	Edmund-Graf-Hütte	6574 Pettneu am Arlberg, Tyrol, Austria	\N
113	0	0101000020E6100000455BF9D0380E2A4056DBD4F478794740	Dr.Hernaus-Stöckl	9020 Klagenfurt, Kärnten, Austria	\N
114	0	0101000020E61000003AD4CD22968A2D406DAF4FF575F14740	Amstettner Hütte	3340 Waidhofen an der Ybbs, Niederösterreich, Austria	\N
115	0	0101000020E61000003470C88518362B404F23C0A11DEA4740	Hochleckenhaus	4853 Steinbach am Attersee, Oberösterreich, Austria	\N
116	0	0101000020E6100000745CA7EA5C3230400E95C9F10B114840	Kampthalerhütte	2384 Breitenfurt bei Wien, Niederösterreich, Austria	\N
117	0	0101000020E610000059E5350827672B402FB2862AC2D34740	Lambacher Hütte	4822 Bad Goisern, Oberösterreich, Austria	\N
118	0	0101000020E610000019FDD2643FA62340662869A087B24740	Lustenauer Hütte	6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria	\N
119	0	0101000020E610000036849931B0F52A4014BD78F039C44740	Gablonzer Hütte	4825 Gosau-Hintertal, Oberösterreich, Austria	\N
120	0	0101000020E6100000202F5A3629BF3740D489BAC5B2144340	Katafygio «Flampouri»	136 72 Acharnes, Attica region, Greece	\N
121	0	0101000020E6100000103E4BA24D3F2B40F731169C1AC04740	Simonyhütte	4830 Hallstatt, Oberösterreich, Austria	\N
122	0	0101000020E610000033190145D5182740BF9048EBDFA04740	Vinzenz-Tollinger-Hütte	6060 Hall in Tirol, Tyrol, Austria	\N
123	0	0101000020E61000001F1E0B5901B82E4091BFCBF1EAB34740	Ottokar-Kernstock-Haus	8600 Bruck an der Mur, Steiermark, Austria	\N
124	0	0101000020E610000018E4FB977DBF2A40D6A3B4422D754740	Reisseckhütte	9814 Mühldorf, Mölltal, Kärnten, Austria	\N
125	0	0101000020E61000007B116DC7D4A52540C0401020436D4740	Vernagthütte	Austria	\N
126	0	0101000020E6100000286211C30EF323407EC9C6832D884740	Wormser Hütte	Austria	\N
127	0	0101000020E6100000999CDA19A60E24406CD097DEFEA04740	Biberacher Hütte	Austria	\N
128	0	0101000020E610000007BC276AC4133740DDF934DDA1A84440	Katafygio «1777»	620 55 Kerkini, Central Macedonia region, Greece	\N
129	0	0101000020E6100000D5AF743E3C0B2A40E6E786A6EC704840	Hochwaldhütte	Germany	\N
130	0	0101000020E6100000C2FBAA5CA8EC19408FC536A968544940	Kölner Eifelhütte	Germany	\N
131	0	0101000020E6100000323CF6B358D223401763601DC7794740	Madrisahütte	Austria	\N
132	0	0101000020E6100000313F373465472640CDC98B4CC07F4740	Dresdner Hütte	Austria	\N
133	0	0101000020E6100000CDCCCCCCCC6C24403E07962364A84740	Fiderepasshütte	Germany	\N
134	0	0101000020E6100000B727486C77172440A9DDAF027C9B4740	Göppinger Hütte	Austria	\N
135	0	0101000020E6100000A379008BFC622340C7629B54348A4740	Oberzalimhütte	Austria	\N
136	0	0101000020E610000013B70A62A0932740B3B45373B99D4740	Rastkogelhütte	Austria	\N
137	0	0101000020E61000009D2D20B41E0E2440D54F49E70DC24740	Ansbacher Skihütte im Allgäu	Germany	\N
138	0	0101000020E610000009E066F16249244097E13FDD408F4740	Kaltenberghütte	Austria	\N
139	0	0101000020E61000000AD7A3703D0A2640E277D32D3B944740	Schweinfurter Hütte	Austria	\N
140	0	0101000020E61000006DC438245A213640DA172BC5E9574340	Katafygio «Vardousion»	330 53 Delphi, Central Greece region, Greece	\N
141	0	0101000020E6100000630F270F8F472D40336D62F5852D4740	Kocbekov dom na Korošici	3334 Luče, Mozirje, Slovenia	\N
142	0	0101000020E6100000D1F5D08072062D40D25C9F20CE114740	Planinski dom Rašiške cete na Rašici	1211 Ljubljana, Šmartno, Slovenia	\N
143	0	0101000020E6100000F70F966F85592C40971550C935374740	Prešernova koca na Stolu	4274 Žirovnica, Slovenia	\N
144	0	0101000020E6100000AA5C8F5FCB372E408E6CD71919184740	Planinski dom na Mrzlici	3302 Griže, Slovenia	\N
145	0	0101000020E6100000651A4D2EC6802C40577A6D3656FC4640	Koca na Planini nad Vrhniko	1360 Vrhnika, Slovenia	\N
146	0	0101000020E6100000245DF94DDD322C4077DAB7E6D0144740	Zavetišce gorske straže na Jelencih	0, -, Slovenia	\N
147	0	0101000020E6100000313F3734656F2E406F7F2E1A32264740	Planinski dom na Gori	Šentjungert, 3310 Žalec, Slovenia	\N
148	0	0101000020E610000098F2E7FC90A22B40C7CBA2C928274740	Bregarjevo zavetišce na planini Viševnik	4265 Bohinjsko jezero, Slovenia	\N
149	0	0101000020E610000091860959CC862B401635F33FD4244740	Koca pod Bogatinom	4265 Bohinjsko jezero, Slovenia	\N
150	0	0101000020E6100000678B3942E5992B40007F639573334740	Pogacnikov dom na Kriških podih	5232 Soca, Slovenia	\N
151	0	0101000020E610000008F580BBE4CC2D402A9C0F95E7344740	Dom na Smrekovcu	3325 Šoštanj, Slovenia	\N
152	0	0101000020E610000073F6CE68AB32194060E811A3E77C4640	Refuge Du Chatelleret	38520 Saint Christophe En Oisans, Isère, France	\N
153	0	0101000020E610000084622B685AF218408177F2E9B16B4640	Refuge De Chalance	5800 La Chapelle En Valgaudemar, Hautes-Alpes, France	\N
154	0	0101000020E6100000963D096CCE711940AE7FD767CE6A4640	Refuge Des Bans	5290 Vallouise, Hautes-Alpes, France	\N
155	0	0101000020E6100000DEAB5626FC52DBBFAED689CBF16A4540	Refuge De Pombie	65400 Laruns, Pyrénées-Atlantiques, France	\N
156	0	0101000020E6100000A69C2FF65E7CD2BFA9F92AF9D86D4540	Refuge De Larribet	65400 Arrens, Marsous, Hautes-Pyrénées, France	\N
157	0	0101000020E61000009CA6CF0EB84E1B401232906797C34640	Refuge Du Mont Pourri	73210 Peisey Nancroix, Savoie, France	\N
158	0	0101000020E6100000C712D6C6D8E91A40BF81C98D222D4740	Refuge De La Dent D?Oche	74500 Bernex, Haute-Savoie, France	\N
159	0	0101000020E6100000BEBDCA2243F820405620D41E27544740	Bergseehütte SAC	Uri, Switzerland	\N
160	0	0101000020E6100000CDD5732CA96D1E40F591820D5C054740	Bivouac au Col de la Dent Blanche CAS	Wallis, Switzerland	\N
161	0	0101000020E610000060F1FE571F0C2140D6BA5B328C564740	Salbitschijenbiwak SAC	Uri, Switzerland	\N
162	0	0101000020E610000084EAC5BE53052140F224048A5C664740	Spannorthütte SAC	Uri, Switzerland	\N
163	0	0101000020E6100000827FB24EBCB71E406113E452EB0C4740	Cabane Arpitettaz CAS	Wallis, Switzerland	\N
164	0	0101000020E61000008A75AA7CCF48E4BF588BF447BD614540	Refugio De Lizara	22730, Aragón, Spain	\N
165	0	0101000020E6100000AE56C01909F8E43F58DB5E1CA6064540	Albergue De Montfalcó	22585 Tolva, Aragón, Spain	\N
166	0	0101000020E61000000A4CFFBF1E610AC08B780953B6904240	El Molonillo/Peña Partida	18160 Güejar Sierra, Andalucía, Spain	\N
167	0	0101000020E610000029110100A92D0AC0F39F054F27844240	La Campiñuela	18417 Trévelez, Andalucía, Spain	\N
168	0	0101000020E61000008E79782A3BCC3440BEAE152301FF4440	Titov Vrv	Tetovo, Municipality of Tetovo, North Macedonia	\N
169	0	0101000020E6100000A2EC2DE57C212B40C7F143A5113D4540	Rifugio Franchetti	Pietracamela, Abruzzo, Italy	\N
171	0	0101000020E6100000A197F67244A31F40313D06D094EE4640	Rifugio Città di Mortara 	Alagna Valsesia, Piemonte, Italy	\N
172	0	0101000020E61000006E39F29B1D242040AB1ED555260C4740	Rifugio Andolla	Antrona Schieranico, Piemonte, Italy	\N
173	0	0101000020E61000000AD80E46ECAB2440B70BCD751AFF4540	Rifugio Forte dei Marmi	Stazzema, Toscana, Italy	\N
174	0	0101000020E6100000A88B14CAC2CF284038D66AB4C1504740	Rifugio Berti	Comelico Superiore, Veneto, Italy	\N
175	0	0101000020E610000071B43E4052BB2B406FE70CD649CF4640	Rifugio Premuda	San Dorligo della Valle, Friuli Venezia Giulia, Italy	\N
176	0	0101000020E61000006CCF2C0950C32240191BBAD91FF84640	Rifugio Elisa	Mandello del Lario, Lombardia, Italy	\N
177	0	0101000020E6100000A5BDC11726B31F40F90FE9B7AFFB4640	Rifugio CAI Saronno	Macugnaga, Piemonte, Italy	\N
178	0	0101000020E610000098DD9387857A2640A930B610E4584740	Rifugio Picco Ivigna	Scena, Trentino Alto Adige, Italy	\N
179	0	0101000020E61000003AE97DE36B8F1C404AEF1B5F7B8A4640	Rifugio Toesca	Bussoleno, Piemonte, Italy	\N
180	0	0101000020E6100000A913D044D8E02040382D78D1570C4740	Rifugio Al Cedo	Santa Maria Maggiore, Piemonte, Italy	\N
181	0	0101000020E6100000449D5ECE11661F4009ED8B3A29F34640	Capanna Gnifetti	Gressoney La Trinitè, Valle d?Aosta, Italy	\N
182	0	0101000020E6100000B8AE9811DE3E1E403A048E041AFC4640	Rifugio Aosta	Bionaz, Valle d?Aosta, Italy	\N
183	0	0101000020E6100000BBB31B22135525408EA8F523EA374740	Rifugio Cevedale	Pejo, Trentino Alto Adige, Italy	\N
184	0	0101000020E61000000D33349E08722340F0A485CB2A204740	Rifugio Ponti	Val Masino, Lombardia, Italy	\N
185	0	0101000020E6100000C46D7E0DD2B125405364085B47134740	Rifugio XII Apostoli	Stenico, Trentino Alto Adige, Italy	\N
186	0	0101000020E61000009F1C058882591B40DDD1FF722DE24640	Rifugio Elisabetta Soldini	Courmayeur, Valle d?Aosta, Italy	\N
187	0	0101000020E610000061D57994804F25409903A4C1291F4740	Rifugio Denza	Vermiglio, Trentino Alto Adige, Italy	\N
188	0	0101000020E61000000C1F115322F92A40338AE596560F4540	Rifugio Fonte Tavoloni 	Ovindoli, Abruzzo, Italy	\N
189	0	0101000020E610000037C2A2224EBF2840F2ED5D83BE4E4740	Rifugio Carducci	Auronzo di Cadore, Veneto, Italy	\N
190	0	0101000020E61000006FA53220D64E26400DE02D90A0044740	Rifugio Bindesi	Trento, Trentino Alto Adige, Italy	\N
191	0	0101000020E610000001C11C3D7ECB2D40C670D0B9365A4640	Mountain hut Miroslav Hirtz	53287 Jablanac, Ličko-senjska županija, Croatia	\N
192	0	0101000020E6100000398485EEED352C4098331D324C154740	Koca na Blegošu	4224 Gorenja vas, Slovenia	\N
193	0	0101000020E610000040F850A225BF1F400F441669E2594940	Wittener Hütte	Germany	\N
194	0	0101000020E610000000FDBE7FF3AA25409A99999999694740	Hochjoch-Hospiz	Austria	\N
195	0	0101000020E6100000D7A02FBDFD412640CDCCCCCCCCB44740	Meilerhütte	Germany	\N
196	0	0101000020E610000050C422861DA628406E85B01A4BC64740	Gaudeamushütte	Austria	\N
197	0	0101000020E6100000179CC1DF2F961940D5EB1681B15C4940	Rheydter Hütte	Germany	\N
198	0	0101000020E6100000FB66518EB8562C4057E883656C744940	Sektionshütte Krippen	Germany	\N
199	0	0101000020E61000001F7A839D234C2C40B45EF68814A34740	Neunkirchner Hütte	2620 Neunkirchen, Steiermark, Austria	\N
200	0	0101000020E61000009CE379FC2043E7BF8FC536A9682C4540	Refugio De Riglos	22808, Aragón, Spain	\N
201	0	0101000020E6100000563D4FC4941A2140EBB308E997564740	Salbithütte SAC	Uri, Switzerland	\N
202	0	0101000020E61000001D55C855B23A2040B8EB64DCCE424740	Finsteraarhornhütte SAC	Wallis, Switzerland	\N
203	0	0101000020E6100000DEFD765E1AE71D4038777A52B2FE4640	Cabane des Vignettes CAS	Wallis, Switzerland	\N
204	0	0101000020E6100000E769EE0B84312040FBE19FAF02504740	Glecksteinhütte SAC	Bern, Switzerland	\N
205	0	0101000020E6100000752B5D3C5F152240D9971BDB51454740	Länta-Hütte SAC	Graubünden, Switzerland	\N
206	0	0101000020E610000055ADDEFA26292040BAB9F14860214740	Monte-Leone-Hütte SAC	Wallis, Switzerland	\N
207	0	0101000020E6100000557F0CE8F9C222408F373B25D26E4740	Ringelspitzhütte SAC	Graubünden, Switzerland	\N
208	0	0101000020E6100000A4AA09A2EE0334408E23D6E253104640	Na poljanama Maljen	Maljen, Serbia	\N
209	0	0101000020E6100000A9DE1AD82A313440C5E6E3DA50114640	Dobra voda	Suvobor, Serbia	\N
210	0	0101000020E61000007250C24CDBFF2E402D095053CBC64640	Ivanova hiža	Karlovac town environment, Karlovačka, Croatia	\N
211	0	0101000020E6100000C6DCB5847CC02F40C746205ED7EB4640	Glavica	Medvednica, City of Zagreb, Croatia	\N
212	0	0101000020E6100000FFEC478AC8B83040D3F6AFAC34BD4540	Trpošnjik	Mosor, Splitsko-dalmatinska, Croatia	\N
213	0	0101000020E6100000C217265305932D40C4CE143AAFA54640	Bitorajka	Bitoraj, Primorsko-goranska, Croatia	\N
214	0	0101000020E6100000AB09A2EE0360304006D847A7AE084640	Zlatko Prgin	Dinara, Šibensko-kninska, Croatia	\N
215	0	0101000020E6100000D3872EA86F492E405C8FC2F528444640	Prpa	Velebit, Ličko-senjska, Croatia	\N
216	0	0101000020E6100000787FBC57AD5C2E408BFD65F7E43D4640	Ždrilo	Velebit, Ličko-senjska, Croatia	\N
217	0	0101000020E610000086032159C0F42D40B21188D7F59B4640	Miroslav Hirtz	Velika Kapela, Primorsko-goranska, Croatia	\N
218	0	0101000020E6100000A31EA2D11DAC3140462575029AC04640	Jezerce	Papuk, Požeško-slavonska, Croatia	\N
219	0	0101000020E61000003EE8D9ACFA4C2F405F0CE544BBE24640	Ivica Sudnik	Samoborska gora, Zagrebačka, Croatia	\N
220	0	0101000020E6100000AD3BCC4D8A7D2840CBDF185D39124640		1 Borgo Italo, Borgo Giosu� salentino, Italy	\N
221	0	0101000020E6100000AF5E454607602340EDF2AD0FEB6B4440		2 Piazza Miglio, Vinebaldo veneto, Italy	\N
222	0	0101000020E610000050BA3EBD63AA2840D5DBB0B7DE294640		528 Rotonda Zordan, Sesto Rainelda sardo, Italy	\N
223	0	0101000020E6100000E7204322C8042640F6AEE6A507F54540		89 Contrada Chiara, Comito veneto, Italy	\N
224	0	0101000020E61000009F11B6E919B02140ABAC12D154364640		756 Rotonda Lombardi, Emmerico laziale, Italy	\N
225	0	0101000020E61000009EBFBFF7ED2224402DAAEA8ABEE84640		18 Piazza Otilia, Settimo Godeberta, Italy	\N
226	0	0101000020E6100000FF209221C76E274017844DF8002D4640		01 Strada Semprini, Malizia terme, Italy	\N
227	0	0101000020E6100000C2B28817FA8E2340D5809C8B1AB04640		39 Piazza Celentano, Sesto Beato ligure, Italy	\N
228	0	0101000020E6100000107BFC3960762540600A6A53D0274740		22 Strada Filipponi, Settimo Costanza, Italy	\N
229	0	0101000020E6100000CF5AC0BAE0462B40B9ED314745E34640		571 Via Romano, Sesto Nazario, Italy	\N
230	0	0101000020E610000048B42E7FCFC525403379B93E620B4740		4 Via Cordioli, Renda salentino, Italy	\N
231	0	0101000020E6100000E066F16261B42A4084E85AC52CF04640		9 Contrada Ornella, Pascali nell'emilia, Italy	\N
232	0	0101000020E610000021263CFC90E62840C604EBEEF0074640		1 Contrada D'Elia, Guida lido, Italy	\N
233	0	0101000020E6100000CFB81567B161274070CFF3A78DA74640		12 Borgo Ilva, Borgo Severiano, Italy	\N
234	0	0101000020E6100000C1F979F8D76F224054F0CAE48AB04640		10 Incrocio Egidio, Liotta umbro, Italy	\N
235	0	0101000020E61000008248D0A975782B40741200D2EDC94640		3 Piazza Violante, Chessa a mare, Italy	\N
236	0	0101000020E6100000918B208436172940630E828E564E4540		4 Contrada Daniele, Luciano ligure, Italy	\N
237	0	0101000020E610000023484A1F5F572240D37CDF09072C4640		37 Incrocio Casimira, Giulitta lido, Italy	\N
238	0	0101000020E6100000A09339F130542140F7DBE8ADCB384740		52 Contrada Cointa, Severino umbro, Italy	\N
239	0	0101000020E6100000068A0E37967A2540DB1FDE29D3664540		23 Contrada Liotta, Olindo laziale, Italy	\N
240	0	0101000020E6100000CF59B09EA4CE2640F18288D4B4434740		9 Rotonda Ermete, Furio ligure, Italy	\N
241	0	0101000020E6100000C153C8957A5A26407541D8840FE14640		436 Borgo Umberto, Settimo Emma, Italy	\N
242	0	0101000020E61000008577B988EF302140BAD3426E2B3D4740		55 Incrocio Di Santo, Iacono ligure, Italy	\N
243	0	0101000020E6100000589643E6259E2540B49487E013DD4540		8 Rotonda Italia, Balboni laziale, Italy	\N
244	0	0101000020E6100000249E4720B9702840B1F84D61A5124640		734 Strada Villari, San Ansaldo, Italy	\N
245	0	0101000020E61000008B89CDC7B55926407EB4EED57D084740		89 Piazza Venanzio, Genesia salentino, Italy	\N
246	0	0101000020E6100000D8B969334EEB27402CF8C84164804540		1 Borgo Irma, Salis terme, Italy	\N
247	0	0101000020E610000061D394AEAAD4204012A6835039FC4640		010 Borgo Schiavo, Sansone ligure, Italy	\N
248	0	0101000020E6100000B53C6AA741AC27408F0134A550B84640		53 Via Di Domenico, Quarto Gesualdo a mare, Italy	\N
249	0	0101000020E6100000F78CE9AE91D52240ED48F59D5FE54640		6 Piazza Gaudenzia, Di Caccamo nell'emilia, Italy	\N
250	0	0101000020E6100000626DE75663902B4097FA1E9A1ED44640		287 Piazza Eraldo, Nazario salentino, Italy	\N
251	0	0101000020E6100000FFF9C78C011B2640DD706946501E4740		59 Borgo Argelia, Villani del friuli, Italy	\N
252	0	0101000020E61000009C363EEEB67E2740BC2363B5F9BA4640		0 Rotonda Butera, Sesto Mimma laziale, Italy	\N
253	0	0101000020E61000008A9466F3387C1E402B31CF4A5AE74640		8 Strada Alcide, Plutarco laziale, Italy	\N
254	0	0101000020E6100000F22895F084D22A404082870E26ED4440		40 Rotonda Landolfo, Batilda umbro, Italy	\N
255	0	0101000020E61000007E1D386744712240C878399105CC4640		00 Incrocio Guarneri, Quarto Costanza calabro, Italy	\N
256	0	0101000020E610000020D84C1993812240A475AFEEB30D4740		918 Piazza Mora, Borgo Piergiorgio lido, Italy	\N
257	0	0101000020E6100000242136FD7E2E26406E2AF7A7F91A4740		5 Strada Alda, San Artemisa sardo, Italy	\N
258	0	0101000020E6100000485E8C37E8B927408860C1A2C7CA4640		03 Incrocio Pitzalis, Settimo Fosco, Italy	\N
259	0	0101000020E61000005E961BB1BB751E407379BD4571EF4640		849 Strada Coccia, Macario terme, Italy	\N
260	0	0101000020E6100000BE2ABC708CED2340366964A1E7DD4640		378 Strada Cremenzio, Fiorentino a mare, Italy	\N
261	0	0101000020E610000053B4722F302B2540E4DC26DC2B4D4740		0 Via Sabato, Motta sardo, Italy	\N
262	0	0101000020E61000009A97C3EE3B32254052B241CB5F574640		93 Rotonda Lo Iacono, Colella sardo, Italy	\N
263	0	0101000020E6100000622D3E05C0782840F70BD17C29DE4640		2 Rotonda Foca, Settimo Milena, Italy	\N
264	0	0101000020E6100000B05758703F782440773A4668BAB84640		6 Contrada Mencarelli, Colonna sardo, Italy	\N
265	0	0101000020E610000011D20957F63B2640E6B8AEF3CA084740		7 Contrada Mautone, San Everardo, Italy	\N
266	0	0101000020E61000004704E3E0D2692C408514F2F741A74640		69 Incrocio Sinfronio, Sesto Eugenia, Italy	\N
267	0	0101000020E61000002F0ACC54D2C8264038FE9F1E36CA4640		838 Piazza Alfieri, Sesto Azeglio, Italy	\N
268	0	0101000020E610000046E80C31035E29405A46EA3D95E54640		49 Strada Fabio, Settimo Cleo, Italy	\N
269	0	0101000020E6100000E4F90CA8376B2340ABA3F496BC5E4440		0 Contrada Novello, Sardina salentino, Italy	\N
270	0	0101000020E6100000967DB2BD71ED26406F7319EDA7C14640		38 Incrocio Trasea, Di Maria salentino, Italy	\N
271	0	0101000020E6100000FC68DDABFB5427401073EE1B04334740		3 Strada Giampaolo, Mollica ligure, Italy	\N
272	0	0101000020E610000069965F611C5B2540B52792F991CA4540		79 Strada Passuello, San Bruto, Italy	\N
273	0	0101000020E6100000B4C6455ACF692740D8C523A765B04640		9 Contrada Ignazio, Maffeo ligure, Italy	\N
274	0	0101000020E61000003B843B61D3CC1E40935742D202D44640		3 Borgo Caforio, Erenia calabro, Italy	\N
275	0	0101000020E6100000C03FA54A9455284094347F4C6BE54640		335 Piazza Amato, Borgo Ambrogio salentino, Italy	\N
276	0	0101000020E610000003FBF900EEEB1E40FA6184F068EE4640		38 Via Giaccio, Borgo Emidio, Italy	\N
277	0	0101000020E610000007681140209E2640B177352F3D9D4640		2 Piazza Acario, Sesto Claudio, Italy	\N
278	0	0101000020E6100000525F96766AFE23402A7C6C81F3EE4640		6 Rotonda Papapietro, Sesto Umberto umbro, Italy	\N
279	0	0101000020E61000007319EDA7B5EF1E400B1060EC18EC4640		56 Borgo Liberati, Sesto Cleopatra, Italy	\N
280	0	0101000020E6100000F86B578DCA1A284015E06014A9B14640		089 Borgo Barone, Sesto Morgana, Italy	\N
281	0	0101000020E6100000D634947FD2A12740811A081390584540		564 Borgo Bozzi, Tanzi ligure, Italy	\N
282	0	0101000020E61000009D63E53C08EA2640B7FB0BF3D4DC4540		3 Borgo Croce, Quarto Adalberto del friuli, Italy	\N
283	0	0101000020E6100000EA0E18DAEF9B2B40948444DAC6764640		782 Piazza Chimenti, Settimo Ischirione veneto, Italy	\N
284	0	0101000020E610000014BCD7FFEFC62640BA66F2CD36DE4640		025 Contrada Domezio, San Proserpina, Italy	\N
285	0	0101000020E610000009168733BFBE27405D4E098849354540		9 Rotonda Parente, Mirabella calabro, Italy	\N
286	0	0101000020E6100000462AE7E6763A2940ABB8CC446CE14440		0 Piazza Beltrami, Palombi terme, Italy	\N
287	0	0101000020E610000075EED176A7F62640A7F97486F3B24640		161 Piazza Iolanda, Sesto Griselda terme, Italy	\N
288	0	0101000020E6100000F9A23D5E48F727405789C3E3ECE04640		7 Incrocio Zanotti, San Temistocle salentino, Italy	\N
289	0	0101000020E6100000731A587D64FD294065FED13769E64540		1 Via Belmonte, Luciano a mare, Italy	\N
290	0	0101000020E6100000ABC5F18D322421407D1FB3582FFA4640		1 Piazza Vinebaldo, Adelaide veneto, Italy	\N
291	0	0101000020E610000035D252793B0228403A79ECC26AEA4640		31 Strada Luana, Carrieri a mare, Italy	\N
292	0	0101000020E6100000DD730580CFD02640F16261889CD44640		4 Incrocio Sapienza, Quarto Zarina, Italy	\N
293	0	0101000020E61000006531564046E12040530E1C8645E74640		705 Strada Cesaretti, Borgo Amando, Italy	\N
294	0	0101000020E610000026B8A2DE9D5E2740311A434AFDDC4640		599 Strada Richelmo, Surano terme, Italy	\N
295	0	0101000020E61000000A5BFD22B27524407121EA99B95B4640		7 Contrada Capitani, Borgo Antonella lido, Italy	\N
296	0	0101000020E6100000C132DBBA40CE2240D0EFFB372F274740		105 Borgo Leoni, Quarto Speranzio nell'emilia, Italy	\N
297	0	0101000020E6100000CA558737C6B91F40EB79ED88F9BD4640		3 Borgo Immacolato, San Pardo, Italy	\N
298	0	0101000020E61000006AEE320DD4F324401D098F9147B14640		91 Via Norina, Quarto Giadero lido, Italy	\N
299	0	0101000020E610000044053D8A291B2140F0FACC599F5A4440		589 Via Marianna, Calò lido, Italy	\N
300	0	0101000020E61000002B1D07B9E6212040F08C11E4FBF04640		520 Incrocio Ferrante, Sesto Gianmaria a mare, Italy	\N
301	0	0101000020E61000007BEDE3B21BB727403464E190B2DD4640		162 Strada Giadero, Teodoto lido, Italy	\N
302	0	0101000020E6100000D8E9ACBB1EE91F40A0A932E774D04640		7 Via Ruperto, Borgo Abibo lido, Italy	\N
303	0	0101000020E61000009C8136DEC21B294063731FCA61894540		42 Contrada Calandro, Oreste a mare, Italy	\N
304	0	0101000020E6100000E3B08FA91680204076A0F3BF01E94640		100 Borgo Sostrato, Di Tommaso terme, Italy	\N
305	0	0101000020E6100000EE6EAF16E9832340C6F0225D7DCC4640		2 Via Campagna, San Beatrice salentino, Italy	\N
306	0	0101000020E6100000D81D41E037B02140C2F1214D61C54440		89 Incrocio Pompili, Farella laziale, Italy	\N
307	0	0101000020E6100000A807BB174E80284061BC8B9C2AD94640		935 Strada Galante, San Ivo, Italy	\N
308	0	0101000020E6100000FD18CE9085A322406C9CA80073DB4640		97 Rotonda Giunta, Quarto Crescenzia del friuli, Italy	\N
309	0	0101000020E6100000E39F635122672540E113A1C7DEDE4640		0 Via Gedeone, San Desiderato veneto, Italy	\N
310	0	0101000020E610000098231A93B47928409916500361674640		87 Borgo Pantaleone, Petrucci veneto, Italy	\N
311	0	0101000020E6100000ABBCD3539A032740A544B7031AEF4640		339 Via Trovato, Oreste lido, Italy	\N
312	0	0101000020E61000001E424B0D239B2440D8D1DD1A7DA04640		20 Borgo Apollo, Santo nell'emilia, Italy	\N
313	0	0101000020E6100000CF2CAE96E0891F405EB642FDD3234640		5 Contrada Fiorini, Barsaba lido, Italy	\N
314	0	0101000020E6100000D7BDBACF96BC254007205AD020C34640		8 Incrocio Tarcisio, Lorenza terme, Italy	\N
315	0	0101000020E6100000C96BCABA24832740A97E4A3A6FE54640		087 Borgo Garavaglia, Baiocco sardo, Italy	\N
316	0	0101000020E6100000A8DAB80F8AC32940DF67017F9D1A4540		4 Strada Matarazzo, Quarto Teodoto laziale, Italy	\N
317	0	0101000020E6100000C272DFC556972640A4271BC528D24640		28 Via Fusco, Sesto Ermenegilda laziale, Italy	\N
318	0	0101000020E61000005F306E5974411E40EC3F21F1E13A4740		3 Rotonda Esuperio, Sesto Giosu�, Italy	\N
319	0	0101000020E61000006C109CE9142628401760C4E347124740		8 Piazza Davoli, Puca terme, Italy	\N
320	0	0101000020E610000044EC0214D9FD284012AC600AC5EE4440		120 Via Cristoforo Colombo, Roma, Italy	\N
321	0	0101000020E6100000B0FECF61BEF827406DFD99E6C2F24640		75 Via Milena, Telemaco nell'emilia, Italy	\N
322	0	0101000020E6100000EBB76576CCAF26407B8FE9BFBD424640		0 Strada De Candido, Carminati a mare, Italy	\N
323	0	0101000020E6100000D6479682247220407379BD4571084740		80 Incrocio Antelmo, Signorile nell'emilia, Italy	\N
324	0	0101000020E610000097900F7A36872040AB251DE560074740		68 Incrocio Cupido, Quarto Dionisia, Italy	\N
325	0	0101000020E61000000DABD3DC65C22740D32F116F9DE34640		687 Via Melchiorre, Quarto Flaviana calabro, Italy	\N
326	0	0101000020E61000009FEE97AA0FCF27402834FF9E0E024740		76 Contrada Romoaldo, Vittore calabro, Italy	\N
327	0	0101000020E6100000E417B90265622C40EFC0A50815E24440		82 Contrada Viliberto, Giusto veneto, Italy	\N
328	0	0101000020E6100000B2463D44A37B2540F3C011EEDF764540		4 Incrocio Quiteria, Borgo Geminiano nell'emilia, Italy	\N
329	0	0101000020E6100000B6B0B84956A326409DC2A5BE87334740		98 Rotonda Perini, Settimo Candido ligure, Italy	\N
330	0	0101000020E6100000D56C2FB319AD2840823C16365EC04640		21 Incrocio Ivo, Doronzo ligure, Italy	\N
331	0	0101000020E610000076583C5002EE1E40E0CCF9731BE14640		63 Incrocio Annabella, Falzone calabro, Italy	\N
332	0	0101000020E6100000470EC7A98CC52840B6A73F564BE04640		217 Contrada Gioacchini, Borgo Serafina laziale, Italy	\N
333	0	0101000020E61000004DC00A4B97B91F4005C1E3DBBBF84540		911 Rotonda Santilli, Quarto Luigi, Italy	\N
334	0	0101000020E610000059EB7A585E182740106D1162780E4640		16 Rotonda Mos�, Ippolito del friuli, Italy	\N
335	0	0101000020E610000051D9B0A6B2581F4089B7CEBF5DE14640		65 Via Nazzareno, Borgo Violante umbro, Italy	\N
336	0	0101000020E6100000AD7603BB504F27406049A8CFC4374640		481 Contrada Brumat, Masala terme, Italy	\N
337	0	0101000020E61000004692C5A28EF72640D32934B511794640		3 Piazza Crespi, Izzi del friuli, Italy	\N
338	0	0101000020E6100000068B790C45182740C3CB1D47BD774640		624 Piazza Massimo, Borgo Marisa, Italy	\N
339	0	0101000020E61000005CC0159A35C620401880A1A245F44640		0 Contrada Milella, Settimo Argo, Italy	\N
340	0	0101000020E6100000FA2D9512DD7227409453967C47234640		72 Strada Palazzo, Cattaneo laziale, Italy	\N
341	0	0101000020E61000008ECD8E54DFA12B403562C1583A2D4540		8 Strada Albano, Settimo Silvio sardo, Italy	\N
342	0	0101000020E610000020651FBF127F254034C06092257F4640		0 Contrada Bernadetta, Termine a mare, Italy	\N
343	0	0101000020E610000064BB31F3D36E22404F401361C3C24640		65 Incrocio Costa, Valerico veneto, Italy	\N
344	0	0101000020E6100000D160AEA0C47E2240E41824D813C04640		37 Via Giustra, Quarto Genesio, Italy	\N
345	0	0101000020E61000006FD8B628B3B91E40086465EA64D64640		0 Incrocio Mazzanti, Settimo Siria, Italy	\N
346	0	0101000020E610000016CDB9CAC93E2140BC0E8B074A744640		5 Contrada Santo, La Monaca umbro, Italy	\N
347	0	0101000020E6100000B4064A65E54A274026DAFA8E86E14640		088 Via Melitina, Quarto Rosita, Italy	\N
348	0	0101000020E61000000736F80CF26822405273034F6B9C4640		1 Strada Annamaria, Albina calabro, Italy	\N
349	0	0101000020E6100000DF6124C511412140D11CFE3FF3744640		34 Borgo Aciscolo, Sesto Fabio, Italy	\N
350	0	0101000020E610000077ED77CD50412140CB243493B9744640		0 Strada Santarsia, Tamara del friuli, Italy	\N
351	0	0101000020E61000002E008DD2A5032D406B5CA4F55C204540		824 Incrocio Evodio, Vladimiro laziale, Italy	\N
352	0	0101000020E61000004ED367075C6F1F403A57941282D64640		42 Incrocio Corbiniano, San Giobbe, Italy	\N
353	0	0101000020E61000006405BF0D316E1F409F07D22060D24640		5 Via Bianchetti, Quarto Tiziana umbro, Italy	\N
354	0	0101000020E61000006F4BE482334C2740A928A8F287304640		215 Borgo Zucca, Settimo Ilda, Italy	\N
355	0	0101000020E61000005BC52CC59F522B40DB68A5B50EFA4640		9 Borgo Verecondo, Sesto Appia ligure, Italy	\N
356	0	0101000020E61000000D5F155E383A21402BCC310F4F724640		4 Rotonda Zanetta, Mulè a mare, Italy	\N
357	0	0101000020E6100000E04158326C5D2140821C9430D3704640		39 Contrada Arduino, Doroteo ligure, Italy	\N
358	0	0101000020E6100000C1F979F8D7071F404EFA319C21CD4640		765 Strada Di Cesare, Indelicato sardo, Italy	\N
359	0	0101000020E61000000C97B0917F3921404C9C267D6B734640		2 Contrada Baroni, Giadero a mare, Italy	\N
360	0	0101000020E6100000EFA18ED838742840FA10AF46D1764640		271 Via Giorgio, Corinna a mare, Italy	\N
361	0	0101000020E6100000B032BF3F4AC11E4019CD25B094D54640		8 Contrada Prato, Pisu ligure, Italy	\N
362	0	0101000020E610000039FBB9579CA829401D9C3EF152FC4440		3 Strada Gazzola, Quarto Agnese, Italy	\N
363	0	0101000020E6100000440E5BC4C1F71E4071033E3F8C7E4640		8 Rotonda Domezio, Cataldo veneto, Italy	\N
364	0	0101000020E6100000C69EE2DD36D82B400B8AD5D5D3E84640		64 Strada Asterio, Sesto Carlo terme, Italy	\N
365	0	0101000020E6100000888961E2EA131F4040E7244A31CD4640		41 Borgo Festuccia, Cammarata laziale, Italy	\N
366	0	0101000020E6100000E8F86871C6D81E40E7EBE86E8DD84640		463 Rotonda Crocefisso, Adelchi veneto, Italy	\N
367	0	0101000020E610000024BF34FBF2301F405FCE6C57E8CB4640		67 Strada Flaminia, Quarto Tarquinia umbro, Italy	\N
368	0	0101000020E61000000242902859C7254075988AE832F64540		4 Borgo Monti, Paola lido, Italy	\N
369	0	0101000020E61000005CEC5113D8AF1E405650ACAE9ED84640		44 Rotonda Veronica, Calpurnia umbro, Italy	\N
370	0	0101000020E6100000A6A84423E9E41E40BF20336145E14640		46 Strada Siciliano, San Volfango laziale, Italy	\N
371	0	0101000020E6100000F07A7AB6582B2740B1ADFAB726234640		690 Rotonda Belvisi, Sesto Taziana, Italy	\N
372	0	0101000020E61000002252D32EA6C91E404392B47636E94640		49 Rotonda Pantaleo, Di Somma laziale, Italy	\N
373	0	0101000020E61000000BC336983C2C27405262D7F676234640		609 Borgo Ireneo, San Ione calabro, Italy	\N
374	0	0101000020E61000004F722C94F1E8264075F2D885D5064740		088 Contrada Giovinazzo, Edgardo sardo, Italy	\N
375	0	0101000020E61000005C8BBBE6FA8F26407A4F8AFB343B4740		70 Borgo Marzi, Di Giuseppe a mare, Italy	\N
376	0	0101000020E61000007B9054956C0B28407BB5487FD4974640		5 Incrocio Fiorenza, Sesto Odidone, Italy	\N
377	0	0101000020E6100000BE52F1DA00B72B40D21D1F8887274540		097 Rotonda Alcibiade, Borgo Mirella lido, Italy	\N
378	0	0101000020E6100000A732D6485C052740FDD8243FE2394640		602 Contrada Perilli, Miranda salentino, Italy	\N
379	0	0101000020E6100000AD94545C0B4D2240EE885462E8B94640		901 Borgo Consiglio, Borgo Verulo, Italy	\N
380	0	0101000020E6100000333097F9B3641F40983BE93356DF4640		905 Strada Casale, Grange del friuli, Italy	\N
381	0	0101000020E61000002B8AB2124E762740C1EA234B41314640		897 Borgo Alcino, Severino lido, Italy	\N
382	0	0101000020E6100000905F8951219022403E5695229E864640		071 Rotonda Amadori, San Savina, Italy	\N
383	0	0101000020E610000096C1621E43E92640E580B80611044740		78 Borgo Taide, Sesto Cleopatra del friuli, Italy	\N
384	0	0101000020E61000007090B52B99842B40E461461DC27E4640		0 Borgo Viale, Borgo Carla salentino, Italy	\N
385	0	0101000020E610000084B1CFAD219A26406BDECC43010E4740		640 Borgo Metello, Settimo Afro, Italy	\N
386	0	0101000020E6100000CC1D47BDF13F2240A5A31CCC26824640		103 Piazza Riolo, San Garimberto, Italy	\N
387	0	0101000020E610000048E58123DCFF26407F7E294D94084740		85 Borgo Edilberto, San Liberto sardo, Italy	\N
388	0	0101000020E61000006B5A73918C1625409D7C1FB358204740		6 Contrada Golia, Castellana lido, Italy	\N
389	0	0101000020E6100000204F818241C01E40068B1E53D2D34640		82 Rotonda Tonelli, Benigna nell'emilia, Italy	\N
390	0	0101000020E6100000C0CBB161F2931E40B859BC5818D34640		8 Borgo Marotta, Borgo Michele, Italy	\N
391	0	0101000020E610000070DA4246F68B2C40A79C8AAFD1364740		3 Strada Giacomo, Righi ligure, Italy	\N
392	0	0101000020E6100000A9D5FC9D92882C4058FBE02131384740		90 Strada Marini, San Aristo del friuli, Italy	\N
393	0	0101000020E6100000F74A0FF91DD1274067DC8AB3D8024740		58 Borgo Salomone, Barbieri umbro, Italy	\N
394	0	0101000020E61000004221A7542EE52C40A39BB3F457164740		829 Strada Esposito, Conti calabro, Italy	\N
395	0	0101000020E6100000D3D7987C586422408E7CB9AA47A84640		433 Via Euclide, Rondoni terme, Italy	\N
396	0	0101000020E610000008CDAE7B2B8A2440E646EC6EF9664540		4 Borgo Bortolo, Leonardi terme, Italy	\N
397	0	0101000020E610000081EB8A19E1CD26408A4457D8C2194640		781 Via Lucarelli, Cerullo umbro, Italy	\N
398	0	0101000020E6100000B4CA4C69FD5122404A95CDC1D8134540		487 Via Acario, San Oriana, Italy	\N
399	0	0101000020E6100000E4BD6A65C267264033260EEA6CBC4640		36 Borgo Bernardo, Borgo Erico, Italy	\N
400	0	0101000020E610000071C0536DDCD325406C312E0BDCB14640		561 Strada Cesare, Violi a mare, Italy	\N
401	0	0101000020E6100000B368F0ADFEEA2540D42AFA4333B54640		27 Contrada Tabita, Settimo Melissa, Italy	\N
402	0	0101000020E61000005B2CA0AB08EA2740DE454E15422C4740		409 Contrada Carponio, Lo Piccolo del friuli, Italy	\N
403	0	0101000020E61000009703988D2933274052EC0D63778A4640		66 Via Monte Grappa, Lendinara, Italy	\N
404	0	0101000020E61000005389FC44AF582940E7D2AEF83CCA4640		12 Strada Di Girolamo, San Lanfranco umbro, Italy	\N
405	0	0101000020E61000000236D6B441802C4025D5D237C46B4440		44 Via dei Greci, Napoli, Italy	\N
406	0	0101000020E610000073220BE24DBC2740A1E4C40DAE2D4740		04 Incrocio Bortoluzzi, San Gigliola a mare, Italy	\N
407	0	0101000020E610000046B1DCD26AB02540072E45A808074740		8 Piazza Sucera, Liliana lido, Italy	\N
408	0	0101000020E6100000B17E7DBE77992240C0F858B043504440		33 Incrocio Galasso, San Massimiliano, Italy	\N
409	0	0101000020E6100000EC3026FDBD2C27403B6AF1CE46024740		4 Via Godeberta, Zambuto del friuli, Italy	\N
410	0	0101000020E6100000996EC8F5A5712B40C576F700DD3C4740		9 Strada Cuzia, Quarto Divo, Italy	\N
411	0	0101000020E6100000AA5DB818A8F922406B0DA5F622154440		317 Contrada Adrione, San Alina a mare, Italy	\N
412	0	0101000020E610000034B10AE58E682040CFC941BFA57A4440		0 Piazza Boffa, San Guendalina, Italy	\N
413	0	0101000020E610000008D04AB5AABC2140800F5EBBB4374640		450 Incrocio Ciccarelli, Settimo Maffeo, Italy	\N
414	0	0101000020E6100000B35DA10F967D2D408F49905BDD324740		501 Contrada Ludovica, Remondo calabro, Italy	\N
415	0	0101000020E6100000852348A5D8C12840842458C114E24540		13 Rotonda Fernanda, San Bindo, Italy	\N
416	0	0101000020E6100000BF5076E915252B40EA398EC4703B4740		8 Borgo Servidio, Eliano calabro, Italy	\N
417	0	0101000020E6100000B956D6917EDA2B40DF707A72A8054540		548 Contrada Umile, Nicotra a mare, Italy	\N
418	0	0101000020E61000007889A02067742340DE2A3EF493CE4640		446 Borgo Liberatore, Sesto Moreno, Italy	\N
419	0	0101000020E6100000235399BDC70C254059CFFF6101ED4540		6 Rotonda Pascali, Laezza del friuli, Italy	\N
420	0	0101000020E610000027F33405D7392640E75E16C90D2C4740		44 Strada Abenzio, Indelicato umbro, Italy	\N
421	0	0101000020E61000001C15EE4BECAC2A40DD11A9C4D02E4540		5 Via Gargiulo, Genesio calabro, Italy	\N
422	0	0101000020E6100000C1D4850E70E722408E6D63FDB0594540		57 Incrocio Teodora, La Malfa del friuli, Italy	\N
423	0	0101000020E6100000E5BA849E28A826407E7D63BE723F4640		370 Via Carminati, Settimo Quirino del friuli, Italy	\N
424	0	0101000020E610000055B1E72109D11F4018CFA0A17FB14640		728 Contrada Pavan, Borgo Sidonio ligure, Italy	\N
425	0	0101000020E61000007DEFCA89D18E2640DB0B16985F354540		922 Piazza Fonda, Pircher ligure, Italy	\N
426	0	0101000020E6100000BB6D9516E41D244002678412C1A94640		932 Borgo Peleo, Cavallini lido, Italy	\N
427	0	0101000020E6100000F67AF7C77BB52740FA449E245D4F4740		72 Contrada Cornelia, Borgo Iorio calabro, Italy	\N
428	0	0101000020E6100000DE68119BD960294098E8E225EEFB4440		7 Contrada Fumagalli, Sesto Fedora, Italy	\N
429	0	0101000020E61000007ED3AA4CE7E52340C9CC052E8F254640		8 Incrocio Moretto, Quarto Valtena, Italy	\N
430	0	0101000020E61000004EDF217B732E2240D3F4D901D7214540		41 Borgo Guido, Guerriero umbro, Italy	\N
431	0	0101000020E61000004377A45588CA264008951348E43C4640		670 Incrocio Ferruccio, Quarto Dionisio, Italy	\N
432	0	0101000020E610000072593B40E6692840252D4B2A09EC4440		6 Incrocio Flore, Bertoldo umbro, Italy	\N
433	0	0101000020E610000023E7B3F281D7214072C8618B38C84640		73 Via Cingolani, Tassi salentino, Italy	\N
434	0	0101000020E61000000C84AE8E2D752740A4897780272E4640		56 Incrocio Asaro, Neri laziale, Italy	\N
435	0	0101000020E6100000A63C5F58A33326408C811A63CCED4540		71 Incrocio Berardi, Quarto Eros lido, Italy	\N
436	0	0101000020E6100000CC0C1B65FD922840A42C8DA905C14640		223 Rotonda Frasca, San Albano, Italy	\N
437	0	0101000020E61000007332CC64933F2740FEDDF1DC31254640		74 Piazza Rocco, Mazzone a mare, Italy	\N
438	0	0101000020E610000032D758784D462240743F4C67CC0B4740		1 Piazza Belmonte, Settimo Telemaco, Italy	\N
439	0	0101000020E61000002B16BF29ACC825401AB6775787864540		0 Incrocio Giglio, Borgo Beronico, Italy	\N
440	0	0101000020E6100000FE00B562C9B62A4032CFA51364D94440		56 Incrocio Di Bari, Sesto Clodomiro ligure, Italy	\N
441	0	0101000020E61000002AD890C9F3362640A3C629DFD80F4640		464 Piazza Proserpina, Gesualdo del friuli, Italy	\N
442	0	0101000020E610000098F0958AD7422540F3DD52735E994640		665 Incrocio Margiotta, Borgo Galatea terme, Italy	\N
443	0	0101000020E6100000451B36806D772640B99BF1C7FE074740		029 Incrocio Elmo, Valerico terme, Italy	\N
444	0	0101000020E61000008948A8740B9027402B7D321015F14540		079 Incrocio Enzo, Sesto Caronte umbro, Italy	\N
445	0	0101000020E6100000484B8A3496612B40F1F44A5986DF4640		474 Piazza Maria, Falchi sardo, Italy	\N
446	0	0101000020E610000006240626DCE0264059631A97BBDC4640		7 Piazza Nazzaro, Oronzo veneto, Italy	\N
447	0	0101000020E61000001A62067470422640EF6BC94F4FBD4540		657 Borgo Massimiliano, Lombardo ligure, Italy	\N
448	0	0101000020E6100000F0F1536694F425402F5D77A9C7134640		23 Via Moras, Arena sardo, Italy	\N
449	0	0101000020E6100000A5DAA7E3317F2240E75E16C90DEF4640		0 Rotonda Socrate, Quarto Minerva terme, Italy	\N
450	0	0101000020E6100000D12E956D967D2C40126C5CFFAE6D4440		03 Strada Adami, Egidio veneto, Italy	\N
451	0	0101000020E6100000DD6CBDF0941F27409F515F3BBDDA4640		41 Borgo Viviana, Borgo Icilio, Italy	\N
452	0	0101000020E610000096EA025E66002640FA4E82ED16F44540		927 Strada Genchi, Amadeo umbro, Italy	\N
453	0	0101000020E61000009DDE20B5E43C25407F83F6EAE39D4540		971 Strada Immacolato, Domenico lido, Italy	\N
454	0	0101000020E6100000016E162F168E2340861BF0F9614A4440		7 Via Loredana, Agape terme, Italy	\N
455	0	0101000020E61000009F32480BE1EA20405C8A50114CDA4640		1 Contrada Celeste, Poletti del friuli, Italy	\N
456	0	0101000020E6100000618841052C422B400938DFE3A78E4640		0 Strada Travaglini, Quarto Menelao ligure, Italy	\N
457	0	0101000020E6100000160F94803D132140276BD44334E04640		2 Borgo Gottardo, San Gentile veneto, Italy	\N
458	0	0101000020E610000097A13BD22A4C25401A80B2CE9DD44540		833 Borgo Mazzei, Cino salentino, Italy	\N
459	0	0101000020E6100000AD904D4DDD3827405B632BC313B14540		65 Strada Brancaleone, D'Avino calabro, Italy	\N
460	0	0101000020E610000071E82D1EDEEB2C405F93DA30AF824440		8 Strada Cadoni, Quarto Camillo a mare, Italy	\N
461	0	0101000020E6100000DA48C8F6109B1F40EE2AFFB5176E4640		83 Rotonda Porzia, Benigna sardo, Italy	\N
462	0	0101000020E61000004D028A4798F02740C38366D7BD264640		56 Via Verenzio, Di Michele laziale, Italy	\N
463	0	0101000020E6100000BCB77DEAB38A2C404EF04DD3676E4440		338 Strada Antonia, Borgo Eufronio del friuli, Italy	\N
464	0	0101000020E6100000CBC80F4BB93126404793E6EA22FD4640		1 Strada Bonomi, Caiazzo nell'emilia, Italy	\N
465	0	0101000020E6100000A68E9FD7E925284065677682A2C64640		41 Borgo Carmen, Settimo Graziella a mare, Italy	\N
466	0	0101000020E6100000407562C55F5D294091FC773359C24640		01 Incrocio Sucameli, Quarto Eugenio, Italy	\N
467	0	0101000020E6100000CF328B506C4D244070D63B37C8184640		034 Borgo Maura, Archimede salentino, Italy	\N
468	0	0101000020E61000007E6E0D11DC1122409453967C47EB4640		788 Piazza Caterino, San Bonifacio umbro, Italy	\N
469	0	0101000020E610000043A44BA4D989204072A8DF85ADD34640		86 Piazza Carriero, Didimo sardo, Italy	\N
470	0	0101000020E61000004371C79BFC022C404AF5F81807254540		116 Borgo Zanotti, Borgo Saul lido, Italy	\N
471	0	0101000020E61000009EA74B10BFA422400292FAFC41944440		060 Contrada Ilva, Ezio laziale, Italy	\N
472	0	0101000020E61000000D88B59D5B012C40CF70B9B024144540		41 Incrocio Bartolomeo, Perini ligure, Italy	\N
473	0	0101000020E610000059935D1F8CFE26407E6DA23B2D3B4640		3 Rotonda Tullia, San Noemi, Italy	\N
474	0	0101000020E6100000D50451F7010829403B736AC2510D4640		86 Rotonda Melchiade, Quarto Emiliano, Italy	\N
475	0	0101000020E6100000CD6152D735012740D65F6523C6394640		780 Borgo Correale, Lidio umbro, Italy	\N
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hike_track_points ("userHikeId", index, "pointId", datetime) FROM stdin;
\.


--
-- Data for Name: user_hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes (id, "userId", "hikeId", "startedAt", "updatedAt", "finishedAt", "psTotalKms", "psHighestAltitude", "psAltitudeRange", "psTotalTimeMinutes", "psAverageSpeed", "psAverageVerticalAscentSpeed", "maxElapsedTime", "weatherNotified", "unfinishedNotified") FROM stdin;
\.


--
-- Data for Name: user_hikes_track_points_user_hike_track_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_hikes_track_points_user_hike_track_points ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash", approved, preferences, "plannedHikes") FROM stdin;
2	$2b$10$HQ7CyxeHCRCoMJZP3OBOu.NrPlokc4lhOlZzstilVNlykG2Zkqtfe	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N	t	\N	\N
4	$2b$10$UUSwPeGya14II7LY1xIXlusjrY4E1jmtEi3fLzv.OK8EpaYQXKU6m	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N	t	\N	\N
5	$2b$10$5GP.MfTYv4ZVww9kYhqJteVwL30ls1uCVYMbRhW1QVWu8Cdxzy.qC	Laura	Zurru	5	laura@emergency.it	\N	t	\N	t	\N	\N
1	$2b$10$ZPVoPBf9zf.pvp6IwXOJye4EWS5QnhFk2bqk9hZtDUCKiCaWgAeGy	German	Gorodnev	0	german@hiker.it	\N	t	\N	t	\N	\N
3	$2b$10$gQmHsLZOwI9n/k771I/xfegtv1mmGGADpQPKsb22feotKWEtH8hbC	Vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N	t	\N	\N
6	$2b$10$8C7Kqwqf5AvvI0ZSp0g4/OVMcN0zIm099TYB34yXAXk/7CA.mzgxK	Francesco	Grande	1	francesco@friend.it	\N	t	\N	t	\N	\N
7	$2b$10$gF1RwkxSs/Xz7j9gsmUOrujxOke0clLxJMYlVGZEuXAuVj65TeLSi	Armida	Pedrazzini	4	hutWorker0@gmail.com	\N	t	\N	t	\N	\N
8	$2b$10$3/tHXxcdcJ10jbMxDdYbxu641SyEikcWJzh9t6mpTTTgfKExAECl6	Ascanio	Evola	4	hutWorker1@gmail.com	\N	t	\N	f	\N	\N
9	$2b$10$ucMLMQHy6i29eKojnlsUNOw4IDpsPYr3sxV67Ye81qUKu.l6DDXRm	Boris	Corrado	4	hutWorker2@gmail.com	\N	t	\N	t	\N	\N
10	$2b$10$uXNCvctE2jEbW0SWI56mcOdmlGV.ILO57P/q/hcHcIHV3TR3/7FHS	Priamo	Di Dio	4	hutWorker3@gmail.com	\N	t	\N	f	\N	\N
11	$2b$10$Aqhd5gtUDcuEnl.TlijkFupHlKA1Dlnddh.QmAWiXezahkaZQKH9q	Magda	Palano	4	hutWorker4@gmail.com	\N	t	\N	t	\N	\N
12	$2b$10$.DpomHQzaVZl2Pzccc/H9uDcuidrwikU5vRruZUKERBLN4pNuVeaO	Alessandra	Carrara	4	hutWorker5@gmail.com	\N	t	\N	f	\N	\N
13	$2b$10$MTJb2LyIBgZP/FcnE/LguOqLUDhq8nti14pJDGCE/ajfYANfuUJM6	Lamberto	Montanaro	4	hutWorker6@gmail.com	\N	t	\N	t	\N	\N
14	$2b$10$i14abM8jbFlH7aDSKHeeee/XLeN22qoaE7/FDq9eaNwclkHZRa7Q2	Eugenia	Liguori	4	hutWorker7@gmail.com	\N	t	\N	f	\N	\N
15	$2b$10$gEE3AjQceLDoLnZuOEXHZ.UwJtS.campgKbh70lee/dJ3EREfHGZ6	Livia	Cerri	4	hutWorker8@gmail.com	\N	t	\N	t	\N	\N
16	$2b$10$pi5ybDtDnjpGRGqFOOatOebW.p..oaHYyE283/2LhJik/WmhGUgrq	Dina	Maresca	4	hutWorker9@gmail.com	\N	t	\N	f	\N	\N
17	$2b$10$dACuCW3SDr/yuVSAZ/YWmutf63pHn/c96HlKBK46ydwvk8XS./1uO	Lavinia	Salvatore	4	hutWorker10@gmail.com	\N	t	\N	t	\N	\N
18	$2b$10$U293OUDTWAzrXUloEWB8HOjdqG3UoU/pWkaeuHvFfhXYGHAlvkThC	Ferruccio	Pitzalis	4	hutWorker11@gmail.com	\N	t	\N	f	\N	\N
19	$2b$10$tJbJ7JUG4dFS0VPMDgE8du5nevBd7lpaBELpc3E/oPFM9HFYkBHmC	Monica	Bellomo	4	hutWorker12@gmail.com	\N	t	\N	t	\N	\N
20	$2b$10$8YYe1ubIaxZ8YXkQ8gRgoewEWGQ6viu6DnRzyZ6ncLFSR7.M.1xVe	Lucrezia	Galeazzi	4	hutWorker13@gmail.com	\N	t	\N	f	\N	\N
21	$2b$10$yomX6TjN7pl.jNG6CJ7HpeEHucWQy3gXCFHIcwY0YvxZrNI7bfdma	Adelgardo	Pollina	4	hutWorker14@gmail.com	\N	t	\N	t	\N	\N
22	$2b$10$sLplYpMkidItcbOoTyjnt.Un5c9w3W3Ap9T/r9Rv.FwARhf.EP1K6	Aristione	De Santis	4	hutWorker15@gmail.com	\N	t	\N	f	\N	\N
23	$2b$10$yVnrlqVi5HUD8YrunldyWOkeEps73ejzI6F4hLIUGgV0INwKs/ZTG	Albina	Girardi	4	hutWorker16@gmail.com	\N	t	\N	t	\N	\N
24	$2b$10$sm7ds1DWiSukNbxvjuZOKOmM52W4473MMVuYXaOLIq3A/.qI2Xt4.	Gemma	Centofanti	4	hutWorker17@gmail.com	\N	t	\N	f	\N	\N
25	$2b$10$A11y8GwOksd4MKYeMln4ouZDktRySMmoM2aKv7JHtYtp15e4iioFy	Licia	Ranieri	4	hutWorker18@gmail.com	\N	t	\N	t	\N	\N
26	$2b$10$37iZdUAgFzzcpk0eu6QyV.uWs/1h.8b41higuCzi.y5x94ul4dKOS	Rosmunda	Tonelli	4	hutWorker19@gmail.com	\N	t	\N	f	\N	\N
27	$2b$10$y.Y3SpKQcLvxO.znZKiUYONfOlHF3oy9zDojNRPD.ia46YSjONgs6	Melitina	Luchetti	4	hutWorker20@gmail.com	\N	t	\N	t	\N	\N
28	$2b$10$UMfO6puWTWVkBTrIvm.kb.jZZyjesD0rcIceIhQovzogdwYqzM572	Mirta	Montalbano	4	hutWorker21@gmail.com	\N	t	\N	f	\N	\N
29	$2b$10$0Zpsz7LqLmLC.mqgeErROerimksYmc0mP605I/zDO8stdhJDFmIUS	Basilio	Rizzi	4	hutWorker22@gmail.com	\N	t	\N	t	\N	\N
30	$2b$10$grwr6C/dKKy8suDHfLUid.1EDiAQIjXrhPTgVMJtIQDki1Sk9ltp6	Doroteo	Del Prete	4	hutWorker23@gmail.com	\N	t	\N	f	\N	\N
31	$2b$10$AzAP1kqkoIn0ZeS9DWFQheQvniNkSirD.eP2unR5BxTOObhmW1Z1.	Manfredo	Oliviero	4	hutWorker24@gmail.com	\N	t	\N	t	\N	\N
32	$2b$10$DV3chTLcOa11cdU34hY4g.z7.eV/9eDZodjVrpQ52CRXrxilIxlo6	Ambra	Riccio	4	hutWorker25@gmail.com	\N	t	\N	f	\N	\N
33	$2b$10$WhUC/yPFCiLPwpg2DUjnu.DrW46NSv4vnLX9nIcm.8j.nqMJEzku6	Giotto	Guarneri	4	hutWorker26@gmail.com	\N	t	\N	t	\N	\N
34	$2b$10$lFlZl1ojsh.uQ8NqNnRa3Opwc.iDB87IZFToGOL6/PGm47hXKkDHm	Luciana	Pizzi	4	hutWorker27@gmail.com	\N	t	\N	f	\N	\N
35	$2b$10$M7GecpMaIy01AyPNuTFO1.sZLM9nnqHRmyWWD6NsAkL9zYqa5wLfu	Savino	Passuello	4	hutWorker28@gmail.com	\N	t	\N	t	\N	\N
36	$2b$10$K6p.ejz.f3nhVR10358XDuEo/LPZDucCODVtM5GDKzOcSxqrD.U8K	Cristiano	Tumino	4	hutWorker29@gmail.com	\N	t	\N	f	\N	\N
37	$2b$10$yp4jUzFyRdmDOp75R13JPO5ffdg9NY6PfsOry/1mT9a6O9nLp5oVe	Messalina	Natali	4	hutWorker30@gmail.com	\N	t	\N	t	\N	\N
38	$2b$10$U9JbJtMWzYyZ3Y3Q8o5yV.fGrzFLjAShtmdlY3FypgGOz2UGpddY.	Ovidio	De Lucia	4	hutWorker31@gmail.com	\N	t	\N	f	\N	\N
39	$2b$10$cNpSz293dcjDA6CcnMYDzOMo7Yy0Dhtuus/1yNp16J4HHboBBf7cu	Emma	Iuliano	4	hutWorker32@gmail.com	\N	t	\N	t	\N	\N
40	$2b$10$OyH/0wGW/4XqQtKXglnciOstSXSllBFAP/Q0QUP8Nn0UgR4.penJe	Ultimo	Ballarin	4	hutWorker33@gmail.com	\N	t	\N	f	\N	\N
41	$2b$10$i64EoOetS4PqvNvQWEpjvOEz1K2De0IHBvCTcPQvTlF4ppFIG9WKq	Agesilao	Cerrato	4	hutWorker34@gmail.com	\N	t	\N	t	\N	\N
42	$2b$10$J7X5yb7FMaE4K/asAGtk4O3faB4Pxkjg/9O1T0GhqamQR6oLKa5x.	Ippocrate	Fasano	4	hutWorker35@gmail.com	\N	t	\N	f	\N	\N
43	$2b$10$rypL6Q.sakmhXLrhi30NVeb3WgrVDP6Z75R9oWpupP/bgymLsFc5u	Floriana	Albano	4	hutWorker36@gmail.com	\N	t	\N	t	\N	\N
44	$2b$10$/QteuAC2jYS5z7.28TkBqeTdnt5ECjaezsqqUEiYN4W2NROgjLiY.	Zanita	Lodi	4	hutWorker37@gmail.com	\N	t	\N	f	\N	\N
45	$2b$10$FvUrNfyQBU3IozZh/57Zo..k6dwFzErQeNH/CfHCMrceUubSfylfW	Egidio	Vacca	4	hutWorker38@gmail.com	\N	t	\N	t	\N	\N
46	$2b$10$9U98fYbiIULVpwDOY28JaOXINNOUmWC.j4afZPibaPuPMcwVpY.8q	Gianmarco	Costantini	4	hutWorker39@gmail.com	\N	t	\N	f	\N	\N
47	$2b$10$nUnIGXJvkRuuzpRRPTO.h.70o439UzOxjDh.wxCV4jR.Vr8yX3U4K	Ornella	Bongiovanni	4	hutWorker40@gmail.com	\N	t	\N	t	\N	\N
48	$2b$10$n.MyE/XSA16n/dx7ghGSbOAjK8vzeVt03ONc2QsS95Aw6isdzTmbC	Giacinta	Narciso	4	hutWorker41@gmail.com	\N	t	\N	f	\N	\N
49	$2b$10$r0zwWh4nD8NE.6fCPrl19.6WFe7pZjJGNJGnwNQuNUSMTHD5ofYN.	Margherita	Buzzi	4	hutWorker42@gmail.com	\N	t	\N	t	\N	\N
50	$2b$10$Fwcoib0/ShfFAvRWDrY4y.qgNer9u4w9b8.d4OYuZuImr48jhScwi	Adalgisa	Benvenuto	4	hutWorker43@gmail.com	\N	t	\N	f	\N	\N
51	$2b$10$N91xEnntWi4f6hCpHeSpBOPD5YxbszRdz3WBnyWY8vbKP2NPpTMOO	Carmela	Sarti	4	hutWorker44@gmail.com	\N	t	\N	t	\N	\N
52	$2b$10$PYZNv3e/PnPFr57wqbX0y.URfmWWhxltLJvWR2YYL4lo4wAWGGxti	Samanta	Tiberti	4	hutWorker45@gmail.com	\N	t	\N	f	\N	\N
53	$2b$10$a5qen9x/J/ebxogxeodICui0ih7Kt1PVI.qb4bLx/zLiMJvHoylOq	Rosamunda	Landi	4	hutWorker46@gmail.com	\N	t	\N	t	\N	\N
54	$2b$10$2LHYft5YXYwqGXJl0pSFyOC9Q5/XCY/1duFVDja1INYgfyLeNpVeC	Siria	Mangano	4	hutWorker47@gmail.com	\N	t	\N	f	\N	\N
55	$2b$10$qNtk.jHvoYi49/5ltXqimODe6UnGCRwMjisMgiBUpo0iwkAYzce.S	Patrizio	Manzi	4	hutWorker48@gmail.com	\N	t	\N	t	\N	\N
56	$2b$10$1lp5ihkzvYZNKy.QueYr1OhMXgG6126BXKrOqtk4dYEn.HQl1YkPm	Assunta	Rusciano	4	hutWorker49@gmail.com	\N	t	\N	f	\N	\N
57	$2b$10$nQBJndLXCDoNcXVthXAM7.oQN964b3qUjVupoAsNIkpt0DPRTlPvW	Ausilio	Faraci	4	hutWorker50@gmail.com	\N	t	\N	t	\N	\N
58	$2b$10$dRg09wkX2sxSm72kEK88D.vOzkgqy3Re2.588haK2kDWEizbUZlEm	Taddeo	Boschetti	4	hutWorker51@gmail.com	\N	t	\N	f	\N	\N
59	$2b$10$mWTp8Zh/I0v1v3xDUphICeDYudlnJwq2wyEx/.zGjyk.bHcRsfqu.	Martina	Tofani	4	hutWorker52@gmail.com	\N	t	\N	t	\N	\N
60	$2b$10$UYTivpi5JjxxUUDKSbz4AeWrY2KXcuiOteZpdx1RJ.Ls3RSanRLmW	Ettore	Mele	4	hutWorker53@gmail.com	\N	t	\N	f	\N	\N
61	$2b$10$nHp7G1LeEbifpwSE5WrDvecERPCnJ.qNHqDApIwixs/vTB8qkKGJW	Donatello	Cherubini	4	hutWorker54@gmail.com	\N	t	\N	t	\N	\N
62	$2b$10$LK.Q8FRfI7h3oWerSjpH..is4OXsmCbgmjVTm/UyrtVAjgYup4VZ6	Nilde	Simonini	4	hutWorker55@gmail.com	\N	t	\N	f	\N	\N
63	$2b$10$VrkbwmxOgNUG2zFTL5Ae4OhlNKGKfsPposItLo3FJUUWm2sKAECge	Imelda	Argenio	4	hutWorker56@gmail.com	\N	t	\N	t	\N	\N
64	$2b$10$7qAhXlnhkjZ3oM5IEEsaaeRD5Bz8PZnTlRB0iizMeOOaBofQHjxPm	Leonida	Caggiano	4	hutWorker57@gmail.com	\N	t	\N	f	\N	\N
65	$2b$10$SmYKkA.RCH2oWgcrhbOR8.bqiqahefHIBX6gZ7Vi2.ntCCyfBN7py	Sabina	Altieri	4	hutWorker58@gmail.com	\N	t	\N	t	\N	\N
66	$2b$10$YrsdPmxwolVNfKqb/UtMEuK0jjlDM36GD9qyA9bt2P.wW12Mbdh/O	Placido	Foglia	4	hutWorker59@gmail.com	\N	t	\N	f	\N	\N
67	$2b$10$pGIKGpxQtiLTR.NnxN3IGeO00Opeb.67yCMGPXxqRMhEzVeLmdLBO	Quiteria	Catarsi	4	hutWorker60@gmail.com	\N	t	\N	t	\N	\N
68	$2b$10$DG8uZP/B.80s6dYSDPhAXOEY/o7N4jOSXY4uS5nttih14bfRGIniy	Desdemona	Carrozzo	4	hutWorker61@gmail.com	\N	t	\N	f	\N	\N
69	$2b$10$XpAnHoQSNLa6S5WLdgYcBeGi49oEpRz55uEg.qPz3B49GH3Onyf4m	Giambattista	Gambino	4	hutWorker62@gmail.com	\N	t	\N	t	\N	\N
70	$2b$10$3APAZXHiIa8B5fxqVqZyGOlcXJfbSwilo/ZGEqiHnwgsiu5VQDdNS	Flaminia	Mazzotta	4	hutWorker63@gmail.com	\N	t	\N	f	\N	\N
71	$2b$10$k/YHSPH8PFEuWHKfTYaYTOnlyae6j5Xq0L77oj2yfiS7/yvtu5PVu	Boris	Medici	4	hutWorker64@gmail.com	\N	t	\N	t	\N	\N
72	$2b$10$JBsk.uJNCxbeF/i74Ke2reDcAjKj8Iqn1cBmRAp3al/4Va4w6OeTC	Venusta	Bertani	4	hutWorker65@gmail.com	\N	t	\N	f	\N	\N
73	$2b$10$Gw47AScCthtSHx.NUPjd4etkPEu335t7SOcjEWJTbGjGkNY851wuG	Antonia	Gioia	4	hutWorker66@gmail.com	\N	t	\N	t	\N	\N
74	$2b$10$vifha.Xzp7YBmukWc2rRYu5nHq45z.e57LSXikZv.Y4AW1fhRloFe	Cuzia	Grosso	4	hutWorker67@gmail.com	\N	t	\N	f	\N	\N
75	$2b$10$OBvcdssT12APyRhd.ezKVObT.F2.Ii5ocUb6OURhK11ksZl.bWXH6	Adelaide	Narcisi	4	hutWorker68@gmail.com	\N	t	\N	t	\N	\N
76	$2b$10$vgm66i8o3MXk5hYgAVQNjO7kJuimk1XOgdZPO8qzsO7gKYsuFVxAm	Fazio	Coccia	4	hutWorker69@gmail.com	\N	t	\N	f	\N	\N
77	$2b$10$0eZ8vRw7jxeLPDLnvkBT8.PqFd2wwDZbZAabwyRb1Ya9lWJccVfNe	Roberta	D'Amore	4	hutWorker70@gmail.com	\N	t	\N	t	\N	\N
78	$2b$10$NymAoXK3bzV1wwPDz7qsQODYk.r2QmGu7nhuPfLhGVtdPnzTNK2uO	Tecla	Pasquini	4	hutWorker71@gmail.com	\N	t	\N	f	\N	\N
79	$2b$10$4BovtmhaRFFx256nkjngLuwhnX6TE7Ah17ov6bnnIiReRNOjcMLSq	Osanna	Cammarata	4	hutWorker72@gmail.com	\N	t	\N	t	\N	\N
80	$2b$10$KHgfNxK5UWBlE4lAdXWWrOrnfUyIqR83SfanTxEZZ8nalzoWkijFe	Severa	Siino	4	hutWorker73@gmail.com	\N	t	\N	f	\N	\N
81	$2b$10$TuOGte97FfNhX2BiTMWMLuv6TZw5sFL0fdTKwam34GmiPe6ghBSaa	Osvaldo	Cipriano	4	hutWorker74@gmail.com	\N	t	\N	t	\N	\N
82	$2b$10$pVGOe/qXRUese.qQwtw1XOxJfab1jIkAa.Ws.For.FBpCpkTa50gG	Graciliano	Favara	4	hutWorker75@gmail.com	\N	t	\N	f	\N	\N
83	$2b$10$L0hMYaT6qlVp8OZIzh1cI.pZI/i/WJVLhgbgJOCRnNY.QX3ZMf6P.	Lodovico	Tucci	4	hutWorker76@gmail.com	\N	t	\N	t	\N	\N
84	$2b$10$/kaPrdMIBwBD5qCpXCDEK.guqzd1bqzq9gHiz2p/TLrNPzvsax7PS	Valentina	Santarsiero	4	hutWorker77@gmail.com	\N	t	\N	f	\N	\N
85	$2b$10$NbNmfzwAADG/egT6qqpnPuAjZOk1CVITtRFwMDF0eKX7C0Lk4Ayjq	Virone	De Carolis	4	hutWorker78@gmail.com	\N	t	\N	t	\N	\N
86	$2b$10$5Y4DKkeubiVra.xXwz6LNuHBJtpXZ1z.xTGZ.nix21dmif/XeqUwa	Euclide	Daniele	4	hutWorker79@gmail.com	\N	t	\N	f	\N	\N
87	$2b$10$V0rP21Bs2S7I72YBXE/fJ.1vqLg66kkn6QvpfqaPIjNqk.8yg/Vs.	Fernanda	De Rosa	4	hutWorker80@gmail.com	\N	t	\N	t	\N	\N
88	$2b$10$dss.w3K2zjgnGJzrRxGuJuqKk20IAh0mkIr9vT0w9sAfMN7JZFvSW	Venusto	Liberati	4	hutWorker81@gmail.com	\N	t	\N	f	\N	\N
89	$2b$10$LH/IX8wb06j6dBerbsavf.Fsf5ujAunhWnhAvEIjKxqO0Nz8gH.sG	Crescenzio	Golinelli	4	hutWorker82@gmail.com	\N	t	\N	t	\N	\N
90	$2b$10$i3a4bfNc02B2ft5SBCmgsuQDZ93kZeeSuB7MavQf59e5RwzM2w1T6	Marinetta	Aprile	4	hutWorker83@gmail.com	\N	t	\N	f	\N	\N
91	$2b$10$fXJz9YKXUqnNZ1X.OFrcUuPG7/kd6uhngekNNuh5qKoX89KLwG7fS	Sabrina	Manica	4	hutWorker84@gmail.com	\N	t	\N	t	\N	\N
92	$2b$10$PqeAbLu2H5FjpLzglrWXPuaoV1AmuDNp5HtC3t/X3wd3qmdQ3nbk2	Irma	Cusumano	4	hutWorker85@gmail.com	\N	t	\N	f	\N	\N
93	$2b$10$MhFB7AJyFpLvhxBusr8JT.TgyVKfhDtcjY0wGrTArtNAik1qTQ6XC	Beato	Scognamiglio	4	hutWorker86@gmail.com	\N	t	\N	t	\N	\N
94	$2b$10$xH.J/rgP65CKj66w5u2TieV1mKrWsXFxTV1OT18aoc3SUaiSlrMZC	Carmela	Cavalli	4	hutWorker87@gmail.com	\N	t	\N	f	\N	\N
95	$2b$10$sTv/fulafgTi4fmZZ5W8Fuijvw5SME45jbH/fsRZE7GCWokrPyosW	Lia	Bedini	4	hutWorker88@gmail.com	\N	t	\N	t	\N	\N
96	$2b$10$lMmrYXsOTk2il8XhIuWHSO37GNqzpeMH4XJL26L4d4LighT/n2jwK	Euclide	Caradonna	4	hutWorker89@gmail.com	\N	t	\N	f	\N	\N
97	$2b$10$QFXuwXkfKHuks8KwT5o.YukiXeGS3oInRDPM4gpeH3Ir1hUvtW3CO	Santina	Tallarico	4	hutWorker90@gmail.com	\N	t	\N	t	\N	\N
98	$2b$10$Y2PP7TYU7KHyui1iMUfYf.IRjgFfRpRufe2.dfGvQoqYhfLdshc7m	Rossella	Scherini	4	hutWorker91@gmail.com	\N	t	\N	f	\N	\N
99	$2b$10$XuIIN0WwJeM7UCj.izHZUuYy3u.PoCeKwwZvMaCSGv7woGix5JGt.	Viola	Ruberto	4	hutWorker92@gmail.com	\N	t	\N	t	\N	\N
100	$2b$10$6TTutyVB0tw0yZOrCKyaMeF8wYOZ8yF09WxqV7WaYJz/xirml5M4K	Deodato	Concas	4	hutWorker93@gmail.com	\N	t	\N	f	\N	\N
101	$2b$10$JwaBQwqKZBzdJmRncavxxeyt5H8ep1zA1CMPlotrChZ0RlGYazuwe	Prisca	Cavalieri	4	hutWorker94@gmail.com	\N	t	\N	t	\N	\N
102	$2b$10$zlfrNpZjJnTJ6QDpBu2mAeMA0BPiO9tdWXISJ.ihZzBjMmF4kJQsu	Donna	Iannello	4	hutWorker95@gmail.com	\N	t	\N	f	\N	\N
103	$2b$10$fcaib5ByKtXj0jr89xqr0ezpB9yDTVwl5ToS2GS4v/rkwXvfnFCwW	Laurentino	Biccari	4	hutWorker96@gmail.com	\N	t	\N	t	\N	\N
104	$2b$10$dFQHUSF0ZSkHz.aRg4jwfu4oTsIAbb9oSkZrC9BhRW.IE86k8beF.	Debora	Lupi	4	hutWorker97@gmail.com	\N	t	\N	f	\N	\N
105	$2b$10$MS2nmKLpo/tjNqRfUhzJAuTMyXaNmptuGNjqYlqTLPlry.29pHSNO	Proteo	Lupi	4	hutWorker98@gmail.com	\N	t	\N	t	\N	\N
106	$2b$10$s8bh4AllLS6XnSzrheXKP.u1e9CYuZEMYvdb2NmwAJWwVIXIXTYkC	Carolina	Longhi	4	hutWorker99@gmail.com	\N	t	\N	f	\N	\N
107	$2b$10$fN/2Ek3ghhSdkjNMvRlJKOvYqzigv12Z4qElv2uswvpHHwvBJPrKq	Virgilio	Sartor	4	hutWorker100@gmail.com	\N	t	\N	t	\N	\N
108	$2b$10$xlyhXILwrmkYMIyuKff2Vuoo.1Xmfiaz0VhMu8eXtjH9GXIOSplPu	Celso	Cannata	4	hutWorker101@gmail.com	\N	t	\N	f	\N	\N
109	$2b$10$7sDzPYrO/wvE/NiPF55MPuuYh1Pz8es62Etg7EmyzQJoY3GJ5Pa5W	Vinicio	Tesi	4	hutWorker102@gmail.com	\N	t	\N	t	\N	\N
110	$2b$10$e2dppqDcPbOI7eG34jIdsOT1GA9wykD1HoBg51j5to93HDu.cK4jG	Gerardo	Crispino	4	hutWorker103@gmail.com	\N	t	\N	f	\N	\N
111	$2b$10$SQRgvB3jRSu7UYgAESI9ROwX5DLDb1RvwkshSbPPau37R6b0DgS9a	Amina	Distefano	4	hutWorker104@gmail.com	\N	t	\N	t	\N	\N
112	$2b$10$Tw.GVJpjodIHjPM/yYz5HOuIhAsCyDMKya9/EPPbR3GyaZiq9ZZC2	Cointa	Granata	4	hutWorker105@gmail.com	\N	t	\N	f	\N	\N
113	$2b$10$zuM9hfLyeBOlfgxPgU0aA.sDCCkfQmM8pZyvfVfmv90gvsvgb5lay	Evaristo	Pichler	4	hutWorker106@gmail.com	\N	t	\N	t	\N	\N
114	$2b$10$.slKxSV9Q9OnNb0j7Tjy4eoJ1y1WQzqnhzLxD1MA0qtighGEI0xx.	Iside	Anselmo	4	hutWorker107@gmail.com	\N	t	\N	f	\N	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 49, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 108, true);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 256, true);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 475, true);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_hikes_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

