--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: insert_hut(integer, double precision, double precision, integer, numeric, character varying, character varying, character varying, character varying, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut(user_id integer, lat double precision, lon double precision, number_of_beds integer, price numeric, title character varying, address character varying, owner_name character varying, website character varying, elevation numeric) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation
    );
    END
    $$;


--
-- Name: insert_parking_lot(integer, double precision, double precision, character varying, integer, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_parking_lot(user_id integer, lat double precision, lon double precision, name character varying, max_cars integer, address character varying, city character varying, country character varying, region character varying, province character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country) FROM stdin;
1	2	0.00	0	0.00	0	Airline Trail - Detour		/static/gpx/001_Airline_Trail___Detour.gpx	0.00				USA
2	2	0.00	0	0.00	2	Airline Trail		/static/gpx/002_Airline_Trail.gpx	0.00				USA
3	2	0.00	0	0.00	2	Colchester Railroad		/static/gpx/003_Colchester_Railroad.gpx	0.00				USA
4	2	0.00	0	0.00	0	Willimantic Flower Bridge		/static/gpx/004_Willimantic_Flower_Bridge.gpx	0.00				USA
5	2	0.00	0	0.00	0	Willimantic Pedestrian Bridge		/static/gpx/005_Willimantic_Pedestrian_Bridge.gpx	0.00				USA
6	2	0.00	0	0.00	2	Two Sister'S Preserve Loop Trail		/static/gpx/006_Two_Sister_S_Preserve_Loop_Trail.gpx	0.00				USA
7	2	0.00	0	0.00	2	Putnam River Trail		/static/gpx/007_Putnam_River_Trail.gpx	0.00				USA
8	2	0.00	0	0.00	2	Airline Trail Bypass		/static/gpx/008_Airline_Trail_Bypass.gpx	0.00				USA
9	2	0.00	0	0.00	0	Indian Neck		/static/gpx/009_Indian_Neck.gpx	0.00				USA
10	2	0.00	0	0.00	2	Stony Creek		/static/gpx/010_Stony_Creek.gpx	0.00				USA
11	2	0.00	0	0.00	1	Quarry-Westwoods		/static/gpx/011_Quarry_Westwoods.gpx	0.00				USA
12	2	0.00	0	0.00	1	Short Beach		/static/gpx/012_Short_Beach.gpx	0.00				USA
13	2	0.00	0	0.00	2	Charter Oak Greenway		/static/gpx/013_Charter_Oak_Greenway.gpx	0.00				USA
14	2	0.00	0	0.00	1	Bissell Greenway		/static/gpx/014_Bissell_Greenway.gpx	0.00				USA
15	2	0.00	0	0.00	0	Riverfront Trail System		/static/gpx/015_Riverfront_Trail_System.gpx	0.00				USA
16	2	0.00	0	0.00	2	Millers Pond Park Trail		/static/gpx/016_Millers_Pond_Park_Trail.gpx	0.00				USA
17	2	0.00	0	0.00	2	Mattabesett Trail		/static/gpx/017_Mattabesett_Trail.gpx	0.00				USA
18	2	0.00	0	0.00	2	Jefferson Park Trail		/static/gpx/018_Jefferson_Park_Trail.gpx	0.00				USA
19	2	0.00	0	0.00	2	Cockaponset Trail		/static/gpx/019_Cockaponset_Trail.gpx	0.00				USA
20	2	0.00	0	0.00	0	Mt. Nebo Park		/static/gpx/020_Mt__Nebo_Park.gpx	0.00				USA
21	2	0.00	0	0.00	2	 		/static/gpx/021__.gpx	0.00				USA
22	2	0.00	0	0.00	2	Proposed Trail		/static/gpx/022_Proposed_Trail.gpx	0.00				USA
23	2	0.00	0	0.00	2	Blinnshed Ridge Trail		/static/gpx/023_Blinnshed_Ridge_Trail.gpx	0.00				USA
24	2	0.00	0	0.00	2	Neck River Trail		/static/gpx/024_Neck_River_Trail.gpx	0.00				USA
25	2	0.00	0	0.00	2	Unnamed Trail		/static/gpx/025_Unnamed_Trail.gpx	0.00				USA
26	2	0.00	0	0.00	2	Oil Mill Brook Trail		/static/gpx/026_Oil_Mill_Brook_Trail.gpx	0.00				USA
27	2	0.00	0	0.00	2	Chatfield Trail		/static/gpx/027_Chatfield_Trail.gpx	0.00				USA
28	2	0.00	0	0.00	2	Unamed Trail		/static/gpx/028_Unamed_Trail.gpx	0.00				USA
29	2	0.00	0	0.00	2	Lost Pond Trail		/static/gpx/029_Lost_Pond_Trail.gpx	0.00				USA
30	2	0.00	0	0.00	2	Ccc Camp Hadley Trail		/static/gpx/030_Ccc_Camp_Hadley_Trail.gpx	0.00				USA
31	2	0.00	0	0.00	2	Double Loop Trail		/static/gpx/031_Double_Loop_Trail.gpx	0.00				USA
32	2	0.00	0	0.00	2	Over Brook Trail		/static/gpx/032_Over_Brook_Trail.gpx	0.00				USA
33	2	0.00	0	0.00	2	Cockaponset Forest Trail		/static/gpx/033_Cockaponset_Forest_Trail.gpx	0.00				USA
34	2	0.00	0	0.00	2	Pattaconk Trail		/static/gpx/034_Pattaconk_Trail.gpx	0.00				USA
35	2	0.00	0	0.00	2	Westwoods Forest Trail		/static/gpx/035_Westwoods_Forest_Trail.gpx	0.00				USA
36	2	0.00	0	0.00	2	Blinnshed Loop Trail		/static/gpx/036_Blinnshed_Loop_Trail.gpx	0.00				USA
37	2	0.00	0	0.00	2	Unnamed Tsail		/static/gpx/037_Unnamed_Tsail.gpx	0.00				USA
38	2	0.00	0	0.00	1	Messerschmidt Wma Trail		/static/gpx/038_Messerschmidt_Wma_Trail.gpx	0.00				USA
39	2	0.00	0	0.00	2	Westwoods Nature Trail		/static/gpx/039_Westwoods_Nature_Trail.gpx	0.00				USA
40	2	0.00	0	0.00	2	Enduro		/static/gpx/040_Enduro.gpx	0.00				USA
41	2	0.00	0	0.00	2	Land Trust Trail		/static/gpx/041_Land_Trust_Trail.gpx	0.00				USA
42	2	0.00	0	0.00	1	Beaver Brook Park Trail		/static/gpx/042_Beaver_Brook_Park_Trail.gpx	0.00				USA
43	2	0.00	0	0.00	1	Housatonic Forest Trail		/static/gpx/043_Housatonic_Forest_Trail.gpx	0.00				USA
44	2	0.00	0	0.00	2	Farmington Canal Trail		/static/gpx/044_Farmington_Canal_Trail.gpx	0.00				USA
45	2	0.00	0	0.00	2	Beckley Furnace Park Path		/static/gpx/045_Beckley_Furnace_Park_Path.gpx	0.00				USA
46	2	0.00	0	0.00	0	Farmington River Trail		/static/gpx/046_Farmington_River_Trail.gpx	0.00				USA
47	2	0.00	0	0.00	2	Farminton Canal Trail		/static/gpx/047_Farminton_Canal_Trail.gpx	0.00				USA
48	2	0.00	0	0.00	2	Farminton River Trail		/static/gpx/048_Farminton_River_Trail.gpx	0.00				USA
49	2	0.00	0	0.00	2	Hop River Trail		/static/gpx/049_Hop_River_Trail.gpx	0.00				USA
50	2	0.00	0	0.00	0	Hoprivertrail - Detouraround316		/static/gpx/050_Hoprivertrail___Detouraround316.gpx	0.00				USA
51	2	0.00	0	0.00	0	Hop River Trail - Long Hill Rd.		/static/gpx/051_Hop_River_Trail___Long_Hill_Rd_.gpx	0.00				USA
52	2	0.00	0	0.00	2	Hop River Trail - Rockville Spur		/static/gpx/052_Hop_River_Trail___Rockville_Spur.gpx	0.00				USA
53	2	0.00	0	0.00	1	Housatonic Rail Trail		/static/gpx/053_Housatonic_Rail_Trail.gpx	0.00				USA
54	2	0.00	0	0.00	1	Middletown Bikeway		/static/gpx/054_Middletown_Bikeway.gpx	0.00				USA
55	2	0.00	0	0.00	2	Mattabesett Trolley Trail		/static/gpx/055_Mattabesett_Trolley_Trail.gpx	0.00				USA
56	2	0.00	0	0.00	1	Moosup Valley State Park Trail		/static/gpx/056_Moosup_Valley_State_Park_Trail.gpx	0.00				USA
57	2	0.00	0	0.00	2	Quinnebaug River Trail		/static/gpx/057_Quinnebaug_River_Trail.gpx	0.00				USA
58	2	0.00	0	0.00	1	Tracey Road Trail		/static/gpx/058_Tracey_Road_Trail.gpx	0.00				USA
59	2	0.00	0	0.00	0	Trolley Trail		/static/gpx/059_Trolley_Trail.gpx	0.00				USA
60	2	0.00	0	0.00	2	Quinnebaug Hatchery Trail		/static/gpx/060_Quinnebaug_Hatchery_Trail.gpx	0.00				USA
61	2	0.00	0	0.00	2	Hopeville Park Trail		/static/gpx/061_Hopeville_Park_Trail.gpx	0.00				USA
62	2	0.00	0	0.00	1	Hopeville Park Path		/static/gpx/062_Hopeville_Park_Path.gpx	0.00				USA
63	2	0.00	0	0.00	2	Nehantic Trail		/static/gpx/063_Nehantic_Trail.gpx	0.00				USA
64	2	0.00	0	0.00	1	Camp Columbia Trail		/static/gpx/064_Camp_Columbia_Trail.gpx	0.00				USA
65	2	0.00	0	0.00	2	Shelton Land Trust Trail		/static/gpx/065_Shelton_Land_Trust_Trail.gpx	0.00				USA
66	2	0.00	0	0.00	1	Dinosaur Park Sidewalk		/static/gpx/066_Dinosaur_Park_Sidewalk.gpx	0.00				USA
67	2	0.00	0	0.00	2	Dinosaur Park Trail		/static/gpx/067_Dinosaur_Park_Trail.gpx	0.00				USA
68	2	0.00	0	0.00	1	Access Road		/static/gpx/068_Access_Road.gpx	0.00				USA
69	2	0.00	0	0.00	0	Day Pond Park Path		/static/gpx/069_Day_Pond_Park_Path.gpx	0.00				USA
70	2	0.00	0	0.00	1	Day Pond Park Trail		/static/gpx/070_Day_Pond_Park_Trail.gpx	0.00				USA
71	2	0.00	0	0.00	1	Salmon River Trail		/static/gpx/071_Salmon_River_Trail.gpx	0.00				USA
72	2	0.00	0	0.00	0	Salmon River Trial		/static/gpx/072_Salmon_River_Trial.gpx	0.00				USA
73	2	0.00	0	0.00	0	Dennis Hill Park Trail		/static/gpx/073_Dennis_Hill_Park_Trail.gpx	0.00				USA
74	2	0.00	0	0.00	2	Railroad Trail		/static/gpx/074_Railroad_Trail.gpx	0.00				USA
75	2	0.00	0	0.00	0	Gillette Castle Trail		/static/gpx/075_Gillette_Castle_Trail.gpx	0.00				USA
76	2	0.00	0	0.00	0	Kent Falls Park Path		/static/gpx/076_Kent_Falls_Park_Path.gpx	0.00				USA
77	2	0.00	0	0.00	1	Kent Falls Park Trail		/static/gpx/077_Kent_Falls_Park_Trail.gpx	0.00				USA
78	2	0.00	0	0.00	0	Lovers Leap Park Trail		/static/gpx/078_Lovers_Leap_Park_Trail.gpx	0.00				USA
79	2	0.00	0	0.00	2	Enders Forest Trail		/static/gpx/079_Enders_Forest_Trail.gpx	0.00				USA
80	2	0.00	0	0.00	2	Gay City Park Path		/static/gpx/080_Gay_City_Park_Path.gpx	0.00				USA
81	2	0.00	0	0.00	0	Gay City Park Trail		/static/gpx/081_Gay_City_Park_Trail.gpx	0.00				USA
82	2	0.00	0	0.00	1	Split Rock Trail		/static/gpx/082_Split_Rock_Trail.gpx	0.00				USA
83	2	0.00	0	0.00	1	Gillette Castle Path		/static/gpx/083_Gillette_Castle_Path.gpx	0.00				USA
84	2	0.00	0	0.00	2	Great Pond Forest Trail		/static/gpx/084_Great_Pond_Forest_Trail.gpx	0.00				USA
85	2	0.00	0	0.00	1	Haddam Meadows Park Trail		/static/gpx/085_Haddam_Meadows_Park_Trail.gpx	0.00				USA
86	2	0.00	0	0.00	2	Haley Farm Park Trail		/static/gpx/086_Haley_Farm_Park_Trail.gpx	0.00				USA
87	2	0.00	0	0.00	0	Hammonasset Park Path		/static/gpx/087_Hammonasset_Park_Path.gpx	0.00				USA
88	2	0.00	0	0.00	1	Nature Trail		/static/gpx/088_Nature_Trail.gpx	0.00				USA
89	2	0.00	0	0.00	1	Hammonasset Bike Path		/static/gpx/089_Hammonasset_Bike_Path.gpx	0.00				USA
90	2	0.00	0	0.00	1	Hammonasset Park Boardwalk		/static/gpx/090_Hammonasset_Park_Boardwalk.gpx	0.00				USA
91	2	0.00	0	0.00	2	Meigs Point Jetty		/static/gpx/091_Meigs_Point_Jetty.gpx	0.00				USA
92	2	0.00	0	0.00	2	Willard Island Nature Trail		/static/gpx/092_Willard_Island_Nature_Trail.gpx	0.00				USA
93	2	0.00	0	0.00	2	Moraine Nature Trail		/static/gpx/093_Moraine_Nature_Trail.gpx	0.00				USA
94	2	0.00	0	0.00	0	Haystack Park Trail		/static/gpx/094_Haystack_Park_Trail.gpx	0.00				USA
95	2	0.00	0	0.00	2	Higganum Reservoir Park Trail		/static/gpx/095_Higganum_Reservoir_Park_Trail.gpx	0.00				USA
96	2	0.00	0	0.00	1	Appalachian Trail		/static/gpx/096_Appalachian_Trail.gpx	0.00				USA
97	2	0.00	0	0.00	2	Mohawk Trail		/static/gpx/097_Mohawk_Trail.gpx	0.00				USA
98	2	0.00	0	0.00	1	Pine Knob Loop		/static/gpx/098_Pine_Knob_Loop.gpx	0.00				USA
99	2	0.00	0	0.00	0	Appalachian/Pine Knob Loop		/static/gpx/099_Appalachian_Pine_Knob_Loop.gpx	0.00				USA
100	2	0.00	0	0.00	1	White Mountain Trail		/static/gpx/100_White_Mountain_Trail.gpx	0.00				USA
101	2	0.00	0	0.00	1	River Trail		/static/gpx/101_River_Trail.gpx	0.00				USA
102	2	0.00	0	0.00	0	Hurd Park Trail		/static/gpx/102_Hurd_Park_Trail.gpx	0.00				USA
103	2	0.00	0	0.00	0	Hurd Park Path		/static/gpx/103_Hurd_Park_Path.gpx	0.00				USA
104	2	0.00	0	0.00	0	Paugussett Trail		/static/gpx/104_Paugussett_Trail.gpx	0.00				USA
105	2	0.00	0	0.00	1	Waterfall Trail		/static/gpx/105_Waterfall_Trail.gpx	0.00				USA
106	2	0.00	0	0.00	1	Paugussett Trail Connector		/static/gpx/106_Paugussett_Trail_Connector.gpx	0.00				USA
107	2	0.00	0	0.00	0	Minetto Park Trail		/static/gpx/107_Minetto_Park_Trail.gpx	0.00				USA
108	2	0.00	0	0.00	2	Coincident Macedonia Brook Rd		/static/gpx/108_Coincident_Macedonia_Brook_Rd.gpx	0.00				USA
109	2	0.00	0	0.00	0	Coincident Weber Road		/static/gpx/109_Coincident_Weber_Road.gpx	0.00				USA
110	2	0.00	0	0.00	0	Macedonia Ridge Trail		/static/gpx/110_Macedonia_Ridge_Trail.gpx	0.00				USA
111	2	0.00	0	0.00	0	Cobble Mountain Trail		/static/gpx/111_Cobble_Mountain_Trail.gpx	0.00				USA
112	2	0.00	0	0.00	2	Shenipsit Trail		/static/gpx/112_Shenipsit_Trail.gpx	0.00				USA
113	2	0.00	0	0.00	2	Meshomasic Forest Trail		/static/gpx/113_Meshomasic_Forest_Trail.gpx	0.00				USA
114	2	0.00	0	0.00	1	Crest Trail		/static/gpx/114_Crest_Trail.gpx	0.00				USA
115	2	0.00	0	0.00	1	Campground Trail		/static/gpx/115_Campground_Trail.gpx	0.00				USA
116	2	0.00	0	0.00	2	Brook Trail		/static/gpx/116_Brook_Trail.gpx	0.00				USA
117	2	0.00	0	0.00	0	Kettletown Park Trail		/static/gpx/117_Kettletown_Park_Trail.gpx	0.00				USA
118	2	0.00	0	0.00	0	North Ridge Trail		/static/gpx/118_North_Ridge_Trail.gpx	0.00				USA
119	2	0.00	0	0.00	1	North Ridge Loop Trail		/static/gpx/119_North_Ridge_Loop_Trail.gpx	0.00				USA
120	2	0.00	0	0.00	0	Miller Brook Connector Trail		/static/gpx/120_Miller_Brook_Connector_Trail.gpx	0.00				USA
121	2	0.00	0	0.00	2	Miller Trail		/static/gpx/121_Miller_Trail.gpx	0.00				USA
122	2	0.00	0	0.00	2	Miller Trail Spur		/static/gpx/122_Miller_Trail_Spur.gpx	0.00				USA
123	2	0.00	0	0.00	0	Pomperaug Trail		/static/gpx/123_Pomperaug_Trail.gpx	0.00				USA
124	2	0.00	0	0.00	0	Brook Trail Access		/static/gpx/124_Brook_Trail_Access.gpx	0.00				USA
125	2	0.00	0	0.00	0	Waramaug Lake Park Trail		/static/gpx/125_Waramaug_Lake_Park_Trail.gpx	0.00				USA
126	2	0.00	0	0.00	2	Well Groomed Trail		/static/gpx/126_Well_Groomed_Trail.gpx	0.00				USA
127	2	0.00	0	0.00	1	Mashamoquet Brook Park Trail		/static/gpx/127_Mashamoquet_Brook_Park_Trail.gpx	0.00				USA
128	2	0.00	0	0.00	1	Shenipsit Trail Spur		/static/gpx/128_Shenipsit_Trail_Spur.gpx	0.00				USA
129	2	0.00	0	0.00	0	Shenipsit		/static/gpx/129_Shenipsit.gpx	0.00				USA
130	2	0.00	0	0.00	2	Nassahegon Forest Trail		/static/gpx/130_Nassahegon_Forest_Trail.gpx	0.00				USA
131	2	0.00	0	0.00	1	Tunxis Trail		/static/gpx/131_Tunxis_Trail.gpx	0.00				USA
132	2	0.00	0	0.00	0	Black Spruce Bog Trail		/static/gpx/132_Black_Spruce_Bog_Trail.gpx	0.00				USA
133	2	0.00	0	0.00	2	Mohawk Forest Trail		/static/gpx/133_Mohawk_Forest_Trail.gpx	0.00				USA
134	2	0.00	0	0.00	2	Ethan Allen Youth Trail		/static/gpx/134_Ethan_Allen_Youth_Trail.gpx	0.00				USA
135	2	0.00	0	0.00	2	Punch Brook Trail		/static/gpx/135_Punch_Brook_Trail.gpx	0.00				USA
136	2	0.00	0	0.00	0	Red Cedar Lake Trail		/static/gpx/136_Red_Cedar_Lake_Trail.gpx	0.00				USA
137	2	0.00	0	0.00	0	Under Mountain Trail		/static/gpx/137_Under_Mountain_Trail.gpx	0.00				USA
138	2	0.00	0	0.00	2	Mount Tom Trail		/static/gpx/138_Mount_Tom_Trail.gpx	0.00				USA
139	2	0.00	0	0.00	2	Naugatuck Trail		/static/gpx/139_Naugatuck_Trail.gpx	0.00				USA
140	2	0.00	0	0.00	1	Nehantic Forest Trail		/static/gpx/140_Nehantic_Forest_Trail.gpx	0.00				USA
141	2	0.00	0	0.00	2	Naugatuck Forest Trail		/static/gpx/141_Naugatuck_Forest_Trail.gpx	0.00				USA
142	2	0.00	0	0.00	2	Naugatuck Spur		/static/gpx/142_Naugatuck_Spur.gpx	0.00				USA
143	2	0.00	0	0.00	2	Whitemore Trail		/static/gpx/143_Whitemore_Trail.gpx	0.00				USA
144	2	0.00	0	0.00	2	Quinnipiac Trail		/static/gpx/144_Quinnipiac_Trail.gpx	0.00				USA
145	2	0.00	0	0.00	0	Nehantic Forest Trai		/static/gpx/145_Nehantic_Forest_Trai.gpx	0.00				USA
146	2	0.00	0	0.00	2	Nepaug Forest Trail		/static/gpx/146_Nepaug_Forest_Trail.gpx	0.00				USA
147	2	0.00	0	0.00	1	Naugatuck		/static/gpx/147_Naugatuck.gpx	0.00				USA
148	2	0.00	0	0.00	2	Nyantaquit Trail		/static/gpx/148_Nyantaquit_Trail.gpx	0.00				USA
149	2	0.00	0	0.00	2	Tipping Rock Loop Trail		/static/gpx/149_Tipping_Rock_Loop_Trail.gpx	0.00				USA
150	2	0.00	0	0.00	1	Valley Outlook Trail		/static/gpx/150_Valley_Outlook_Trail.gpx	0.00				USA
151	2	0.00	0	0.00	2	Shelter 4 Loop Trail		/static/gpx/151_Shelter_4_Loop_Trail.gpx	0.00				USA
152	2	0.00	0	0.00	0	Osbornedale Park Trail		/static/gpx/152_Osbornedale_Park_Trail.gpx	0.00				USA
153	2	0.00	0	0.00	0	Unnamed		/static/gpx/153_Unnamed.gpx	0.00				USA
154	2	0.00	0	0.00	0	Paugnut Forest Trail		/static/gpx/154_Paugnut_Forest_Trail.gpx	0.00				USA
155	2	0.00	0	0.00	2	Charles L Pack Trail		/static/gpx/155_Charles_L_Pack_Trail.gpx	0.00				USA
156	2	0.00	0	0.00	0	Peoples Forest Trail		/static/gpx/156_Peoples_Forest_Trail.gpx	0.00				USA
157	2	0.00	0	0.00	2	Putnam Memorial Trail		/static/gpx/157_Putnam_Memorial_Trail.gpx	0.00				USA
158	2	0.00	0	0.00	1	Platt Hill Park Trail		/static/gpx/158_Platt_Hill_Park_Trail.gpx	0.00				USA
159	2	0.00	0	0.00	0	Metacomet Trail		/static/gpx/159_Metacomet_Trail.gpx	0.00				USA
160	2	0.00	0	0.00	2	Metacomet Trail Bypass		/static/gpx/160_Metacomet_Trail_Bypass.gpx	0.00				USA
161	2	0.00	0	0.00	0	Penwood Park Trail		/static/gpx/161_Penwood_Park_Trail.gpx	0.00				USA
162	2	0.00	0	0.00	1	Quadick Park Path		/static/gpx/162_Quadick_Park_Path.gpx	0.00				USA
163	2	0.00	0	0.00	0	Quadick Red Trail		/static/gpx/163_Quadick_Red_Trail.gpx	0.00				USA
164	2	0.00	0	0.00	1	Pootatuck Forest Trail		/static/gpx/164_Pootatuck_Forest_Trail.gpx	0.00				USA
165	2	0.00	0	0.00	2	River Highland Park Trail		/static/gpx/165_River_Highland_Park_Trail.gpx	0.00				USA
166	2	0.00	0	0.00	2	Tunxis		/static/gpx/166_Tunxis.gpx	0.00				USA
167	2	0.00	0	0.00	1	Old Furnace Trail		/static/gpx/167_Old_Furnace_Trail.gpx	0.00				USA
168	2	0.00	0	0.00	0	Old Furnace Park Trail		/static/gpx/168_Old_Furnace_Park_Trail.gpx	0.00				USA
169	2	0.00	0	0.00	2	Kestral Trail		/static/gpx/169_Kestral_Trail.gpx	0.00				USA
170	2	0.00	0	0.00	0	Warbler Trail		/static/gpx/170_Warbler_Trail.gpx	0.00				USA
171	2	0.00	0	0.00	1	Muir Trail		/static/gpx/171_Muir_Trail.gpx	0.00				USA
172	2	0.00	0	0.00	0	Shadow Pond Nature Trail		/static/gpx/172_Shadow_Pond_Nature_Trail.gpx	0.00				USA
173	2	0.00	0	0.00	1	Jesse Gerard Trail		/static/gpx/173_Jesse_Gerard_Trail.gpx	0.00				USA
174	2	0.00	0	0.00	1	Robert Ross Trail		/static/gpx/174_Robert_Ross_Trail.gpx	0.00				USA
175	2	0.00	0	0.00	1	Agnes Bowen Trail		/static/gpx/175_Agnes_Bowen_Trail.gpx	0.00				USA
176	2	0.00	0	0.00	0	Elliot Bronson Trail		/static/gpx/176_Elliot_Bronson_Trail.gpx	0.00				USA
177	2	0.00	0	0.00	1	Walt Landgraf Trail		/static/gpx/177_Walt_Landgraf_Trail.gpx	0.00				USA
178	2	0.00	0	0.00	1	Squantz Pond Park Trail		/static/gpx/178_Squantz_Pond_Park_Trail.gpx	0.00				USA
179	2	0.00	0	0.00	0	Putnam Memorial Museum Trail		/static/gpx/179_Putnam_Memorial_Museum_Trail.gpx	0.00				USA
180	2	0.00	0	0.00	1	Quinnipiac Park Trail		/static/gpx/180_Quinnipiac_Park_Trail.gpx	0.00				USA
181	2	0.00	0	0.00	2	Boardwalk		/static/gpx/181_Boardwalk.gpx	0.00				USA
182	2	0.00	0	0.00	0	Rocky Neck Park Sidewalk		/static/gpx/182_Rocky_Neck_Park_Sidewalk.gpx	0.00				USA
183	2	0.00	0	0.00	1	Rocky Neck Park Path		/static/gpx/183_Rocky_Neck_Park_Path.gpx	0.00				USA
184	2	0.00	0	0.00	2	Rocky Neck Park Trail		/static/gpx/184_Rocky_Neck_Park_Trail.gpx	0.00				USA
185	2	0.00	0	0.00	1	Rope Swing		/static/gpx/185_Rope_Swing.gpx	0.00				USA
186	2	0.00	0	0.00	2	Sherwood Island Park Path		/static/gpx/186_Sherwood_Island_Park_Path.gpx	0.00				USA
187	2	0.00	0	0.00	0	Sleeping Giant Park Trail		/static/gpx/187_Sleeping_Giant_Park_Trail.gpx	0.00				USA
188	2	0.00	0	0.00	0	Sherwood Island Nature Trail		/static/gpx/188_Sherwood_Island_Nature_Trail.gpx	0.00				USA
189	2	0.00	0	0.00	1	Sleeping Giant Park Path		/static/gpx/189_Sleeping_Giant_Park_Path.gpx	0.00				USA
190	2	0.00	0	0.00	2	Tower Trail		/static/gpx/190_Tower_Trail.gpx	0.00				USA
191	2	0.00	0	0.00	0	Quinnipiac Trail Spur		/static/gpx/191_Quinnipiac_Trail_Spur.gpx	0.00				USA
192	2	0.00	0	0.00	2	Southford Falls Park Trail		/static/gpx/192_Southford_Falls_Park_Trail.gpx	0.00				USA
193	2	0.00	0	0.00	2	Tunxis Forest Trail		/static/gpx/193_Tunxis_Forest_Trail.gpx	0.00				USA
194	2	0.00	0	0.00	2	Sleeping Giant Trail		/static/gpx/194_Sleeping_Giant_Trail.gpx	0.00				USA
195	2	0.00	0	0.00	2	Stratton Brook Park Path		/static/gpx/195_Stratton_Brook_Park_Path.gpx	0.00				USA
196	2	0.00	0	0.00	1	Bike Trail		/static/gpx/196_Bike_Trail.gpx	0.00				USA
197	2	0.00	0	0.00	1	Stratton Brook Park Trail		/static/gpx/197_Stratton_Brook_Park_Trail.gpx	0.00				USA
198	2	0.00	0	0.00	0	Simsbury Park Trail		/static/gpx/198_Simsbury_Park_Trail.gpx	0.00				USA
199	2	0.00	0	0.00	2	Wolcott Trail		/static/gpx/199_Wolcott_Trail.gpx	0.00				USA
200	2	0.00	0	0.00	2	Madden Fyler Pond Trail		/static/gpx/200_Madden_Fyler_Pond_Trail.gpx	0.00				USA
201	2	0.00	0	0.00	2	Sunny Brook Park Trail		/static/gpx/201_Sunny_Brook_Park_Trail.gpx	0.00				USA
202	2	0.00	0	0.00	0	Fadoir Spring Trail		/static/gpx/202_Fadoir_Spring_Trail.gpx	0.00				USA
203	2	0.00	0	0.00	2	Fadoir Trail		/static/gpx/203_Fadoir_Trail.gpx	0.00				USA
204	2	0.00	0	0.00	1	Walnut Mountain Trail		/static/gpx/204_Walnut_Mountain_Trail.gpx	0.00				USA
205	2	0.00	0	0.00	1	Wolcott		/static/gpx/205_Wolcott.gpx	0.00				USA
206	2	0.00	0	0.00	1	Old Metacomet Trail		/static/gpx/206_Old_Metacomet_Trail.gpx	0.00				USA
207	2	0.00	0	0.00	2	Talcott Mountain Park Trail		/static/gpx/207_Talcott_Mountain_Park_Trail.gpx	0.00				USA
208	2	0.00	0	0.00	1	Falls Brook Trail		/static/gpx/208_Falls_Brook_Trail.gpx	0.00				USA
209	2	0.00	0	0.00	2	Whittemore Glen Trail		/static/gpx/209_Whittemore_Glen_Trail.gpx	0.00				USA
210	2	0.00	0	0.00	1	Wharton Brook Park Trail		/static/gpx/210_Wharton_Brook_Park_Trail.gpx	0.00				USA
211	2	0.00	0	0.00	0	Larkin Bridle Trail		/static/gpx/211_Larkin_Bridle_Trail.gpx	0.00				USA
212	2	0.00	0	0.00	0	Bluff Point Bike Path		/static/gpx/212_Bluff_Point_Bike_Path.gpx	0.00				USA
213	2	0.00	0	0.00	0	Bluff Point Trail		/static/gpx/213_Bluff_Point_Trail.gpx	0.00				USA
214	2	0.00	0	0.00	1	Hrt - Main Street Spur		/static/gpx/214_Hrt___Main_Street_Spur.gpx	0.00				USA
215	2	0.00	0	0.00	2	Laurel Brook Trail		/static/gpx/215_Laurel_Brook_Trail.gpx	0.00				USA
216	2	0.00	0	0.00	2	Wadsworth Falls Park Trail		/static/gpx/216_Wadsworth_Falls_Park_Trail.gpx	0.00				USA
217	2	0.00	0	0.00	2	White Birch Trail		/static/gpx/217_White_Birch_Trail.gpx	0.00				USA
218	2	0.00	0	0.00	2	Red Cedar Trail		/static/gpx/218_Red_Cedar_Trail.gpx	0.00				USA
219	2	0.00	0	0.00	2	Little Falls Trail		/static/gpx/219_Little_Falls_Trail.gpx	0.00				USA
220	2	0.00	0	0.00	2	Deer Trail		/static/gpx/220_Deer_Trail.gpx	0.00				USA
221	2	0.00	0	0.00	2	Rockfall Land Trust Trail		/static/gpx/221_Rockfall_Land_Trust_Trail.gpx	0.00				USA
222	2	0.00	0	0.00	2	Bridge Trail		/static/gpx/222_Bridge_Trail.gpx	0.00				USA
223	2	0.00	0	0.00	2	Main Trail		/static/gpx/223_Main_Trail.gpx	0.00				USA
224	2	0.00	0	0.00	2	American Legion Forest Trail		/static/gpx/224_American_Legion_Forest_Trail.gpx	0.00				USA
225	2	0.00	0	0.00	2	Turkey Vultures Ledges Trail		/static/gpx/225_Turkey_Vultures_Ledges_Trail.gpx	0.00				USA
226	2	0.00	0	0.00	2	Henry R Buck Trail		/static/gpx/226_Henry_R_Buck_Trail.gpx	0.00				USA
227	2	0.00	0	0.00	2	Mashapaug Pond View Trail		/static/gpx/227_Mashapaug_Pond_View_Trail.gpx	0.00				USA
228	2	0.00	0	0.00	2	Bigelow Hollow Park Trail		/static/gpx/228_Bigelow_Hollow_Park_Trail.gpx	0.00				USA
229	2	0.00	0	0.00	2	Breakneck Pond View Trail		/static/gpx/229_Breakneck_Pond_View_Trail.gpx	0.00				USA
230	2	0.00	0	0.00	2	East Ridge Trail		/static/gpx/230_East_Ridge_Trail.gpx	0.00				USA
231	2	0.00	0	0.00	2	Bigelow Pond Loop Trail		/static/gpx/231_Bigelow_Pond_Loop_Trail.gpx	0.00				USA
232	2	0.00	0	0.00	2	Ridge Trail		/static/gpx/232_Ridge_Trail.gpx	0.00				USA
233	2	0.00	0	0.00	2	Nipmuck Trail		/static/gpx/233_Nipmuck_Trail.gpx	0.00				USA
234	2	0.00	0	0.00	2	Mattatuck Trail		/static/gpx/234_Mattatuck_Trail.gpx	0.00				USA
235	2	0.00	0	0.00	2	Black Rock Park Trail		/static/gpx/235_Black_Rock_Park_Trail.gpx	0.00				USA
236	2	0.00	0	0.00	1	Poquonnock River Walk		/static/gpx/236_Poquonnock_River_Walk.gpx	0.00				USA
237	2	0.00	0	0.00	0	Kempf & Shenipsit Trail		/static/gpx/237_Kempf___Shenipsit_Trail.gpx	0.00				USA
238	2	0.00	0	0.00	2	Kempf Trail		/static/gpx/238_Kempf_Trail.gpx	0.00				USA
239	2	0.00	0	0.00	2	Railroad Bed		/static/gpx/239_Railroad_Bed.gpx	0.00				USA
240	2	0.00	0	0.00	2	Mohegan Trail		/static/gpx/240_Mohegan_Trail.gpx	0.00				USA
241	2	0.00	0	0.00	0	Burr Pond Park Trail		/static/gpx/241_Burr_Pond_Park_Trail.gpx	0.00				USA
242	2	0.00	0	0.00	0	Burr Pond Park Path		/static/gpx/242_Burr_Pond_Park_Path.gpx	0.00				USA
243	2	0.00	0	0.00	0	Campbell Falls Trail		/static/gpx/243_Campbell_Falls_Trail.gpx	0.00				USA
244	2	0.00	0	0.00	2	Deep Woods Trail		/static/gpx/244_Deep_Woods_Trail.gpx	0.00				USA
245	2	0.00	0	0.00	2	Chimney Trail		/static/gpx/245_Chimney_Trail.gpx	0.00				USA
246	2	0.00	0	0.00	2	Chimney Connector Trail		/static/gpx/246_Chimney_Connector_Trail.gpx	0.00				USA
247	2	0.00	0	0.00	2	East Woods Trail		/static/gpx/247_East_Woods_Trail.gpx	0.00				USA
248	2	0.00	0	0.00	2	East Woods Connector Trail		/static/gpx/248_East_Woods_Connector_Trail.gpx	0.00				USA
249	2	0.00	0	0.00	2	Covered Bridge Connector Trail		/static/gpx/249_Covered_Bridge_Connector_Trail.gpx	0.00				USA
250	2	0.00	0	0.00	2	Covered Bridge Trail		/static/gpx/250_Covered_Bridge_Trail.gpx	0.00				USA
251	2	0.00	0	0.00	2	Lookout Trail		/static/gpx/251_Lookout_Trail.gpx	0.00				USA
252	2	0.00	0	0.00	2	Chatfield Hollow Park Trail		/static/gpx/252_Chatfield_Hollow_Park_Trail.gpx	0.00				USA
253	2	0.00	0	0.00	2	Lookout Spur Trail		/static/gpx/253_Lookout_Spur_Trail.gpx	0.00				USA
254	2	0.00	0	0.00	2	Chimney Spur Trail		/static/gpx/254_Chimney_Spur_Trail.gpx	0.00				USA
255	2	0.00	0	0.00	2	Deep Woods Access Trail		/static/gpx/255_Deep_Woods_Access_Trail.gpx	0.00				USA
256	2	0.00	0	0.00	2	West Crest Trail		/static/gpx/256_West_Crest_Trail.gpx	0.00				USA
257	2	0.00	0	0.00	2	Chatfield Park Path		/static/gpx/257_Chatfield_Park_Path.gpx	0.00				USA
258	2	0.00	0	0.00	2	Pond Trail		/static/gpx/258_Pond_Trail.gpx	0.00				USA
259	2	0.00	0	0.00	2	Paul F Wildermann		/static/gpx/259_Paul_F_Wildermann.gpx	0.00				USA
260	2	0.00	0	0.00	2	Cockaponset Forest Path		/static/gpx/260_Cockaponset_Forest_Path.gpx	0.00				USA
261	2	0.00	0	0.00	2	Kay Fullerton Trail		/static/gpx/261_Kay_Fullerton_Trail.gpx	0.00				USA
262	2	0.00	0	0.00	1	Quinimay Trail		/static/gpx/262_Quinimay_Trail.gpx	0.00				USA
263	2	0.00	0	0.00	2	Cowboy Way Trail		/static/gpx/263_Cowboy_Way_Trail.gpx	0.00				USA
264	2	0.00	0	0.00	2	Muck Rock Road Trail		/static/gpx/264_Muck_Rock_Road_Trail.gpx	0.00				USA
265	2	0.00	0	0.00	2	Weber Road Trail		/static/gpx/265_Weber_Road_Trail.gpx	0.00				USA
266	2	0.00	0	0.00	2	Beechnut Bog Trail		/static/gpx/266_Beechnut_Bog_Trail.gpx	0.00				USA
267	2	0.00	0	0.00	2	Wood Road Trail		/static/gpx/267_Wood_Road_Trail.gpx	0.00				USA
268	2	0.00	0	0.00	2	Bumpy Hill Road Trail		/static/gpx/268_Bumpy_Hill_Road_Trail.gpx	0.00				USA
269	2	0.00	0	0.00	2	Kristens Way Trail		/static/gpx/269_Kristens_Way_Trail.gpx	0.00				USA
270	2	0.00	0	0.00	2	Messerschmidt Lane Trail		/static/gpx/270_Messerschmidt_Lane_Trail.gpx	0.00				USA
271	2	0.00	0	0.00	2	Tower Hill Connector Trail		/static/gpx/271_Tower_Hill_Connector_Trail.gpx	0.00				USA
272	2	0.00	0	0.00	2	Mattabesset Trail		/static/gpx/272_Mattabesset_Trail.gpx	0.00				USA
273	2	0.00	0	0.00	2	Mattabasset Trail		/static/gpx/273_Mattabasset_Trail.gpx	0.00				USA
274	2	0.00	0	0.00	2	Old Mattebesset Trail		/static/gpx/274_Old_Mattebesset_Trail.gpx	0.00				USA
275	2	0.00	0	0.00	2	Huntington Park Trail		/static/gpx/275_Huntington_Park_Trail.gpx	0.00				USA
276	2	0.00	0	0.00	2	Huntington Ridge Trail		/static/gpx/276_Huntington_Ridge_Trail.gpx	0.00				USA
277	2	0.00	0	0.00	2	Aspetuck Valley Trail		/static/gpx/277_Aspetuck_Valley_Trail.gpx	0.00				USA
278	2	0.00	0	0.00	2	Vista Trail		/static/gpx/278_Vista_Trail.gpx	0.00				USA
279	2	0.00	0	0.00	2	Devils Hopyard Park Trail		/static/gpx/279_Devils_Hopyard_Park_Trail.gpx	0.00				USA
280	2	0.00	0	0.00	2	Witch Hazel/Millington Trail		/static/gpx/280_Witch_Hazel_Millington_Trail.gpx	0.00				USA
281	2	0.00	0	0.00	2	Millington Trail		/static/gpx/281_Millington_Trail.gpx	0.00				USA
282	2	0.00	0	0.00	2	Loop Trail		/static/gpx/282_Loop_Trail.gpx	0.00				USA
283	2	0.00	0	0.00	2	Witch Hazel Trail		/static/gpx/283_Witch_Hazel_Trail.gpx	0.00				USA
284	2	0.00	0	0.00	2	Woodcutters Trail		/static/gpx/284_Woodcutters_Trail.gpx	0.00				USA
285	2	0.00	0	0.00	2	Chapman Falls Trail		/static/gpx/285_Chapman_Falls_Trail.gpx	0.00				USA
286	2	0.00	0	0.00	2	Devils Oven Spur Trail		/static/gpx/286_Devils_Oven_Spur_Trail.gpx	0.00				USA
287	2	0.00	0	0.00	2	Maxs Trail		/static/gpx/287_Maxs_Trail.gpx	0.00				USA
288	2	0.00	0	0.00	2	Machimoodus Park Trail		/static/gpx/288_Machimoodus_Park_Trail.gpx	0.00				USA
289	2	0.00	0	0.00	0	Fishermans Trail		/static/gpx/289_Fishermans_Trail.gpx	0.00				USA
290	2	0.00	0	0.00	2	Ccc Trail		/static/gpx/290_Ccc_Trail.gpx	0.00				USA
291	2	0.00	0	0.00	2	Natchaug Trail		/static/gpx/291_Natchaug_Trail.gpx	0.00				USA
292	2	0.00	0	0.00	2	Natchaug Forest Trail		/static/gpx/292_Natchaug_Forest_Trail.gpx	0.00				USA
293	2	0.00	0	0.00	2	Goodwin Forest Trail		/static/gpx/293_Goodwin_Forest_Trail.gpx	0.00				USA
294	2	0.00	0	0.00	2	Pine Acres Pond Trail		/static/gpx/294_Pine_Acres_Pond_Trail.gpx	0.00				USA
295	2	0.00	0	0.00	2	Brown Hill Pond Trail		/static/gpx/295_Brown_Hill_Pond_Trail.gpx	0.00				USA
296	2	0.00	0	0.00	2	Yellow White Loop Trail		/static/gpx/296_Yellow_White_Loop_Trail.gpx	0.00				USA
297	2	0.00	0	0.00	2	Red Yellow Connector Trail		/static/gpx/297_Red_Yellow_Connector_Trail.gpx	0.00				USA
298	2	0.00	0	0.00	2	Governor'S Island Trail		/static/gpx/298_Governor_S_Island_Trail.gpx	0.00				USA
299	2	0.00	0	0.00	2	Goodwin Foresttrail		/static/gpx/299_Goodwin_Foresttrail.gpx	0.00				USA
300	2	0.00	0	0.00	2	Forest Discovery Trail		/static/gpx/300_Forest_Discovery_Trail.gpx	0.00				USA
301	2	0.00	0	0.00	2	Goodwin Heritage Trail		/static/gpx/301_Goodwin_Heritage_Trail.gpx	0.00				USA
302	2	0.00	0	0.00	2	Crest		/static/gpx/302_Crest.gpx	0.00				USA
303	2	0.00	0	0.00	2	Mansfield Hollow Park Trail		/static/gpx/303_Mansfield_Hollow_Park_Trail.gpx	0.00				USA
304	2	0.00	0	0.00	1	Nipmuck Trail - East Branch		/static/gpx/304_Nipmuck_Trail___East_Branch.gpx	0.00				USA
305	2	0.00	0	0.00	2	Nipmuck Alternate		/static/gpx/305_Nipmuck_Alternate.gpx	0.00				USA
306	2	0.00	0	0.00	0	Mashamoquet Brook Nature Trail		/static/gpx/306_Mashamoquet_Brook_Nature_Trail.gpx	0.00				USA
307	2	0.00	0	0.00	2	Nipmuck Forest Trail		/static/gpx/307_Nipmuck_Forest_Trail.gpx	0.00				USA
308	2	0.00	0	0.00	2	Morey Pond Trail		/static/gpx/308_Morey_Pond_Trail.gpx	0.00				USA
309	2	0.00	0	0.00	2	Nipmuck Foreat Trail		/static/gpx/309_Nipmuck_Foreat_Trail.gpx	0.00				USA
310	2	0.00	0	0.00	2	Pharisee Rock Trail		/static/gpx/310_Pharisee_Rock_Trail.gpx	0.00				USA
311	2	0.00	0	0.00	2	Pachaug Forest Trail		/static/gpx/311_Pachaug_Forest_Trail.gpx	0.00				USA
312	2	0.00	0	0.00	2	Pachaug Trail		/static/gpx/312_Pachaug_Trail.gpx	0.00				USA
313	2	0.00	0	0.00	2	Canonicus Trail		/static/gpx/313_Canonicus_Trail.gpx	0.00				USA
314	2	0.00	0	0.00	2	Pachaug		/static/gpx/314_Pachaug.gpx	0.00				USA
315	2	0.00	0	0.00	2	Laurel Loop Trail		/static/gpx/315_Laurel_Loop_Trail.gpx	0.00				USA
316	2	0.00	0	0.00	2	Pachaug/Nehantic Connector		/static/gpx/316_Pachaug_Nehantic_Connector.gpx	0.00				USA
317	2	0.00	0	0.00	2	Pachaug/Tippecansett Connector		/static/gpx/317_Pachaug_Tippecansett_Connector.gpx	0.00				USA
318	2	0.00	0	0.00	2	Nehantic/Pachaug Connector		/static/gpx/318_Nehantic_Pachaug_Connector.gpx	0.00				USA
319	2	0.00	0	0.00	2	Quinebaug/Pachaug Connector		/static/gpx/319_Quinebaug_Pachaug_Connector.gpx	0.00				USA
320	2	0.00	0	0.00	2	Quinebaug Trail		/static/gpx/320_Quinebaug_Trail.gpx	0.00				USA
321	2	0.00	0	0.00	2	Pachaug/Narragansett Connector		/static/gpx/321_Pachaug_Narragansett_Connector.gpx	0.00				USA
322	2	0.00	0	0.00	2	Narragansett Trail		/static/gpx/322_Narragansett_Trail.gpx	0.00				USA
323	2	0.00	0	0.00	2	Green Falls Loop Trail		/static/gpx/323_Green_Falls_Loop_Trail.gpx	0.00				USA
324	2	0.00	0	0.00	2	Green Falls Water Access Trail		/static/gpx/324_Green_Falls_Water_Access_Trail.gpx	0.00				USA
325	2	0.00	0	0.00	2	Freeman Trail		/static/gpx/325_Freeman_Trail.gpx	0.00				USA
326	2	0.00	0	0.00	2	Tippecansett Trail		/static/gpx/326_Tippecansett_Trail.gpx	0.00				USA
327	2	0.00	0	0.00	2	Tippecansett/Freeman Trail		/static/gpx/327_Tippecansett_Freeman_Trail.gpx	0.00				USA
328	2	0.00	0	0.00	1	Green Falls Pond Trail		/static/gpx/328_Green_Falls_Pond_Trail.gpx	0.00				USA
329	2	0.00	0	0.00	2	Nehantic/Pachaug Trail		/static/gpx/329_Nehantic_Pachaug_Trail.gpx	0.00				USA
330	2	0.00	0	0.00	2	Phillips Pond Spur Trail		/static/gpx/330_Phillips_Pond_Spur_Trail.gpx	0.00				USA
331	2	0.00	0	0.00	2	Quinebaug/Nehantic Connector		/static/gpx/331_Quinebaug_Nehantic_Connector.gpx	0.00				USA
332	2	0.00	0	0.00	0	Nehantic/Quinebaug Connector		/static/gpx/332_Nehantic_Quinebaug_Connector.gpx	0.00				USA
333	2	0.00	0	0.00	1	Patagansett Trail		/static/gpx/333_Patagansett_Trail.gpx	0.00				USA
334	2	0.00	0	0.00	2	Paugussett Forest Trail		/static/gpx/334_Paugussett_Forest_Trail.gpx	0.00				USA
335	2	0.00	0	0.00	2	Zoar Trail		/static/gpx/335_Zoar_Trail.gpx	0.00				USA
336	2	0.00	0	0.00	2	Lillinonah Trail		/static/gpx/336_Lillinonah_Trail.gpx	0.00				USA
337	2	0.00	0	0.00	2	Zoar Trail (Old)		/static/gpx/337_Zoar_Trail__Old_.gpx	0.00				USA
338	2	0.00	0	0.00	2	Upper Gussy Trail		/static/gpx/338_Upper_Gussy_Trail.gpx	0.00				USA
339	2	0.00	0	0.00	2	Pierrepont Park Trail		/static/gpx/339_Pierrepont_Park_Trail.gpx	0.00				USA
340	2	0.00	0	0.00	2	Shenipsit Forest Trail		/static/gpx/340_Shenipsit_Forest_Trail.gpx	0.00				USA
341	2	0.00	0	0.00	2	Quary Trail		/static/gpx/341_Quary_Trail.gpx	0.00				USA
342	2	0.00	0	0.00	2	Shenipsit Forest Road		/static/gpx/342_Shenipsit_Forest_Road.gpx	0.00				USA
343	2	0.00	0	0.00	2	Topsmead Forest Trail		/static/gpx/343_Topsmead_Forest_Trail.gpx	0.00				USA
344	2	0.00	0	0.00	2	Edith M Chase Ecology Trail		/static/gpx/344_Edith_M_Chase_Ecology_Trail.gpx	0.00				USA
345	2	0.00	0	0.00	2	Bernard H Stairs Trail		/static/gpx/345_Bernard_H_Stairs_Trail.gpx	0.00				USA
346	2	0.00	0	0.00	2	West Rock Park Trail		/static/gpx/346_West_Rock_Park_Trail.gpx	0.00				USA
347	2	0.00	0	0.00	2	West Rock Summit Trail		/static/gpx/347_West_Rock_Summit_Trail.gpx	0.00				USA
348	2	0.00	0	0.00	2	Regicides Trail		/static/gpx/348_Regicides_Trail.gpx	0.00				USA
349	2	0.00	0	0.00	2	Sanford Feeder Trail		/static/gpx/349_Sanford_Feeder_Trail.gpx	0.00				USA
350	2	0.00	0	0.00	2	North Summit Trail		/static/gpx/350_North_Summit_Trail.gpx	0.00				USA
351	2	0.00	0	0.00	2	Westville Feeder Trail		/static/gpx/351_Westville_Feeder_Trail.gpx	0.00				USA
352	2	0.00	0	0.00	1	West Rock Park Road		/static/gpx/352_West_Rock_Park_Road.gpx	0.00				USA
353	2	0.00	0	0.00	0	Bennetts Pond Trail		/static/gpx/353_Bennetts_Pond_Trail.gpx	0.00				USA
354	2	0.00	0	0.00	2	Ives Trail		/static/gpx/354_Ives_Trail.gpx	0.00				USA
355	2	0.00	0	0.00	2	Ridgefield Open Space Trail		/static/gpx/355_Ridgefield_Open_Space_Trail.gpx	0.00				USA
356	2	0.00	0	0.00	1	George Dudley Seymour Park Trail		/static/gpx/356_George_Dudley_Seymour_Park_Trail.gpx	0.00				USA
357	2	0.00	0	0.00	1	Grta		/static/gpx/357_Grta.gpx	0.00				USA
358	2	0.00	0	0.00	1	Mohegan Forest Trail		/static/gpx/358_Mohegan_Forest_Trail.gpx	0.00				USA
359	2	0.00	0	0.00	0	Mount Bushnell Trail		/static/gpx/359_Mount_Bushnell_Trail.gpx	0.00				USA
360	2	0.00	0	0.00	2	Nye Holman Trail		/static/gpx/360_Nye_Holman_Trail.gpx	0.00				USA
361	2	0.00	0	0.00	2	Al'S Trail		/static/gpx/361_Al_S_Trail.gpx	0.00				USA
362	2	0.00	0	0.00	2	Salt Rock State Park Trail		/static/gpx/362_Salt_Rock_State_Park_Trail.gpx	0.00				USA
363	2	0.00	0	0.00	1	Scantic River Trail		/static/gpx/363_Scantic_River_Trail.gpx	0.00				USA
364	2	0.00	0	0.00	1	Scantic River Park Trail		/static/gpx/364_Scantic_River_Park_Trail.gpx	0.00				USA
365	2	0.00	0	0.00	2	Scantic Park Access		/static/gpx/365_Scantic_Park_Access.gpx	0.00				USA
366	2	0.00	0	0.00	1	Sunrise Park Trail		/static/gpx/366_Sunrise_Park_Trail.gpx	0.00				USA
367	2	0.00	0	0.00	1	Kitchel Trail		/static/gpx/367_Kitchel_Trail.gpx	0.00				USA
368	2	0.00	0	0.00	1	Old Driveway		/static/gpx/368_Old_Driveway.gpx	0.00				USA
369	2	0.00	0	0.00	1	Kitchel		/static/gpx/369_Kitchel.gpx	0.00				USA
370	2	0.00	0	0.00	2	Driveway		/static/gpx/370_Driveway.gpx	0.00				USA
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website, elevation) FROM stdin;
1	1	8	122.00	Edmund-Graf-Hütte	2	Marvin O'Kon MD	http://harsh-rocket.com	\N
2	2	2	43.00	Dr.Hernaus-Stöckl	2	Miss Heidi Labadie	http://miserable-widget.com	\N
3	3	8	130.00	Amstettner Hütte	2	Bernadette Bauch	https://fitting-hypothermia.name	\N
4	4	10	67.00	Hochleckenhaus	2	Sherman Rempel	http://muffled-gliding.biz	\N
5	5	5	49.00	Kampthalerhütte	2	George Dibbert	https://thoughtful-creator.com	\N
6	6	2	53.00	Lambacher Hütte	2	Lora Marquardt	https://misguided-slot.net	\N
7	7	5	76.00	Lustenauer Hütte	2	Cecelia Schmitt MD	https://buoyant-particular.net	\N
8	8	3	59.00	Gablonzer Hütte	2	Frederick Becker II	https://grown-trailer.biz	\N
9	9	4	135.00	Katafygio «Flampouri»	2	Patricia Fay	https://flat-middleman.net	\N
10	10	6	121.00	Simonyhütte	2	Gail Hane	https://fitting-investment.biz	\N
11	11	6	148.00	Vinzenz-Tollinger-Hütte	2	Rudy Ullrich	http://puzzling-lawyer.net	\N
12	12	5	43.00	Ottokar-Kernstock-Haus	2	Amanda Yundt PhD	http://scornful-spec.info	\N
13	13	3	52.00	Reisseckhütte	2	Jermaine Aufderhar	http://amazing-driver.com	\N
14	14	7	113.00	Vernagthütte	2	Brandy Kreiger	https://zigzag-rainstorm.name	\N
15	15	3	124.00	Wormser Hütte	2	Paul Rippin	https://majestic-pod.com	\N
16	16	5	132.00	Biberacher Hütte	2	Hope Ferry	http://whopping-residue.net	\N
17	17	2	105.00	Katafygio «1777»	2	Rick Glover II	http://fabulous-bather.net	\N
18	18	1	131.00	Hochwaldhütte	2	Michael Kassulke	https://political-multimedia.name	\N
19	19	7	78.00	Kölner Eifelhütte	2	Suzanne Jerde Sr.	http://unwelcome-resemblance.biz	\N
20	20	7	69.00	Madrisahütte	2	Jeffrey Prohaska	https://blue-ambition.info	\N
21	21	7	97.00	Dresdner Hütte	2	Chad Hilll	https://elderly-legislator.net	\N
22	22	9	125.00	Fiderepasshütte	2	Armando Cassin	http://dearest-liquid.org	\N
23	23	7	94.00	Göppinger Hütte	2	Monique Moen	http://irresponsible-priest.org	\N
24	24	4	77.00	Oberzalimhütte	2	Jake Beer	http://apprehensive-yogurt.org	\N
25	25	6	85.00	Rastkogelhütte	2	Sadie Bayer	http://idealistic-alligator.com	\N
26	26	2	80.00	Ansbacher Skihütte im Allgäu	2	Leon Mraz	http://grotesque-example.com	\N
27	27	5	123.00	Kaltenberghütte	2	Lynn Stracke PhD	https://careful-semicolon.info	\N
28	28	9	64.00	Schweinfurter Hütte	2	Andre Simonis	http://deadly-climate.name	\N
29	29	6	140.00	Katafygio «Vardousion»	2	Jesus Daniel	http://animated-proportion.com	\N
30	30	7	52.00	Kocbekov dom na Korošici	2	Andrew Cartwright DVM	https://humiliating-harmonize.name	\N
31	31	2	133.00	Planinski dom Rašiške cete na Rašici	2	Tabitha Reilly I	https://stark-vector.org	\N
32	32	9	88.00	Prešernova koca na Stolu	2	Luther Beahan	http://fresh-vacuum.org	\N
33	33	1	38.00	Planinski dom na Mrzlici	2	Mrs. Angelica Rodriguez	http://any-test.com	\N
34	34	6	107.00	Koca na Planini nad Vrhniko	2	Lauren Zboncak DVM	http://smug-stick.name	\N
35	35	5	74.00	Zavetišce gorske straže na Jelencih	2	Pablo Champlin	http://official-oval.org	\N
36	36	6	70.00	Planinski dom na Gori	2	Jamie Stracke	http://grand-eddy.org	\N
37	37	9	89.00	Bregarjevo zavetišce na planini Viševnik	2	Lamar Schinner	https://short-affiliate.biz	\N
38	38	10	60.00	Koca pod Bogatinom	2	Wendell Abshire	http://amusing-zinc.org	\N
39	39	2	42.00	Pogacnikov dom na Kriških podih	2	Jill Hauck	https://gummy-hypothesis.com	\N
40	40	4	66.00	Dom na Smrekovcu	2	April Miller	http://french-organ.com	\N
41	41	8	115.00	Refuge Du Chatelleret	2	George Cole	http://quick-witted-flintlock.com	\N
42	42	9	101.00	Refuge De Chalance	2	Guadalupe Anderson	http://mellow-pony.net	\N
43	43	1	101.00	Refuge Des Bans	2	Eva Treutel	https://gracious-weeder.biz	\N
44	44	3	76.00	Refuge De Pombie	2	Thelma Romaguera	http://far-flung-neologism.org	\N
45	45	9	118.00	Refuge De Larribet	2	Flora McDermott	https://delirious-bronze.com	\N
46	46	5	92.00	Refuge Du Mont Pourri	2	Miss Kristie Stoltenberg	http://scientific-genius.name	\N
47	47	8	87.00	Refuge De La Dent D?Oche	2	Lori Kutch	http://smooth-robin.org	\N
48	48	9	108.00	Bergseehütte SAC	2	Luke Mills	https://petty-water.net	\N
49	49	2	49.00	Bivouac au Col de la Dent Blanche CAS	2	Florence Schulist	http://chief-dune.biz	\N
50	50	4	129.00	Salbitschijenbiwak SAC	2	Ms. Jeremy Spinka	https://empty-gap.net	\N
51	51	6	140.00	Spannorthütte SAC	2	Casey Hartmann	https://dazzling-suede.info	\N
52	52	6	88.00	Cabane Arpitettaz CAS	2	Valerie Yost	https://unnatural-departure.net	\N
53	53	4	82.00	Refugio De Lizara	2	Israel Larson PhD	http://smooth-freak.biz	\N
54	54	7	143.00	Albergue De Montfalcó	2	Damon Ritchie	http://high-level-stem.com	\N
55	55	8	141.00	El Molonillo/Peña Partida	2	Lillie Bergnaum	http://previous-assignment.org	\N
56	56	7	46.00	La Campiñuela	2	Sonja Raynor	https://apt-spatula.com	\N
57	57	5	87.00	Titov Vrv	2	Carol Boehm	https://diligent-cotton.com	\N
58	58	5	84.00	Rifugio Franchetti	2	Ethel Hagenes DVM	http://thirsty-embellishment.org	\N
59	59	3	145.00	Rifugio Semenza	2	Dr. Jackie Kshlerin	http://grandiose-bathroom.com	\N
60	60	10	91.00	Rifugio Città di Mortara 	2	Annette Littel	https://beneficial-softdrink.org	\N
61	61	8	87.00	Rifugio Andolla	2	Joe Konopelski	https://intrepid-paranoia.org	\N
62	62	8	145.00	Rifugio Forte dei Marmi	2	Charles Bradtke	http://prime-surrounds.biz	\N
63	63	5	69.00	Rifugio Berti	2	Boyd Berge	http://junior-employment.info	\N
64	64	10	131.00	Rifugio Premuda	2	Cassandra Parisian	https://foolhardy-sunday.com	\N
65	65	4	62.00	Rifugio Elisa	2	Troy Aufderhar	https://unique-religion.com	\N
66	66	9	117.00	Rifugio CAI Saronno	2	Loren Predovic	https://understated-moonlight.info	\N
67	67	7	62.00	Rifugio Picco Ivigna	2	Randy Smitham	http://quick-tracking.com	\N
68	68	9	77.00	Rifugio Toesca	2	Merle Lockman	https://demanding-dispatch.com	\N
69	69	2	84.00	Rifugio Al Cedo	2	Walter Romaguera	https://confused-overheard.biz	\N
70	70	1	104.00	Capanna Gnifetti	2	Alfredo Flatley	http://velvety-gran.org	\N
71	71	4	61.00	Rifugio Aosta	2	Doug Pacocha	https://high-level-multimedia.name	\N
72	72	3	80.00	Rifugio Cevedale	2	Stewart Bernier	http://conventional-classmate.org	\N
73	73	9	126.00	Rifugio Ponti	2	Leah Kulas	https://wan-parachute.org	\N
74	74	2	53.00	Rifugio XII Apostoli	2	Ismael Lynch	https://right-bitten.info	\N
75	75	8	100.00	Rifugio Elisabetta Soldini	2	Miss Rudy Reichert	http://courageous-lox.net	\N
76	76	9	43.00	Rifugio Denza	2	Lucas Effertz	https://boiling-amber.net	\N
77	77	9	56.00	Rifugio Fonte Tavoloni 	2	Bobbie Fisher	https://anxious-stepdaughter.name	\N
78	78	6	48.00	Rifugio Carducci	2	Jodi Rice	http://known-dandelion.biz	\N
79	79	3	52.00	Rifugio Bindesi	2	Julius Kulas	https://bony-similarity.name	\N
80	80	1	52.00	Mountain hut Miroslav Hirtz	2	Gwendolyn Rosenbaum	http://necessary-basil.name	\N
81	81	5	84.00	Koca na Blegošu	2	Fernando Lebsack	https://major-centimeter.info	\N
82	82	6	43.00	Wittener Hütte	2	Carl Witting	https://concerned-vegetarian.name	\N
83	83	9	86.00	Hochjoch-Hospiz	2	Ronald Shields	https://obedient-state.org	\N
84	84	4	74.00	Meilerhütte	2	Andre Kozey	https://whirlwind-adaptation.org	\N
85	85	6	135.00	Gaudeamushütte	2	Miss Melissa Dooley	http://gargantuan-submarine.com	\N
86	86	6	89.00	Rheydter Hütte	2	Ira Cummerata	https://joint-step-grandmother.com	\N
87	87	9	118.00	Sektionshütte Krippen	2	Nicholas Gusikowski MD	https://regal-teapot.biz	\N
88	88	4	63.00	Neunkirchner Hütte	2	Miss Monica Hermiston	http://wicked-hometown.info	\N
89	89	1	88.00	Refugio De Riglos	2	Dwayne Cassin	https://impure-quantity.info	\N
90	90	1	43.00	Salbithütte SAC	2	Carlos Schneider	https://glorious-radio.com	\N
91	91	2	91.00	Finsteraarhornhütte SAC	2	Angelo Kohler	https://grouchy-father-in-law.biz	\N
92	92	5	80.00	Cabane des Vignettes CAS	2	Fernando Schultz	http://busy-competition.name	\N
93	93	5	97.00	Glecksteinhütte SAC	2	Isaac Wisoky	https://careless-separation.org	\N
94	94	2	98.00	Länta-Hütte SAC	2	Joey Becker	https://scary-pimple.net	\N
95	95	9	126.00	Monte-Leone-Hütte SAC	2	Mr. Brendan Harris V	https://half-lifetime.info	\N
96	96	10	45.00	Ringelspitzhütte SAC	2	Diana Toy	https://imaginative-audience.biz	\N
97	97	7	50.00	Na poljanama Maljen	2	Faye Bergnaum	https://joyous-expansionism.biz	\N
98	98	8	67.00	Dobra voda	2	Gregg Upton	http://apprehensive-boundary.com	\N
99	99	6	101.00	Ivanova hiža	2	Woodrow Franey	https://massive-fennel.info	\N
100	100	8	80.00	Glavica	2	Fernando Haley	https://fair-grammar.name	\N
101	101	4	119.00	Trpošnjik	2	Victor Friesen	http://dopey-migrant.net	\N
102	102	6	101.00	Bitorajka	2	Christie Hettinger	https://knowing-bond.biz	\N
103	103	10	136.00	Zlatko Prgin	2	Leon Roberts	https://worse-package.biz	\N
104	104	3	133.00	Prpa	2	Hannah Mraz	http://joyous-payoff.biz	\N
105	105	6	127.00	Ždrilo	2	Tasha Lang Jr.	http://frayed-zero.com	\N
106	106	1	68.00	Miroslav Hirtz	2	Miss Adrienne Runolfsson	http://infamous-wax.name	\N
107	107	8	46.00	Jezerce	2	Jim Kemmer	http://distinct-admission.org	\N
108	108	1	126.00	Ivica Sudnik	2	Sheryl Leffler	https://tiny-devastation.org	\N
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
1	109	72	2	Italy	Hawaii		Sophiafurt
2	110	267	2	Italy	Alabama		Rancho Palos Verdes
3	111	276	2	Italy	Louisiana		Herthacester
4	112	25	2	Italy	Arizona		Dale City
5	113	54	2	Italy	Idaho		New Sidney
6	114	103	2	Italy	Georgia		Fontana
7	115	140	2	Italy	Delaware		South Alexandriaburgh
8	116	86	2	Italy	Indiana		East Salvadorfield
9	117	183	2	Italy	Massachusetts		West Rosalyn
10	118	183	2	Italy	Nevada		Altenwerthton
11	119	112	2	Italy	Louisiana		West Hannahboro
12	120	261	2	Italy	Ohio		Ratkechester
13	121	230	2	Italy	Nebraska		Frederick
14	122	215	2	Italy	Utah		Madysonport
15	123	136	2	Italy	Kentucky		Ellisview
16	124	269	2	Italy	Iowa		Boca Raton
17	125	297	2	Italy	Hawaii		Vonborough
18	126	226	2	Italy	Tennessee		Port Murphy
19	127	260	2	Italy	Oklahoma		North Winifredchester
20	128	135	2	Italy	Maryland		Asafurt
21	129	105	2	Italy	Nevada		Erdmanboro
22	130	201	2	Italy	Wisconsin		West Priceville
23	131	6	2	Italy	Hawaii		Sandrachester
24	132	131	2	Italy	Idaho		Port Rahul
25	133	207	2	Italy	Wisconsin		Fort Darien
26	134	223	2	Italy	Kentucky		Ogden
27	135	216	2	Italy	Massachusetts		New Bobby
28	136	33	2	Italy	Montana		Rennerstad
29	137	236	2	Italy	South Dakota		Jacobsonshire
30	138	239	2	Italy	South Dakota		Alvisborough
31	139	84	2	Italy	Illinois		South Hobartville
32	140	250	2	Italy	Georgia		Lauderhill
33	141	169	2	Italy	Idaho		Aliafield
34	142	5	2	Italy	New Jersey		Keelinghaven
35	143	42	2	Italy	New Hampshire		Gislasonbury
36	144	93	2	Italy	Mississippi		West Marvin
37	145	239	2	Italy	California		Lake Deonte
38	146	232	2	Italy	Ohio		Silasland
39	147	54	2	Italy	Colorado		North Elmiraton
40	148	81	2	Italy	Vermont		West Duaneland
41	149	20	2	Italy	Washington		East Dino
42	150	30	2	Italy	Montana		Broomfield
43	151	36	2	Italy	New York		New Burdette
44	152	242	2	Italy	North Carolina		Nienowberg
45	153	152	2	Italy	South Carolina		Normal
46	154	251	2	Italy	Massachusetts		Alameda
47	155	56	2	Italy	Mississippi		Willaland
48	156	250	2	Italy	Minnesota		West Jerodbury
49	157	39	2	Italy	Hawaii		New Stacyport
50	158	79	2	Italy	Iowa		Gary
51	159	81	2	Italy	New Hampshire		Jefferson City
52	160	11	2	Italy	Ohio		San Antonio
53	161	225	2	Italy	Colorado		O'Connellfield
54	162	8	2	Italy	Nebraska		Veldahaven
55	163	214	2	Italy	Rhode Island		Brendafield
56	164	176	2	Italy	Kentucky		Bountiful
57	165	123	2	Italy	Texas		Salem
58	166	40	2	Italy	North Carolina		Winston-Salem
59	167	257	2	Italy	Pennsylvania		Henrishire
60	168	222	2	Italy	New Jersey		Purdystead
61	169	163	2	Italy	Oklahoma		North Berniemouth
62	170	65	2	Italy	Montana		Towneview
63	171	96	2	Italy	Illinois		Arcadia
64	172	47	2	Italy	Tennessee		Ebertstead
65	173	295	2	Italy	Connecticut		West Bayleefield
66	174	134	2	Italy	North Carolina		West Rahsaan
67	175	227	2	Italy	Montana		Port Pink
68	176	26	2	Italy	Michigan		Port Keshaunview
69	177	206	2	Italy	Arkansas		Camylleville
70	178	15	2	Italy	Pennsylvania		East Alanabury
71	179	234	2	Italy	Tennessee		Indio
72	180	77	2	Italy	Wyoming		Brockborough
73	181	241	2	Italy	Arizona		Brookhaven
74	182	132	2	Italy	Massachusetts		Fort Rubenstead
75	183	141	2	Italy	Wyoming		Nitzscheville
76	184	206	2	Italy	Maine		Frederick
77	185	89	2	Italy	New Jersey		South Jarretside
78	186	52	2	Italy	California		Clementinaworth
79	187	272	2	Italy	Montana		South Kenna
80	188	180	2	Italy	New Mexico		Pomona
81	189	61	2	Italy	Montana		Lake Laneberg
82	190	245	2	Italy	New Jersey		Fort Maggie
83	191	119	2	Italy	Oklahoma		Dillanside
84	192	254	2	Italy	Utah		Taylorcester
85	193	294	2	Italy	North Dakota		Lake Jackfurt
86	194	159	2	Italy	Massachusetts		Gabemouth
87	195	83	2	Italy	Massachusetts		South Isabella
88	196	133	2	Italy	West Virginia		Port Suzanne
89	197	268	2	Italy	Georgia		Fort Sidview
90	198	70	2	Italy	Hawaii		Deloresbury
91	199	265	2	Italy	Montana		West Barbaraland
92	200	272	2	Italy	Illinois		Steubermouth
93	201	51	2	Italy	Oklahoma		Maiyamouth
94	202	201	2	Italy	California		Fort Daren
95	203	34	2	Italy	Kansas		South Kiphaven
96	204	90	2	Italy	Oregon		Wilmachester
97	205	226	2	Italy	Louisiana		Victorstad
98	206	163	2	Italy	Michigan		Sandrineville
99	207	61	2	Italy	Colorado		North Flavioland
100	208	117	2	Italy	Ohio		West Santosfield
101	209	54	2	Italy	New Hampshire		Roma
102	210	28	2	Italy	Pennsylvania		Melisaworth
103	211	242	2	Italy	South Carolina		Dashawnhaven
104	212	112	2	Italy	Alaska		Sauerfield
105	213	232	2	Italy	Texas		East Carmen
106	214	130	2	Italy	Nebraska		Fort Reeseside
107	215	125	2	Italy	Missouri		North Pedrostad
108	216	29	2	Italy	Connecticut		Fort Hazel
109	217	50	2	Italy	New York		South Cordeliaville
110	218	149	2	Italy	Montana		East Anna
111	219	153	2	Italy	California		Winonafurt
112	220	170	2	Italy	Texas		Jeffersonville
113	221	121	2	Italy	Delaware		Haverhill
114	222	102	2	Italy	South Dakota		East Kenneth
115	223	28	2	Italy	Connecticut		Mervintown
116	224	206	2	Italy	Mississippi		Kubmouth
117	225	237	2	Italy	Texas		Lodi
118	226	31	2	Italy	New Jersey		Port Mateoport
119	227	25	2	Italy	Texas		North Herbertstad
120	228	90	2	Italy	New Jersey		Yasmineport
121	229	85	2	Italy	Minnesota		Port Marjoryburgh
122	230	267	2	Italy	South Carolina		Kaelacester
123	231	50	2	Italy	Rhode Island		Johnson City
124	232	57	2	Italy	Montana		Santa Rosa
125	233	164	2	Italy	Georgia		Giuseppebury
126	234	223	2	Italy	South Carolina		Genovevaton
127	235	1	2	Italy	Louisiana		West Maximillia
128	236	172	2	Italy	New Mexico		North Jazlyn
129	237	177	2	Italy	North Carolina		Johanview
130	238	1	2	Italy	Virginia		Midwest City
131	239	1	2	Italy	Michigan		North Hertaburgh
132	240	289	2	Italy	Connecticut		Stromanbury
133	241	236	2	Italy	Utah		Brayanport
134	242	92	2	Italy	Indiana		McKinney
135	243	287	2	Italy	Delaware		North Gunner
136	244	238	2	Italy	Vermont		Michelleview
137	245	1	2	Italy	Indiana		Littelboro
138	246	1	2	Italy	Louisiana		Cecilstead
139	247	210	2	Italy	Florida		South Guiseppe
140	248	1	2	Italy	Ohio		Baltimore
141	249	271	2	Italy	Wisconsin		Gloverworth
142	250	148	2	Italy	Maryland		Gilesstead
143	251	132	2	Italy	Virginia		Loveland
144	252	52	2	Italy	South Dakota		West Joshuaborough
145	253	111	2	Italy	West Virginia		Martystead
146	254	25	2	Italy	Tennessee		Milwaukee
147	255	27	2	Italy	Alaska		Nicholeside
148	256	52	2	Italy	Wisconsin		Carrollfurt
149	257	89	2	Italy	Oregon		Berkeley
150	258	137	2	Italy	Michigan		Dudleyland
151	259	63	2	Italy	California		Alysachester
152	260	114	2	Italy	Kansas		New Delpha
153	261	240	2	Italy	Wisconsin		Boganview
154	262	142	2	Italy	Oregon		Cruzfield
155	263	70	2	Italy	Georgia		South Eldridgehaven
156	264	214	2	Italy	Connecticut		Shawnview
157	265	268	2	Italy	Nebraska		New Reecebury
158	266	295	2	Italy	North Carolina		Fort Maida
159	267	98	2	Italy	Nebraska		North Jessycaside
160	268	90	2	Italy	Wyoming		Port Hailee
161	269	36	2	Italy	Oregon		Ellicott City
162	270	149	2	Italy	New Jersey		West Moniquestead
163	271	246	2	Italy	Wyoming		Carliehaven
164	272	112	2	Italy	South Carolina		Lake Alisonfield
165	273	134	2	Italy	Tennessee		Conntown
166	274	30	2	Italy	Wyoming		Neldaberg
167	275	258	2	Italy	Oklahoma		New Nicoletteville
168	276	253	2	Italy	Ohio		Rodrigoland
169	277	143	2	Italy	Wisconsin		Warwick
170	278	71	2	Italy	Minnesota		Lake Elmore
171	279	92	2	Italy	Vermont		Fort Myers
172	280	32	2	Italy	Georgia		Lake Aliyahboro
173	281	273	2	Italy	Minnesota		Fort Elenorchester
174	282	150	2	Italy	Idaho		Fort Cecelia
175	283	28	2	Italy	Arizona		Arloboro
176	284	228	2	Italy	North Carolina		Oscarfield
177	285	123	2	Italy	South Dakota		Lehigh Acres
178	286	103	2	Italy	Arkansas		Littelside
179	287	138	2	Italy	Kansas		New Douglasborough
180	288	165	2	Italy	Texas		Glendale
181	289	48	2	Italy	Ohio		West Noratown
182	290	158	2	Italy	Alabama		Lake Estherfield
183	291	6	2	Italy	New Jersey		Yvettefurt
184	292	191	2	Italy	North Dakota		Lendinara
185	293	75	2	Italy	Maryland		Lake Noemieland
186	294	59	2	Italy	Alaska		Napoli
187	295	159	2	Italy	Wisconsin		Schowalterhaven
188	296	81	2	Italy	Kentucky		Gulgowskimouth
189	297	172	2	Italy	Michigan		Donnellybury
190	298	58	2	Italy	Alaska		Dandrefort
191	299	245	2	Italy	Oregon		Deionshire
192	300	278	2	Italy	Idaho		East Silas
193	301	79	2	Italy	Iowa		Fort Alexis
194	302	72	2	Italy	Alabama		West Kaden
195	303	214	2	Italy	South Dakota		North Ewellshire
196	304	278	2	Italy	New York		Elizabethborough
197	305	100	2	Italy	North Dakota		Jarretstead
198	306	97	2	Italy	Louisiana		Lake Carlie
199	307	149	2	Italy	Kansas		South Minerva
200	308	146	2	Italy	Mississippi		Kreigerfurt
201	309	246	2	Italy	Kansas		Harrisonburg
202	310	177	2	Italy	Kentucky		Boganstad
203	311	410	2	Italy	Illinois		Runtefurt
204	312	143	2	Italy	Pennsylvania		South Ava
205	313	199	2	Italy	New Mexico		East Alexie
206	314	83	2	Italy	Massachusetts		West Elodystad
207	315	246	2	Italy	New Hampshire		Antoinettefort
208	316	276	2	Italy	New York		Apopka
209	317	273	2	Italy	Maine		Funkland
210	318	165	2	Italy	Maine		Port Lucyfurt
211	319	262	2	Italy	Montana		Vallejo
212	320	71	2	Italy	Connecticut		East Krystal
213	321	9	2	Italy	New Mexico		Cormierfurt
214	322	182	2	Italy	Texas		North Miles
215	323	207	2	Italy	Missouri		Stokesberg
216	324	80	2	Italy	Colorado		Nicolaschester
217	325	203	2	Italy	Arkansas		Gilbert
218	326	218	2	Italy	Iowa		Funkshire
219	327	213	2	Italy	Pennsylvania		Fort Lauderdale
220	328	284	2	Italy	Nebraska		Vallejo
221	329	93	2	Italy	South Carolina		New Kristoffer
222	330	3	2	Italy	Wisconsin		Darefurt
223	331	240	2	Italy	Idaho		Lake Lesterworth
224	332	232	2	Italy	Illinois		Hoppeshire
225	333	108	2	Italy	Virginia		Marisolland
226	334	89	2	Italy	Vermont		Estrellafort
227	335	48	2	Italy	Connecticut		Fort Americoburgh
228	336	34	2	Italy	Arizona		East Spencer
229	337	93	2	Italy	Tennessee		Denver
230	338	117	2	Italy	Missouri		South Katrinecester
231	339	132	2	Italy	Montana		Gutmannview
232	340	232	2	Italy	Vermont		Kayabury
233	341	149	2	Italy	Arizona		Reillystead
234	342	160	2	Italy	Oklahoma		East Rockymouth
235	343	227	2	Italy	Florida		El Dorado Hills
236	344	188	2	Italy	Colorado		Josianecester
237	345	245	2	Italy	Maryland		Cedar Hill
238	346	69	2	Italy	Utah		West Marieview
239	347	206	2	Italy	Alaska		Port Thelma
240	348	64	2	Italy	Utah		Port Shermanfield
241	349	246	2	Italy	Michigan		West Kobecester
242	350	280	2	Italy	Nevada		Jerdecester
243	351	88	2	Italy	South Carolina		New Caroline
244	352	69	2	Italy	Florida		Lethafurt
245	353	266	2	Italy	Oklahoma		Kingsport
246	354	80	2	Italy	Pennsylvania		Eduardoside
247	355	37	2	Italy	Texas		Maryamton
248	356	189	2	Italy	West Virginia		Leilaburgh
249	357	143	2	Italy	New York		Pinellas Park
250	358	9	2	Italy	Arkansas		Raphaellebury
251	359	238	2	Italy	Kentucky		Lukastown
252	360	120	2	Italy	Iowa		East Manuel
253	361	97	2	Italy	Nevada		North Odellborough
254	362	159	2	Italy	New Hampshire		West Dameon
255	363	87	2	Italy	Nevada		West Seneca
256	364	107	2	Italy	Washington		South Maximus
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address) FROM stdin;
1	0	0101000020E61000002D64979723B62440C66F2527958D4740	Edmund-Graf-Hütte	6574 Pettneu am Arlberg, Tyrol, Austria
2	0	0101000020E6100000455BF9D0380E2A4056DBD4F478794740	Dr.Hernaus-Stöckl	9020 Klagenfurt, Kärnten, Austria
3	0	0101000020E61000003AD4CD22968A2D406DAF4FF575F14740	Amstettner Hütte	3340 Waidhofen an der Ybbs, Niederösterreich, Austria
4	0	0101000020E61000003470C88518362B404F23C0A11DEA4740	Hochleckenhaus	4853 Steinbach am Attersee, Oberösterreich, Austria
5	0	0101000020E6100000745CA7EA5C3230400E95C9F10B114840	Kampthalerhütte	2384 Breitenfurt bei Wien, Niederösterreich, Austria
6	0	0101000020E610000059E5350827672B402FB2862AC2D34740	Lambacher Hütte	4822 Bad Goisern, Oberösterreich, Austria
7	0	0101000020E610000019FDD2643FA62340662869A087B24740	Lustenauer Hütte	6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria
8	0	0101000020E610000036849931B0F52A4014BD78F039C44740	Gablonzer Hütte	4825 Gosau-Hintertal, Oberösterreich, Austria
9	0	0101000020E6100000202F5A3629BF3740D489BAC5B2144340	Katafygio «Flampouri»	136 72 Acharnes, Attica region, Greece
10	0	0101000020E6100000103E4BA24D3F2B40F731169C1AC04740	Simonyhütte	4830 Hallstatt, Oberösterreich, Austria
11	0	0101000020E610000033190145D5182740BF9048EBDFA04740	Vinzenz-Tollinger-Hütte	6060 Hall in Tirol, Tyrol, Austria
12	0	0101000020E61000001F1E0B5901B82E4091BFCBF1EAB34740	Ottokar-Kernstock-Haus	8600 Bruck an der Mur, Steiermark, Austria
13	0	0101000020E610000018E4FB977DBF2A40D6A3B4422D754740	Reisseckhütte	9814 Mühldorf, Mölltal, Kärnten, Austria
14	0	0101000020E61000007B116DC7D4A52540C0401020436D4740	Vernagthütte	Austria
15	0	0101000020E6100000286211C30EF323407EC9C6832D884740	Wormser Hütte	Austria
16	0	0101000020E6100000999CDA19A60E24406CD097DEFEA04740	Biberacher Hütte	Austria
17	0	0101000020E610000007BC276AC4133740DDF934DDA1A84440	Katafygio «1777»	620 55 Kerkini, Central Macedonia region, Greece
18	0	0101000020E6100000D5AF743E3C0B2A40E6E786A6EC704840	Hochwaldhütte	Germany
19	0	0101000020E6100000C2FBAA5CA8EC19408FC536A968544940	Kölner Eifelhütte	Germany
20	0	0101000020E6100000323CF6B358D223401763601DC7794740	Madrisahütte	Austria
21	0	0101000020E6100000313F373465472640CDC98B4CC07F4740	Dresdner Hütte	Austria
22	0	0101000020E6100000CDCCCCCCCC6C24403E07962364A84740	Fiderepasshütte	Germany
23	0	0101000020E6100000B727486C77172440A9DDAF027C9B4740	Göppinger Hütte	Austria
24	0	0101000020E6100000A379008BFC622340C7629B54348A4740	Oberzalimhütte	Austria
25	0	0101000020E610000013B70A62A0932740B3B45373B99D4740	Rastkogelhütte	Austria
26	0	0101000020E61000009D2D20B41E0E2440D54F49E70DC24740	Ansbacher Skihütte im Allgäu	Germany
27	0	0101000020E610000009E066F16249244097E13FDD408F4740	Kaltenberghütte	Austria
28	0	0101000020E61000000AD7A3703D0A2640E277D32D3B944740	Schweinfurter Hütte	Austria
29	0	0101000020E61000006DC438245A213640DA172BC5E9574340	Katafygio «Vardousion»	330 53 Delphi, Central Greece region, Greece
30	0	0101000020E6100000630F270F8F472D40336D62F5852D4740	Kocbekov dom na Korošici	3334 Luče, Mozirje, Slovenia
31	0	0101000020E6100000D1F5D08072062D40D25C9F20CE114740	Planinski dom Rašiške cete na Rašici	1211 Ljubljana, Šmartno, Slovenia
32	0	0101000020E6100000F70F966F85592C40971550C935374740	Prešernova koca na Stolu	4274 Žirovnica, Slovenia
33	0	0101000020E6100000AA5C8F5FCB372E408E6CD71919184740	Planinski dom na Mrzlici	3302 Griže, Slovenia
34	0	0101000020E6100000651A4D2EC6802C40577A6D3656FC4640	Koca na Planini nad Vrhniko	1360 Vrhnika, Slovenia
35	0	0101000020E6100000245DF94DDD322C4077DAB7E6D0144740	Zavetišce gorske straže na Jelencih	0, -, Slovenia
36	0	0101000020E6100000313F3734656F2E406F7F2E1A32264740	Planinski dom na Gori	Šentjungert, 3310 Žalec, Slovenia
37	0	0101000020E610000098F2E7FC90A22B40C7CBA2C928274740	Bregarjevo zavetišce na planini Viševnik	4265 Bohinjsko jezero, Slovenia
38	0	0101000020E610000091860959CC862B401635F33FD4244740	Koca pod Bogatinom	4265 Bohinjsko jezero, Slovenia
39	0	0101000020E6100000678B3942E5992B40007F639573334740	Pogacnikov dom na Kriških podih	5232 Soca, Slovenia
40	0	0101000020E610000008F580BBE4CC2D402A9C0F95E7344740	Dom na Smrekovcu	3325 Šoštanj, Slovenia
41	0	0101000020E610000073F6CE68AB32194060E811A3E77C4640	Refuge Du Chatelleret	38520 Saint Christophe En Oisans, Isère, France
42	0	0101000020E610000084622B685AF218408177F2E9B16B4640	Refuge De Chalance	5800 La Chapelle En Valgaudemar, Hautes-Alpes, France
43	0	0101000020E6100000963D096CCE711940AE7FD767CE6A4640	Refuge Des Bans	5290 Vallouise, Hautes-Alpes, France
44	0	0101000020E6100000DEAB5626FC52DBBFAED689CBF16A4540	Refuge De Pombie	65400 Laruns, Pyrénées-Atlantiques, France
45	0	0101000020E6100000A69C2FF65E7CD2BFA9F92AF9D86D4540	Refuge De Larribet	65400 Arrens, Marsous, Hautes-Pyrénées, France
46	0	0101000020E61000009CA6CF0EB84E1B401232906797C34640	Refuge Du Mont Pourri	73210 Peisey Nancroix, Savoie, France
47	0	0101000020E6100000C712D6C6D8E91A40BF81C98D222D4740	Refuge De La Dent D?Oche	74500 Bernex, Haute-Savoie, France
48	0	0101000020E6100000BEBDCA2243F820405620D41E27544740	Bergseehütte SAC	Uri, Switzerland
49	0	0101000020E6100000CDD5732CA96D1E40F591820D5C054740	Bivouac au Col de la Dent Blanche CAS	Wallis, Switzerland
50	0	0101000020E610000060F1FE571F0C2140D6BA5B328C564740	Salbitschijenbiwak SAC	Uri, Switzerland
51	0	0101000020E610000084EAC5BE53052140F224048A5C664740	Spannorthütte SAC	Uri, Switzerland
52	0	0101000020E6100000827FB24EBCB71E406113E452EB0C4740	Cabane Arpitettaz CAS	Wallis, Switzerland
53	0	0101000020E61000008A75AA7CCF48E4BF588BF447BD614540	Refugio De Lizara	22730, Aragón, Spain
54	0	0101000020E6100000AE56C01909F8E43F58DB5E1CA6064540	Albergue De Montfalcó	22585 Tolva, Aragón, Spain
55	0	0101000020E61000000A4CFFBF1E610AC08B780953B6904240	El Molonillo/Peña Partida	18160 Güejar Sierra, Andalucía, Spain
56	0	0101000020E610000029110100A92D0AC0F39F054F27844240	La Campiñuela	18417 Trévelez, Andalucía, Spain
57	0	0101000020E61000008E79782A3BCC3440BEAE152301FF4440	Titov Vrv	Tetovo, Municipality of Tetovo, North Macedonia
58	0	0101000020E6100000A2EC2DE57C212B40C7F143A5113D4540	Rifugio Franchetti	Pietracamela, Abruzzo, Italy
59	0	0101000020E610000052E2299ABDFA2840518B1C7D27114740	Rifugio Semenza	Tambre, Veneto, Italy
60	0	0101000020E6100000A197F67244A31F40313D06D094EE4640	Rifugio Città di Mortara 	Alagna Valsesia, Piemonte, Italy
61	0	0101000020E61000006E39F29B1D242040AB1ED555260C4740	Rifugio Andolla	Antrona Schieranico, Piemonte, Italy
62	0	0101000020E61000000AD80E46ECAB2440B70BCD751AFF4540	Rifugio Forte dei Marmi	Stazzema, Toscana, Italy
63	0	0101000020E6100000A88B14CAC2CF284038D66AB4C1504740	Rifugio Berti	Comelico Superiore, Veneto, Italy
64	0	0101000020E610000071B43E4052BB2B406FE70CD649CF4640	Rifugio Premuda	San Dorligo della Valle, Friuli Venezia Giulia, Italy
65	0	0101000020E61000006CCF2C0950C32240191BBAD91FF84640	Rifugio Elisa	Mandello del Lario, Lombardia, Italy
66	0	0101000020E6100000A5BDC11726B31F40F90FE9B7AFFB4640	Rifugio CAI Saronno	Macugnaga, Piemonte, Italy
67	0	0101000020E610000098DD9387857A2640A930B610E4584740	Rifugio Picco Ivigna	Scena, Trentino Alto Adige, Italy
68	0	0101000020E61000003AE97DE36B8F1C404AEF1B5F7B8A4640	Rifugio Toesca	Bussoleno, Piemonte, Italy
69	0	0101000020E6100000A913D044D8E02040382D78D1570C4740	Rifugio Al Cedo	Santa Maria Maggiore, Piemonte, Italy
70	0	0101000020E6100000449D5ECE11661F4009ED8B3A29F34640	Capanna Gnifetti	Gressoney La Trinitè, Valle d?Aosta, Italy
71	0	0101000020E6100000B8AE9811DE3E1E403A048E041AFC4640	Rifugio Aosta	Bionaz, Valle d?Aosta, Italy
72	0	0101000020E6100000BBB31B22135525408EA8F523EA374740	Rifugio Cevedale	Pejo, Trentino Alto Adige, Italy
73	0	0101000020E61000000D33349E08722340F0A485CB2A204740	Rifugio Ponti	Val Masino, Lombardia, Italy
74	0	0101000020E6100000C46D7E0DD2B125405364085B47134740	Rifugio XII Apostoli	Stenico, Trentino Alto Adige, Italy
75	0	0101000020E61000009F1C058882591B40DDD1FF722DE24640	Rifugio Elisabetta Soldini	Courmayeur, Valle d?Aosta, Italy
76	0	0101000020E610000061D57994804F25409903A4C1291F4740	Rifugio Denza	Vermiglio, Trentino Alto Adige, Italy
77	0	0101000020E61000000C1F115322F92A40338AE596560F4540	Rifugio Fonte Tavoloni 	Ovindoli, Abruzzo, Italy
78	0	0101000020E610000037C2A2224EBF2840F2ED5D83BE4E4740	Rifugio Carducci	Auronzo di Cadore, Veneto, Italy
79	0	0101000020E61000006FA53220D64E26400DE02D90A0044740	Rifugio Bindesi	Trento, Trentino Alto Adige, Italy
80	0	0101000020E610000001C11C3D7ECB2D40C670D0B9365A4640	Mountain hut Miroslav Hirtz	53287 Jablanac, Ličko-senjska županija, Croatia
81	0	0101000020E6100000398485EEED352C4098331D324C154740	Koca na Blegošu	4224 Gorenja vas, Slovenia
82	0	0101000020E610000040F850A225BF1F400F441669E2594940	Wittener Hütte	Germany
83	0	0101000020E610000000FDBE7FF3AA25409A99999999694740	Hochjoch-Hospiz	Austria
84	0	0101000020E6100000D7A02FBDFD412640CDCCCCCCCCB44740	Meilerhütte	Germany
85	0	0101000020E610000050C422861DA628406E85B01A4BC64740	Gaudeamushütte	Austria
86	0	0101000020E6100000179CC1DF2F961940D5EB1681B15C4940	Rheydter Hütte	Germany
87	0	0101000020E6100000FB66518EB8562C4057E883656C744940	Sektionshütte Krippen	Germany
88	0	0101000020E61000001F7A839D234C2C40B45EF68814A34740	Neunkirchner Hütte	2620 Neunkirchen, Steiermark, Austria
89	0	0101000020E61000009CE379FC2043E7BF8FC536A9682C4540	Refugio De Riglos	22808, Aragón, Spain
90	0	0101000020E6100000563D4FC4941A2140EBB308E997564740	Salbithütte SAC	Uri, Switzerland
91	0	0101000020E61000001D55C855B23A2040B8EB64DCCE424740	Finsteraarhornhütte SAC	Wallis, Switzerland
92	0	0101000020E6100000DEFD765E1AE71D4038777A52B2FE4640	Cabane des Vignettes CAS	Wallis, Switzerland
93	0	0101000020E6100000E769EE0B84312040FBE19FAF02504740	Glecksteinhütte SAC	Bern, Switzerland
94	0	0101000020E6100000752B5D3C5F152240D9971BDB51454740	Länta-Hütte SAC	Graubünden, Switzerland
95	0	0101000020E610000055ADDEFA26292040BAB9F14860214740	Monte-Leone-Hütte SAC	Wallis, Switzerland
96	0	0101000020E6100000557F0CE8F9C222408F373B25D26E4740	Ringelspitzhütte SAC	Graubünden, Switzerland
97	0	0101000020E6100000A4AA09A2EE0334408E23D6E253104640	Na poljanama Maljen	Maljen, Serbia
98	0	0101000020E6100000A9DE1AD82A313440C5E6E3DA50114640	Dobra voda	Suvobor, Serbia
99	0	0101000020E61000007250C24CDBFF2E402D095053CBC64640	Ivanova hiža	Karlovac town environment, Karlovačka, Croatia
100	0	0101000020E6100000C6DCB5847CC02F40C746205ED7EB4640	Glavica	Medvednica, City of Zagreb, Croatia
101	0	0101000020E6100000FFEC478AC8B83040D3F6AFAC34BD4540	Trpošnjik	Mosor, Splitsko-dalmatinska, Croatia
102	0	0101000020E6100000C217265305932D40C4CE143AAFA54640	Bitorajka	Bitoraj, Primorsko-goranska, Croatia
103	0	0101000020E6100000AB09A2EE0360304006D847A7AE084640	Zlatko Prgin	Dinara, Šibensko-kninska, Croatia
104	0	0101000020E6100000D3872EA86F492E405C8FC2F528444640	Prpa	Velebit, Ličko-senjska, Croatia
105	0	0101000020E6100000787FBC57AD5C2E408BFD65F7E43D4640	Ždrilo	Velebit, Ličko-senjska, Croatia
106	0	0101000020E610000086032159C0F42D40B21188D7F59B4640	Miroslav Hirtz	Velika Kapela, Primorsko-goranska, Croatia
107	0	0101000020E6100000A31EA2D11DAC3140462575029AC04640	Jezerce	Papuk, Požeško-slavonska, Croatia
108	0	0101000020E61000003EE8D9ACFA4C2F405F0CE544BBE24640	Ivica Sudnik	Samoborska gora, Zagrebačka, Croatia
109	0	0101000020E6100000AD3BCC4D8A7D2840CBDF185D39124640		414 Moore Heights, Sophiafurt, Italy
110	0	0101000020E6100000AF5E454607602340EDF2AD0FEB6B4440		9515 Moore Points, Rancho Palos Verdes, Italy
111	0	0101000020E610000050BA3EBD63AA2840D5DBB0B7DE294640		9973 Luna Estates, Herthacester, Italy
112	0	0101000020E6100000E7204322C8042640F6AEE6A507F54540		40163 Prosacco Bypass, Dale City, Italy
113	0	0101000020E61000009F11B6E919B02140ABAC12D154364640		6627 Mozelle Ramp, New Sidney, Italy
114	0	0101000020E61000009EBFBFF7ED2224402DAAEA8ABEE84640		36159 Gerlach Walks, Fontana, Italy
115	0	0101000020E6100000FF209221C76E274017844DF8002D4640		7579 Ondricka Knoll, South Alexandriaburgh, Italy
116	0	0101000020E6100000C2B28817FA8E2340D5809C8B1AB04640		2169 Eulah Circle, East Salvadorfield, Italy
117	0	0101000020E6100000107BFC3960762540600A6A53D0274740		79777 Antonette Route, West Rosalyn, Italy
118	0	0101000020E6100000CF5AC0BAE0462B40B9ED314745E34640		9062 Bartell Ramp, Altenwerthton, Italy
119	0	0101000020E610000048B42E7FCFC525403379B93E620B4740		66834 Hamill River, West Hannahboro, Italy
120	0	0101000020E6100000E066F16261B42A4084E85AC52CF04640		570 Cormier Curve, Ratkechester, Italy
121	0	0101000020E610000021263CFC90E62840C604EBEEF0074640		6003 Eusebio Plains, Frederick, Italy
122	0	0101000020E6100000CFB81567B161274070CFF3A78DA74640		0460 Suzanne Points, Madysonport, Italy
123	0	0101000020E6100000C1F979F8D76F224054F0CAE48AB04640		5917 Kaitlin Extension, Ellisview, Italy
124	0	0101000020E61000008248D0A975782B40741200D2EDC94640		09662 Welch Spurs, Boca Raton, Italy
125	0	0101000020E6100000918B208436172940630E828E564E4540		758 Elmore Road, Vonborough, Italy
126	0	0101000020E610000023484A1F5F572240D37CDF09072C4640		3865 Stanton Trail, Port Murphy, Italy
127	0	0101000020E6100000A09339F130542140F7DBE8ADCB384740		84391 Clotilde Rapid, North Winifredchester, Italy
128	0	0101000020E6100000068A0E37967A2540DB1FDE29D3664540		74246 Joanne Pines, Asafurt, Italy
129	0	0101000020E6100000CF59B09EA4CE2640F18288D4B4434740		695 Heath Rue, Erdmanboro, Italy
130	0	0101000020E6100000C153C8957A5A26407541D8840FE14640		176 MacGyver Drive, West Priceville, Italy
131	0	0101000020E61000008577B988EF302140BAD3426E2B3D4740		93624 Mack Freeway, Sandrachester, Italy
132	0	0101000020E6100000589643E6259E2540B49487E013DD4540		50051 Goyette Run, Port Rahul, Italy
133	0	0101000020E6100000249E4720B9702840B1F84D61A5124640		892 Lucie Stravenue, Fort Darien, Italy
134	0	0101000020E61000008B89CDC7B55926407EB4EED57D084740		97552 McGlynn Extensions, Ogden, Italy
135	0	0101000020E6100000D8B969334EEB27402CF8C84164804540		41878 Skiles Springs, New Bobby, Italy
136	0	0101000020E610000061D394AEAAD4204012A6835039FC4640		300 Hammes Loop, Rennerstad, Italy
137	0	0101000020E6100000B53C6AA741AC27408F0134A550B84640		823 McKenzie Lock, Jacobsonshire, Italy
138	0	0101000020E6100000F78CE9AE91D52240ED48F59D5FE54640		5378 Dereck Row, Alvisborough, Italy
139	0	0101000020E6100000626DE75663902B4097FA1E9A1ED44640		52775 Jaskolski Green, South Hobartville, Italy
140	0	0101000020E6100000FFF9C78C011B2640DD706946501E4740		491 Lindgren Springs, Lauderhill, Italy
141	0	0101000020E61000009C363EEEB67E2740BC2363B5F9BA4640		191 Adonis Expressway, Aliafield, Italy
142	0	0101000020E61000008A9466F3387C1E402B31CF4A5AE74640		903 Beer Courts, Keelinghaven, Italy
143	0	0101000020E6100000F22895F084D22A404082870E26ED4440		60862 Caroline Cliffs, Gislasonbury, Italy
144	0	0101000020E61000007E1D386744712240C878399105CC4640		263 Jimmy Viaduct, West Marvin, Italy
145	0	0101000020E610000020D84C1993812240A475AFEEB30D4740		031 Lebsack Stravenue, Lake Deonte, Italy
146	0	0101000020E6100000242136FD7E2E26406E2AF7A7F91A4740		3549 Boyle Circle, Silasland, Italy
147	0	0101000020E6100000485E8C37E8B927408860C1A2C7CA4640		926 Lyda Manors, North Elmiraton, Italy
148	0	0101000020E61000005E961BB1BB751E407379BD4571EF4640		696 Trycia Center, West Duaneland, Italy
149	0	0101000020E6100000BE2ABC708CED2340366964A1E7DD4640		99052 Andre Radial, East Dino, Italy
150	0	0101000020E610000053B4722F302B2540E4DC26DC2B4D4740		833 Birdie Avenue, Broomfield, Italy
151	0	0101000020E61000009A97C3EE3B32254052B241CB5F574640		435 Jacobi Divide, New Burdette, Italy
152	0	0101000020E6100000622D3E05C0782840F70BD17C29DE4640		22136 Wunsch Camp, Nienowberg, Italy
153	0	0101000020E6100000B05758703F782440773A4668BAB84640		657 Geo Centers, Normal, Italy
154	0	0101000020E610000011D20957F63B2640E6B8AEF3CA084740		003 Patricia Rue, Alameda, Italy
155	0	0101000020E61000004704E3E0D2692C408514F2F741A74640		46579 Boehm Extensions, Willaland, Italy
156	0	0101000020E61000002F0ACC54D2C8264038FE9F1E36CA4640		041 Dibbert Drive, West Jerodbury, Italy
157	0	0101000020E610000046E80C31035E29405A46EA3D95E54640		5341 Aufderhar Ford, New Stacyport, Italy
158	0	0101000020E6100000E4F90CA8376B2340ABA3F496BC5E4440		1820 Nia Ways, Gary, Italy
159	0	0101000020E6100000967DB2BD71ED26406F7319EDA7C14640		333 Doris Burgs, Jefferson City, Italy
160	0	0101000020E6100000FC68DDABFB5427401073EE1B04334740		779 Trudie Club, San Antonio, Italy
161	0	0101000020E610000069965F611C5B2540B52792F991CA4540		064 Casper Forge, O'Connellfield, Italy
162	0	0101000020E6100000B4C6455ACF692740D8C523A765B04640		47328 MacGyver Knolls, Veldahaven, Italy
163	0	0101000020E61000003B843B61D3CC1E40935742D202D44640		89516 Ruthe Avenue, Brendafield, Italy
164	0	0101000020E6100000C03FA54A9455284094347F4C6BE54640		0019 Maximillian Well, Bountiful, Italy
165	0	0101000020E610000003FBF900EEEB1E40FA6184F068EE4640		6349 Barrows Inlet, Salem, Italy
166	0	0101000020E610000007681140209E2640B177352F3D9D4640		38111 Murazik Court, Winston-Salem, Italy
167	0	0101000020E6100000525F96766AFE23402A7C6C81F3EE4640		6417 Lind Lodge, Henrishire, Italy
168	0	0101000020E61000007319EDA7B5EF1E400B1060EC18EC4640		49119 Marquardt Trace, Purdystead, Italy
169	0	0101000020E6100000F86B578DCA1A284015E06014A9B14640		4823 Janet Estates, North Berniemouth, Italy
170	0	0101000020E6100000D634947FD2A12740811A081390584540		7248 Gwendolyn Dam, Towneview, Italy
171	0	0101000020E61000009D63E53C08EA2640B7FB0BF3D4DC4540		50360 Tyrese Loaf, Arcadia, Italy
172	0	0101000020E6100000EA0E18DAEF9B2B40948444DAC6764640		29451 Roberts Shoals, Ebertstead, Italy
173	0	0101000020E610000014BCD7FFEFC62640BA66F2CD36DE4640		90950 Schroeder Prairie, West Bayleefield, Italy
174	0	0101000020E610000009168733BFBE27405D4E098849354540		4419 Francisco Springs, West Rahsaan, Italy
175	0	0101000020E6100000462AE7E6763A2940ABB8CC446CE14440		6175 Raynor Streets, Port Pink, Italy
176	0	0101000020E610000075EED176A7F62640A7F97486F3B24640		28912 Bulah Flat, Port Keshaunview, Italy
177	0	0101000020E6100000F9A23D5E48F727405789C3E3ECE04640		94886 Hyatt Squares, Camylleville, Italy
178	0	0101000020E6100000731A587D64FD294065FED13769E64540		625 Markus Manor, East Alanabury, Italy
179	0	0101000020E6100000ABC5F18D322421407D1FB3582FFA4640		8295 Colin Motorway, Indio, Italy
180	0	0101000020E610000035D252793B0228403A79ECC26AEA4640		3562 Dibbert Gardens, Brockborough, Italy
181	0	0101000020E6100000DD730580CFD02640F16261889CD44640		234 Aida Port, Brookhaven, Italy
182	0	0101000020E61000006531564046E12040530E1C8645E74640		23743 Nitzsche Avenue, Fort Rubenstead, Italy
183	0	0101000020E610000026B8A2DE9D5E2740311A434AFDDC4640		826 Nathen Via, Nitzscheville, Italy
184	0	0101000020E61000000A5BFD22B27524407121EA99B95B4640		572 Kyler Row, Frederick, Italy
185	0	0101000020E6100000C132DBBA40CE2240D0EFFB372F274740		128 Myah Route, South Jarretside, Italy
186	0	0101000020E6100000CA558737C6B91F40EB79ED88F9BD4640		36553 Emard Knoll, Clementinaworth, Italy
187	0	0101000020E61000006AEE320DD4F324401D098F9147B14640		91050 Arnaldo Lane, South Kenna, Italy
188	0	0101000020E610000044053D8A291B2140F0FACC599F5A4440		2459 Conroy Crescent, Pomona, Italy
189	0	0101000020E61000002B1D07B9E6212040F08C11E4FBF04640		14357 Jake Course, Lake Laneberg, Italy
190	0	0101000020E61000007BEDE3B21BB727403464E190B2DD4640		833 Goyette Manors, Fort Maggie, Italy
191	0	0101000020E6100000D8E9ACBB1EE91F40A0A932E774D04640		77460 Paucek Knolls, Dillanside, Italy
192	0	0101000020E61000009C8136DEC21B294063731FCA61894540		0036 Sauer Drives, Taylorcester, Italy
193	0	0101000020E6100000E3B08FA91680204076A0F3BF01E94640		71709 Cummings Ridge, Lake Jackfurt, Italy
194	0	0101000020E6100000EE6EAF16E9832340C6F0225D7DCC4640		10847 Cartwright Course, Gabemouth, Italy
195	0	0101000020E6100000D81D41E037B02140C2F1214D61C54440		622 Roob Motorway, South Isabella, Italy
196	0	0101000020E6100000A807BB174E80284061BC8B9C2AD94640		156 Damaris Shoals, Port Suzanne, Italy
197	0	0101000020E6100000FD18CE9085A322406C9CA80073DB4640		8678 West Ford, Fort Sidview, Italy
198	0	0101000020E6100000E39F635122672540E113A1C7DEDE4640		905 Dominique Burg, Deloresbury, Italy
199	0	0101000020E610000098231A93B47928409916500361674640		649 Dietrich Groves, West Barbaraland, Italy
200	0	0101000020E6100000ABBCD3539A032740A544B7031AEF4640		44139 Art Port, Steubermouth, Italy
201	0	0101000020E61000001E424B0D239B2440D8D1DD1A7DA04640		072 Bergstrom Plaza, Maiyamouth, Italy
202	0	0101000020E6100000CF2CAE96E0891F405EB642FDD3234640		29866 Morar Track, Fort Daren, Italy
203	0	0101000020E6100000D7BDBACF96BC254007205AD020C34640		08611 Adolf Rapids, South Kiphaven, Italy
204	0	0101000020E6100000C96BCABA24832740A97E4A3A6FE54640		6468 Flatley Cove, Wilmachester, Italy
205	0	0101000020E6100000A8DAB80F8AC32940DF67017F9D1A4540		575 Waters Place, Victorstad, Italy
206	0	0101000020E6100000C272DFC556972640A4271BC528D24640		380 Kihn Groves, Sandrineville, Italy
207	0	0101000020E61000005F306E5974411E40EC3F21F1E13A4740		1957 Euna Walk, North Flavioland, Italy
208	0	0101000020E61000006C109CE9142628401760C4E347124740		4766 Breitenberg Manors, West Santosfield, Italy
209	0	0101000020E610000044EC0214D9FD284012AC600AC5EE4440		120 Via Cristoforo Colombo, Roma, Italy
210	0	0101000020E6100000B0FECF61BEF827406DFD99E6C2F24640		708 Dejuan Lane, Melisaworth, Italy
211	0	0101000020E6100000EBB76576CCAF26407B8FE9BFBD424640		354 Kelli Manor, Dashawnhaven, Italy
212	0	0101000020E6100000D6479682247220407379BD4571084740		7869 Athena Fords, Sauerfield, Italy
213	0	0101000020E610000097900F7A36872040AB251DE560074740		3263 Bechtelar Run, East Carmen, Italy
214	0	0101000020E61000000DABD3DC65C22740D32F116F9DE34640		947 Jakubowski Station, Fort Reeseside, Italy
215	0	0101000020E61000009FEE97AA0FCF27402834FF9E0E024740		43548 Hermiston Ferry, North Pedrostad, Italy
216	0	0101000020E6100000E417B90265622C40EFC0A50815E24440		067 Gutmann Forest, Fort Hazel, Italy
217	0	0101000020E6100000B2463D44A37B2540F3C011EEDF764540		8355 Kling Vista, South Cordeliaville, Italy
218	0	0101000020E6100000B6B0B84956A326409DC2A5BE87334740		626 Toni Walk, East Anna, Italy
219	0	0101000020E6100000D56C2FB319AD2840823C16365EC04640		078 Stephan Harbor, Winonafurt, Italy
220	0	0101000020E610000076583C5002EE1E40E0CCF9731BE14640		7732 Predovic Ranch, Jeffersonville, Italy
221	0	0101000020E6100000470EC7A98CC52840B6A73F564BE04640		6639 Ahmad Light, Haverhill, Italy
222	0	0101000020E61000004DC00A4B97B91F4005C1E3DBBBF84540		0362 Talia Corner, East Kenneth, Italy
223	0	0101000020E610000059EB7A585E182740106D1162780E4640		599 Karina Isle, Mervintown, Italy
224	0	0101000020E610000051D9B0A6B2581F4089B7CEBF5DE14640		563 Dooley Skyway, Kubmouth, Italy
225	0	0101000020E6100000AD7603BB504F27406049A8CFC4374640		854 Noble Cliffs, Lodi, Italy
226	0	0101000020E61000004692C5A28EF72640D32934B511794640		90510 Von Shoal, Port Mateoport, Italy
227	0	0101000020E6100000068B790C45182740C3CB1D47BD774640		104 Bechtelar Crossing, North Herbertstad, Italy
228	0	0101000020E61000005CC0159A35C620401880A1A245F44640		2709 Alec Forges, Yasmineport, Italy
229	0	0101000020E6100000FA2D9512DD7227409453967C47234640		4637 Godfrey Bridge, Port Marjoryburgh, Italy
230	0	0101000020E61000008ECD8E54DFA12B403562C1583A2D4540		07457 Ferry Spur, Kaelacester, Italy
231	0	0101000020E610000020651FBF127F254034C06092257F4640		7318 Thiel Throughway, Johnson City, Italy
232	0	0101000020E610000064BB31F3D36E22404F401361C3C24640		420 Fay Lake, Santa Rosa, Italy
233	0	0101000020E6100000D160AEA0C47E2240E41824D813C04640		52621 Crooks Pine, Giuseppebury, Italy
234	0	0101000020E61000006FD8B628B3B91E40086465EA64D64640		2137 Isadore Court, Genovevaton, Italy
235	0	0101000020E610000016CDB9CAC93E2140BC0E8B074A744640		82202 Olga Lakes, West Maximillia, Italy
236	0	0101000020E6100000B4064A65E54A274026DAFA8E86E14640		597 Mante Viaduct, North Jazlyn, Italy
237	0	0101000020E61000000736F80CF26822405273034F6B9C4640		13562 O'Hara Field, Johanview, Italy
238	0	0101000020E6100000DF6124C511412140D11CFE3FF3744640		5981 Wilkinson Light, Midwest City, Italy
239	0	0101000020E610000077ED77CD50412140CB243493B9744640		25573 Keenan Causeway, North Hertaburgh, Italy
240	0	0101000020E61000002E008DD2A5032D406B5CA4F55C204540		62045 Emily Well, Stromanbury, Italy
241	0	0101000020E61000004ED367075C6F1F403A57941282D64640		629 Morissette Highway, Brayanport, Italy
242	0	0101000020E61000006405BF0D316E1F409F07D22060D24640		2531 Magdalen Alley, McKinney, Italy
243	0	0101000020E61000006F4BE482334C2740A928A8F287304640		509 Kreiger Mills, North Gunner, Italy
244	0	0101000020E61000005BC52CC59F522B40DB68A5B50EFA4640		636 Kautzer Orchard, Michelleview, Italy
245	0	0101000020E61000000D5F155E383A21402BCC310F4F724640		3085 Bernhard Course, Littelboro, Italy
246	0	0101000020E6100000E04158326C5D2140821C9430D3704640		829 Maximillia Way, Cecilstead, Italy
247	0	0101000020E6100000C1F979F8D7071F404EFA319C21CD4640		6628 Hoeger Falls, South Guiseppe, Italy
248	0	0101000020E61000000C97B0917F3921404C9C267D6B734640		21054 Jenkins Pines, Baltimore, Italy
249	0	0101000020E6100000EFA18ED838742840FA10AF46D1764640		835 Max Radial, Gloverworth, Italy
250	0	0101000020E6100000B032BF3F4AC11E4019CD25B094D54640		03063 Konopelski Light, Gilesstead, Italy
251	0	0101000020E610000039FBB9579CA829401D9C3EF152FC4440		2114 Bernice Walk, Loveland, Italy
252	0	0101000020E6100000440E5BC4C1F71E4071033E3F8C7E4640		6985 Rohan Coves, West Joshuaborough, Italy
253	0	0101000020E6100000C69EE2DD36D82B400B8AD5D5D3E84640		478 Friesen Cape, Martystead, Italy
254	0	0101000020E6100000888961E2EA131F4040E7244A31CD4640		4537 Johnathon Vista, Milwaukee, Italy
255	0	0101000020E6100000E8F86871C6D81E40E7EBE86E8DD84640		80688 Ondricka Points, Nicholeside, Italy
256	0	0101000020E610000024BF34FBF2301F405FCE6C57E8CB4640		93924 Lisandro Creek, Carrollfurt, Italy
257	0	0101000020E61000000242902859C7254075988AE832F64540		702 Prohaska Shoal, Berkeley, Italy
258	0	0101000020E61000005CEC5113D8AF1E405650ACAE9ED84640		49083 Justen Ford, Dudleyland, Italy
259	0	0101000020E6100000A6A84423E9E41E40BF20336145E14640		24975 Gottlieb Mills, Alysachester, Italy
260	0	0101000020E6100000F07A7AB6582B2740B1ADFAB726234640		610 Pfannerstill Drives, New Delpha, Italy
261	0	0101000020E61000002252D32EA6C91E404392B47636E94640		92869 Fatima Crossroad, Boganview, Italy
262	0	0101000020E61000000BC336983C2C27405262D7F676234640		1783 Araceli Glens, Cruzfield, Italy
263	0	0101000020E61000004F722C94F1E8264075F2D885D5064740		26592 Spencer Drive, South Eldridgehaven, Italy
264	0	0101000020E61000005C8BBBE6FA8F26407A4F8AFB343B4740		65434 Wiza Ville, Shawnview, Italy
265	0	0101000020E61000007B9054956C0B28407BB5487FD4974640		724 Dominique Shores, New Reecebury, Italy
266	0	0101000020E6100000BE52F1DA00B72B40D21D1F8887274540		46450 Darby Mountain, Fort Maida, Italy
267	0	0101000020E6100000A732D6485C052740FDD8243FE2394640		7053 Cormier Manor, North Jessycaside, Italy
268	0	0101000020E6100000AD94545C0B4D2240EE885462E8B94640		3944 Goyette Pines, Port Hailee, Italy
269	0	0101000020E6100000333097F9B3641F40983BE93356DF4640		6128 Benedict Unions, Ellicott City, Italy
270	0	0101000020E61000002B8AB2124E762740C1EA234B41314640		255 Ebert Parkways, West Moniquestead, Italy
271	0	0101000020E6100000905F8951219022403E5695229E864640		01874 Chanel Fields, Carliehaven, Italy
272	0	0101000020E610000096C1621E43E92640E580B80611044740		69088 Green Cliff, Lake Alisonfield, Italy
273	0	0101000020E61000007090B52B99842B40E461461DC27E4640		67158 Nyasia Place, Conntown, Italy
274	0	0101000020E610000084B1CFAD219A26406BDECC43010E4740		4132 Katarina Cove, Neldaberg, Italy
275	0	0101000020E6100000CC1D47BDF13F2240A5A31CCC26824640		589 Brakus Shores, New Nicoletteville, Italy
276	0	0101000020E610000048E58123DCFF26407F7E294D94084740		0826 Batz Extension, Rodrigoland, Italy
277	0	0101000020E61000006B5A73918C1625409D7C1FB358204740		65988 Walsh Manors, Warwick, Italy
278	0	0101000020E6100000204F818241C01E40068B1E53D2D34640		7692 Elvera Stravenue, Lake Elmore, Italy
279	0	0101000020E6100000C0CBB161F2931E40B859BC5818D34640		31788 Anderson Isle, Fort Myers, Italy
280	0	0101000020E610000070DA4246F68B2C40A79C8AAFD1364740		171 Waelchi Mission, Lake Aliyahboro, Italy
281	0	0101000020E6100000A9D5FC9D92882C4058FBE02131384740		73217 Hand Parkway, Fort Elenorchester, Italy
282	0	0101000020E6100000F74A0FF91DD1274067DC8AB3D8024740		43038 Kacey Harbor, Fort Cecelia, Italy
283	0	0101000020E61000004221A7542EE52C40A39BB3F457164740		887 Ernest Forge, Arloboro, Italy
284	0	0101000020E6100000D3D7987C586422408E7CB9AA47A84640		9502 Vivian Spur, Oscarfield, Italy
285	0	0101000020E610000008CDAE7B2B8A2440E646EC6EF9664540		89135 Braun Coves, Lehigh Acres, Italy
286	0	0101000020E610000081EB8A19E1CD26408A4457D8C2194640		3110 Desiree Fields, Littelside, Italy
287	0	0101000020E6100000B4CA4C69FD5122404A95CDC1D8134540		0821 Coralie Shore, New Douglasborough, Italy
288	0	0101000020E6100000E4BD6A65C267264033260EEA6CBC4640		88504 Cronin Camp, Glendale, Italy
289	0	0101000020E610000071C0536DDCD325406C312E0BDCB14640		07742 Sebastian Mountain, West Noratown, Italy
290	0	0101000020E6100000B368F0ADFEEA2540D42AFA4333B54640		402 Amos Bridge, Lake Estherfield, Italy
291	0	0101000020E61000005B2CA0AB08EA2740DE454E15422C4740		43626 Weldon Wall, Yvettefurt, Italy
292	0	0101000020E61000009703988D2933274052EC0D63778A4640		88990 Via Monte Grappa, Lendinara, Italy
293	0	0101000020E61000005389FC44AF582940E7D2AEF83CCA4640		4036 Bailey Prairie, Lake Noemieland, Italy
294	0	0101000020E61000000236D6B441802C4025D5D237C46B4440		44 Via dei Greci, Napoli, Italy
295	0	0101000020E610000073220BE24DBC2740A1E4C40DAE2D4740		38550 Stracke Rue, Schowalterhaven, Italy
296	0	0101000020E610000046B1DCD26AB02540072E45A808074740		7314 Demarco Lane, Gulgowskimouth, Italy
297	0	0101000020E6100000B17E7DBE77992240C0F858B043504440		48765 Lyda Club, Donnellybury, Italy
298	0	0101000020E6100000EC3026FDBD2C27403B6AF1CE46024740		2783 Mosciski Terrace, Dandrefort, Italy
299	0	0101000020E6100000996EC8F5A5712B40C576F700DD3C4740		9105 Joany Curve, Deionshire, Italy
300	0	0101000020E6100000AA5DB818A8F922406B0DA5F622154440		0560 Beier Crest, East Silas, Italy
301	0	0101000020E610000034B10AE58E682040CFC941BFA57A4440		3494 Wolff Court, Fort Alexis, Italy
302	0	0101000020E610000008D04AB5AABC2140800F5EBBB4374640		1437 Jones Track, West Kaden, Italy
303	0	0101000020E6100000B35DA10F967D2D408F49905BDD324740		7956 Lupe Plains, North Ewellshire, Italy
304	0	0101000020E6100000852348A5D8C12840842458C114E24540		228 Efren Ways, Elizabethborough, Italy
305	0	0101000020E6100000BF5076E915252B40EA398EC4703B4740		1225 Bednar Green, Jarretstead, Italy
306	0	0101000020E6100000B956D6917EDA2B40DF707A72A8054540		64883 Ernestine Bypass, Lake Carlie, Italy
307	0	0101000020E61000007889A02067742340DE2A3EF493CE4640		568 Myles Junction, South Minerva, Italy
308	0	0101000020E6100000235399BDC70C254059CFFF6101ED4540		8295 Lavada Ford, Kreigerfurt, Italy
309	0	0101000020E610000027F33405D7392640E75E16C90D2C4740		912 Reichel Crossing, Harrisonburg, Italy
310	0	0101000020E61000001C15EE4BECAC2A40DD11A9C4D02E4540		0196 Williamson Walks, Boganstad, Italy
311	0	0101000020E6100000C1D4850E70E722408E6D63FDB0594540		2098 Jimmy Wall, Runtefurt, Italy
312	0	0101000020E6100000E5BA849E28A826407E7D63BE723F4640		6634 Huel Greens, South Ava, Italy
313	0	0101000020E610000055B1E72109D11F4018CFA0A17FB14640		74444 Kutch Alley, East Alexie, Italy
314	0	0101000020E61000007DEFCA89D18E2640DB0B16985F354540		72845 Abelardo Islands, West Elodystad, Italy
315	0	0101000020E6100000BB6D9516E41D244002678412C1A94640		97667 Aaron Flats, Antoinettefort, Italy
316	0	0101000020E6100000F67AF7C77BB52740FA449E245D4F4740		77128 Aida River, Apopka, Italy
317	0	0101000020E6100000DE68119BD960294098E8E225EEFB4440		42923 Dooley Squares, Funkland, Italy
318	0	0101000020E61000007ED3AA4CE7E52340C9CC052E8F254640		89220 Kelsi Knolls, Port Lucyfurt, Italy
319	0	0101000020E61000004EDF217B732E2240D3F4D901D7214540		602 Wolff Circles, Vallejo, Italy
320	0	0101000020E61000004377A45588CA264008951348E43C4640		892 Larson Rapids, East Krystal, Italy
321	0	0101000020E610000072593B40E6692840252D4B2A09EC4440		38494 Bogisich Pine, Cormierfurt, Italy
322	0	0101000020E610000023E7B3F281D7214072C8618B38C84640		09940 Lucas Cove, North Miles, Italy
323	0	0101000020E61000000C84AE8E2D752740A4897780272E4640		3312 Luna Cliff, Stokesberg, Italy
324	0	0101000020E6100000A63C5F58A33326408C811A63CCED4540		3707 Stark Junctions, Nicolaschester, Italy
325	0	0101000020E6100000CC0C1B65FD922840A42C8DA905C14640		614 Taylor Vista, Gilbert, Italy
326	0	0101000020E61000007332CC64933F2740FEDDF1DC31254640		971 Rohan Extensions, Funkshire, Italy
327	0	0101000020E610000032D758784D462240743F4C67CC0B4740		5804 Melvina Meadows, Fort Lauderdale, Italy
328	0	0101000020E61000002B16BF29ACC825401AB6775787864540		8958 Kuhn Island, Vallejo, Italy
329	0	0101000020E6100000FE00B562C9B62A4032CFA51364D94440		99332 Ernestine Harbors, New Kristoffer, Italy
330	0	0101000020E61000002AD890C9F3362640A3C629DFD80F4640		164 Tito Ranch, Darefurt, Italy
331	0	0101000020E610000098F0958AD7422540F3DD52735E994640		16465 Hickle Overpass, Lake Lesterworth, Italy
332	0	0101000020E6100000451B36806D772640B99BF1C7FE074740		7073 Isaias Inlet, Hoppeshire, Italy
333	0	0101000020E61000008948A8740B9027402B7D321015F14540		474 O'Kon Valley, Marisolland, Italy
334	0	0101000020E6100000484B8A3496612B40F1F44A5986DF4640		46659 Norbert Rapids, Estrellafort, Italy
335	0	0101000020E610000006240626DCE0264059631A97BBDC4640		733 Weber Heights, Fort Americoburgh, Italy
336	0	0101000020E61000001A62067470422640EF6BC94F4FBD4540		212 Simone Circle, East Spencer, Italy
337	0	0101000020E6100000F0F1536694F425402F5D77A9C7134640		398 Jakubowski Ridges, Denver, Italy
338	0	0101000020E6100000A5DAA7E3317F2240E75E16C90DEF4640		5266 Jerrod Ways, South Katrinecester, Italy
339	0	0101000020E6100000D12E956D967D2C40126C5CFFAE6D4440		444 Carlee Circle, Gutmannview, Italy
340	0	0101000020E6100000DD6CBDF0941F27409F515F3BBDDA4640		33926 Feest Forest, Kayabury, Italy
341	0	0101000020E610000096EA025E66002640FA4E82ED16F44540		0723 Lenna Course, Reillystead, Italy
342	0	0101000020E61000009DDE20B5E43C25407F83F6EAE39D4540		7186 King Shore, East Rockymouth, Italy
343	0	0101000020E6100000016E162F168E2340861BF0F9614A4440		228 Gibson Hills, El Dorado Hills, Italy
344	0	0101000020E61000009F32480BE1EA20405C8A50114CDA4640		30001 Prohaska Courts, Josianecester, Italy
345	0	0101000020E6100000618841052C422B400938DFE3A78E4640		309 Donavon Crossroad, Cedar Hill, Italy
346	0	0101000020E6100000160F94803D132140276BD44334E04640		63094 Rippin Port, West Marieview, Italy
347	0	0101000020E610000097A13BD22A4C25401A80B2CE9DD44540		2149 Erdman Fall, Port Thelma, Italy
348	0	0101000020E6100000AD904D4DDD3827405B632BC313B14540		430 Langworth Station, Port Shermanfield, Italy
349	0	0101000020E610000071E82D1EDEEB2C405F93DA30AF824440		0101 Lehner Groves, West Kobecester, Italy
350	0	0101000020E6100000DA48C8F6109B1F40EE2AFFB5176E4640		4005 Prohaska Forge, Jerdecester, Italy
351	0	0101000020E61000004D028A4798F02740C38366D7BD264640		512 Mitchell Divide, New Caroline, Italy
352	0	0101000020E6100000BCB77DEAB38A2C404EF04DD3676E4440		19932 Ferry Burg, Lethafurt, Italy
353	0	0101000020E6100000CBC80F4BB93126404793E6EA22FD4640		4536 Hahn Ridge, Kingsport, Italy
354	0	0101000020E6100000A68E9FD7E925284065677682A2C64640		38726 Aric Tunnel, Eduardoside, Italy
355	0	0101000020E6100000407562C55F5D294091FC773359C24640		066 Dickens Oval, Maryamton, Italy
356	0	0101000020E6100000CF328B506C4D244070D63B37C8184640		0535 Grant Mount, Leilaburgh, Italy
357	0	0101000020E61000007E6E0D11DC1122409453967C47EB4640		443 Gibson Cape, Pinellas Park, Italy
358	0	0101000020E610000043A44BA4D989204072A8DF85ADD34640		9457 Carolyne Club, Raphaellebury, Italy
359	0	0101000020E61000004371C79BFC022C404AF5F81807254540		536 O'Hara Crossing, Lukastown, Italy
360	0	0101000020E61000009EA74B10BFA422400292FAFC41944440		49812 Schultz Locks, East Manuel, Italy
361	0	0101000020E61000000D88B59D5B012C40CF70B9B024144540		18832 Turner Station, North Odellborough, Italy
362	0	0101000020E610000059935D1F8CFE26407E6DA23B2D3B4640		8172 Effertz Crossroad, West Dameon, Italy
363	0	0101000020E6100000D50451F7010829403B736AC2510D4640		7204 Doyle Crossing, West Seneca, Italy
364	0	0101000020E6100000CD6152D735012740D65F6523C6394640		53834 Oral Trace, South Maximus, Italy
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash") FROM stdin;
2	$2b$10$LDfMfeAKNF.07mq2znrW4e.qRcOZ6Zf0qmQ4NJTdQjA4PQAdJEgg6	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N
4	$2b$10$gNW./qab0aQFkAH4ulHe9ua3wurBK3rVqcrA8ab.Tr1VL6.7W/VKW	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N
5	$2b$10$pqtC2bByoG/zN6.vHaheI.xyq9.UBqW5ePuTUptRC2KUEW7gx.8c.	Laura	Zurru	5	laura@emergency.it	\N	t	\N
1	$2b$10$Kq1EkBXnK6a315DZrf8OAO.AJ4PFMr0ppaTv7bzjNnoedQOhORszm	German	Gorodnev	0	german@hiker.it	\N	t	\N
3	$2b$10$CTvXHlqehgiAorEC9PCjMOuOR4lseT89Dls.yMznDVSRitqyC63UG	vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 370, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 108, true);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 256, true);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 364, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: hike_points PK_7fc686c35c52228d8494a7c4947; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_7fc686c35c52228d8494a7c4947" PRIMARY KEY ("hikeId", "pointId");


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

