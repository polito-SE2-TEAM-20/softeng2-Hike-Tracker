--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: hike_points PK_7fc686c35c52228d8494a7c4947; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_7fc686c35c52228d8494a7c4947" PRIMARY KEY ("hikeId", "pointId");


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$LDfMfeAKNF.07mq2znrW4e.qRcOZ6Zf0qmQ4NJTdQjA4PQAdJEgg6',
    'Antonio',
    'Battipaglia',
    2,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$gNW./qab0aQFkAH4ulHe9ua3wurBK3rVqcrA8ab.Tr1VL6.7W/VKW',
    'Erfan',
    'Gholami',
    4,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$pqtC2bByoG/zN6.vHaheI.xyq9.UBqW5ePuTUptRC2KUEW7gx.8c.',
    'Laura',
    'Zurru',
    5,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$Kq1EkBXnK6a315DZrf8OAO.AJ4PFMr0ppaTv7bzjNnoedQOhORszm',
    'German',
    'Gorodnev',
    0,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$CTvXHlqehgiAorEC9PCjMOuOR4lseT89Dls.yMznDVSRitqyC63UG',
    'vincenzo',
    'Sagristano',
    3,
    true
  );
  

      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Airline Trail - Detour',
        0,
        '/static/gpx/001_Airline_Trail___Detour.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Airline Trail',
        2,
        '/static/gpx/002_Airline_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Colchester Railroad',
        2,
        '/static/gpx/003_Colchester_Railroad.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Willimantic Flower Bridge',
        0,
        '/static/gpx/004_Willimantic_Flower_Bridge.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Willimantic Pedestrian Bridge',
        0,
        '/static/gpx/005_Willimantic_Pedestrian_Bridge.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Two Sister''S Preserve Loop Trail',
        2,
        '/static/gpx/006_Two_Sister_S_Preserve_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Putnam River Trail',
        2,
        '/static/gpx/007_Putnam_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Airline Trail Bypass',
        2,
        '/static/gpx/008_Airline_Trail_Bypass.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Indian Neck',
        0,
        '/static/gpx/009_Indian_Neck.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Stony Creek',
        2,
        '/static/gpx/010_Stony_Creek.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quarry-Westwoods',
        1,
        '/static/gpx/011_Quarry_Westwoods.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Short Beach',
        1,
        '/static/gpx/012_Short_Beach.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Charter Oak Greenway',
        2,
        '/static/gpx/013_Charter_Oak_Greenway.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bissell Greenway',
        1,
        '/static/gpx/014_Bissell_Greenway.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Riverfront Trail System',
        0,
        '/static/gpx/015_Riverfront_Trail_System.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Millers Pond Park Trail',
        2,
        '/static/gpx/016_Millers_Pond_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mattabesett Trail',
        2,
        '/static/gpx/017_Mattabesett_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Jefferson Park Trail',
        2,
        '/static/gpx/018_Jefferson_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Cockaponset Trail',
        2,
        '/static/gpx/019_Cockaponset_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mt. Nebo Park',
        0,
        '/static/gpx/020_Mt__Nebo_Park.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        ' ',
        2,
        '/static/gpx/021__.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Proposed Trail',
        2,
        '/static/gpx/022_Proposed_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Blinnshed Ridge Trail',
        2,
        '/static/gpx/023_Blinnshed_Ridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Neck River Trail',
        2,
        '/static/gpx/024_Neck_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Unnamed Trail',
        2,
        '/static/gpx/025_Unnamed_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Oil Mill Brook Trail',
        2,
        '/static/gpx/026_Oil_Mill_Brook_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Chatfield Trail',
        2,
        '/static/gpx/027_Chatfield_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Unamed Trail',
        2,
        '/static/gpx/028_Unamed_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Lost Pond Trail',
        2,
        '/static/gpx/029_Lost_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Ccc Camp Hadley Trail',
        2,
        '/static/gpx/030_Ccc_Camp_Hadley_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Double Loop Trail',
        2,
        '/static/gpx/031_Double_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Over Brook Trail',
        2,
        '/static/gpx/032_Over_Brook_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Cockaponset Forest Trail',
        2,
        '/static/gpx/033_Cockaponset_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pattaconk Trail',
        2,
        '/static/gpx/034_Pattaconk_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Westwoods Forest Trail',
        2,
        '/static/gpx/035_Westwoods_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Blinnshed Loop Trail',
        2,
        '/static/gpx/036_Blinnshed_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Unnamed Tsail',
        2,
        '/static/gpx/037_Unnamed_Tsail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Messerschmidt Wma Trail',
        1,
        '/static/gpx/038_Messerschmidt_Wma_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Westwoods Nature Trail',
        2,
        '/static/gpx/039_Westwoods_Nature_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Enduro',
        2,
        '/static/gpx/040_Enduro.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Land Trust Trail',
        2,
        '/static/gpx/041_Land_Trust_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Beaver Brook Park Trail',
        1,
        '/static/gpx/042_Beaver_Brook_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Housatonic Forest Trail',
        1,
        '/static/gpx/043_Housatonic_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Farmington Canal Trail',
        2,
        '/static/gpx/044_Farmington_Canal_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Beckley Furnace Park Path',
        2,
        '/static/gpx/045_Beckley_Furnace_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Farmington River Trail',
        0,
        '/static/gpx/046_Farmington_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Farminton Canal Trail',
        2,
        '/static/gpx/047_Farminton_Canal_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Farminton River Trail',
        2,
        '/static/gpx/048_Farminton_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hop River Trail',
        2,
        '/static/gpx/049_Hop_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hoprivertrail - Detouraround316',
        0,
        '/static/gpx/050_Hoprivertrail___Detouraround316.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hop River Trail - Long Hill Rd.',
        0,
        '/static/gpx/051_Hop_River_Trail___Long_Hill_Rd_.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hop River Trail - Rockville Spur',
        2,
        '/static/gpx/052_Hop_River_Trail___Rockville_Spur.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Housatonic Rail Trail',
        1,
        '/static/gpx/053_Housatonic_Rail_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Middletown Bikeway',
        1,
        '/static/gpx/054_Middletown_Bikeway.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mattabesett Trolley Trail',
        2,
        '/static/gpx/055_Mattabesett_Trolley_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Moosup Valley State Park Trail',
        1,
        '/static/gpx/056_Moosup_Valley_State_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinnebaug River Trail',
        2,
        '/static/gpx/057_Quinnebaug_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tracey Road Trail',
        1,
        '/static/gpx/058_Tracey_Road_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Trolley Trail',
        0,
        '/static/gpx/059_Trolley_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinnebaug Hatchery Trail',
        2,
        '/static/gpx/060_Quinnebaug_Hatchery_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hopeville Park Trail',
        2,
        '/static/gpx/061_Hopeville_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hopeville Park Path',
        1,
        '/static/gpx/062_Hopeville_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nehantic Trail',
        2,
        '/static/gpx/063_Nehantic_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Camp Columbia Trail',
        1,
        '/static/gpx/064_Camp_Columbia_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shelton Land Trust Trail',
        2,
        '/static/gpx/065_Shelton_Land_Trust_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Dinosaur Park Sidewalk',
        1,
        '/static/gpx/066_Dinosaur_Park_Sidewalk.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Dinosaur Park Trail',
        2,
        '/static/gpx/067_Dinosaur_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Access Road',
        1,
        '/static/gpx/068_Access_Road.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Day Pond Park Path',
        0,
        '/static/gpx/069_Day_Pond_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Day Pond Park Trail',
        1,
        '/static/gpx/070_Day_Pond_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Salmon River Trail',
        1,
        '/static/gpx/071_Salmon_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Salmon River Trial',
        0,
        '/static/gpx/072_Salmon_River_Trial.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Dennis Hill Park Trail',
        0,
        '/static/gpx/073_Dennis_Hill_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Railroad Trail',
        2,
        '/static/gpx/074_Railroad_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Gillette Castle Trail',
        0,
        '/static/gpx/075_Gillette_Castle_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kent Falls Park Path',
        0,
        '/static/gpx/076_Kent_Falls_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kent Falls Park Trail',
        1,
        '/static/gpx/077_Kent_Falls_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Lovers Leap Park Trail',
        0,
        '/static/gpx/078_Lovers_Leap_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Enders Forest Trail',
        2,
        '/static/gpx/079_Enders_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Gay City Park Path',
        2,
        '/static/gpx/080_Gay_City_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Gay City Park Trail',
        0,
        '/static/gpx/081_Gay_City_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Split Rock Trail',
        1,
        '/static/gpx/082_Split_Rock_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Gillette Castle Path',
        1,
        '/static/gpx/083_Gillette_Castle_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Great Pond Forest Trail',
        2,
        '/static/gpx/084_Great_Pond_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Haddam Meadows Park Trail',
        1,
        '/static/gpx/085_Haddam_Meadows_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Haley Farm Park Trail',
        2,
        '/static/gpx/086_Haley_Farm_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hammonasset Park Path',
        0,
        '/static/gpx/087_Hammonasset_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nature Trail',
        1,
        '/static/gpx/088_Nature_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hammonasset Bike Path',
        1,
        '/static/gpx/089_Hammonasset_Bike_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hammonasset Park Boardwalk',
        1,
        '/static/gpx/090_Hammonasset_Park_Boardwalk.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Meigs Point Jetty',
        2,
        '/static/gpx/091_Meigs_Point_Jetty.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Willard Island Nature Trail',
        2,
        '/static/gpx/092_Willard_Island_Nature_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Moraine Nature Trail',
        2,
        '/static/gpx/093_Moraine_Nature_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Haystack Park Trail',
        0,
        '/static/gpx/094_Haystack_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Higganum Reservoir Park Trail',
        2,
        '/static/gpx/095_Higganum_Reservoir_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Appalachian Trail',
        1,
        '/static/gpx/096_Appalachian_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mohawk Trail',
        2,
        '/static/gpx/097_Mohawk_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pine Knob Loop',
        1,
        '/static/gpx/098_Pine_Knob_Loop.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Appalachian/Pine Knob Loop',
        0,
        '/static/gpx/099_Appalachian_Pine_Knob_Loop.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'White Mountain Trail',
        1,
        '/static/gpx/100_White_Mountain_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'River Trail',
        1,
        '/static/gpx/101_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hurd Park Trail',
        0,
        '/static/gpx/102_Hurd_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hurd Park Path',
        0,
        '/static/gpx/103_Hurd_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Paugussett Trail',
        0,
        '/static/gpx/104_Paugussett_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Waterfall Trail',
        1,
        '/static/gpx/105_Waterfall_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Paugussett Trail Connector',
        1,
        '/static/gpx/106_Paugussett_Trail_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Minetto Park Trail',
        0,
        '/static/gpx/107_Minetto_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Coincident Macedonia Brook Rd',
        2,
        '/static/gpx/108_Coincident_Macedonia_Brook_Rd.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Coincident Weber Road',
        0,
        '/static/gpx/109_Coincident_Weber_Road.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Macedonia Ridge Trail',
        0,
        '/static/gpx/110_Macedonia_Ridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Cobble Mountain Trail',
        0,
        '/static/gpx/111_Cobble_Mountain_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shenipsit Trail',
        2,
        '/static/gpx/112_Shenipsit_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Meshomasic Forest Trail',
        2,
        '/static/gpx/113_Meshomasic_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Crest Trail',
        1,
        '/static/gpx/114_Crest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Campground Trail',
        1,
        '/static/gpx/115_Campground_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Brook Trail',
        2,
        '/static/gpx/116_Brook_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kettletown Park Trail',
        0,
        '/static/gpx/117_Kettletown_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'North Ridge Trail',
        0,
        '/static/gpx/118_North_Ridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'North Ridge Loop Trail',
        1,
        '/static/gpx/119_North_Ridge_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Miller Brook Connector Trail',
        0,
        '/static/gpx/120_Miller_Brook_Connector_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Miller Trail',
        2,
        '/static/gpx/121_Miller_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Miller Trail Spur',
        2,
        '/static/gpx/122_Miller_Trail_Spur.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pomperaug Trail',
        0,
        '/static/gpx/123_Pomperaug_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Brook Trail Access',
        0,
        '/static/gpx/124_Brook_Trail_Access.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Waramaug Lake Park Trail',
        0,
        '/static/gpx/125_Waramaug_Lake_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Well Groomed Trail',
        2,
        '/static/gpx/126_Well_Groomed_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mashamoquet Brook Park Trail',
        1,
        '/static/gpx/127_Mashamoquet_Brook_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shenipsit Trail Spur',
        1,
        '/static/gpx/128_Shenipsit_Trail_Spur.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shenipsit',
        0,
        '/static/gpx/129_Shenipsit.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nassahegon Forest Trail',
        2,
        '/static/gpx/130_Nassahegon_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tunxis Trail',
        1,
        '/static/gpx/131_Tunxis_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Black Spruce Bog Trail',
        0,
        '/static/gpx/132_Black_Spruce_Bog_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mohawk Forest Trail',
        2,
        '/static/gpx/133_Mohawk_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Ethan Allen Youth Trail',
        2,
        '/static/gpx/134_Ethan_Allen_Youth_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Punch Brook Trail',
        2,
        '/static/gpx/135_Punch_Brook_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Red Cedar Lake Trail',
        0,
        '/static/gpx/136_Red_Cedar_Lake_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Under Mountain Trail',
        0,
        '/static/gpx/137_Under_Mountain_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mount Tom Trail',
        2,
        '/static/gpx/138_Mount_Tom_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Naugatuck Trail',
        2,
        '/static/gpx/139_Naugatuck_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nehantic Forest Trail',
        1,
        '/static/gpx/140_Nehantic_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Naugatuck Forest Trail',
        2,
        '/static/gpx/141_Naugatuck_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Naugatuck Spur',
        2,
        '/static/gpx/142_Naugatuck_Spur.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Whitemore Trail',
        2,
        '/static/gpx/143_Whitemore_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinnipiac Trail',
        2,
        '/static/gpx/144_Quinnipiac_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nehantic Forest Trai',
        0,
        '/static/gpx/145_Nehantic_Forest_Trai.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nepaug Forest Trail',
        2,
        '/static/gpx/146_Nepaug_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Naugatuck',
        1,
        '/static/gpx/147_Naugatuck.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nyantaquit Trail',
        2,
        '/static/gpx/148_Nyantaquit_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tipping Rock Loop Trail',
        2,
        '/static/gpx/149_Tipping_Rock_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Valley Outlook Trail',
        1,
        '/static/gpx/150_Valley_Outlook_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shelter 4 Loop Trail',
        2,
        '/static/gpx/151_Shelter_4_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Osbornedale Park Trail',
        0,
        '/static/gpx/152_Osbornedale_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Unnamed',
        0,
        '/static/gpx/153_Unnamed.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Paugnut Forest Trail',
        0,
        '/static/gpx/154_Paugnut_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Charles L Pack Trail',
        2,
        '/static/gpx/155_Charles_L_Pack_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Peoples Forest Trail',
        0,
        '/static/gpx/156_Peoples_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Putnam Memorial Trail',
        2,
        '/static/gpx/157_Putnam_Memorial_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Platt Hill Park Trail',
        1,
        '/static/gpx/158_Platt_Hill_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Metacomet Trail',
        0,
        '/static/gpx/159_Metacomet_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Metacomet Trail Bypass',
        2,
        '/static/gpx/160_Metacomet_Trail_Bypass.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Penwood Park Trail',
        0,
        '/static/gpx/161_Penwood_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quadick Park Path',
        1,
        '/static/gpx/162_Quadick_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quadick Red Trail',
        0,
        '/static/gpx/163_Quadick_Red_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pootatuck Forest Trail',
        1,
        '/static/gpx/164_Pootatuck_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'River Highland Park Trail',
        2,
        '/static/gpx/165_River_Highland_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tunxis',
        2,
        '/static/gpx/166_Tunxis.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Old Furnace Trail',
        1,
        '/static/gpx/167_Old_Furnace_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Old Furnace Park Trail',
        0,
        '/static/gpx/168_Old_Furnace_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kestral Trail',
        2,
        '/static/gpx/169_Kestral_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Warbler Trail',
        0,
        '/static/gpx/170_Warbler_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Muir Trail',
        1,
        '/static/gpx/171_Muir_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shadow Pond Nature Trail',
        0,
        '/static/gpx/172_Shadow_Pond_Nature_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Jesse Gerard Trail',
        1,
        '/static/gpx/173_Jesse_Gerard_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Robert Ross Trail',
        1,
        '/static/gpx/174_Robert_Ross_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Agnes Bowen Trail',
        1,
        '/static/gpx/175_Agnes_Bowen_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Elliot Bronson Trail',
        0,
        '/static/gpx/176_Elliot_Bronson_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Walt Landgraf Trail',
        1,
        '/static/gpx/177_Walt_Landgraf_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Squantz Pond Park Trail',
        1,
        '/static/gpx/178_Squantz_Pond_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Putnam Memorial Museum Trail',
        0,
        '/static/gpx/179_Putnam_Memorial_Museum_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinnipiac Park Trail',
        1,
        '/static/gpx/180_Quinnipiac_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Boardwalk',
        2,
        '/static/gpx/181_Boardwalk.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Rocky Neck Park Sidewalk',
        0,
        '/static/gpx/182_Rocky_Neck_Park_Sidewalk.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Rocky Neck Park Path',
        1,
        '/static/gpx/183_Rocky_Neck_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Rocky Neck Park Trail',
        2,
        '/static/gpx/184_Rocky_Neck_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Rope Swing',
        1,
        '/static/gpx/185_Rope_Swing.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sherwood Island Park Path',
        2,
        '/static/gpx/186_Sherwood_Island_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sleeping Giant Park Trail',
        0,
        '/static/gpx/187_Sleeping_Giant_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sherwood Island Nature Trail',
        0,
        '/static/gpx/188_Sherwood_Island_Nature_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sleeping Giant Park Path',
        1,
        '/static/gpx/189_Sleeping_Giant_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tower Trail',
        2,
        '/static/gpx/190_Tower_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinnipiac Trail Spur',
        0,
        '/static/gpx/191_Quinnipiac_Trail_Spur.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Southford Falls Park Trail',
        2,
        '/static/gpx/192_Southford_Falls_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tunxis Forest Trail',
        2,
        '/static/gpx/193_Tunxis_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sleeping Giant Trail',
        2,
        '/static/gpx/194_Sleeping_Giant_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Stratton Brook Park Path',
        2,
        '/static/gpx/195_Stratton_Brook_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bike Trail',
        1,
        '/static/gpx/196_Bike_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Stratton Brook Park Trail',
        1,
        '/static/gpx/197_Stratton_Brook_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Simsbury Park Trail',
        0,
        '/static/gpx/198_Simsbury_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Wolcott Trail',
        2,
        '/static/gpx/199_Wolcott_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Madden Fyler Pond Trail',
        2,
        '/static/gpx/200_Madden_Fyler_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sunny Brook Park Trail',
        2,
        '/static/gpx/201_Sunny_Brook_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Fadoir Spring Trail',
        0,
        '/static/gpx/202_Fadoir_Spring_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Fadoir Trail',
        2,
        '/static/gpx/203_Fadoir_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Walnut Mountain Trail',
        1,
        '/static/gpx/204_Walnut_Mountain_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Wolcott',
        1,
        '/static/gpx/205_Wolcott.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Old Metacomet Trail',
        1,
        '/static/gpx/206_Old_Metacomet_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Talcott Mountain Park Trail',
        2,
        '/static/gpx/207_Talcott_Mountain_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Falls Brook Trail',
        1,
        '/static/gpx/208_Falls_Brook_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Whittemore Glen Trail',
        2,
        '/static/gpx/209_Whittemore_Glen_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Wharton Brook Park Trail',
        1,
        '/static/gpx/210_Wharton_Brook_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Larkin Bridle Trail',
        0,
        '/static/gpx/211_Larkin_Bridle_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bluff Point Bike Path',
        0,
        '/static/gpx/212_Bluff_Point_Bike_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bluff Point Trail',
        0,
        '/static/gpx/213_Bluff_Point_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Hrt - Main Street Spur',
        1,
        '/static/gpx/214_Hrt___Main_Street_Spur.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Laurel Brook Trail',
        2,
        '/static/gpx/215_Laurel_Brook_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Wadsworth Falls Park Trail',
        2,
        '/static/gpx/216_Wadsworth_Falls_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'White Birch Trail',
        2,
        '/static/gpx/217_White_Birch_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Red Cedar Trail',
        2,
        '/static/gpx/218_Red_Cedar_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Little Falls Trail',
        2,
        '/static/gpx/219_Little_Falls_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Deer Trail',
        2,
        '/static/gpx/220_Deer_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Rockfall Land Trust Trail',
        2,
        '/static/gpx/221_Rockfall_Land_Trust_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bridge Trail',
        2,
        '/static/gpx/222_Bridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Main Trail',
        2,
        '/static/gpx/223_Main_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'American Legion Forest Trail',
        2,
        '/static/gpx/224_American_Legion_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Turkey Vultures Ledges Trail',
        2,
        '/static/gpx/225_Turkey_Vultures_Ledges_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Henry R Buck Trail',
        2,
        '/static/gpx/226_Henry_R_Buck_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mashapaug Pond View Trail',
        2,
        '/static/gpx/227_Mashapaug_Pond_View_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bigelow Hollow Park Trail',
        2,
        '/static/gpx/228_Bigelow_Hollow_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Breakneck Pond View Trail',
        2,
        '/static/gpx/229_Breakneck_Pond_View_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'East Ridge Trail',
        2,
        '/static/gpx/230_East_Ridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bigelow Pond Loop Trail',
        2,
        '/static/gpx/231_Bigelow_Pond_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Ridge Trail',
        2,
        '/static/gpx/232_Ridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nipmuck Trail',
        2,
        '/static/gpx/233_Nipmuck_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mattatuck Trail',
        2,
        '/static/gpx/234_Mattatuck_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Black Rock Park Trail',
        2,
        '/static/gpx/235_Black_Rock_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Poquonnock River Walk',
        1,
        '/static/gpx/236_Poquonnock_River_Walk.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kempf & Shenipsit Trail',
        0,
        '/static/gpx/237_Kempf___Shenipsit_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kempf Trail',
        2,
        '/static/gpx/238_Kempf_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Railroad Bed',
        2,
        '/static/gpx/239_Railroad_Bed.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mohegan Trail',
        2,
        '/static/gpx/240_Mohegan_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Burr Pond Park Trail',
        0,
        '/static/gpx/241_Burr_Pond_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Burr Pond Park Path',
        0,
        '/static/gpx/242_Burr_Pond_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Campbell Falls Trail',
        0,
        '/static/gpx/243_Campbell_Falls_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Deep Woods Trail',
        2,
        '/static/gpx/244_Deep_Woods_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Chimney Trail',
        2,
        '/static/gpx/245_Chimney_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Chimney Connector Trail',
        2,
        '/static/gpx/246_Chimney_Connector_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'East Woods Trail',
        2,
        '/static/gpx/247_East_Woods_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'East Woods Connector Trail',
        2,
        '/static/gpx/248_East_Woods_Connector_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Covered Bridge Connector Trail',
        2,
        '/static/gpx/249_Covered_Bridge_Connector_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Covered Bridge Trail',
        2,
        '/static/gpx/250_Covered_Bridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Lookout Trail',
        2,
        '/static/gpx/251_Lookout_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Chatfield Hollow Park Trail',
        2,
        '/static/gpx/252_Chatfield_Hollow_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Lookout Spur Trail',
        2,
        '/static/gpx/253_Lookout_Spur_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Chimney Spur Trail',
        2,
        '/static/gpx/254_Chimney_Spur_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Deep Woods Access Trail',
        2,
        '/static/gpx/255_Deep_Woods_Access_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'West Crest Trail',
        2,
        '/static/gpx/256_West_Crest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Chatfield Park Path',
        2,
        '/static/gpx/257_Chatfield_Park_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pond Trail',
        2,
        '/static/gpx/258_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Paul F Wildermann',
        2,
        '/static/gpx/259_Paul_F_Wildermann.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Cockaponset Forest Path',
        2,
        '/static/gpx/260_Cockaponset_Forest_Path.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kay Fullerton Trail',
        2,
        '/static/gpx/261_Kay_Fullerton_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinimay Trail',
        1,
        '/static/gpx/262_Quinimay_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Cowboy Way Trail',
        2,
        '/static/gpx/263_Cowboy_Way_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Muck Rock Road Trail',
        2,
        '/static/gpx/264_Muck_Rock_Road_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Weber Road Trail',
        2,
        '/static/gpx/265_Weber_Road_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Beechnut Bog Trail',
        2,
        '/static/gpx/266_Beechnut_Bog_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Wood Road Trail',
        2,
        '/static/gpx/267_Wood_Road_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bumpy Hill Road Trail',
        2,
        '/static/gpx/268_Bumpy_Hill_Road_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kristens Way Trail',
        2,
        '/static/gpx/269_Kristens_Way_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Messerschmidt Lane Trail',
        2,
        '/static/gpx/270_Messerschmidt_Lane_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tower Hill Connector Trail',
        2,
        '/static/gpx/271_Tower_Hill_Connector_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mattabesset Trail',
        2,
        '/static/gpx/272_Mattabesset_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mattabasset Trail',
        2,
        '/static/gpx/273_Mattabasset_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Old Mattebesset Trail',
        2,
        '/static/gpx/274_Old_Mattebesset_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Huntington Park Trail',
        2,
        '/static/gpx/275_Huntington_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Huntington Ridge Trail',
        2,
        '/static/gpx/276_Huntington_Ridge_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Aspetuck Valley Trail',
        2,
        '/static/gpx/277_Aspetuck_Valley_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Vista Trail',
        2,
        '/static/gpx/278_Vista_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Devils Hopyard Park Trail',
        2,
        '/static/gpx/279_Devils_Hopyard_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Witch Hazel/Millington Trail',
        2,
        '/static/gpx/280_Witch_Hazel_Millington_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Millington Trail',
        2,
        '/static/gpx/281_Millington_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Loop Trail',
        2,
        '/static/gpx/282_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Witch Hazel Trail',
        2,
        '/static/gpx/283_Witch_Hazel_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Woodcutters Trail',
        2,
        '/static/gpx/284_Woodcutters_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Chapman Falls Trail',
        2,
        '/static/gpx/285_Chapman_Falls_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Devils Oven Spur Trail',
        2,
        '/static/gpx/286_Devils_Oven_Spur_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Maxs Trail',
        2,
        '/static/gpx/287_Maxs_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Machimoodus Park Trail',
        2,
        '/static/gpx/288_Machimoodus_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Fishermans Trail',
        0,
        '/static/gpx/289_Fishermans_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Ccc Trail',
        2,
        '/static/gpx/290_Ccc_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Natchaug Trail',
        2,
        '/static/gpx/291_Natchaug_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Natchaug Forest Trail',
        2,
        '/static/gpx/292_Natchaug_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Goodwin Forest Trail',
        2,
        '/static/gpx/293_Goodwin_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pine Acres Pond Trail',
        2,
        '/static/gpx/294_Pine_Acres_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Brown Hill Pond Trail',
        2,
        '/static/gpx/295_Brown_Hill_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Yellow White Loop Trail',
        2,
        '/static/gpx/296_Yellow_White_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Red Yellow Connector Trail',
        2,
        '/static/gpx/297_Red_Yellow_Connector_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Governor''S Island Trail',
        2,
        '/static/gpx/298_Governor_S_Island_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Goodwin Foresttrail',
        2,
        '/static/gpx/299_Goodwin_Foresttrail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Forest Discovery Trail',
        2,
        '/static/gpx/300_Forest_Discovery_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Goodwin Heritage Trail',
        2,
        '/static/gpx/301_Goodwin_Heritage_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Crest',
        2,
        '/static/gpx/302_Crest.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mansfield Hollow Park Trail',
        2,
        '/static/gpx/303_Mansfield_Hollow_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nipmuck Trail - East Branch',
        1,
        '/static/gpx/304_Nipmuck_Trail___East_Branch.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nipmuck Alternate',
        2,
        '/static/gpx/305_Nipmuck_Alternate.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mashamoquet Brook Nature Trail',
        0,
        '/static/gpx/306_Mashamoquet_Brook_Nature_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nipmuck Forest Trail',
        2,
        '/static/gpx/307_Nipmuck_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Morey Pond Trail',
        2,
        '/static/gpx/308_Morey_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nipmuck Foreat Trail',
        2,
        '/static/gpx/309_Nipmuck_Foreat_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pharisee Rock Trail',
        2,
        '/static/gpx/310_Pharisee_Rock_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pachaug Forest Trail',
        2,
        '/static/gpx/311_Pachaug_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pachaug Trail',
        2,
        '/static/gpx/312_Pachaug_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Canonicus Trail',
        2,
        '/static/gpx/313_Canonicus_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pachaug',
        2,
        '/static/gpx/314_Pachaug.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Laurel Loop Trail',
        2,
        '/static/gpx/315_Laurel_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pachaug/Nehantic Connector',
        2,
        '/static/gpx/316_Pachaug_Nehantic_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pachaug/Tippecansett Connector',
        2,
        '/static/gpx/317_Pachaug_Tippecansett_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nehantic/Pachaug Connector',
        2,
        '/static/gpx/318_Nehantic_Pachaug_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinebaug/Pachaug Connector',
        2,
        '/static/gpx/319_Quinebaug_Pachaug_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinebaug Trail',
        2,
        '/static/gpx/320_Quinebaug_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pachaug/Narragansett Connector',
        2,
        '/static/gpx/321_Pachaug_Narragansett_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Narragansett Trail',
        2,
        '/static/gpx/322_Narragansett_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Green Falls Loop Trail',
        2,
        '/static/gpx/323_Green_Falls_Loop_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Green Falls Water Access Trail',
        2,
        '/static/gpx/324_Green_Falls_Water_Access_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Freeman Trail',
        2,
        '/static/gpx/325_Freeman_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tippecansett Trail',
        2,
        '/static/gpx/326_Tippecansett_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Tippecansett/Freeman Trail',
        2,
        '/static/gpx/327_Tippecansett_Freeman_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Green Falls Pond Trail',
        1,
        '/static/gpx/328_Green_Falls_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nehantic/Pachaug Trail',
        2,
        '/static/gpx/329_Nehantic_Pachaug_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Phillips Pond Spur Trail',
        2,
        '/static/gpx/330_Phillips_Pond_Spur_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quinebaug/Nehantic Connector',
        2,
        '/static/gpx/331_Quinebaug_Nehantic_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nehantic/Quinebaug Connector',
        0,
        '/static/gpx/332_Nehantic_Quinebaug_Connector.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Patagansett Trail',
        1,
        '/static/gpx/333_Patagansett_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Paugussett Forest Trail',
        2,
        '/static/gpx/334_Paugussett_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Zoar Trail',
        2,
        '/static/gpx/335_Zoar_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Lillinonah Trail',
        2,
        '/static/gpx/336_Lillinonah_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Zoar Trail (Old)',
        2,
        '/static/gpx/337_Zoar_Trail__Old_.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Upper Gussy Trail',
        2,
        '/static/gpx/338_Upper_Gussy_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Pierrepont Park Trail',
        2,
        '/static/gpx/339_Pierrepont_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shenipsit Forest Trail',
        2,
        '/static/gpx/340_Shenipsit_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Quary Trail',
        2,
        '/static/gpx/341_Quary_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Shenipsit Forest Road',
        2,
        '/static/gpx/342_Shenipsit_Forest_Road.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Topsmead Forest Trail',
        2,
        '/static/gpx/343_Topsmead_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Edith M Chase Ecology Trail',
        2,
        '/static/gpx/344_Edith_M_Chase_Ecology_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bernard H Stairs Trail',
        2,
        '/static/gpx/345_Bernard_H_Stairs_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'West Rock Park Trail',
        2,
        '/static/gpx/346_West_Rock_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'West Rock Summit Trail',
        2,
        '/static/gpx/347_West_Rock_Summit_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Regicides Trail',
        2,
        '/static/gpx/348_Regicides_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sanford Feeder Trail',
        2,
        '/static/gpx/349_Sanford_Feeder_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'North Summit Trail',
        2,
        '/static/gpx/350_North_Summit_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Westville Feeder Trail',
        2,
        '/static/gpx/351_Westville_Feeder_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'West Rock Park Road',
        1,
        '/static/gpx/352_West_Rock_Park_Road.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Bennetts Pond Trail',
        0,
        '/static/gpx/353_Bennetts_Pond_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Ives Trail',
        2,
        '/static/gpx/354_Ives_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Ridgefield Open Space Trail',
        2,
        '/static/gpx/355_Ridgefield_Open_Space_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'George Dudley Seymour Park Trail',
        1,
        '/static/gpx/356_George_Dudley_Seymour_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Grta',
        1,
        '/static/gpx/357_Grta.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mohegan Forest Trail',
        1,
        '/static/gpx/358_Mohegan_Forest_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Mount Bushnell Trail',
        0,
        '/static/gpx/359_Mount_Bushnell_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Nye Holman Trail',
        2,
        '/static/gpx/360_Nye_Holman_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Al''S Trail',
        2,
        '/static/gpx/361_Al_S_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Salt Rock State Park Trail',
        2,
        '/static/gpx/362_Salt_Rock_State_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Scantic River Trail',
        1,
        '/static/gpx/363_Scantic_River_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Scantic River Park Trail',
        1,
        '/static/gpx/364_Scantic_River_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Scantic Park Access',
        2,
        '/static/gpx/365_Scantic_Park_Access.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Sunrise Park Trail',
        1,
        '/static/gpx/366_Sunrise_Park_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kitchel Trail',
        1,
        '/static/gpx/367_Kitchel_Trail.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Old Driveway',
        1,
        '/static/gpx/368_Old_Driveway.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Kitchel',
        1,
        '/static/gpx/369_Kitchel.gpx',
        'USA'
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country"
      ) VALUES(
        2,
        'Driveway',
        2,
        '/static/gpx/370_Driveway.gpx',
        'USA'
      );
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2)
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        8,
        122,
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Marvin O''Kon MD',
        'http://harsh-rocket.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        2,
        43,
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Miss Heidi Labadie',
        'http://miserable-widget.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        8,
        130,
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Bernadette Bauch',
        'https://fitting-hypothermia.name',
        null
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        10,
        67,
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Sherman Rempel',
        'http://muffled-gliding.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        5,
        49,
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'George Dibbert',
        'https://thoughtful-creator.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        2,
        53,
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Lora Marquardt',
        'https://misguided-slot.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        5,
        76,
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Cecelia Schmitt MD',
        'https://buoyant-particular.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        3,
        59,
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Frederick Becker II',
        'https://grown-trailer.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        4,
        135,
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Patricia Fay',
        'https://flat-middleman.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        6,
        121,
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Gail Hane',
        'https://fitting-investment.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        6,
        148,
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Rudy Ullrich',
        'http://puzzling-lawyer.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        5,
        43,
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Amanda Yundt PhD',
        'http://scornful-spec.info',
        null
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        3,
        52,
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Jermaine Aufderhar',
        'http://amazing-driver.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        7,
        113,
        'Vernagthütte',
        'Austria',
        'Brandy Kreiger',
        'https://zigzag-rainstorm.name',
        null
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        3,
        124,
        'Wormser Hütte',
        'Austria',
        'Paul Rippin',
        'https://majestic-pod.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        5,
        132,
        'Biberacher Hütte',
        'Austria',
        'Hope Ferry',
        'http://whopping-residue.net',
        null
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        2,
        105,
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Rick Glover II',
        'http://fabulous-bather.net',
        null
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        1,
        131,
        'Hochwaldhütte',
        'Germany',
        'Michael Kassulke',
        'https://political-multimedia.name',
        null
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        7,
        78,
        'Kölner Eifelhütte',
        'Germany',
        'Suzanne Jerde Sr.',
        'http://unwelcome-resemblance.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        7,
        69,
        'Madrisahütte',
        'Austria',
        'Jeffrey Prohaska',
        'https://blue-ambition.info',
        null
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        7,
        97,
        'Dresdner Hütte',
        'Austria',
        'Chad Hilll',
        'https://elderly-legislator.net',
        null
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        9,
        125,
        'Fiderepasshütte',
        'Germany',
        'Armando Cassin',
        'http://dearest-liquid.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        7,
        94,
        'Göppinger Hütte',
        'Austria',
        'Monique Moen',
        'http://irresponsible-priest.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        4,
        77,
        'Oberzalimhütte',
        'Austria',
        'Jake Beer',
        'http://apprehensive-yogurt.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        6,
        85,
        'Rastkogelhütte',
        'Austria',
        'Sadie Bayer',
        'http://idealistic-alligator.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        2,
        80,
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Leon Mraz',
        'http://grotesque-example.com',
        null
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        5,
        123,
        'Kaltenberghütte',
        'Austria',
        'Lynn Stracke PhD',
        'https://careful-semicolon.info',
        null
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        9,
        64,
        'Schweinfurter Hütte',
        'Austria',
        'Andre Simonis',
        'http://deadly-climate.name',
        null
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        6,
        140,
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Jesus Daniel',
        'http://animated-proportion.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        7,
        52,
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Andrew Cartwright DVM',
        'https://humiliating-harmonize.name',
        null
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        2,
        133,
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Tabitha Reilly I',
        'https://stark-vector.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        9,
        88,
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Luther Beahan',
        'http://fresh-vacuum.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        1,
        38,
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Mrs. Angelica Rodriguez',
        'http://any-test.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        6,
        107,
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Lauren Zboncak DVM',
        'http://smug-stick.name',
        null
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        5,
        74,
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Pablo Champlin',
        'http://official-oval.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        6,
        70,
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Jamie Stracke',
        'http://grand-eddy.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        9,
        89,
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Lamar Schinner',
        'https://short-affiliate.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        10,
        60,
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Wendell Abshire',
        'http://amusing-zinc.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        2,
        42,
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Jill Hauck',
        'https://gummy-hypothesis.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        4,
        66,
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'April Miller',
        'http://french-organ.com',
        null
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        8,
        115,
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'George Cole',
        'http://quick-witted-flintlock.com',
        null
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        9,
        101,
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Guadalupe Anderson',
        'http://mellow-pony.net',
        null
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        1,
        101,
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Eva Treutel',
        'https://gracious-weeder.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        3,
        76,
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Thelma Romaguera',
        'http://far-flung-neologism.org',
        null
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        9,
        118,
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Flora McDermott',
        'https://delirious-bronze.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        5,
        92,
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Miss Kristie Stoltenberg',
        'http://scientific-genius.name',
        null
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        8,
        87,
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Lori Kutch',
        'http://smooth-robin.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        9,
        108,
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Luke Mills',
        'https://petty-water.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        2,
        49,
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Florence Schulist',
        'http://chief-dune.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        4,
        129,
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Ms. Jeremy Spinka',
        'https://empty-gap.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        6,
        140,
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Casey Hartmann',
        'https://dazzling-suede.info',
        null
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        6,
        88,
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Valerie Yost',
        'https://unnatural-departure.net',
        null
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        4,
        82,
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Israel Larson PhD',
        'http://smooth-freak.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        7,
        143,
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Damon Ritchie',
        'http://high-level-stem.com',
        null
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        8,
        141,
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Lillie Bergnaum',
        'http://previous-assignment.org',
        null
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        7,
        46,
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Sonja Raynor',
        'https://apt-spatula.com',
        null
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        5,
        87,
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Carol Boehm',
        'https://diligent-cotton.com',
        null
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        5,
        84,
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Ethel Hagenes DVM',
        'http://thirsty-embellishment.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        3,
        145,
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Dr. Jackie Kshlerin',
        'http://grandiose-bathroom.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        10,
        91,
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Annette Littel',
        'https://beneficial-softdrink.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        8,
        87,
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Joe Konopelski',
        'https://intrepid-paranoia.org',
        null
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        8,
        145,
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Charles Bradtke',
        'http://prime-surrounds.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        5,
        69,
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Boyd Berge',
        'http://junior-employment.info',
        null
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        10,
        131,
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Cassandra Parisian',
        'https://foolhardy-sunday.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        4,
        62,
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Troy Aufderhar',
        'https://unique-religion.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        9,
        117,
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Loren Predovic',
        'https://understated-moonlight.info',
        null
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        7,
        62,
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Randy Smitham',
        'http://quick-tracking.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        9,
        77,
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Merle Lockman',
        'https://demanding-dispatch.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        2,
        84,
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Walter Romaguera',
        'https://confused-overheard.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        1,
        104,
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Alfredo Flatley',
        'http://velvety-gran.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        4,
        61,
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Doug Pacocha',
        'https://high-level-multimedia.name',
        null
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        3,
        80,
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Stewart Bernier',
        'http://conventional-classmate.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        9,
        126,
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Leah Kulas',
        'https://wan-parachute.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        2,
        53,
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Ismael Lynch',
        'https://right-bitten.info',
        null
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        8,
        100,
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Miss Rudy Reichert',
        'http://courageous-lox.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        9,
        43,
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Lucas Effertz',
        'https://boiling-amber.net',
        null
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        9,
        56,
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Bobbie Fisher',
        'https://anxious-stepdaughter.name',
        null
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        6,
        48,
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Jodi Rice',
        'http://known-dandelion.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        3,
        52,
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Julius Kulas',
        'https://bony-similarity.name',
        null
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        1,
        52,
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Gwendolyn Rosenbaum',
        'http://necessary-basil.name',
        null
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        5,
        84,
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Fernando Lebsack',
        'https://major-centimeter.info',
        null
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        6,
        43,
        'Wittener Hütte',
        'Germany',
        'Carl Witting',
        'https://concerned-vegetarian.name',
        null
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        9,
        86,
        'Hochjoch-Hospiz',
        'Austria',
        'Ronald Shields',
        'https://obedient-state.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        4,
        74,
        'Meilerhütte',
        'Germany',
        'Andre Kozey',
        'https://whirlwind-adaptation.org',
        null
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        6,
        135,
        'Gaudeamushütte',
        'Austria',
        'Miss Melissa Dooley',
        'http://gargantuan-submarine.com',
        null
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        6,
        89,
        'Rheydter Hütte',
        'Germany',
        'Ira Cummerata',
        'https://joint-step-grandmother.com',
        null
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        9,
        118,
        'Sektionshütte Krippen',
        'Germany',
        'Nicholas Gusikowski MD',
        'https://regal-teapot.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        4,
        63,
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Miss Monica Hermiston',
        'http://wicked-hometown.info',
        null
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        1,
        88,
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Dwayne Cassin',
        'https://impure-quantity.info',
        null
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        1,
        43,
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Carlos Schneider',
        'https://glorious-radio.com',
        null
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        2,
        91,
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Angelo Kohler',
        'https://grouchy-father-in-law.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        5,
        80,
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Fernando Schultz',
        'http://busy-competition.name',
        null
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        5,
        97,
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Isaac Wisoky',
        'https://careless-separation.org',
        null
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        2,
        98,
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Joey Becker',
        'https://scary-pimple.net',
        null
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        9,
        126,
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Mr. Brendan Harris V',
        'https://half-lifetime.info',
        null
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        10,
        45,
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Diana Toy',
        'https://imaginative-audience.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        7,
        50,
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Faye Bergnaum',
        'https://joyous-expansionism.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        8,
        67,
        'Dobra voda',
        'Suvobor, Serbia',
        'Gregg Upton',
        'http://apprehensive-boundary.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        6,
        101,
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Woodrow Franey',
        'https://massive-fennel.info',
        null
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        8,
        80,
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Fernando Haley',
        'https://fair-grammar.name',
        null
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        4,
        119,
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Victor Friesen',
        'http://dopey-migrant.net',
        null
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        6,
        101,
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Christie Hettinger',
        'https://knowing-bond.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        10,
        136,
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Leon Roberts',
        'https://worse-package.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        3,
        133,
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Hannah Mraz',
        'http://joyous-payoff.biz',
        null
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        6,
        127,
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Tasha Lang Jr.',
        'http://frayed-zero.com',
        null
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        1,
        68,
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Miss Adrienne Runolfsson',
        'http://infamous-wax.name',
        null
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        8,
        46,
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Jim Kemmer',
        'http://distinct-admission.org',
        null
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        1,
        126,
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Sheryl Leffler',
        'https://tiny-devastation.org',
        null
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '414 Moore Heights, Sophiafurt, Italy',
        'Sophiafurt',
        'Italy',
        'Hawaii',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        267,
        '9515 Moore Points, Rancho Palos Verdes, Italy',
        'Rancho Palos Verdes',
        'Italy',
        'Alabama',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        276,
        '9973 Luna Estates, Herthacester, Italy',
        'Herthacester',
        'Italy',
        'Louisiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        25,
        '40163 Prosacco Bypass, Dale City, Italy',
        'Dale City',
        'Italy',
        'Arizona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        54,
        '6627 Mozelle Ramp, New Sidney, Italy',
        'New Sidney',
        'Italy',
        'Idaho',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        103,
        '36159 Gerlach Walks, Fontana, Italy',
        'Fontana',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        140,
        '7579 Ondricka Knoll, South Alexandriaburgh, Italy',
        'South Alexandriaburgh',
        'Italy',
        'Delaware',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        86,
        '2169 Eulah Circle, East Salvadorfield, Italy',
        'East Salvadorfield',
        'Italy',
        'Indiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        183,
        '79777 Antonette Route, West Rosalyn, Italy',
        'West Rosalyn',
        'Italy',
        'Massachusetts',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        183,
        '9062 Bartell Ramp, Altenwerthton, Italy',
        'Altenwerthton',
        'Italy',
        'Nevada',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        112,
        '66834 Hamill River, West Hannahboro, Italy',
        'West Hannahboro',
        'Italy',
        'Louisiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        261,
        '570 Cormier Curve, Ratkechester, Italy',
        'Ratkechester',
        'Italy',
        'Ohio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        230,
        '6003 Eusebio Plains, Frederick, Italy',
        'Frederick',
        'Italy',
        'Nebraska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        215,
        '0460 Suzanne Points, Madysonport, Italy',
        'Madysonport',
        'Italy',
        'Utah',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        136,
        '5917 Kaitlin Extension, Ellisview, Italy',
        'Ellisview',
        'Italy',
        'Kentucky',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        269,
        '09662 Welch Spurs, Boca Raton, Italy',
        'Boca Raton',
        'Italy',
        'Iowa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        297,
        '758 Elmore Road, Vonborough, Italy',
        'Vonborough',
        'Italy',
        'Hawaii',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        226,
        '3865 Stanton Trail, Port Murphy, Italy',
        'Port Murphy',
        'Italy',
        'Tennessee',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        260,
        '84391 Clotilde Rapid, North Winifredchester, Italy',
        'North Winifredchester',
        'Italy',
        'Oklahoma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        135,
        '74246 Joanne Pines, Asafurt, Italy',
        'Asafurt',
        'Italy',
        'Maryland',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        105,
        '695 Heath Rue, Erdmanboro, Italy',
        'Erdmanboro',
        'Italy',
        'Nevada',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        201,
        '176 MacGyver Drive, West Priceville, Italy',
        'West Priceville',
        'Italy',
        'Wisconsin',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '93624 Mack Freeway, Sandrachester, Italy',
        'Sandrachester',
        'Italy',
        'Hawaii',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        131,
        '50051 Goyette Run, Port Rahul, Italy',
        'Port Rahul',
        'Italy',
        'Idaho',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        207,
        '892 Lucie Stravenue, Fort Darien, Italy',
        'Fort Darien',
        'Italy',
        'Wisconsin',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        223,
        '97552 McGlynn Extensions, Ogden, Italy',
        'Ogden',
        'Italy',
        'Kentucky',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        216,
        '41878 Skiles Springs, New Bobby, Italy',
        'New Bobby',
        'Italy',
        'Massachusetts',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        33,
        '300 Hammes Loop, Rennerstad, Italy',
        'Rennerstad',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        236,
        '823 McKenzie Lock, Jacobsonshire, Italy',
        'Jacobsonshire',
        'Italy',
        'South Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        239,
        '5378 Dereck Row, Alvisborough, Italy',
        'Alvisborough',
        'Italy',
        'South Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        84,
        '52775 Jaskolski Green, South Hobartville, Italy',
        'South Hobartville',
        'Italy',
        'Illinois',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        250,
        '491 Lindgren Springs, Lauderhill, Italy',
        'Lauderhill',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        169,
        '191 Adonis Expressway, Aliafield, Italy',
        'Aliafield',
        'Italy',
        'Idaho',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '903 Beer Courts, Keelinghaven, Italy',
        'Keelinghaven',
        'Italy',
        'New Jersey',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        42,
        '60862 Caroline Cliffs, Gislasonbury, Italy',
        'Gislasonbury',
        'Italy',
        'New Hampshire',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        93,
        '263 Jimmy Viaduct, West Marvin, Italy',
        'West Marvin',
        'Italy',
        'Mississippi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        239,
        '031 Lebsack Stravenue, Lake Deonte, Italy',
        'Lake Deonte',
        'Italy',
        'California',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        232,
        '3549 Boyle Circle, Silasland, Italy',
        'Silasland',
        'Italy',
        'Ohio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        54,
        '926 Lyda Manors, North Elmiraton, Italy',
        'North Elmiraton',
        'Italy',
        'Colorado',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        81,
        '696 Trycia Center, West Duaneland, Italy',
        'West Duaneland',
        'Italy',
        'Vermont',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '99052 Andre Radial, East Dino, Italy',
        'East Dino',
        'Italy',
        'Washington',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        30,
        '833 Birdie Avenue, Broomfield, Italy',
        'Broomfield',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        36,
        '435 Jacobi Divide, New Burdette, Italy',
        'New Burdette',
        'Italy',
        'New York',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        242,
        '22136 Wunsch Camp, Nienowberg, Italy',
        'Nienowberg',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        152,
        '657 Geo Centers, Normal, Italy',
        'Normal',
        'Italy',
        'South Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        251,
        '003 Patricia Rue, Alameda, Italy',
        'Alameda',
        'Italy',
        'Massachusetts',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        56,
        '46579 Boehm Extensions, Willaland, Italy',
        'Willaland',
        'Italy',
        'Mississippi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        250,
        '041 Dibbert Drive, West Jerodbury, Italy',
        'West Jerodbury',
        'Italy',
        'Minnesota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        39,
        '5341 Aufderhar Ford, New Stacyport, Italy',
        'New Stacyport',
        'Italy',
        'Hawaii',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        79,
        '1820 Nia Ways, Gary, Italy',
        'Gary',
        'Italy',
        'Iowa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        81,
        '333 Doris Burgs, Jefferson City, Italy',
        'Jefferson City',
        'Italy',
        'New Hampshire',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '779 Trudie Club, San Antonio, Italy',
        'San Antonio',
        'Italy',
        'Ohio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        225,
        '064 Casper Forge, O''Connellfield, Italy',
        'O''Connellfield',
        'Italy',
        'Colorado',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '47328 MacGyver Knolls, Veldahaven, Italy',
        'Veldahaven',
        'Italy',
        'Nebraska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        214,
        '89516 Ruthe Avenue, Brendafield, Italy',
        'Brendafield',
        'Italy',
        'Rhode Island',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        176,
        '0019 Maximillian Well, Bountiful, Italy',
        'Bountiful',
        'Italy',
        'Kentucky',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        123,
        '6349 Barrows Inlet, Salem, Italy',
        'Salem',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        40,
        '38111 Murazik Court, Winston-Salem, Italy',
        'Winston-Salem',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        257,
        '6417 Lind Lodge, Henrishire, Italy',
        'Henrishire',
        'Italy',
        'Pennsylvania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        222,
        '49119 Marquardt Trace, Purdystead, Italy',
        'Purdystead',
        'Italy',
        'New Jersey',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        163,
        '4823 Janet Estates, North Berniemouth, Italy',
        'North Berniemouth',
        'Italy',
        'Oklahoma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        65,
        '7248 Gwendolyn Dam, Towneview, Italy',
        'Towneview',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        96,
        '50360 Tyrese Loaf, Arcadia, Italy',
        'Arcadia',
        'Italy',
        'Illinois',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        47,
        '29451 Roberts Shoals, Ebertstead, Italy',
        'Ebertstead',
        'Italy',
        'Tennessee',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        295,
        '90950 Schroeder Prairie, West Bayleefield, Italy',
        'West Bayleefield',
        'Italy',
        'Connecticut',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        134,
        '4419 Francisco Springs, West Rahsaan, Italy',
        'West Rahsaan',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        227,
        '6175 Raynor Streets, Port Pink, Italy',
        'Port Pink',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        26,
        '28912 Bulah Flat, Port Keshaunview, Italy',
        'Port Keshaunview',
        'Italy',
        'Michigan',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        206,
        '94886 Hyatt Squares, Camylleville, Italy',
        'Camylleville',
        'Italy',
        'Arkansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '625 Markus Manor, East Alanabury, Italy',
        'East Alanabury',
        'Italy',
        'Pennsylvania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        234,
        '8295 Colin Motorway, Indio, Italy',
        'Indio',
        'Italy',
        'Tennessee',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        77,
        '3562 Dibbert Gardens, Brockborough, Italy',
        'Brockborough',
        'Italy',
        'Wyoming',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        241,
        '234 Aida Port, Brookhaven, Italy',
        'Brookhaven',
        'Italy',
        'Arizona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        132,
        '23743 Nitzsche Avenue, Fort Rubenstead, Italy',
        'Fort Rubenstead',
        'Italy',
        'Massachusetts',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        141,
        '826 Nathen Via, Nitzscheville, Italy',
        'Nitzscheville',
        'Italy',
        'Wyoming',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        206,
        '572 Kyler Row, Frederick, Italy',
        'Frederick',
        'Italy',
        'Maine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        89,
        '128 Myah Route, South Jarretside, Italy',
        'South Jarretside',
        'Italy',
        'New Jersey',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        52,
        '36553 Emard Knoll, Clementinaworth, Italy',
        'Clementinaworth',
        'Italy',
        'California',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        272,
        '91050 Arnaldo Lane, South Kenna, Italy',
        'South Kenna',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        180,
        '2459 Conroy Crescent, Pomona, Italy',
        'Pomona',
        'Italy',
        'New Mexico',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        61,
        '14357 Jake Course, Lake Laneberg, Italy',
        'Lake Laneberg',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        245,
        '833 Goyette Manors, Fort Maggie, Italy',
        'Fort Maggie',
        'Italy',
        'New Jersey',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        119,
        '77460 Paucek Knolls, Dillanside, Italy',
        'Dillanside',
        'Italy',
        'Oklahoma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        254,
        '0036 Sauer Drives, Taylorcester, Italy',
        'Taylorcester',
        'Italy',
        'Utah',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        294,
        '71709 Cummings Ridge, Lake Jackfurt, Italy',
        'Lake Jackfurt',
        'Italy',
        'North Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        159,
        '10847 Cartwright Course, Gabemouth, Italy',
        'Gabemouth',
        'Italy',
        'Massachusetts',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        83,
        '622 Roob Motorway, South Isabella, Italy',
        'South Isabella',
        'Italy',
        'Massachusetts',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        133,
        '156 Damaris Shoals, Port Suzanne, Italy',
        'Port Suzanne',
        'Italy',
        'West Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        268,
        '8678 West Ford, Fort Sidview, Italy',
        'Fort Sidview',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        70,
        '905 Dominique Burg, Deloresbury, Italy',
        'Deloresbury',
        'Italy',
        'Hawaii',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        265,
        '649 Dietrich Groves, West Barbaraland, Italy',
        'West Barbaraland',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        272,
        '44139 Art Port, Steubermouth, Italy',
        'Steubermouth',
        'Italy',
        'Illinois',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        51,
        '072 Bergstrom Plaza, Maiyamouth, Italy',
        'Maiyamouth',
        'Italy',
        'Oklahoma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        201,
        '29866 Morar Track, Fort Daren, Italy',
        'Fort Daren',
        'Italy',
        'California',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        34,
        '08611 Adolf Rapids, South Kiphaven, Italy',
        'South Kiphaven',
        'Italy',
        'Kansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        90,
        '6468 Flatley Cove, Wilmachester, Italy',
        'Wilmachester',
        'Italy',
        'Oregon',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        226,
        '575 Waters Place, Victorstad, Italy',
        'Victorstad',
        'Italy',
        'Louisiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        163,
        '380 Kihn Groves, Sandrineville, Italy',
        'Sandrineville',
        'Italy',
        'Michigan',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        61,
        '1957 Euna Walk, North Flavioland, Italy',
        'North Flavioland',
        'Italy',
        'Colorado',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        117,
        '4766 Breitenberg Manors, West Santosfield, Italy',
        'West Santosfield',
        'Italy',
        'Ohio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        54,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'New Hampshire',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        28,
        '708 Dejuan Lane, Melisaworth, Italy',
        'Melisaworth',
        'Italy',
        'Pennsylvania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        242,
        '354 Kelli Manor, Dashawnhaven, Italy',
        'Dashawnhaven',
        'Italy',
        'South Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        112,
        '7869 Athena Fords, Sauerfield, Italy',
        'Sauerfield',
        'Italy',
        'Alaska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        232,
        '3263 Bechtelar Run, East Carmen, Italy',
        'East Carmen',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        130,
        '947 Jakubowski Station, Fort Reeseside, Italy',
        'Fort Reeseside',
        'Italy',
        'Nebraska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        125,
        '43548 Hermiston Ferry, North Pedrostad, Italy',
        'North Pedrostad',
        'Italy',
        'Missouri',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        29,
        '067 Gutmann Forest, Fort Hazel, Italy',
        'Fort Hazel',
        'Italy',
        'Connecticut',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        50,
        '8355 Kling Vista, South Cordeliaville, Italy',
        'South Cordeliaville',
        'Italy',
        'New York',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        149,
        '626 Toni Walk, East Anna, Italy',
        'East Anna',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        153,
        '078 Stephan Harbor, Winonafurt, Italy',
        'Winonafurt',
        'Italy',
        'California',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        170,
        '7732 Predovic Ranch, Jeffersonville, Italy',
        'Jeffersonville',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        121,
        '6639 Ahmad Light, Haverhill, Italy',
        'Haverhill',
        'Italy',
        'Delaware',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        102,
        '0362 Talia Corner, East Kenneth, Italy',
        'East Kenneth',
        'Italy',
        'South Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        28,
        '599 Karina Isle, Mervintown, Italy',
        'Mervintown',
        'Italy',
        'Connecticut',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        206,
        '563 Dooley Skyway, Kubmouth, Italy',
        'Kubmouth',
        'Italy',
        'Mississippi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        237,
        '854 Noble Cliffs, Lodi, Italy',
        'Lodi',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        31,
        '90510 Von Shoal, Port Mateoport, Italy',
        'Port Mateoport',
        'Italy',
        'New Jersey',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        25,
        '104 Bechtelar Crossing, North Herbertstad, Italy',
        'North Herbertstad',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        90,
        '2709 Alec Forges, Yasmineport, Italy',
        'Yasmineport',
        'Italy',
        'New Jersey',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        85,
        '4637 Godfrey Bridge, Port Marjoryburgh, Italy',
        'Port Marjoryburgh',
        'Italy',
        'Minnesota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        267,
        '07457 Ferry Spur, Kaelacester, Italy',
        'Kaelacester',
        'Italy',
        'South Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        50,
        '7318 Thiel Throughway, Johnson City, Italy',
        'Johnson City',
        'Italy',
        'Rhode Island',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        57,
        '420 Fay Lake, Santa Rosa, Italy',
        'Santa Rosa',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        164,
        '52621 Crooks Pine, Giuseppebury, Italy',
        'Giuseppebury',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        223,
        '2137 Isadore Court, Genovevaton, Italy',
        'Genovevaton',
        'Italy',
        'South Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '82202 Olga Lakes, West Maximillia, Italy',
        'West Maximillia',
        'Italy',
        'Louisiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        172,
        '597 Mante Viaduct, North Jazlyn, Italy',
        'North Jazlyn',
        'Italy',
        'New Mexico',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        177,
        '13562 O''Hara Field, Johanview, Italy',
        'Johanview',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '5981 Wilkinson Light, Midwest City, Italy',
        'Midwest City',
        'Italy',
        'Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '25573 Keenan Causeway, North Hertaburgh, Italy',
        'North Hertaburgh',
        'Italy',
        'Michigan',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        289,
        '62045 Emily Well, Stromanbury, Italy',
        'Stromanbury',
        'Italy',
        'Connecticut',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        236,
        '629 Morissette Highway, Brayanport, Italy',
        'Brayanport',
        'Italy',
        'Utah',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        92,
        '2531 Magdalen Alley, McKinney, Italy',
        'McKinney',
        'Italy',
        'Indiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        287,
        '509 Kreiger Mills, North Gunner, Italy',
        'North Gunner',
        'Italy',
        'Delaware',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        238,
        '636 Kautzer Orchard, Michelleview, Italy',
        'Michelleview',
        'Italy',
        'Vermont',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '3085 Bernhard Course, Littelboro, Italy',
        'Littelboro',
        'Italy',
        'Indiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '829 Maximillia Way, Cecilstead, Italy',
        'Cecilstead',
        'Italy',
        'Louisiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        210,
        '6628 Hoeger Falls, South Guiseppe, Italy',
        'South Guiseppe',
        'Italy',
        'Florida',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '21054 Jenkins Pines, Baltimore, Italy',
        'Baltimore',
        'Italy',
        'Ohio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        271,
        '835 Max Radial, Gloverworth, Italy',
        'Gloverworth',
        'Italy',
        'Wisconsin',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        148,
        '03063 Konopelski Light, Gilesstead, Italy',
        'Gilesstead',
        'Italy',
        'Maryland',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        132,
        '2114 Bernice Walk, Loveland, Italy',
        'Loveland',
        'Italy',
        'Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        52,
        '6985 Rohan Coves, West Joshuaborough, Italy',
        'West Joshuaborough',
        'Italy',
        'South Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        111,
        '478 Friesen Cape, Martystead, Italy',
        'Martystead',
        'Italy',
        'West Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        25,
        '4537 Johnathon Vista, Milwaukee, Italy',
        'Milwaukee',
        'Italy',
        'Tennessee',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        27,
        '80688 Ondricka Points, Nicholeside, Italy',
        'Nicholeside',
        'Italy',
        'Alaska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        52,
        '93924 Lisandro Creek, Carrollfurt, Italy',
        'Carrollfurt',
        'Italy',
        'Wisconsin',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        89,
        '702 Prohaska Shoal, Berkeley, Italy',
        'Berkeley',
        'Italy',
        'Oregon',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        137,
        '49083 Justen Ford, Dudleyland, Italy',
        'Dudleyland',
        'Italy',
        'Michigan',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        63,
        '24975 Gottlieb Mills, Alysachester, Italy',
        'Alysachester',
        'Italy',
        'California',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        114,
        '610 Pfannerstill Drives, New Delpha, Italy',
        'New Delpha',
        'Italy',
        'Kansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        240,
        '92869 Fatima Crossroad, Boganview, Italy',
        'Boganview',
        'Italy',
        'Wisconsin',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        142,
        '1783 Araceli Glens, Cruzfield, Italy',
        'Cruzfield',
        'Italy',
        'Oregon',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        70,
        '26592 Spencer Drive, South Eldridgehaven, Italy',
        'South Eldridgehaven',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        214,
        '65434 Wiza Ville, Shawnview, Italy',
        'Shawnview',
        'Italy',
        'Connecticut',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        268,
        '724 Dominique Shores, New Reecebury, Italy',
        'New Reecebury',
        'Italy',
        'Nebraska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        295,
        '46450 Darby Mountain, Fort Maida, Italy',
        'Fort Maida',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        98,
        '7053 Cormier Manor, North Jessycaside, Italy',
        'North Jessycaside',
        'Italy',
        'Nebraska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        90,
        '3944 Goyette Pines, Port Hailee, Italy',
        'Port Hailee',
        'Italy',
        'Wyoming',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        36,
        '6128 Benedict Unions, Ellicott City, Italy',
        'Ellicott City',
        'Italy',
        'Oregon',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        149,
        '255 Ebert Parkways, West Moniquestead, Italy',
        'West Moniquestead',
        'Italy',
        'New Jersey',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        246,
        '01874 Chanel Fields, Carliehaven, Italy',
        'Carliehaven',
        'Italy',
        'Wyoming',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        112,
        '69088 Green Cliff, Lake Alisonfield, Italy',
        'Lake Alisonfield',
        'Italy',
        'South Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        134,
        '67158 Nyasia Place, Conntown, Italy',
        'Conntown',
        'Italy',
        'Tennessee',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '4132 Katarina Cove, Neldaberg, Italy',
        'Neldaberg',
        'Italy',
        'Wyoming',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        258,
        '589 Brakus Shores, New Nicoletteville, Italy',
        'New Nicoletteville',
        'Italy',
        'Oklahoma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        253,
        '0826 Batz Extension, Rodrigoland, Italy',
        'Rodrigoland',
        'Italy',
        'Ohio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        143,
        '65988 Walsh Manors, Warwick, Italy',
        'Warwick',
        'Italy',
        'Wisconsin',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        71,
        '7692 Elvera Stravenue, Lake Elmore, Italy',
        'Lake Elmore',
        'Italy',
        'Minnesota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        92,
        '31788 Anderson Isle, Fort Myers, Italy',
        'Fort Myers',
        'Italy',
        'Vermont',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        32,
        '171 Waelchi Mission, Lake Aliyahboro, Italy',
        'Lake Aliyahboro',
        'Italy',
        'Georgia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        273,
        '73217 Hand Parkway, Fort Elenorchester, Italy',
        'Fort Elenorchester',
        'Italy',
        'Minnesota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        150,
        '43038 Kacey Harbor, Fort Cecelia, Italy',
        'Fort Cecelia',
        'Italy',
        'Idaho',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        28,
        '887 Ernest Forge, Arloboro, Italy',
        'Arloboro',
        'Italy',
        'Arizona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        228,
        '9502 Vivian Spur, Oscarfield, Italy',
        'Oscarfield',
        'Italy',
        'North Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        123,
        '89135 Braun Coves, Lehigh Acres, Italy',
        'Lehigh Acres',
        'Italy',
        'South Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        103,
        '3110 Desiree Fields, Littelside, Italy',
        'Littelside',
        'Italy',
        'Arkansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        138,
        '0821 Coralie Shore, New Douglasborough, Italy',
        'New Douglasborough',
        'Italy',
        'Kansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        165,
        '88504 Cronin Camp, Glendale, Italy',
        'Glendale',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        48,
        '07742 Sebastian Mountain, West Noratown, Italy',
        'West Noratown',
        'Italy',
        'Ohio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        158,
        '402 Amos Bridge, Lake Estherfield, Italy',
        'Lake Estherfield',
        'Italy',
        'Alabama',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '43626 Weldon Wall, Yvettefurt, Italy',
        'Yvettefurt',
        'Italy',
        'New Jersey',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        191,
        '88990 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'North Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        75,
        '4036 Bailey Prairie, Lake Noemieland, Italy',
        'Lake Noemieland',
        'Italy',
        'Maryland',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        59,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'Alaska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        159,
        '38550 Stracke Rue, Schowalterhaven, Italy',
        'Schowalterhaven',
        'Italy',
        'Wisconsin',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        81,
        '7314 Demarco Lane, Gulgowskimouth, Italy',
        'Gulgowskimouth',
        'Italy',
        'Kentucky',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        172,
        '48765 Lyda Club, Donnellybury, Italy',
        'Donnellybury',
        'Italy',
        'Michigan',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        58,
        '2783 Mosciski Terrace, Dandrefort, Italy',
        'Dandrefort',
        'Italy',
        'Alaska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        245,
        '9105 Joany Curve, Deionshire, Italy',
        'Deionshire',
        'Italy',
        'Oregon',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        278,
        '0560 Beier Crest, East Silas, Italy',
        'East Silas',
        'Italy',
        'Idaho',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        79,
        '3494 Wolff Court, Fort Alexis, Italy',
        'Fort Alexis',
        'Italy',
        'Iowa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        72,
        '1437 Jones Track, West Kaden, Italy',
        'West Kaden',
        'Italy',
        'Alabama',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        214,
        '7956 Lupe Plains, North Ewellshire, Italy',
        'North Ewellshire',
        'Italy',
        'South Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        278,
        '228 Efren Ways, Elizabethborough, Italy',
        'Elizabethborough',
        'Italy',
        'New York',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        100,
        '1225 Bednar Green, Jarretstead, Italy',
        'Jarretstead',
        'Italy',
        'North Dakota',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        97,
        '64883 Ernestine Bypass, Lake Carlie, Italy',
        'Lake Carlie',
        'Italy',
        'Louisiana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        149,
        '568 Myles Junction, South Minerva, Italy',
        'South Minerva',
        'Italy',
        'Kansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        146,
        '8295 Lavada Ford, Kreigerfurt, Italy',
        'Kreigerfurt',
        'Italy',
        'Mississippi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        246,
        '912 Reichel Crossing, Harrisonburg, Italy',
        'Harrisonburg',
        'Italy',
        'Kansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        177,
        '0196 Williamson Walks, Boganstad, Italy',
        'Boganstad',
        'Italy',
        'Kentucky',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '2098 Jimmy Wall, Runtefurt, Italy',
        'Runtefurt',
        'Italy',
        'Illinois',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        143,
        '6634 Huel Greens, South Ava, Italy',
        'South Ava',
        'Italy',
        'Pennsylvania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        199,
        '74444 Kutch Alley, East Alexie, Italy',
        'East Alexie',
        'Italy',
        'New Mexico',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        83,
        '72845 Abelardo Islands, West Elodystad, Italy',
        'West Elodystad',
        'Italy',
        'Massachusetts',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        246,
        '97667 Aaron Flats, Antoinettefort, Italy',
        'Antoinettefort',
        'Italy',
        'New Hampshire',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        276,
        '77128 Aida River, Apopka, Italy',
        'Apopka',
        'Italy',
        'New York',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        273,
        '42923 Dooley Squares, Funkland, Italy',
        'Funkland',
        'Italy',
        'Maine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        165,
        '89220 Kelsi Knolls, Port Lucyfurt, Italy',
        'Port Lucyfurt',
        'Italy',
        'Maine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        262,
        '602 Wolff Circles, Vallejo, Italy',
        'Vallejo',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        71,
        '892 Larson Rapids, East Krystal, Italy',
        'East Krystal',
        'Italy',
        'Connecticut',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '38494 Bogisich Pine, Cormierfurt, Italy',
        'Cormierfurt',
        'Italy',
        'New Mexico',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        182,
        '09940 Lucas Cove, North Miles, Italy',
        'North Miles',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        207,
        '3312 Luna Cliff, Stokesberg, Italy',
        'Stokesberg',
        'Italy',
        'Missouri',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        80,
        '3707 Stark Junctions, Nicolaschester, Italy',
        'Nicolaschester',
        'Italy',
        'Colorado',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        203,
        '614 Taylor Vista, Gilbert, Italy',
        'Gilbert',
        'Italy',
        'Arkansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        218,
        '971 Rohan Extensions, Funkshire, Italy',
        'Funkshire',
        'Italy',
        'Iowa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        213,
        '5804 Melvina Meadows, Fort Lauderdale, Italy',
        'Fort Lauderdale',
        'Italy',
        'Pennsylvania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        284,
        '8958 Kuhn Island, Vallejo, Italy',
        'Vallejo',
        'Italy',
        'Nebraska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        93,
        '99332 Ernestine Harbors, New Kristoffer, Italy',
        'New Kristoffer',
        'Italy',
        'South Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '164 Tito Ranch, Darefurt, Italy',
        'Darefurt',
        'Italy',
        'Wisconsin',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        240,
        '16465 Hickle Overpass, Lake Lesterworth, Italy',
        'Lake Lesterworth',
        'Italy',
        'Idaho',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        232,
        '7073 Isaias Inlet, Hoppeshire, Italy',
        'Hoppeshire',
        'Italy',
        'Illinois',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        108,
        '474 O''Kon Valley, Marisolland, Italy',
        'Marisolland',
        'Italy',
        'Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        89,
        '46659 Norbert Rapids, Estrellafort, Italy',
        'Estrellafort',
        'Italy',
        'Vermont',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        48,
        '733 Weber Heights, Fort Americoburgh, Italy',
        'Fort Americoburgh',
        'Italy',
        'Connecticut',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        34,
        '212 Simone Circle, East Spencer, Italy',
        'East Spencer',
        'Italy',
        'Arizona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        93,
        '398 Jakubowski Ridges, Denver, Italy',
        'Denver',
        'Italy',
        'Tennessee',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        117,
        '5266 Jerrod Ways, South Katrinecester, Italy',
        'South Katrinecester',
        'Italy',
        'Missouri',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        132,
        '444 Carlee Circle, Gutmannview, Italy',
        'Gutmannview',
        'Italy',
        'Montana',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        232,
        '33926 Feest Forest, Kayabury, Italy',
        'Kayabury',
        'Italy',
        'Vermont',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        149,
        '0723 Lenna Course, Reillystead, Italy',
        'Reillystead',
        'Italy',
        'Arizona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        160,
        '7186 King Shore, East Rockymouth, Italy',
        'East Rockymouth',
        'Italy',
        'Oklahoma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        227,
        '228 Gibson Hills, El Dorado Hills, Italy',
        'El Dorado Hills',
        'Italy',
        'Florida',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        188,
        '30001 Prohaska Courts, Josianecester, Italy',
        'Josianecester',
        'Italy',
        'Colorado',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        245,
        '309 Donavon Crossroad, Cedar Hill, Italy',
        'Cedar Hill',
        'Italy',
        'Maryland',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        69,
        '63094 Rippin Port, West Marieview, Italy',
        'West Marieview',
        'Italy',
        'Utah',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        206,
        '2149 Erdman Fall, Port Thelma, Italy',
        'Port Thelma',
        'Italy',
        'Alaska',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        64,
        '430 Langworth Station, Port Shermanfield, Italy',
        'Port Shermanfield',
        'Italy',
        'Utah',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        246,
        '0101 Lehner Groves, West Kobecester, Italy',
        'West Kobecester',
        'Italy',
        'Michigan',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        280,
        '4005 Prohaska Forge, Jerdecester, Italy',
        'Jerdecester',
        'Italy',
        'Nevada',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        88,
        '512 Mitchell Divide, New Caroline, Italy',
        'New Caroline',
        'Italy',
        'South Carolina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        69,
        '19932 Ferry Burg, Lethafurt, Italy',
        'Lethafurt',
        'Italy',
        'Florida',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        266,
        '4536 Hahn Ridge, Kingsport, Italy',
        'Kingsport',
        'Italy',
        'Oklahoma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        80,
        '38726 Aric Tunnel, Eduardoside, Italy',
        'Eduardoside',
        'Italy',
        'Pennsylvania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        37,
        '066 Dickens Oval, Maryamton, Italy',
        'Maryamton',
        'Italy',
        'Texas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        189,
        '0535 Grant Mount, Leilaburgh, Italy',
        'Leilaburgh',
        'Italy',
        'West Virginia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        143,
        '443 Gibson Cape, Pinellas Park, Italy',
        'Pinellas Park',
        'Italy',
        'New York',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '9457 Carolyne Club, Raphaellebury, Italy',
        'Raphaellebury',
        'Italy',
        'Arkansas',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        238,
        '536 O''Hara Crossing, Lukastown, Italy',
        'Lukastown',
        'Italy',
        'Kentucky',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        120,
        '49812 Schultz Locks, East Manuel, Italy',
        'East Manuel',
        'Italy',
        'Iowa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        97,
        '18832 Turner Station, North Odellborough, Italy',
        'North Odellborough',
        'Italy',
        'Nevada',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        159,
        '8172 Effertz Crossroad, West Dameon, Italy',
        'West Dameon',
        'Italy',
        'New Hampshire',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        87,
        '7204 Doyle Crossing, West Seneca, Italy',
        'West Seneca',
        'Italy',
        'Nevada',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        107,
        '53834 Oral Trace, South Maximus, Italy',
        'South Maximus',
        'Italy',
        'Washington',
        ''
      );
    
  