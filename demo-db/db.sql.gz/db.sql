--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: insert_hut(integer, double precision, double precision, integer, numeric, character varying, character varying, character varying, character varying, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_hut(user_id integer, lat double precision, lon double precision, number_of_beds integer, price numeric, title character varying, address character varying, owner_name character varying, website character varying, elevation numeric) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation
    );
    END
    $$;


--
-- Name: insert_parking_lot(integer, double precision, double precision, character varying, integer, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.insert_parking_lot(user_id integer, lat double precision, lon double precision, name character varying, max_cars integer, address character varying, city character varying, country character varying, region character varying, province character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: hike_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hike_points ("hikeId", "pointId", index, type) FROM stdin;
\.


--
-- Data for Name: hikes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hikes (id, "userId", length, "expectedTime", ascent, difficulty, title, description, "gpxPath", distance, region, province, city, country) FROM stdin;
1	2	1.00	15	24.80	1	Airline Trail - Detour		/static/gpx/001_Airline_Trail___Detour.gpx	0.00	Asti		De Salvo lido	USA
2	2	1.30	18	10.30	2	Airline Trail		/static/gpx/002_Airline_Trail.gpx	0.00	Trapani		Borgo Eriberto lido	USA
3	2	0.80	12	22.60	0	Colchester Railroad		/static/gpx/003_Colchester_Railroad.gpx	0.00	Forlì-Cesena		Sesto Gautiero veneto	USA
4	2	1.00	15	15.30	2	Two Sister'S Preserve Loop Trail		/static/gpx/004_Two_Sister_S_Preserve_Loop_Trail.gpx	0.00	Carbonia-Iglesias		Iacopone a mare	USA
5	2	1.20	17	15.10	0	Putnam River Trail		/static/gpx/005_Putnam_River_Trail.gpx	0.00	Lecce		San Flaviana terme	USA
6	2	1.10	15	17.10	2	Airline Trail Bypass		/static/gpx/006_Airline_Trail_Bypass.gpx	0.00	Cagliari		Sesto Armando	USA
7	2	2.60	42	11.60	2	Indian Neck		/static/gpx/007_Indian_Neck.gpx	0.00	Terni		San Iole calabro	USA
8	2	3.20	40	24.70	0	Stony Creek		/static/gpx/008_Stony_Creek.gpx	0.00	Avellino		Postiglione nell'emilia	USA
9	2	7.70	101	18.00	2	Quarry-Westwoods		/static/gpx/009_Quarry_Westwoods.gpx	0.00	Belluno		San Giove	USA
10	2	3.00	37	6.60	1	Short Beach		/static/gpx/010_Short_Beach.gpx	0.00	Barletta-Andria-Trani		Eloisa laziale	USA
11	2	0.70	12	28.70	0	Charter Oak Greenway		/static/gpx/011_Charter_Oak_Greenway.gpx	0.00	Belluno		Alda umbro	USA
12	2	1.00	13	8.30	2	Bissell Greenway		/static/gpx/012_Bissell_Greenway.gpx	0.00	Cremona		San Severo	USA
13	2	1.20	15	11.10	2	Riverfront Trail System		/static/gpx/013_Riverfront_Trail_System.gpx	0.00	Ascoli Piceno		Magno nell'emilia	USA
14	2	0.80	11	24.70	2	Millers Pond Park Trail		/static/gpx/014_Millers_Pond_Park_Trail.gpx	0.00	Bergamo		Leonilda del friuli	USA
15	2	0.90	14	27.70	2	Mattabesett Trail		/static/gpx/015_Mattabesett_Trail.gpx	0.00	Bergamo		Borgo Mariano salentino	USA
16	2	0.80	10	29.60	2	Jefferson Park Trail		/static/gpx/016_Jefferson_Park_Trail.gpx	0.00	Enna		Quarto Eusebia sardo	USA
17	2	1.40	18	9.80	1	Mt. Nebo Park		/static/gpx/017_Mt__Nebo_Park.gpx	0.00	Brescia		Coletta a mare	USA
18	2	1.20	19	26.90	2	 		/static/gpx/018__.gpx	0.00	Savona		Toti lido	USA
19	2	1.30	19	11.50	2	Blinnshed Ridge Trail		/static/gpx/019_Blinnshed_Ridge_Trail.gpx	0.00	Alessandria		Borgo Violante	USA
20	2	0.60	7	8.90	2	Neck River Trail		/static/gpx/020_Neck_River_Trail.gpx	0.00	Bolzano		Consolata ligure	USA
21	2	1.50	25	14.40	2	Oil Mill Brook Trail		/static/gpx/021_Oil_Mill_Brook_Trail.gpx	0.00	Massa-Carrara		Faraci salentino	USA
22	2	0.80	10	24.40	2	Chatfield Trail		/static/gpx/022_Chatfield_Trail.gpx	0.00	Pistoia		Nicarete a mare	USA
23	2	1.50	21	5.30	2	Unamed Trail		/static/gpx/023_Unamed_Trail.gpx	0.00	Crotone		Sergio veneto	USA
24	2	0.90	15	18.00	2	Unnamed Trail		/static/gpx/024_Unnamed_Trail.gpx	0.00	Reggio Emilia		Agapito lido	USA
25	2	1.00	14	17.70	2	Lost Pond Trail		/static/gpx/025_Lost_Pond_Trail.gpx	0.00	Pordenone		Brunetti laziale	USA
26	2	1.20	18	9.50	2	Ccc Camp Hadley Trail		/static/gpx/026_Ccc_Camp_Hadley_Trail.gpx	0.00	Caltanissetta		Borgo Fulvia	USA
27	2	0.70	12	16.80	2	Double Loop Trail		/static/gpx/027_Double_Loop_Trail.gpx	0.00	Lucca		Ponziano terme	USA
28	2	1.40	22	29.90	2	Cockaponset Forest Trail		/static/gpx/028_Cockaponset_Forest_Trail.gpx	0.00	Cagliari		Spadafora ligure	USA
29	2	1.40	20	7.10	2	Westwoods Forest Trail		/static/gpx/029_Westwoods_Forest_Trail.gpx	0.00	Treviso		Borgo Agapito salentino	USA
30	2	1.30	21	16.30	2	Over Brook Trail		/static/gpx/030_Over_Brook_Trail.gpx	0.00	Torino		Settimo Stiliano	USA
31	2	1.50	25	27.30	2	Blinnshed Loop Trail		/static/gpx/031_Blinnshed_Loop_Trail.gpx	0.00	Trieste		Indelicato terme	USA
32	2	1.10	16	25.60	2	Unnamed Tsail		/static/gpx/032_Unnamed_Tsail.gpx	0.00	Matera		Sassi calabro	USA
33	2	1.50	22	29.70	2	Messerschmidt Wma Trail		/static/gpx/033_Messerschmidt_Wma_Trail.gpx	0.00	Pordenone		Settimo Luce	USA
34	2	1.00	13	14.00	2	Westwoods Nature Trail		/static/gpx/034_Westwoods_Nature_Trail.gpx	0.00	Vercelli		Borgo Fausto	USA
35	2	0.50	8	22.40	1	Housatonic Forest Trail		/static/gpx/035_Housatonic_Forest_Trail.gpx	0.00	Rovigo		Evangelista sardo	USA
36	2	1.10	15	27.90	0	Farmington Canal Trail		/static/gpx/036_Farmington_Canal_Trail.gpx	0.00	Teramo		San Tecla laziale	USA
37	2	1.20	17	28.80	0	Farmington River Trail		/static/gpx/037_Farmington_River_Trail.gpx	0.00	Alessandria		Guido salentino	USA
38	2	1.10	18	17.20	2	Farminton Canal Trail		/static/gpx/038_Farminton_Canal_Trail.gpx	0.00	Asti		Sesto Tiziana	USA
39	2	4.10	63	29.60	1	Hop River Trail		/static/gpx/039_Hop_River_Trail.gpx	0.00	Barletta-Andria-Trani		Quarto Virginio lido	USA
40	2	1.30	16	13.60	1	Housatonic Rail Trail		/static/gpx/040_Housatonic_Rail_Trail.gpx	0.00	Genova		Sesto Piero calabro	USA
41	2	1.40	22	11.30	1	Middletown Bikeway		/static/gpx/041_Middletown_Bikeway.gpx	0.00	Bari		Mori a mare	USA
42	2	1.00	17	10.80	2	Mattabesett Trolley Trail		/static/gpx/042_Mattabesett_Trolley_Trail.gpx	0.00	Udine		Fernanda veneto	USA
43	2	0.70	9	21.20	2	Moosup Valley State Park Trail		/static/gpx/043_Moosup_Valley_State_Park_Trail.gpx	0.00	Savona		Sesto Ermanno ligure	USA
44	2	1.10	18	6.00	1	Quinnebaug River Trail		/static/gpx/044_Quinnebaug_River_Trail.gpx	0.00	Gorizia		Settimo Alberto terme	USA
45	2	1.90	25	30.00	2	Quinnebaug Hatchery Trail		/static/gpx/045_Quinnebaug_Hatchery_Trail.gpx	0.00	Ferrara		San Alfredo del friuli	USA
46	2	1.20	17	12.50	2	Trolley Trail		/static/gpx/046_Trolley_Trail.gpx	0.00	Olbia-Tempio		Settimo Ventura	USA
47	2	1.20	15	25.70	2	Hopeville Park Trail		/static/gpx/047_Hopeville_Park_Trail.gpx	0.00	Agrigento		Salerno salentino	USA
48	2	1.50	22	20.70	2	Nehantic Trail		/static/gpx/048_Nehantic_Trail.gpx	0.00	Bari		San Quarto	USA
49	2	1.00	13	5.50	0	Camp Columbia Trail		/static/gpx/049_Camp_Columbia_Trail.gpx	0.00	Treviso		Settimo Arturo	USA
50	2	0.60	9	24.10	2	Dinosaur Park Trail		/static/gpx/050_Dinosaur_Park_Trail.gpx	0.00	Fermo		Quarto Orietta lido	USA
51	2	0.80	10	5.80	1	Day Pond Park Trail		/static/gpx/051_Day_Pond_Park_Trail.gpx	0.00	Vicenza		Borgo Prisca lido	USA
52	2	2.00	30	23.10	1	Salmon River Trail		/static/gpx/052_Salmon_River_Trail.gpx	0.00	Siracusa		Magda nell'emilia	USA
53	2	1.00	15	22.10	2	Salmon River Trial		/static/gpx/053_Salmon_River_Trial.gpx	0.00	Cagliari		Iolanda veneto	USA
54	2	1.10	17	15.90	0	Dennis Hill Park Trail		/static/gpx/054_Dennis_Hill_Park_Trail.gpx	0.00	Alessandria		Bruno laziale	USA
55	2	0.70	9	13.40	0	Kent Falls Park Trail		/static/gpx/055_Kent_Falls_Park_Trail.gpx	0.00	Grosseto		San Cassio del friuli	USA
56	2	1.50	21	5.10	1	Enders Forest Trail		/static/gpx/056_Enders_Forest_Trail.gpx	0.00	Medio Campidano		Borgo Filomena	USA
57	2	0.90	12	20.30	2	Gay City Park Trail		/static/gpx/057_Gay_City_Park_Trail.gpx	0.00	Pistoia		Liverani lido	USA
58	2	1.30	17	12.00	0	Split Rock Trail		/static/gpx/058_Split_Rock_Trail.gpx	0.00	Bologna		Quarto Liberata	USA
59	2	1.50	19	15.30	1	Gillette Castle Trail		/static/gpx/059_Gillette_Castle_Trail.gpx	0.00	Pistoia		Sesto Macaria	USA
60	2	1.30	21	12.30	0	Great Pond Forest Trail		/static/gpx/060_Great_Pond_Forest_Trail.gpx	0.00	Siracusa		Sesto Nina	USA
61	2	1.20	18	7.00	0	Haddam Meadows Park Trail		/static/gpx/061_Haddam_Meadows_Park_Trail.gpx	0.00	Barletta-Andria-Trani		Ludano a mare	USA
62	2	0.60	9	11.70	1	Haley Farm Park Trail		/static/gpx/062_Haley_Farm_Park_Trail.gpx	0.00	Ferrara		San Romola	USA
63	2	1.10	17	18.70	0	Nature Trail		/static/gpx/063_Nature_Trail.gpx	0.00	L'Aquila		Concetto nell'emilia	USA
64	2	1.30	20	17.40	0	Hammonasset Bike Path		/static/gpx/064_Hammonasset_Bike_Path.gpx	0.00	Lecce		Abelardo nell'emilia	USA
65	2	1.00	12	11.80	0	Hammonasset Park Boardwalk		/static/gpx/065_Hammonasset_Park_Boardwalk.gpx	0.00	Alessandria		San Cleopatra	USA
66	2	0.80	11	13.90	0	Willard Island Nature Trail		/static/gpx/066_Willard_Island_Nature_Trail.gpx	0.00	Rimini		Patroclo umbro	USA
67	2	0.60	10	26.50	0	Moraine Nature Trail		/static/gpx/067_Moraine_Nature_Trail.gpx	0.00	Barletta-Andria-Trani		Gino sardo	USA
68	2	0.50	8	22.20	2	Haystack Park Trail		/static/gpx/068_Haystack_Park_Trail.gpx	0.00	Messina		Sacchet sardo	USA
69	2	0.90	12	29.80	1	Higganum Reservoir Park Trail		/static/gpx/069_Higganum_Reservoir_Park_Trail.gpx	0.00	Piacenza		Settimo Aniello umbro	USA
70	2	0.90	15	23.30	2	Appalachian Trail		/static/gpx/070_Appalachian_Trail.gpx	0.00	Palermo		Silvia laziale	USA
71	2	1.00	14	6.10	2	Mohawk Trail		/static/gpx/071_Mohawk_Trail.gpx	0.00	Milano		Lucrezia salentino	USA
72	2	1.50	21	24.00	1	Pine Knob Loop		/static/gpx/072_Pine_Knob_Loop.gpx	0.00	Crotone		Monitore salentino	USA
73	2	2.60	33	8.20	0	Appalachian/Pine Knob Loop		/static/gpx/073_Appalachian_Pine_Knob_Loop.gpx	0.00	Brindisi		Settimo Liliana	USA
74	2	1.50	22	13.00	1	White Mountain Trail		/static/gpx/074_White_Mountain_Trail.gpx	0.00	Aosta		Ilda veneto	USA
75	2	1.40	24	10.50	1	River Trail		/static/gpx/075_River_Trail.gpx	0.00	Bologna		Francesco nell'emilia	USA
76	2	0.60	7	15.50	1	Hurd Park Trail		/static/gpx/076_Hurd_Park_Trail.gpx	0.00	Rimini		Bartolini laziale	USA
77	2	1.20	20	25.80	2	Paugussett Trail		/static/gpx/077_Paugussett_Trail.gpx	0.00	Fermo		Borgo Cirano	USA
78	2	1.10	18	28.70	2	Waterfall Trail		/static/gpx/078_Waterfall_Trail.gpx	0.00	Bologna		Settimo Maffeo lido	USA
79	2	1.40	20	14.50	0	Proposed Trail		/static/gpx/079_Proposed_Trail.gpx	0.00	Avellino		Carlo veneto	USA
80	2	0.80	12	7.90	2	Coincident Weber Road		/static/gpx/080_Coincident_Weber_Road.gpx	0.00	Parma		Settimo Genesia	USA
81	2	4.30	59	12.70	2	Macedonia Ridge Trail		/static/gpx/081_Macedonia_Ridge_Trail.gpx	0.00	Bologna		Vaccaro laziale	USA
82	2	0.80	10	12.00	1	Cobble Mountain Trail		/static/gpx/082_Cobble_Mountain_Trail.gpx	0.00	Nuoro		Roberti sardo	USA
83	2	1.20	20	28.20	0	Shenipsit Trail		/static/gpx/083_Shenipsit_Trail.gpx	0.00	Messina		San Demetria	USA
84	2	1.00	14	23.40	1	Meshomasic Forest Trail		/static/gpx/084_Meshomasic_Forest_Trail.gpx	0.00	Pescara		Trevisan sardo	USA
85	2	1.60	27	9.00	0	Crest Trail		/static/gpx/085_Crest_Trail.gpx	0.00	Frosinone		Borgo Aniceto	USA
86	2	0.70	12	12.40	1	Campground Trail		/static/gpx/086_Campground_Trail.gpx	0.00	Bolzano		San Flaviano	USA
87	2	0.90	12	10.70	2	Brook Trail		/static/gpx/087_Brook_Trail.gpx	0.00	Ravenna		Borgo Gioia	USA
88	2	0.60	7	24.80	2	North Ridge Loop Trail		/static/gpx/088_North_Ridge_Loop_Trail.gpx	0.00	Pesaro e Urbino		Vincenzo del friuli	USA
89	2	1.50	20	19.30	2	North Ridge Trail		/static/gpx/089_North_Ridge_Trail.gpx	0.00	Cagliari		San Ida calabro	USA
90	2	0.60	9	10.50	0	Miller Trail		/static/gpx/090_Miller_Trail.gpx	0.00	Rovigo		Marian laziale	USA
91	2	1.40	21	6.50	0	Miller Trail Spur		/static/gpx/091_Miller_Trail_Spur.gpx	0.00	Pistoia		Settimo Scolastica	USA
92	2	0.50	7	6.40	2	Pomperaug Trail		/static/gpx/092_Pomperaug_Trail.gpx	0.00	L'Aquila		Moras laziale	USA
93	2	0.60	10	11.30	1	Waramaug Lake Park Trail		/static/gpx/093_Waramaug_Lake_Park_Trail.gpx	0.00	Lecce		Alba terme	USA
94	2	0.90	14	7.50	0	Lovers Leap Park Trail		/static/gpx/094_Lovers_Leap_Park_Trail.gpx	0.00	Teramo		Settimo Simone veneto	USA
95	2	1.50	19	23.20	0	Mashamoquet Brook Park Trail		/static/gpx/095_Mashamoquet_Brook_Park_Trail.gpx	0.00	Pesaro e Urbino		Manno laziale	USA
96	2	1.40	17	22.00	2	Shenipsit		/static/gpx/096_Shenipsit.gpx	0.00	Livorno		Como salentino	USA
97	2	1.30	17	27.70	0	Nassahegon Forest Trail		/static/gpx/097_Nassahegon_Forest_Trail.gpx	0.00	Bologna		Cinelli laziale	USA
98	2	1.40	18	6.00	1	Black Spruce Bog Trail		/static/gpx/098_Black_Spruce_Bog_Trail.gpx	0.00	Palermo		Borgo Otilia	USA
99	2	1.50	23	11.00	2	Mohawk Forest Trail		/static/gpx/099_Mohawk_Forest_Trail.gpx	0.00	Vibo Valentia		Borgo Cornelia	USA
100	2	0.80	13	18.00	2	Ethan Allen Youth Trail		/static/gpx/100_Ethan_Allen_Youth_Trail.gpx	0.00	Gorizia		Sesto Muziano salentino	USA
101	2	1.50	18	16.40	1	Punch Brook Trail		/static/gpx/101_Punch_Brook_Trail.gpx	0.00	Crotone		Quarto Silvio	USA
102	2	1.00	13	29.30	1	Tunxis Trail		/static/gpx/102_Tunxis_Trail.gpx	0.00	Vibo Valentia		Sesto Davide	USA
103	2	0.80	13	5.30	0	Red Cedar Lake Trail		/static/gpx/103_Red_Cedar_Lake_Trail.gpx	0.00	Parma		Ferro calabro	USA
104	2	1.70	24	10.70	0	Under Mountain Trail		/static/gpx/104_Under_Mountain_Trail.gpx	0.00	Sassari		Sesto Gisella del friuli	USA
105	2	1.40	18	25.20	2	Mount Tom Trail		/static/gpx/105_Mount_Tom_Trail.gpx	0.00	Cremona		Piermarco lido	USA
106	2	0.50	7	11.00	0	Naugatuck Trail		/static/gpx/106_Naugatuck_Trail.gpx	0.00	Rieti		Settimo Pietro calabro	USA
107	2	1.40	17	14.90	2	Nehantic Forest Trail		/static/gpx/107_Nehantic_Forest_Trail.gpx	0.00	Perugia		Settimo Rolando	USA
108	2	1.40	19	22.00	0	Naugatuck Forest Trail		/static/gpx/108_Naugatuck_Forest_Trail.gpx	0.00	Nuoro		Ducci laziale	USA
109	2	1.10	13	21.50	0	Whitemore Trail		/static/gpx/109_Whitemore_Trail.gpx	0.00	Perugia		Leonardo laziale	USA
110	2	1.60	22	24.80	1	Quinnipiac Trail		/static/gpx/110_Quinnipiac_Trail.gpx	0.00	Rovigo		Settimo Silvana	USA
111	2	0.90	13	17.70	0	Nehantic Forest Trai		/static/gpx/111_Nehantic_Forest_Trai.gpx	0.00	Carbonia-Iglesias		Colella ligure	USA
112	2	1.30	16	23.50	2	Nepaug Forest Trail		/static/gpx/112_Nepaug_Forest_Trail.gpx	0.00	Lucca		Settimo Fosco veneto	USA
113	2	1.40	21	6.10	0	Naugatuck		/static/gpx/113_Naugatuck.gpx	0.00	Modena		Quarto Macaria nell'emilia	USA
114	2	1.10	19	18.30	1	Nyantaquit Trail		/static/gpx/114_Nyantaquit_Trail.gpx	0.00	Barletta-Andria-Trani		Tedeschi veneto	USA
115	2	1.50	19	23.80	2	Tipping Rock Loop Trail		/static/gpx/115_Tipping_Rock_Loop_Trail.gpx	0.00	Savona		Marcianò veneto	USA
116	2	0.70	12	26.60	0	Valley Outlook Trail		/static/gpx/116_Valley_Outlook_Trail.gpx	0.00	Carbonia-Iglesias		Quarto Mercurio nell'emilia	USA
117	2	1.50	18	15.00	1	Shelter 4 Loop Trail		/static/gpx/117_Shelter_4_Loop_Trail.gpx	0.00	Enna		Settimo Ildebrando	USA
118	2	1.40	18	15.70	1	Paugnut Forest Trail		/static/gpx/118_Paugnut_Forest_Trail.gpx	0.00	Caserta		Borgo Florina	USA
119	2	1.50	19	7.20	0	Charles L Pack Trail		/static/gpx/119_Charles_L_Pack_Trail.gpx	0.00	Pesaro e Urbino		Vecchi salentino	USA
120	2	1.40	23	20.50	0	Peoples Forest Trail		/static/gpx/120_Peoples_Forest_Trail.gpx	0.00	Firenze		Quarto Eberardo veneto	USA
121	2	2.60	37	27.80	1	Penwood Park Trail		/static/gpx/121_Penwood_Park_Trail.gpx	0.00	Ogliastra		Sesto Concordio sardo	USA
122	2	1.40	19	20.60	0	Quadick Red Trail		/static/gpx/122_Quadick_Red_Trail.gpx	0.00	Chieti		Quarto Crescenzio terme	USA
123	2	1.50	20	15.40	1	Pootatuck Forest Trail		/static/gpx/123_Pootatuck_Forest_Trail.gpx	0.00	Bari		Sesto Deanna	USA
124	2	1.30	16	9.50	0	River Highland Park Trail		/static/gpx/124_River_Highland_Park_Trail.gpx	0.00	Rimini		Borgo Iorio veneto	USA
125	2	1.00	13	29.10	1	Tunxis		/static/gpx/125_Tunxis.gpx	0.00	Varese		Capuano salentino	USA
126	2	0.90	13	23.80	0	Osbornedale Park Trail		/static/gpx/126_Osbornedale_Park_Trail.gpx	0.00	Modena		Borgo Egizia	USA
127	2	1.30	22	29.60	2	Old Furnace Park Trail		/static/gpx/127_Old_Furnace_Park_Trail.gpx	0.00	Pesaro e Urbino		Casini lido	USA
128	2	1.10	13	22.50	1	Old Furnace Trail		/static/gpx/128_Old_Furnace_Trail.gpx	0.00	Bolzano		Borgo Demetrio	USA
129	2	0.90	15	29.00	1	Kestral Trail		/static/gpx/129_Kestral_Trail.gpx	0.00	Chieti		De Rosa lido	USA
130	2	1.50	20	25.60	0	Warbler Trail		/static/gpx/130_Warbler_Trail.gpx	0.00	Trento		Corrado calabro	USA
131	2	1.70	25	14.70	2	Muir Trail		/static/gpx/131_Muir_Trail.gpx	0.00	Catanzaro		Quarto Orsino calabro	USA
132	2	0.50	6	11.30	2	Unnamed		/static/gpx/132_Unnamed.gpx	0.00	Rimini		San Aza	USA
133	2	1.20	20	7.10	1	Shadow Pond Nature Trail		/static/gpx/133_Shadow_Pond_Nature_Trail.gpx	0.00	Salerno		Kofler ligure	USA
134	2	0.80	13	22.30	1	Metacomet Trail		/static/gpx/134_Metacomet_Trail.gpx	0.00	Arezzo		San Eva veneto	USA
135	2	1.30	19	11.90	0	Metacomet Trail Bypass		/static/gpx/135_Metacomet_Trail_Bypass.gpx	0.00	Parma		Sesto Maurizio	USA
136	2	1.40	20	13.70	2	Jesse Gerard Trail		/static/gpx/136_Jesse_Gerard_Trail.gpx	0.00	Caltanissetta		Di Luca sardo	USA
137	2	1.00	16	27.70	1	Robert Ross Trail		/static/gpx/137_Robert_Ross_Trail.gpx	0.00	Pavia		Sesto Mina	USA
138	2	1.30	19	25.00	1	Agnes Bowen Trail		/static/gpx/138_Agnes_Bowen_Trail.gpx	0.00	Lucca		Goffredo ligure	USA
139	2	0.80	12	12.10	1	Elliot Bronson Trail		/static/gpx/139_Elliot_Bronson_Trail.gpx	0.00	Grosseto		Iovino sardo	USA
140	2	0.80	13	14.90	0	Walt Landgraf Trail		/static/gpx/140_Walt_Landgraf_Trail.gpx	0.00	Macerata		Borgo Lorella	USA
141	2	1.20	17	11.60	2	Platt Hill Park Trail		/static/gpx/141_Platt_Hill_Park_Trail.gpx	0.00	Piacenza		Giannini sardo	USA
142	2	1.20	16	14.20	2	Quadick Park Path		/static/gpx/142_Quadick_Park_Path.gpx	0.00	Potenza		Belotti salentino	USA
143	2	0.80	11	24.00	2	Rocky Neck Park Sidewalk		/static/gpx/143_Rocky_Neck_Park_Sidewalk.gpx	0.00	Pistoia		San Tiziana salentino	USA
144	2	1.40	17	6.10	0	Rocky Neck Park Path		/static/gpx/144_Rocky_Neck_Park_Path.gpx	0.00	Olbia-Tempio		Pascucci calabro	USA
145	2	1.20	16	23.90	1	Rocky Neck Park Trail		/static/gpx/145_Rocky_Neck_Park_Trail.gpx	0.00	Udine		Speranza laziale	USA
146	2	1.00	13	11.00	0	Rope Swing		/static/gpx/146_Rope_Swing.gpx	0.00	Caserta		Piersilvio veneto	USA
147	2	1.30	19	24.50	2	Sleeping Giant Park Trail		/static/gpx/147_Sleeping_Giant_Park_Trail.gpx	0.00	Lucca		Borgo Vito	USA
148	2	1.50	23	11.30	0	Sherwood Island Park Path		/static/gpx/148_Sherwood_Island_Park_Path.gpx	0.00	Verbano-Cusio-Ossola		La Rocca sardo	USA
149	2	1.40	17	21.40	1	Sherwood Island Nature Trail		/static/gpx/149_Sherwood_Island_Nature_Trail.gpx	0.00	Pisa		Arcadio ligure	USA
150	2	1.40	19	20.20	2	Tower Trail		/static/gpx/150_Tower_Trail.gpx	0.00	Firenze		Rita nell'emilia	USA
151	2	1.00	14	6.20	2	Southford Falls Park Trail		/static/gpx/151_Southford_Falls_Park_Trail.gpx	0.00	Salerno		Borgo Giasone	USA
152	2	0.70	10	25.60	2	Tunxis Forest Trail		/static/gpx/152_Tunxis_Forest_Trail.gpx	0.00	Asti		Celli calabro	USA
153	2	1.20	16	29.70	0	Sleeping Giant Trail		/static/gpx/153_Sleeping_Giant_Trail.gpx	0.00	Trieste		Bonagiunta lido	USA
154	2	1.30	19	12.40	1	Squantz Pond Park Trail		/static/gpx/154_Squantz_Pond_Park_Trail.gpx	0.00	Pesaro e Urbino		Settimo Cataldo	USA
155	2	1.50	19	20.50	2	Simsbury Park Trail		/static/gpx/155_Simsbury_Park_Trail.gpx	0.00	Ravenna		Loris lido	USA
156	2	1.10	14	28.10	0	Stratton Brook Park Trail		/static/gpx/156_Stratton_Brook_Park_Trail.gpx	0.00	Aosta		Cristiano terme	USA
157	2	1.10	18	29.50	1	Stratton Brook Park Path		/static/gpx/157_Stratton_Brook_Park_Path.gpx	0.00	Asti		Quirino ligure	USA
158	2	1.50	24	20.10	1	Madden Fyler Pond Trail		/static/gpx/158_Madden_Fyler_Pond_Trail.gpx	0.00	Roma		Quarto Giordano	USA
159	2	0.70	9	17.00	2	Sunny Brook Park Trail		/static/gpx/159_Sunny_Brook_Park_Trail.gpx	0.00	Carbonia-Iglesias		Cancelliere ligure	USA
160	2	0.60	8	25.20	1	Wolcott Trail		/static/gpx/160_Wolcott_Trail.gpx	0.00	Roma		Sesto Norma ligure	USA
161	2	1.20	20	9.60	1	Fadoir Spring Trail		/static/gpx/161_Fadoir_Spring_Trail.gpx	0.00	Rovigo		Tanzi terme	USA
162	2	1.40	24	21.60	1	Fadoir Trail		/static/gpx/162_Fadoir_Trail.gpx	0.00	Treviso		Giraudo salentino	USA
163	2	1.10	18	24.60	1	Walnut Mountain Trail		/static/gpx/163_Walnut_Mountain_Trail.gpx	0.00	Ravenna		Quarto Valente umbro	USA
164	2	1.60	20	22.50	0	Old Metacomet Trail		/static/gpx/164_Old_Metacomet_Trail.gpx	0.00	Bologna		Borgo Euseo laziale	USA
165	2	1.50	18	20.30	1	Talcott Mountain Park Trail		/static/gpx/165_Talcott_Mountain_Park_Trail.gpx	0.00	Livorno		Settimo Renata nell'emilia	USA
166	2	2.60	42	25.80	2	Falls Brook Trail		/static/gpx/166_Falls_Brook_Trail.gpx	0.00	Carbonia-Iglesias		Quarto Iginia	USA
167	2	1.00	14	9.60	2	Whittemore Glen Trail		/static/gpx/167_Whittemore_Glen_Trail.gpx	0.00	Parma		Abbondanzio umbro	USA
168	2	0.60	8	26.10	2	Wharton Brook Park Trail		/static/gpx/168_Wharton_Brook_Park_Trail.gpx	0.00	Pavia		Garavaglia laziale	USA
169	2	9.20	112	11.80	1	Larkin Bridle Trail		/static/gpx/169_Larkin_Bridle_Trail.gpx	0.00	Crotone		Aris a mare	USA
170	2	0.70	10	6.30	1	Bluff Point Bike Path		/static/gpx/170_Bluff_Point_Bike_Path.gpx	0.00	Terni		San Menelao laziale	USA
171	2	1.30	17	13.30	2	Bluff Point Trail		/static/gpx/171_Bluff_Point_Trail.gpx	0.00	Macerata		Genesio veneto	USA
172	2	1.50	24	7.80	2	Laurel Brook Trail		/static/gpx/172_Laurel_Brook_Trail.gpx	0.00	Asti		Osvaldo veneto	USA
173	2	1.10	18	17.10	2	Red Cedar Trail		/static/gpx/173_Red_Cedar_Trail.gpx	0.00	Ascoli Piceno		Tedeschi umbro	USA
174	2	1.30	17	16.10	2	White Birch Trail		/static/gpx/174_White_Birch_Trail.gpx	0.00	Reggio Emilia		Iezzi terme	USA
175	2	0.80	10	16.30	2	Little Falls Trail		/static/gpx/175_Little_Falls_Trail.gpx	0.00	Macerata		Italo calabro	USA
176	2	1.90	24	29.50	2	Wadsworth Falls Park Trail		/static/gpx/176_Wadsworth_Falls_Park_Trail.gpx	0.00	Catanzaro		Sesto Amatore	USA
177	2	1.50	25	14.50	2	Rockfall Land Trust Trail		/static/gpx/177_Rockfall_Land_Trust_Trail.gpx	0.00	Caltanissetta		Borgo Graziella lido	USA
178	2	1.40	20	16.60	2	Deer Trail		/static/gpx/178_Deer_Trail.gpx	0.00	Treviso		Dini terme	USA
179	2	1.20	19	10.80	2	Turkey Vultures Ledges Trail		/static/gpx/179_Turkey_Vultures_Ledges_Trail.gpx	0.00	Udine		Ferreri calabro	USA
180	2	1.10	17	25.70	2	American Legion Forest Trail		/static/gpx/180_American_Legion_Forest_Trail.gpx	0.00	Novara		Giustra terme	USA
181	2	3.10	42	6.00	2	Henry R Buck Trail		/static/gpx/181_Henry_R_Buck_Trail.gpx	0.00	Nuoro		Settimo Settimo	USA
182	2	1.80	24	17.30	2	Breakneck Pond View Trail		/static/gpx/182_Breakneck_Pond_View_Trail.gpx	0.00	Biella		Motta terme	USA
183	2	0.70	10	6.20	2	Bigelow Pond Loop Trail		/static/gpx/183_Bigelow_Pond_Loop_Trail.gpx	0.00	Pordenone		Settimo Gemma	USA
184	2	4.80	59	19.70	2	Mashapaug Pond View Trail		/static/gpx/184_Mashapaug_Pond_View_Trail.gpx	0.00	Lecce		Sesto Augusto salentino	USA
185	2	1.00	12	6.50	2	Ridge Trail		/static/gpx/185_Ridge_Trail.gpx	0.00	Pavia		Tazio a mare	USA
186	2	0.90	13	21.10	2	Nipmuck Trail		/static/gpx/186_Nipmuck_Trail.gpx	0.00	Enna		San Ampelio	USA
187	2	2.00	26	18.80	2	East Ridge Trail		/static/gpx/187_East_Ridge_Trail.gpx	0.00	Parma		Rapuano umbro	USA
188	2	0.90	15	19.60	2	Mattatuck Trail		/static/gpx/188_Mattatuck_Trail.gpx	0.00	Modena		Ostuni laziale	USA
189	2	1.40	24	19.30	2	Black Rock Park Trail		/static/gpx/189_Black_Rock_Park_Trail.gpx	0.00	Bari		Tranquillo terme	USA
190	2	1.20	19	11.40	2	Poquonnock River Walk		/static/gpx/190_Poquonnock_River_Walk.gpx	0.00	Chieti		Settimo Daciano	USA
191	2	1.20	16	30.00	2	Kempf & Shenipsit Trail		/static/gpx/191_Kempf___Shenipsit_Trail.gpx	0.00	Piacenza		Dolce laziale	USA
192	2	0.60	7	10.30	0	Mohegan Trail		/static/gpx/192_Mohegan_Trail.gpx	0.00	Catanzaro		Quarto Marciano	USA
193	2	1.40	21	28.40	1	Kempf Trail		/static/gpx/193_Kempf_Trail.gpx	0.00	Mantova		Borgo Auberto	USA
194	2	0.80	12	11.20	0	Burr Pond Park Trail		/static/gpx/194_Burr_Pond_Park_Trail.gpx	0.00	Monza e della Brianza		Borgo Guido del friuli	USA
195	2	0.60	9	24.60	2	Burr Pond Park Path		/static/gpx/195_Burr_Pond_Park_Path.gpx	0.00	Savona		Campana nell'emilia	USA
196	2	0.70	10	21.50	0	Campbell Falls Trail		/static/gpx/196_Campbell_Falls_Trail.gpx	0.00	Verbano-Cusio-Ossola		Tesifonte laziale	USA
197	2	1.20	17	16.20	2	Deep Woods Trail		/static/gpx/197_Deep_Woods_Trail.gpx	0.00	Torino		Quarto Basileo nell'emilia	USA
198	2	0.90	12	23.20	2	Chimney Trail		/static/gpx/198_Chimney_Trail.gpx	0.00	Caserta		Tosco del friuli	USA
199	2	1.40	22	18.90	2	East Woods Trail		/static/gpx/199_East_Woods_Trail.gpx	0.00	Grosseto		Borgo Eutalia salentino	USA
200	2	0.50	7	5.40	2	East Woods Connector Trail		/static/gpx/200_East_Woods_Connector_Trail.gpx	0.00	Asti		Bianchetti umbro	USA
201	2	0.70	10	15.30	2	Covered Bridge Trail		/static/gpx/201_Covered_Bridge_Trail.gpx	0.00	Cagliari		Basilio a mare	USA
202	2	1.60	20	14.50	2	Lookout Trail		/static/gpx/202_Lookout_Trail.gpx	0.00	Verbano-Cusio-Ossola		Nazzaro nell'emilia	USA
203	2	0.90	13	26.00	2	Chimney Spur Trail		/static/gpx/203_Chimney_Spur_Trail.gpx	0.00	Lodi		Ferraris salentino	USA
204	2	1.10	16	9.90	2	West Crest Trail		/static/gpx/204_West_Crest_Trail.gpx	0.00	Lecco		Quarto Egisto sardo	USA
205	2	3.20	42	18.30	2	Pond Trail		/static/gpx/205_Pond_Trail.gpx	0.00	Caserta		Viscardo lido	USA
206	2	1.30	22	28.50	2	Chatfield Hollow Park Trail		/static/gpx/206_Chatfield_Hollow_Park_Trail.gpx	0.00	Prato		Settimo Afro sardo	USA
207	2	1.20	18	28.00	0	Paul F Wildermann		/static/gpx/207_Paul_F_Wildermann.gpx	0.00	Piacenza		Isidora sardo	USA
208	2	1.50	18	22.90	2	Pattaconk Trail		/static/gpx/208_Pattaconk_Trail.gpx	0.00	Vicenza		Porzia sardo	USA
209	2	0.60	9	11.10	2	Cockaponset Trail		/static/gpx/209_Cockaponset_Trail.gpx	0.00	Grosseto		Settimo Adelfo	USA
210	2	0.60	7	21.80	1	Quinimay Trail		/static/gpx/210_Quinimay_Trail.gpx	0.00	Varese		Peaquin calabro	USA
211	2	1.40	17	25.00	2	Kay Fullerton Trail		/static/gpx/211_Kay_Fullerton_Trail.gpx	0.00	Grosseto		San Teobaldo nell'emilia	USA
212	2	1.10	15	24.30	2	Cowboy Way Trail		/static/gpx/212_Cowboy_Way_Trail.gpx	0.00	Pescara		Eleuterio nell'emilia	USA
213	2	1.40	23	28.40	2	Muck Rock Road Trail		/static/gpx/213_Muck_Rock_Road_Trail.gpx	0.00	Trieste		Settimo Rosmunda laziale	USA
214	2	1.50	23	10.70	2	Weber Road Trail		/static/gpx/214_Weber_Road_Trail.gpx	0.00	Terni		Sesto Polidoro	USA
215	2	1.10	18	24.90	2	Wood Road Trail		/static/gpx/215_Wood_Road_Trail.gpx	0.00	La Spezia		Illidio sardo	USA
216	2	1.40	18	9.40	2	Beechnut Bog Trail		/static/gpx/216_Beechnut_Bog_Trail.gpx	0.00	Siracusa		Morabito lido	USA
217	2	1.30	21	8.20	2	Bumpy Hill Road Trail		/static/gpx/217_Bumpy_Hill_Road_Trail.gpx	0.00	Chieti		Settimo Sansone	USA
218	2	1.00	13	17.60	2	Kristens Way Trail		/static/gpx/218_Kristens_Way_Trail.gpx	0.00	Fermo		Quarto Argo lido	USA
219	2	0.80	13	14.50	2	Messerschmidt Lane Trail		/static/gpx/219_Messerschmidt_Lane_Trail.gpx	0.00	Ogliastra		Borgo Quiteria salentino	USA
220	2	1.40	19	19.10	2	Tower Hill Connector Trail		/static/gpx/220_Tower_Hill_Connector_Trail.gpx	0.00	Cuneo		Quarto Casto	USA
221	2	0.60	8	10.80	2	Mattabesset Trail		/static/gpx/221_Mattabesset_Trail.gpx	0.00	Modena		Adrione umbro	USA
222	2	1.10	14	25.00	2	Mattabasset Trail		/static/gpx/222_Mattabasset_Trail.gpx	0.00	Roma		Di Somma umbro	USA
223	2	1.00	14	20.20	2	Old Mattebesset Trail		/static/gpx/223_Old_Mattebesset_Trail.gpx	0.00	Novara		Sesto Lisa umbro	USA
224	2	1.10	13	19.30	2	Huntington Park Trail		/static/gpx/224_Huntington_Park_Trail.gpx	0.00	Rimini		Delfino umbro	USA
225	2	1.00	15	10.30	2	Huntington Ridge Trail		/static/gpx/225_Huntington_Ridge_Trail.gpx	0.00	Avellino		Settimo Loreno lido	USA
226	2	0.70	9	16.50	2	Aspetuck Valley Trail		/static/gpx/226_Aspetuck_Valley_Trail.gpx	0.00	Cosenza		Croce salentino	USA
227	2	1.30	17	7.10	2	Vista Trail		/static/gpx/227_Vista_Trail.gpx	0.00	Imperia		Denti laziale	USA
228	2	1.20	17	8.60	2	Witch Hazel/Millington Trail		/static/gpx/228_Witch_Hazel_Millington_Trail.gpx	0.00	Modena		Quarto Indro ligure	USA
229	2	1.30	18	8.50	2	Millington Trail		/static/gpx/229_Millington_Trail.gpx	0.00	Forlì-Cesena		Sesto Lisa salentino	USA
230	2	0.90	11	15.20	2	Witch Hazel Trail		/static/gpx/230_Witch_Hazel_Trail.gpx	0.00	Benevento		Cara nell'emilia	USA
231	2	0.80	11	14.30	2	Woodcutters Trail		/static/gpx/231_Woodcutters_Trail.gpx	0.00	Brindisi		Settimo Abelardo salentino	USA
232	2	1.40	21	11.30	2	Devils Hopyard Park Trail		/static/gpx/232_Devils_Hopyard_Park_Trail.gpx	0.00	Barletta-Andria-Trani		Benvenuta nell'emilia	USA
233	2	1.50	21	11.00	2	Loop Trail		/static/gpx/233_Loop_Trail.gpx	0.00	Vercelli		Borgo Milo a mare	USA
234	2	1.40	24	26.70	2	Maxs Trail		/static/gpx/234_Maxs_Trail.gpx	0.00	Verbano-Cusio-Ossola		Rossini lido	USA
235	2	1.00	15	27.70	1	Machimoodus Park Trail		/static/gpx/235_Machimoodus_Park_Trail.gpx	0.00	Sassari		Quarto Mariella	USA
236	2	1.00	14	22.10	1	Fishermans Trail		/static/gpx/236_Fishermans_Trail.gpx	0.00	Salerno		San Emilio salentino	USA
237	2	3.70	50	15.50	2	Ccc Trail		/static/gpx/237_Ccc_Trail.gpx	0.00	Roma		Sesto Lelia	USA
238	2	0.70	11	12.50	2	Natchaug Trail		/static/gpx/238_Natchaug_Trail.gpx	0.00	Piacenza		San Morena veneto	USA
239	2	0.60	9	20.20	2	Natchaug Forest Trail		/static/gpx/239_Natchaug_Forest_Trail.gpx	0.00	Massa-Carrara		Toti terme	USA
240	2	1.20	19	5.50	2	Goodwin Forest Trail		/static/gpx/240_Goodwin_Forest_Trail.gpx	0.00	Latina		Colmanno a mare	USA
241	2	0.50	7	11.90	2	Pine Acres Pond Trail		/static/gpx/241_Pine_Acres_Pond_Trail.gpx	0.00	Pistoia		San Mercede salentino	USA
242	2	0.70	11	13.80	2	Brown Hill Pond Trail		/static/gpx/242_Brown_Hill_Pond_Trail.gpx	0.00	Foggia		Quarto Gennaro salentino	USA
243	2	1.50	20	9.80	2	Red Yellow Connector Trail		/static/gpx/243_Red_Yellow_Connector_Trail.gpx	0.00	Bologna		Erico sardo	USA
244	2	1.10	14	9.20	2	Yellow White Loop Trail		/static/gpx/244_Yellow_White_Loop_Trail.gpx	0.00	Brindisi		Privato laziale	USA
245	2	1.20	15	21.10	2	Governor'S Island Trail		/static/gpx/245_Governor_S_Island_Trail.gpx	0.00	Trento		San Ciro	USA
246	2	1.20	19	17.00	0	Goodwin Heritage Trail		/static/gpx/246_Goodwin_Heritage_Trail.gpx	0.00	Benevento		Settimo Sirio	USA
247	2	0.80	11	12.70	1	Forest Discovery Trail		/static/gpx/247_Forest_Discovery_Trail.gpx	0.00	Lecce		Borgo Innocente	USA
248	2	1.20	16	8.40	2	Crest		/static/gpx/248_Crest.gpx	0.00	Lecce		San Casilda del friuli	USA
249	2	1.40	22	12.70	0	Miller Brook Connector Trail		/static/gpx/249_Miller_Brook_Connector_Trail.gpx	0.00	Lucca		Vittori veneto	USA
250	2	1.70	21	14.90	0	Mansfield Hollow Park Trail		/static/gpx/250_Mansfield_Hollow_Park_Trail.gpx	0.00	Ravenna		Sesto Osvaldo nell'emilia	USA
251	2	0.90	12	19.80	0	Nipmuck Trail - East Branch		/static/gpx/251_Nipmuck_Trail___East_Branch.gpx	0.00	Vicenza		Paolo laziale	USA
252	2	0.90	11	22.80	0	Nipmuck Alternate		/static/gpx/252_Nipmuck_Alternate.gpx	0.00	Perugia		Borgo Diamante	USA
253	2	0.80	10	25.30	0	Mashamoquet Brook Nature Trail		/static/gpx/253_Mashamoquet_Brook_Nature_Trail.gpx	0.00	Trieste		Ruberto ligure	USA
254	2	1.80	23	24.40	2	Nipmuck Forest Trail		/static/gpx/254_Nipmuck_Forest_Trail.gpx	0.00	Taranto		Quarto Evaristo	USA
255	2	0.60	8	5.40	2	Morey Pond Trail		/static/gpx/255_Morey_Pond_Trail.gpx	0.00	Caltanissetta		Leopardi veneto	USA
256	2	1.10	16	26.20	2	Pharisee Rock Trail		/static/gpx/256_Pharisee_Rock_Trail.gpx	0.00	Cosenza		Borgo Virginio a mare	USA
257	2	0.80	10	5.40	2	Pachaug Forest Trail		/static/gpx/257_Pachaug_Forest_Trail.gpx	0.00	Reggio Emilia		Quarto Dora laziale	USA
258	2	1.10	19	7.20	2	Pachaug Trail		/static/gpx/258_Pachaug_Trail.gpx	0.00	Taranto		Milena a mare	USA
259	2	0.60	8	25.40	2	Canonicus Trail		/static/gpx/259_Canonicus_Trail.gpx	0.00	Modena		Greco salentino	USA
260	2	1.10	17	22.90	2	Laurel Loop Trail		/static/gpx/260_Laurel_Loop_Trail.gpx	0.00	Alessandria		Sesto Gioia veneto	USA
261	2	1.50	19	23.00	2	Pachaug/Nehantic Connector		/static/gpx/261_Pachaug_Nehantic_Connector.gpx	0.00	Taranto		Schirru terme	USA
262	2	0.50	7	16.40	2	Pachaug/Tippecansett Connector		/static/gpx/262_Pachaug_Tippecansett_Connector.gpx	0.00	Ascoli Piceno		Romano salentino	USA
263	2	0.60	8	28.60	2	Nehantic/Pachaug Connector		/static/gpx/263_Nehantic_Pachaug_Connector.gpx	0.00	Verbano-Cusio-Ossola		Settimo Fiorenza	USA
264	2	1.00	15	16.60	2	Quinebaug/Pachaug Connector		/static/gpx/264_Quinebaug_Pachaug_Connector.gpx	0.00	Matera		Pavan umbro	USA
265	2	1.40	21	9.80	2	Quinebaug Trail		/static/gpx/265_Quinebaug_Trail.gpx	0.00	Medio Campidano		Sesto Barsimeo calabro	USA
266	2	0.70	12	26.60	2	Pachaug/Narragansett Connector		/static/gpx/266_Pachaug_Narragansett_Connector.gpx	0.00	Cosenza		Bambina del friuli	USA
267	2	1.20	20	29.70	2	Green Falls Loop Trail		/static/gpx/267_Green_Falls_Loop_Trail.gpx	0.00	Barletta-Andria-Trani		Bibiano a mare	USA
268	2	1.40	19	30.00	2	Narragansett Trail		/static/gpx/268_Narragansett_Trail.gpx	0.00	Genova		Ovidio veneto	USA
269	2	1.50	18	11.80	2	Freeman Trail		/static/gpx/269_Freeman_Trail.gpx	0.00	Nuoro		Bonazzi sardo	USA
270	2	1.20	15	12.20	2	Tippecansett Trail		/static/gpx/270_Tippecansett_Trail.gpx	0.00	Udine		San Rutilo	USA
271	2	1.10	18	11.50	2	Green Falls Water Access Trail		/static/gpx/271_Green_Falls_Water_Access_Trail.gpx	0.00	Latina		Martucci lido	USA
272	2	1.00	13	7.20	2	Nehantic/Pachaug Trail		/static/gpx/272_Nehantic_Pachaug_Trail.gpx	0.00	Pavia		Sesto Archimede	USA
273	2	1.40	19	14.20	2	Phillips Pond Spur Trail		/static/gpx/273_Phillips_Pond_Spur_Trail.gpx	0.00	Oristano		Borgo Palatino	USA
274	2	0.80	10	24.50	2	Paugussett Forest Trail		/static/gpx/274_Paugussett_Forest_Trail.gpx	0.00	Forlì-Cesena		Galluzzo sardo	USA
275	2	1.00	17	27.20	2	Zoar Trail		/static/gpx/275_Zoar_Trail.gpx	0.00	Avellino		Settimo Crescenzio	USA
276	2	1.20	17	18.10	2	Lillinonah Trail		/static/gpx/276_Lillinonah_Trail.gpx	0.00	Cuneo		Floriano del friuli	USA
277	2	1.40	18	23.30	2	Zoar Trail (Old)		/static/gpx/277_Zoar_Trail__Old_.gpx	0.00	Grosseto		Borgo Giotto laziale	USA
278	2	1.50	18	16.70	1	Upper Gussy Trail		/static/gpx/278_Upper_Gussy_Trail.gpx	0.00	Firenze		San Leonida lido	USA
279	2	1.50	24	25.60	2	Pierrepont Park Trail		/static/gpx/279_Pierrepont_Park_Trail.gpx	0.00	Firenze		Borgo Gentile	USA
280	2	1.30	18	22.10	2	Shenipsit Forest Trail		/static/gpx/280_Shenipsit_Forest_Trail.gpx	0.00	Bari		Borgo Serena nell'emilia	USA
281	2	1.10	18	20.20	2	Quary Trail		/static/gpx/281_Quary_Trail.gpx	0.00	Monza e della Brianza		Veridiana umbro	USA
282	2	1.20	16	22.40	2	Shenipsit Forest Road		/static/gpx/282_Shenipsit_Forest_Road.gpx	0.00	Taranto		De Sanctis salentino	USA
283	2	1.20	20	28.10	2	Edith M Chase Ecology Trail		/static/gpx/283_Edith_M_Chase_Ecology_Trail.gpx	0.00	Olbia-Tempio		Crisafulli del friuli	USA
284	2	1.40	22	5.80	2	Topsmead Forest Trail		/static/gpx/284_Topsmead_Forest_Trail.gpx	0.00	Rieti		Telchide sardo	USA
285	2	1.00	13	20.00	2	Bernard H Stairs Trail		/static/gpx/285_Bernard_H_Stairs_Trail.gpx	0.00	Genova		Settimo Giambattista	USA
286	2	0.60	9	9.50	2	West Rock Park Trail		/static/gpx/286_West_Rock_Park_Trail.gpx	0.00	Crotone		Settimo Prudenzio salentino	USA
287	2	1.10	15	24.50	2	West Rock Summit Trail		/static/gpx/287_West_Rock_Summit_Trail.gpx	0.00	Aosta		Varo umbro	USA
288	2	2.60	37	17.70	2	Regicides Trail		/static/gpx/288_Regicides_Trail.gpx	0.00	Massa-Carrara		Borgo Cornelia del friuli	USA
289	2	1.10	16	16.70	2	Sanford Feeder Trail		/static/gpx/289_Sanford_Feeder_Trail.gpx	0.00	Vibo Valentia		Borgo Milena	USA
290	2	1.80	24	8.00	2	North Summit Trail		/static/gpx/290_North_Summit_Trail.gpx	0.00	Imperia		Settimo Quartilla	USA
291	2	0.80	13	21.90	2	Westville Feeder Trail		/static/gpx/291_Westville_Feeder_Trail.gpx	0.00	La Spezia		Ulpiano terme	USA
292	2	0.80	12	18.10	2	West Rock Park Road		/static/gpx/292_West_Rock_Park_Road.gpx	0.00	Cuneo		Settimo Desiderio	USA
293	2	1.00	13	18.80	2	Bennetts Pond Trail		/static/gpx/293_Bennetts_Pond_Trail.gpx	0.00	Varese		Fabiano ligure	USA
294	2	1.00	17	16.20	0	Ives Trail		/static/gpx/294_Ives_Trail.gpx	0.00	Lodi		Cronida ligure	USA
295	2	1.10	16	25.70	1	Ridgefield Open Space Trail		/static/gpx/295_Ridgefield_Open_Space_Trail.gpx	0.00	Viterbo		Romeo calabro	USA
296	2	1.00	15	9.00	2	George Dudley Seymour Park Trail		/static/gpx/296_George_Dudley_Seymour_Park_Trail.gpx	0.00	Frosinone		Salvadori calabro	USA
297	2	1.00	14	7.90	1	Grta		/static/gpx/297_Grta.gpx	0.00	Vicenza		Melillo lido	USA
298	2	1.40	20	29.30	2	Mohegan Forest Trail		/static/gpx/298_Mohegan_Forest_Trail.gpx	0.00	Carbonia-Iglesias		Quarto Alba	USA
299	2	0.50	8	13.10	2	Mount Bushnell Trail		/static/gpx/299_Mount_Bushnell_Trail.gpx	0.00	Matera		Rodolfo terme	USA
300	2	1.60	24	17.40	2	Nye Holman Trail		/static/gpx/300_Nye_Holman_Trail.gpx	0.00	Chieti		Remo laziale	USA
301	2	1.10	17	16.10	2	Al'S Trail		/static/gpx/301_Al_S_Trail.gpx	0.00	Parma		San Furio	USA
302	2	1.40	24	28.90	2	Salt Rock State Park Trail		/static/gpx/302_Salt_Rock_State_Park_Trail.gpx	0.00	Cuneo		San Giliola laziale	USA
303	2	1.20	15	12.70	0	Scantic River Trail		/static/gpx/303_Scantic_River_Trail.gpx	0.00	Brindisi		Riccobono veneto	USA
304	2	1.00	15	15.70	1	Scantic River Park Trail		/static/gpx/304_Scantic_River_Park_Trail.gpx	0.00	Lodi		Settimo Mauro	USA
305	2	0.80	12	18.40	0	Scantic Park Access		/static/gpx/305_Scantic_Park_Access.gpx	0.00	Genova		Ermete nell'emilia	USA
306	2	1.10	16	25.40	0	Sunrise Park Trail		/static/gpx/306_Sunrise_Park_Trail.gpx	0.00	Vercelli		Sesto Pellegrino	USA
307	2	1.30	21	11.80	0	Kitchel Trail		/static/gpx/307_Kitchel_Trail.gpx	0.00	Genova		Settimo Domenico del friuli	USA
308	2	1.30	18	21.70	0	Kitchel		/static/gpx/308_Kitchel.gpx	0.00	Oristano		Settimo Michelangelo del friuli	USA
\.


--
-- Data for Name: huts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.huts (id, "pointId", "numberOfBeds", price, title, "userId", "ownerName", website, elevation) FROM stdin;
1	1	4	52.00	Edmund-Graf-Hütte	2	Dott. Roberta Puggioni	https://nocturnal-seal.net	\N
2	2	8	43.00	Dr.Hernaus-Stöckl	2	Omar Senatore	https://miserly-diaper.org	\N
3	3	5	68.00	Amstettner Hütte	2	Alano Salierno	https://essential-pleasure.it	\N
4	4	5	138.00	Hochleckenhaus	2	Mauro Marongiu	https://shameful-guest.com	\N
5	5	10	68.00	Kampthalerhütte	2	Miriam Sbrana	http://angelic-spat.org	\N
6	6	1	96.00	Lambacher Hütte	2	Rosamunda Bellucci	http://sugary-solvency.it	\N
7	7	5	82.00	Lustenauer Hütte	2	Dr. Appia Parente	http://decimal-mutt.it	\N
8	8	5	37.00	Gablonzer Hütte	2	Sibilla De Salvo	https://nutty-theft.org	\N
9	9	2	130.00	Katafygio «Flampouri»	2	Clelia Paladini	http://empty-mall.com	\N
10	10	10	83.00	Simonyhütte	2	Lapo Evola	http://celebrated-red.it	\N
11	11	8	72.00	Vinzenz-Tollinger-Hütte	2	Franco Grosso	https://stiff-panty.com	\N
12	12	2	146.00	Ottokar-Kernstock-Haus	2	Allegra Poli	http://mature-reorganisation.org	\N
13	13	1	94.00	Reisseckhütte	2	Birino Di Marino	http://surprised-hospitalization.it	\N
14	14	4	44.00	Vernagthütte	2	Ermilo Tuccillo	https://youthful-chest.it	\N
15	15	9	45.00	Wormser Hütte	2	Nereo Rocchi	https://corrupt-compassionate.it	\N
16	16	2	111.00	Biberacher Hütte	2	Letizia Favero	http://lonely-wedding.com	\N
17	17	2	48.00	Katafygio «1777»	2	Graziano Torresi	http://overdue-area.com	\N
18	18	8	140.00	Hochwaldhütte	2	Orfeo Zaccaria	http://loathsome-lunch.it	\N
19	19	2	121.00	Kölner Eifelhütte	2	Adalgiso Iaria	https://definite-cap.com	\N
20	20	6	107.00	Madrisahütte	2	Iside Notaro	https://starchy-mesenchyme.it	\N
21	21	10	132.00	Dresdner Hütte	2	Delfina Tomaselli	http://impolite-influx.net	\N
22	22	8	79.00	Fiderepasshütte	2	Dr. Aurelia Ciccarelli	http://speedy-stock-in-trade.net	\N
23	23	2	42.00	Göppinger Hütte	2	Giovanni Tasso	https://flustered-deposit.com	\N
24	24	9	90.00	Oberzalimhütte	2	Adriano Riggi	https://complete-poll.com	\N
25	25	5	144.00	Rastkogelhütte	2	Giove Orlando	https://second-hand-court.org	\N
26	26	8	55.00	Ansbacher Skihütte im Allgäu	2	Sig. Benigna Tallarico	https://tired-kidney.net	\N
27	27	1	108.00	Kaltenberghütte	2	Leo Peaquin	https://cool-harm.org	\N
28	28	10	58.00	Schweinfurter Hütte	2	Dionigi Giannotti	http://distorted-limo.org	\N
29	29	5	78.00	Katafygio «Vardousion»	2	Carina Fonti	http://mature-month.it	\N
30	30	1	130.00	Kocbekov dom na Korošici	2	Garimberto Vailati	http://hasty-extension.net	\N
31	31	7	48.00	Planinski dom Rašiške cete na Rašici	2	Vulmaro De Vita	http://dense-presence.net	\N
32	32	6	114.00	Prešernova koca na Stolu	2	Gastone Mori	https://eager-mozzarella.net	\N
33	33	4	86.00	Planinski dom na Mrzlici	2	Postumio Callegari	https://fatal-advance.org	\N
34	34	7	148.00	Koca na Planini nad Vrhniko	2	Elvino Caccamo	https://ignorant-meander.it	\N
35	35	8	49.00	Zavetišce gorske straže na Jelencih	2	Celso Giuliano	https://wide-eyed-cholesterol.org	\N
36	36	1	59.00	Planinski dom na Gori	2	Dr. Morena Cardini	http://fake-kale.it	\N
37	37	10	67.00	Bregarjevo zavetišce na planini Viševnik	2	Severa Lupi	https://charming-nonconformist.it	\N
38	38	10	38.00	Koca pod Bogatinom	2	Anselmo Botta	http://dental-pride.com	\N
39	39	3	101.00	Pogacnikov dom na Kriških podih	2	Privato Rodigari	https://ready-belly.com	\N
40	40	6	137.00	Dom na Smrekovcu	2	Cunegonda Destro	http://thoughtful-tone.org	\N
41	41	4	92.00	Refuge Du Chatelleret	2	Brigitta Leoncini	https://gracious-flint.com	\N
42	42	5	132.00	Refuge De Chalance	2	Berardo Pece	http://bumpy-nit.org	\N
43	43	1	90.00	Refuge Des Bans	2	Asterio Franzè	https://icky-variable.it	\N
44	44	10	44.00	Refuge De Pombie	2	Ing. Corinna Scarano	https://threadbare-alder.net	\N
45	45	3	37.00	Refuge De Larribet	2	Isidora Da Rold	https://rubbery-cloister.com	\N
46	46	2	143.00	Refuge Du Mont Pourri	2	Ponzio Lari	http://circular-civilization.it	\N
47	47	5	122.00	Refuge De La Dent D?Oche	2	Macaria Battisti	https://lame-spiritual.org	\N
48	48	8	55.00	Bergseehütte SAC	2	Enecone Sottile	https://afraid-orange.it	\N
49	49	5	127.00	Bivouac au Col de la Dent Blanche CAS	2	Liberata Macchi	https://immaculate-effacement.com	\N
50	50	6	119.00	Salbitschijenbiwak SAC	2	Desdemona Salzano	http://sunny-moai.it	\N
51	51	2	117.00	Spannorthütte SAC	2	Cordelia Mazzoleno	http://flustered-lady.net	\N
52	52	3	55.00	Cabane Arpitettaz CAS	2	Dott. Francesca Fusaro	http://creepy-apron.org	\N
53	53	1	36.00	Refugio De Lizara	2	Giosuè Palmieri	https://outlandish-value.org	\N
54	54	1	76.00	Albergue De Montfalcó	2	Donna Ciaccio	https://crowded-dimple.it	\N
55	55	7	75.00	El Molonillo/Peña Partida	2	Fausto Giovinazzo	https://tame-speculation.com	\N
56	56	10	57.00	La Campiñuela	2	Elisa Maurizi	https://hidden-privilege.com	\N
57	57	9	79.00	Titov Vrv	2	Odetta Marinucci	http://stylish-immigrant.it	\N
58	58	9	60.00	Rifugio Franchetti	2	Chiara Fabiano	http://shameful-moustache.net	\N
59	59	4	61.00	Rifugio Semenza	2	Ionne Dragoni	http://icky-specialty.net	\N
60	60	3	109.00	Rifugio Città di Mortara 	2	Marinella Loffredo	https://yawning-jicama.net	\N
61	61	9	124.00	Rifugio Andolla	2	Arnaldo Forgione	https://unwelcome-equinox.net	\N
62	62	8	62.00	Rifugio Forte dei Marmi	2	Nestore Piazza	https://petty-gallery.it	\N
63	63	2	143.00	Rifugio Berti	2	Claudio Palmisano	http://substantial-aside.org	\N
64	64	1	76.00	Rifugio Premuda	2	Alessia Meli	https://pleased-postage.net	\N
65	65	4	108.00	Rifugio Elisa	2	Vinebaldo Librizzi	https://nifty-snowmobiling.net	\N
66	66	5	108.00	Rifugio CAI Saronno	2	Fedele Castellano	http://plaintive-infinite.com	\N
67	67	8	82.00	Rifugio Picco Ivigna	2	Napoleone Huber	https://jaunty-sill.it	\N
68	68	6	145.00	Rifugio Toesca	2	Lodovica Perri	http://thirsty-daylight.org	\N
69	69	4	88.00	Rifugio Al Cedo	2	Elita Cascone	http://tall-pressroom.org	\N
70	70	10	94.00	Capanna Gnifetti	2	Maurilio Mercuri	http://plump-heir.net	\N
71	71	7	96.00	Rifugio Aosta	2	Dott. Beniamino Martini	https://plush-minimum.it	\N
72	72	7	50.00	Rifugio Cevedale	2	Zoilo Martines	https://ringed-promotion.net	\N
73	73	6	129.00	Rifugio Ponti	2	Onorata Montemurro	http://ragged-episode.org	\N
74	74	2	56.00	Rifugio XII Apostoli	2	Dr. Romano Casavecchia	http://cluttered-sheath.org	\N
75	75	5	94.00	Rifugio Elisabetta Soldini	2	Edoardo Moffa	http://giant-insert.it	\N
76	76	9	60.00	Rifugio Denza	2	Concetta Gullì	https://grounded-schooner.it	\N
77	77	8	111.00	Rifugio Fonte Tavoloni 	2	Diego Aceto	https://nippy-woodwind.org	\N
78	78	9	49.00	Rifugio Carducci	2	Fabio Ambrosini	https://windy-stroke.com	\N
79	79	8	113.00	Rifugio Bindesi	2	Sidonia Michelucci	http://excited-craftsman.org	\N
80	80	10	60.00	Mountain hut Miroslav Hirtz	2	Metrofane Guglielmi	http://bustling-ranger.com	\N
81	81	10	83.00	Koca na Blegošu	2	Nazzareno Vicini	http://mixed-tempo.net	\N
82	82	6	60.00	Wittener Hütte	2	Letizia Pascarella	http://excellent-rhyme.com	\N
83	83	3	105.00	Hochjoch-Hospiz	2	Lucio Bellomo	http://creative-crib.com	\N
84	84	9	120.00	Meilerhütte	2	Dott. Allegra Petrucci	http://flustered-individual.it	\N
85	85	4	50.00	Gaudeamushütte	2	Pantaleo Gusmeroli	http://frilly-barium.it	\N
86	86	8	106.00	Rheydter Hütte	2	Iago Paonessa	https://shy-hypothermia.com	\N
87	87	7	149.00	Sektionshütte Krippen	2	Melchiorre Minniti	http://thin-self.com	\N
88	88	3	61.00	Neunkirchner Hütte	2	Donatella Tagliaferri	https://paltry-shred.com	\N
89	89	4	46.00	Refugio De Riglos	2	Rainaldo Marelli	https://normal-fondue.org	\N
90	90	7	74.00	Salbithütte SAC	2	Semiramide Mair	https://crisp-gland.org	\N
91	91	10	140.00	Finsteraarhornhütte SAC	2	Tiberio Nobili	http://fabulous-genius.net	\N
92	92	8	52.00	Cabane des Vignettes CAS	2	Gordiano Polito	https://major-rib.it	\N
93	93	7	141.00	Glecksteinhütte SAC	2	Sigismondo Canepa	http://motionless-wage.it	\N
94	94	10	62.00	Länta-Hütte SAC	2	Durante Giorgi	http://whirlwind-cape.it	\N
95	95	9	117.00	Monte-Leone-Hütte SAC	2	Carola Catanzaro	http://tight-slip.it	\N
96	96	5	106.00	Ringelspitzhütte SAC	2	Ofelia Campisi	https://joint-teller.net	\N
97	97	10	43.00	Na poljanama Maljen	2	Elvino Cammarata	http://grounded-facet.net	\N
98	98	6	94.00	Dobra voda	2	Ildebrando Marrone	https://tan-victim.it	\N
99	99	9	119.00	Ivanova hiža	2	Sidonia Gatto	http://french-size.org	\N
100	100	7	134.00	Glavica	2	Giulia Piazza	https://bumpy-interject.net	\N
101	101	3	38.00	Trpošnjik	2	Mirocleto La Porta	http://anchored-architect.it	\N
102	102	2	69.00	Bitorajka	2	Zosimo Grande	http://dangerous-put.org	\N
103	103	6	131.00	Zlatko Prgin	2	Cleandro Esposito	https://ultimate-potato.com	\N
104	104	4	84.00	Prpa	2	Celinia Maltese	http://that-harmony.it	\N
105	105	7	119.00	Ždrilo	2	Dott. Natalina Cannella	https://dapper-world.net	\N
106	106	4	102.00	Miroslav Hirtz	2	Ottilia Perna	http://giddy-derivative.com	\N
107	107	6	130.00	Jezerce	2	Gianmaria Cannas	https://unpleasant-guinea.org	\N
108	108	5	91.00	Ivica Sudnik	2	Eleonora D'Alessandro	https://light-hub.com	\N
\.


--
-- Data for Name: parking_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_lots (id, "pointId", "maxCars", "userId", country, region, province, city) FROM stdin;
1	109	72	2	Italy	Imperia		Sesto Colombano salentino
2	110	276	2	Italy	Arezzo		Borgo Sirio
3	111	174	2	Italy	Bari		Settimo Reginaldo
4	112	286	2	Italy	Palermo		Ruggero salentino
5	113	77	2	Italy	Nuoro		Quarto Monaldo terme
6	114	256	2	Italy	Verbano-Cusio-Ossola		Castellana nell'emilia
7	115	54	2	Italy	L'Aquila		Quarto Grazia del friuli
8	116	147	2	Italy	Medio Campidano		Granata del friuli
9	117	160	2	Italy	Frosinone		Ventimiglia calabro
10	118	293	2	Italy	Bergamo		Sesto Basilio lido
11	119	146	2	Italy	Vicenza		Borgo Erberto
12	120	203	2	Italy	Catania		Settimo Ida
13	121	120	2	Italy	Venezia		Quarto Giorgio
14	122	87	2	Italy	Ferrara		Quarto Antelmo
15	123	204	2	Italy	Piacenza		Bresciani veneto
16	124	268	2	Italy	Latina		Gigliola laziale
17	125	117	2	Italy	Aosta		Quarto Terzo calabro
18	126	145	2	Italy	Barletta-Andria-Trani		San Camillo
19	127	130	2	Italy	Verbano-Cusio-Ossola		Antonia a mare
20	128	162	2	Italy	Torino		Borgo Iside laziale
21	129	190	2	Italy	Ancona		San Roberto
22	130	205	2	Italy	Lecco		Vincenzo terme
23	131	6	2	Italy	Grosseto		Consolata salentino
24	132	70	2	Italy	Trento		Pezzella calabro
25	133	129	2	Italy	Latina		Gabriele laziale
26	134	286	2	Italy	Novara		Settimo Ada lido
27	135	197	2	Italy	Ascoli Piceno		Borgo Beniamino
28	136	157	2	Italy	Imperia		Mauro terme
29	137	194	2	Italy	Matera		San Ileana del friuli
30	138	125	2	Italy	Perugia		Borgo Enecone ligure
31	139	240	2	Italy	Varese		Ottaviano a mare
32	140	292	2	Italy	Parma		Rizzi calabro
33	141	198	2	Italy	Potenza		Settimo Vespasiano
34	142	5	2	Italy	Cagliari		Quarto Pardo nell'emilia
35	143	253	2	Italy	Ferrara		San Ismaele
36	144	227	2	Italy	Treviso		Quarto Veronica terme
37	145	102	2	Italy	Siena		Sesto Temistocle calabro
38	146	131	2	Italy	Monza e della Brianza		Benedetti laziale
39	147	207	2	Italy	Pistoia		Calcedonio sardo
40	148	47	2	Italy	Pescara		Sesto Felicita del friuli
41	149	20	2	Italy	Macerata		Settimo Cecilio nell'emilia
42	150	227	2	Italy	Novara		Sesto Canziano salentino
43	151	30	2	Italy	Avellino		Sesto Giasone
44	152	68	2	Italy	Siena		Diamante nell'emilia
45	153	119	2	Italy	Alessandria		San Edoardo
46	154	54	2	Italy	Ancona		Sesto Abaco calabro
47	155	268	2	Italy	Forlì-Cesena		Prisco salentino
48	156	47	2	Italy	Siena		Borgo Beronico calabro
49	157	195	2	Italy	Crotone		Settimo Zenebio
50	158	270	2	Italy	Carbonia-Iglesias		Cingolani del friuli
51	159	240	2	Italy	Taranto		Telemaco nell'emilia
52	160	11	2	Italy	Sondrio		Sesto Liberata nell'emilia
53	161	185	2	Italy	Firenze		Settimo Amabile
54	162	8	2	Italy	Livorno		Borgo Maida
55	163	289	2	Italy	Caserta		Filippi del friuli
56	164	228	2	Italy	Benevento		Sinfronio del friuli
57	165	280	2	Italy	Torino		Borgo Aleardo
58	166	208	2	Italy	Parma		Carolina calabro
59	167	59	2	Italy	Trapani		Quarto Quintiliano umbro
60	168	296	2	Italy	Chieti		San Mancio terme
61	169	47	2	Italy	Pordenone		Borgo Giobbe
62	170	275	2	Italy	Parma		Sesto Amedeo lido
63	171	43	2	Italy	Massa-Carrara		San Aldo terme
64	172	88	2	Italy	Ogliastra		Saponaro ligure
65	173	33	2	Italy	Lodi		Settimo Beltramo sardo
66	174	291	2	Italy	Verona		Selene nell'emilia
67	175	136	2	Italy	Udine		Settimo Monaldo
68	176	238	2	Italy	Forlì-Cesena		Quarto Calcedonio
69	177	278	2	Italy	Savona		San Gioventino
70	178	15	2	Italy	Biella		Ingrassia umbro
71	179	87	2	Italy	Biella		Vespasiano umbro
72	180	294	2	Italy	Carbonia-Iglesias		Sesto Geltrude nell'emilia
73	181	140	2	Italy	Viterbo		Settimo Antonello
74	182	184	2	Italy	Agrigento		Abbondanza umbro
75	183	226	2	Italy	Crotone		Panetta ligure
76	184	27	2	Italy	Reggio Emilia		Iride sardo
77	185	238	2	Italy	Varese		Volfango del friuli
78	186	43	2	Italy	Bologna		Borgo Adolfo calabro
79	187	178	2	Italy	Venezia		Borgo Gedeone
80	188	270	2	Italy	Milano		Luigi veneto
81	189	249	2	Italy	Imperia		Baraldi terme
82	190	65	2	Italy	Bergamo		Furseo veneto
83	191	129	2	Italy	Potenza		Ducci ligure
84	192	27	2	Italy	Bari		San Eraldo
85	193	68	2	Italy	Medio Campidano		Salvucci nell'emilia
86	194	79	2	Italy	Asti		Cascio nell'emilia
87	195	270	2	Italy	Belluno		San Renzo
88	196	114	2	Italy	Bari		Puglisi nell'emilia
89	197	52	2	Italy	Medio Campidano		San Delinda del friuli
90	198	221	2	Italy	Teramo		Borgo Giancarlo umbro
91	199	129	2	Italy	Biella		San Liberato
92	200	96	2	Italy	Ancona		Sesto Teodosio
93	201	145	2	Italy	Vercelli		Carli del friuli
94	202	118	2	Italy	Salerno		Adelmo salentino
95	203	39	2	Italy	Modena		Settimo Claudio
96	204	46	2	Italy	Caltanissetta		San Ippolito sardo
97	205	216	2	Italy	Catania		Bonazzi sardo
98	206	48	2	Italy	Novara		Quarto Elifio calabro
99	207	220	2	Italy	Parma		Mattia veneto
100	208	64	2	Italy	Forlì-Cesena		Settimo Abramio
101	209	37	2	Italy	Lucca		Roma
102	210	138	2	Italy	Monza e della Brianza		Pivetta laziale
103	211	44	2	Italy	Messina		San Rita
104	212	76	2	Italy	Gorizia		Borgo Romina veneto
105	213	197	2	Italy	Pisa		Sesto Salom�
106	214	58	2	Italy	Lucca		Palmira a mare
107	215	152	2	Italy	Verona		Concordio del friuli
108	216	278	2	Italy	Vibo Valentia		San Zetico umbro
109	217	182	2	Italy	Avellino		Sesto Laura
110	218	80	2	Italy	Reggio Emilia		Sesto Veriana sardo
111	219	103	2	Italy	Palermo		Mancini calabro
112	220	80	2	Italy	Perugia		Romanini del friuli
113	221	172	2	Italy	Cagliari		Settimo Azzurra calabro
114	222	80	2	Italy	Taranto		Tolomeo terme
115	223	182	2	Italy	Pescara		Sesto Severa nell'emilia
116	224	258	2	Italy	Grosseto		Pugliesi lido
117	225	89	2	Italy	Isernia		Ermenegildo salentino
118	226	137	2	Italy	Vicenza		Roberta terme
119	227	217	2	Italy	Avellino		Borgo Carmela
120	228	236	2	Italy	Ragusa		Quarto Linda lido
121	229	178	2	Italy	Perugia		Rainelda laziale
122	230	267	2	Italy	Rovigo		Zeno umbro
123	231	273	2	Italy	Viterbo		San Penelope
124	232	100	2	Italy	Teramo		San Otello
125	233	163	2	Italy	Lecco		Giorgia a mare
126	234	41	2	Italy	Benevento		Sesto Alfonso
127	235	1	2	Italy	Napoli		San Folco umbro
128	236	174	2	Italy	Bari		Rubiano sardo
129	237	155	2	Italy	Frosinone		Castaldo laziale
130	238	1	2	Italy	Medio Campidano		Borgo Silvano del friuli
131	239	1	2	Italy	Nuoro		Siracusa umbro
132	240	199	2	Italy	Milano		Fratello salentino
133	241	194	2	Italy	Caserta		Sesto Maggiorino
134	242	278	2	Italy	Ogliastra		Morini del friuli
135	243	54	2	Italy	Brescia		Elia laziale
136	244	235	2	Italy	Genova		Capoccia nell'emilia
137	245	1	2	Italy	Cosenza		Ildegarda laziale
138	246	1	2	Italy	Bari		San Abdone del friuli
139	247	31	2	Italy	Imperia		Eros veneto
140	248	1	2	Italy	Brescia		Quarto Misaele
141	249	69	2	Italy	Verona		Otello ligure
142	250	243	2	Italy	Isernia		Paradiso del friuli
143	251	62	2	Italy	Aosta		Quarto Fernando nell'emilia
144	252	208	2	Italy	Ferrara		Catanzaro lido
145	253	221	2	Italy	Gorizia		Emanuele veneto
146	254	84	2	Italy	Vercelli		Settimo Cornelio
147	255	137	2	Italy	Barletta-Andria-Trani		Pirone terme
148	256	270	2	Italy	Lecco		Capogna ligure
149	257	140	2	Italy	Biella		Settimo Gerasimo
150	258	89	2	Italy	Brindisi		Musso lido
151	259	253	2	Italy	Modena		Alma laziale
152	260	108	2	Italy	Ferrara		Sesto Antonio
153	261	234	2	Italy	Padova		Borgo Rubiano
154	262	286	2	Italy	Savona		Minelli del friuli
155	263	177	2	Italy	Pesaro e Urbino		Quarto Alda
156	264	281	2	Italy	Teramo		Raniolo calabro
157	265	75	2	Italy	Reggio Emilia		Settimo Saverio veneto
158	266	281	2	Italy	Ravenna		Sesto Alano
159	267	277	2	Italy	Verona		Consiglio veneto
160	268	136	2	Italy	Trapani		Rina veneto
161	269	184	2	Italy	Bari		San Adelmo laziale
162	270	42	2	Italy	Frosinone		Papapietro del friuli
163	271	36	2	Italy	Trieste		Dionisia umbro
164	272	169	2	Italy	Agrigento		Cardini a mare
165	273	207	2	Italy	Carbonia-Iglesias		Sesto Mara
166	274	30	2	Italy	Taranto		Settimo Primo
167	275	153	2	Italy	Carbonia-Iglesias		Lori ligure
168	276	63	2	Italy	Messina		Quarto Urbano
169	277	46	2	Italy	Barletta-Andria-Trani		Ausiliatrice lido
170	278	34	2	Italy	Agrigento		Settimo Sostrato
171	279	109	2	Italy	Cosenza		San Adele
172	280	80	2	Italy	Olbia-Tempio		Settimo Barbara
173	281	278	2	Italy	Aosta		Carponio umbro
174	282	141	2	Italy	L'Aquila		Settimo Bartolomea laziale
175	283	49	2	Italy	Benevento		Settimo Edelberga
176	284	121	2	Italy	Viterbo		Longobardi del friuli
177	285	239	2	Italy	Mantova		Vera laziale
178	286	224	2	Italy	Livorno		Sesto Nazario
179	287	170	2	Italy	Chieti		No� lido
180	288	60	2	Italy	Pistoia		Sesto Tranquillo
181	289	40	2	Italy	Lucca		Quarto Albrico calabro
182	290	190	2	Italy	Latina		Zanon lido
183	291	6	2	Italy	Agrigento		Sesto Ardito del friuli
184	292	279	2	Italy	Ferrara		Lendinara
185	293	177	2	Italy	Frosinone		Borgo Emmerico lido
186	294	95	2	Italy	Sassari		Napoli
187	295	63	2	Italy	Piacenza		Lara calabro
188	296	61	2	Italy	Chieti		Quarto Costantino
189	297	129	2	Italy	Isernia		Martino salentino
190	298	102	2	Italy	Belluno		Settimo Caino veneto
191	299	299	2	Italy	Pavia		Settimo Polidoro lido
192	300	220	2	Italy	Parma		Quarto Uranio
193	301	178	2	Italy	Siracusa		Sesto Dario
194	302	141	2	Italy	Caserta		Liberio umbro
195	303	176	2	Italy	Treviso		Settimo Sonia
196	304	73	2	Italy	Ravenna		Traini veneto
197	305	274	2	Italy	Nuoro		Borgo Rutilo laziale
198	306	184	2	Italy	Ragusa		Teresa a mare
199	307	264	2	Italy	Carbonia-Iglesias		Borgo Mariella
200	308	141	2	Italy	Lucca		Lazzaro del friuli
201	309	115	2	Italy	Catania		Sesto Isidoro
202	310	198	2	Italy	Milano		Crisci a mare
203	311	410	2	Italy	Latina		Tarquini a mare
204	312	93	2	Italy	Modena		Erardo umbro
205	313	38	2	Italy	Cuneo		San Regina del friuli
206	314	145	2	Italy	Arezzo		Settimo Genesia
207	315	79	2	Italy	Como		Malavasi del friuli
208	316	53	2	Italy	Crotone		Famiano del friuli
209	317	114	2	Italy	Monza e della Brianza		Borgo Ines
210	318	165	2	Italy	Ragusa		Cavaliere calabro
211	319	157	2	Italy	Brindisi		Ventura sardo
212	320	225	2	Italy	Massa-Carrara		Sesto Prospero lido
213	321	9	2	Italy	Barletta-Andria-Trani		Stella ligure
214	322	97	2	Italy	Messina		Bianchi veneto
215	323	106	2	Italy	Mantova		Borgo Feliciano
216	324	164	2	Italy	Potenza		San Euclide
217	325	208	2	Italy	Torino		San Mariella umbro
218	326	200	2	Italy	Ascoli Piceno		Cataldo nell'emilia
219	327	192	2	Italy	Reggio Emilia		Matranga ligure
220	328	221	2	Italy	Ravenna		Felice del friuli
221	329	111	2	Italy	Monza e della Brianza		San Antelmo
222	330	3	2	Italy	Verona		Settimo Galeazzo calabro
223	331	204	2	Italy	Rimini		Zappia lido
224	332	235	2	Italy	Roma		Settimo Giusta sardo
225	333	76	2	Italy	Brescia		Quarto Dina veneto
226	334	26	2	Italy	Savona		Quarto Irene
227	335	125	2	Italy	Palermo		Quarto Senofonte nell'emilia
228	336	286	2	Italy	Arezzo		Quarto Ugolino terme
229	337	200	2	Italy	Ancona		Settimo Sabrina nell'emilia
230	338	188	2	Italy	Asti		Santina calabro
231	339	299	2	Italy	Enna		Settimo Flavia terme
232	340	159	2	Italy	Carbonia-Iglesias		Settimo Ciro
233	341	265	2	Italy	Medio Campidano		Pastore terme
234	342	182	2	Italy	Massa-Carrara		Borgo Priamo laziale
235	343	33	2	Italy	Modena		De Bona terme
236	344	177	2	Italy	Pistoia		Mattia veneto
237	345	27	2	Italy	Potenza		San Ianira umbro
238	346	194	2	Italy	Rieti		Amone sardo
239	347	159	2	Italy	Pisa		Settimo Ermenegilda
240	348	192	2	Italy	Isernia		Quarto Piera
241	349	99	2	Italy	Lucca		Borgo Sabazio salentino
242	350	212	2	Italy	Venezia		Sabele terme
243	351	50	2	Italy	Ascoli Piceno		Settimo Olga
244	352	250	2	Italy	Catania		Socrate terme
245	353	281	2	Italy	Terni		Sandro sardo
246	354	190	2	Italy	Taranto		Gastone a mare
247	355	242	2	Italy	Pistoia		Gulino veneto
248	356	123	2	Italy	Reggio Calabria		Sesto Rosa salentino
249	357	147	2	Italy	Verona		Tito ligure
250	358	9	2	Italy	Parma		Borgo Fosca
251	359	52	2	Italy	Salerno		Fabiani a mare
252	360	55	2	Italy	Alessandria		Sesto Nostriano a mare
253	361	41	2	Italy	Bergamo		Gisella del friuli
254	362	161	2	Italy	Brindisi		Deodato veneto
255	363	156	2	Italy	Lecce		San Aresio
256	364	156	2	Italy	Taranto		San Leontina laziale
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id, type, "position", name, address) FROM stdin;
1	0	0101000020E61000002D64979723B62440C66F2527958D4740	Edmund-Graf-Hütte	6574 Pettneu am Arlberg, Tyrol, Austria
2	0	0101000020E6100000455BF9D0380E2A4056DBD4F478794740	Dr.Hernaus-Stöckl	9020 Klagenfurt, Kärnten, Austria
3	0	0101000020E61000003AD4CD22968A2D406DAF4FF575F14740	Amstettner Hütte	3340 Waidhofen an der Ybbs, Niederösterreich, Austria
4	0	0101000020E61000003470C88518362B404F23C0A11DEA4740	Hochleckenhaus	4853 Steinbach am Attersee, Oberösterreich, Austria
5	0	0101000020E6100000745CA7EA5C3230400E95C9F10B114840	Kampthalerhütte	2384 Breitenfurt bei Wien, Niederösterreich, Austria
6	0	0101000020E610000059E5350827672B402FB2862AC2D34740	Lambacher Hütte	4822 Bad Goisern, Oberösterreich, Austria
7	0	0101000020E610000019FDD2643FA62340662869A087B24740	Lustenauer Hütte	6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria
8	0	0101000020E610000036849931B0F52A4014BD78F039C44740	Gablonzer Hütte	4825 Gosau-Hintertal, Oberösterreich, Austria
9	0	0101000020E6100000202F5A3629BF3740D489BAC5B2144340	Katafygio «Flampouri»	136 72 Acharnes, Attica region, Greece
10	0	0101000020E6100000103E4BA24D3F2B40F731169C1AC04740	Simonyhütte	4830 Hallstatt, Oberösterreich, Austria
11	0	0101000020E610000033190145D5182740BF9048EBDFA04740	Vinzenz-Tollinger-Hütte	6060 Hall in Tirol, Tyrol, Austria
12	0	0101000020E61000001F1E0B5901B82E4091BFCBF1EAB34740	Ottokar-Kernstock-Haus	8600 Bruck an der Mur, Steiermark, Austria
13	0	0101000020E610000018E4FB977DBF2A40D6A3B4422D754740	Reisseckhütte	9814 Mühldorf, Mölltal, Kärnten, Austria
14	0	0101000020E61000007B116DC7D4A52540C0401020436D4740	Vernagthütte	Austria
15	0	0101000020E6100000286211C30EF323407EC9C6832D884740	Wormser Hütte	Austria
16	0	0101000020E6100000999CDA19A60E24406CD097DEFEA04740	Biberacher Hütte	Austria
17	0	0101000020E610000007BC276AC4133740DDF934DDA1A84440	Katafygio «1777»	620 55 Kerkini, Central Macedonia region, Greece
18	0	0101000020E6100000D5AF743E3C0B2A40E6E786A6EC704840	Hochwaldhütte	Germany
19	0	0101000020E6100000C2FBAA5CA8EC19408FC536A968544940	Kölner Eifelhütte	Germany
20	0	0101000020E6100000323CF6B358D223401763601DC7794740	Madrisahütte	Austria
21	0	0101000020E6100000313F373465472640CDC98B4CC07F4740	Dresdner Hütte	Austria
22	0	0101000020E6100000CDCCCCCCCC6C24403E07962364A84740	Fiderepasshütte	Germany
23	0	0101000020E6100000B727486C77172440A9DDAF027C9B4740	Göppinger Hütte	Austria
24	0	0101000020E6100000A379008BFC622340C7629B54348A4740	Oberzalimhütte	Austria
25	0	0101000020E610000013B70A62A0932740B3B45373B99D4740	Rastkogelhütte	Austria
26	0	0101000020E61000009D2D20B41E0E2440D54F49E70DC24740	Ansbacher Skihütte im Allgäu	Germany
27	0	0101000020E610000009E066F16249244097E13FDD408F4740	Kaltenberghütte	Austria
28	0	0101000020E61000000AD7A3703D0A2640E277D32D3B944740	Schweinfurter Hütte	Austria
29	0	0101000020E61000006DC438245A213640DA172BC5E9574340	Katafygio «Vardousion»	330 53 Delphi, Central Greece region, Greece
30	0	0101000020E6100000630F270F8F472D40336D62F5852D4740	Kocbekov dom na Korošici	3334 Luče, Mozirje, Slovenia
31	0	0101000020E6100000D1F5D08072062D40D25C9F20CE114740	Planinski dom Rašiške cete na Rašici	1211 Ljubljana, Šmartno, Slovenia
32	0	0101000020E6100000F70F966F85592C40971550C935374740	Prešernova koca na Stolu	4274 Žirovnica, Slovenia
33	0	0101000020E6100000AA5C8F5FCB372E408E6CD71919184740	Planinski dom na Mrzlici	3302 Griže, Slovenia
34	0	0101000020E6100000651A4D2EC6802C40577A6D3656FC4640	Koca na Planini nad Vrhniko	1360 Vrhnika, Slovenia
35	0	0101000020E6100000245DF94DDD322C4077DAB7E6D0144740	Zavetišce gorske straže na Jelencih	0, -, Slovenia
36	0	0101000020E6100000313F3734656F2E406F7F2E1A32264740	Planinski dom na Gori	Šentjungert, 3310 Žalec, Slovenia
37	0	0101000020E610000098F2E7FC90A22B40C7CBA2C928274740	Bregarjevo zavetišce na planini Viševnik	4265 Bohinjsko jezero, Slovenia
38	0	0101000020E610000091860959CC862B401635F33FD4244740	Koca pod Bogatinom	4265 Bohinjsko jezero, Slovenia
39	0	0101000020E6100000678B3942E5992B40007F639573334740	Pogacnikov dom na Kriških podih	5232 Soca, Slovenia
40	0	0101000020E610000008F580BBE4CC2D402A9C0F95E7344740	Dom na Smrekovcu	3325 Šoštanj, Slovenia
41	0	0101000020E610000073F6CE68AB32194060E811A3E77C4640	Refuge Du Chatelleret	38520 Saint Christophe En Oisans, Isère, France
42	0	0101000020E610000084622B685AF218408177F2E9B16B4640	Refuge De Chalance	5800 La Chapelle En Valgaudemar, Hautes-Alpes, France
43	0	0101000020E6100000963D096CCE711940AE7FD767CE6A4640	Refuge Des Bans	5290 Vallouise, Hautes-Alpes, France
44	0	0101000020E6100000DEAB5626FC52DBBFAED689CBF16A4540	Refuge De Pombie	65400 Laruns, Pyrénées-Atlantiques, France
45	0	0101000020E6100000A69C2FF65E7CD2BFA9F92AF9D86D4540	Refuge De Larribet	65400 Arrens, Marsous, Hautes-Pyrénées, France
46	0	0101000020E61000009CA6CF0EB84E1B401232906797C34640	Refuge Du Mont Pourri	73210 Peisey Nancroix, Savoie, France
47	0	0101000020E6100000C712D6C6D8E91A40BF81C98D222D4740	Refuge De La Dent D?Oche	74500 Bernex, Haute-Savoie, France
48	0	0101000020E6100000BEBDCA2243F820405620D41E27544740	Bergseehütte SAC	Uri, Switzerland
49	0	0101000020E6100000CDD5732CA96D1E40F591820D5C054740	Bivouac au Col de la Dent Blanche CAS	Wallis, Switzerland
50	0	0101000020E610000060F1FE571F0C2140D6BA5B328C564740	Salbitschijenbiwak SAC	Uri, Switzerland
51	0	0101000020E610000084EAC5BE53052140F224048A5C664740	Spannorthütte SAC	Uri, Switzerland
52	0	0101000020E6100000827FB24EBCB71E406113E452EB0C4740	Cabane Arpitettaz CAS	Wallis, Switzerland
53	0	0101000020E61000008A75AA7CCF48E4BF588BF447BD614540	Refugio De Lizara	22730, Aragón, Spain
54	0	0101000020E6100000AE56C01909F8E43F58DB5E1CA6064540	Albergue De Montfalcó	22585 Tolva, Aragón, Spain
55	0	0101000020E61000000A4CFFBF1E610AC08B780953B6904240	El Molonillo/Peña Partida	18160 Güejar Sierra, Andalucía, Spain
56	0	0101000020E610000029110100A92D0AC0F39F054F27844240	La Campiñuela	18417 Trévelez, Andalucía, Spain
57	0	0101000020E61000008E79782A3BCC3440BEAE152301FF4440	Titov Vrv	Tetovo, Municipality of Tetovo, North Macedonia
58	0	0101000020E6100000A2EC2DE57C212B40C7F143A5113D4540	Rifugio Franchetti	Pietracamela, Abruzzo, Italy
59	0	0101000020E610000052E2299ABDFA2840518B1C7D27114740	Rifugio Semenza	Tambre, Veneto, Italy
60	0	0101000020E6100000A197F67244A31F40313D06D094EE4640	Rifugio Città di Mortara 	Alagna Valsesia, Piemonte, Italy
61	0	0101000020E61000006E39F29B1D242040AB1ED555260C4740	Rifugio Andolla	Antrona Schieranico, Piemonte, Italy
62	0	0101000020E61000000AD80E46ECAB2440B70BCD751AFF4540	Rifugio Forte dei Marmi	Stazzema, Toscana, Italy
63	0	0101000020E6100000A88B14CAC2CF284038D66AB4C1504740	Rifugio Berti	Comelico Superiore, Veneto, Italy
64	0	0101000020E610000071B43E4052BB2B406FE70CD649CF4640	Rifugio Premuda	San Dorligo della Valle, Friuli Venezia Giulia, Italy
65	0	0101000020E61000006CCF2C0950C32240191BBAD91FF84640	Rifugio Elisa	Mandello del Lario, Lombardia, Italy
66	0	0101000020E6100000A5BDC11726B31F40F90FE9B7AFFB4640	Rifugio CAI Saronno	Macugnaga, Piemonte, Italy
67	0	0101000020E610000098DD9387857A2640A930B610E4584740	Rifugio Picco Ivigna	Scena, Trentino Alto Adige, Italy
68	0	0101000020E61000003AE97DE36B8F1C404AEF1B5F7B8A4640	Rifugio Toesca	Bussoleno, Piemonte, Italy
69	0	0101000020E6100000A913D044D8E02040382D78D1570C4740	Rifugio Al Cedo	Santa Maria Maggiore, Piemonte, Italy
70	0	0101000020E6100000449D5ECE11661F4009ED8B3A29F34640	Capanna Gnifetti	Gressoney La Trinitè, Valle d?Aosta, Italy
71	0	0101000020E6100000B8AE9811DE3E1E403A048E041AFC4640	Rifugio Aosta	Bionaz, Valle d?Aosta, Italy
72	0	0101000020E6100000BBB31B22135525408EA8F523EA374740	Rifugio Cevedale	Pejo, Trentino Alto Adige, Italy
73	0	0101000020E61000000D33349E08722340F0A485CB2A204740	Rifugio Ponti	Val Masino, Lombardia, Italy
74	0	0101000020E6100000C46D7E0DD2B125405364085B47134740	Rifugio XII Apostoli	Stenico, Trentino Alto Adige, Italy
75	0	0101000020E61000009F1C058882591B40DDD1FF722DE24640	Rifugio Elisabetta Soldini	Courmayeur, Valle d?Aosta, Italy
76	0	0101000020E610000061D57994804F25409903A4C1291F4740	Rifugio Denza	Vermiglio, Trentino Alto Adige, Italy
77	0	0101000020E61000000C1F115322F92A40338AE596560F4540	Rifugio Fonte Tavoloni 	Ovindoli, Abruzzo, Italy
78	0	0101000020E610000037C2A2224EBF2840F2ED5D83BE4E4740	Rifugio Carducci	Auronzo di Cadore, Veneto, Italy
79	0	0101000020E61000006FA53220D64E26400DE02D90A0044740	Rifugio Bindesi	Trento, Trentino Alto Adige, Italy
80	0	0101000020E610000001C11C3D7ECB2D40C670D0B9365A4640	Mountain hut Miroslav Hirtz	53287 Jablanac, Ličko-senjska županija, Croatia
81	0	0101000020E6100000398485EEED352C4098331D324C154740	Koca na Blegošu	4224 Gorenja vas, Slovenia
82	0	0101000020E610000040F850A225BF1F400F441669E2594940	Wittener Hütte	Germany
83	0	0101000020E610000000FDBE7FF3AA25409A99999999694740	Hochjoch-Hospiz	Austria
84	0	0101000020E6100000D7A02FBDFD412640CDCCCCCCCCB44740	Meilerhütte	Germany
85	0	0101000020E610000050C422861DA628406E85B01A4BC64740	Gaudeamushütte	Austria
86	0	0101000020E6100000179CC1DF2F961940D5EB1681B15C4940	Rheydter Hütte	Germany
87	0	0101000020E6100000FB66518EB8562C4057E883656C744940	Sektionshütte Krippen	Germany
88	0	0101000020E61000001F7A839D234C2C40B45EF68814A34740	Neunkirchner Hütte	2620 Neunkirchen, Steiermark, Austria
89	0	0101000020E61000009CE379FC2043E7BF8FC536A9682C4540	Refugio De Riglos	22808, Aragón, Spain
90	0	0101000020E6100000563D4FC4941A2140EBB308E997564740	Salbithütte SAC	Uri, Switzerland
91	0	0101000020E61000001D55C855B23A2040B8EB64DCCE424740	Finsteraarhornhütte SAC	Wallis, Switzerland
92	0	0101000020E6100000DEFD765E1AE71D4038777A52B2FE4640	Cabane des Vignettes CAS	Wallis, Switzerland
93	0	0101000020E6100000E769EE0B84312040FBE19FAF02504740	Glecksteinhütte SAC	Bern, Switzerland
94	0	0101000020E6100000752B5D3C5F152240D9971BDB51454740	Länta-Hütte SAC	Graubünden, Switzerland
95	0	0101000020E610000055ADDEFA26292040BAB9F14860214740	Monte-Leone-Hütte SAC	Wallis, Switzerland
96	0	0101000020E6100000557F0CE8F9C222408F373B25D26E4740	Ringelspitzhütte SAC	Graubünden, Switzerland
97	0	0101000020E6100000A4AA09A2EE0334408E23D6E253104640	Na poljanama Maljen	Maljen, Serbia
98	0	0101000020E6100000A9DE1AD82A313440C5E6E3DA50114640	Dobra voda	Suvobor, Serbia
99	0	0101000020E61000007250C24CDBFF2E402D095053CBC64640	Ivanova hiža	Karlovac town environment, Karlovačka, Croatia
100	0	0101000020E6100000C6DCB5847CC02F40C746205ED7EB4640	Glavica	Medvednica, City of Zagreb, Croatia
101	0	0101000020E6100000FFEC478AC8B83040D3F6AFAC34BD4540	Trpošnjik	Mosor, Splitsko-dalmatinska, Croatia
102	0	0101000020E6100000C217265305932D40C4CE143AAFA54640	Bitorajka	Bitoraj, Primorsko-goranska, Croatia
103	0	0101000020E6100000AB09A2EE0360304006D847A7AE084640	Zlatko Prgin	Dinara, Šibensko-kninska, Croatia
104	0	0101000020E6100000D3872EA86F492E405C8FC2F528444640	Prpa	Velebit, Ličko-senjska, Croatia
105	0	0101000020E6100000787FBC57AD5C2E408BFD65F7E43D4640	Ždrilo	Velebit, Ličko-senjska, Croatia
106	0	0101000020E610000086032159C0F42D40B21188D7F59B4640	Miroslav Hirtz	Velika Kapela, Primorsko-goranska, Croatia
107	0	0101000020E6100000A31EA2D11DAC3140462575029AC04640	Jezerce	Papuk, Požeško-slavonska, Croatia
108	0	0101000020E61000003EE8D9ACFA4C2F405F0CE544BBE24640	Ivica Sudnik	Samoborska gora, Zagrebačka, Croatia
109	0	0101000020E6100000AD3BCC4D8A7D2840CBDF185D39124640		79 Strada Nicea, Sesto Colombano salentino, Italy
110	0	0101000020E6100000AF5E454607602340EDF2AD0FEB6B4440		665 Rotonda Esuperio, Borgo Sirio, Italy
111	0	0101000020E610000050BA3EBD63AA2840D5DBB0B7DE294640		8 Borgo Huber, Settimo Reginaldo, Italy
112	0	0101000020E6100000E7204322C8042640F6AEE6A507F54540		108 Strada Gullì, Ruggero salentino, Italy
113	0	0101000020E61000009F11B6E919B02140ABAC12D154364640		774 Contrada Desdemona, Quarto Monaldo terme, Italy
114	0	0101000020E61000009EBFBFF7ED2224402DAAEA8ABEE84640		0 Via Ottilia, Castellana nell'emilia, Italy
115	0	0101000020E6100000FF209221C76E274017844DF8002D4640		944 Piazza Vedasto, Quarto Grazia del friuli, Italy
116	0	0101000020E6100000C2B28817FA8E2340D5809C8B1AB04640		451 Contrada Vodingo, Granata del friuli, Italy
117	0	0101000020E6100000107BFC3960762540600A6A53D0274740		11 Piazza Schirru, Ventimiglia calabro, Italy
118	0	0101000020E6100000CF5AC0BAE0462B40B9ED314745E34640		99 Via Diodata, Sesto Basilio lido, Italy
119	0	0101000020E610000048B42E7FCFC525403379B93E620B4740		910 Via Pio, Borgo Erberto, Italy
120	0	0101000020E6100000E066F16261B42A4084E85AC52CF04640		694 Borgo Di Maro, Settimo Ida, Italy
121	0	0101000020E610000021263CFC90E62840C604EBEEF0074640		7 Piazza Giosuele, Quarto Giorgio, Italy
122	0	0101000020E6100000CFB81567B161274070CFF3A78DA74640		2 Via Antonio, Quarto Antelmo, Italy
123	0	0101000020E6100000C1F979F8D76F224054F0CAE48AB04640		08 Rotonda Senesio, Bresciani veneto, Italy
124	0	0101000020E61000008248D0A975782B40741200D2EDC94640		515 Piazza Verecondo, Gigliola laziale, Italy
125	0	0101000020E6100000918B208436172940630E828E564E4540		76 Piazza Acrisio, Quarto Terzo calabro, Italy
126	0	0101000020E610000023484A1F5F572240D37CDF09072C4640		871 Contrada Orlando, San Camillo, Italy
127	0	0101000020E6100000A09339F130542140F7DBE8ADCB384740		548 Strada Cerrato, Antonia a mare, Italy
128	0	0101000020E6100000068A0E37967A2540DB1FDE29D3664540		68 Rotonda Teudosia, Borgo Iside laziale, Italy
129	0	0101000020E6100000CF59B09EA4CE2640F18288D4B4434740		90 Strada Iside, San Roberto, Italy
130	0	0101000020E6100000C153C8957A5A26407541D8840FE14640		50 Strada Falco, Vincenzo terme, Italy
131	0	0101000020E61000008577B988EF302140BAD3426E2B3D4740		9 Rotonda Barbarossa, Consolata salentino, Italy
132	0	0101000020E6100000589643E6259E2540B49487E013DD4540		6 Strada Feliziani, Pezzella calabro, Italy
133	0	0101000020E6100000249E4720B9702840B1F84D61A5124640		048 Strada Galeazzi, Gabriele laziale, Italy
134	0	0101000020E61000008B89CDC7B55926407EB4EED57D084740		78 Strada Berardo, Settimo Ada lido, Italy
135	0	0101000020E6100000D8B969334EEB27402CF8C84164804540		0 Rotonda Nicol�, Borgo Beniamino, Italy
136	0	0101000020E610000061D394AEAAD4204012A6835039FC4640		8 Incrocio Piero, Mauro terme, Italy
137	0	0101000020E6100000B53C6AA741AC27408F0134A550B84640		73 Incrocio Maida, San Ileana del friuli, Italy
138	0	0101000020E6100000F78CE9AE91D52240ED48F59D5FE54640		163 Strada Ambrosini, Borgo Enecone ligure, Italy
139	0	0101000020E6100000626DE75663902B4097FA1E9A1ED44640		754 Incrocio Messina, Ottaviano a mare, Italy
140	0	0101000020E6100000FFF9C78C011B2640DD706946501E4740		81 Via Tristano, Rizzi calabro, Italy
141	0	0101000020E61000009C363EEEB67E2740BC2363B5F9BA4640		15 Via Santilli, Settimo Vespasiano, Italy
142	0	0101000020E61000008A9466F3387C1E402B31CF4A5AE74640		2 Contrada Fidenzio, Quarto Pardo nell'emilia, Italy
143	0	0101000020E6100000F22895F084D22A404082870E26ED4440		2 Contrada Ariele, San Ismaele, Italy
144	0	0101000020E61000007E1D386744712240C878399105CC4640		13 Via Angeletti, Quarto Veronica terme, Italy
145	0	0101000020E610000020D84C1993812240A475AFEEB30D4740		04 Borgo Albina, Sesto Temistocle calabro, Italy
146	0	0101000020E6100000242136FD7E2E26406E2AF7A7F91A4740		50 Incrocio Clelia, Benedetti laziale, Italy
147	0	0101000020E6100000485E8C37E8B927408860C1A2C7CA4640		595 Piazza Daria, Calcedonio sardo, Italy
148	0	0101000020E61000005E961BB1BB751E407379BD4571EF4640		933 Rotonda Altieri, Sesto Felicita del friuli, Italy
149	0	0101000020E6100000BE2ABC708CED2340366964A1E7DD4640		72 Piazza Traini, Settimo Cecilio nell'emilia, Italy
150	0	0101000020E610000053B4722F302B2540E4DC26DC2B4D4740		6 Incrocio Molinaro, Sesto Canziano salentino, Italy
151	0	0101000020E61000009A97C3EE3B32254052B241CB5F574640		84 Strada Pugliesi, Sesto Giasone, Italy
152	0	0101000020E6100000622D3E05C0782840F70BD17C29DE4640		1 Borgo Pucci, Diamante nell'emilia, Italy
153	0	0101000020E6100000B05758703F782440773A4668BAB84640		470 Borgo Sacco, San Edoardo, Italy
154	0	0101000020E610000011D20957F63B2640E6B8AEF3CA084740		5 Borgo Eufrasia, Sesto Abaco calabro, Italy
155	0	0101000020E61000004704E3E0D2692C408514F2F741A74640		525 Rotonda Salvi, Prisco salentino, Italy
156	0	0101000020E61000002F0ACC54D2C8264038FE9F1E36CA4640		320 Strada Marangoni, Borgo Beronico calabro, Italy
157	0	0101000020E610000046E80C31035E29405A46EA3D95E54640		855 Rotonda Apollonia, Settimo Zenebio, Italy
158	0	0101000020E6100000E4F90CA8376B2340ABA3F496BC5E4440		87 Incrocio Rea, Cingolani del friuli, Italy
159	0	0101000020E6100000967DB2BD71ED26406F7319EDA7C14640		035 Piazza Mazza, Telemaco nell'emilia, Italy
160	0	0101000020E6100000FC68DDABFB5427401073EE1B04334740		2 Strada Gori, Sesto Liberata nell'emilia, Italy
161	0	0101000020E610000069965F611C5B2540B52792F991CA4540		49 Via Gillo, Settimo Amabile, Italy
162	0	0101000020E6100000B4C6455ACF692740D8C523A765B04640		18 Strada Valentina, Borgo Maida, Italy
163	0	0101000020E61000003B843B61D3CC1E40935742D202D44640		82 Incrocio Adelina, Filippi del friuli, Italy
164	0	0101000020E6100000C03FA54A9455284094347F4C6BE54640		1 Rotonda Petralia, Sinfronio del friuli, Italy
165	0	0101000020E610000003FBF900EEEB1E40FA6184F068EE4640		3 Via Quiteria, Borgo Aleardo, Italy
166	0	0101000020E610000007681140209E2640B177352F3D9D4640		440 Via Salomone, Carolina calabro, Italy
167	0	0101000020E6100000525F96766AFE23402A7C6C81F3EE4640		368 Piazza Fiorini, Quarto Quintiliano umbro, Italy
168	0	0101000020E61000007319EDA7B5EF1E400B1060EC18EC4640		3 Rotonda Mascolo, San Mancio terme, Italy
169	0	0101000020E6100000F86B578DCA1A284015E06014A9B14640		1 Rotonda Zaira, Borgo Giobbe, Italy
170	0	0101000020E6100000D634947FD2A12740811A081390584540		6 Via Emma, Sesto Amedeo lido, Italy
171	0	0101000020E61000009D63E53C08EA2640B7FB0BF3D4DC4540		07 Contrada Mignogna, San Aldo terme, Italy
172	0	0101000020E6100000EA0E18DAEF9B2B40948444DAC6764640		596 Incrocio Euseo, Saponaro ligure, Italy
173	0	0101000020E610000014BCD7FFEFC62640BA66F2CD36DE4640		75 Piazza Vincenza, Settimo Beltramo sardo, Italy
174	0	0101000020E610000009168733BFBE27405D4E098849354540		71 Piazza Ottavio, Selene nell'emilia, Italy
175	0	0101000020E6100000462AE7E6763A2940ABB8CC446CE14440		1 Contrada Ione, Settimo Monaldo, Italy
176	0	0101000020E610000075EED176A7F62640A7F97486F3B24640		6 Contrada Fuoco, Quarto Calcedonio, Italy
177	0	0101000020E6100000F9A23D5E48F727405789C3E3ECE04640		13 Borgo Spizzirri, San Gioventino, Italy
178	0	0101000020E6100000731A587D64FD294065FED13769E64540		71 Via Doda, Ingrassia umbro, Italy
179	0	0101000020E6100000ABC5F18D322421407D1FB3582FFA4640		532 Strada Eleonora, Vespasiano umbro, Italy
180	0	0101000020E610000035D252793B0228403A79ECC26AEA4640		360 Via Edmondo, Sesto Geltrude nell'emilia, Italy
181	0	0101000020E6100000DD730580CFD02640F16261889CD44640		923 Borgo Grieco, Settimo Antonello, Italy
182	0	0101000020E61000006531564046E12040530E1C8645E74640		5 Rotonda Edilberto, Abbondanza umbro, Italy
183	0	0101000020E610000026B8A2DE9D5E2740311A434AFDDC4640		16 Via Evaristo, Panetta ligure, Italy
184	0	0101000020E61000000A5BFD22B27524407121EA99B95B4640		8 Borgo Di Mauro, Iride sardo, Italy
185	0	0101000020E6100000C132DBBA40CE2240D0EFFB372F274740		174 Borgo Bertelli, Volfango del friuli, Italy
186	0	0101000020E6100000CA558737C6B91F40EB79ED88F9BD4640		711 Strada Abaco, Borgo Adolfo calabro, Italy
187	0	0101000020E61000006AEE320DD4F324401D098F9147B14640		477 Strada Emidio, Borgo Gedeone, Italy
188	0	0101000020E610000044053D8A291B2140F0FACC599F5A4440		025 Incrocio Napoletano, Luigi veneto, Italy
189	0	0101000020E61000002B1D07B9E6212040F08C11E4FBF04640		1 Strada De Maio, Baraldi terme, Italy
190	0	0101000020E61000007BEDE3B21BB727403464E190B2DD4640		36 Strada Filomeno, Furseo veneto, Italy
191	0	0101000020E6100000D8E9ACBB1EE91F40A0A932E774D04640		391 Piazza Cloe, Ducci ligure, Italy
192	0	0101000020E61000009C8136DEC21B294063731FCA61894540		44 Via Godiva, San Eraldo, Italy
193	0	0101000020E6100000E3B08FA91680204076A0F3BF01E94640		1 Incrocio Immacolato, Salvucci nell'emilia, Italy
194	0	0101000020E6100000EE6EAF16E9832340C6F0225D7DCC4640		3 Piazza Alfreda, Cascio nell'emilia, Italy
195	0	0101000020E6100000D81D41E037B02140C2F1214D61C54440		518 Piazza Ventura, San Renzo, Italy
196	0	0101000020E6100000A807BB174E80284061BC8B9C2AD94640		608 Strada Montanari, Puglisi nell'emilia, Italy
197	0	0101000020E6100000FD18CE9085A322406C9CA80073DB4640		032 Strada Maffei, San Delinda del friuli, Italy
198	0	0101000020E6100000E39F635122672540E113A1C7DEDE4640		73 Contrada Moro, Borgo Giancarlo umbro, Italy
199	0	0101000020E610000098231A93B47928409916500361674640		607 Rotonda Molteni, San Liberato, Italy
200	0	0101000020E6100000ABBCD3539A032740A544B7031AEF4640		808 Piazza Manti, Sesto Teodosio, Italy
201	0	0101000020E61000001E424B0D239B2440D8D1DD1A7DA04640		782 Via Ambra, Carli del friuli, Italy
202	0	0101000020E6100000CF2CAE96E0891F405EB642FDD3234640		09 Rotonda Vanessa, Adelmo salentino, Italy
203	0	0101000020E6100000D7BDBACF96BC254007205AD020C34640		25 Borgo Girardi, Settimo Claudio, Italy
204	0	0101000020E6100000C96BCABA24832740A97E4A3A6FE54640		52 Contrada Ortenzi, San Ippolito sardo, Italy
205	0	0101000020E6100000A8DAB80F8AC32940DF67017F9D1A4540		994 Incrocio Prisca, Bonazzi sardo, Italy
206	0	0101000020E6100000C272DFC556972640A4271BC528D24640		2 Piazza Avallone, Quarto Elifio calabro, Italy
207	0	0101000020E61000005F306E5974411E40EC3F21F1E13A4740		18 Rotonda Lucia, Mattia veneto, Italy
208	0	0101000020E61000006C109CE9142628401760C4E347124740		06 Via Ragusa, Settimo Abramio, Italy
209	0	0101000020E610000044EC0214D9FD284012AC600AC5EE4440		120 Via Cristoforo Colombo, Roma, Italy
210	0	0101000020E6100000B0FECF61BEF827406DFD99E6C2F24640		0 Borgo Tommasi, Pivetta laziale, Italy
211	0	0101000020E6100000EBB76576CCAF26407B8FE9BFBD424640		343 Rotonda Eloisa, San Rita, Italy
212	0	0101000020E6100000D6479682247220407379BD4571084740		85 Incrocio Salzano, Borgo Romina veneto, Italy
213	0	0101000020E610000097900F7A36872040AB251DE560074740		0 Borgo Idea, Sesto Salom�, Italy
214	0	0101000020E61000000DABD3DC65C22740D32F116F9DE34640		758 Borgo Orenzio, Palmira a mare, Italy
215	0	0101000020E61000009FEE97AA0FCF27402834FF9E0E024740		78 Piazza Allegretti, Concordio del friuli, Italy
216	0	0101000020E6100000E417B90265622C40EFC0A50815E24440		204 Piazza Ardito, San Zetico umbro, Italy
217	0	0101000020E6100000B2463D44A37B2540F3C011EEDF764540		128 Strada Poletti, Sesto Laura, Italy
218	0	0101000020E6100000B6B0B84956A326409DC2A5BE87334740		8 Piazza Meloni, Sesto Veriana sardo, Italy
219	0	0101000020E6100000D56C2FB319AD2840823C16365EC04640		266 Via Abramio, Mancini calabro, Italy
220	0	0101000020E610000076583C5002EE1E40E0CCF9731BE14640		739 Piazza Sabina, Romanini del friuli, Italy
221	0	0101000020E6100000470EC7A98CC52840B6A73F564BE04640		708 Borgo Benvenuti, Settimo Azzurra calabro, Italy
222	0	0101000020E61000004DC00A4B97B91F4005C1E3DBBBF84540		543 Via Veneranda, Tolomeo terme, Italy
223	0	0101000020E610000059EB7A585E182740106D1162780E4640		56 Piazza Calanico, Sesto Severa nell'emilia, Italy
224	0	0101000020E610000051D9B0A6B2581F4089B7CEBF5DE14640		576 Strada Esa�, Pugliesi lido, Italy
225	0	0101000020E6100000AD7603BB504F27406049A8CFC4374640		746 Contrada Ascione, Ermenegildo salentino, Italy
226	0	0101000020E61000004692C5A28EF72640D32934B511794640		06 Borgo Marita, Roberta terme, Italy
227	0	0101000020E6100000068B790C45182740C3CB1D47BD774640		347 Strada Dario, Borgo Carmela, Italy
228	0	0101000020E61000005CC0159A35C620401880A1A245F44640		07 Piazza Castellano, Quarto Linda lido, Italy
229	0	0101000020E6100000FA2D9512DD7227409453967C47234640		7 Contrada Mazzotti, Rainelda laziale, Italy
230	0	0101000020E61000008ECD8E54DFA12B403562C1583A2D4540		79 Rotonda Malco, Zeno umbro, Italy
231	0	0101000020E610000020651FBF127F254034C06092257F4640		0 Via Lo Iacono, San Penelope, Italy
232	0	0101000020E610000064BB31F3D36E22404F401361C3C24640		862 Borgo Manicone, San Otello, Italy
233	0	0101000020E6100000D160AEA0C47E2240E41824D813C04640		64 Rotonda Olga, Giorgia a mare, Italy
234	0	0101000020E61000006FD8B628B3B91E40086465EA64D64640		82 Incrocio Pala, Sesto Alfonso, Italy
235	0	0101000020E610000016CDB9CAC93E2140BC0E8B074A744640		122 Incrocio Marilena, San Folco umbro, Italy
236	0	0101000020E6100000B4064A65E54A274026DAFA8E86E14640		659 Contrada Venusto, Rubiano sardo, Italy
237	0	0101000020E61000000736F80CF26822405273034F6B9C4640		97 Strada Bacco, Castaldo laziale, Italy
238	0	0101000020E6100000DF6124C511412140D11CFE3FF3744640		14 Piazza Maffeo, Borgo Silvano del friuli, Italy
239	0	0101000020E610000077ED77CD50412140CB243493B9744640		2 Contrada Pupolo, Siracusa umbro, Italy
240	0	0101000020E61000002E008DD2A5032D406B5CA4F55C204540		368 Incrocio Veronica, Fratello salentino, Italy
241	0	0101000020E61000004ED367075C6F1F403A57941282D64640		8 Incrocio Orsino, Sesto Maggiorino, Italy
242	0	0101000020E61000006405BF0D316E1F409F07D22060D24640		569 Strada Masiero, Morini del friuli, Italy
243	0	0101000020E61000006F4BE482334C2740A928A8F287304640		076 Strada Felicia, Elia laziale, Italy
244	0	0101000020E61000005BC52CC59F522B40DB68A5B50EFA4640		81 Borgo De Vita, Capoccia nell'emilia, Italy
245	0	0101000020E61000000D5F155E383A21402BCC310F4F724640		02 Incrocio Elmo, Ildegarda laziale, Italy
246	0	0101000020E6100000E04158326C5D2140821C9430D3704640		28 Rotonda Bibiano, San Abdone del friuli, Italy
247	0	0101000020E6100000C1F979F8D7071F404EFA319C21CD4640		517 Borgo Pirone, Eros veneto, Italy
248	0	0101000020E61000000C97B0917F3921404C9C267D6B734640		60 Contrada Carini, Quarto Misaele, Italy
249	0	0101000020E6100000EFA18ED838742840FA10AF46D1764640		146 Contrada Vulmaro, Otello ligure, Italy
250	0	0101000020E6100000B032BF3F4AC11E4019CD25B094D54640		168 Via Barbarigo, Paradiso del friuli, Italy
251	0	0101000020E610000039FBB9579CA829401D9C3EF152FC4440		16 Borgo Cora, Quarto Fernando nell'emilia, Italy
252	0	0101000020E6100000440E5BC4C1F71E4071033E3F8C7E4640		033 Rotonda Lucidi, Catanzaro lido, Italy
253	0	0101000020E6100000C69EE2DD36D82B400B8AD5D5D3E84640		07 Strada Claudia, Emanuele veneto, Italy
254	0	0101000020E6100000888961E2EA131F4040E7244A31CD4640		9 Incrocio Teudosia, Settimo Cornelio, Italy
255	0	0101000020E6100000E8F86871C6D81E40E7EBE86E8DD84640		498 Contrada Marino, Pirone terme, Italy
256	0	0101000020E610000024BF34FBF2301F405FCE6C57E8CB4640		67 Incrocio Piscopo, Capogna ligure, Italy
257	0	0101000020E61000000242902859C7254075988AE832F64540		046 Borgo Mamante, Settimo Gerasimo, Italy
258	0	0101000020E61000005CEC5113D8AF1E405650ACAE9ED84640		33 Strada Petrarca, Musso lido, Italy
259	0	0101000020E6100000A6A84423E9E41E40BF20336145E14640		289 Incrocio Evangelisti, Alma laziale, Italy
260	0	0101000020E6100000F07A7AB6582B2740B1ADFAB726234640		187 Strada Cerullo, Sesto Antonio, Italy
261	0	0101000020E61000002252D32EA6C91E404392B47636E94640		36 Contrada Bernardini, Borgo Rubiano, Italy
262	0	0101000020E61000000BC336983C2C27405262D7F676234640		988 Piazza Palladino, Minelli del friuli, Italy
263	0	0101000020E61000004F722C94F1E8264075F2D885D5064740		00 Strada Garau, Quarto Alda, Italy
264	0	0101000020E61000005C8BBBE6FA8F26407A4F8AFB343B4740		1 Rotonda Quaranta, Raniolo calabro, Italy
265	0	0101000020E61000007B9054956C0B28407BB5487FD4974640		87 Strada Alvaro, Settimo Saverio veneto, Italy
266	0	0101000020E6100000BE52F1DA00B72B40D21D1F8887274540		774 Incrocio Onorata, Sesto Alano, Italy
267	0	0101000020E6100000A732D6485C052740FDD8243FE2394640		0 Via Campo, Consiglio veneto, Italy
268	0	0101000020E6100000AD94545C0B4D2240EE885462E8B94640		606 Contrada Battaglia, Rina veneto, Italy
269	0	0101000020E6100000333097F9B3641F40983BE93356DF4640		4 Rotonda Femina, San Adelmo laziale, Italy
270	0	0101000020E61000002B8AB2124E762740C1EA234B41314640		895 Borgo Borrelli, Papapietro del friuli, Italy
271	0	0101000020E6100000905F8951219022403E5695229E864640		5 Strada Forconi, Dionisia umbro, Italy
272	0	0101000020E610000096C1621E43E92640E580B80611044740		0 Strada Calanico, Cardini a mare, Italy
273	0	0101000020E61000007090B52B99842B40E461461DC27E4640		26 Contrada Modica, Sesto Mara, Italy
274	0	0101000020E610000084B1CFAD219A26406BDECC43010E4740		106 Contrada Lippolis, Settimo Primo, Italy
275	0	0101000020E6100000CC1D47BDF13F2240A5A31CCC26824640		9 Rotonda Giovenzio, Lori ligure, Italy
276	0	0101000020E610000048E58123DCFF26407F7E294D94084740		17 Incrocio Costante, Quarto Urbano, Italy
277	0	0101000020E61000006B5A73918C1625409D7C1FB358204740		85 Via Eros, Ausiliatrice lido, Italy
278	0	0101000020E6100000204F818241C01E40068B1E53D2D34640		5 Rotonda Masala, Settimo Sostrato, Italy
279	0	0101000020E6100000C0CBB161F2931E40B859BC5818D34640		632 Contrada Serr, San Adele, Italy
280	0	0101000020E610000070DA4246F68B2C40A79C8AAFD1364740		694 Piazza Felicita, Settimo Barbara, Italy
281	0	0101000020E6100000A9D5FC9D92882C4058FBE02131384740		02 Rotonda Cara, Carponio umbro, Italy
282	0	0101000020E6100000F74A0FF91DD1274067DC8AB3D8024740		992 Incrocio Bino, Settimo Bartolomea laziale, Italy
283	0	0101000020E61000004221A7542EE52C40A39BB3F457164740		8 Piazza Di Franco, Settimo Edelberga, Italy
284	0	0101000020E6100000D3D7987C586422408E7CB9AA47A84640		7 Piazza Baldassarre, Longobardi del friuli, Italy
285	0	0101000020E610000008CDAE7B2B8A2440E646EC6EF9664540		032 Contrada Zosimo, Vera laziale, Italy
286	0	0101000020E610000081EB8A19E1CD26408A4457D8C2194640		332 Piazza Benetti, Sesto Nazario, Italy
287	0	0101000020E6100000B4CA4C69FD5122404A95CDC1D8134540		48 Contrada Sinfronio, No� lido, Italy
288	0	0101000020E6100000E4BD6A65C267264033260EEA6CBC4640		35 Incrocio Buccheri, Sesto Tranquillo, Italy
289	0	0101000020E610000071C0536DDCD325406C312E0BDCB14640		9 Borgo Petrelli, Quarto Albrico calabro, Italy
290	0	0101000020E6100000B368F0ADFEEA2540D42AFA4333B54640		670 Incrocio Di Marco, Zanon lido, Italy
291	0	0101000020E61000005B2CA0AB08EA2740DE454E15422C4740		601 Strada Rina, Sesto Ardito del friuli, Italy
292	0	0101000020E61000009703988D2933274052EC0D63778A4640		595 Via Monte Grappa, Lendinara, Italy
293	0	0101000020E61000005389FC44AF582940E7D2AEF83CCA4640		736 Via Rufino, Borgo Emmerico lido, Italy
294	0	0101000020E61000000236D6B441802C4025D5D237C46B4440		44 Via dei Greci, Napoli, Italy
295	0	0101000020E610000073220BE24DBC2740A1E4C40DAE2D4740		04 Rotonda Amoroso, Lara calabro, Italy
296	0	0101000020E610000046B1DCD26AB02540072E45A808074740		0 Strada Ragusa, Quarto Costantino, Italy
297	0	0101000020E6100000B17E7DBE77992240C0F858B043504440		40 Borgo Esmeralda, Martino salentino, Italy
298	0	0101000020E6100000EC3026FDBD2C27403B6AF1CE46024740		6 Via Durante, Settimo Caino veneto, Italy
299	0	0101000020E6100000996EC8F5A5712B40C576F700DD3C4740		57 Piazza Isabella, Settimo Polidoro lido, Italy
300	0	0101000020E6100000AA5DB818A8F922406B0DA5F622154440		63 Incrocio Rinaldo, Quarto Uranio, Italy
301	0	0101000020E610000034B10AE58E682040CFC941BFA57A4440		62 Borgo Umberto, Sesto Dario, Italy
302	0	0101000020E610000008D04AB5AABC2140800F5EBBB4374640		8 Contrada Moroni, Liberio umbro, Italy
303	0	0101000020E6100000B35DA10F967D2D408F49905BDD324740		8 Via Pollina, Settimo Sonia, Italy
304	0	0101000020E6100000852348A5D8C12840842458C114E24540		63 Incrocio Saverio, Traini veneto, Italy
305	0	0101000020E6100000BF5076E915252B40EA398EC4703B4740		538 Contrada Capitolina, Borgo Rutilo laziale, Italy
306	0	0101000020E6100000B956D6917EDA2B40DF707A72A8054540		3 Contrada Patrone, Teresa a mare, Italy
307	0	0101000020E61000007889A02067742340DE2A3EF493CE4640		2 Piazza Ecclesio, Borgo Mariella, Italy
308	0	0101000020E6100000235399BDC70C254059CFFF6101ED4540		7 Via Huber, Lazzaro del friuli, Italy
309	0	0101000020E610000027F33405D7392640E75E16C90D2C4740		86 Borgo Eufronio, Sesto Isidoro, Italy
310	0	0101000020E61000001C15EE4BECAC2A40DD11A9C4D02E4540		093 Strada Vezio, Crisci a mare, Italy
311	0	0101000020E6100000C1D4850E70E722408E6D63FDB0594540		1 Borgo Lisa, Tarquini a mare, Italy
312	0	0101000020E6100000E5BA849E28A826407E7D63BE723F4640		9 Via Salvatore, Erardo umbro, Italy
313	0	0101000020E610000055B1E72109D11F4018CFA0A17FB14640		405 Via Barretta, San Regina del friuli, Italy
314	0	0101000020E61000007DEFCA89D18E2640DB0B16985F354540		0 Strada Termine, Settimo Genesia, Italy
315	0	0101000020E6100000BB6D9516E41D244002678412C1A94640		09 Via Marchetto, Malavasi del friuli, Italy
316	0	0101000020E6100000F67AF7C77BB52740FA449E245D4F4740		0 Contrada Calabria, Famiano del friuli, Italy
317	0	0101000020E6100000DE68119BD960294098E8E225EEFB4440		1 Via Acquadro, Borgo Ines, Italy
318	0	0101000020E61000007ED3AA4CE7E52340C9CC052E8F254640		7 Strada Santinelli, Cavaliere calabro, Italy
319	0	0101000020E61000004EDF217B732E2240D3F4D901D7214540		27 Via Traverso, Ventura sardo, Italy
320	0	0101000020E61000004377A45588CA264008951348E43C4640		43 Strada Prassede, Sesto Prospero lido, Italy
321	0	0101000020E610000072593B40E6692840252D4B2A09EC4440		78 Strada Cola, Stella ligure, Italy
322	0	0101000020E610000023E7B3F281D7214072C8618B38C84640		14 Incrocio Improta, Bianchi veneto, Italy
323	0	0101000020E61000000C84AE8E2D752740A4897780272E4640		558 Piazza Magno, Borgo Feliciano, Italy
324	0	0101000020E6100000A63C5F58A33326408C811A63CCED4540		055 Piazza Palmira, San Euclide, Italy
325	0	0101000020E6100000CC0C1B65FD922840A42C8DA905C14640		7 Contrada Callegari, San Mariella umbro, Italy
326	0	0101000020E61000007332CC64933F2740FEDDF1DC31254640		61 Rotonda Oderico, Cataldo nell'emilia, Italy
327	0	0101000020E610000032D758784D462240743F4C67CC0B4740		1 Piazza Antonucci, Matranga ligure, Italy
328	0	0101000020E61000002B16BF29ACC825401AB6775787864540		9 Rotonda Tedesco, Felice del friuli, Italy
329	0	0101000020E6100000FE00B562C9B62A4032CFA51364D94440		11 Piazza Fabiano, San Antelmo, Italy
330	0	0101000020E61000002AD890C9F3362640A3C629DFD80F4640		5 Incrocio Carla, Settimo Galeazzo calabro, Italy
331	0	0101000020E610000098F0958AD7422540F3DD52735E994640		17 Strada Argimiro, Zappia lido, Italy
332	0	0101000020E6100000451B36806D772640B99BF1C7FE074740		93 Contrada Lena, Settimo Giusta sardo, Italy
333	0	0101000020E61000008948A8740B9027402B7D321015F14540		274 Borgo Bertini, Quarto Dina veneto, Italy
334	0	0101000020E6100000484B8A3496612B40F1F44A5986DF4640		153 Strada Adriano, Quarto Irene, Italy
335	0	0101000020E610000006240626DCE0264059631A97BBDC4640		7 Piazza Cattaneo, Quarto Senofonte nell'emilia, Italy
336	0	0101000020E61000001A62067470422640EF6BC94F4FBD4540		02 Rotonda Italo, Quarto Ugolino terme, Italy
337	0	0101000020E6100000F0F1536694F425402F5D77A9C7134640		16 Incrocio De Bonis, Settimo Sabrina nell'emilia, Italy
338	0	0101000020E6100000A5DAA7E3317F2240E75E16C90DEF4640		2 Piazza Bedini, Santina calabro, Italy
339	0	0101000020E6100000D12E956D967D2C40126C5CFFAE6D4440		620 Contrada Giglio, Settimo Flavia terme, Italy
340	0	0101000020E6100000DD6CBDF0941F27409F515F3BBDDA4640		1 Incrocio Marilena, Settimo Ciro, Italy
341	0	0101000020E610000096EA025E66002640FA4E82ED16F44540		981 Piazza Onofrio, Pastore terme, Italy
342	0	0101000020E61000009DDE20B5E43C25407F83F6EAE39D4540		175 Via Orazio, Borgo Priamo laziale, Italy
343	0	0101000020E6100000016E162F168E2340861BF0F9614A4440		964 Rotonda Franchini, De Bona terme, Italy
344	0	0101000020E61000009F32480BE1EA20405C8A50114CDA4640		17 Incrocio Milan, Mattia veneto, Italy
345	0	0101000020E6100000618841052C422B400938DFE3A78E4640		636 Contrada Marzia, San Ianira umbro, Italy
346	0	0101000020E6100000160F94803D132140276BD44334E04640		3 Incrocio Demurtas, Amone sardo, Italy
347	0	0101000020E610000097A13BD22A4C25401A80B2CE9DD44540		63 Strada Gino, Settimo Ermenegilda, Italy
348	0	0101000020E6100000AD904D4DDD3827405B632BC313B14540		68 Strada Oliviera, Quarto Piera, Italy
349	0	0101000020E610000071E82D1EDEEB2C405F93DA30AF824440		6 Rotonda Cattaneo, Borgo Sabazio salentino, Italy
350	0	0101000020E6100000DA48C8F6109B1F40EE2AFFB5176E4640		6 Borgo Celeste, Sabele terme, Italy
351	0	0101000020E61000004D028A4798F02740C38366D7BD264640		170 Via Cointa, Settimo Olga, Italy
352	0	0101000020E6100000BCB77DEAB38A2C404EF04DD3676E4440		76 Borgo Onorina, Socrate terme, Italy
353	0	0101000020E6100000CBC80F4BB93126404793E6EA22FD4640		9 Incrocio Dione, Sandro sardo, Italy
354	0	0101000020E6100000A68E9FD7E925284065677682A2C64640		3 Borgo Loredana, Gastone a mare, Italy
355	0	0101000020E6100000407562C55F5D294091FC773359C24640		60 Rotonda Corrado, Gulino veneto, Italy
356	0	0101000020E6100000CF328B506C4D244070D63B37C8184640		3 Strada Mosca, Sesto Rosa salentino, Italy
357	0	0101000020E61000007E6E0D11DC1122409453967C47EB4640		4 Via Druina, Tito ligure, Italy
358	0	0101000020E610000043A44BA4D989204072A8DF85ADD34640		0 Via Pellegrini, Borgo Fosca, Italy
359	0	0101000020E61000004371C79BFC022C404AF5F81807254540		151 Incrocio Aristide, Fabiani a mare, Italy
360	0	0101000020E61000009EA74B10BFA422400292FAFC41944440		7 Piazza Rondoni, Sesto Nostriano a mare, Italy
361	0	0101000020E61000000D88B59D5B012C40CF70B9B024144540		776 Strada Savoia, Gisella del friuli, Italy
362	0	0101000020E610000059935D1F8CFE26407E6DA23B2D3B4640		8 Piazza Sammartano, Deodato veneto, Italy
363	0	0101000020E6100000D50451F7010829403B736AC2510D4640		86 Contrada Metello, San Aresio, Italy
364	0	0101000020E6100000CD6152D735012740D65F6523C6394640		1 Piazza Reina, San Leontina laziale, Italy
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, password, "firstName", "lastName", role, email, "phoneNumber", verified, "verificationHash") FROM stdin;
2	$2b$10$bloKlwXLTZ42etmO5z26w.X2LA0zniZngeVh3txijsXu5ZB1wgmfm	Antonio	Battipaglia	2	antonio@localguide.it	\N	t	\N
4	$2b$10$m5y6t7V2Ino/NFZ59odvVOR0UaNhpSyri1gep1U.hh9X3REGxKwWm	Erfan	Gholami	4	erfan@hutworker.it	\N	t	\N
5	$2b$10$5gwaIuNySzHzX/8YSiHmfOGjoeqsyH6kR2FnvML0I784dswwbTWMm	Laura	Zurru	5	laura@emergency.it	\N	t	\N
1	$2b$10$NBofoYe54MoueUIEQfT9vu7Xci3TSfDMm/GE/9PNOPUTdM5Sxnh9W	German	Gorodnev	0	german@hiker.it	\N	t	\N
3	$2b$10$ZbAPLOemQVY/LN9zfB2fMeRbV6XZj3wOI2b1Xef6Dhubl3/HcDKW6	vincenzo	Sagristano	3	vincenzo@admin.it	\N	t	\N
\.


--
-- Name: hikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hikes_id_seq', 308, true);


--
-- Name: huts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.huts_id_seq', 108, true);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parking_lots_id_seq', 256, true);


--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_seq', 364, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: hike_points PK_7fc686c35c52228d8494a7c4947; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_7fc686c35c52228d8494a7c4947" PRIMARY KEY ("hikeId", "pointId");


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

