--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2)
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$eAo5.D7ruzTqe3dSDxlhb.u4opQDU331RRUKzdtoV6SvhXNFhQp0q',
    'Antonio',
    'Battipaglia',
    2,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$EjJR3tc5oj7PVtnos91Rn.oMq3hmWF.LHwClbV4P.6bsKY2ohMkEi',
    'Erfan',
    'Gholami',
    4,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$SLegIgxBauK0IMF8Ft3ze.GEN4weq/hFXkgIFmqca8QNVh50Ydqqq',
    'Laura',
    'Zurru',
    5,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$nY72JGgULjvfl0rtsbWk6.CplV14R4vyR23JfZAEThlBy5H/wzHzq',
    'German',
    'Gorodnev',
    0,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$Ak8WoFHMy.9hPwnZjHOQ1.t5Qp0mu6d8ivaQrlp2NXBdJbQC2lPZy',
    'vincenzo',
    'Sagristano',
    3,
    true
  );
  

      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        2,
        'Amprimo',
        2,
        '/static/gpx/Amprimo.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        0.6,
        24.1,
        80,
        'Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.'
        '["/static/images/3.jpg"]'::jsonb
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        2,
        'Anello Chateau Beaulard - Cotolivier - Vazon',
        1,
        '/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Beaulard',
        10.5,
        15.3,
        200,
        'Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.'
        '["/static/images/2.jpg"]'::jsonb
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        2,
        'Lago Bianco',
        2,
        '/static/gpx/Lago Bianco.gpx',
        'Francia',
        'Auvergne-Rhone-Alpes',
        'Savoia',
        'Val-Cenis',
        19.7,
        21.9,
        210,
        'Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.

La diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.

La Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.

Si può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.'
        '["/static/images/1.jpg"]'::jsonb
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        2,
        'Alte Langhe Settentrionali - Cossano Belbo',
        2,
        '/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cossano Belbo',
        3.9,
        27.7,
        200,
        'Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.
Si svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.
Si imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.
Inizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.
Percorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. 
Seguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. 
Si procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante Arcobaleno.
Percorsi ancora alcune centinaia di metri si svolta a sinistra su una strada bianca e poi subito a destra salendo.
Si incrocia il Sentiero GTL e si svolta a destra.'
        '["/static/images/4.jpg"]'::jsonb
      );
    
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        2,
        'La pieve romanica di Piesenzana e la valle delle tartufaie',
        2,
        '/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montechiaro d''Asti',
        11.5,
        21.8,
        225,
        'Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. 
Circa 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. 
In regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. 
A Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). 
Contemporaneamente i ristoranti della zona propongono piatti a base di tartufi'
        '["/static/images/5.jpg"]'::jsonb
      );
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2),
        workingTimeStart time without time zone,
        workingTimeEnd time without time zone,
        email varchar,
        phoneNumber varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        7,
        76,
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Mara Calì',
        'https://extra-large-nutmeg.net',
        null,
        292.605,
        '09:00:00',
        '13:00:00',
        'Bacco_Amadori18@yahoo.it',
        '+391659913453',
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        7,
        72,
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Filomeno Tucci',
        'https://metallic-pinstripe.com',
        null,
        286.519,
        '02:00:00',
        '21:00:00',
        'Savina.Menconi@hotmail.com',
        '+391478453495',
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        1,
        60,
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Filomeno Luzzi',
        'http://equal-download.org',
        null,
        331.714,
        '08:00:00',
        '11:00:00',
        'Rodolfo22@libero.it',
        '+396791639065',
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        9,
        91,
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Dott. Giuliana Capogna',
        'https://villainous-jalapeño.com',
        null,
        282.645,
        '01:00:00',
        '03:00:00',
        'Odilia_Zanon@hotmail.com',
        '+391929701118',
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        1,
        147,
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Giulia Bortot',
        'https://confused-gloom.net',
        null,
        268.927,
        '04:00:00',
        '12:00:00',
        'Egizia_Barbero@yahoo.it',
        '+396893484916',
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        8,
        59,
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Narciso Serafino',
        'https://dreary-medal.net',
        null,
        279.946,
        '04:00:00',
        '23:00:00',
        'Costanza_Paolicelli@yahoo.it',
        '+395019028522',
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        5,
        132,
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Bortolo Ottonello',
        'http://artistic-company.it',
        null,
        267.38,
        '08:00:00',
        '21:00:00',
        'Desdemona.Curreli@hotmail.com',
        '+398505769194',
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        9,
        149,
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Sig. Sveva Sassi',
        'https://plain-patio.net',
        null,
        312.06,
        '01:00:00',
        '21:00:00',
        'Saba23@yahoo.com',
        '+390617534758',
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        4,
        57,
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Gordiano Sarnataro',
        'https://hearty-infrastructure.com',
        null,
        287.077,
        '05:00:00',
        '11:00:00',
        'Gervasio81@yahoo.it',
        '+396447460868',
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        3,
        133,
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Maruta Peaquin',
        'https://cautious-shopper.net',
        null,
        268.218,
        '06:00:00',
        '11:00:00',
        'Eufemio_Cataldi@gmail.com',
        '+396783178581',
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        8,
        49,
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Celso Mazza',
        'https://smug-treatment.org',
        null,
        330.209,
        '02:00:00',
        '22:00:00',
        'Turibio_Valle13@email.it',
        '+390640721385',
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        1,
        146,
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Allegra Tumino',
        'https://misguided-congressperson.org',
        null,
        268.035,
        '07:00:00',
        '13:00:00',
        'Evidio80@gmail.com',
        '+390144961365',
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        2,
        50,
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Alighiero Cappelli',
        'http://feisty-venture.com',
        null,
        279.686,
        '06:00:00',
        '17:00:00',
        'Loriana0@yahoo.it',
        '+391831675825',
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        10,
        69,
        'Vernagthütte',
        'Austria',
        'Sabazio Liccardo',
        'http://soft-gun.net',
        null,
        307.162,
        '01:00:00',
        '05:00:00',
        'Attila_Carbone@email.it',
        '+393001800367',
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        1,
        84,
        'Wormser Hütte',
        'Austria',
        'Deanna Agostinelli',
        'http://tidy-anatomy.org',
        null,
        273.074,
        '01:00:00',
        '23:00:00',
        'Elaide.Belotti@yahoo.it',
        '+396829052862',
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        9,
        68,
        'Biberacher Hütte',
        'Austria',
        'Rosamunda Paone',
        'https://suburban-elephant.net',
        null,
        264.822,
        '03:00:00',
        '21:00:00',
        'Giulio.Guerra@gmail.com',
        '+393752488002',
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        10,
        37,
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Prisco Polese',
        'http://scrawny-decoration.net',
        null,
        307.604,
        '02:00:00',
        '18:00:00',
        'Damiana_Piccinini64@yahoo.it',
        '+397894757373',
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        6,
        37,
        'Hochwaldhütte',
        'Germany',
        'Leontina Grillo',
        'http://cheap-put.it',
        null,
        272.469,
        '01:00:00',
        '06:00:00',
        'Rosita_Massimi@hotmail.com',
        '+395634401220',
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        6,
        122,
        'Kölner Eifelhütte',
        'Germany',
        'Rutilo Magi',
        'https://dental-admire.com',
        null,
        291.563,
        '05:00:00',
        '14:00:00',
        'Ascanio.Cappiello47@hotmail.com',
        '+394119319872',
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        8,
        78,
        'Madrisahütte',
        'Austria',
        'Diego Vanni',
        'http://physical-ascent.org',
        null,
        264.338,
        '08:00:00',
        '11:00:00',
        'Gioele.Cavallari93@hotmail.com',
        '+392799846344',
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        9,
        40,
        'Dresdner Hütte',
        'Austria',
        'Dott. Elmo Montagner',
        'http://beloved-memory.org',
        null,
        311.837,
        '06:00:00',
        '16:00:00',
        'Adelasia_LaBarbera1@yahoo.com',
        '+392170958024',
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        4,
        74,
        'Fiderepasshütte',
        'Germany',
        'Alarico Bordoni',
        'https://puzzled-suspect.net',
        null,
        323.148,
        '03:00:00',
        '05:00:00',
        'Filiberto79@yahoo.com',
        '+390353907653',
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        9,
        117,
        'Göppinger Hütte',
        'Austria',
        'Celso Forte',
        'http://wasteful-helmet.net',
        null,
        277.537,
        '06:00:00',
        '09:00:00',
        'Erminio_Polidori@yahoo.it',
        '+393635571263',
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        10,
        144,
        'Oberzalimhütte',
        'Austria',
        'Luana Biancheri',
        'https://empty-balaclava.it',
        null,
        313.412,
        '04:00:00',
        '20:00:00',
        'Valeria.Giampaolo@hotmail.com',
        '+392061650458',
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        7,
        77,
        'Rastkogelhütte',
        'Austria',
        'Aza Benini',
        'https://disguised-cashew.org',
        null,
        311.314,
        '04:00:00',
        '14:00:00',
        'Marianna57@yahoo.com',
        '+396873014275',
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        9,
        60,
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Liliana Capponi',
        'http://pleasant-banana.it',
        null,
        288.339,
        '06:00:00',
        '11:00:00',
        'Aimone4@libero.it',
        '+392307883248',
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        5,
        125,
        'Kaltenberghütte',
        'Austria',
        'Barsaba Nicastro',
        'https://capital-destiny.com',
        null,
        266.312,
        '08:00:00',
        '17:00:00',
        'Florina61@libero.it',
        '+397488211413',
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        1,
        51,
        'Schweinfurter Hütte',
        'Austria',
        'Dr. Tizio Tolomeo',
        'https://striking-formula.net',
        null,
        311.423,
        '09:00:00',
        '19:00:00',
        'Cino.Simeoli11@libero.it',
        '+395893170458',
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        3,
        130,
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Adele Matarazzo',
        'http://chief-place.net',
        null,
        304.741,
        '04:00:00',
        '23:00:00',
        'Afro.Bono@email.it',
        '+391134884797',
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        9,
        100,
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Dott. Savina Varriale',
        'https://female-understatement.net',
        null,
        311.142,
        '03:00:00',
        '14:00:00',
        'Enrico21@gmail.com',
        '+399967440020',
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        1,
        115,
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Casimira Candela',
        'http://threadbare-mystery.net',
        null,
        334.535,
        '02:00:00',
        '22:00:00',
        'Bartolomeo37@yahoo.com',
        '+396696307812',
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        10,
        132,
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Adone Di Maio',
        'https://grand-churn.it',
        null,
        314.326,
        '09:00:00',
        '15:00:00',
        'Corinna_Felici@email.it',
        '+393510959051',
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        10,
        115,
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Lavinia Scano',
        'http://webbed-carload.org',
        null,
        270.004,
        '06:00:00',
        '23:00:00',
        'Gino86@email.it',
        '+391270264215',
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        10,
        132,
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Sig. Massimiliano Zunino',
        'https://playful-markup.net',
        null,
        298.616,
        '05:00:00',
        '09:00:00',
        'Venera_Dragoni63@yahoo.it',
        '+393635323079',
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        1,
        145,
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Dorotea Pucci',
        'https://key-firm.com',
        null,
        281.943,
        '06:00:00',
        '07:00:00',
        'Marinetta_Crisci84@hotmail.com',
        '+395513089208',
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        5,
        92,
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Lauriano Marelli',
        'https://winged-sleeping.com',
        null,
        282.697,
        '02:00:00',
        '22:00:00',
        'Cinzia_Toldo@hotmail.com',
        '+396589614577',
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        6,
        126,
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Orietta Panico',
        'https://faraway-stonework.net',
        null,
        311.097,
        '06:00:00',
        '16:00:00',
        'Sveva88@yahoo.com',
        '+392773407367',
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        6,
        41,
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Adalgisa D''Alessio',
        'https://chief-bun.com',
        null,
        312.149,
        '07:00:00',
        '08:00:00',
        'Bice19@gmail.com',
        '+391388994168',
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        7,
        102,
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Ludovica Iotti',
        'http://delicious-principle.com',
        null,
        287.674,
        '02:00:00',
        '08:00:00',
        'Temistocle_Moretto@hotmail.com',
        '+393264620459',
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        3,
        139,
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Mara Silvestrini',
        'http://substantial-toque.org',
        null,
        315.762,
        '09:00:00',
        '18:00:00',
        'Vidiano47@libero.it',
        '+392004207810',
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        7,
        128,
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Martino Bernasconi',
        'https://dizzy-entrepreneur.it',
        null,
        326.533,
        '05:00:00',
        '07:00:00',
        'Iole58@yahoo.it',
        '+397358750915',
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        3,
        118,
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Callisto Lotito',
        'https://dramatic-contour.it',
        null,
        321.078,
        '07:00:00',
        '21:00:00',
        'Surano.Carbone@libero.it',
        '+397842789082',
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        5,
        127,
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Adelasia Balducci',
        'https://tall-slang.org',
        null,
        333.065,
        '02:00:00',
        '05:00:00',
        'Eraldo14@hotmail.com',
        '+394458905921',
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        9,
        113,
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Valtena Fontana',
        'http://profuse-discipline.it',
        null,
        308.159,
        '01:00:00',
        '18:00:00',
        'Renata61@email.it',
        '+391913824052',
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        5,
        107,
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Lorella Guidetti',
        'http://youthful-misrepresentation.com',
        null,
        272.579,
        '06:00:00',
        '17:00:00',
        'Plutarco.Iovino@yahoo.com',
        '+399433445032',
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        9,
        98,
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Felicia Ugolini',
        'http://reckless-raincoat.it',
        null,
        279.185,
        '07:00:00',
        '13:00:00',
        'Mauro.Donda90@yahoo.com',
        '+391290956035',
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        10,
        142,
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Sig. Ulfa Gentile',
        'http://another-tablecloth.net',
        null,
        339.167,
        '05:00:00',
        '13:00:00',
        'Andrea_Traini@gmail.com',
        '+393394989188',
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        1,
        122,
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Cosima Luongo',
        'https://homely-boot.com',
        null,
        324.734,
        '09:00:00',
        '10:00:00',
        'Antero4@hotmail.com',
        '+394511858419',
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        3,
        117,
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Basilia Quarta',
        'https://decimal-doing.com',
        null,
        327.98,
        '02:00:00',
        '13:00:00',
        'Enimia58@yahoo.com',
        '+393888289065',
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        5,
        87,
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Venustiano Bonini',
        'http://heavy-farm.net',
        null,
        338.982,
        '08:00:00',
        '12:00:00',
        'Zosimo_Mastronardi@yahoo.com',
        '+392425548725',
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        2,
        62,
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Biagio Nobile',
        'https://required-leptocephalus.org',
        null,
        262.184,
        '04:00:00',
        '13:00:00',
        'Sinfronio_Troisi47@libero.it',
        '+397385552824',
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        3,
        65,
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Fuscolo Terzi',
        'http://homely-justification.net',
        null,
        289.628,
        '01:00:00',
        '05:00:00',
        'Dino_Furno59@yahoo.com',
        '+397407230550',
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        6,
        127,
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Isotta Farris',
        'http://liquid-guitarist.net',
        null,
        311.486,
        '05:00:00',
        '21:00:00',
        'Zoe_Tomaselli@yahoo.com',
        '+392012441549',
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        10,
        118,
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Vinicio Kofler',
        'https://magnificent-vestment.com',
        null,
        331.787,
        '01:00:00',
        '17:00:00',
        'Nuccia15@yahoo.it',
        '+396072630357',
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        9,
        128,
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Marianna Boffa',
        'https://noisy-relish.org',
        null,
        330.839,
        '06:00:00',
        '12:00:00',
        'Beniamina_Ponti@hotmail.com',
        '+395008029622',
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        10,
        40,
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Vilfredo Pagani',
        'https://hateful-vomit.org',
        null,
        282.323,
        '04:00:00',
        '22:00:00',
        'Rufina_Agostinelli46@hotmail.com',
        '+395589784921',
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        5,
        142,
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Azelia Errante',
        'https://late-angina.net',
        null,
        263.088,
        '06:00:00',
        '21:00:00',
        'Ermenegarda_Rizzi10@yahoo.com',
        '+390847377893',
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        1,
        60,
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Dott. Carmen Modica',
        'https://insidious-credential.net',
        null,
        296.588,
        '03:00:00',
        '14:00:00',
        'Fiorenzo75@hotmail.com',
        '+395199034884',
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        3,
        131,
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Guiscardo Di Donato',
        'https://greedy-roadway.net',
        null,
        273.344,
        '05:00:00',
        '22:00:00',
        'Diana4@gmail.com',
        '+391880117638',
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        1,
        36,
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Zetico Guastella',
        'https://acclaimed-poignance.com',
        null,
        336.606,
        '09:00:00',
        '11:00:00',
        'Agazio.Massari13@hotmail.com',
        '+398300795404',
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        3,
        96,
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Modesto Mancinelli',
        'https://exemplary-overload.net',
        null,
        314.433,
        '08:00:00',
        '16:00:00',
        'Remigio_Diamanti@yahoo.it',
        '+391916587973',
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        8,
        50,
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Norina Vitali',
        'http://rotating-influence.com',
        null,
        339.703,
        '05:00:00',
        '22:00:00',
        'Ortensio22@libero.it',
        '+395781801514',
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        9,
        145,
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Fabrizio Carnevale',
        'https://fresh-haste.net',
        null,
        273.926,
        '01:00:00',
        '14:00:00',
        'Romola_Olivieri68@hotmail.com',
        '+391787417708',
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        3,
        99,
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Dott. Dafne Di Benedetto',
        'http://careless-flow.org',
        null,
        266.812,
        '05:00:00',
        '08:00:00',
        'Eugenia52@yahoo.it',
        '+398216321178',
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        8,
        80,
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Colombo Passarelli',
        'https://recent-framework.org',
        null,
        334.539,
        '01:00:00',
        '18:00:00',
        'Elisabetta.Babini@gmail.com',
        '+398034951832',
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        7,
        45,
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Giandomenico Torri',
        'http://poised-yahoo.com',
        null,
        293.237,
        '01:00:00',
        '12:00:00',
        'Serviliano_Ferracuti@gmail.com',
        '+392503386416',
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        2,
        39,
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Appia Bozzi',
        'http://nonstop-attorney.it',
        null,
        308.361,
        '04:00:00',
        '12:00:00',
        'Algiso.Cascone@libero.it',
        '+393783637328',
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        1,
        82,
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Sandra Marchese',
        'http://gloomy-acquisition.com',
        null,
        327.849,
        '05:00:00',
        '07:00:00',
        'Medardo.Delfino@libero.it',
        '+394914170395',
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        3,
        37,
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Rita Cappelli',
        'http://slow-spot.net',
        null,
        304.345,
        '05:00:00',
        '12:00:00',
        'Loris_DiVita22@libero.it',
        '+399325730272',
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        9,
        93,
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Giadero Petrini',
        'http://jagged-parliament.org',
        null,
        267.87,
        '06:00:00',
        '08:00:00',
        'Amanzio_Florio@gmail.com',
        '+398096084572',
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        5,
        147,
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Sabrina Fanelli',
        'https://ordinary-noise.org',
        null,
        265.815,
        '05:00:00',
        '14:00:00',
        'Agesilao.Bertolini12@email.it',
        '+396467560667',
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        8,
        110,
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Dott. Marilena Melandri',
        'http://slight-petitioner.net',
        null,
        263.239,
        '03:00:00',
        '23:00:00',
        'Serafina13@yahoo.it',
        '+399142361244',
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        1,
        88,
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Balderico Burgio',
        'https://traumatic-okra.com',
        null,
        302.477,
        '06:00:00',
        '14:00:00',
        'Niceto.Antonucci78@libero.it',
        '+391145369374',
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        6,
        131,
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Giacobbe Pittalis',
        'https://necessary-independence.net',
        null,
        289.413,
        '05:00:00',
        '19:00:00',
        'Priscilla48@libero.it',
        '+397728393004',
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        2,
        90,
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Ercolano Crisafulli',
        'http://rewarding-mining.com',
        null,
        314.567,
        '07:00:00',
        '08:00:00',
        'Melchiade.Santinelli@yahoo.com',
        '+391018921308',
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        1,
        141,
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Basilia Saracino',
        'http://natural-grill.it',
        null,
        288.865,
        '08:00:00',
        '11:00:00',
        'Algiso_Pedrotti@hotmail.com',
        '+399339518267',
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        3,
        142,
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Demetrio Dattilo',
        'https://gummy-mint.it',
        null,
        284.265,
        '05:00:00',
        '22:00:00',
        'Emmerico.Riggio@libero.it',
        '+396430095941',
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        2,
        59,
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Ing. Gaetano Palazzi',
        'https://failing-fedelini.org',
        null,
        285.266,
        '07:00:00',
        '11:00:00',
        'Nostriano58@yahoo.it',
        '+391282547342',
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        9,
        118,
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Elaide Pittalis',
        'https://sparkling-evaluation.org',
        null,
        317.025,
        '04:00:00',
        '13:00:00',
        'Martino_Valentini@yahoo.it',
        '+397071964286',
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        2,
        38,
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Leonio Gangemi',
        'https://direct-stack.com',
        null,
        299.92,
        '09:00:00',
        '20:00:00',
        'Riccardo91@yahoo.com',
        '+398368231413',
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        9,
        133,
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Ricario Saporito',
        'http://clear-cut-kettle.it',
        null,
        288.767,
        '06:00:00',
        '18:00:00',
        'Timoteo29@libero.it',
        '+398263604235',
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        6,
        145,
        'Wittener Hütte',
        'Germany',
        'Marisa Farris',
        'https://aggressive-modification.it',
        null,
        331.732,
        '08:00:00',
        '22:00:00',
        'Dora.DeCarolis96@email.it',
        '+395401506118',
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        4,
        79,
        'Hochjoch-Hospiz',
        'Austria',
        'Adelfo Campanella',
        'http://minty-marten.it',
        null,
        339.846,
        '05:00:00',
        '17:00:00',
        'Viliberto_DePalma@hotmail.com',
        '+396446492699',
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        1,
        42,
        'Meilerhütte',
        'Germany',
        'Ing. Deodata Gasser',
        'http://idolized-doorbell.net',
        null,
        297.209,
        '02:00:00',
        '16:00:00',
        'Zaira10@email.it',
        '+399882251196',
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        1,
        45,
        'Gaudeamushütte',
        'Austria',
        'Lapo Ferretti',
        'http://heartfelt-experience.net',
        null,
        300.248,
        '06:00:00',
        '21:00:00',
        'Liberto_Miceli21@libero.it',
        '+391738268467',
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        7,
        127,
        'Rheydter Hütte',
        'Germany',
        'Gerolamo Luise',
        'http://this-ligand.net',
        null,
        335.61,
        '01:00:00',
        '05:00:00',
        'Vittorio.Saba49@email.it',
        '+395254179002',
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        1,
        89,
        'Sektionshütte Krippen',
        'Germany',
        'Aurelia De Vito',
        'http://unusual-feel.com',
        null,
        301.608,
        '01:00:00',
        '23:00:00',
        'Amleto_Pavan@yahoo.it',
        '+391897643557',
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        10,
        63,
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Gabriele Galeazzi',
        'https://worn-diaper.org',
        null,
        336.202,
        '04:00:00',
        '23:00:00',
        'Egle_Zullo@libero.it',
        '+396707366529',
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        7,
        122,
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Anselmo Viviani',
        'http://conventional-punch.org',
        null,
        321.713,
        '05:00:00',
        '08:00:00',
        'Ugolina.Cocco20@email.it',
        '+390464494505',
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        1,
        59,
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Rufino Curcio',
        'http://criminal-prosecutor.it',
        null,
        311.22,
        '03:00:00',
        '16:00:00',
        'Ulderico_Siciliano79@email.it',
        '+391076278053',
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        3,
        144,
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Godiva Stefani',
        'http://unwilling-nobody.it',
        null,
        306.352,
        '05:00:00',
        '14:00:00',
        'Linda15@gmail.com',
        '+393351433793',
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        1,
        131,
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Rufino Barbieri',
        'http://legitimate-soup.net',
        null,
        338.296,
        '04:00:00',
        '22:00:00',
        'Sara51@yahoo.it',
        '+390035509690',
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        5,
        146,
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Marzia Coslovich',
        'http://wooden-basis.it',
        null,
        305.457,
        '07:00:00',
        '13:00:00',
        'Marita94@email.it',
        '+398634259645',
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        7,
        142,
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Dianora Marotta',
        'http://corny-shampoo.org',
        null,
        277.057,
        '06:00:00',
        '15:00:00',
        'Dina40@yahoo.com',
        '+395164960904',
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        9,
        67,
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Basilia Casavecchia',
        'https://shocked-behavior.net',
        null,
        292.455,
        '02:00:00',
        '03:00:00',
        'Gaspare.Venezia@hotmail.com',
        '+397500790547',
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        3,
        105,
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Mario Tucci',
        'http://new-chocolate.net',
        null,
        299.552,
        '04:00:00',
        '19:00:00',
        'Fortunata58@email.it',
        '+394562540648',
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        2,
        122,
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Norina Massari',
        'http://shiny-laboratory.org',
        null,
        295.979,
        '04:00:00',
        '14:00:00',
        'Tecla59@hotmail.com',
        '+398329038690',
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        1,
        69,
        'Dobra voda',
        'Suvobor, Serbia',
        'Ansaldo Passarelli',
        'http://oval-neglect.net',
        null,
        328.291,
        '07:00:00',
        '16:00:00',
        'Odetta_Caruso5@gmail.com',
        '+399770808154',
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        5,
        142,
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Delia Manfredi',
        'http://downright-mention.net',
        null,
        318.788,
        '01:00:00',
        '19:00:00',
        'Spano.Gualtieri@gmail.com',
        '+397271347781',
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        7,
        90,
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Lauriano Pastore',
        'http://embellished-bell.net',
        null,
        320.074,
        '05:00:00',
        '21:00:00',
        'Italia_Venturelli67@yahoo.it',
        '+394362334385',
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        9,
        51,
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Oriana Guglielmi',
        'https://conscious-colonization.com',
        null,
        314.516,
        '05:00:00',
        '08:00:00',
        'Aza84@libero.it',
        '+392680655030',
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        5,
        113,
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Ermenegilda Celano',
        'http://jolly-racism.net',
        null,
        321.17,
        '06:00:00',
        '14:00:00',
        'Bonavita_Denaro@gmail.com',
        '+398691067663',
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        9,
        121,
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Agnese Vuillermoz',
        'https://bare-surfboard.it',
        null,
        285.391,
        '05:00:00',
        '18:00:00',
        'Ivanoe44@gmail.com',
        '+395019660970',
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        5,
        140,
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Eufebio Del Vecchio',
        'https://steel-tripod.net',
        null,
        325.402,
        '05:00:00',
        '12:00:00',
        'Iolanda13@gmail.com',
        '+393907071645',
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        1,
        103,
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Michele Orlando',
        'https://knobby-salt.it',
        null,
        289.853,
        '06:00:00',
        '16:00:00',
        'Angelo_Basso33@libero.it',
        '+398640800561',
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        10,
        74,
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Angela Nigro',
        'http://dishonest-money.com',
        null,
        286.402,
        '07:00:00',
        '19:00:00',
        'Candido67@hotmail.com',
        '+393575615722',
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        10,
        42,
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Ione Catellani',
        'https://admired-advent.org',
        null,
        304.814,
        '01:00:00',
        '12:00:00',
        'Vincenzo50@yahoo.com',
        '+391279574385',
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        2,
        42,
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Lia Palmeri',
        'https://glass-chivalry.net',
        null,
        315.71,
        '02:00:00',
        '15:00:00',
        'Norberto44@yahoo.it',
        '+396546625713',
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '0 Via Dacio, Govoni ligure, Italy',
        'Govoni ligure',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        158,
        '418 Rotonda Romanini, Liborio del friuli, Italy',
        'Liborio del friuli',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        224,
        '679 Borgo Pastorino, Cesaretti nell''emilia, Italy',
        'Cesaretti nell''emilia',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        260,
        '261 Rotonda Duccio, Sesto Monaldo, Italy',
        'Sesto Monaldo',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        273,
        '25 Rotonda Vitale, Fiordaliso terme, Italy',
        'Fiordaliso terme',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        38,
        '0 Contrada Dina, Calabrese umbro, Italy',
        'Calabrese umbro',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        189,
        '785 Strada Mancio, Antelmo umbro, Italy',
        'Antelmo umbro',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        104,
        '732 Rotonda Corrado, Settimo Bonifacio umbro, Italy',
        'Settimo Bonifacio umbro',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        47,
        '06 Strada Riparbelli, Borgo Manuele terme, Italy',
        'Borgo Manuele terme',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        121,
        '5 Borgo Chessari, Barletta laziale, Italy',
        'Barletta laziale',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        214,
        '767 Strada Bartolucci, Sesto Alamanno, Italy',
        'Sesto Alamanno',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        87,
        '15 Via D''Orazio, Ruggiero nell''emilia, Italy',
        'Ruggiero nell''emilia',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        59,
        '590 Incrocio Favero, Biagio ligure, Italy',
        'Biagio ligure',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        28,
        '05 Via Simula, Settimo Rinaldo calabro, Italy',
        'Settimo Rinaldo calabro',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        176,
        '64 Piazza Giovanna, Asella a mare, Italy',
        'Asella a mare',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        174,
        '1 Piazza Iannone, Cora ligure, Italy',
        'Cora ligure',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        255,
        '02 Borgo Carli, Alcibiade del friuli, Italy',
        'Alcibiade del friuli',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        285,
        '5 Strada Castiello, Borgo Iride, Italy',
        'Borgo Iride',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        109,
        '952 Borgo Cirino, San Ada nell''emilia, Italy',
        'San Ada nell''emilia',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        194,
        '43 Contrada Raniolo, Quarto Pia, Italy',
        'Quarto Pia',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        99,
        '55 Incrocio Tesauro, Settimo Ippolito, Italy',
        'Settimo Ippolito',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        284,
        '257 Borgo Talarico, Sesto Arduino, Italy',
        'Sesto Arduino',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '1 Rotonda Favre, Gigli salentino, Italy',
        'Gigli salentino',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        118,
        '7 Piazza Babila, Sesto Giorgia, Italy',
        'Sesto Giorgia',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        89,
        '36 Rotonda Alberti, Sesto Clemente ligure, Italy',
        'Sesto Clemente ligure',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        175,
        '80 Contrada Baroni, San Orlando calabro, Italy',
        'San Orlando calabro',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        156,
        '7 Piazza Galeazzo, Zordan ligure, Italy',
        'Zordan ligure',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        264,
        '0 Strada Cabras, Agape calabro, Italy',
        'Agape calabro',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        91,
        '271 Rotonda Garimberto, Maffeo sardo, Italy',
        'Maffeo sardo',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        32,
        '09 Strada Leda, Borgo Ambra calabro, Italy',
        'Borgo Ambra calabro',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        48,
        '58 Contrada Magnani, Settimo Fernanda, Italy',
        'Settimo Fernanda',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        123,
        '73 Contrada Marina, Borgo Tulliano, Italy',
        'Borgo Tulliano',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        213,
        '48 Incrocio Zarina, Concordio del friuli, Italy',
        'Concordio del friuli',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '0 Via Gasparini, Gautiero sardo, Italy',
        'Gautiero sardo',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        229,
        '38 Piazza Appia, De Rosa sardo, Italy',
        'De Rosa sardo',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        135,
        '186 Via Corbiniano, Finotti nell''emilia, Italy',
        'Finotti nell''emilia',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        126,
        '50 Piazza Vulpiano, San Cosimo umbro, Italy',
        'San Cosimo umbro',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        278,
        '34 Borgo Amanda, Settimo Anacleto, Italy',
        'Settimo Anacleto',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        239,
        '641 Rotonda Soro, Santarsia terme, Italy',
        'Santarsia terme',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        232,
        '9 Rotonda Caradonna, De Martino laziale, Italy',
        'De Martino laziale',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '24 Incrocio Giliola, Borgo Tiziana nell''emilia, Italy',
        'Borgo Tiziana nell''emilia',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        151,
        '5 Incrocio Benini, Quarto Climaco lido, Italy',
        'Quarto Climaco lido',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        230,
        '3 Contrada Ponti, Doriano del friuli, Italy',
        'Doriano del friuli',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        286,
        '833 Piazza Menegatti, Quarto Valfrido, Italy',
        'Quarto Valfrido',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        89,
        '8 Strada Bartolomeo, Gatta lido, Italy',
        'Gatta lido',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        65,
        '3 Incrocio Mansueto, Zabedeo calabro, Italy',
        'Zabedeo calabro',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        167,
        '712 Rotonda Giacomelli, San Aiace calabro, Italy',
        'San Aiace calabro',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        67,
        '583 Strada Grossi, Piga lido, Italy',
        'Piga lido',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        282,
        '0 Strada De Rosa, Sesto Virginia salentino, Italy',
        'Sesto Virginia salentino',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        152,
        '549 Rotonda Dante, Lombardi nell''emilia, Italy',
        'Lombardi nell''emilia',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        242,
        '153 Incrocio Caracciolo, Donato nell''emilia, Italy',
        'Donato nell''emilia',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '389 Strada Ermenegarda, Telesca salentino, Italy',
        'Telesca salentino',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        148,
        '57 Borgo Margherita, San Eufronio sardo, Italy',
        'San Eufronio sardo',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '89 Piazza Piersilvio, Settimo Cassio, Italy',
        'Settimo Cassio',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        221,
        '455 Contrada Ferrario, Innocente nell''emilia, Italy',
        'Innocente nell''emilia',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        271,
        '255 Strada Guglielmo, Tagliabue del friuli, Italy',
        'Tagliabue del friuli',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        126,
        '23 Piazza Abbondio, Pellicanò terme, Italy',
        'Pellicanò terme',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        224,
        '3 Via Pamela, Rocchi salentino, Italy',
        'Rocchi salentino',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        245,
        '681 Borgo Latini, Sesto Unna laziale, Italy',
        'Sesto Unna laziale',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        54,
        '8 Borgo Romano, Gianluca a mare, Italy',
        'Gianluca a mare',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        274,
        '09 Incrocio Edelberga, Quarto Paola terme, Italy',
        'Quarto Paola terme',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        97,
        '018 Via Bartolomeo, Mautone salentino, Italy',
        'Mautone salentino',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        193,
        '338 Strada Ginevra, Denaro calabro, Italy',
        'Denaro calabro',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        52,
        '08 Strada Mulè, Evaristo terme, Italy',
        'Evaristo terme',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        44,
        '5 Borgo Sala, San Atanasio ligure, Italy',
        'San Atanasio ligure',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        267,
        '4 Piazza Di Paola, Ferranti lido, Italy',
        'Ferranti lido',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        114,
        '917 Rotonda Gianpaolo, Sesto Gundelinda, Italy',
        'Sesto Gundelinda',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        241,
        '35 Strada Gonerio, San Doda, Italy',
        'San Doda',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        163,
        '2 Borgo Bonaventura, Pappalardo lido, Italy',
        'Pappalardo lido',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '3 Via Vezzoli, Amanda ligure, Italy',
        'Amanda ligure',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        172,
        '8 Via Piersilvio, Lorenzini a mare, Italy',
        'Lorenzini a mare',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        45,
        '56 Incrocio Criscione, Virone calabro, Italy',
        'Virone calabro',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        78,
        '2 Strada Marziali, Quarto Irene, Italy',
        'Quarto Irene',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        52,
        '3 Incrocio Caretti, Aris veneto, Italy',
        'Aris veneto',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        222,
        '6 Piazza Matteucci, Settimo Piersilvio calabro, Italy',
        'Settimo Piersilvio calabro',
        'Italy',
        'Lecco',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        232,
        '8 Borgo Tolu, Simeti salentino, Italy',
        'Simeti salentino',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        286,
        '98 Incrocio Eusebia, Murru ligure, Italy',
        'Murru ligure',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        183,
        '88 Borgo Tomei, San Alberico del friuli, Italy',
        'San Alberico del friuli',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        78,
        '169 Strada Lucilla, Albano a mare, Italy',
        'Albano a mare',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        290,
        '926 Incrocio Casella, Settimo Mina, Italy',
        'Settimo Mina',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        45,
        '4 Via Rotundo, Bernardi calabro, Italy',
        'Bernardi calabro',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        229,
        '53 Borgo Giuliano, Didimo terme, Italy',
        'Didimo terme',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        156,
        '60 Piazza Paterniano, Ione laziale, Italy',
        'Ione laziale',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        229,
        '459 Contrada Albanese, Sesto Indro, Italy',
        'Sesto Indro',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        272,
        '39 Strada Angeletti, Allegretti salentino, Italy',
        'Allegretti salentino',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        103,
        '7 Strada Ulfo, Borgo Zaira, Italy',
        'Borgo Zaira',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        188,
        '21 Piazza Tedde, Sesto Alarico, Italy',
        'Sesto Alarico',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        272,
        '0 Via Semprini, Almiro a mare, Italy',
        'Almiro a mare',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        123,
        '73 Rotonda Ruggiero, Sesto Climaco, Italy',
        'Sesto Climaco',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        211,
        '44 Rotonda Tufo, Famiano nell''emilia, Italy',
        'Famiano nell''emilia',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        145,
        '008 Contrada Gualberto, Erberto laziale, Italy',
        'Erberto laziale',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        291,
        '6 Borgo Erasmo, Diana calabro, Italy',
        'Diana calabro',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        215,
        '77 Borgo Aiello, Quarto Eugenia, Italy',
        'Quarto Eugenia',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        187,
        '351 Contrada Barone, Quarto Quartilla del friuli, Italy',
        'Quarto Quartilla del friuli',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        216,
        '7 Strada Barbara, Feliciano lido, Italy',
        'Feliciano lido',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        219,
        '8 Borgo Elmo, Demetrio laziale, Italy',
        'Demetrio laziale',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        173,
        '8 Borgo Aquilino, Sesto Romano terme, Italy',
        'Sesto Romano terme',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        119,
        '15 Contrada Adriana, San Ludovica, Italy',
        'San Ludovica',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        129,
        '338 Strada Muziano, Cicala sardo, Italy',
        'Cicala sardo',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        286,
        '050 Strada Celeste, Borgo Danio, Italy',
        'Borgo Danio',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        87,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        105,
        '3 Borgo Panico, Schettino umbro, Italy',
        'Schettino umbro',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        154,
        '07 Piazza Efrem, Giraudo nell''emilia, Italy',
        'Giraudo nell''emilia',
        'Italy',
        'Agrigento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        55,
        '8 Piazza Placida, Giustra umbro, Italy',
        'Giustra umbro',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        245,
        '028 Incrocio Cirillo, Musso del friuli, Italy',
        'Musso del friuli',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        237,
        '82 Via Barreca, Lazzarini veneto, Italy',
        'Lazzarini veneto',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        187,
        '53 Piazza Albino, Borgo Eusebio terme, Italy',
        'Borgo Eusebio terme',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        297,
        '56 Incrocio Furno, Eufebio calabro, Italy',
        'Eufebio calabro',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        124,
        '18 Incrocio Delogu, Eva ligure, Italy',
        'Eva ligure',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        118,
        '916 Borgo Pedrazzini, De Luca sardo, Italy',
        'De Luca sardo',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        30,
        '751 Strada Gavino, Sesto Giusto, Italy',
        'Sesto Giusto',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        108,
        '325 Piazza Ciacio, Pozzi salentino, Italy',
        'Pozzi salentino',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        212,
        '28 Borgo Amabile, San Galdino, Italy',
        'San Galdino',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        60,
        '7 Rotonda Morena, Mario veneto, Italy',
        'Mario veneto',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        36,
        '201 Incrocio Bino, Maio lido, Italy',
        'Maio lido',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        170,
        '497 Incrocio Murtas, Salierno umbro, Italy',
        'Salierno umbro',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        159,
        '47 Contrada Adrione, Dora sardo, Italy',
        'Dora sardo',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        125,
        '19 Via Pierluigi, Crespignano calabro, Italy',
        'Crespignano calabro',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        74,
        '3 Strada Respicio, San Saturniano sardo, Italy',
        'San Saturniano sardo',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        65,
        '096 Strada Eleuterio, Adalberta laziale, Italy',
        'Adalberta laziale',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        123,
        '7 Incrocio Beltrame, Pavone a mare, Italy',
        'Pavone a mare',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        213,
        '58 Incrocio Eva, Epifani salentino, Italy',
        'Epifani salentino',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        97,
        '9 Borgo Bartolomea, Viliberto umbro, Italy',
        'Viliberto umbro',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        257,
        '7 Via La Torre, Sara veneto, Italy',
        'Sara veneto',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        215,
        '514 Borgo Manzo, Borgo Asdrubale laziale, Italy',
        'Borgo Asdrubale laziale',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        272,
        '9 Via Novella, Tammaro umbro, Italy',
        'Tammaro umbro',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '467 Via Marino, Rampazzo laziale, Italy',
        'Rampazzo laziale',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        155,
        '08 Incrocio Bassiano, Torrisi lido, Italy',
        'Torrisi lido',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        161,
        '95 Strada Flacco, San Isa sardo, Italy',
        'San Isa sardo',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '5 Incrocio Scuderi, Sesto Acacio calabro, Italy',
        'Sesto Acacio calabro',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '082 Borgo Selvaggia, Diamante lido, Italy',
        'Diamante lido',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        251,
        '4 Strada Adalgiso, Quarto Adamo, Italy',
        'Quarto Adamo',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        34,
        '743 Strada Susanna, San Lidania, Italy',
        'San Lidania',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        293,
        '512 Borgo Fiorella, Settimo Gianmaria salentino, Italy',
        'Settimo Gianmaria salentino',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        291,
        '5 Strada Oliviero, Sesto Messalina, Italy',
        'Sesto Messalina',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        196,
        '458 Contrada Euclide, Bertolussi lido, Italy',
        'Bertolussi lido',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '43 Borgo Pacifico, Settimo Delfina, Italy',
        'Settimo Delfina',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '6 Piazza Valerio, San Romola, Italy',
        'San Romola',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        274,
        '25 Piazza Santo, Benvenuti a mare, Italy',
        'Benvenuti a mare',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '916 Borgo Moro, Sesto Nestore, Italy',
        'Sesto Nestore',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        294,
        '41 Strada Enea, Borgo Ferruccio, Italy',
        'Borgo Ferruccio',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        142,
        '86 Piazza Valenti, Monticelli del friuli, Italy',
        'Monticelli del friuli',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        58,
        '533 Via Usai, Bernabei lido, Italy',
        'Bernabei lido',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        185,
        '9 Piazza Tranquillo, Quarto Ildegarda, Italy',
        'Quarto Ildegarda',
        'Italy',
        'Arezzo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        259,
        '90 Via Baldo, Matarazzo lido, Italy',
        'Matarazzo lido',
        'Italy',
        'Perugia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        286,
        '123 Incrocio Andrisani, Borgo Innocenzo ligure, Italy',
        'Borgo Innocenzo ligure',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        218,
        '21 Contrada Maresca, Curci sardo, Italy',
        'Curci sardo',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        79,
        '08 Borgo Severa, San Gilda, Italy',
        'San Gilda',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        183,
        '75 Borgo Principato, De Carolis umbro, Italy',
        'De Carolis umbro',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        233,
        '691 Borgo Tarantino, Cristiana lido, Italy',
        'Cristiana lido',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        257,
        '502 Via Ventura, Amato umbro, Italy',
        'Amato umbro',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        271,
        '20 Strada Valente, Sesto Aristeo veneto, Italy',
        'Sesto Aristeo veneto',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        192,
        '6 Rotonda Palla, Sesto Saffiro, Italy',
        'Sesto Saffiro',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        241,
        '19 Strada Pugliese, Borgo Eufebio lido, Italy',
        'Borgo Eufebio lido',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        133,
        '9 Via Giordano, Medugno umbro, Italy',
        'Medugno umbro',
        'Italy',
        'Mantova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        116,
        '88 Contrada Venusta, Eloisa veneto, Italy',
        'Eloisa veneto',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        125,
        '914 Strada Cristiano, Papini a mare, Italy',
        'Papini a mare',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        117,
        '274 Piazza Giuliano, San Glenda lido, Italy',
        'San Glenda lido',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        176,
        '306 Piazza Affinito, Corazza salentino, Italy',
        'Corazza salentino',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        58,
        '2 Incrocio Manilio, Borgo Bruno, Italy',
        'Borgo Bruno',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        86,
        '79 Incrocio Caccamo, Boschi veneto, Italy',
        'Boschi veneto',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        84,
        '5 Contrada Sostene, Borgo Namazio, Italy',
        'Borgo Namazio',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        132,
        '420 Borgo Serafina, San Adriano, Italy',
        'San Adriano',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        300,
        '95 Rotonda Gerolamo, San Zetico, Italy',
        'San Zetico',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        95,
        '729 Incrocio Aimone, Sesto Ermete lido, Italy',
        'Sesto Ermete lido',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '380 Piazza Amendola, Quarto Godeberta del friuli, Italy',
        'Quarto Godeberta del friuli',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        68,
        '82 Incrocio Fioretti, Emma a mare, Italy',
        'Emma a mare',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        44,
        '85 Via Di Bari, Moscato terme, Italy',
        'Moscato terme',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        260,
        '28 Borgo Alarico, Di Fiore del friuli, Italy',
        'Di Fiore del friuli',
        'Italy',
        'Caltanissetta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        272,
        '8 Rotonda Moriconi, Marciano terme, Italy',
        'Marciano terme',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        196,
        '2 Rotonda Gerardo, Annamaria terme, Italy',
        'Annamaria terme',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        121,
        '739 Via Napolitano, San Paola, Italy',
        'San Paola',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        30,
        '2 Incrocio Liberati, Bordoni veneto, Italy',
        'Bordoni veneto',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        47,
        '88 Via Perra, Beltrame lido, Italy',
        'Beltrame lido',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        269,
        '977 Incrocio Desiderio, Settimo Respicio, Italy',
        'Settimo Respicio',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        95,
        '7 Strada Passarelli, San Neopolo, Italy',
        'San Neopolo',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        158,
        '90 Strada Riparbelli, Galdino nell''emilia, Italy',
        'Galdino nell''emilia',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        182,
        '72 Contrada Stefania, Quarto Dorotea laziale, Italy',
        'Quarto Dorotea laziale',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        120,
        '770 Via Amalia, Silvestro terme, Italy',
        'Silvestro terme',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        225,
        '776 Strada Tumino, Clara veneto, Italy',
        'Clara veneto',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        274,
        '95 Contrada Egidio, De Col a mare, Italy',
        'De Col a mare',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        206,
        '1 Strada Quirino, Sesto Ursicio umbro, Italy',
        'Sesto Ursicio umbro',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '1 Piazza Gilberto, Lorena salentino, Italy',
        'Lorena salentino',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        177,
        '271 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        64,
        '1 Rotonda Gerasimo, Quarto Alfio lido, Italy',
        'Quarto Alfio lido',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        226,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        137,
        '078 Incrocio Tarsilla, Settimo Richelmo, Italy',
        'Settimo Richelmo',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        83,
        '5 Contrada Carlo, Ballarin laziale, Italy',
        'Ballarin laziale',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        211,
        '1 Incrocio Puggioni, Prete nell''emilia, Italy',
        'Prete nell''emilia',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        78,
        '69 Borgo D''Amico, Mautone umbro, Italy',
        'Mautone umbro',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        59,
        '4 Via Adriano, Settimo Adalfredo, Italy',
        'Settimo Adalfredo',
        'Italy',
        'Padova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        116,
        '63 Piazza Di Tommaso, Borgo Galeazzo, Italy',
        'Borgo Galeazzo',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        111,
        '07 Piazza Faraone, Vitalico nell''emilia, Italy',
        'Vitalico nell''emilia',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        102,
        '36 Incrocio Dacio, Sigismondo lido, Italy',
        'Sigismondo lido',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        294,
        '8 Incrocio Goffredo, Settimo Everardo, Italy',
        'Settimo Everardo',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        28,
        '6 Borgo Idea, Ugolini sardo, Italy',
        'Ugolini sardo',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        34,
        '742 Contrada Bindi, Borgo Minervino umbro, Italy',
        'Borgo Minervino umbro',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        101,
        '70 Incrocio Ardito, Fernanda sardo, Italy',
        'Fernanda sardo',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        225,
        '5 Strada Gianpiero, Godeberta lido, Italy',
        'Godeberta lido',
        'Italy',
        'Belluno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        245,
        '999 Piazza Cordioli, Terenzi salentino, Italy',
        'Terenzi salentino',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        273,
        '1 Incrocio Corbiniano, San Prassede terme, Italy',
        'San Prassede terme',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        96,
        '5 Piazza Angelini, Flacco umbro, Italy',
        'Flacco umbro',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '766 Piazza Loris, Iannello veneto, Italy',
        'Iannello veneto',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        192,
        '4 Strada Aristotele, Settimo Vinfrido, Italy',
        'Settimo Vinfrido',
        'Italy',
        'Catanzaro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        119,
        '78 Strada Ottaviani, Foschi veneto, Italy',
        'Foschi veneto',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        247,
        '482 Rotonda Liberato, Bonanni lido, Italy',
        'Bonanni lido',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        122,
        '211 Piazza Casale, Moreno laziale, Italy',
        'Moreno laziale',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        282,
        '34 Incrocio Soro, Amanda sardo, Italy',
        'Amanda sardo',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        226,
        '4 Incrocio Ricario, Sottile nell''emilia, Italy',
        'Sottile nell''emilia',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        277,
        '704 Rotonda Ivo, Loreto veneto, Italy',
        'Loreto veneto',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        224,
        '17 Incrocio Pio, Sesto Gastone, Italy',
        'Sesto Gastone',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        131,
        '3 Incrocio Violi, Borgo Grazia, Italy',
        'Borgo Grazia',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '730 Strada Prospera, Settimo Orsino del friuli, Italy',
        'Settimo Orsino del friuli',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        143,
        '16 Incrocio De Carolis, Torrisi laziale, Italy',
        'Torrisi laziale',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        199,
        '11 Rotonda Longobardi, Santo laziale, Italy',
        'Santo laziale',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        33,
        '9 Contrada Clemenzia, Amadori del friuli, Italy',
        'Amadori del friuli',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        286,
        '494 Strada Pintus, Zappia sardo, Italy',
        'Zappia sardo',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        273,
        '722 Borgo Angelucci, Settimo Turi, Italy',
        'Settimo Turi',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        155,
        '4 Rotonda Lanteri, Veronese salentino, Italy',
        'Veronese salentino',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        92,
        '20 Strada Daniele, Ivano veneto, Italy',
        'Ivano veneto',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        104,
        '62 Borgo Attila, Borgo Ermenegarda, Italy',
        'Borgo Ermenegarda',
        'Italy',
        'Siracusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '8 Via Silvana, Borgo Filiberto, Italy',
        'Borgo Filiberto',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        83,
        '4 Contrada Assunta, Settimo Gillo veneto, Italy',
        'Settimo Gillo veneto',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        286,
        '5 Via Vecchi, Sesto Vala salentino, Italy',
        'Sesto Vala salentino',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        54,
        '48 Strada Folco, Quarto Mirta, Italy',
        'Quarto Mirta',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        96,
        '17 Incrocio Palombo, Settimo Tullia nell''emilia, Italy',
        'Settimo Tullia nell''emilia',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        163,
        '7 Via Ragone, Palumbo veneto, Italy',
        'Palumbo veneto',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        207,
        '9 Via Annagrazia, Settimo Ludovica, Italy',
        'Settimo Ludovica',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        266,
        '628 Contrada Ugo, Di Iorio lido, Italy',
        'Di Iorio lido',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        132,
        '77 Via Torchio, Borgo Raimondo, Italy',
        'Borgo Raimondo',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        94,
        '5 Incrocio Raide, Chiaravalle sardo, Italy',
        'Chiaravalle sardo',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        191,
        '088 Piazza Demetrio, Sesto Gianpietro laziale, Italy',
        'Sesto Gianpietro laziale',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        187,
        '0 Rotonda Ruperto, Quarto Telemaco salentino, Italy',
        'Quarto Telemaco salentino',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        223,
        '464 Piazza Sala, Marrazzo ligure, Italy',
        'Marrazzo ligure',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        243,
        '79 Borgo Attilano, Sesto Libero, Italy',
        'Sesto Libero',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        97,
        '81 Incrocio Giachi, Santoro laziale, Italy',
        'Santoro laziale',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        257,
        '2 Piazza Bassi, Marani del friuli, Italy',
        'Marani del friuli',
        'Italy',
        'Nuoro',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        270,
        '3 Borgo Cardinali, Sisto sardo, Italy',
        'Sisto sardo',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        105,
        '951 Contrada Perseo, Zambon a mare, Italy',
        'Zambon a mare',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        90,
        '6 Via Giannotti, Borgo Fosco, Italy',
        'Borgo Fosco',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        140,
        '0 Via Parente, Aza terme, Italy',
        'Aza terme',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        25,
        '217 Incrocio Lucarini, San Sostrato, Italy',
        'San Sostrato',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        168,
        '098 Via Sartori, Quarto Noemi, Italy',
        'Quarto Noemi',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        123,
        '650 Contrada Damaso, San Elsa, Italy',
        'San Elsa',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        212,
        '0 Contrada Puccio, Settimo Selene del friuli, Italy',
        'Settimo Selene del friuli',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        28,
        '58 Via Petronio, Quarto Cleopatra salentino, Italy',
        'Quarto Cleopatra salentino',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        139,
        '60 Borgo Gondulfo, Licitra ligure, Italy',
        'Licitra ligure',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        94,
        '068 Contrada Vannini, Settimo Bassiano ligure, Italy',
        'Settimo Bassiano ligure',
        'Italy',
        'Novara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        127,
        '620 Via Diamante, Saffo ligure, Italy',
        'Saffo ligure',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '697 Via Cappelli, Settimo Vodingo, Italy',
        'Settimo Vodingo',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        152,
        '8 Borgo Silvia, Sesto Ursino, Italy',
        'Sesto Ursino',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        130,
        '96 Borgo Lelia, Fratello a mare, Italy',
        'Fratello a mare',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        228,
        '1 Strada Berto, Tarsilla a mare, Italy',
        'Tarsilla a mare',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        235,
        '9 Borgo Candida, Sesto Edilberto a mare, Italy',
        'Sesto Edilberto a mare',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        65,
        '7 Strada Eriberto, Quarto Leopardo lido, Italy',
        'Quarto Leopardo lido',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        278,
        '3 Contrada Camillo, Gianotti a mare, Italy',
        'Gianotti a mare',
        'Italy',
        'Napoli',
        ''
      );
    
  