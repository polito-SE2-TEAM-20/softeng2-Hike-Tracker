--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: code-hike; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."code-hike" (
    code character varying(256) NOT NULL,
    "userHikeId" integer NOT NULL
);


--
-- Name: hike_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hike_points (
    "hikeId" integer NOT NULL,
    "pointId" integer NOT NULL,
    index integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    length numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "expectedTime" integer DEFAULT 0 NOT NULL,
    ascent numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    difficulty smallint DEFAULT '0'::smallint NOT NULL,
    title character varying(500) DEFAULT ''::character varying NOT NULL,
    description character varying(1000) DEFAULT ''::character varying NOT NULL,
    "gpxPath" character varying(1024),
    distance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    region public.citext DEFAULT ''::public.citext NOT NULL,
    province public.citext DEFAULT ''::public.citext NOT NULL,
    city public.citext DEFAULT ''::public.citext NOT NULL,
    country public.citext DEFAULT ''::public.citext NOT NULL,
    condition smallint DEFAULT '0'::smallint NOT NULL,
    cause character varying(256) DEFAULT ''::character varying,
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    "weatherStatus" smallint DEFAULT '0'::smallint,
    "weatherDescription" character varying(1000) DEFAULT ''::character varying
);


--
-- Name: hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hikes_id_seq OWNED BY public.hikes.id;


--
-- Name: hut-worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."hut-worker" (
    "userId" integer NOT NULL,
    "hutId" integer NOT NULL
);


--
-- Name: huts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.huts (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "numberOfBeds" integer,
    price numeric(12,2) DEFAULT '0'::numeric,
    title character varying(1024) DEFAULT ''::character varying NOT NULL,
    "userId" integer NOT NULL,
    "ownerName" character varying(1024),
    website character varying,
    elevation numeric(12,2),
    pictures jsonb DEFAULT '[]'::jsonb NOT NULL,
    description character varying(1024) DEFAULT ''::character varying,
    "workingTimeStart" time without time zone,
    "workingTimeEnd" time without time zone,
    "phoneNumber" character varying(20),
    email character varying(256)
);


--
-- Name: huts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.huts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: huts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.huts_id_seq OWNED BY public.huts.id;


--
-- Name: parking_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_lots (
    id integer NOT NULL,
    "pointId" integer NOT NULL,
    "maxCars" integer,
    "userId" integer NOT NULL,
    country character varying,
    region character varying,
    province character varying,
    city character varying
);


--
-- Name: parking_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parking_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parking_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parking_lots_id_seq OWNED BY public.parking_lots.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id integer NOT NULL,
    type smallint DEFAULT '0'::smallint NOT NULL,
    "position" public.geography(Point,4326),
    name character varying(256),
    address character varying(1024),
    altitude numeric(12,2)
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hike_track_points (
    "userHikeId" integer NOT NULL,
    index integer NOT NULL,
    "pointId" integer NOT NULL,
    datetime timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_hikes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "hikeId" integer NOT NULL,
    "startedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "psTotalKms" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psHighestAltitude" numeric(12,2),
    "psAltitudeRange" numeric(12,2),
    "psTotalTimeMinutes" numeric(12,2),
    "psAverageSpeed" numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    "psAverageVerticalAscentSpeed" numeric(12,2),
    "maxElapsedTime" interval,
    "weatherNotified" boolean DEFAULT false,
    "unfinishedNotified" boolean
);


--
-- Name: user_hikes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_hikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_hikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_hikes_id_seq OWNED BY public.user_hikes.id;


--
-- Name: user_hikes_track_points_user_hike_track_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_hikes_track_points_user_hike_track_points (
    "userHikesId" integer NOT NULL,
    "userHikeTrackPointsUserHikeId" integer NOT NULL,
    "userHikeTrackPointsIndex" integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying(256) NOT NULL,
    "firstName" character varying(100) NOT NULL,
    "lastName" character varying(100) NOT NULL,
    role integer NOT NULL,
    email character varying(256) NOT NULL,
    "phoneNumber" character varying(10),
    verified boolean DEFAULT false NOT NULL,
    "verificationHash" character varying(256),
    approved boolean DEFAULT false NOT NULL,
    preferences jsonb,
    "plannedHikes" integer[]
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes ALTER COLUMN id SET DEFAULT nextval('public.hikes_id_seq'::regclass);


--
-- Name: huts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts ALTER COLUMN id SET DEFAULT nextval('public.huts_id_seq'::regclass);


--
-- Name: parking_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots ALTER COLUMN id SET DEFAULT nextval('public.parking_lots_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: user_hikes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes ALTER COLUMN id SET DEFAULT nextval('public.user_hikes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: parking_lots PK_27af37fbf2f9f525c1db6c20a48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "PK_27af37fbf2f9f525c1db6c20a48" PRIMARY KEY (id);


--
-- Name: user_hikes PK_2b0b2b6b59dc57d133a353a953d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "PK_2b0b2b6b59dc57d133a353a953d" PRIMARY KEY (id);


--
-- Name: hut-worker PK_2c732ecb89b4368ba72b281654b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "PK_2c732ecb89b4368ba72b281654b" PRIMARY KEY ("userId", "hutId");


--
-- Name: points PK_57a558e5e1e17668324b165dadf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT "PK_57a558e5e1e17668324b165dadf" PRIMARY KEY (id);


--
-- Name: user_hike_track_points PK_81a17bd27de4a41931a4eaf5217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "PK_81a17bd27de4a41931a4eaf5217" PRIMARY KEY ("userHikeId", index);


--
-- Name: hikes PK_881b1b0345363b62221642c4dcf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "PK_881b1b0345363b62221642c4dcf" PRIMARY KEY (id);


--
-- Name: code-hike PK_9500beb2927801a6786af62da6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "PK_9500beb2927801a6786af62da6f" PRIMARY KEY (code);


--
-- Name: hike_points PK_9ab8dc4d573150ef80eb53038c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "PK_9ab8dc4d573150ef80eb53038c2" PRIMARY KEY ("hikeId", "pointId", type);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: huts PK_adcd88a1c922beb9143eb3bdfec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "PK_adcd88a1c922beb9143eb3bdfec" PRIMARY KEY (id);


--
-- Name: user_hikes_track_points_user_hike_track_points PK_ba36f9f2e9463bf6a8e4c43f222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "PK_ba36f9f2e9463bf6a8e4c43f222" PRIMARY KEY ("userHikesId", "userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_15eee9079461d7d0738ffca93b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_15eee9079461d7d0738ffca93b" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikesId");


--
-- Name: IDX_5578b74fb3a7136ae7fc341274; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_5578b74fb3a7136ae7fc341274" ON public.user_hikes_track_points_user_hike_track_points USING btree ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex");


--
-- Name: hike_points_hikeId_index_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "hike_points_hikeId_index_idx" ON public.hike_points USING btree ("hikeId", index);


--
-- Name: points_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_position_idx ON public.points USING gist ("position");


--
-- Name: user_hikes_track_points_user_hike_track_points FK_15eee9079461d7d0738ffca93bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_15eee9079461d7d0738ffca93bb" FOREIGN KEY ("userHikesId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hikes FK_3a853c2e56855fa75564bc82b95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hikes
    ADD CONSTRAINT "FK_3a853c2e56855fa75564bc82b95" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_4a2dcd9958cff25c15716d39ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_4a2dcd9958cff25c15716d39ace" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes_track_points_user_hike_track_points FK_5578b74fb3a7136ae7fc3412747; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes_track_points_user_hike_track_points
    ADD CONSTRAINT "FK_5578b74fb3a7136ae7fc3412747" FOREIGN KEY ("userHikeTrackPointsUserHikeId", "userHikeTrackPointsIndex") REFERENCES public.user_hike_track_points("userHikeId", index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: huts FK_6c722f6be150f27b3b63b572dd6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.huts
    ADD CONSTRAINT "FK_6c722f6be150f27b3b63b572dd6" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_887e0df89863e659bb84db732de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_887e0df89863e659bb84db732de" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: code-hike FK_9d5037cc0db6ebcdf6bd0c17ee6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."code-hike"
    ADD CONSTRAINT "FK_9d5037cc0db6ebcdf6bd0c17ee6" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_b3a54f24b64d7b8a2ec144475b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_b3a54f24b64d7b8a2ec144475b9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parking_lots FK_bcefe331ee2ad14ff880bdfddc5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_lots
    ADD CONSTRAINT "FK_bcefe331ee2ad14ff880bdfddc5" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hut-worker FK_fb368a3d4c117270161897f7014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."hut-worker"
    ADD CONSTRAINT "FK_fb368a3d4c117270161897f7014" FOREIGN KEY ("hutId") REFERENCES public.huts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hike_points hike_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hike_points
    ADD CONSTRAINT "hike_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_pointId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_pointId_fk" FOREIGN KEY ("pointId") REFERENCES public.points(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hike_track_points user_hike_track_points_userHikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hike_track_points
    ADD CONSTRAINT "user_hike_track_points_userHikeId_fk" FOREIGN KEY ("userHikeId") REFERENCES public.user_hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_hikeId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_hikeId_fk" FOREIGN KEY ("hikeId") REFERENCES public.hikes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_hikes user_hikes_userId_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_hikes
    ADD CONSTRAINT "user_hikes_userId_fk" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    2,
    'antonio@localguide.it',
    '$2b$10$RYnvthmz69nV/99YLqX4jOwa8yG.o2INmQtr2HJcd6oZzJjKnl/ny',
    'Antonio',
    'Battipaglia',
    2,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    4,
    'erfan@hutworker.it',
    '$2b$10$BBOh1E92pUN1SDdJQOosgeNlJ7FFneNMr5LjKnK3p8vbIWhTEZssq',
    'Erfan',
    'Gholami',
    4,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    5,
    'laura@emergency.it',
    '$2b$10$0.XL/Z43yV7cRve576WBnuv4LU9LU3yFvNzvbb1yo6TIjWynY8NYW',
    'Laura',
    'Zurru',
    5,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    1,
    'german@hiker.it',
    '$2b$10$YrDvgyN7S0C1xnL.aDcC3u/3M0ngFk4EN5hFKiuCbC9sEvPBPbVxe',
    'German',
    'Gorodnev',
    0,
    true,
    true
  );
  

  INSERT INTO "public"."users" (
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "role",
    "verified",
    "approved"
  ) VALUES(
    3,
    'vincenzo@admin.it',
    '$2b$10$TuXve46Gdk9wwmFuE0Hr6.8SG8zYkv/DcdihnhWP8iA0Z3Rr1J0wG',
    'vincenzo',
    'Sagristano',
    3,
    true,
    true
  );
  

      CREATE OR REPLACE FUNCTION public.insert_hike(
        user_id integer,
        title varchar,
        difficulty integer,
        gpx_path varchar,
        country varchar,
        region varchar,
        province varchar,
        city varchar,
        length numeric(12,2),
        ascent numeric(12,2),
        expected_time integer,
        description varchar,
        pictures jsonb,
        start_point jsonb,
        end_point jsonb,
        reference_points jsonb
      )  RETURNS VOID AS
      $func$
      DECLARE
        hike_id integer;
        point_id integer;
        ref jsonb;
        i integer;
      BEGIN
      INSERT INTO "public"."hikes" (
        "userId",
        "title",
        "difficulty",
        "gpxPath",
        "country",
        "region",
        "province",
        "city",
        "length",
        "ascent",
        "expectedTime",
        "description",
        "pictures"
      ) VALUES(
        user_id, title, difficulty, gpx_path,
        country, region, province, city,
        length, ascent, expected_time, description, pictures
      ) returning id into hike_id;

      -- create start end point if necessary
      if start_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((start_point->>'lon')::double precision, (start_point->>'lat')::double precision), 4326),
          (start_point->>'name')::varchar,
          (start_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          5,
          0
        );
      end if;

      -- end point --
      if end_point is not null then
        insert into public.points (
          "type", "position", "name", "address"
        ) values (
          0,
          public.ST_SetSRID(public.ST_MakePoint((end_point->>'lon')::double precision, (end_point->>'lat')::double precision), 4326),
          (end_point->>'name')::varchar,
          (end_point->>'address')::varchar
        ) returning id into point_id;
        insert into public.hike_points (
          "hikeId", "pointId", "type", "index"
        ) values (
          hike_id,
          point_id,
          6,
          100000
        );
      end if;

      -- reference points
      i = 1;
      if reference_points is not null then
        for ref in select * FROM jsonb_array_elements(reference_points)
        loop
          insert into public.points (
            "type", "position", "name", "address", "altitude"
          ) values (
            0,
            public.ST_SetSRID(public.ST_MakePoint((ref->>'lon')::double precision, (ref->>'lat')::double precision), 4326),
            (ref->>'address')::varchar,
            (ref->>'name')::varchar,
            (ref->>'altitude')::numeric(12,2)
          ) returning id into point_id;
          insert into public.hike_points (
            "hikeId", "pointId", "type", "index"
          ) values (
            hike_id,
            point_id,
            3,
            i
          );
          i = i + 1;
        end loop;
      end if;
      END
      $func$ LANGUAGE plpgsql;

      
      select public."insert_hike"(
        2,
        'Amprimo',
        2,
        '/static/gpx/Amprimo.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Bussoleno',
        1.2,
        24.3,
        80,
        'Durante il periodo invernale la strada è pulita solo fino all’abitato di Città, sarà necessario quindi lasciare l’auto qui e proseguire a piedi.',
        '["/static/images/3.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.165559804,"lat":45.102780737}'::jsonb,
        '{"name":"End Point","address":"Rifugio Amprimo, Via Rio Gerardo, Giordani, Mattie, Torino, Piemonte, 10053, Italia","lon":7.14299586,"lat":45.099887898}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":7.164360252,"lat":45.102912389,"altitude":1256.852},{"name":"Ref Point 2","address":"","lon":7.158207147,"lat":45.102886551,"altitude":1283.605}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Anello Chateau Beaulard - Cotolivier - Vazon',
        1,
        '/static/gpx/Anello Chateau Beaulard - Cotolivier - Vazon.gpx',
        'Italia',
        'Piemonte',
        'Torino',
        'Beaulard',
        10.7,
        23.2,
        200,
        'Per arrivarci bisogna seguire la strada statale 335 in direzione Bardonecchia fino a svoltare a sinistra, seguendo le indicazioni per Beaulard, passando sotto uno stretto sottopassaggio. Lasciandosi a sinistra il campeggio che si incontra dopo aver attraversato un ponte, si prosegue su una stretta strada asfaltata fino a giungere in prossimità dell’abitato di Chateau Beaulard. Prima di entrare nel paese si svolta a destra fino ad arrivare ad un piccolo spiazzo dove è possibile parcheggiare la macchina.',
        '["/static/images/2.jpg"]'::jsonb,
        '{"name":"Start Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.772358,"lat":45.03205}'::jsonb,
        '{"name":"End Point","address":"San Michele, Circonvallazione Borgata Chateau, Château Beaulard, Beaulard, Oulx, Torino, Piemonte, 10056, Italia","lon":6.77234,"lat":45.032238}'::jsonb,
        NULL
      );
    
      select public."insert_hike"(
        2,
        'Lago Bianco',
        2,
        '/static/gpx/Lago Bianco.gpx',
        'Francia',
        'Auvergne-Rhone-Alpes',
        'Savoia',
        'Val-Cenis',
        10.8,
        19.2,
        210,
        'Il punto di partenza di questa escursione è la famosa e imponente Diga del Moncenisio , più precisamente il piazzale del Forte Varisello.

La diga, costruita nel 1968, dà vita al lago artificiale del Moncenisio, che prende il nome dal colle ove è situato: il Colle del Moncenisio.

La Diga è percorribile oltre che a piedi anche in macchina e ciò consente di parcheggiare l’autovettura da entrambi i lati dello sbarramento. Il fondo è sterrato ma facilmente percorribile da tutte le autovetture.

Si può inoltre partire dal parcheggio dell’Hotel Malamot oppure, allungando notevolmente il tragitto, dal parcheggio antistante il Lago Arpone.',
        '["/static/images/1.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945681,"lat":45.223814}'::jsonb,
        '{"name":"End Point","address":"Sous la Maison, D 1006, Gran Croce, Lanslebourg-Mont-Cenis, Val-Cenis, Saint-Jean-de-Maurienne, Savoia, Auvergne-Rhône-Alpes, Francia metropolitana, 73480, Francia","lon":6.945581,"lat":45.224058}'::jsonb,
        '[{"name":"fountain","address":"","lon":6.940291,"lat":45.222543,"altitude":2027},{"name":"Peak","address":"","lon":6.937204,"lat":45.215867,"altitude":2131}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'Alte Langhe Settentrionali - Cossano Belbo',
        2,
        '/static/gpx/alte-langhe-settentrionali-cossano-belbo-dalla-scala-santa-a.gpx',
        'Italia',
        'Piemonte',
        'Cuneo',
        'Cossano Belbo',
        5.7,
        7.1,
        200,
        'Parcheggiata l’auto nella piazza antistante al Comune si percorre per poche centinaia di metri la Strada Provinciale n.592 in direzione Santo Stefano Belbo.
Si svolta a destra e si inizia a salire fino ad incontrare la Chiesetta di Santa Libera e le indicazioni per la Scala Santa.
Si imbocca il Sentiero sulla sinistra della Chiesetta e si procede prima in piano, poi in discesa fino ad un ponte in legno che consente di oltrepassare un torrente.
Inizia ora una scalinata in pietra che sale fino ad un pianoro. Raggiunta la sommità si svolta a sinistra e seguendo le indicazioni si incontra la strada asfaltata nei pressi della Cascina Borella.
Percorse alcune centinaia di metri si svolta a destra su Sentiero in salita per giungere alla Chiesetta di San Bovo. 
Seguendo il Sentiero si supera un agriturismo e poi subito sulla sinistra si procede su asfalto. 
Si procede per un paio di chilometri, passando accanto ad alcune cascine, fino a trovare l’installazione panoramica della Panchina Gigante',
        '["/static/images/4.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199049,"lat":44.670379}'::jsonb,
        '{"name":"End Point","address":"Via Statale, Cossano Belbo, Cuneo, Piemonte, 12054, Italia","lon":8.199052,"lat":44.670377}'::jsonb,
        '[{"name":"Ref Point 1","address":"","lon":8.214142,"lat":44.674545,"altitude":482.526},{"name":"Ref Point 2","address":"","lon":8.197792,"lat":44.668772,"altitude":242.585}]'::jsonb
      );
    
      select public."insert_hike"(
        2,
        'La pieve romanica di Piesenzana e la valle delle tartufaie',
        2,
        '/static/gpx/la-pieve-romanica-di-piesenzana-e-la-valle-delle-tartufaie.gpx',
        'Italia',
        'Piemonte',
        'Asti',
        'Montechiaro d''Asti',
        3.9,
        27.6,
        225,
        'Sul territorio del Comune di Montechiaro vi è una delle più estese zone italiane con presenza di “Riserve tartufigene”. 
Circa 50 ettari di terreno che si estendono nelle valli Bairello,Beronco e Seria. 
In regione Santa Maria, l’Amministrazione comunale ha allestito una tartufaia didattica dove vengono effettuate ricerche simulate del tartufo. 
A Montechiaro si tiene ,annualmente,la fiera nazionale del tartufo bianco(mercato con bancarelle piene di tartufi,premi ai migliori esemplari di tartufo e premi ai trifolau più abili). 
Contemporaneamente i ristoranti della zona propongono piatti a base di tartufi',
        '["/static/images/5.jpg"]'::jsonb,
        '{"name":"Start Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.113224,"lat":45.007605}'::jsonb,
        '{"name":"End Point","address":"Piazza della Pace, Piazza del Mercato, Montechiaro d''Asti, Asti, Piemonte, 14025, Italia","lon":8.11358,"lat":45.007557}'::jsonb,
        NULL
      );
    
    

    CREATE OR REPLACE FUNCTION public.insert_hut(
        user_id integer,
        lat double precision,
        lon double precision,
        number_of_beds integer,
        price numeric(12,2),
        title varchar,
        address varchar,
        owner_name varchar,
        website varchar,
        elevation numeric(12,2),
        working_time_start time without time zone,
        working_time_end time without time zone,
        email varchar,
        phone_number varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      title,
      address
    ) returning id into point_id;

    INSERT INTO "public"."huts" (
      "userId",
      "pointId",
      "numberOfBeds",
      "price",
      "title",
      "ownerName",
      "website",
      "elevation",
      "workingTimeStart",
      "workingTimeEnd",
      "email",
      "phoneNumber"
    ) VALUES (
      user_id,
      point_id,
      number_of_beds,
      price,
      title,
      owner_name,
      website,
      elevation,
      working_time_start,
      working_time_end,
      email,
      phone_number
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_hut"(
        2,
        47.1061142857357,
        10.355740296583543,
        3,
        118::numeric(12,2),
        'Edmund-Graf-Hütte',
        '6574 Pettneu am Arlberg, Tyrol, Austria',
        'Icaro Cini',
        'http://pink-fowl.org',
        321.137,
        '06:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Otello_Brigand36@email.it',
        '+390740717241'
      );
    

      select public."insert_hut"(
        2,
        46.94900379556081,
        13.027777224005726,
        10,
        58::numeric(12,2),
        'Dr.Hernaus-Stöckl',
        '9020 Klagenfurt, Kärnten, Austria',
        'Oriana Giacalone',
        'http://spry-drink.com',
        325.213,
        '03:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Beltramo_Scherini@gmail.com',
        '+398389343473'
      );
    

      select public."insert_hut"(
        2,
        47.886412300022904,
        14.7706766964203,
        8,
        133::numeric(12,2),
        'Amstettner Hütte',
        '3340 Waidhofen an der Ybbs, Niederösterreich, Austria',
        'Grazia Delfino',
        'http://enraged-pinot.org',
        323.095,
        '08:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Giusta_Foglia@yahoo.it',
        '+391428766841'
      );
    

      select public."insert_hut"(
        2,
        47.829029291932436,
        13.605655842511716,
        1,
        71::numeric(12,2),
        'Hochleckenhaus',
        '4853 Steinbach am Attersee, Oberösterreich, Austria',
        'Eliseo Salierno',
        'https://crazy-witch.net',
        308.48,
        '02:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Gildo.Ortenzi@gmail.com',
        '+398261847902'
      );
    

      select public."insert_hut"(
        2,
        48.133177016667204,
        16.19673029504743,
        5,
        115::numeric(12,2),
        'Kampthalerhütte',
        '2384 Breitenfurt bei Wien, Niederösterreich, Austria',
        'Calogera Proietti',
        'https://unruly-sweat.it',
        305.623,
        '01:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Odidone.Palazzolo@yahoo.it',
        '+398317732550'
      );
    

      select public."insert_hut"(
        2,
        47.65436297966914,
        13.701469666079605,
        5,
        64::numeric(12,2),
        'Lambacher Hütte',
        '4822 Bad Goisern, Oberösterreich, Austria',
        'Sisto Mazzeo',
        'https://selfish-piss.it',
        325.583,
        '09:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Menodora28@gmail.com',
        '+399073869680'
      );
    

      select public."insert_hut"(
        2,
        47.39476399550112,
        9.82470240665002,
        2,
        97::numeric(12,2),
        'Lustenauer Hütte',
        '6867 Schwarzenberg, Bregenzerwald, Vorarlberg, Austria',
        'Iris Pugliese',
        'http://neglected-expert.net',
        260.53,
        '04:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Ferdinando84@gmail.com',
        '+399676956035'
      );
    

      select public."insert_hut"(
        2,
        47.5330181684059,
        13.479859876622964,
        7,
        142::numeric(12,2),
        'Gablonzer Hütte',
        '4825 Gosau-Hintertal, Oberösterreich, Austria',
        'Gerolamo Bonazzi',
        'http://considerate-midline.com',
        331.177,
        '05:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Rachele.Benvenuti2@gmail.com',
        '+390295345851'
      );
    

      select public."insert_hut"(
        2,
        38.1617057,
        23.7467226,
        3,
        85::numeric(12,2),
        'Katafygio «Flampouri»',
        '136 72 Acharnes, Attica region, Greece',
        'Benigna Fois',
        'https://whispered-accuracy.it',
        318.534,
        '03:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Manuela.Martelli24@gmail.com',
        '+393568582903'
      );
    

      select public."insert_hut"(
        2,
        47.500812064015854,
        13.623639175114505,
        5,
        142::numeric(12,2),
        'Simonyhütte',
        '4830 Hallstatt, Oberösterreich, Austria',
        'Dott. Benigna Di Santo',
        'http://excellent-climate.net',
        294.706,
        '03:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Tizio_Ferrario74@yahoo.it',
        '+397934199404'
      );
    

      select public."insert_hut"(
        2,
        47.256833467895824,
        11.548502117523276,
        1,
        130::numeric(12,2),
        'Vinzenz-Tollinger-Hütte',
        '6060 Hall in Tirol, Tyrol, Austria',
        'Dott. Remo Di Martino',
        'https://unwelcome-syndicate.org',
        332.626,
        '05:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Beniamino_Errico94@libero.it',
        '+393971165301'
      );
    

      select public."insert_hut"(
        2,
        47.40560743759773,
        15.35938528309549,
        6,
        149::numeric(12,2),
        'Ottokar-Kernstock-Haus',
        '8600 Bruck an der Mur, Steiermark, Austria',
        'Raide Mecca',
        'http://steel-picnic.net',
        299.817,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Brando_Mazzaro41@yahoo.it',
        '+398073642905'
      );
    

      select public."insert_hut"(
        2,
        46.91544374294578,
        13.374005078791058,
        7,
        100::numeric(12,2),
        'Reisseckhütte',
        '9814 Mühldorf, Mölltal, Kärnten, Austria',
        'Metrofane Marchesi',
        'http://limited-step-son.it',
        265.853,
        '03:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Gianpiero_DiFranco3@hotmail.com',
        '+399483837788'
      );
    

      select public."insert_hut"(
        2,
        46.853611,
        10.823889,
        6,
        123::numeric(12,2),
        'Vernagthütte',
        'Austria',
        'Orchidea Militello',
        'http://subtle-consumer.it',
        301.65,
        '04:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Alberto.Zambon38@gmail.com',
        '+393758384714'
      );
    

      select public."insert_hut"(
        2,
        47.063889,
        9.974722,
        10,
        123::numeric(12,2),
        'Wormser Hütte',
        'Austria',
        'Rosalinda Citro',
        'http://relieved-layer.org',
        272.619,
        '06:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Umile.Licciardello22@hotmail.com',
        '+399143193859'
      );
    

      select public."insert_hut"(
        2,
        47.257778,
        10.028611,
        8,
        46::numeric(12,2),
        'Biberacher Hütte',
        'Austria',
        'Brancaleone D''Aleo',
        'https://speedy-supplier.org',
        275.454,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Zosimo_Pavan@gmail.com',
        '+397909667650'
      );
    

      select public."insert_hut"(
        2,
        41.3174397,
        23.0772158,
        1,
        41::numeric(12,2),
        'Katafygio «1777»',
        '620 55 Kerkini, Central Macedonia region, Greece',
        'Valerico Toti',
        'https://big-hearted-profit.it',
        269.724,
        '09:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Bruno84@libero.it',
        '+394111214683'
      );
    

      select public."insert_hut"(
        2,
        48.882222,
        13.021944,
        10,
        110::numeric(12,2),
        'Hochwaldhütte',
        'Germany',
        'Settimio Romanini',
        'https://free-shower.org',
        311.322,
        '03:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Candida_Scalia@yahoo.com',
        '+390613065582'
      );
    

      select public."insert_hut"(
        2,
        50.659444,
        6.481111,
        8,
        115::numeric(12,2),
        'Kölner Eifelhütte',
        'Germany',
        'Ombretta Tolomeo',
        'http://flickering-compulsion.org',
        306.062,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Lorenzo.DiFiore30@hotmail.com',
        '+394896991133'
      );
    

      select public."insert_hut"(
        2,
        46.951389,
        9.910833,
        1,
        86::numeric(12,2),
        'Madrisahütte',
        'Austria',
        'Erenia Nardi',
        'https://unfinished-inclusion.com',
        328.968,
        '05:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Aureliano.DiFranco80@gmail.com',
        '+397916383521'
      );
    

      select public."insert_hut"(
        2,
        46.998056,
        11.139444,
        7,
        88::numeric(12,2),
        'Dresdner Hütte',
        'Austria',
        'Damiano Rondoni',
        'http://scared-priest.com',
        275.066,
        '08:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Ferdinando.Scano@gmail.com',
        '+395575945928'
      );
    

      select public."insert_hut"(
        2,
        47.315556,
        10.2125,
        4,
        66::numeric(12,2),
        'Fiderepasshütte',
        'Germany',
        'Brunilde Marino',
        'https://that-hydroxyl.it',
        299.755,
        '05:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Sabina48@hotmail.com',
        '+393634558219'
      );
    

      select public."insert_hut"(
        2,
        47.214722,
        10.045833,
        7,
        84::numeric(12,2),
        'Göppinger Hütte',
        'Austria',
        'Nicla Fabrizi',
        'http://stupendous-sock.com',
        299.386,
        '06:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Otilia_Epifani@email.it',
        '+395447379580'
      );
    

      select public."insert_hut"(
        2,
        47.079722,
        9.693333,
        10,
        145::numeric(12,2),
        'Oberzalimhütte',
        'Austria',
        'Roberta Palombi',
        'http://colorless-exception.net',
        309.413,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Ambra_Giordano57@yahoo.it',
        '+399836801319'
      );
    

      select public."insert_hut"(
        2,
        47.232222,
        11.788333,
        6,
        73::numeric(12,2),
        'Rastkogelhütte',
        'Austria',
        'Ubaldo De Col',
        'https://oily-blend.com',
        317.422,
        '02:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Agata_Latorre16@email.it',
        '+398831516922'
      );
    

      select public."insert_hut"(
        2,
        47.5160493,
        10.027578,
        10,
        74::numeric(12,2),
        'Ansbacher Skihütte im Allgäu',
        'Germany',
        'Dafne Vincenzi',
        'http://unwitting-wiring.org',
        295.878,
        '04:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Costanza3@email.it',
        '+396985667151'
      );
    

      select public."insert_hut"(
        2,
        47.119167,
        10.143333,
        2,
        96::numeric(12,2),
        'Kaltenberghütte',
        'Austria',
        'Marino Manzi',
        'https://deep-celery.org',
        317.782,
        '04:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Bonavita_Perilli25@libero.it',
        '+397630071431'
      );
    

      select public."insert_hut"(
        2,
        47.158056,
        11.02,
        5,
        120::numeric(12,2),
        'Schweinfurter Hütte',
        'Austria',
        'Secondiano Di Iorio',
        'https://pretty-sausage.org',
        326.124,
        '03:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Ildegarda_Biondi7@libero.it',
        '+395334037944'
      );
    

      select public."insert_hut"(
        2,
        38.68682159999999,
        22.1302817,
        1,
        137::numeric(12,2),
        'Katafygio «Vardousion»',
        '330 53 Delphi, Central Greece region, Greece',
        'Rosamunda Marcelli',
        'http://bowed-monastery.it',
        281.094,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Giordano89@hotmail.com',
        '+390342820321'
      );
    

      select public."insert_hut"(
        2,
        46.35565059,
        14.63976333,
        10,
        40::numeric(12,2),
        'Kocbekov dom na Korošici',
        '3334 Luče, Mozirje, Slovenia',
        'Gottardo Menozzi',
        'https://subdued-option.net',
        304.639,
        '08:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Donna4@hotmail.com',
        '+390294137354'
      );
    

      select public."insert_hut"(
        2,
        46.13910301,
        14.51259234,
        6,
        106::numeric(12,2),
        'Planinski dom Rašiške cete na Rašici',
        '1211 Ljubljana, Šmartno, Slovenia',
        'Guiscardo Marzocchi',
        'http://conscious-brass.com',
        272.416,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Diodoro96@yahoo.it',
        '+390817462428'
      );
    

      select public."insert_hut"(
        2,
        46.43132893,
        14.17484616,
        5,
        50::numeric(12,2),
        'Prešernova koca na Stolu',
        '4274 Žirovnica, Slovenia',
        'Galileo Cecchini',
        'https://kind-attendant.net',
        300.321,
        '07:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Evremondo.Passuello59@email.it',
        '+392174052147'
      );
    

      select public."insert_hut"(
        2,
        46.18826602,
        15.10897349,
        4,
        92::numeric(12,2),
        'Planinski dom na Mrzlici',
        '3302 Griže, Slovenia',
        'Menelao Viscò',
        'https://grounded-wrench.com',
        274.163,
        '02:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Agostina_Ceccarini@yahoo.com',
        '+399765562752'
      );
    

      select public."insert_hut"(
        2,
        45.971381,
        14.251512,
        1,
        104::numeric(12,2),
        'Koca na Planini nad Vrhniko',
        '1360 Vrhnika, Slovenia',
        'Orazio Boschi',
        'https://heavenly-journalist.com',
        317.877,
        '09:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Iris.Liverani@libero.it',
        '+393729571483'
      );
    

      select public."insert_hut"(
        2,
        46.16262516,
        14.09934467,
        5,
        43::numeric(12,2),
        'Zavetišce gorske straže na Jelencih',
        '0, -, Slovenia',
        'Verena Liguori',
        'http://steel-convection.com',
        279.326,
        '01:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Pardo76@yahoo.com',
        '+396285412537'
      );
    

      select public."insert_hut"(
        2,
        46.298404,
        15.217569,
        5,
        66::numeric(12,2),
        'Planinski dom na Gori',
        'Šentjungert, 3310 Žalec, Slovenia',
        'Pompeo Piras',
        'https://dear-presume.org',
        263.379,
        '07:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Stefano.Vierin59@yahoo.com',
        '+391762054577'
      );
    

      select public."insert_hut"(
        2,
        46.30593224,
        13.81751242,
        6,
        67::numeric(12,2),
        'Bregarjevo zavetišce na planini Viševnik',
        '4265 Bohinjsko jezero, Slovenia',
        'Dott. Beniamino Bordoni',
        'https://menacing-weird.com',
        278.102,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Miriam_Corona94@yahoo.it',
        '+391896206982'
      );
    

      select public."insert_hut"(
        2,
        46.28772735,
        13.7632778,
        1,
        150::numeric(12,2),
        'Koca pod Bogatinom',
        '4265 Bohinjsko jezero, Slovenia',
        'Ursino Masi',
        'https://plush-beaver.net',
        264.028,
        '03:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Brando28@yahoo.com',
        '+391593616186'
      );
    

      select public."insert_hut"(
        2,
        46.40196483,
        13.80057723,
        8,
        134::numeric(12,2),
        'Pogacnikov dom na Kriških podih',
        '5232 Soca, Slovenia',
        'Scolastica Campoli',
        'http://hot-excursion.it',
        292.869,
        '09:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Procopio55@hotmail.com',
        '+395289613356'
      );
    

      select public."insert_hut"(
        2,
        46.41331733,
        14.90018259,
        6,
        94::numeric(12,2),
        'Dom na Smrekovcu',
        '3325 Šoštanj, Slovenia',
        'Debora Bellomo',
        'https://infatuated-dolman.net',
        271.869,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Barsimeo23@gmail.com',
        '+390065855305'
      );
    

      select public."insert_hut"(
        2,
        44.975819,
        6.299482,
        10,
        69::numeric(12,2),
        'Refuge Du Chatelleret',
        '38520 Saint Christophe En Oisans, Isère, France',
        'Sig. Clemenzia Contini',
        'http://costly-disposer.it',
        331.702,
        '03:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Pammachio_Bortolin@hotmail.com',
        '+392268976876'
      );
    

      select public."insert_hut"(
        2,
        44.841367,
        6.236673,
        2,
        112::numeric(12,2),
        'Refuge De Chalance',
        '5800 La Chapelle En Valgaudemar, Hautes-Alpes, France',
        'Luce Martini',
        'https://precious-integrity.net',
        301.986,
        '06:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Amico.Scarano@yahoo.com',
        '+391855618474'
      );
    

      select public."insert_hut"(
        2,
        44.834424,
        6.361139,
        2,
        145::numeric(12,2),
        'Refuge Des Bans',
        '5290 Vallouise, Hautes-Alpes, France',
        'Virginia Sepe',
        'https://realistic-opportunity.it',
        311.063,
        '05:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Oderico_Torchio@yahoo.com',
        '+393194286890'
      );
    

      select public."insert_hut"(
        2,
        42.835504,
        -0.42694,
        10,
        46::numeric(12,2),
        'Refuge De Pombie',
        '65400 Laruns, Pyrénées-Atlantiques, France',
        'Cesario Mattioli',
        'https://squiggly-fraud.org',
        291.8,
        '07:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Diocleziano_Padovan@yahoo.it',
        '+396244170618'
      );
    

      select public."insert_hut"(
        2,
        42.858184,
        -0.288841,
        8,
        44::numeric(12,2),
        'Refuge De Larribet',
        '65400 Arrens, Marsous, Hautes-Pyrénées, France',
        'Bonavita Guidotti',
        'http://frizzy-blossom.it',
        295.432,
        '07:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Calogera_Gasparini94@libero.it',
        '+390794326038'
      );
    

      select public."insert_hut"(
        2,
        45.528058,
        6.826874,
        7,
        115::numeric(12,2),
        'Refuge Du Mont Pourri',
        '73210 Peisey Nancroix, Savoie, France',
        'Marta Bortot',
        'https://forked-bread.com',
        310.49,
        '03:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Lidio_Carrozzo@libero.it',
        '+390705472823'
      );
    

      select public."insert_hut"(
        2,
        46.352617,
        6.728366,
        3,
        137::numeric(12,2),
        'Refuge De La Dent D?Oche',
        '74500 Bernex, Haute-Savoie, France',
        'Stiriaco Santangelo',
        'https://huge-sink.com',
        314.018,
        '09:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Catena74@libero.it',
        '+393737894962'
      );
    

      select public."insert_hut"(
        2,
        46.65744386060457,
        8.484887206314735,
        5,
        38::numeric(12,2),
        'Bergseehütte SAC',
        'Uri, Switzerland',
        'Ausiliatrice Di Gaetano',
        'https://well-informed-suck.it',
        321.925,
        '01:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Rufino.Narcisi45@libero.it',
        '+393492770869'
      );
    

      select public."insert_hut"(
        2,
        46.041871727709726,
        7.607090658731477,
        8,
        141::numeric(12,2),
        'Bivouac au Col de la Dent Blanche CAS',
        'Wallis, Switzerland',
        'Eufemia Loreto',
        'https://corny-marble.org',
        315.174,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Filomeno96@yahoo.it',
        '+394079013402'
      );
    

      select public."insert_hut"(
        2,
        46.67615346411701,
        8.523676633711773,
        7,
        36::numeric(12,2),
        'Salbitschijenbiwak SAC',
        'Uri, Switzerland',
        'Diodata Tassi',
        'https://doting-swell.net',
        329.747,
        '04:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Tizio.Massari41@gmail.com',
        '+391435942977'
      );
    

      select public."insert_hut"(
        2,
        46.799699069999306,
        8.510404550227811,
        10,
        120::numeric(12,2),
        'Spannorthütte SAC',
        'Uri, Switzerland',
        'Dr. Taide Tallarico',
        'http://hospitable-mantel.net',
        320.754,
        '02:00:00'::time without time zone,
        '08:00:00'::time without time zone,
        'Isabella.Saladino@gmail.com',
        '+396697860802'
      );
    

      select public."insert_hut"(
        2,
        46.10093151222714,
        7.679429273266466,
        8,
        73::numeric(12,2),
        'Cabane Arpitettaz CAS',
        'Wallis, Switzerland',
        'Girolamo Casella',
        'http://royal-patentee.org',
        330.055,
        '07:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Nunzio.Caputo@libero.it',
        '+398968128847'
      );
    

      select public."insert_hut"(
        2,
        42.7635889,
        -0.633888,
        5,
        148::numeric(12,2),
        'Refugio De Lizara',
        '22730, Aragón, Spain',
        'Luminosa Adragna',
        'https://ecstatic-cord.net',
        327.477,
        '01:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Gumesindo10@gmail.com',
        '+397075957313'
      );
    

      select public."insert_hut"(
        2,
        42.0519443,
        0.655277777,
        2,
        55::numeric(12,2),
        'Albergue De Montfalcó',
        '22585 Tolva, Aragón, Spain',
        'Ing. Natalina Madonna',
        'http://reflecting-discharge.it',
        321.404,
        '09:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Luminosa_Giovinazzo@libero.it',
        '+390175881182'
      );
    

      select public."insert_hut"(
        2,
        37.130564098,
        -3.2974219322,
        9,
        101::numeric(12,2),
        'El Molonillo/Peña Partida',
        '18160 Güejar Sierra, Andalucía, Spain',
        'Ermete Stanzione',
        'https://decimal-spaghetti.net',
        327.836,
        '05:00:00'::time without time zone,
        '22:00:00'::time without time zone,
        'Angelo.Favero@hotmail.com',
        '+398551603718'
      );
    

      select public."insert_hut"(
        2,
        37.0324496057,
        -3.2722949982,
        9,
        146::numeric(12,2),
        'La Campiñuela',
        '18417 Trévelez, Andalucía, Spain',
        'Elisabetta Luise',
        'https://hideous-tie.com',
        330.652,
        '01:00:00'::time without time zone,
        '11:00:00'::time without time zone,
        'Lucia.Drago@yahoo.com',
        '+397260148149'
      );
    

      select public."insert_hut"(
        2,
        41.9922222,
        20.7977778,
        9,
        103::numeric(12,2),
        'Titov Vrv',
        'Tetovo, Municipality of Tetovo, North Macedonia',
        'Furseo Pastorino',
        'https://precious-sprinter.it',
        307.227,
        '01:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Geronimo_Ambrosio@yahoo.com',
        '+393762656650'
      );
    

      select public."insert_hut"(
        2,
        42.477101,
        13.565406,
        2,
        108::numeric(12,2),
        'Rifugio Franchetti',
        'Pietracamela, Abruzzo, Italy',
        'Mia Fornara',
        'http://firsthand-rabbit.com',
        265.227,
        '02:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Casilda69@yahoo.it',
        '+392749322646'
      );
    

      select public."insert_hut"(
        2,
        46.1340176,
        12.4897278,
        6,
        92::numeric(12,2),
        'Rifugio Semenza',
        'Tambre, Veneto, Italy',
        'Sergio Siracusa',
        'https://tubby-code.com',
        296.836,
        '04:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Isotta_Lari@hotmail.com',
        '+391793640252'
      );
    

      select public."insert_hut"(
        2,
        45.8639164,
        7.9094408,
        10,
        39::numeric(12,2),
        'Rifugio Città di Mortara ',
        'Alagna Valsesia, Piemonte, Italy',
        'Melania Laezza',
        'https://conventional-nylon.net',
        317.902,
        '05:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Ermelinda.Pardini@libero.it',
        '+392290719699'
      );
    

      select public."insert_hut"(
        2,
        46.0949199,
        8.0705384,
        3,
        61::numeric(12,2),
        'Rifugio Andolla',
        'Antrona Schieranico, Piemonte, Italy',
        'Giuliano Salemme',
        'https://solid-subconscious.net',
        336.484,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Unna.Violante92@yahoo.com',
        '+392671020001'
      );
    

      select public."insert_hut"(
        2,
        43.992995,
        10.335787,
        6,
        77::numeric(12,2),
        'Rifugio Forte dei Marmi',
        'Stazzema, Toscana, Italy',
        'Loredana Conti',
        'http://prestigious-sweat.org',
        324.116,
        '08:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Romualdo_DAlessandro@hotmail.com',
        '+392242655784'
      );
    

      select public."insert_hut"(
        2,
        46.6309114,
        12.405783,
        7,
        118::numeric(12,2),
        'Rifugio Berti',
        'Comelico Superiore, Veneto, Italy',
        'Dr. Gigliola Vuillermoz',
        'http://chubby-pressure.it',
        271.367,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Remo_Gruppuso57@libero.it',
        '+394889647053'
      );
    

      select public."insert_hut"(
        2,
        45.6194408,
        13.8658619,
        9,
        146::numeric(12,2),
        'Rifugio Premuda',
        'San Dorligo della Valle, Friuli Venezia Giulia, Italy',
        'Dott. Crescenzia Terlizzi',
        'https://adept-larva.com',
        266.488,
        '06:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Donatella_Gioacchini@yahoo.it',
        '+396824507180'
      );
    

      select public."insert_hut"(
        2,
        45.938472,
        9.38147,
        2,
        97::numeric(12,2),
        'Rifugio Elisa',
        'Mandello del Lario, Lombardia, Italy',
        'Ido Monaci',
        'http://purple-chalet.com',
        310.861,
        '03:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Siriano42@libero.it',
        '+398876141139'
      );
    

      select public."insert_hut"(
        2,
        45.9663,
        7.92495,
        4,
        107::numeric(12,2),
        'Rifugio CAI Saronno',
        'Macugnaga, Piemonte, Italy',
        'Alcina Marcon',
        'https://musty-creation.org',
        326.844,
        '07:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Ricario39@hotmail.com',
        '+398470509116'
      );
    

      select public."insert_hut"(
        2,
        46.69446,
        11.2393,
        4,
        84::numeric(12,2),
        'Rifugio Picco Ivigna',
        'Scena, Trentino Alto Adige, Italy',
        'Dott. Filomena Egger',
        'https://forceful-commotion.org',
        275.777,
        '03:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Assunto.Viviani@email.it',
        '+397692555345'
      );
    

      select public."insert_hut"(
        2,
        45.08189,
        7.14006,
        4,
        124::numeric(12,2),
        'Rifugio Toesca',
        'Bussoleno, Piemonte, Italy',
        'Gaudino Mollica',
        'http://proper-position.org',
        332.265,
        '05:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Federico30@gmail.com',
        '+394271887222'
      );
    

      select public."insert_hut"(
        2,
        46.09643,
        8.43915,
        6,
        44::numeric(12,2),
        'Rifugio Al Cedo',
        'Santa Maria Maggiore, Piemonte, Italy',
        'Mina Donati',
        'http://wee-vegetable.org',
        276.469,
        '01:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Samanta10@hotmail.com',
        '+390339125135'
      );
    

      select public."insert_hut"(
        2,
        45.8996957,
        7.8496773,
        2,
        114::numeric(12,2),
        'Capanna Gnifetti',
        'Gressoney La Trinitè, Valle d?Aosta, Italy',
        'Davino Palla',
        'http://full-fairy.com',
        294.582,
        '07:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Tesifonte39@yahoo.com',
        '+394438933021'
      );
    

      select public."insert_hut"(
        2,
        45.969544,
        7.561394,
        4,
        118::numeric(12,2),
        'Rifugio Aosta',
        'Bionaz, Valle d?Aosta, Italy',
        'Gottardo Mottola',
        'https://agreeable-glider.net',
        299.13,
        '06:00:00'::time without time zone,
        '12:00:00'::time without time zone,
        'Novella75@gmail.com',
        '+398353508568'
      );
    

      select public."insert_hut"(
        2,
        46.4368329,
        10.6661616,
        9,
        89::numeric(12,2),
        'Rifugio Cevedale',
        'Pejo, Trentino Alto Adige, Italy',
        'Amata Palombo',
        'https://lavish-stonework.org',
        285.554,
        '08:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Crispino_Toti85@gmail.com',
        '+391351697958'
      );
    

      select public."insert_hut"(
        2,
        46.251306,
        9.722722,
        7,
        71::numeric(12,2),
        'Rifugio Ponti',
        'Val Masino, Lombardia, Italy',
        'Adriana De Bonis',
        'https://vigorous-charm.it',
        298.842,
        '09:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Maggiorino.Spizzirri@yahoo.com',
        '+399610853178'
      );
    

      select public."insert_hut"(
        2,
        46.1506151,
        10.8473057,
        3,
        49::numeric(12,2),
        'Rifugio XII Apostoli',
        'Stenico, Trentino Alto Adige, Italy',
        'Aldo Musella',
        'https://slight-schnitzel.it',
        265.666,
        '08:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Osvaldo93@yahoo.it',
        '+397810636255'
      );
    

      select public."insert_hut"(
        2,
        45.767012,
        6.837412,
        8,
        106::numeric(12,2),
        'Rifugio Elisabetta Soldini',
        'Courmayeur, Valle d?Aosta, Italy',
        'Atanasia Briano',
        'http://direct-canopy.net',
        270.8,
        '04:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Venusta_Valente51@hotmail.com',
        '+391111777904'
      );
    

      select public."insert_hut"(
        2,
        46.243461804471,
        10.655277862427,
        5,
        53::numeric(12,2),
        'Rifugio Denza',
        'Vermiglio, Trentino Alto Adige, Italy',
        'Asella Di Battista',
        'https://old-fashioned-citrus.it',
        277.237,
        '06:00:00'::time without time zone,
        '13:00:00'::time without time zone,
        'Matteo23@yahoo.com',
        '+390447697886'
      );
    

      select public."insert_hut"(
        2,
        42.11983,
        13.48659,
        8,
        59::numeric(12,2),
        'Rifugio Fonte Tavoloni ',
        'Ovindoli, Abruzzo, Italy',
        'Dott. Dino Melis',
        'https://knotty-mass.com',
        269.244,
        '01:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Agenore92@hotmail.com',
        '+396754628213'
      );
    

      select public."insert_hut"(
        2,
        46.615189,
        12.373643,
        8,
        126::numeric(12,2),
        'Rifugio Carducci',
        'Auronzo di Cadore, Veneto, Italy',
        'Sinesio Di Maio',
        'http://arctic-designer.net',
        307.491,
        '07:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Vera_Leoncini@email.it',
        '+396868243719'
      );
    

      select public."insert_hut"(
        2,
        46.03615,
        11.1539774,
        8,
        123::numeric(12,2),
        'Rifugio Bindesi',
        'Trento, Trentino Alto Adige, Italy',
        'Dr. Lorella Fiorentini',
        'https://weepy-landscape.net',
        312.878,
        '06:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Romola54@hotmail.com',
        '+394391258278'
      );
    

      select public."insert_hut"(
        2,
        44.7047951,
        14.8974475,
        2,
        103::numeric(12,2),
        'Mountain hut Miroslav Hirtz',
        '53287 Jablanac, Ličko-senjska županija, Croatia',
        'Angelica Mazzeo',
        'https://pitiful-holiday.org',
        338.918,
        '04:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Cosma.Campisi83@yahoo.it',
        '+396520604759'
      );
    

      select public."insert_hut"(
        2,
        46.16638781,
        14.1053309,
        2,
        96::numeric(12,2),
        'Koca na Blegošu',
        '4224 Gorenja vas, Slovenia',
        'Samuele Ferroni',
        'https://parallel-relay.net',
        268.16,
        '08:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Gervasio75@yahoo.it',
        '+399251589420'
      );
    

      select public."insert_hut"(
        2,
        50.702222,
        7.936667,
        8,
        76::numeric(12,2),
        'Wittener Hütte',
        'Germany',
        'Diogene Bongiorno',
        'http://milky-envelope.com',
        309.054,
        '08:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Michelangelo71@hotmail.com',
        '+397282208994'
      );
    

      select public."insert_hut"(
        2,
        46.825,
        10.833889,
        4,
        111::numeric(12,2),
        'Hochjoch-Hospiz',
        'Austria',
        'Valeria Lupo',
        'http://handy-food.com',
        339.215,
        '02:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Esmeralda.Ferrigno65@yahoo.com',
        '+397938098927'
      );
    

      select public."insert_hut"(
        2,
        47.4125,
        11.128889,
        6,
        59::numeric(12,2),
        'Meilerhütte',
        'Germany',
        'Concetta Palazzo',
        'https://close-causal.net',
        296.026,
        '06:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Loreno46@hotmail.com',
        '+396099512753'
      );
    

      select public."insert_hut"(
        2,
        47.549167,
        12.324444,
        3,
        70::numeric(12,2),
        'Gaudeamushütte',
        'Austria',
        'Angelo Pianese',
        'http://perky-strategy.it',
        294.313,
        '03:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Vissia24@hotmail.com',
        '+398666015931'
      );
    

      select public."insert_hut"(
        2,
        50.724167,
        6.396667,
        2,
        45::numeric(12,2),
        'Rheydter Hütte',
        'Germany',
        'Gabriele Addari',
        'http://soupy-thunderstorm.org',
        314.963,
        '08:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Solange_Simula@libero.it',
        '+397829524050'
      );
    

      select public."insert_hut"(
        2,
        50.909558,
        14.1693768,
        6,
        53::numeric(12,2),
        'Sektionshütte Krippen',
        'Germany',
        'Oronzo Botta',
        'https://treasured-gazelle.org',
        318.222,
        '07:00:00'::time without time zone,
        '21:00:00'::time without time zone,
        'Miriam_Gran@yahoo.com',
        '+390640222012'
      );
    

      select public."insert_hut"(
        2,
        47.27406417875082,
        14.14870922307915,
        3,
        147::numeric(12,2),
        'Neunkirchner Hütte',
        '2620 Neunkirchen, Steiermark, Austria',
        'Ilda Dominici',
        'https://ultimate-bucket.com',
        280.688,
        '08:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Doda.Masi@yahoo.it',
        '+394623480174'
      );
    

      select public."insert_hut"(
        2,
        42.346944,
        -0.72694444,
        6,
        92::numeric(12,2),
        'Refugio De Riglos',
        '22808, Aragón, Spain',
        'Generoso Cerri',
        'http://queasy-living.com',
        271.773,
        '09:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Rodrigo_Fedele@email.it',
        '+399088016469'
      );
    

      select public."insert_hut"(
        2,
        46.6765109341139,
        8.551916250870516,
        9,
        91::numeric(12,2),
        'Salbithütte SAC',
        'Uri, Switzerland',
        'Liberato Cusumano',
        'https://acidic-tablecloth.net',
        335.55,
        '08:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Sabrina98@email.it',
        '+392255035440'
      );
    

      select public."insert_hut"(
        2,
        46.52193789413235,
        8.114641838745735,
        5,
        63::numeric(12,2),
        'Finsteraarhornhütte SAC',
        'Wallis, Switzerland',
        'Mimma De Maria',
        'https://filthy-microlending.net',
        317.103,
        '07:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Neri_Simula16@yahoo.it',
        '+394189869410'
      );
    

      select public."insert_hut"(
        2,
        45.98981696109553,
        7.475686527264285,
        8,
        65::numeric(12,2),
        'Cabane des Vignettes CAS',
        'Wallis, Switzerland',
        'Natalia Ciani',
        'http://cooked-phenomenon.org',
        339.515,
        '04:00:00'::time without time zone,
        '18:00:00'::time without time zone,
        'Esuperio_Federico23@hotmail.com',
        '+396157884131'
      );
    

      select public."insert_hut"(
        2,
        46.62508197123312,
        8.096710560658677,
        9,
        82::numeric(12,2),
        'Glecksteinhütte SAC',
        'Bern, Switzerland',
        'Ing. Nerea Matranga',
        'http://outlying-forever.net',
        287.589,
        '03:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Nino_Benetti@hotmail.com',
        '+395374586457'
      );
    

      select public."insert_hut"(
        2,
        46.5415605435116,
        9.041742216466199,
        3,
        35::numeric(12,2),
        'Länta-Hütte SAC',
        'Graubünden, Switzerland',
        'Cristiana Iandolo',
        'https://naughty-spandex.it',
        301.161,
        '04:00:00'::time without time zone,
        '20:00:00'::time without time zone,
        'Tibaldo.Parise80@libero.it',
        '+394419292649'
      );
    

      select public."insert_hut"(
        2,
        46.26075088313105,
        8.080375518495808,
        3,
        36::numeric(12,2),
        'Monte-Leone-Hütte SAC',
        'Wallis, Switzerland',
        'Barbarigo Gemma',
        'https://musty-precipitation.org',
        310.534,
        '02:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Antimo.Borrelli41@email.it',
        '+395044474619'
      );
    

      select public."insert_hut"(
        2,
        46.86578812972504,
        9.380812884831963,
        8,
        74::numeric(12,2),
        'Ringelspitzhütte SAC',
        'Graubünden, Switzerland',
        'Sig. Bassilla Perrone',
        'https://green-orange.org',
        325.202,
        '05:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Bonaventura.Mingarelli78@gmail.com',
        '+399720338324'
      );
    

      select public."insert_hut"(
        2,
        44.12756,
        20.01536,
        5,
        75::numeric(12,2),
        'Na poljanama Maljen',
        'Maljen, Serbia',
        'Gelsomina Terlizzi',
        'http://knowledgeable-inflation.com',
        272.521,
        '06:00:00'::time without time zone,
        '23:00:00'::time without time zone,
        'Aresio.Masi@yahoo.com',
        '+398168558462'
      );
    

      select public."insert_hut"(
        2,
        44.13528,
        20.19206,
        7,
        72::numeric(12,2),
        'Dobra voda',
        'Suvobor, Serbia',
        'Dino Lori',
        'http://glum-spelt.com',
        326.221,
        '01:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Palladia8@libero.it',
        '+394574806982'
      );
    

      select public."insert_hut"(
        2,
        45.55308,
        15.49972,
        7,
        35::numeric(12,2),
        'Ivanova hiža',
        'Karlovac town environment, Karlovačka, Croatia',
        'Dr. Roberto D''Ambrosio',
        'https://great-snail.net',
        279.68,
        '08:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Armida.Gianni79@hotmail.com',
        '+394502272648'
      );
    

      select public."insert_hut"(
        2,
        45.84251,
        15.87595,
        2,
        145::numeric(12,2),
        'Glavica',
        'Medvednica, City of Zagreb, Croatia',
        'Beniamino Pagliuca',
        'http://elderly-priority.net',
        300.446,
        '05:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Loriana.Iacono@hotmail.com',
        '+394888782984'
      );
    

      select public."insert_hut"(
        2,
        43.47817,
        16.72181,
        4,
        50::numeric(12,2),
        'Trpošnjik',
        'Mosor, Splitsko-dalmatinska, Croatia',
        'Deodato Concas',
        'https://granular-downstairs.org',
        291.25,
        '02:00:00'::time without time zone,
        '10:00:00'::time without time zone,
        'Eliana34@yahoo.com',
        '+398320747305'
      );
    

      select public."insert_hut"(
        2,
        45.29441,
        14.78715,
        9,
        100::numeric(12,2),
        'Bitorajka',
        'Bitoraj, Primorsko-goranska, Croatia',
        'Generosa Gervasi',
        'https://dutiful-mochi.org',
        292.296,
        '09:00:00'::time without time zone,
        '19:00:00'::time without time zone,
        'Graciliano_Stanzione@yahoo.com',
        '+394780173483'
      );
    

      select public."insert_hut"(
        2,
        44.06783,
        16.37506,
        5,
        69::numeric(12,2),
        'Zlatko Prgin',
        'Dinara, Šibensko-kninska, Croatia',
        'Stanislao Celentano',
        'http://moral-bran.net',
        329.264,
        '06:00:00'::time without time zone,
        '16:00:00'::time without time zone,
        'Dante_Serena38@yahoo.com',
        '+394286106864'
      );
    

      select public."insert_hut"(
        2,
        44.5325,
        15.14343,
        8,
        117::numeric(12,2),
        'Prpa',
        'Velebit, Ličko-senjska, Croatia',
        'Gilda Sorce',
        'http://interesting-week.com',
        331.719,
        '04:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Filomena52@yahoo.com',
        '+396460454011'
      );
    

      select public."insert_hut"(
        2,
        44.48355,
        15.18101,
        6,
        68::numeric(12,2),
        'Ždrilo',
        'Velebit, Ličko-senjska, Croatia',
        'Erico Caiazza',
        'https://extroverted-vet.net',
        271.179,
        '04:00:00'::time without time zone,
        '17:00:00'::time without time zone,
        'Tizio_Olivi60@email.it',
        '+395755897991'
      );
    

      select public."insert_hut"(
        2,
        45.21844,
        14.97803,
        10,
        119::numeric(12,2),
        'Miroslav Hirtz',
        'Velika Kapela, Primorsko-goranska, Croatia',
        'Severa Marinucci',
        'https://ajar-noodle.org',
        315.721,
        '06:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Zaira.Taormina28@yahoo.com',
        '+396471445709'
      );
    

      select public."insert_hut"(
        2,
        45.5047,
        17.67233,
        4,
        72::numeric(12,2),
        'Jezerce',
        'Papuk, Požeško-slavonska, Croatia',
        'Proserpina Vella',
        'https://enchanted-table.net',
        302.964,
        '01:00:00'::time without time zone,
        '14:00:00'::time without time zone,
        'Egizia.DiLiberto@libero.it',
        '+398567479505'
      );
    

      select public."insert_hut"(
        2,
        45.77134,
        15.65035,
        5,
        86::numeric(12,2),
        'Ivica Sudnik',
        'Samoborska gora, Zagrebačka, Croatia',
        'Sig. Quinziano Cara',
        'http://amazing-practitioner.org',
        301.093,
        '02:00:00'::time without time zone,
        '15:00:00'::time without time zone,
        'Rufino81@yahoo.com',
        '+390507867407'
      );
    
  

    CREATE OR REPLACE FUNCTION public.insert_parking_lot(
        user_id integer,
        lat double precision,
        lon double precision,
        name varchar,
        max_cars integer,
        address varchar,
        city varchar,
        country varchar,
        region varchar,
        province varchar
    )  RETURNS VOID AS
    $func$
    DECLARE
      point_id integer;
    BEGIN
    insert into public.points (
      "type", "position", "name", "address"
    ) values (
      0,
      public.ST_SetSRID(public.ST_MakePoint(lon, lat), 4326),
      '',
      address
    ) returning id into point_id;

    INSERT INTO "public"."parking_lots" (
      "userId",
      "pointId",
      "maxCars",
      "country",
      "region",
      "province",
      "city"
    ) VALUES (
      user_id,
      point_id,
      max_cars,
      country,
      region,
      province,
      city
    );
    END
    $func$ LANGUAGE plpgsql;

    
      select public."insert_parking_lot"(
        2,
        44.1423756,
        12.2451958,
        'Silos Piazza Franchini Angeloni',
        72,
        '1 Strada Furseo, Ofelia laziale, Italy',
        'Ofelia laziale',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8431110,
        9.6875555,
        NULL,
        65,
        '901 Contrada Clarenzio, Sesto Amina, Italy',
        'Sesto Amina',
        'Italy',
        'Varese',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3271093,
        12.3327922,
        NULL,
        278,
        '1 Strada Calogera, Enrico terme, Italy',
        'Enrico terme',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9142959,
        11.0093394,
        NULL,
        99,
        '1 Via Spagnolo, Borgo Natalia, Italy',
        'Borgo Natalia',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4244634,
        8.8439477,
        NULL,
        29,
        '9 Rotonda Scarano, San Dino sardo, Italy',
        'San Dino sardo',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8183149,
        10.0682218,
        NULL,
        47,
        '4 Rotonda Noto, Landi salentino, Italy',
        'Landi salentino',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3515921,
        11.7163630,
        NULL,
        191,
        '655 Rotonda Natale, Elifio calabro, Italy',
        'Elifio calabro',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3758101,
        9.7792518,
        NULL,
        149,
        '3 Rotonda Maggio, Fumagalli nell''emilia, Italy',
        'Fumagalli nell''emilia',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3110451,
        10.7312029,
        NULL,
        281,
        '635 Incrocio Palombi, Scrofani calabro, Italy',
        'Scrofani calabro',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7755517,
        13.6384333,
        NULL,
        56,
        '362 Piazza Ermete, Borgo Nilde del friuli, Italy',
        'Borgo Nilde del friuli',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0889357,
        10.8863487,
        NULL,
        297,
        '691 Via Valente, Settimio terme, Italy',
        'Settimio terme',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8763663,
        13.3523055,
        NULL,
        39,
        '4 Rotonda Gandolfo, Sesto Adelasia, Italy',
        'Sesto Adelasia',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.0620402,
        12.4503249,
        NULL,
        272,
        '4 Via Silvano, Settimo Loretta, Italy',
        'Settimo Loretta',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3090105,
        11.6908066,
        NULL,
        158,
        '4 Contrada Giuliana, Cerrani laziale, Italy',
        'Cerrani laziale',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3792387,
        9.2184446,
        NULL,
        126,
        '311 Via Ponziano, Settimo Abramo, Italy',
        'Settimo Abramo',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5775702,
        13.7352727,
        NULL,
        77,
        '2 Contrada Distefano, Borgo Giona umbro, Italy',
        'Borgo Giona umbro',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6120165,
        12.5453378,
        NULL,
        273,
        '4 Incrocio Smeralda, Sesto Scolastica veneto, Italy',
        'Sesto Scolastica veneto',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3439648,
        9.1706476,
        NULL,
        188,
        '065 Strada Archippo, Sesto Valter terme, Italy',
        'Sesto Valter terme',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4437158,
        8.6644359,
        NULL,
        294,
        '0 Piazza Magno, Quarto Adina, Italy',
        'Quarto Adina',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8033192,
        10.7394273,
        NULL,
        248,
        '02 Strada Serafina, Ultimo calabro, Italy',
        'Ultimo calabro',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.5289560,
        11.4035997,
        NULL,
        234,
        '474 Rotonda Piazzolla, Maggi terme, Italy',
        'Maggi terme',
        'Italy',
        'Carbonia-Iglesias',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7582861,
        11.1767165,
        NULL,
        212,
        '15 Contrada Acrisio, Settimo Norberto, Italy',
        'Settimo Norberto',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4778879,
        8.5955775,
        NULL,
        6,
        '5 Via Nardi, Settimo Diodata, Italy',
        'Settimo Diodata',
        'Italy',
        'L''Aquila',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7271691,
        10.8088829,
        NULL,
        298,
        '9 Strada Postumio, San Viliana laziale, Italy',
        'San Viliana laziale',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1456720,
        12.2201624,
        NULL,
        25,
        '927 Strada Irma, Settimo Regina, Italy',
        'Settimo Regina',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0663402,
        11.1752150,
        NULL,
        137,
        '12 Contrada Demontis, Cingolani umbro, Italy',
        'Cingolani umbro',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0030596,
        11.9595810,
        'P&R',
        83,
        '9 Incrocio Bastiano, San Alano del friuli, Italy',
        'San Alano del friuli',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9704991,
        8.4153647,
        NULL,
        164,
        '47 Borgo Tiziano, Borgo Elisabetta salentino, Italy',
        'Borgo Elisabetta salentino',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4399611,
        11.8364384,
        NULL,
        124,
        '539 Piazza Carlino, Quarto Ruperto salentino, Italy',
        'Quarto Ruperto salentino',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7919805,
        9.4171271,
        'Parcheggio',
        284,
        '34 Via Sardella, Di Blasi umbro, Italy',
        'Di Blasi umbro',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6571839,
        13.7820079,
        NULL,
        90,
        '6 Strada Padula, San Filomena, Italy',
        'San Filomena',
        'Italy',
        'Crotone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2368248,
        11.0527462,
        NULL,
        150,
        '942 Contrada Visconti, Borgo Beltramo, Italy',
        'Borgo Beltramo',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4607455,
        11.7474894,
        NULL,
        226,
        '6 Contrada Pintus, Borgo Gianpietro a mare, Italy',
        'Borgo Gianpietro a mare',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8074430,
        7.6213110,
        'Parcheggio del Cimitero',
        5,
        '4 Via Ausiliatrice, Margiotta del friuli, Italy',
        'Margiotta del friuli',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8527239,
        13.4111705,
        NULL,
        292,
        '36 Rotonda Mazzoleno, Vitalico veneto, Italy',
        'Vitalico veneto',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5939199,
        9.2212250,
        NULL,
        75,
        '998 Incrocio Di Girolamo, San Abramio del friuli, Italy',
        'San Abramio del friuli',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1070536,
        9.2530754,
        NULL,
        176,
        '017 Borgo Loddo, San Cora, Italy',
        'San Cora',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2107439,
        11.0908126,
        NULL,
        157,
        '75 Rotonda D''Errico, Poggi nell''emilia, Italy',
        'Poggi nell''emilia',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5842174,
        11.8630998,
        NULL,
        141,
        '4 Via Felici, Balducci terme, Italy',
        'Balducci terme',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8706443,
        7.6149738,
        NULL,
        83,
        '7 Piazza Mario, Caiazzo laziale, Italy',
        'Caiazzo laziale',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7336313,
        9.9639621,
        NULL,
        20,
        '738 Via Elena, Velio a mare, Italy',
        'Velio a mare',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6029010,
        10.5843520,
        NULL,
        128,
        '199 Borgo Bosco, Quarto Agnese salentino, Italy',
        'Quarto Agnese salentino',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.6826109,
        10.5981135,
        NULL,
        58,
        '601 Contrada Teodoro, Pellegrino sardo, Italy',
        'Pellegrino sardo',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7356411,
        12.2358400,
        'Park Cimitero',
        282,
        '30 Incrocio Pietro, Gatto veneto, Italy',
        'Gatto veneto',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4431887,
        10.2348590,
        NULL,
        51,
        '353 Rotonda Turchi, Pardo ligure, Italy',
        'Pardo ligure',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0686936,
        11.1171138,
        NULL,
        25,
        '71 Piazza Polidoro, Settimo Onofrio, Italy',
        'Settimo Onofrio',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3067007,
        14.2066870,
        NULL,
        141,
        '385 Via Falzone, Settimo Liboria a mare, Italy',
        'Settimo Liboria a mare',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5797766,
        11.3922297,
        'Piazza Salvo D''Acquisto',
        161,
        '6 Borgo Vitale, Borgo Taziano, Italy',
        'Borgo Taziano',
        'Italy',
        'Caserta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7936170,
        12.6836181,
        NULL,
        165,
        '5 Piazza Goffredo, Gustavo lido, Italy',
        'Gustavo lido',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7401303,
        9.7094090,
        NULL,
        30,
        '4 Strada Tristano, Settimo Ulstano, Italy',
        'Settimo Ulstano',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5129372,
        11.4637584,
        NULL,
        29,
        '564 Strada Galeazzi, Settimo Paciano, Italy',
        'Settimo Paciano',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3985629,
        11.6659826,
        NULL,
        11,
        '303 Incrocio Rosmunda, Raffaele calabro, Italy',
        'Raffaele calabro',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.5825798,
        10.6779509,
        NULL,
        241,
        '20 Incrocio Visconti, Quirino umbro, Italy',
        'Quirino umbro',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3781022,
        11.7066601,
        NULL,
        8,
        '008 Contrada Ferraro, Bassiano umbro, Italy',
        'Bassiano umbro',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6563361,
        7.7000251,
        NULL,
        36,
        '94 Piazza Talarico, Achille a mare, Italy',
        'Achille a mare',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7923370,
        12.1671470,
        NULL,
        188,
        '92 Rotonda Diana, Quarto Ermenegarda, Italy',
        'Quarto Ermenegarda',
        'Italy',
        'Trento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8625775,
        7.7304001,
        NULL,
        181,
        '384 Contrada Editta, Settimo Giorgio nell''emilia, Italy',
        'Settimo Giorgio nell''emilia',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2284297,
        11.3088398,
        NULL,
        247,
        '0 Incrocio Fuscolo, Marciano a mare, Italy',
        'Marciano a mare',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8668062,
        9.9969060,
        NULL,
        174,
        '2 Strada Candida, Piva salentino, Italy',
        'Piva salentino',
        'Italy',
        'Livorno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8445106,
        7.7340914,
        NULL,
        152,
        '417 Via Zumbo, Casilda lido, Italy',
        'Casilda lido',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3879724,
        12.0523266,
        'Park Impianti Sportivi',
        123,
        '6 Strada Reale, Quarto Benigna, Italy',
        'Quarto Benigna',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.6918968,
        11.8160591,
        NULL,
        73,
        '0 Via Di Fiore, Settimo Ermenegarda ligure, Italy',
        'Settimo Ermenegarda ligure',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7252487,
        11.4570941,
        NULL,
        181,
        '867 Piazza Cesare, Borgo Menardo, Italy',
        'Borgo Menardo',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9279435,
        13.8045643,
        NULL,
        260,
        '7 Borgo Loretta, Polidori terme, Italy',
        'Polidori terme',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7360475,
        11.3885498,
        NULL,
        165,
        '12 Borgo Caino, Andrea nell''emilia, Italy',
        'Andrea nell''emilia',
        'Italy',
        'Oristano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4163065,
        11.8725525,
        NULL,
        94,
        '984 Strada Gianluca, Quarto Lucrezia, Italy',
        'Quarto Lucrezia',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7611166,
        12.6141884,
        NULL,
        164,
        '869 Borgo Paride, San Flaminia, Italy',
        'San Flaminia',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3980568,
        11.4817464,
        'Park Cimitero',
        48,
        '58 Via Pozzo, San Degna, Italy',
        'San Degna',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7572293,
        11.9829740,
        NULL,
        30,
        '14 Piazza Gioia, Borgo Marinetta calabro, Italy',
        'Borgo Marinetta calabro',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8000860,
        12.9949073,
        NULL,
        15,
        '6 Borgo Leonida, Loreno salentino, Italy',
        'Loreno salentino',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9545699,
        8.5706982,
        NULL,
        25,
        '28 Rotonda Lara, Valter calabro, Italy',
        'Valter calabro',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8313831,
        12.0043600,
        NULL,
        257,
        '128 Incrocio Edda, Sesto Aurelia umbro, Italy',
        'Sesto Aurelia umbro',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6610270,
        11.4078331,
        NULL,
        124,
        '60 Rotonda Di Marino, Criscenti nell''emilia, Italy',
        'Criscenti nell''emilia',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8068092,
        8.4399891,
        NULL,
        30,
        '65 Piazza Patriarca, San Rubiano, Italy',
        'San Rubiano',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7264798,
        11.6847982,
        NULL,
        252,
        '9 Contrada Dianora, Borgo Manuela, Italy',
        'Borgo Manuela',
        'Italy',
        'Brindisi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.7166016,
        10.2298747,
        NULL,
        204,
        '18 Rotonda Sigismondo, Annabella calabro, Italy',
        'Annabella calabro',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3061285,
        9.4028376,
        NULL,
        103,
        '636 Borgo Pasqua, Sesto Gioacchina sardo, Italy',
        'Sesto Gioacchina sardo',
        'Italy',
        'Forlì-Cesena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4841777,
        7.9314202,
        NULL,
        214,
        '86 Strada Menna, Borgo Amina, Italy',
        'Borgo Amina',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3849966,
        10.4762272,
        NULL,
        111,
        '746 Via Cinzia, Albino nell''emilia, Italy',
        'Albino nell''emilia',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.7079880,
        8.5530513,
        NULL,
        179,
        '6 Via Gondulfo, Borgo Damaso veneto, Italy',
        'Borgo Damaso veneto',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8826871,
        8.0662134,
        NULL,
        113,
        '633 Rotonda Cataldo, Borgo Vittore, Italy',
        'Borgo Vittore',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7320119,
        11.8576332,
        NULL,
        260,
        '20 Incrocio Crespi, Castagna ligure, Italy',
        'Castagna ligure',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6285676,
        7.9776563,
        NULL,
        269,
        '83 Borgo Beniamina, Quarto Pollione terme, Italy',
        'Quarto Pollione terme',
        'Italy',
        'Rovigo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0732968,
        12.5542211,
        NULL,
        99,
        '795 Rotonda Aprile, Correale a mare, Italy',
        'Correale a mare',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8203659,
        8.2501729,
        NULL,
        52,
        '48 Rotonda Passuello, San Evelina, Italy',
        'San Evelina',
        'Italy',
        'Vicenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5975758,
        9.7576377,
        NULL,
        227,
        '1 Piazza Azeglio, Zabedeo del friuli, Italy',
        'Zabedeo del friuli',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.5420319,
        8.8441763,
        NULL,
        233,
        '8 Piazza Divo, Demurtas lido, Italy',
        'Demurtas lido',
        'Italy',
        'Chieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6966129,
        12.2505958,
        NULL,
        240,
        '46 Rotonda Lidania, Immacolata a mare, Italy',
        'Immacolata a mare',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7144471,
        9.3193784,
        NULL,
        180,
        '2 Strada Vitalico, Sesto Siro laziale, Italy',
        'Sesto Siro laziale',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7411737,
        10.7014337,
        NULL,
        47,
        '6 Contrada Esmeralda, Elettra sardo, Italy',
        'Elettra sardo',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8076481,
        12.2377058,
        NULL,
        175,
        '998 Contrada Pastorino, Borgo Mirella, Italy',
        'Borgo Mirella',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8679814,
        11.5070368,
        NULL,
        40,
        '783 Incrocio Sabatini, Roberti ligure, Italy',
        'Roberti ligure',
        'Italy',
        'Bari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2538179,
        10.3030018,
        NULL,
        55,
        '91 Incrocio Privitera, Elsa salentino, Italy',
        'Elsa salentino',
        'Italy',
        'Teramo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2799069,
        7.8846458,
        NULL,
        92,
        '195 Contrada Nicoletta, Settimo Costante, Italy',
        'Settimo Costante',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5244389,
        10.8683381,
        NULL,
        235,
        '2 Via Savini, Borgo Edilberto a mare, Italy',
        'Borgo Edilberto a mare',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7924569,
        11.7561396,
        NULL,
        55,
        '744 Borgo Bianco, Quarto Gesualdo veneto, Italy',
        'Quarto Gesualdo veneto',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2079314,
        12.8819127,
        NULL,
        149,
        '7 Incrocio Ferrini, Cosma umbro, Italy',
        'Cosma umbro',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6418692,
        11.2955839,
        NULL,
        206,
        '26 Contrada Gianni, Tornatore terme, Italy',
        'Tornatore terme',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4600202,
        7.5639204,
        NULL,
        102,
        '322 Strada Costantino, Vittoriano veneto, Italy',
        'Vittoriano veneto',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1428189,
        12.0743783,
        NULL,
        53,
        '9 Borgo Bonaldo, Borgo Amanda ligure, Italy',
        'Borgo Amanda ligure',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8653882,
        12.4957968,
        'Garage Colombo',
        158,
        '120 Via Cristoforo Colombo, Roma, Italy',
        'Roma',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8965729,
        11.9858275,
        NULL,
        139,
        '5 Strada Clemente, Nicea laziale, Italy',
        'Nicea laziale',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.5214157,
        11.3433568,
        NULL,
        233,
        '96 Contrada Giacinta, San Giuda, Italy',
        'San Giuda',
        'Italy',
        'Pisa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0659568,
        8.2229348,
        NULL,
        186,
        '1 Via Ferdinando, De Cicco lido, Italy',
        'De Cicco lido',
        'Italy',
        'Rimini',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0576445,
        8.2640875,
        NULL,
        37,
        '08 Incrocio Alberico, Borgo Otilia, Italy',
        'Borgo Otilia',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7782420,
        11.8796834,
        NULL,
        69,
        '1 Strada Giandomenico, Sesto Delia sardo, Italy',
        'Sesto Delia sardo',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0160712,
        11.9044164,
        NULL,
        209,
        '28 Strada Sigfrido, Borgo Simona nell''emilia, Italy',
        'Borgo Simona nell''emilia',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.7662669,
        14.1921769,
        NULL,
        286,
        '414 Via Orlandi, Narseo calabro, Italy',
        'Narseo calabro',
        'Italy',
        'Treviso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.9287088,
        10.7414800,
        NULL,
        188,
        '438 Strada Menardo, Castiello sardo, Italy',
        'Castiello sardo',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4025801,
        11.3190177,
        NULL,
        55,
        '5 Contrada Castiglioni, Flaviana nell''emilia, Italy',
        'Flaviana nell''emilia',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5028751,
        12.3380867,
        'P1',
        180,
        '7 Contrada Baldassarre, Graziani a mare, Italy',
        'Graziani a mare',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7586503,
        7.7324307,
        NULL,
        104,
        '498 Rotonda Ermenegildo, Casimiro lido, Italy',
        'Casimiro lido',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7522991,
        12.3858388,
        NULL,
        179,
        '19 Via Di Luca, Cardella veneto, Italy',
        'Cardella veneto',
        'Italy',
        'Imperia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9432330,
        7.9312412,
        NULL,
        251,
        '39 Piazza Sarbello, Icaro umbro, Italy',
        'Icaro umbro',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1130488,
        11.5475948,
        NULL,
        98,
        '66 Borgo Privitera, Settimo Liberto, Italy',
        'Settimo Liberto',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7606735,
        7.8366190,
        NULL,
        265,
        '015 Via Chiacchio, Sesto Gineto calabro, Italy',
        'Sesto Gineto calabro',
        'Italy',
        'Ragusa',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4356937,
        11.6549128,
        NULL,
        135,
        '76 Rotonda Aronne, San Saturnino, Italy',
        'San Saturnino',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9458529,
        11.4835101,
        NULL,
        228,
        '553 Piazza Semprini, Sesto Cuzia, Italy',
        'Sesto Cuzia',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9354638,
        11.5474018,
        NULL,
        228,
        '55 Contrada Di Francesco, Borgo Sabele, Italy',
        'Borgo Sabele',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9083751,
        8.3871277,
        NULL,
        170,
        '72 Contrada Artemisa, Peroni nell''emilia, Italy',
        'Peroni nell''emilia',
        'Italy',
        'Cuneo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2756191,
        11.7243429,
        NULL,
        176,
        '53 Piazza Rollo, Virginio sardo, Italy',
        'Virginio sardo',
        'Italy',
        'Bergamo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3533431,
        13.8161570,
        NULL,
        47,
        '6 Via Elimena, Barbagallo ligure, Italy',
        'Barbagallo ligure',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9933341,
        10.7481899,
        NULL,
        234,
        '85 Borgo Di Biase, Sestito ligure, Italy',
        'Sestito ligure',
        'Italy',
        'Genova',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5215875,
        9.2164608,
        NULL,
        125,
        '515 Via Cioffi, Palla sardo, Italy',
        'Palla sardo',
        'Italy',
        'Cagliari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5006056,
        9.2475939,
        NULL,
        178,
        '692 Strada Casadei, Lodovica ligure, Italy',
        'Lodovica ligure',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6749547,
        7.6813475,
        NULL,
        42,
        '077 Strada Aniello, Cavallari calabro, Italy',
        'Cavallari calabro',
        'Italy',
        'Cremona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9085092,
        8.6226333,
        NULL,
        1,
        '8 Strada Fermo, Severa sardo, Italy',
        'Severa sardo',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7619189,
        11.6462814,
        NULL,
        291,
        '74 Strada Murru, San Enzo sardo, Italy',
        'San Enzo sardo',
        'Italy',
        'Asti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.2220248,
        9.2049717,
        NULL,
        215,
        '424 Borgo Lucarini, Damaso umbro, Italy',
        'Damaso umbro',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9136734,
        8.6270887,
        NULL,
        1,
        '277 Incrocio Procopio, Alcino ligure, Italy',
        'Alcino ligure',
        'Italy',
        'Ascoli Piceno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9119133,
        8.6275696,
        NULL,
        1,
        '4 Borgo Adele, San Rosita, Italy',
        'San Rosita',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2528369,
        14.5071245,
        NULL,
        29,
        '2 Strada Petrone, Pacini veneto, Italy',
        'Pacini veneto',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6758445,
        7.8587495,
        NULL,
        222,
        '701 Borgo Baldomero, Marcello terme, Italy',
        'Marcello terme',
        'Italy',
        'Bolzano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6435586,
        7.8576090,
        NULL,
        118,
        '1 Contrada Ernesto, Sesto Acilio, Italy',
        'Sesto Acilio',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3791488,
        11.6488305,
        NULL,
        158,
        '504 Borgo Fulberto, San Ottaviano, Italy',
        'San Ottaviano',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9535739,
        13.6613752,
        NULL,
        102,
        '41 Borgo Cola, Bonazzi calabro, Italy',
        'Bonazzi calabro',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8930377,
        8.6137113,
        NULL,
        1,
        '204 Incrocio Cosimo, Settimo Adalgiso, Italy',
        'Settimo Adalgiso',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8814450,
        8.6824661,
        NULL,
        1,
        '199 Borgo Iside, Sorbello del friuli, Italy',
        'Sorbello del friuli',
        'Italy',
        'Gorizia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6025882,
        7.7576598,
        NULL,
        43,
        '46 Piazza Bernasconi, Quarto Asimodeo, Italy',
        'Quarto Asimodeo',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9017178,
        8.6123014,
        NULL,
        1,
        '4 Strada Belmonte, Borgo Maida, Italy',
        'Borgo Maida',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9282616,
        12.2269962,
        NULL,
        100,
        '5 Borgo Artemisa, Settimo Raimondo, Italy',
        'Settimo Raimondo',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6686001,
        7.6887598,
        NULL,
        215,
        '87 Rotonda Lombardini, Contini nell''emilia, Italy',
        'Contini nell''emilia',
        'Italy',
        'Pavia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9712812,
        12.8293178,
        NULL,
        91,
        '19 Rotonda Plinio, Gamberini calabro, Italy',
        'Gamberini calabro',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9886550,
        7.7419501,
        NULL,
        29,
        '1 Borgo Pillitteri, Quarto Ovidio, Italy',
        'Quarto Ovidio',
        'Italy',
        'Savona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8189647,
        13.9222936,
        NULL,
        158,
        '0 Incrocio Gerino, Valentino terme, Italy',
        'Valentino terme',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6030667,
        7.7694507,
        NULL,
        240,
        '5 Borgo Trasea, Vitale calabro, Italy',
        'Vitale calabro',
        'Italy',
        'Pistoia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6918162,
        7.7116945,
        NULL,
        268,
        '8 Rotonda Pammachio, Ortensia ligure, Italy',
        'Ortensia ligure',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5930280,
        7.7978019,
        NULL,
        138,
        '433 Contrada Russo, Eufebio sardo, Italy',
        'Eufebio sardo',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9234286,
        10.8893521,
        NULL,
        241,
        '9 Strada Pession, Sesto Oderico laziale, Italy',
        'Sesto Oderico laziale',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6923426,
        7.6717227,
        NULL,
        60,
        '413 Incrocio Cavallini, Puccio umbro, Italy',
        'Puccio umbro',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7599298,
        7.7235456,
        NULL,
        261,
        '695 Via Bartolomei, Sesto Mimma, Italy',
        'Sesto Mimma',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2746191,
        11.5846612,
        NULL,
        174,
        '65 Rotonda Giorgia, Borgo Ludovico, Italy',
        'Borgo Ludovico',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8219746,
        7.6969230,
        NULL,
        211,
        '3 Piazza Angeli, Borgo Adone, Italy',
        'Borgo Adone',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2770680,
        11.5863998,
        NULL,
        102,
        '0 Contrada Bacci, Sesto Laurentino sardo, Italy',
        'Sesto Laurentino sardo',
        'Italy',
        'Roma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0533912,
        11.4549681,
        NULL,
        56,
        '522 Borgo Attilano, Quarto Gregorio calabro, Italy',
        'Quarto Gregorio calabro',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4625544,
        11.2812111,
        NULL,
        29,
        '3 Rotonda Quaranta, San Melania, Italy',
        'San Melania',
        'Italy',
        'Ogliastra',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1861724,
        12.0223128,
        NULL,
        184,
        '17 Via Rodiano, Sesto Galatea salentino, Italy',
        'Sesto Galatea salentino',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3088236,
        13.8574284,
        NULL,
        92,
        '9 Incrocio Giocondo, San Prudenzio, Italy',
        'San Prudenzio',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4522170,
        11.5104697,
        NULL,
        190,
        '4 Borgo Aimone, San Gigliola, Italy',
        'San Gigliola',
        'Italy',
        'Monza e della Brianza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4524043,
        9.1504773,
        'Autorimessa Leone',
        72,
        '914 Contrada Teresi, Settimo Pacomio lido, Italy',
        'Settimo Pacomio lido',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7448182,
        7.8483428,
        NULL,
        151,
        '9 Borgo Urdino, Cavallaro laziale, Italy',
        'Cavallaro laziale',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3848051,
        11.7310644,
        NULL,
        92,
        '093 Piazza Buccheri, Marrone veneto, Italy',
        'Marrone veneto',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0517009,
        9.2815042,
        NULL,
        296,
        '30 Strada Flaminia, Adalfredo laziale, Italy',
        'Adalfredo laziale',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0317696,
        11.4555902,
        NULL,
        292,
        '505 Contrada Motisi, Carriero nell''emilia, Italy',
        'Carriero nell''emilia',
        'Italy',
        'Taranto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.9902989,
        13.7589811,
        NULL,
        44,
        '0 Contrada Mottola, Spadafora terme, Italy',
        'Spadafora terme',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1094136,
        11.3010382,
        'Parcheggio Palestra Sant''Orsola',
        30,
        '3 Incrocio Ersilia, Lorena calabro, Italy',
        'Lorena calabro',
        'Italy',
        'Verbano-Cusio-Ossola',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0168090,
        9.1248912,
        NULL,
        124,
        '4 Incrocio Repetto, Settimo Agesilao, Italy',
        'Settimo Agesilao',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0670258,
        11.4997264,
        NULL,
        116,
        '5 Piazza Sabia, Tolomeo sardo, Italy',
        'Tolomeo sardo',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.2527069,
        10.5440412,
        NULL,
        178,
        '223 Borgo Malco, Di Maria lido, Italy',
        'Di Maria lido',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6548561,
        7.6877499,
        NULL,
        191,
        '53 Piazza Mirco, Tagliaferri veneto, Italy',
        'Tagliaferri veneto',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6491805,
        7.6444793,
        NULL,
        248,
        '10 Rotonda Saturniano, Ortensia nell''emilia, Italy',
        'Ortensia nell''emilia',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4282741,
        14.2733633,
        NULL,
        106,
        '55 Rotonda Quintiliano, Borgo Genziano, Italy',
        'Borgo Genziano',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4389994,
        14.2667436,
        NULL,
        210,
        '64 Strada Coppola, Sesto Gianpaolo lido, Italy',
        'Sesto Gianpaolo lido',
        'Italy',
        'Potenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0222382,
        11.9084318,
        'Ospedale di Feltre',
        271,
        '1 Rotonda Puglisi, Quarto Achille salentino, Italy',
        'Quarto Achille salentino',
        'Italy',
        'Brescia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.1745592,
        14.4476191,
        NULL,
        232,
        '22 Piazza Gaudino, Sesto Eberardo, Italy',
        'Sesto Eberardo',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3146871,
        9.1959876,
        NULL,
        213,
        '65 Borgo Dianora, Settimo Saturniano, Italy',
        'Settimo Saturniano',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.8044871,
        10.2698630,
        NULL,
        250,
        '0 Via Fiorella, Settimo Ella sardo, Italy',
        'Settimo Ella sardo',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2012587,
        11.4021080,
        NULL,
        102,
        '9 Incrocio Perla, Borelli lido, Italy',
        'Borelli lido',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1550524,
        9.1601365,
        NULL,
        42,
        '886 Borgo Giliola, Sesto Letterio laziale, Italy',
        'Sesto Letterio laziale',
        'Italy',
        'Enna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4720738,
        11.2026550,
        NULL,
        283,
        '6 Strada Gherardo, Sesto Delfina salentino, Italy',
        'Sesto Delfina salentino',
        'Italy',
        'Messina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3895277,
        10.9137911,
        NULL,
        63,
        '35 Borgo Ataleo, Quarto Consolata, Italy',
        'Quarto Consolata',
        'Italy',
        'Alessandria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.4156270,
        10.9589743,
        NULL,
        200,
        '58 Rotonda Adina, Sesto Daniele umbro, Italy',
        'Sesto Daniele umbro',
        'Italy',
        'Matera',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3457667,
        11.9570974,
        NULL,
        6,
        '912 Strada Colomba, Angelini laziale, Italy',
        'Angelini laziale',
        'Italy',
        'Ferrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.0817684,
        11.5999264,
        'Parcheggio',
        254,
        '8 Via Monte Grappa, Lendinara, Italy',
        'Lendinara',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5799857,
        12.6732122,
        NULL,
        174,
        '41 Incrocio Panfilo, Quarto Teodolinda salentino, Italy',
        'Quarto Teodolinda salentino',
        'Italy',
        'Torino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8419256,
        14.2505013,
        'Garage Oriente',
        198,
        '44 Via dei Greci, Napoli, Italy',
        'Napoli',
        'Italy',
        'Sondrio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3568742,
        11.8677817,
        NULL,
        79,
        '4 Incrocio Settimo, Settimo Saturniano, Italy',
        'Settimo Saturniano',
        'Italy',
        'Milano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0549517,
        10.8445650,
        NULL,
        234,
        '949 Strada Mercuri, Gioventino terme, Italy',
        'Gioventino terme',
        'Italy',
        'Lodi',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.6270657,
        9.2997417,
        NULL,
        222,
        '31 Rotonda Satta, Luchini nell''emilia, Italy',
        'Luchini nell''emilia',
        'Italy',
        'Frosinone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0177859,
        11.5873870,
        NULL,
        92,
        '1 Rotonda Di Marzio, Gamper calabro, Italy',
        'Gamper calabro',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4754945,
        13.7219693,
        NULL,
        66,
        '256 Piazza Sardina, Cherubino sardo, Italy',
        'Cherubino sardo',
        'Italy',
        'Trieste',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.1651295,
        9.4876106,
        'Sedda Ar Baccas',
        162,
        '0 Incrocio Ippoliti, Quarto Davide, Italy',
        'Quarto Davide',
        'Italy',
        'Venezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.9581832,
        8.2042152,
        'Privato',
        29,
        '899 Borgo Saul, Sesto Aureliano, Italy',
        'Sesto Aureliano',
        'Italy',
        'Modena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4352030,
        8.8684899,
        NULL,
        245,
        '67 Piazza Prudenzia, Costa terme, Italy',
        'Costa terme',
        'Italy',
        'Como',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3973803,
        14.7452855,
        NULL,
        41,
        '085 Strada Elpidio, Borgo Galileo, Italy',
        'Borgo Galileo',
        'Italy',
        'Firenze',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.7662584,
        12.3786060,
        NULL,
        114,
        '6 Incrocio Alice, Settimo Livino veneto, Italy',
        'Settimo Livino veneto',
        'Italy',
        'Cosenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.4643789,
        13.5724328,
        NULL,
        250,
        '923 Strada Caccavo, Lazzarini laziale, Italy',
        'Lazzarini laziale',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.0442031,
        13.9267469,
        NULL,
        287,
        '7 Contrada Aristofane, Rolfo terme, Italy',
        'Rolfo terme',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6138902,
        9.7273493,
        NULL,
        114,
        '49 Contrada Gemma, Sesto Abbondanzio, Italy',
        'Sesto Abbondanzio',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8516047,
        10.5249614,
        NULL,
        246,
        '169 Via Gianotti, Bonanni laziale, Italy',
        'Bonanni laziale',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.3441707,
        11.1129686,
        NULL,
        41,
        '2 Contrada Chianese, Settimo Amos, Italy',
        'Settimo Amos',
        'Italy',
        'Olbia-Tempio',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.3657461,
        13.3377403,
        NULL,
        171,
        '1 Strada Vidiano, Borgo Bernadetta, Italy',
        'Borgo Bernadetta',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.7007138,
        9.4520268,
        NULL,
        410,
        '78 Via Viscardo, Asdrubale ligure, Italy',
        'Asdrubale ligure',
        'Italy',
        'Benevento',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4956892,
        11.3284349,
        NULL,
        190,
        '8 Piazza Forgione, Sesto Settimo veneto, Italy',
        'Sesto Settimo veneto',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3867075,
        7.9541364,
        NULL,
        59,
        '3 Via Graziani, San Giorgio calabro, Italy',
        'San Giorgio calabro',
        'Italy',
        'Verona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.4169798,
        11.2789424,
        NULL,
        270,
        '131 Contrada Leonio, Quarto Brigida laziale, Italy',
        'Quarto Brigida laziale',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.3262046,
        10.0583808,
        NULL,
        182,
        '573 Via Adina, Termine calabro, Italy',
        'Termine calabro',
        'Italy',
        'Avellino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.6200300,
        11.8544600,
        NULL,
        158,
        '112 Strada Adolfo, Scarpellini veneto, Italy',
        'Scarpellini veneto',
        'Italy',
        'Piacenza',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.9682052,
        12.6891602,
        NULL,
        130,
        '0 Borgo Tiano, Pamela sardo, Italy',
        'Pamela sardo',
        'Italy',
        'Sassari',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2934320,
        9.9490303,
        NULL,
        228,
        '820 Borgo Vizziello, Settimo Eutalio, Italy',
        'Settimo Eutalio',
        'Italy',
        'Massa-Carrara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2643740,
        9.0907248,
        NULL,
        33,
        '899 Contrada Mimma, Ippoliti a mare, Italy',
        'Ippoliti a mare',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4757166,
        11.3955714,
        NULL,
        85,
        '776 Incrocio Bernardini, Euseo umbro, Italy',
        'Euseo umbro',
        'Italy',
        'Catania',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.8440297,
        12.2068348,
        NULL,
        9,
        '4 Piazza Zeno, Quarto Rodrigo, Italy',
        'Quarto Rodrigo',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5642256,
        8.9209133,
        NULL,
        249,
        '660 Strada Menconi, Mattia laziale, Italy',
        'Mattia laziale',
        'Italy',
        'Siena',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3605805,
        11.7288632,
        NULL,
        149,
        '999 Contrada Visentin, Sesto Edoardo ligure, Italy',
        'Sesto Edoardo ligure',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8577999,
        11.1008556,
        NULL,
        203,
        '863 Via Ciaccio, Sesto Rocco, Italy',
        'Sesto Rocco',
        'Italy',
        'Pordenone',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5079853,
        12.2870895,
        NULL,
        193,
        '02 Incrocio Elimena, Atzeni ligure, Italy',
        'Atzeni ligure',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.2905842,
        11.6241714,
        NULL,
        218,
        '028 Contrada Valente, Santamaria nell''emilia, Italy',
        'Santamaria nell''emilia',
        'Italy',
        'Pescara',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0921754,
        9.1373098,
        NULL,
        172,
        '1 Rotonda Almerigo, Quarto Zefiro, Italy',
        'Quarto Zefiro',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.0510053,
        10.8919385,
        NULL,
        203,
        '571 Contrada Durante, Elifio calabro, Italy',
        'Elifio calabro',
        'Italy',
        'Parma',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.6983666,
        13.3570052,
        NULL,
        232,
        '382 Borgo Pandolfi, Borgo Fausta, Italy',
        'Borgo Fausta',
        'Italy',
        'Terni',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1238059,
        11.1073287,
        NULL,
        3,
        '8 Via Gazzola, Gabrielli ligure, Italy',
        'Gabrielli ligure',
        'Italy',
        'Foggia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1981949,
        10.6305507,
        NULL,
        94,
        '257 Incrocio Galati, Tosi salentino, Italy',
        'Tosi salentino',
        'Italy',
        'Trapani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        46.0624628,
        11.2332573,
        NULL,
        201,
        '768 Borgo Pascarella, San Eberardo, Italy',
        'San Eberardo',
        'Italy',
        'Biella',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.8834553,
        11.7813374,
        NULL,
        159,
        '541 Borgo Pircher, Telica salentino, Italy',
        'Telica salentino',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7462875,
        13.6905991,
        NULL,
        222,
        '115 Piazza Piacentini, Settimo Efrem, Italy',
        'Settimo Efrem',
        'Italy',
        'Lucca',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7244748,
        11.4391796,
        NULL,
        50,
        '75 Contrada Candido, Di Bella umbro, Italy',
        'Di Bella umbro',
        'Italy',
        'Prato',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.4789829,
        11.1297642,
        NULL,
        173,
        '015 Rotonda Grassi, Settimo Simone ligure, Italy',
        'Settimo Simone ligure',
        'Italy',
        'Viterbo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1545307,
        10.9776947,
        NULL,
        200,
        '47 Strada Gargiulo, Zappia terme, Italy',
        'Zappia terme',
        'Italy',
        'Vercelli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8676082,
        9.2484275,
        NULL,
        148,
        '2 Strada Cecchetti, Aurelia sardo, Italy',
        'Aurelia sardo',
        'Italy',
        'Campobasso',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8569030,
        14.2452883,
        '2F',
        286,
        '3 Via Tagliabue, Sesto Lorenzo, Italy',
        'Sesto Lorenzo',
        'Italy',
        'Napoli',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7088999,
        11.5616832,
        NULL,
        91,
        '10 Contrada Manfredo, Borgo Ombretta lido, Italy',
        'Borgo Ombretta lido',
        'Italy',
        'Barletta-Andria-Trani',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.9069497,
        11.0007810,
        NULL,
        176,
        '5 Via Giada, Sesto Bernardo lido, Italy',
        'Sesto Bernardo lido',
        'Italy',
        'Vibo Valentia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.2335180,
        10.6189324,
        NULL,
        294,
        '9 Borgo Carolina, Fabrizio lido, Italy',
        'Fabrizio lido',
        'Italy',
        'Bologna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.5811150,
        9.7775130,
        NULL,
        254,
        '431 Incrocio Lorella, Adone sardo, Italy',
        'Adone sardo',
        'Italy',
        'Fermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7054464,
        8.4587482,
        'P1 Parcheggio temporaneo',
        231,
        '558 Strada Di Grezia, Sesto Manlio umbro, Italy',
        'Sesto Manlio umbro',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.1144986,
        13.6292421,
        NULL,
        150,
        '0 Rotonda Porziano, Foca calabro, Italy',
        'Foca calabro',
        'Italy',
        'Palermo',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.7515950,
        8.5375786,
        NULL,
        114,
        '7 Incrocio Calpurnia, Quarto Gioberto, Italy',
        'Quarto Gioberto',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.6610659,
        10.6487642,
        NULL,
        117,
        '38 Rotonda Agostinelli, Cellini del friuli, Italy',
        'Cellini del friuli',
        'Italy',
        'Ravenna',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        43.3834156,
        11.6110634,
        NULL,
        294,
        '35 Rotonda Barbarossa, Iannone nell''emilia, Italy',
        'Iannone nell''emilia',
        'Italy',
        'Salerno',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.0209714,
        14.4606790,
        NULL,
        141,
        '41 Incrocio Cleofe, Quarto Amauri, Italy',
        'Quarto Amauri',
        'Italy',
        'Pesaro e Urbino',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.8600986,
        7.9014319,
        NULL,
        239,
        '31 Contrada Sviturno, Rigoni nell''emilia, Italy',
        'Rigoni nell''emilia',
        'Italy',
        'Isernia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.3026685,
        11.9699118,
        NULL,
        190,
        '57 Strada Forte, Settimo Gildo, Italy',
        'Settimo Gildo',
        'Italy',
        'Udine',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        40.8625435,
        14.2709039,
        'Via Arenaccia, 154 Garage',
        300,
        '3 Via Zenone, Quarto Taziano del friuli, Italy',
        'Quarto Taziano del friuli',
        'Italy',
        'Aosta',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.9776281,
        11.0971168,
        NULL,
        124,
        '361 Strada Suriano, Puglisi salentino, Italy',
        'Puglisi salentino',
        'Italy',
        'Medio Campidano',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5518344,
        12.0740497,
        'Piazzale Bastia',
        264,
        '39 Borgo Desiderio, Leonio laziale, Italy',
        'Leonio laziale',
        'Italy',
        'Reggio Emilia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.5183472,
        12.6823713,
        NULL,
        273,
        '805 Piazza Corsini, Borgo Belina, Italy',
        'Borgo Belina',
        'Italy',
        'Grosseto',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1936101,
        10.1512170,
        NULL,
        247,
        '7 Via Isidora, Sesto Salvatore ligure, Italy',
        'Sesto Salvatore ligure',
        'Italy',
        'Lecce',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.8381191,
        9.0348821,
        NULL,
        278,
        '944 Contrada Albano, Pavone ligure, Italy',
        'Pavone ligure',
        'Italy',
        'La Spezia',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        45.6537330,
        8.2692386,
        NULL,
        9,
        '81 Contrada Mottola, Torrisi veneto, Italy',
        'Torrisi veneto',
        'Italy',
        'Reggio Calabria',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.2892791,
        14.0058335,
        NULL,
        197,
        '15 Contrada Artioli, Borgo Agazio, Italy',
        'Borgo Agazio',
        'Italy',
        'Ancona',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        41.1582638,
        9.3217702,
        NULL,
        199,
        '8 Piazza Castaldo, Valeri del friuli, Italy',
        'Valeri del friuli',
        'Italy',
        'Latina',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        42.1573697,
        14.0026521,
        NULL,
        97,
        '03 Strada Franzè, Sesto Serena sardo, Italy',
        'Sesto Serena sardo',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4623179,
        11.4971628,
        NULL,
        129,
        '1 Piazza Marco, San Riccarda sardo, Italy',
        'San Riccarda sardo',
        'Italy',
        'Macerata',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.1040576,
        12.5156400,
        'Montmartre Parking',
        116,
        '907 Contrada Lauri, San Ezechiele sardo, Italy',
        'San Ezechiele sardo',
        'Italy',
        'Rieti',
        ''
      );
    

      select public."insert_parking_lot"(
        2,
        44.4513592,
        11.5023639,
        NULL,
        27,
        '0 Strada Dante, Santucci veneto, Italy',
        'Santucci veneto',
        'Italy',
        'Cuneo',
        ''
      );
    
  